var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/route/upload/image.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube/cubemig.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 3);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 4);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 5);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let couponCd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let couponName = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discountPrice = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: couponCd,
                coupon_type: 3,
                // 全商品
                coupon_name: couponName,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discountPrice,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                customer_id: record.customer_id,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
        return res;
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/collection.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
      return res;
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.aggregate(query).toArray());
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let ItemController;
module.watch(require("../../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/service/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 5);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  //
  // 商品情報登録と更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              let quantity = Promise.await(itemController.getStock(item._id));
              Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/tooltest.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      const newLocal = Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
        throw e;
      })));
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return newLocal;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/wowma.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 4);
let request;
module.watch(require("request-promise"), {
  default(v) {
    request = v;
  }

}, 5);
let WowmaApi;
module.watch(require("../imports/service/wowmaApi"), {
  default(v) {
    WowmaApi = v;
  }

}, 6);
let utilError;
module.watch(require("../imports/util/error"), {
  default(v) {
    utilError = v;
  }

}, 7);
const tag = 'wowma';
Meteor.methods({
  //
  // WOWMA 商品データベース上の商品を公開する
  [`${tag}.updateItem.open`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('Wowma! 商品データベース上の商品を公開する', () => Promise.asyncApply(() => {
        //
        // jline_engine 商品データベースへの接続
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); //
        // 商品情報の作成

        let cur = Promise.await(itemController.Items.aggregate([{
          $match: {
            $and: [{
              'mall.wowma.itemCode': {
                $exists: 1
              }
            }]
          }
        }, {
          // 商品コードの一覧を作る
          $group: {
            _id: '$mall.wowma.itemCode'
          }
        }, {
          $project: {
            _id: 0,
            itemCode: '$_id'
          }
        }])); // 得られた商品ごとにAPIリクエストを発行

        let api = new WowmaApi(config.wowmaApiPost, config.shopId);
        Promise.await(report.forEachOnCursor(cur, item => Promise.asyncApply(() => {
          item.saleStatus = 1;
          item.limitedPasswd = 'NULL';

          try {
            let res = Promise.await(api.updateItem(item));
            return {
              requestBody: item,
              response: res
            };
          } catch (e) {
            throw Object.assign({
              requestBody: item
            }, utilError.parse(e));
          }
        })));
      })));
      return report.publish();
    });
  },

  //
  // WOWMA 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('WOWMA! 在庫更新', () => Promise.asyncApply(() => {
        //
        // 在庫情報の作成
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        let cur = Promise.await(itemController.Items.aggregate([{
          $match: {
            $and: [{
              'mall.wowma.itemCode': {
                $exists: 1
              } // テスト検索条件設定
              //   ,{
              //     $or: [
              //       {
              //         'mall.wowma.itemCode': '10005402'
              //       }
              //       ,{
              //         'mall.wowma.itemCode': 'gk-163'
              //       }
              //       ,{
              //         'mall.wowma.itemCode': '10004743'
              //       }
              //     ]
              //   }

            }]
          }
        }, {
          // 配送方法の違いを省く
          $group: {
            _id: {
              itemCode: '$mall.wowma.itemCode',
              choicesStockHorizontalCode: '$mall.wowma.HChoiceName',
              choicesStockVerticalCode: '$mall.wowma.VChoiceName'
            },
            item: {
              $first: '$_id'
            }
          }
        }, {
          // 商品ページごと（商品コード）にグループ化する
          $group: {
            _id: '$_id.itemCode',
            variations: {
              $push: {
                _id: '$item',
                choicesStockHorizontalCode: '$_id.choicesStockHorizontalCode',
                choicesStockVerticalCode: '$_id.choicesStockVerticalCode'
              }
            }
          }
        }, {
          $project: {
            _id: 0,
            itemCode: '$_id',
            variations: '$variations'
          }
        }])); // let resMongo = await cur.toArray()
        // return resMongo
        // リクエストボディ

        while (Promise.await(cur.hasNext())) {
          let item = Promise.await(cur.next()); // 在庫を設定する

          for (let e of item.variations) {
            e.stock = Promise.await(itemController.getStock(e._id));
            delete e._id;
          } //
          // 在庫更新リクエスト


          let api = new WowmaApi(config.wowmaApiPost, config.shopId);

          try {
            let res = Promise.await(api.updateStock([item]));
            report.iSuccess(res);
          } catch (e) {
            report.iError(e);
          }
        }

        cur.close();
      })));
      return report.publish();
    });
  },

  //
  // WOWMA 商品検索
  [`${tag}.searchItem`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('WOWMA! 商品情報取得', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // APIから取得した商品情報を保存する場所


        const workdir = `${config.workdir}/items_${new Date().getTime()}`; // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(workdir));
        } catch (e) {} // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let options = JSON.parse(JSON.stringify(config.wowmaApi));
            options.uri = `${options.uri}/searchItemInfo`;
            options.qs.itemCode = item.mall.wowma.itemCode;
            let repos = Promise.await(request(options));
            let filename = `${workdir}/${item.model}.xml`;
            Promise.await(fsExtra.writeFile(filename, repos));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/wowmaApi.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let WowmaApiItemFilter;
module.watch(require("../imports/service/dbfilter"), {
  WowmaApiItemFilter(v) {
    WowmaApiItemFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
const tag = 'wowmaApi';
Meteor.methods({
  //
  // WOWMA商品情報取得
  [`${tag}.getItem`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('WOWMA! 商品情報取得', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new WowmaApiItemFilter(config.wowmaApi, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // // 作業フォルダを作成する
        // try {
        //   await fsExtra.mkdir(config.workdir)
        // } catch (e) {}
        // // APIから取得した商品情報を保存する場所
        // const workdir = `${config.workdir}/items_${(new Date()).getTime()}`
        // // 作業フォルダを作成する
        // try {
        //   await fsExtra.mkdir(workdir)
        // } catch (e) {}
        // メインループ
        //

        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            report.iSuccess(item);
          })
        }));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/yauct.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
let PassThrough, Transform;
module.watch(require("stream"), {
  PassThrough(v) {
    PassThrough = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 9);
const prefix = 'packet';
const tag = 'yauct';
Meteor.methods({
  //
  // ヤフオク受注ファイル
  [`${tag}.order`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク受注', () => Promise.asyncApply(() => {
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        const workdir = `${config.workdir}/order`;
        const r = fsExtra.createReadStream(`${workdir}/${config.orderLoadfile}`);
        const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`);
        r.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
          columns: true
        })).pipe(csv.transform((record, callback) => Promise.asyncApply(() => {
          let err = null; // 管理番号を置き換える

          try {
            record['管理番号'] = Promise.await(itemController.getModelClass(record['管理番号']));
          } catch (e) {
            err = e;
          }

          callback(err, record);
        }))).pipe(csv.stringify({
          header: true
        })).pipe(iconv.decodeStream('UTF-8')).pipe(iconv.encodeStream('SJIS')).pipe(w);
      })));
    });
  },

  //
  // ヤフオク出品ファイル
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク出品', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 繰り返し処理を任意の（packetSize）で分割

        const packet = new Packet(config.packetSize); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // CSVファイルを作成し画像データを収集する場所


        const workdir = `${config.workdir}/work`;
        Promise.await(fsExtra.remove(workdir));
        Promise.await(fsExtra.mkdir(workdir)); // ZIPファイルを保存する場所

        const uploaddir = `${config.workdir}/upload`;
        Promise.await(fsExtra.remove(uploaddir));
        Promise.await(fsExtra.mkdir(uploaddir));
        let cd = null; // パケットフォルダ

        let filename = null; // csvファイル

        let name = null; // パケット番号
        // CSVフィールドを定義し、順番を確定する

        let fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
        let header = fields.map(v => `"${v}"`).join(',') + '\n'; // パケット化開始時

        packet.onPacketStart = packetCount => Promise.asyncApply(() => {
          name = prefix + ('00000' + packetCount).slice(-5);
          cd = `${workdir}/${name}`;
          filename = `${cd}/${config.csvFileName}`;
          Promise.await(fsExtra.mkdir(cd)); // CSVファイルにフィールドを設定する

          Promise.await(fsExtra.appendFile(filename, iconv.encode(header, 'Shift_JIS')));
        }); // パケット化時


        packet.onPacket = arg => Promise.asyncApply(() => {
          let yauct = arg.yauct;
          let item = arg.item; // csvファイルにレコード（商品テンプレート）を追加する

          let record = fields.map(v => {
            return yauct[v] ? `"${yauct[v]}"` : '""';
          }).join(',') + '\n';
          Promise.await(fsExtra.appendFile(filename, iconv.encode(record, 'Shift_JIS'))); // 画像ファイルをコピー

          for (let img of item.images) {
            let imgSrc = `${config.imagedir}/${img}`;
            let imgTgt = `${cd}/${img}`;

            try {
              // 同じファイルがある場合はコピーしない
              Promise.await(fsExtra.access(imgTgt));
            } catch (e) {
              Promise.await(fsExtra.copyFile(imgSrc, imgTgt));
            }
          }
        }); // パケット終了時


        packet.onPacketEnd = packetCount => Promise.asyncApply(() => {
          const zip = archiver('zip');
          const zipname = `${uploaddir}/${name}.zip`;
          const output = fsExtra.createWriteStream(zipname);
          zip.pipe(output);
          zip.directory(cd, false);
          zip.finalize();
        }); // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id)); // itemに定義されている最低必要在庫より多い商品を出品する

            if (quantity >= item.mall.yauct.minQuantity) {
              let yauct = Promise.await(itemController.convertItemYauct(config.default, item));
              Promise.await(packet.submit({
                yauct: yauct,
                item: item
              }));
            }
          })
        }));
        packet.close();
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/configs.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/filters.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/groups.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/logs.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Logs: () => Logs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Logs = new Mongo.Collection('logs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/uploads.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/cube3api.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);

class Cube3Api {
  /**
   *
   * @param {MySQL} mysql
   */
  constructor(mysql) {
    this.mysql_ = mysql;
  }

  updateStock(productClassId, quantity = 0) {
    return Promise.asyncApply(() => {
      Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      }));
      Promise.await(this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      }));
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = []; // 削除するタグ

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      }); // 表示するタグ


      let tagon = tag => Promise.asyncApply(() => {
        // すでに表示されているタグがあれば何もしない
        let sql = `
      SELECT COUNT(*) FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        let countRes = Promise.await(this.mysql_.query(sql));
        if (countRes[0]['COUNT(*)']) return;
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creatorId,
          create_date: 'NOW()'
        })));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let productId = data.product_id;
      let images = data.images;
      let creatorId = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${productId}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        Promise.await(this.mysql_.queryInsert('dtb_product_image', {
          product_id: productId,
          creator_id: creatorId,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        }));
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let updateData = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      Promise.await(this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      })); // dtb_product_class

      updateData = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      let res = Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      }));
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = {};
      let updateData = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', updateData, {
        creator_id: creatorId,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      updateData = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', updateData, {
        creator_id: creatorId,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creatorId,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/dbfilter.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter,
  WowmaApiItemFilter: () => WowmaApiItemFilter
});
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 1);
let request;
module.watch(require("request-promise"), {
  default(v) {
    request = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let xml2js;
module.watch(require("xml-js"), {
  xml2js(v) {
    xml2js = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case 'mysql':
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    switch (plug.type) {
      case 'mysql':
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error('invalid plug type');
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   *
   *
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== 'undefined') {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      let res = Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
      return res;
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find(); // カーソルのタイムアウトを解除

      cur.addCursorFlag('noCursorTimeout', true); // すべてのドキュメントをループ

      try {
        while (Promise.await(cur.hasNext())) {
          let doc = Promise.await(cur.next());
          Promise.await(onResult(doc, context));
        }

        ;
      } finally {
        // カーソルを開放
        Promise.await(cur.close());
      }
    }));
  }

}

class WowmaApiItemFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // 商品情報の取得ループを定義

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      // コレクションを取得
      let options = JSON.parse(JSON.stringify(plug));
      options.uri = `${options.uri}/searchStocks`;
      let context = {
        options: options
      };

      while (1) {
        // Wowma Api から商品情報を取得
        let res = Promise.await(request(options));
        res = xml2js(res, {
          compact: true
        });
        let maxCount = Number(res.response.searchResult.maxCount._text);
        let resultCount = Number(res.response.searchResult.resultCount._text);
        let startCount = Number(res.response.searchResult.startCount._text);
        let resultStocks = res.response.searchResult.resultStocks; // 取得した商品情報をカスタムプロセスに渡す

        if (resultStocks instanceof Array) {
          // 取得したデータが複数商品の場合
          for (let i = 0; i < resultCount; i++) {
            Promise.await(onResult(resultStocks[i], context));
          }
        } else {
          // 取得したデータが単数商品の場合
          Promise.await(onResult(resultStocks, context));
        }

        let next = startCount + resultCount;
        if (next > maxCount) break;
        options.qs.startCount = next;
      }
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/items.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);
let ObjectID;
module.watch(require("bson"), {
  ObjectID(v) {
    ObjectID = v;
  }

}, 2);
let TextUtil;
module.watch(require("../util/text"), {
  default(v) {
    TextUtil = v;
  }

}, 3);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(itemId) {
    return Promise.asyncApply(() => {
      let item = Promise.await(this.Items.findOne({
        _id: itemId
      }, {
        projection: {
          'product': 1
        }
      }));
      let productSet = item.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[{ids:[<ObjectId>],set:<Number>}]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let productRef of productSet) {
        let prdQuantity = 0;

        for (let id of productRef.ids) {
          let product = Promise.await(this.Products.findOne({
            _id: id
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stockArray = product.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stockArray) {
            prdQuantity += stock.quantity;
          }
        } // 商品(item)の在庫数 = 製品在庫数(prdQuantity) / 必要セット数(productRef.set)


        quantities.push(Math.floor(prdQuantity / productRef.set));
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   *
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   *
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   *
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   *
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   *
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }
  /**
   * 指定の商品に関連する商品群の属性別の商品情報を返す。
   *
   * 引数として受け取るitemは任意の商品情報。
   * itemに関連する商品群について必要な情報を整理し返す。
   *
   * projectに参照したい商品情報フィールドを定義する。
   * メソッドの呼び出し時に必要に応じてprojectを設定する。
   *
   * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
   *
   * @param {Object} item
   * @param {Object} project
   */


  getVariation(item, project) {
    return Promise.asyncApply(() => {
      /**
       * aggregation設定
       *
       * label: 属性名（配送方法、カラー、サイズなど）
       * current: 指定されたアイテム（item）が該当する項目
       * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
       * query: aggregation対象とするドキュメントの検索条件
       */
      let set = [{
        label: '配送方法',
        current: item.delivery,
        project: {
          value: '$delivery'
        },
        query: {
          class1_value: item.class1_value,
          class2_value: item.class2_value
        }
      }, {
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          delivery: item.delivery,
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          delivery: item.delivery,
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }, {
            $sort: {
              _id: 1
            }
          }]).toArray()),
          props: s
        });
      }

      for (let attr of attrs) {
        for (let v of attr.variations) {
          v.stock = Promise.await(this.getStock(v._id));
        }
      }

      return attrs;
    });
  } // モデルクラス形式を作る
  // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]


  getModelClass(arg) {
    return Promise.asyncApply(() => {
      let item; // item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

      if (typeof arg === 'string') {
        let exp = new RegExp(`${arg}$`);
        let cur = this.Items.find({}, {
          projection: {
            model: 1,
            class1_value: 1,
            class2_value: 1
          }
        });

        while (1) {
          try {
            item = Promise.await(cur.next());
            let match = Promise.await(item._id.toHexString().match(exp));

            if (match) {
              break;
            }
          } catch (e) {
            // 該当するitemデータがない
            cur.close();
            return arg;
          }
        }

        cur.close();
      } else {
        item = arg;
      }

      let modelClass = [];
      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value);
      return modelClass.join('/');
    });
  }

  convertItemCube3(creatorId, item) {
    return Promise.asyncApply(() => {
      // 値変換
      let convDeliv = delivery => delivery === 'ゆうパケット' ? 'ポスト投函' : delivery; // product_id


      let productId = null;
      let modelClass = []; // 下記の形式を作る
      // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]

      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let productTypeId;

      switch (item.delivery) {
        case '宅配便':
          productTypeId = 1;
          break;

        case 'ゆうパケット':
          productTypeId = 2;
          break;

        default:
          productTypeId = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let deliveryFee = null;

      switch (item.delivery) {
        case '宅配便':
          deliveryFee = null;
          break;

        case 'ゆうパケット':
          deliveryFee = 240;
          break;
      } //
      // 顧客向けバリエーション商品選択機能の実装
      //


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      })); // HTML バリエーション商品ごとのリンク付きボタンを表示する
      // 値の変換

      attrs = attrs.map(attr => {
        attr.props.current = convDeliv(attr.props.current);
        attr.variations = attr.variations.map(variation => {
          variation.value = convDeliv(variation.value);
          return variation;
        });
        return attr;
      }); // HTML生成

      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row">` + `<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">` + `<strong>${attr.props.label}</strong>` + `</div>` + attr.variations.map(variation => {
        if (attr.props.current === variation.value) {
          // 表示中の商品ボタン
          return `<button class="btn btn-success btn-sm btn-item-class-select"><strong>${variation.value}</strong></button>`;
        } else if (variation.stock > 0) {
          // 販売可能商品のボタン
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-sm btn-item-class-select">${variation.value}</button></a>`;
        } else {
          // 販売不可能商品のボタン（在庫なし）
          return `<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">${variation.value}</button>`;
        }
      }).join('') + '</div>' + '</div>').join('');
      let descriptionDetail = `
    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>
    ${variationHtml}
    `; // 商品データを作る

      let data = {
        product_id: productId,
        creator_id: creatorId,
        name: `${modelClass.join('/')} ${convDeliv(item.delivery)} ${item.name} ${item.jan_code}`,
        description_detail: descriptionDetail,
        free_area: item.description + ' ',
        product_code: modelClass.join('/'),
        price01: item.retail_price,
        price02: item.sales_price * 0.95,
        // 楽天価格から5%値引き
        images: item.images,
        product_type_id: productTypeId,
        tags: tags,
        delivery_fee: deliveryFee
      };
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  } // ヤフオクテンプレートへの変換


  convertItemYauct(def, item) {
    return Promise.asyncApply(() => {
      const idLength = 20;
      const titleLength = 130;
      let yauct = {}; // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）

      yauct = JSON.parse(JSON.stringify(def[item.delivery])); // 画像の記述

      const imgPrefix = '画像';

      for (let i = 0; i < item.images.length; i++) {
        yauct[imgPrefix + (i + 1)] = item.images[i];
      } // タイトル


      yauct['カテゴリ'] = item.mall.yauct.category;
      yauct['タイトル'] = TextUtil.substr8(`${Promise.await(this.getModelClass(item))} ${item.delivery} ${item.name}`, titleLength);
      yauct['開始価格'] = item.sales_price;
      yauct['即決価格'] = item.sales_price;
      yauct['管理番号'] = item._id.toHexString().slice(-idLength);
      yauct['説明'] = item.description;
      yauct['JANコード・ISBNコード'] = item.jan_code;
      return yauct;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/wowmaApi.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => WowmaApi
});
let request;
module.watch(require("request-promise"), {
  default(v) {
    request = v;
  }

}, 0);
let json2xml;
module.watch(require("xml-js"), {
  json2xml(v) {
    json2xml = v;
  }

}, 1);
let utilError;
module.watch(require("../util/error"), {
  default(v) {
    utilError = v;
  }

}, 2);
const BASE_URI = 'https://api.manager.wowma.jp/wmshopapi';

class WowmaApi {
  constructor(plug, shopId) {
    this.plug = plug;
    this.shopId = shopId;
  } // 商品情報更新


  updateItem(updateItem) {
    return Promise.asyncApply(() => {
      let request = `<request><shopId>${this.shopId}</shopId><updateItem>${json2xml(updateItem, {
        compact: true
      })}</updateItem></request>`;

      try {
        let res = Promise.await(this.requestPost('updateItemInfo', request));
        return {
          response: res,
          requestXML: request
        };
      } catch (e) {
        throw Object.assign(utilError.parse(e), {
          requestXML: request
        });
      }
    });
  }

  requestPost(method, body) {
    return Promise.asyncApply(() => {
      // 接続オプションの作成
      let apiRequest = {
        method: 'POST',
        uri: `${BASE_URI}/${method}`,
        body: body // 共通の接続設定と結合する

      };
      Object.assign(apiRequest, this.plug); // リクエスト発行

      let res = Promise.await(request(apiRequest));
      return res;
    });
  }

  updateStock(stockUpdateItem) {
    return Promise.asyncApply(() => {
      // 接続オプションの作成
      let apiRequest = {
        method: 'POST',
        uri: `${BASE_URI}/updateStock` // 共通の接続設定と結合する

      };
      Object.assign(apiRequest, this.plug);
      apiRequest.body = Promise.await(this.updateStockCreateRequestBody(stockUpdateItem)); // リクエスト発行

      let res = Promise.await(request(apiRequest));
      return res;
    });
  }

  updateStockCreateRequestBody(stockUpdateItem) {
    return Promise.asyncApply(() => {
      //
      // stockUpdateItem =
      // [
      //   {
      //     itemCode: <String>,
      //     variations: [
      //        {
      //          choicesStockHorizontalCode: <String>,
      //          choicesStockVerticalCode: <String>,
      //          stock: <Number>
      //        }
      //     ]
      //   }
      // ]
      let stockUpdateItemXML = '';

      for (let item of stockUpdateItem) {
        // 値のチェック
        for (let e of item.variations) {
          // 在庫数の上限100
          if (e.stock > 100) e.stock = 100;
        }

        stockUpdateItemXML += '<stockUpdateItem>';
        stockUpdateItemXML += `<itemCode>${item.itemCode}</itemCode>`; // 商品在庫種別を振り分け
        // 1 -> 通常商品
        // 2 -> 選択肢別在庫

        let var0 = item.variations[0];

        if (var0.choicesStockHorizontalCode === '' && var0.choicesStockVerticalCode === '') {
          // 通常商品
          stockUpdateItemXML += '<stockSegment>1</stockSegment>';
          stockUpdateItemXML += `<stockCount>${var0.stock}</stockCount>`;
        } else {
          // 選択肢別在庫
          stockUpdateItemXML += '<stockSegment>2</stockSegment>'; // リクエストボディを作成する

          for (let variation of item.variations) {
            // 在庫設定タグの名前を差し替える
            variation.choicesStockCount = variation.stock;
            delete variation.stock; // xmlを構成する

            stockUpdateItemXML += '<choicesStocks>';

            for (let key of Object.keys(variation)) {
              stockUpdateItemXML += `<${key}>${variation[key]}</${key}>`;
            }

            stockUpdateItemXML += '</choicesStocks>';
          }
        }

        stockUpdateItemXML += '</stockUpdateItem>';
      } // リクエストボディの作成


      let apiRequestBody = `
    <request>
    <shopId>${this.shopId}</shopId>
    ${stockUpdateItemXML}
    </request>
    `; // リクエストボディを返す

      return apiRequestBody;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/error.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mongo.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mysql.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   *
   * @param {String} sql
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, dataSql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(dataSql)) {
        map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, dataSql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(dataSql)) {
        updates.push(`${k}=${dataSql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/packet.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Packet
});

class Packet {
  constructor(packetSize) {
    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  submit(arg) {
    return Promise.asyncApply(() => {
      // packetSizeの回数ごとに、初期化を呼び出す
      if (this.count % this.packetSize === 0) {
        if (this.onPacketStart) {
          Promise.await(this.onPacketStart(this.packetCount));
        }
      }

      if (this.onPacket) {
        Promise.await(this.onPacket(arg));
      }

      this.count++; // packetSizeの回数ごとに、終了処理を呼び出す

      if (this.count % this.packetSize === 0) {
        this.close();
        this.packetCount++;
      }
    });
  }

  close() {
    if (this.onPacketEnd) {
      this.onPacketEnd(this.packetCount);
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/report.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Logs;
module.watch(require("../collection/logs"), {
  Logs(v) {
    Logs = v;
  }

}, 2);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 3);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  } // private


  setupIterator(phaseId) {
    this.iterator = new Iterator(phaseId);
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let rec = {
        phaseId: uniqid()
      };
      this.setupIterator(rec.phaseId);

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        // ループ処理のレポートを作成
        if (this.iterator.metric.total) {
          Object.assign(rec, {
            iterator: this.iterator.metric
          });
        } // タイムスタンプ


        rec.timeStamp = new Date(); // レポートをデータベースに記録

        Logs.insert(rec); // 呼び出し元用レポートに追加

        this.record.push(rec);
      }
    });
  } // カーソルをループし、与えられた関数を実行
  // 呼び出す関数の引数にはカーソルから得られたドキュメントを渡す


  forEachOnCursor(cur, fn) {
    return Promise.asyncApply(() => {
      while (Promise.await(cur.hasNext())) {
        let doc = Promise.await(cur.next());

        try {
          // リクエスト発行
          let res = Promise.await(fn(doc));
          this.iSuccess(res);
        } catch (e) {
          this.iError(e);
        }
      }

      cur.close();
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    // 呼び出し元へレポート
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor(phaseId) {
    this.metric = {
      total: 0,
      success: 0,
      error: 0,
      phaseId: phaseId
    };
    this.lastError = null;
  }

  success(newRecord) {
    if (newRecord) {
      this.log(newRecord, true);
    }

    this.metric.success++;
    this.metric.total++;
  }

  error(newRecord) {
    // 直前と同じエラーは省く
    if (JSON.stringify(this.lastError) !== JSON.stringify(newRecord)) {
      if (newRecord && newRecord !== {} && newRecord !== '') {
        this.log(newRecord, false);
        this.lastError = newRecord;
      }
    }

    this.metric.error++;
    this.metric.total++;
  }

  log(newRecord, isSuccess
  /* true => success or false => error */
  ) {
    let rec = {
      success: isSuccess,
      phaseId: this.metric.phaseId,
      message: newRecord,
      timeStamp: new Date()
    };
    Logs.insert(rec);
  }

  errorOcurred() {
    return this.metric.error;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/text.js                                                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => TextUtil
});

class TextUtil {
  static substr8(text, len, truncation) {
    if (truncation === undefined) {
      truncation = '';
    }

    var textArray = text.split('');
    var count = 0;
    var str = '';

    for (let i = 0; i < textArray.length; i++) {
      var n = escape(textArray[i]);
      if (n.length < 4) count++;else count += 2;

      if (count > len) {
        return str + truncation;
      }

      str += text.charAt(i);
    }

    return text;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/wowmaApi.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90b29sdGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvd293bWFBcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci95YXVjdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9jb25maWdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3Vwcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2xvZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi91cGxvYWRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvY3ViZTNhcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2Uvd293bWFBcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9lcnJvci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL21vbmdvLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbXlzcWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9wYWNrZXQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9yZXBvcnQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC90ZXh0LmpzIl0sIm5hbWVzIjpbImZzIiwibW9kdWxlIiwid2F0Y2giLCJyZXF1aXJlIiwiZGVmYXVsdCIsInYiLCJ1bmlxaWQiLCJtdWx0aXBhcnR5IiwiVXBsb2FkcyIsIm11bHRpcGFydHlNaWRkbGV3YXJlIiwicm91dGUiLCJXZWJBcHAiLCJjb25uZWN0SGFuZGxlcnMiLCJ1c2UiLCJyZXEiLCJyZXNwIiwicmVhZGVyIiwiTWV0ZW9yIiwid3JhcEFzeW5jIiwicmVhZEZpbGUiLCJ3cml0ZXIiLCJ3cml0ZUZpbGUiLCJ1cGxvYWRJZCIsImZpbGUiLCJmaWxlcyIsImRhdGEiLCJwYXRoIiwiZmlsZW5hbWUiLCJzYXZlUGF0aCIsImJvZHkiLCJpbWFnZWRpciIsImRvYyIsImNsaWVudEZpbGVOYW1lIiwibmFtZSIsInVwbG9hZGVkRmlsZU5hbWUiLCJlcnIiLCJlcnJvciIsImluc2VydCIsIndyaXRlSGVhZCIsImVuZCIsIkpTT04iLCJzdHJpbmdpZnkiLCJzYXZlRGlyIiwiY3J5cHRvIiwiTXlTUUwiLCJSZXBvcnQiLCJHcm91cCIsIkdyb3VwRmFjdG9yeSIsIkZpbHRlciIsInRhZyIsIm1ldGhvZHMiLCJjb25maWciLCJyZXBvcnQiLCJmaWx0ZXIiLCJzcmNGaWx0ZXJJZCIsInRlc3RRdWVyeSIsImRzdERiIiwiZHN0IiwiY3JlZCIsInBoYXNlIiwicXVlcnkiLCJyZXMiLCJmb3JlYWNoIiwibW9iaWxlTnVsbCIsInJlY29yZCIsInNxbCIsImN1c3RvbWVyX2lkIiwic3RhdHVzIiwic2V4Iiwiam9iIiwiY291bnRyeV9pZCIsInByZWYiLCJuYW1lMDEiLCJuYW1lMDIiLCJrYW5hMDEiLCJrYW5hMDIiLCJjb21wYW55X25hbWUiLCJ6aXAwMSIsInppcDAyIiwiemlwY29kZSIsImFkZHIwMSIsImFkZHIwMiIsImVtYWlsIiwidGVsMDEiLCJ0ZWwwMiIsInRlbDAzIiwiZmF4MDEiLCJmYXgwMiIsImZheDAzIiwiYmlydGgiLCJwYXNzd29yZCIsInNhbHQiLCJzZWNyZXRfa2V5IiwiZmlyc3RfYnV5X2RhdGUiLCJsYXN0X2J1eV9kYXRlIiwiYnV5X3RpbWVzIiwiYnV5X3RvdGFsIiwibm90ZSIsImNyZWF0ZV9kYXRlIiwidXBkYXRlX2RhdGUiLCJkZWxfZmxnIiwicXVlcnlJbnNlcnQiLCJlIiwiaUVycm9yIiwiY3VzdG9tZXJfYWRkcmVzc19pZCIsImlkIiwibWFpbG1hZ2FfZmxnIiwiY291cG9uQ2QiLCJyYW5kb21CeXRlcyIsInRvU3RyaW5nIiwic3Vic3RyaW5nIiwiY291cG9uTmFtZSIsImRpc2NvdW50UHJpY2UiLCJwb2ludCIsImNvdXBvbl9pZCIsImNvdXBvbl9jZCIsImNvdXBvbl90eXBlIiwiY291cG9uX25hbWUiLCJkaXNjb3VudF90eXBlIiwiY291cG9uX3VzZV90aW1lIiwiY291cG9uX3JlbGVhc2UiLCJkaXNjb3VudF9wcmljZSIsImRpc2NvdW50X3JhdGUiLCJlbmFibGVfZmxhZyIsImNvdXBvbl9tZW1iZXIiLCJjb3Vwb25fbG93ZXJfbGltaXQiLCJhdmFpbGFibGVfZnJvbV9kYXRlIiwiYXZhaWxhYmxlX3RvX2RhdGUiLCJwdWJsaXNoIiwicHJvZmlsZSIsImRiIiwiTW9uZ29Db2xsZWN0aW9uIiwicGx1ZyIsInByb2plY3Rpb24iLCJjb2xsIiwiZ2V0IiwiY29sbGVjdGlvbiIsImZpbmQiLCJ0b0FycmF5IiwiYWdncmVnYXRlIiwiSXRlbUNvbnRyb2xsZXIiLCJtb2RlbCIsImNsYXNzMSIsImNsYXNzMiIsIml0ZW1jb24iLCJpbml0IiwidXBsb2FkZWQiLCJzZXRJbWFnZSIsImNsZWFuSW1hZ2UiLCJNb25nb0RCRmlsdGVyIiwiQ3ViZTNBcGkiLCJpdGVtc0RCIiwiaXRlbUNvbnRyb2xsZXIiLCJ0YXJnZXREQiIsImN1YmUzREIiLCJhcGkiLCJpdGVtIiwiY29udGV4dCIsInF1YW50aXR5IiwiZ2V0U3RvY2siLCJfaWQiLCJ1cGRhdGVTdG9jayIsIm1hbGwiLCJzaGFyYWt1U2hvcCIsInByb2R1Y3RfY2xhc3NfaWQiLCJjb2wiLCJjdWJlSXRlbSIsImNvbnZlcnRJdGVtQ3ViZTMiLCJjcmVhdG9yX2lkIiwiaW5zZXJ0UmVzIiwicHJvZHVjdENyZWF0ZSIsInVwZGF0ZSIsIiRzZXQiLCJpU3VjY2VzcyIsInByb2R1Y3RJbWFnZVVwZGF0ZSIsInByb2R1Y3RVcGRhdGUiLCJwcm9kdWN0VGFnVXBkYXRlIiwibmV3TG9jYWwiLCJmc0V4dHJhIiwicmVxdWVzdCIsIldvd21hQXBpIiwidXRpbEVycm9yIiwiY3VyIiwiSXRlbXMiLCIkbWF0Y2giLCIkYW5kIiwiJGV4aXN0cyIsIiRncm91cCIsIiRwcm9qZWN0IiwiaXRlbUNvZGUiLCJ3b3dtYUFwaVBvc3QiLCJzaG9wSWQiLCJmb3JFYWNoT25DdXJzb3IiLCJzYWxlU3RhdHVzIiwibGltaXRlZFBhc3N3ZCIsInVwZGF0ZUl0ZW0iLCJyZXF1ZXN0Qm9keSIsInJlc3BvbnNlIiwiT2JqZWN0IiwiYXNzaWduIiwicGFyc2UiLCJjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZSIsImNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZSIsIiRmaXJzdCIsInZhcmlhdGlvbnMiLCIkcHVzaCIsImhhc05leHQiLCJuZXh0Iiwic3RvY2siLCJjbG9zZSIsIm1rZGlyIiwid29ya2RpciIsIkRhdGUiLCJnZXRUaW1lIiwib3B0aW9ucyIsIndvd21hQXBpIiwidXJpIiwicXMiLCJ3b3dtYSIsInJlcG9zIiwiV293bWFBcGlJdGVtRmlsdGVyIiwiUGFja2V0IiwiaWNvbnYiLCJhcmNoaXZlciIsImNzdiIsIlBhc3NUaHJvdWdoIiwiVHJhbnNmb3JtIiwicHJlZml4IiwiciIsImNyZWF0ZVJlYWRTdHJlYW0iLCJvcmRlckxvYWRmaWxlIiwidyIsImNyZWF0ZVdyaXRlU3RyZWFtIiwib3JkZXJTYXZlZmlsZSIsInBpcGUiLCJkZWNvZGVTdHJlYW0iLCJlbmNvZGVTdHJlYW0iLCJjb2x1bW5zIiwidHJhbnNmb3JtIiwiY2FsbGJhY2siLCJnZXRNb2RlbENsYXNzIiwiaGVhZGVyIiwicGFja2V0IiwicGFja2V0U2l6ZSIsInJlbW92ZSIsInVwbG9hZGRpciIsImNkIiwiZmllbGRzIiwibWFwIiwiam9pbiIsIm9uUGFja2V0U3RhcnQiLCJwYWNrZXRDb3VudCIsInNsaWNlIiwiY3N2RmlsZU5hbWUiLCJhcHBlbmRGaWxlIiwiZW5jb2RlIiwib25QYWNrZXQiLCJhcmciLCJ5YXVjdCIsImltZyIsImltYWdlcyIsImltZ1NyYyIsImltZ1RndCIsImFjY2VzcyIsImNvcHlGaWxlIiwib25QYWNrZXRFbmQiLCJ6aXAiLCJ6aXBuYW1lIiwib3V0cHV0IiwiZGlyZWN0b3J5IiwiZmluYWxpemUiLCJtaW5RdWFudGl0eSIsImNvbnZlcnRJdGVtWWF1Y3QiLCJzdWJtaXQiLCJleHBvcnQiLCJDb25maWdzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiaWRHZW5lcmF0aW9uIiwic2lmdCIsIm1vYmplY3QiLCJHcm91cEJhc2UiLCJGaWx0ZXJzIiwiY29uc3RydWN0b3IiLCJmaWx0ZXJJZCIsImZpbmRPbmUiLCJnZXRQbHVnIiwidHlwZSIsIm15c3FsIiwiaW1wb3J0Iiwib25SZXN1bHQiLCJvbkVycm9yIiwidGFibGUiLCJzdHJlYW1pbmdRdWVyeSIsIkVycm9yIiwiY2FsbGJhY2tzIiwiZ2V0UHJvZmlsZSIsImZpbHRlcnMiLCJwdXNoIiwiY291bnQiLCJ1bmVzY2FwZSIsImV4YW0iLCJHcm91cHMiLCJwbGF0Zm9ybVBsdWciLCJncm91cElkIiwia2V5IiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJmb3JFYWNoIiwiaW5kZXgiLCJjYXRjaCIsIkxvZ3MiLCJteXNxbF8iLCJwcm9kdWN0Q2xhc3NJZCIsInF1ZXJ5VXBkYXRlIiwic3RvY2tfdW5saW1pdGVkIiwiY3JlYXRvcklkIiwidGFnb2ZmIiwicHJvZHVjdF9pZCIsInRhZ29uIiwiY291bnRSZXMiLCJ0YWdTZXQiLCJ0YWdzIiwic2V0IiwicHJvZHVjdElkIiwiaSIsImxlbmd0aCIsImZpbGVfbmFtZSIsInJhbmsiLCJ1cGRhdGVEYXRhIiwia2V5cyIsImsiLCJkZXNjcmlwdGlvbl9saXN0Iiwic2VhcmNoX3dvcmQiLCJmcmVlX2FyZWEiLCJjbGFzc19jYXRlZ29yeV9pZDEiLCJjbGFzc19jYXRlZ29yeV9pZDIiLCJkZWxpdmVyeV9kYXRlX2lkIiwic2FsZV9saW1pdCIsInByb2R1Y3Rfc3RvY2tfaWQiLCJEQkZpbHRlckZhY3RvcnkiLCJEQkZpbHRlciIsIk15c3FsREJGaWx0ZXIiLCJNb25nb0NsaWVudCIsInhtbDJqcyIsImluc3RhbmNlIiwiZmFjdG9yeSIsImdldFBsdWdfIiwiZ2V0Q3JlZF8iLCJnZXRQcm9maWxlXyIsInNldEltcG9ydEZ1bmN0aW9uXyIsImZuIiwiaXRlcmF0b3JzIiwiY291bnRlciIsImYiLCJsaW1pdCIsImMiLCJjbGllbnQiLCJjb25uZWN0IiwiZGF0YWJhc2UiLCJhZGRDdXJzb3JGbGFnIiwiY29tcGFjdCIsIm1heENvdW50IiwiTnVtYmVyIiwic2VhcmNoUmVzdWx0IiwiX3RleHQiLCJyZXN1bHRDb3VudCIsInN0YXJ0Q291bnQiLCJyZXN1bHRTdG9ja3MiLCJBcnJheSIsIk9iamVjdElEIiwiVGV4dFV0aWwiLCJQcm9kdWN0cyIsIml0ZW1JZCIsInByb2R1Y3RTZXQiLCJwcm9kdWN0IiwicXVhbnRpdGllcyIsInByb2R1Y3RSZWYiLCJwcmRRdWFudGl0eSIsImlkcyIsInN0b2NrQXJyYXkiLCJNYXRoIiwiZmxvb3IiLCJtaW4iLCJhcHBseSIsImZldGNoIiwiY2xhc3MxX3ZhbHVlIiwiY2xhc3MyX3ZhbHVlIiwidXBkYXRlTWFueSIsIiRlYWNoIiwiZ2V0VmFyaWF0aW9uIiwicHJvamVjdCIsImxhYmVsIiwiY3VycmVudCIsImRlbGl2ZXJ5IiwidmFsdWUiLCJjbGFzczFfbmFtZSIsImNsYXNzMl9uYW1lIiwiYXR0cnMiLCJzIiwiJHNvcnQiLCJwcm9wcyIsImF0dHIiLCJleHAiLCJSZWdFeHAiLCJtYXRjaCIsInRvSGV4U3RyaW5nIiwibW9kZWxDbGFzcyIsImNvbnZEZWxpdiIsInByb2R1Y3RUeXBlSWQiLCJkZWxpdmVyeUZlZSIsInZhcmlhdGlvbiIsInZhcmlhdGlvbkh0bWwiLCJkZXNjcmlwdGlvbkRldGFpbCIsImphbl9jb2RlIiwiZGVzY3JpcHRpb25fZGV0YWlsIiwiZGVzY3JpcHRpb24iLCJwcm9kdWN0X2NvZGUiLCJwcmljZTAxIiwicmV0YWlsX3ByaWNlIiwicHJpY2UwMiIsInNhbGVzX3ByaWNlIiwicHJvZHVjdF90eXBlX2lkIiwiZGVsaXZlcnlfZmVlIiwiZGVmIiwiaWRMZW5ndGgiLCJ0aXRsZUxlbmd0aCIsImltZ1ByZWZpeCIsImNhdGVnb3J5Iiwic3Vic3RyOCIsImpzb24yeG1sIiwiQkFTRV9VUkkiLCJyZXF1ZXN0UG9zdCIsInJlcXVlc3RYTUwiLCJtZXRob2QiLCJhcGlSZXF1ZXN0Iiwic3RvY2tVcGRhdGVJdGVtIiwidXBkYXRlU3RvY2tDcmVhdGVSZXF1ZXN0Qm9keSIsInN0b2NrVXBkYXRlSXRlbVhNTCIsInZhcjAiLCJjaG9pY2VzU3RvY2tDb3VudCIsImFwaVJlcXVlc3RCb2R5IiwibWVzc2FnZSIsImZpbGVOYW1lIiwibGluZU51bWJlciIsImNvbHVtbk51bWJlciIsInN0YWNrIiwibW9tZW50IiwicG9vbCIsImNyZWF0ZVBvb2wiLCJwcm9maWxlTXVsdGkiLCJtdWx0aXBsZVN0YXRlbWVudHMiLCJwb29sTXVsdGkiLCJmb3JtYXREYXRlIiwiZGF0ZSIsImZvcm1hdCIsInJlcGxhY2UiLCJnZXRDb24iLCJ0aGVuIiwiY29uIiwicmVsZWFzZSIsInF1ZXJ5SW5zZXJ0XyIsImluc2VydElkIiwiZGF0YVNxbCIsIk1hcCIsImVzY2FwZSIsInZhbHVlcyIsInVwZGF0ZXMiLCJxdWVyeU11bHRpIiwicG9vbFN3YXAiLCJzdGFydFRyYW5zYWN0aW9uIiwiY29tbWl0Iiwicm9sbGJhY2siLCJvbiIsInBhdXNlIiwicmVzdW1lIiwiZ2V0Q29ubmVjdGlvbiIsIml0ZXJhdG9yIiwic2V0dXBJdGVyYXRvciIsInBoYXNlSWQiLCJJdGVyYXRvciIsInJlYyIsInJlc3VsdCIsIm1ldHJpYyIsInRvdGFsIiwidGltZVN0YW1wIiwibmV3UmVjb3JkIiwic3VjY2VzcyIsImVycm9yT2N1cnJlZCIsIml0ZUVycm9yIiwicGhhRXJyb3IiLCJsYXN0RXJyb3IiLCJsb2ciLCJpc1N1Y2Nlc3MiLCJ0ZXh0IiwibGVuIiwidHJ1bmNhdGlvbiIsInVuZGVmaW5lZCIsInRleHRBcnJheSIsInNwbGl0Iiwic3RyIiwibiIsImNoYXJBdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxFQUFKO0FBQU9DLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxJQUFSLENBQWIsRUFBMkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNMLFNBQUdLLENBQUg7QUFBSzs7QUFBakIsQ0FBM0IsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUMsTUFBSjtBQUFXTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlELElBQUlFLFVBQUo7QUFBZU4sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNFLGlCQUFXRixDQUFYO0FBQWE7O0FBQXpCLENBQTNDLEVBQXNFLENBQXRFO0FBQXlFLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFDQUFSLENBQWIsRUFBNEQ7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBNUQsRUFBb0YsQ0FBcEY7QUFhaE8sSUFBSUksdUJBQXVCRixZQUEzQjtBQUVBLE1BQU1HLFFBQVEsZUFBZCxDLENBRUE7O0FBQ0FDLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCSCxLQUEzQixFQUFrQ0Qsb0JBQWxDO0FBQ0FFLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCSCxLQUEzQixFQUFrQyxDQUFDSSxHQUFELEVBQU1DLElBQU4sS0FBZTtBQUMvQztBQUVBLFFBQU1DLFNBQVNDLE9BQU9DLFNBQVAsQ0FBaUJsQixHQUFHbUIsUUFBcEIsQ0FBZjtBQUNBLFFBQU1DLFNBQVNILE9BQU9DLFNBQVAsQ0FBaUJsQixHQUFHcUIsU0FBcEIsQ0FBZjtBQUNBLFFBQU1DLFdBQVdoQixRQUFqQjs7QUFFQSxPQUFLLElBQUlpQixJQUFULElBQWlCVCxJQUFJVSxLQUFKLENBQVVELElBQTNCLEVBQWlDO0FBQy9CLFVBQU1FLE9BQU9ULE9BQU9PLEtBQUtHLElBQVosQ0FBYixDQUQrQixDQUUvQjtBQUNBOztBQUNBLFFBQUlDLFdBQVksR0FBRXJCLFFBQVMsTUFBM0IsQ0FKK0IsQ0FNL0I7O0FBQ0EsUUFBSXNCLFdBQVdkLElBQUllLElBQUosQ0FBU0MsUUFBVCxHQUFvQixHQUFwQixHQUEwQkgsUUFBekMsQ0FQK0IsQ0FTL0I7QUFFQTs7QUFDQSxRQUFJSSxNQUFNO0FBQ1JULGdCQUFVQSxRQURGO0FBRVJVLHNCQUFnQlQsS0FBS1UsSUFGYjtBQUdSQyx3QkFBa0JQO0FBSFYsS0FBVjs7QUFNQSxRQUFHO0FBQ0RQLGFBQU9RLFFBQVAsRUFBaUJILElBQWpCO0FBQ0QsS0FGRCxDQUdBLE9BQU1VLEdBQU4sRUFBVTtBQUNSSixVQUFJSyxLQUFKLEdBQVlELEdBQVo7QUFDRDs7QUFDRDNCLFlBQVE2QixNQUFSLENBQWVOLEdBQWY7QUFFQSxXQUFPUixJQUFQO0FBRUQ7O0FBQUE7QUFDRFIsT0FBS3VCLFNBQUwsQ0FBZSxHQUFmO0FBQ0F2QixPQUFLd0IsR0FBTCxDQUFTQyxLQUFLQyxTQUFMLENBQWU7QUFDdEJuQixjQUFVQSxRQURZO0FBRXRCb0IsYUFBUzVCLElBQUllLElBQUosQ0FBU0M7QUFGSSxHQUFmLENBQVQ7QUFLRCxDQTFDRCxFOzs7Ozs7Ozs7OztBQ25CQSxJQUFJYSxNQUFKO0FBQVcxQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDc0MsYUFBT3RDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJd0MsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUFsRCxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJeUMsS0FBSixFQUFVQyxZQUFWO0FBQXVCOUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlDQUFSLENBQWIsRUFBd0Q7QUFBQzJDLFFBQU16QyxDQUFOLEVBQVE7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CMEMsZUFBYTFDLENBQWIsRUFBZTtBQUFDMEMsbUJBQWExQyxDQUFiO0FBQWU7O0FBQWxELENBQXhELEVBQTRHLENBQTVHO0FBQStHLElBQUkyQyxNQUFKO0FBQVcvQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0NBQVIsQ0FBYixFQUF5RDtBQUFDNkMsU0FBTzNDLENBQVAsRUFBUztBQUFDMkMsYUFBTzNDLENBQVA7QUFBUzs7QUFBcEIsQ0FBekQsRUFBK0UsQ0FBL0U7QUFhMWMsSUFBSTRDLE1BQU0sU0FBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxVQUFkLEVBQTBCRSxNQUExQjtBQUFBLG9DQUFrQztBQUNoQyxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYixDQURnQyxDQUdoQztBQUNBOztBQUVBLFVBQUlRLFNBQVMsSUFBSUwsTUFBSixDQUFXRyxPQUFPRyxXQUFsQixDQUFiLENBTmdDLENBT2hDO0FBRUE7QUFDQTs7QUFFQSxVQUFJQyxZQUFZLGdCQUFoQjtBQUVBLFVBQUlDLFFBQVEsSUFBSVosS0FBSixDQUFVTyxPQUFPTSxHQUFQLENBQVdDLElBQXJCLENBQVo7QUFFQSxvQkFBTU4sT0FBT08sS0FBUCxDQUFhLHdCQUFiLEVBQ0osK0JBQVk7QUFDVixzQkFBTUgsTUFBTUksS0FBTixDQUFZTCxTQUFaLENBQU47QUFDRCxPQUZELENBREksQ0FBTixFQWhCZ0MsQ0FxQmhDO0FBQ0E7O0FBRUEsb0JBQU1ILE9BQU9PLEtBQVAsQ0FBYSx1QkFBYixFQUNKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUM3QkMsc0JBQW1CQyxNQUFQLDZCQUFrQjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLGdCQUFJQyxNQUFPOzs7OzswQkFLR0QsT0FBT0UsV0FBWSxNQUFLRixPQUFPRyxNQUFPLE1BQUtILE9BQU9JLEdBQUksTUFBS0osT0FBT0ssR0FBSSxNQUFLTCxPQUFPTSxVQUFXLE1BQUtOLE9BQU9PLElBQUssTUFBS1AsT0FBT1EsTUFBTyxNQUFLUixPQUFPUyxNQUFPLE1BQUtULE9BQU9VLE1BQU8sTUFBS1YsT0FBT1csTUFBTyxNQUFLWCxPQUFPWSxZQUFhLE1BQUtaLE9BQU9hLEtBQU0sTUFBS2IsT0FBT2MsS0FBTSxNQUFLZCxPQUFPZSxPQUFRLE1BQUtmLE9BQU9nQixNQUFPLE1BQUtoQixPQUFPaUIsTUFBTyxNQUFLakIsT0FBT2tCLEtBQU0sTUFBS2xCLE9BQU9tQixLQUFNLE1BQUtuQixPQUFPb0IsS0FBTSxNQUFLcEIsT0FBT3FCLEtBQU0sTUFBS3JCLE9BQU9zQixLQUFNLE1BQUt0QixPQUFPdUIsS0FBTSxNQUFLdkIsT0FBT3dCLEtBQU0sTUFBS3hCLE9BQU95QixLQUFNLE1BQUt6QixPQUFPMEIsUUFBUyxNQUFLMUIsT0FBTzJCLElBQUssTUFBSzNCLE9BQU80QixVQUFXLE1BQUs1QixPQUFPNkIsY0FBZSxNQUFLN0IsT0FBTzhCLGFBQWMsTUFBSzlCLE9BQU8rQixTQUFVLE1BQUsvQixPQUFPZ0MsU0FBVSxNQUFLaEMsT0FBT2lDLElBQUssTUFBS2pDLE9BQU9rQyxXQUFZLE1BQUtsQyxPQUFPbUMsV0FBWSxNQUFLbkMsT0FBT29DLE9BQVE7O2lCQUxsc0I7O0FBU0EsZ0JBQUk7QUFDRiw0QkFBTTVDLE1BQU02QyxXQUFOLENBQ0osY0FESSxFQUNZO0FBQ2RuQyw2QkFBYUYsT0FBT0UsV0FETjtBQUVkQyx3QkFBUUgsT0FBT0csTUFGRDtBQUdkQyxxQkFBS0osT0FBT0ksR0FIRTtBQUlkQyxxQkFBS0wsT0FBT0ssR0FKRTtBQUtkQyw0QkFBWU4sT0FBT00sVUFMTDtBQU1kQyxzQkFBTVAsT0FBT08sSUFOQztBQU9kQyx3QkFBUVIsT0FBT1EsTUFQRDtBQVFkQyx3QkFBUVQsT0FBT1MsTUFSRDtBQVNkQyx3QkFBUVYsT0FBT1UsTUFURDtBQVVkQyx3QkFBUVgsT0FBT1csTUFWRDtBQVdkQyw4QkFBY1osT0FBT1ksWUFYUDtBQVlkQyx1QkFBT2IsT0FBT2EsS0FaQTtBQWFkQyx1QkFBT2QsT0FBT2MsS0FiQTtBQWNkQyx5QkFBU2YsT0FBT2UsT0FkRjtBQWVkQyx3QkFBUWhCLE9BQU9nQixNQWZEO0FBZ0JkQyx3QkFBUWpCLE9BQU9pQixNQWhCRDtBQWlCZEMsdUJBQU9sQixPQUFPa0IsS0FqQkE7QUFrQmRDLHVCQUFPbkIsT0FBT21CLEtBbEJBO0FBbUJkQyx1QkFBT3BCLE9BQU9vQixLQW5CQTtBQW9CZEMsdUJBQU9yQixPQUFPcUIsS0FwQkE7QUFxQmRDLHVCQUFPdEIsT0FBT3NCLEtBckJBO0FBc0JkQyx1QkFBT3ZCLE9BQU91QixLQXRCQTtBQXVCZEMsdUJBQU94QixPQUFPd0IsS0F2QkE7QUF3QmRDLHVCQUFPekIsT0FBT3lCLEtBeEJBO0FBeUJkQywwQkFBVTFCLE9BQU8wQixRQXpCSDtBQTBCZEMsc0JBQU0zQixPQUFPMkIsSUExQkM7QUEyQmRDLDRCQUFZNUIsT0FBTzRCLFVBM0JMO0FBNEJkQyxnQ0FBZ0I3QixPQUFPNkIsY0E1QlQ7QUE2QmRDLCtCQUFlOUIsT0FBTzhCLGFBN0JSO0FBOEJkQywyQkFBVy9CLE9BQU8rQixTQTlCSjtBQStCZEMsMkJBQVdoQyxPQUFPZ0MsU0EvQko7QUFnQ2RDLHNCQUFNakMsT0FBT2lDLElBaENDO0FBaUNkQyw2QkFBYWxDLE9BQU9rQyxXQWpDTjtBQWtDZEMsNkJBQWFuQyxPQUFPbUMsV0FsQ047QUFtQ2RDLHlCQUFTcEMsT0FBT29DO0FBbkNGLGVBRFosQ0FBTjtBQXVDRCxhQXhDRCxDQXdDRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFoRTJCLENBa0U1Qjs7O0FBQ0EsZ0JBQUk7QUFDRiw0QkFBTTlDLE1BQU02QyxXQUFOLENBQ0osc0JBREksRUFDb0I7QUFDdEJHLHFDQUFxQixJQURDO0FBRXRCdEMsNkJBQWFGLE9BQU9FLFdBRkU7QUFHdEJJLDRCQUFZTixPQUFPTSxVQUhHO0FBSXRCQyxzQkFBTVAsT0FBT08sSUFKUztBQUt0QkMsd0JBQVFSLE9BQU9RLE1BTE87QUFNdEJDLHdCQUFRVCxPQUFPUyxNQU5PO0FBT3RCQyx3QkFBUVYsT0FBT1UsTUFQTztBQVF0QkMsd0JBQVFYLE9BQU9XLE1BUk87QUFTdEJDLDhCQUFjWixPQUFPWSxZQVRDO0FBVXRCQyx1QkFBT2IsT0FBT2EsS0FWUTtBQVd0QkMsdUJBQU9kLE9BQU9jLEtBWFE7QUFZdEJDLHlCQUFTZixPQUFPZSxPQVpNO0FBYXRCQyx3QkFBUWhCLE9BQU9nQixNQWJPO0FBY3RCQyx3QkFBUWpCLE9BQU9pQixNQWRPO0FBZXRCRSx1QkFBT25CLE9BQU9tQixLQWZRO0FBZ0J0QkMsdUJBQU9wQixPQUFPb0IsS0FoQlE7QUFpQnRCQyx1QkFBT3JCLE9BQU9xQixLQWpCUTtBQWtCdEJDLHVCQUFPdEIsT0FBT3NCLEtBbEJRO0FBbUJ0QkMsdUJBQU92QixPQUFPdUIsS0FuQlE7QUFvQnRCQyx1QkFBT3hCLE9BQU93QixLQXBCUTtBQXFCdEJVLDZCQUFhbEMsT0FBT2tDLFdBckJFO0FBc0J0QkMsNkJBQWFuQyxPQUFPbUMsV0F0QkU7QUF1QnRCQyx5QkFBU3BDLE9BQU9vQztBQXZCTSxlQURwQixDQUFOO0FBMkJELGFBNUJELENBNEJFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWpHMkIsQ0FtRzVCOzs7QUFDQSxnQkFBSTtBQUNGLDRCQUFNOUMsTUFBTTZDLFdBQU4sQ0FDSix1QkFESSxFQUNxQjtBQUN2Qkksb0JBQUksSUFEbUI7QUFFdkJ2Qyw2QkFBYUYsT0FBT0UsV0FGRztBQUd2QndDLDhCQUFjMUMsT0FBTzBDLFlBSEU7QUFJdkJSLDZCQUFhbEMsT0FBT2tDLFdBSkc7QUFLdkJDLDZCQUFhbkMsT0FBT21DLFdBTEc7QUFNdkJDLHlCQUFTcEMsT0FBT29DO0FBTk8sZUFEckIsQ0FBTjtBQVVELGFBWEQsQ0FXRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFqSDJCLENBbUg1Qjs7O0FBRUEsZ0JBQUlLLFdBQVdoRSxPQUFPaUUsV0FBUCxDQUFtQixDQUFuQixFQUFzQkMsUUFBdEIsQ0FBK0IsUUFBL0IsRUFBeUNDLFNBQXpDLENBQW1ELENBQW5ELEVBQXNELEVBQXRELENBQWY7QUFFQSxnQkFBSUMsYUFBYyxHQUFFL0MsT0FBT1EsTUFBTyxJQUFHUixPQUFPUyxNQUFPLG1CQUFrQlQsT0FBT0UsV0FBWSxFQUF4RjtBQUVBLGdCQUFJOEMsZ0JBQWdCaEQsT0FBT2lELEtBQVAsR0FBZSxHQUFuQzs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJcEQsb0JBQVlMLE1BQU02QyxXQUFOLENBQ2QsWUFEYyxFQUNBO0FBQ1phLDJCQUFXLElBREM7QUFFWkMsMkJBQVdSLFFBRkM7QUFHWlMsNkJBQWEsQ0FIRDtBQUdJO0FBQ2hCQyw2QkFBYU4sVUFKRDtBQUtaTywrQkFBZSxDQUxIO0FBTVpDLGlDQUFpQixDQU5MO0FBT1pDLGdDQUFnQixDQVBKO0FBUVpDLGdDQUFnQlQsYUFSSjtBQVNaVSwrQkFBZSxJQVRIO0FBVVpDLDZCQUFhLENBVkQ7QUFXWkMsK0JBQWUsQ0FYSDtBQVlaQyxvQ0FBb0IsSUFaUjtBQWFaM0QsNkJBQWFGLE9BQU9FLFdBYlI7QUFjWjRELHFDQUFxQixxQkFkVDtBQWVaQyxtQ0FBbUIscUJBZlA7QUFnQlozQix5QkFBUztBQWhCRyxlQURBLEVBa0JYO0FBQ0RGLDZCQUFhLE9BRFo7QUFFREMsNkJBQWE7QUFGWixlQWxCVyxDQUFaLENBQUo7QUF1QkQsYUF4QkQsQ0F3QkUsT0FBT0csQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0F0Slc7QUFEaUIsU0FBZixFQXlKVEEsQ0FBUCw2QkFBYTtBQUNYbEQsaUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxTQUZELENBekpnQixDQUFaLENBQUo7QUE4SkEsZUFBT3pDLEdBQVA7QUFDRCxPQWhLRCxDQURJLENBQU47QUFtS0EsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBNUxEO0FBQUEsR0FGYTs7QUFnTVAsdUJBQU4sQ0FBNkJDLE9BQTdCO0FBQUEsb0NBQXNDO0FBQ3BDLFVBQUlDLEtBQUssSUFBSXRGLEtBQUosQ0FBVXFGLE9BQVYsQ0FBVDtBQUNBLFVBQUlwRSxvQkFBWXFFLEdBQUd0RSxLQUFILENBQVMsZ0JBQVQsQ0FBWixDQUFKO0FBQ0EsYUFBT0MsR0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFoTWEsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBLElBQUlzRSxlQUFKO0FBQW9CbEksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ2dJLGtCQUFnQjlILENBQWhCLEVBQWtCO0FBQUM4SCxzQkFBZ0I5SCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBakQsRUFBeUYsQ0FBekY7QUFBNEYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUczSCxJQUFJNEMsTUFBTSxrQkFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXVCbUYsSUFBdkIsRUFBNkJ4RSxRQUFRLEVBQXJDLEVBQXlDeUUsYUFBYSxFQUF0RDtBQUFBLG9DQUEwRDtBQUN4RCxVQUFJQyxxQkFBYUgsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEJBLEtBQUtJLFVBQS9CLENBQWIsQ0FBSjtBQUNBLFVBQUkzRSxvQkFBWXlFLEtBQUtHLElBQUwsQ0FBVTdFLEtBQVYsRUFBaUI7QUFBQ3lFLG9CQUFZQTtBQUFiLE9BQWpCLEVBQTJDSyxPQUEzQyxFQUFaLENBQUo7QUFDQSxhQUFPN0UsR0FBUDtBQUNELEtBSkQ7QUFBQSxHQUZhOztBQVFiLEdBQVEsR0FBRVosR0FBSSxZQUFkLEVBQTRCbUYsSUFBNUIsRUFBa0N4RSxRQUFRLEVBQTFDO0FBQUEsb0NBQThDO0FBQzVDLFVBQUkwRSxxQkFBYUgsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEJBLEtBQUtJLFVBQS9CLENBQWIsQ0FBSjtBQUNBLFVBQUkzRSxvQkFBWXlFLEtBQUtLLFNBQUwsQ0FBZS9FLEtBQWYsRUFBc0I4RSxPQUF0QixFQUFaLENBQUo7QUFDQSxhQUFPN0UsR0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFSYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSStFLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBcEQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUdwSCxJQUFJNEMsTUFBTSxhQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7Ozs7O0FBS0EsR0FBUSxHQUFFRCxHQUFJLFdBQWQsRUFBMkJtRixJQUEzQixFQUFpQzlHLFFBQWpDLEVBQTJDdUgsS0FBM0MsRUFBa0RDLFNBQVMsSUFBM0QsRUFBaUVDLFNBQVMsSUFBMUU7QUFBQSxvQ0FBZ0Y7QUFDOUUsVUFBSUMsVUFBVSxJQUFJSixjQUFKLEVBQWQ7QUFDQSxvQkFBTUksUUFBUUMsSUFBUixDQUFhYixJQUFiLENBQU47QUFDQSxVQUFJYyx5QkFBaUJGLFFBQVFHLFFBQVIsQ0FBaUI3SCxRQUFqQixFQUEyQnVILEtBQTNCLEVBQWtDQyxNQUFsQyxFQUEwQ0MsTUFBMUMsQ0FBakIsQ0FBSjtBQUNBLGFBQU9HLFFBQVA7QUFDRCxLQUxEO0FBQUEsR0FQYTs7QUFjYjs7O0FBR0EsR0FBUSxHQUFFakcsR0FBSSxhQUFkLEVBQTZCbUYsSUFBN0IsRUFBbUNTLEtBQW5DLEVBQTBDQyxTQUFTLElBQW5ELEVBQXlEQyxTQUFTLElBQWxFO0FBQUEsb0NBQXdFO0FBQ3RFLFVBQUlDLFVBQVUsSUFBSUosY0FBSixFQUFkO0FBQ0Esb0JBQU1JLFFBQVFDLElBQVIsQ0FBYWIsSUFBYixDQUFOO0FBQ0Esb0JBQU1ZLFFBQVFJLFVBQVIsQ0FBbUJQLEtBQW5CLEVBQTBCQyxNQUExQixFQUFrQ0MsTUFBbEMsQ0FBTjtBQUNELEtBSkQ7QUFBQTs7QUFqQmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBLElBQUlsRyxNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJaUosUUFBSjtBQUFhckosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ21KLFdBQVNqSixDQUFULEVBQVc7QUFBQ2lKLGVBQVNqSixDQUFUO0FBQVc7O0FBQXhCLENBQXBELEVBQThFLENBQTlFO0FBQWlGLElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQTlDLEVBQW9FLENBQXBFO0FBQXVFLElBQUl1SSxjQUFKO0FBQW1CM0ksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1SSxxQkFBZXZJLENBQWY7QUFBaUI7O0FBQTdCLENBQWpELEVBQWdGLENBQWhGO0FBQW1GLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFZamUsSUFBSTRDLE1BQU0sTUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksY0FBZCxFQUE4QkUsTUFBOUI7QUFBQSxvQ0FBc0M7QUFDcEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLFVBQUlRLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBYjtBQUNBLFVBQUl1QixpQkFBaUIsSUFBSVosY0FBSixFQUFyQjtBQUNBLG9CQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU47QUFFQSxVQUFJRSxXQUFXLElBQUk3RyxLQUFKLENBQVVPLE9BQU91RyxPQUFqQixDQUFmO0FBQ0EsVUFBSUMsTUFBTSxJQUFJTCxRQUFKLENBQWFHLFFBQWIsQ0FBVjtBQUVBLG9CQUFNckcsT0FBT08sS0FBUCxDQUNKLE9BREksRUFFSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFFN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlDLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF3QkgsS0FBS0ksR0FBN0IsQ0FBakIsQ0FBSjtBQUNBLDBCQUFNTCxJQUFJTSxXQUFKLENBQWdCTCxLQUFLTSxJQUFMLENBQVVDLFdBQVYsQ0FBc0JDLGdCQUF0QyxFQUF3RE4sUUFBeEQsQ0FBTjtBQUNELFdBSFM7QUFGbUIsU0FBZixDQUFaLENBQUo7QUFPQSxlQUFPakcsR0FBUDtBQUNELE9BVEQsQ0FGSSxDQUFOO0FBYUEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBekJEO0FBQUEsR0FMYTs7QUFnQ2I7QUFDQTtBQUVBLEdBQVEsR0FBRS9FLEdBQUksWUFBZCxFQUE0QkUsTUFBNUI7QUFBQSxvQ0FBb0M7QUFDbEMsVUFBSUUsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBQ0EsVUFBSXdCLFdBQVcsSUFBSTdHLEtBQUosQ0FBVU8sT0FBT3VHLE9BQWpCLENBQWY7QUFDQSxVQUFJQyxNQUFNLElBQUlMLFFBQUosQ0FBYUcsUUFBYixDQUFWO0FBRUEsVUFBSUQsaUJBQWlCLElBQUlaLGNBQUosRUFBckI7QUFDQSxvQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOLEVBTmtDLENBUWxDOztBQUNBLFVBQUluRyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osZUFESSxFQUVKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUM3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSVEsTUFBTVIsUUFBUXJCLFVBQWxCOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUk4Qix5QkFBaUJkLGVBQWVlLGdCQUFmLENBQWdDcEgsT0FBT3FILFVBQXZDLEVBQW1EWixJQUFuRCxDQUFqQixDQUFKO0FBRUEsa0JBQUlhLDBCQUFrQmQsSUFBSWUsYUFBSixDQUFrQkosUUFBbEIsQ0FBbEIsQ0FBSixDQUhFLENBS0Y7O0FBQ0EsNEJBQU1ELElBQUlNLE1BQUosQ0FBVztBQUNmWCxxQkFBS0osS0FBS0k7QUFESyxlQUFYLEVBRUg7QUFDRFksc0JBQU07QUFDSixzQ0FBb0JILFVBQVU1RztBQUQxQjtBQURMLGVBRkcsQ0FBTjtBQVFBVCxxQkFBT3lILFFBQVA7QUFDRCxhQWZELENBZUUsT0FBT3ZFLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBckJTO0FBRG1CLFNBQWYsRUF3QlRBLENBQVAsNkJBQWE7QUFDWCxnQkFBTUEsQ0FBTjtBQUNELFNBRkQsQ0F4QmdCLENBQVosQ0FBSjtBQTRCQSxlQUFPekMsR0FBUDtBQUNELE9BOUJELENBRkksQ0FBTjtBQWtDQSxvQkFBTVQsT0FBT08sS0FBUCxDQUNKLGdCQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJUSxNQUFNUixRQUFRckIsVUFBbEI7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSThCLHlCQUFpQmQsZUFBZWUsZ0JBQWYsQ0FBZ0NwSCxPQUFPcUgsVUFBdkMsRUFBbURaLElBQW5ELENBQWpCLENBQUo7QUFFQSw0QkFBTUQsSUFBSW1CLGtCQUFKLENBQXVCUixRQUF2QixDQUFOO0FBQ0EsNEJBQU1YLElBQUlvQixhQUFKLENBQWtCVCxRQUFsQixDQUFOO0FBQ0EsNEJBQU1YLElBQUlxQixnQkFBSixDQUFxQlYsUUFBckIsQ0FBTjtBQUVBLGtCQUFJUix5QkFBaUJOLGVBQWVPLFFBQWYsQ0FBd0JILEtBQUtJLEdBQTdCLENBQWpCLENBQUo7QUFDQSw0QkFBTUwsSUFBSU0sV0FBSixDQUFnQkwsS0FBS00sSUFBTCxDQUFVQyxXQUFWLENBQXNCQyxnQkFBdEMsRUFBd0ROLFFBQXhELENBQU47QUFFQTFHLHFCQUFPeUgsUUFBUDtBQUNELGFBWEQsQ0FXRSxPQUFPdkUsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0FqQlM7QUFEbUIsU0FBZixFQW9CVEEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQXBCZ0IsQ0FBWixDQUFKO0FBd0JBLGVBQU96QyxHQUFQO0FBQ0QsT0ExQkQsQ0FGSSxDQUFOO0FBOEJBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTVFRDtBQUFBOztBQW5DYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZEEsSUFBSW5GLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWdKLGFBQUo7QUFBa0JwSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDa0osZ0JBQWNoSixDQUFkLEVBQWdCO0FBQUNnSixvQkFBY2hKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQTlDLEVBQW9FLENBQXBFO0FBQXVFLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFPN1IsSUFBSTRDLE1BQU0sTUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksT0FBZCxFQUF1QkUsTUFBdkI7QUFBQSxvQ0FBK0I7QUFDN0I7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLFVBQUlRLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBYjtBQUVBLFlBQU1nRCx5QkFBaUI1SCxPQUFPUyxPQUFQLENBQWUsRUFBZixFQUEwQndDLENBQVAsNkJBQWE7QUFDckQsY0FBTUEsQ0FBTjtBQUNELE9BRnlDLENBQW5CLENBQWpCLENBQU47QUFHQSxvQkFBTWxELE9BQU9PLEtBQVAsQ0FDSixVQURJLEVBRUosK0JBQVk7QUFDVixlQUFPc0gsUUFBUDtBQUNELE9BRkQsQ0FGSSxDQUFOO0FBTUEsYUFBTzdILE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQWhCRDtBQUFBOztBQUxhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNUQSxJQUFJbkYsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVJLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJNkssT0FBSjtBQUFZakwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZLLGNBQVE3SyxDQUFSO0FBQVU7O0FBQXRCLENBQWpDLEVBQXlELENBQXpEO0FBQTRELElBQUk4SyxPQUFKO0FBQVlsTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUJBQVIsQ0FBYixFQUF3QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzhLLGNBQVE5SyxDQUFSO0FBQVU7O0FBQXRCLENBQXhDLEVBQWdFLENBQWhFO0FBQW1FLElBQUkrSyxRQUFKO0FBQWFuTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQytLLGVBQVMvSyxDQUFUO0FBQVc7O0FBQXZCLENBQXBELEVBQTZFLENBQTdFO0FBQWdGLElBQUlnTCxTQUFKO0FBQWNwTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2dMLGdCQUFVaEwsQ0FBVjtBQUFZOztBQUF4QixDQUE5QyxFQUF3RSxDQUF4RTtBQWFubkIsTUFBTTRDLE1BQU0sT0FBWjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksa0JBQWQsRUFBa0NFLE1BQWxDO0FBQUEsb0NBQTBDO0FBQ3hDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLDBCQURJLEVBRUosK0JBQVk7QUFDVjtBQUNBO0FBQ0EsY0FBTTZGLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTixFQUpVLENBTVY7QUFDQTs7QUFDQSxZQUFJK0Isb0JBQVk5QixlQUFlK0IsS0FBZixDQUFxQjVDLFNBQXJCLENBQ2QsQ0FDRTtBQUNFNkMsa0JBQVE7QUFDTkMsa0JBQU0sQ0FDSjtBQUNFLHFDQUF1QjtBQUFFQyx5QkFBUztBQUFYO0FBRHpCLGFBREk7QUFEQTtBQURWLFNBREYsRUF3QkU7QUFDRTtBQUNBQyxrQkFBUTtBQUNOM0IsaUJBQUs7QUFEQztBQUZWLFNBeEJGLEVBOEJFO0FBQ0U0QixvQkFBVTtBQUNSNUIsaUJBQUssQ0FERztBQUVSNkIsc0JBQVU7QUFGRjtBQURaLFNBOUJGLENBRGMsQ0FBWixDQUFKLENBUlUsQ0FnRFY7O0FBQ0EsWUFBSWxDLE1BQU0sSUFBSXlCLFFBQUosQ0FBYWpJLE9BQU8ySSxZQUFwQixFQUFrQzNJLE9BQU80SSxNQUF6QyxDQUFWO0FBQ0Esc0JBQU0zSSxPQUFPNEksZUFBUCxDQUNKVixHQURJLEVBRUUxQixJQUFOLDZCQUFjO0FBQ1pBLGVBQUtxQyxVQUFMLEdBQWtCLENBQWxCO0FBQ0FyQyxlQUFLc0MsYUFBTCxHQUFxQixNQUFyQjs7QUFDQSxjQUFJO0FBQ0YsZ0JBQUlySSxvQkFBWThGLElBQUl3QyxVQUFKLENBQWV2QyxJQUFmLENBQVosQ0FBSjtBQUNBLG1CQUFPO0FBQUN3QywyQkFBYXhDLElBQWQ7QUFBb0J5Qyx3QkFBVXhJO0FBQTlCLGFBQVA7QUFDRCxXQUhELENBR0UsT0FBT3lDLENBQVAsRUFBVTtBQUNWLGtCQUFNZ0csT0FBT0MsTUFBUCxDQUFjO0FBQUNILDJCQUFheEM7QUFBZCxhQUFkLEVBQW1DeUIsVUFBVW1CLEtBQVYsQ0FBZ0JsRyxDQUFoQixDQUFuQyxDQUFOO0FBQ0Q7QUFDRixTQVRELENBRkksQ0FBTjtBQWFELE9BL0RELENBRkksQ0FBTjtBQW9FQSxhQUFPbEQsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBekVEO0FBQUEsR0FMYTs7QUFnRmI7QUFDQTtBQUVBLEdBQVEsR0FBRS9FLEdBQUksY0FBZCxFQUE4QkUsTUFBOUI7QUFBQSxvQ0FBc0M7QUFDcEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osYUFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUNBLGNBQU02RixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU47QUFFQSxZQUFJK0Isb0JBQVk5QixlQUFlK0IsS0FBZixDQUFxQjVDLFNBQXJCLENBQ2QsQ0FDRTtBQUNFNkMsa0JBQVE7QUFDTkMsa0JBQU0sQ0FDSjtBQUNFLHFDQUF1QjtBQUFFQyx5QkFBUztBQUFYLGVBRHpCLENBR0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFoQkUsYUFESTtBQURBO0FBRFYsU0FERixFQXdCRTtBQUNFO0FBQ0FDLGtCQUFRO0FBQ04zQixpQkFBSztBQUNINkIsd0JBQVUsc0JBRFA7QUFFSFksMENBQTRCLHlCQUZ6QjtBQUdIQyx3Q0FBMEI7QUFIdkIsYUFEQztBQU1OOUMsa0JBQU07QUFDSitDLHNCQUFRO0FBREo7QUFOQTtBQUZWLFNBeEJGLEVBcUNFO0FBQ0U7QUFDQWhCLGtCQUFRO0FBQ04zQixpQkFBSyxlQURDO0FBRU40Qyx3QkFBWTtBQUNWQyxxQkFBTztBQUNMN0MscUJBQUssT0FEQTtBQUVMeUMsNENBQTRCLGlDQUZ2QjtBQUdMQywwQ0FBMEI7QUFIckI7QUFERztBQUZOO0FBRlYsU0FyQ0YsRUFrREU7QUFDRWQsb0JBQVU7QUFDUjVCLGlCQUFLLENBREc7QUFFUjZCLHNCQUFVLE1BRkY7QUFHUmUsd0JBQVk7QUFISjtBQURaLFNBbERGLENBRGMsQ0FBWixDQUFKLENBTlUsQ0FtRVY7QUFDQTtBQUVBOztBQUNBLDZCQUFhdEIsSUFBSXdCLE9BQUosRUFBYixHQUE0QjtBQUMxQixjQUFJbEQscUJBQWEwQixJQUFJeUIsSUFBSixFQUFiLENBQUosQ0FEMEIsQ0FHMUI7O0FBQ0EsZUFBSyxJQUFJekcsQ0FBVCxJQUFjc0QsS0FBS2dELFVBQW5CLEVBQStCO0FBQzdCdEcsY0FBRTBHLEtBQUYsaUJBQWdCeEQsZUFBZU8sUUFBZixDQUF3QnpELEVBQUUwRCxHQUExQixDQUFoQjtBQUNBLG1CQUFPMUQsRUFBRTBELEdBQVQ7QUFDRCxXQVB5QixDQVMxQjtBQUNBOzs7QUFDQSxjQUFJTCxNQUFNLElBQUl5QixRQUFKLENBQWFqSSxPQUFPMkksWUFBcEIsRUFBa0MzSSxPQUFPNEksTUFBekMsQ0FBVjs7QUFDQSxjQUFJO0FBQ0YsZ0JBQUlsSSxvQkFBWThGLElBQUlNLFdBQUosQ0FBZ0IsQ0FBQ0wsSUFBRCxDQUFoQixDQUFaLENBQUo7QUFDQXhHLG1CQUFPeUgsUUFBUCxDQUFnQmhILEdBQWhCO0FBQ0QsV0FIRCxDQUdFLE9BQU95QyxDQUFQLEVBQVU7QUFDVmxELG1CQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRjs7QUFDRGdGLFlBQUkyQixLQUFKO0FBQ0QsT0EzRkQsQ0FGSSxDQUFOO0FBK0ZBLGFBQU83SixPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0FwR0Q7QUFBQSxHQW5GYTs7QUF5TGI7QUFDQTtBQUVBLEdBQVEsR0FBRS9FLEdBQUksYUFBZCxFQUE2QkUsTUFBN0I7QUFBQSxvQ0FBcUM7QUFDbkM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osZUFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUVBLGNBQU1OLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBZjtBQUNBLGNBQU11QixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOVSxDQVFWOztBQUNBLFlBQUk7QUFDRix3QkFBTTJCLFFBQVFnQyxLQUFSLENBQWMvSixPQUFPZ0ssT0FBckIsQ0FBTjtBQUNELFNBRkQsQ0FFRSxPQUFPN0csQ0FBUCxFQUFVLENBQUUsQ0FYSixDQWFWOzs7QUFDQSxjQUFNNkcsVUFBVyxHQUFFaEssT0FBT2dLLE9BQVEsVUFBVSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUF1QixFQUFsRSxDQWRVLENBZVY7O0FBQ0EsWUFBSTtBQUNGLHdCQUFNbkMsUUFBUWdDLEtBQVIsQ0FBY0MsT0FBZCxDQUFOO0FBQ0QsU0FGRCxDQUVFLE9BQU83RyxDQUFQLEVBQVUsQ0FBRSxDQWxCSixDQW9CVjtBQUNBOzs7QUFFQSxZQUFJekMsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSXlELFVBQVU5SyxLQUFLZ0ssS0FBTCxDQUFXaEssS0FBS0MsU0FBTCxDQUFlVSxPQUFPb0ssUUFBdEIsQ0FBWCxDQUFkO0FBQ0FELG9CQUFRRSxHQUFSLEdBQWUsR0FBRUYsUUFBUUUsR0FBSSxpQkFBN0I7QUFDQUYsb0JBQVFHLEVBQVIsQ0FBVzVCLFFBQVgsR0FBc0JqQyxLQUFLTSxJQUFMLENBQVV3RCxLQUFWLENBQWdCN0IsUUFBdEM7QUFFQSxnQkFBSThCLHNCQUFjeEMsUUFBUW1DLE9BQVIsQ0FBZCxDQUFKO0FBQ0EsZ0JBQUkzTCxXQUFZLEdBQUV3TCxPQUFRLElBQUd2RCxLQUFLZixLQUFNLE1BQXhDO0FBRUEsMEJBQU1xQyxRQUFRN0osU0FBUixDQUFrQk0sUUFBbEIsRUFBNEJnTSxLQUE1QixDQUFOO0FBQ0QsV0FUUztBQUZtQixTQUFmLENBQVosQ0FBSjtBQWFBLGVBQU85SixHQUFQO0FBQ0QsT0FyQ0QsQ0FGSSxDQUFOO0FBeUNBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTlDRDtBQUFBOztBQTVMYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSW5GLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSXVOLGtCQUFKO0FBQXVCM04sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ3lOLHFCQUFtQnZOLENBQW5CLEVBQXFCO0FBQUN1Tix5QkFBbUJ2TixDQUFuQjtBQUFxQjs7QUFBNUMsQ0FBcEQsRUFBa0csQ0FBbEc7QUFBcUcsSUFBSXVJLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQVFqVSxNQUFNNEMsTUFBTSxVQUFaO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxVQUFkLEVBQTBCRSxNQUExQjtBQUFBLG9DQUFrQztBQUNoQztBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSixlQURJLEVBRUosK0JBQVk7QUFDVjtBQUNBO0FBRUEsY0FBTU4sU0FBUyxJQUFJdUssa0JBQUosQ0FBdUJ6SyxPQUFPb0ssUUFBOUIsRUFBd0NwSyxPQUFPOEUsT0FBL0MsQ0FBZjtBQUNBLGNBQU11QixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOVSxDQVFWO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFDQTs7QUFFQSxZQUFJMUYsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQ3pHLG1CQUFPeUgsUUFBUCxDQUFnQmpCLElBQWhCO0FBQ0QsV0FGUztBQUZtQixTQUFmLENBQVosQ0FBSjtBQU1BLGVBQU8vRixHQUFQO0FBQ0QsT0E5QkQsQ0FGSSxDQUFOO0FBa0NBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQXZDRDtBQUFBOztBQUxhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNWQSxJQUFJbkYsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVJLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJd04sTUFBSjtBQUFXNU4sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3TixhQUFPeE4sQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJNkssT0FBSjtBQUFZakwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZLLGNBQVE3SyxDQUFSO0FBQVU7O0FBQXRCLENBQWpDLEVBQXlELENBQXpEO0FBQTRELElBQUl5TixLQUFKO0FBQVU3TixPQUFPQyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiLEVBQW1DO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDeU4sWUFBTXpOLENBQU47QUFBUTs7QUFBcEIsQ0FBbkMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSTBOLFFBQUo7QUFBYTlOLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMwTixlQUFTMU4sQ0FBVDtBQUFXOztBQUF2QixDQUFqQyxFQUEwRCxDQUExRDtBQUE2RCxJQUFJMk4sR0FBSjtBQUFRL04sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLEtBQVIsQ0FBYixFQUE0QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzJOLFVBQUkzTixDQUFKO0FBQU07O0FBQWxCLENBQTVCLEVBQWdELENBQWhEO0FBQW1ELElBQUk0TixXQUFKLEVBQWdCQyxTQUFoQjtBQUEwQmpPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQzhOLGNBQVk1TixDQUFaLEVBQWM7QUFBQzROLGtCQUFZNU4sQ0FBWjtBQUFjLEdBQTlCOztBQUErQjZOLFlBQVU3TixDQUFWLEVBQVk7QUFBQzZOLGdCQUFVN04sQ0FBVjtBQUFZOztBQUF4RCxDQUEvQixFQUF5RixDQUF6RjtBQWVsdkIsTUFBTThOLFNBQVMsUUFBZjtBQUNBLE1BQU1sTCxNQUFNLE9BQVo7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLFFBQWQsRUFBd0JFLE1BQXhCO0FBQUEsb0NBQWdDO0FBQzlCO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLFFBREksRUFFSiwrQkFBWTtBQUNWLGNBQU02RixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU47QUFDQSxjQUFNNEQsVUFBVyxHQUFFaEssT0FBT2dLLE9BQVEsUUFBbEM7QUFDQSxjQUFNaUIsSUFBSWxELFFBQVFtRCxnQkFBUixDQUEwQixHQUFFbEIsT0FBUSxJQUFHaEssT0FBT21MLGFBQWMsRUFBNUQsQ0FBVjtBQUNBLGNBQU1DLElBQUlyRCxRQUFRc0QsaUJBQVIsQ0FBMkIsR0FBRXJCLE9BQVEsSUFBR2hLLE9BQU9zTCxhQUFjLEVBQTdELENBQVY7QUFDQUwsVUFBRU0sSUFBRixDQUFPWixNQUFNYSxZQUFOLENBQW1CLE1BQW5CLENBQVAsRUFDR0QsSUFESCxDQUNRWixNQUFNYyxZQUFOLENBQW1CLE9BQW5CLENBRFIsRUFFR0YsSUFGSCxDQUVRVixJQUFJeEIsS0FBSixDQUFVO0FBQUNxQyxtQkFBUztBQUFWLFNBQVYsQ0FGUixFQUdHSCxJQUhILENBR1FWLElBQUljLFNBQUosQ0FDSixDQUFPOUssTUFBUCxFQUFlK0ssUUFBZiw4QkFBNEI7QUFDMUIsY0FBSTVNLE1BQU0sSUFBVixDQUQwQixDQUUxQjs7QUFDQSxjQUFJO0FBQ0Y2QixtQkFBTyxNQUFQLGtCQUF1QndGLGVBQWV3RixhQUFmLENBQTZCaEwsT0FBTyxNQUFQLENBQTdCLENBQXZCO0FBQ0QsV0FGRCxDQUVFLE9BQU9zQyxDQUFQLEVBQVU7QUFDVm5FLGtCQUFNbUUsQ0FBTjtBQUNEOztBQUNEeUksbUJBQVM1TSxHQUFULEVBQWM2QixNQUFkO0FBQ0QsU0FURCxDQURJLENBSFIsRUFlRzBLLElBZkgsQ0FlUVYsSUFBSXZMLFNBQUosQ0FBYztBQUFDd00sa0JBQVE7QUFBVCxTQUFkLENBZlIsRUFnQkdQLElBaEJILENBZ0JRWixNQUFNYSxZQUFOLENBQW1CLE9BQW5CLENBaEJSLEVBaUJHRCxJQWpCSCxDQWlCUVosTUFBTWMsWUFBTixDQUFtQixNQUFuQixDQWpCUixFQWtCR0YsSUFsQkgsQ0FrQlFILENBbEJSO0FBbUJELE9BekJELENBRkksQ0FBTjtBQTZCRCxLQWpDRDtBQUFBLEdBTGE7O0FBd0NiO0FBQ0E7QUFFQSxHQUFRLEdBQUV0TCxHQUFJLFVBQWQsRUFBMEJFLE1BQTFCO0FBQUEsb0NBQWtDO0FBQ2hDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLFFBREksRUFFSiwrQkFBWTtBQUNWO0FBQ0E7QUFFQSxjQUFNTixTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWY7QUFDQSxjQUFNdUIsaUJBQWlCLElBQUlaLGNBQUosRUFBdkI7QUFDQSxzQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOLEVBTlUsQ0FRVjs7QUFDQSxjQUFNMkYsU0FBUyxJQUFJckIsTUFBSixDQUFXMUssT0FBT2dNLFVBQWxCLENBQWYsQ0FUVSxDQVdWOztBQUNBLFlBQUk7QUFDRix3QkFBTWpFLFFBQVFnQyxLQUFSLENBQWMvSixPQUFPZ0ssT0FBckIsQ0FBTjtBQUNELFNBRkQsQ0FFRSxPQUFPN0csQ0FBUCxFQUFVLENBQUUsQ0FkSixDQWdCVjs7O0FBQ0EsY0FBTTZHLFVBQVcsR0FBRWhLLE9BQU9nSyxPQUFRLE9BQWxDO0FBQ0Esc0JBQU1qQyxRQUFRa0UsTUFBUixDQUFlakMsT0FBZixDQUFOO0FBQ0Esc0JBQU1qQyxRQUFRZ0MsS0FBUixDQUFjQyxPQUFkLENBQU4sRUFuQlUsQ0FxQlY7O0FBQ0EsY0FBTWtDLFlBQWEsR0FBRWxNLE9BQU9nSyxPQUFRLFNBQXBDO0FBQ0Esc0JBQU1qQyxRQUFRa0UsTUFBUixDQUFlQyxTQUFmLENBQU47QUFDQSxzQkFBTW5FLFFBQVFnQyxLQUFSLENBQWNtQyxTQUFkLENBQU47QUFFQSxZQUFJQyxLQUFLLElBQVQsQ0ExQlUsQ0EwQkk7O0FBQ2QsWUFBSTNOLFdBQVcsSUFBZixDQTNCVSxDQTJCVTs7QUFDcEIsWUFBSU0sT0FBTyxJQUFYLENBNUJVLENBNEJNO0FBRWhCOztBQUNBLFlBQUlzTixTQUFTLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsTUFBakIsRUFBeUIsSUFBekIsRUFBK0IsZ0JBQS9CLEVBQWlELE1BQWpELEVBQXlELE1BQXpELEVBQWlFLE9BQWpFLEVBQTBFLElBQTFFLEVBQWdGLFFBQWhGLEVBQTBGLElBQTFGLEVBQWdHLE1BQWhHLEVBQXdHLFlBQXhHLEVBQXNILFlBQXRILEVBQW9JLE1BQXBJLEVBQTRJLFdBQTVJLEVBQXlKLFlBQXpKLEVBQXVLLE9BQXZLLEVBQWdMLFNBQWhMLEVBQTJMLE9BQTNMLEVBQW9NLFNBQXBNLEVBQStNLEtBQS9NLEVBQXNOLFNBQXROLEVBQWlPLEtBQWpPLEVBQXdPLFNBQXhPLEVBQW1QLEtBQW5QLEVBQTBQLFNBQTFQLEVBQXFRLEtBQXJRLEVBQTRRLFNBQTVRLEVBQXVSLEtBQXZSLEVBQThSLFNBQTlSLEVBQXlTLEtBQXpTLEVBQWdULFNBQWhULEVBQTJULEtBQTNULEVBQWtVLFNBQWxVLEVBQTZVLEtBQTdVLEVBQW9WLFNBQXBWLEVBQStWLEtBQS9WLEVBQXNXLFNBQXRXLEVBQWlYLE1BQWpYLEVBQXlYLFVBQXpYLEVBQXFZLE1BQXJZLEVBQTZZLFFBQTdZLEVBQXVaLFNBQXZaLEVBQWthLE1BQWxhLEVBQTBhLE1BQTFhLEVBQWtiLFVBQWxiLEVBQThiLE9BQTliLEVBQXVjLFFBQXZjLEVBQWlkLFFBQWpkLEVBQTJkLFdBQTNkLEVBQXdlLFFBQXhlLEVBQWtmLEtBQWxmLEVBQXlmLGNBQXpmLEVBQXlnQixTQUF6Z0IsRUFBb2hCLFNBQXBoQixFQUEraEIsWUFBL2hCLEVBQTZpQixjQUE3aUIsRUFBNmpCLFFBQTdqQixFQUF1a0IsT0FBdmtCLEVBQWdsQixRQUFobEIsRUFBMGxCLFVBQTFsQixFQUFzbUIsbUJBQXRtQixFQUEybkIsZ0JBQTNuQixFQUE2b0IsVUFBN29CLEVBQXlwQixtQkFBenBCLEVBQThxQixnQkFBOXFCLEVBQWdzQixVQUFoc0IsRUFBNHNCLG1CQUE1c0IsRUFBaXVCLGdCQUFqdUIsRUFBbXZCLFVBQW52QixFQUErdkIsbUJBQS92QixFQUFveEIsZ0JBQXB4QixFQUFzeUIsVUFBdHlCLEVBQWt6QixtQkFBbHpCLEVBQXUwQixnQkFBdjBCLEVBQXkxQixVQUF6MUIsRUFBcTJCLG1CQUFyMkIsRUFBMDNCLGdCQUExM0IsRUFBNDRCLFVBQTU0QixFQUF3NUIsbUJBQXg1QixFQUE2NkIsZ0JBQTc2QixFQUErN0IsVUFBLzdCLEVBQTI4QixtQkFBMzhCLEVBQWcrQixnQkFBaCtCLEVBQWsvQixVQUFsL0IsRUFBOC9CLG1CQUE5L0IsRUFBbWhDLGdCQUFuaEMsRUFBcWlDLFdBQXJpQyxFQUFrakMsb0JBQWxqQyxFQUF3a0MsaUJBQXhrQyxFQUEybEMsTUFBM2xDLEVBQW1tQyxXQUFubUMsRUFBZ25DLFNBQWhuQyxFQUEybkMsT0FBM25DLEVBQW9vQyxnQkFBcG9DLENBQWI7QUFDQSxZQUFJTixTQUFTTSxPQUFPQyxHQUFQLENBQVduUCxLQUFNLElBQUdBLENBQUUsR0FBdEIsRUFBMEJvUCxJQUExQixDQUErQixHQUEvQixJQUFzQyxJQUFuRCxDQWhDVSxDQWtDVjs7QUFDQVAsZUFBT1EsYUFBUCxHQUE4QkMsV0FBUCw2QkFBdUI7QUFDNUMxTixpQkFBT2tNLFNBQVMsQ0FBQyxVQUFVd0IsV0FBWCxFQUF3QkMsS0FBeEIsQ0FBOEIsQ0FBQyxDQUEvQixDQUFoQjtBQUNBTixlQUFNLEdBQUVuQyxPQUFRLElBQUdsTCxJQUFLLEVBQXhCO0FBQ0FOLHFCQUFZLEdBQUUyTixFQUFHLElBQUduTSxPQUFPME0sV0FBWSxFQUF2QztBQUNBLHdCQUFNM0UsUUFBUWdDLEtBQVIsQ0FBY29DLEVBQWQsQ0FBTixFQUo0QyxDQUs1Qzs7QUFDQSx3QkFBTXBFLFFBQVE0RSxVQUFSLENBQW1Cbk8sUUFBbkIsRUFBNkJtTSxNQUFNaUMsTUFBTixDQUFhZCxNQUFiLEVBQXFCLFdBQXJCLENBQTdCLENBQU47QUFDRCxTQVBzQixDQUF2QixDQW5DVSxDQTRDVjs7O0FBQ0FDLGVBQU9jLFFBQVAsR0FBeUJDLEdBQVAsNkJBQWU7QUFDL0IsY0FBSUMsUUFBUUQsSUFBSUMsS0FBaEI7QUFDQSxjQUFJdEcsT0FBT3FHLElBQUlyRyxJQUFmLENBRitCLENBRy9COztBQUNBLGNBQUk1RixTQUFTdUwsT0FBT0MsR0FBUCxDQUFXblAsS0FBSztBQUFFLG1CQUFPNlAsTUFBTTdQLENBQU4sSUFBWSxJQUFHNlAsTUFBTTdQLENBQU4sQ0FBUyxHQUF4QixHQUE2QixJQUFwQztBQUEwQyxXQUE1RCxFQUE4RG9QLElBQTlELENBQW1FLEdBQW5FLElBQTBFLElBQXZGO0FBQ0Esd0JBQU12RSxRQUFRNEUsVUFBUixDQUFtQm5PLFFBQW5CLEVBQTZCbU0sTUFBTWlDLE1BQU4sQ0FBYS9MLE1BQWIsRUFBcUIsV0FBckIsQ0FBN0IsQ0FBTixFQUwrQixDQU0vQjs7QUFDQSxlQUFLLElBQUltTSxHQUFULElBQWdCdkcsS0FBS3dHLE1BQXJCLEVBQTZCO0FBQzNCLGdCQUFJQyxTQUFVLEdBQUVsTixPQUFPckIsUUFBUyxJQUFHcU8sR0FBSSxFQUF2QztBQUNBLGdCQUFJRyxTQUFVLEdBQUVoQixFQUFHLElBQUdhLEdBQUksRUFBMUI7O0FBQ0EsZ0JBQUk7QUFDRjtBQUNBLDRCQUFNakYsUUFBUXFGLE1BQVIsQ0FBZUQsTUFBZixDQUFOO0FBQ0QsYUFIRCxDQUdFLE9BQU9oSyxDQUFQLEVBQVU7QUFDViw0QkFBTTRFLFFBQVFzRixRQUFSLENBQWlCSCxNQUFqQixFQUF5QkMsTUFBekIsQ0FBTjtBQUNEO0FBQ0Y7QUFDRixTQWpCaUIsQ0FBbEIsQ0E3Q1UsQ0FnRVY7OztBQUNBcEIsZUFBT3VCLFdBQVAsR0FBNEJkLFdBQVAsNkJBQXVCO0FBQzFDLGdCQUFNZSxNQUFNM0MsU0FBUyxLQUFULENBQVo7QUFDQSxnQkFBTTRDLFVBQVcsR0FBRXRCLFNBQVUsSUFBR3BOLElBQUssTUFBckM7QUFDQSxnQkFBTTJPLFNBQVMxRixRQUFRc0QsaUJBQVIsQ0FBMEJtQyxPQUExQixDQUFmO0FBQ0FELGNBQUloQyxJQUFKLENBQVNrQyxNQUFUO0FBQ0FGLGNBQUlHLFNBQUosQ0FBY3ZCLEVBQWQsRUFBa0IsS0FBbEI7QUFDQW9CLGNBQUlJLFFBQUo7QUFDRCxTQVBvQixDQUFyQixDQWpFVSxDQTBFVjtBQUNBOzs7QUFFQSxZQUFJak4sb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSUMseUJBQWlCTixlQUFlTyxRQUFmLENBQXdCSCxLQUFLSSxHQUE3QixDQUFqQixDQUFKLENBRGlDLENBRWpDOztBQUNBLGdCQUFJRixZQUFZRixLQUFLTSxJQUFMLENBQVVnRyxLQUFWLENBQWdCYSxXQUFoQyxFQUE2QztBQUMzQyxrQkFBSWIsc0JBQWMxRyxlQUFld0gsZ0JBQWYsQ0FBZ0M3TixPQUFPL0MsT0FBdkMsRUFBZ0R3SixJQUFoRCxDQUFkLENBQUo7QUFDQSw0QkFBTXNGLE9BQU8rQixNQUFQLENBQWM7QUFBQ2YsdUJBQU9BLEtBQVI7QUFBZXRHLHNCQUFNQTtBQUFyQixlQUFkLENBQU47QUFDRDtBQUNGLFdBUFM7QUFGbUIsU0FBZixDQUFaLENBQUo7QUFXQXNGLGVBQU9qQyxLQUFQO0FBRUEsZUFBT3BKLEdBQVA7QUFDRCxPQTNGRCxDQUZJLENBQU47QUErRkEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBcEdEO0FBQUE7O0FBM0NhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNsQkEvSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsK0JBQVIsQ0FBYjtBQUF1REYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBdkRGLE9BQU9pUixNQUFQLENBQWM7QUFBQ0MsV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSUMsS0FBSjtBQUFVblIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDaVIsUUFBTS9RLENBQU4sRUFBUTtBQUFDK1EsWUFBTS9RLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFeEMsTUFBTThRLFVBQVUsSUFBSUMsTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUFnQztBQUFDQyxnQkFBYztBQUFmLENBQWhDLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDRlByUixPQUFPaVIsTUFBUCxDQUFjO0FBQUNsTyxVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJb08sS0FBSjtBQUFVblIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDaVIsUUFBTS9RLENBQU4sRUFBUTtBQUFDK1EsWUFBTS9RLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlrUixJQUFKO0FBQVN0UixPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDa1IsV0FBS2xSLENBQUw7QUFBTzs7QUFBbkIsQ0FBN0IsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSW1SLE9BQUo7QUFBWXZSLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNtUixjQUFRblIsQ0FBUjtBQUFVOztBQUF0QixDQUFwQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJb1IsU0FBSjtBQUFjeFIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDc1IsWUFBVXBSLENBQVYsRUFBWTtBQUFDb1IsZ0JBQVVwUixDQUFWO0FBQVk7O0FBQTFCLENBQWpDLEVBQTZELENBQTdEO0FBYW5aLE1BQU1xUixVQUFVLElBQUlOLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBZ0M7QUFDOUNDLGdCQUFjO0FBRGdDLENBQWhDLENBQWhCOztBQUlPLE1BQU10TyxNQUFOLFNBQXFCeU8sU0FBckIsQ0FBK0I7QUFFcENFLGNBQVlDLFFBQVosRUFBc0I7QUFFcEIsUUFBSTNKLFVBQVV5SixRQUFRRyxPQUFSLENBQWdCO0FBQzVCN0gsV0FBSzRIO0FBRHVCLEtBQWhCLENBQWQ7QUFJQSxVQUFNM0osT0FBTjtBQUVBLFFBQUlHLE9BQU8sS0FBSzBKLE9BQUwsRUFBWDs7QUFFQSxZQUFRMUosS0FBSzJKLElBQWI7QUFFRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSXBQLEtBQUosQ0FBVXdGLEtBQUsxRSxJQUFmLENBQWI7O0FBQ0EsYUFBS3VPLE1BQUwsR0FBYyxDQUFRQyxXQUFZbE8sTUFBRCxJQUFVLENBQUUsQ0FBL0IsRUFBaUNtTyxVQUFXN0wsQ0FBRCxJQUFLLENBQUUsQ0FBbEQsOEJBQXdEO0FBQ3BFLGNBQUlyQyxNQUFPLGlCQUFnQm1FLEtBQUtnSyxLQUFNLEVBQXRDO0FBQ0EsK0JBQWEsS0FBS0osS0FBTCxDQUFXSyxjQUFYLENBQTBCcE8sR0FBMUIsRUFBK0JpTyxRQUEvQixFQUF5Q0MsT0FBekMsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFFRjtBQUNFLGNBQU0sSUFBSUcsS0FBSixDQUFVLHVCQUFWLENBQU47QUFYSjtBQWNEO0FBRUQ7Ozs7OztBQUlNeE8sU0FBTixDQUFjeU8sWUFBWSxFQUExQixFQUE4QkosVUFBaUI3TCxDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUF4QztBQUFBLG9DQUF5RDtBQUV2RCxVQUFJMkIsVUFBVSxLQUFLdUssVUFBTCxFQUFkLENBRnVELENBSXZEOztBQUNBdkssY0FBUXdLLE9BQVIsQ0FBZ0JDLElBQWhCLENBQXFCO0FBQ25CWCxjQUFNLE1BRGE7QUFFbkJuTyxlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJK08sUUFBUSxFQUFaOztBQUNBLFdBQUssSUFBSXRQLE1BQVQsSUFBbUI0RSxRQUFRd0ssT0FBM0IsRUFBb0M7QUFDbENFLGNBQU10UCxPQUFPME8sSUFBYixJQUFxQjtBQUNuQm5PLGlCQUFPUCxPQUFPTyxLQURLO0FBRW5CK08saUJBQU87QUFGWSxTQUFyQjtBQUlEOztBQUVELG9CQUFNLEtBQUtWLE1BQUwsQ0FDR2pPLE1BQVAsNkJBQWdCO0FBQ2QsYUFBSyxJQUFJWCxNQUFULElBQW1CNEUsUUFBUXdLLE9BQTNCLEVBQW9DO0FBQ2xDLGNBQUk3TyxRQUFRNE4sUUFBUW9CLFFBQVIsQ0FBaUJ2UCxPQUFPTyxLQUF4QixDQUFaO0FBQ0EsY0FBSWlQLE9BQU90QixLQUFNM04sS0FBTixDQUFYOztBQUNBLGNBQUlpUCxLQUFLN08sTUFBTCxDQUFKLEVBQWtCO0FBQ2hCMk8sa0JBQU10UCxPQUFPME8sSUFBYixFQUFtQlksS0FBbkI7O0FBQ0EsZ0JBQUksT0FBT0osVUFBVWxQLE9BQU8wTyxJQUFqQixDQUFQLEtBQWtDLFdBQXRDLEVBQWtEO0FBQ2hELDRCQUFNUSxVQUFVbFAsT0FBTzBPLElBQWpCLEVBQXVCL04sTUFBdkIsQ0FBTjtBQUNEOztBQUNEO0FBQ0Q7QUFDRjtBQUNGLE9BWkQsQ0FESSxFQWNKbU8sT0FkSSxDQUFOLEVBbEJ1RCxDQW1DdkQ7O0FBQ0EsYUFBT1EsS0FBUDtBQUVELEtBdENEO0FBQUE7O0FBaENvQyxDOzs7Ozs7Ozs7OztBQ2pCdEMxUyxPQUFPaVIsTUFBUCxDQUFjO0FBQUNPLGFBQVUsTUFBSUEsU0FBZjtBQUF5QjNPLFNBQU0sTUFBSUE7QUFBbkMsQ0FBZDtBQUF5RCxJQUFJc08sS0FBSjtBQUFVblIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDaVIsUUFBTS9RLENBQU4sRUFBUTtBQUFDK1EsWUFBTS9RLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBUW5OLE1BQU15UyxTQUFTLElBQUkxQixNQUFNQyxVQUFWLENBQXFCLFFBQXJCLEVBQStCO0FBQzVDQyxnQkFBYztBQUQ4QixDQUEvQixDQUFmOztBQUlPLE1BQU1HLFNBQU4sQ0FBZ0I7QUFJckJFLGNBQVkxSixPQUFaLEVBQXFCO0FBQ25CLFNBQUtBLE9BQUwsR0FBZUEsT0FBZjtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQTZKLFlBQVU7QUFDUixXQUFPLEtBQUs3SixPQUFMLENBQWE4SyxZQUFwQjtBQUNEOztBQUVEUCxlQUFhO0FBQ1gsV0FBTyxLQUFLdkssT0FBWjtBQUNEOztBQUVEbkUsVUFBUWlMLFdBQWtCL0ssTUFBUCw2QkFBa0IsQ0FBRSxDQUFwQixDQUFuQixFQUF5Q21PLFVBQWlCN0wsQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBbkQsRUFBb0UsQ0FBRTs7QUFyQmpEOztBQXlCaEIsTUFBTXhELEtBQU4sU0FBb0IyTyxTQUFwQixDQUE4QjtBQUVuQ0UsY0FBWXFCLE9BQVosRUFBcUI7QUFFbkIsUUFBSS9LLFVBQVU2SyxPQUFPakIsT0FBUCxDQUFlO0FBQzNCN0gsV0FBS2dKO0FBRHNCLEtBQWYsQ0FBZDtBQUlBLFVBQU0vSyxPQUFOO0FBRUEsUUFBSUcsT0FBTyxLQUFLMEosT0FBTCxFQUFYOztBQUVBLFlBQVExSixLQUFLMkosSUFBYjtBQUNFLFdBQUssT0FBTDtBQUNFLGFBQUtDLEtBQUwsR0FBYSxJQUFJcFAsS0FBSixDQUFVd0YsS0FBSzFFLElBQWYsQ0FBYjs7QUFDQSxhQUFLdU8sTUFBTCxHQUFxQmxRLEdBQVAsNkJBQWU7QUFDM0IsY0FBSWtDLE1BQU8saUJBQWdCbUUsS0FBS2dLLEtBQU0sWUFBV3JRLElBQUlrUixHQUFJLFNBQVFsUixJQUFJMEUsRUFBRyxHQUF4RTtBQUNBLCtCQUFhLEtBQUt1TCxLQUFMLENBQVdwTyxLQUFYLENBQWlCSyxHQUFqQixDQUFiO0FBQ0QsU0FIYSxDQUFkOztBQUlBOztBQUNGO0FBQ0UsY0FBTSxJQUFJcU8sS0FBSixDQUFVLG9CQUFWLENBQU47QUFUSjtBQVlEO0FBR0Q7Ozs7OztBQUlBeE8sVUFBUWlMLFdBQWtCL0ssTUFBUCw2QkFBa0IsQ0FBRSxDQUFwQixDQUFuQixFQUF5Q21PLFVBQWlCN0wsQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBbkQsRUFBb0U7QUFFbEUsUUFBSWdGLE1BQU13SCxPQUFPckssSUFBUCxDQUFZO0FBQ3BCdUssZUFBUyxLQUFLL0ssT0FBTCxDQUFhK0I7QUFERixLQUFaLEVBRVA7QUFDRHVGLGNBQVE7QUFDTnZGLGFBQUssQ0FEQztBQUVOdkQsWUFBSSxDQUZFO0FBR053TSxhQUFLO0FBSEM7QUFEUCxLQUZPLENBQVY7QUFVQSxXQUFPLElBQUlDLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFFbkI5SCxVQUFJK0gsT0FBSixDQUNFLENBQU90UixHQUFQLEVBQVl1UixLQUFaLDhCQUFzQjtBQUNwQixZQUFJO0FBQ0YsY0FBSXRQLHVCQUFlLEtBQUtpTyxNQUFMLENBQVlsUSxHQUFaLENBQWYsQ0FBSjtBQUNBLHdCQUFNZ04sU0FBUy9LLE1BQVQsQ0FBTjtBQUNELFNBSEQsQ0FHRSxPQUFPc0MsQ0FBUCxFQUFVO0FBQ1Y2TCxrQkFBUTdMLENBQVI7QUFDRDs7QUFDRCxZQUFJZ04sUUFBUSxDQUFSLEtBQWNoSSxJQUFJcUgsS0FBSixFQUFsQixFQUErQjtBQUM3QlE7QUFDRDtBQUNGLE9BVkQsQ0FERjtBQWFELEtBaEJJLEVBaUJMSSxLQWpCSyxDQWtCSmpOLENBQUQsSUFBTztBQUNMLFlBQU1BLENBQU47QUFDRCxLQXBCSSxDQUFQO0FBdUJEOztBQWxFa0MsQzs7Ozs7Ozs7Ozs7QUNyQ3JDckcsT0FBT2lSLE1BQVAsQ0FBYztBQUFDc0MsUUFBSyxNQUFJQTtBQUFWLENBQWQ7QUFBK0IsSUFBSXBDLEtBQUo7QUFBVW5SLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ2lSLFFBQU0vUSxDQUFOLEVBQVE7QUFBQytRLFlBQU0vUSxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRWxDLE1BQU1tVCxPQUFPLElBQUlwQyxNQUFNQyxVQUFWLENBQXFCLE1BQXJCLEVBQTZCO0FBQUNDLGdCQUFjO0FBQWYsQ0FBN0IsQ0FBYixDOzs7Ozs7Ozs7OztBQ0ZQclIsT0FBT2lSLE1BQVAsQ0FBYztBQUFDMVEsV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSTRRLEtBQUo7QUFBVW5SLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ2lSLFFBQU0vUSxDQUFOLEVBQVE7QUFBQytRLFlBQU0vUSxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRXhDLE1BQU1HLFVBQVUsSUFBSTRRLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBK0I7QUFBQ0MsZ0JBQWE7QUFBZCxDQUEvQixDQUFoQixDOzs7Ozs7Ozs7OztBQ0ZQclIsT0FBT2lSLE1BQVAsQ0FBYztBQUFDNUgsWUFBUyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSTFHLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBakQsRUFBdUUsQ0FBdkU7O0FBRTFDLE1BQU1pSixRQUFOLENBQWU7QUFDcEI7Ozs7QUFJQXFJLGNBQWFLLEtBQWIsRUFBb0I7QUFDbEIsU0FBS3lCLE1BQUwsR0FBY3pCLEtBQWQ7QUFDRDs7QUFFSy9ILGFBQU4sQ0FBbUJ5SixjQUFuQixFQUFtQzVKLFdBQVcsQ0FBOUM7QUFBQSxvQ0FBaUQ7QUFDL0Msb0JBQU0sS0FBSzJKLE1BQUwsQ0FBWUUsV0FBWixDQUNKLG1CQURJLEVBRUgsc0JBQXFCRCxjQUFlLEVBRmpDLEVBR0osRUFISSxFQUdBO0FBQ0YxRyxlQUFPbEQsUUFETDtBQUVGOEoseUJBQWlCLENBRmY7QUFHRnpOLHFCQUFhO0FBSFgsT0FIQSxDQUFOO0FBVUEsb0JBQU0sS0FBS3NOLE1BQUwsQ0FBWUUsV0FBWixDQUNKLG1CQURJLEVBRUgsc0JBQXFCRCxjQUFlLEVBRmpDLEVBR0osRUFISSxFQUdBO0FBQ0YxRyxlQUFPbEQsUUFETDtBQUVGM0QscUJBQWE7QUFGWCxPQUhBLENBQU47QUFRRCxLQW5CRDtBQUFBOztBQXFCTTZFLGtCQUFOLENBQXdCdkosSUFBeEI7QUFBQSxvQ0FBOEI7QUFDNUIsVUFBSW9TLFlBQVlwUyxLQUFLK0ksVUFBckI7QUFFQSxVQUFJM0csTUFBTSxFQUFWLENBSDRCLENBSzVCOztBQUNBLFVBQUlpUSxTQUFnQjdRLEdBQVAsNkJBQWU7QUFDMUIsWUFBSWdCLE1BQU87OzJCQUVVeEMsS0FBS3NTLFVBQVcsY0FBYTlRLEdBQUk7T0FGdEQ7QUFJQVksWUFBSTZPLElBQUosZUFBZSxLQUFLZSxNQUFMLENBQVk3UCxLQUFaLENBQWtCSyxHQUFsQixDQUFmO0FBQ0QsT0FOWSxDQUFiLENBTjRCLENBYzVCOzs7QUFDQSxVQUFJK1AsUUFBZS9RLEdBQVAsNkJBQWU7QUFDekI7QUFDQSxZQUFJZ0IsTUFBTzs7MkJBRVV4QyxLQUFLc1MsVUFBVyxjQUFhOVEsR0FBSTtPQUZ0RDtBQUlBLFlBQUlnUix5QkFBaUIsS0FBS1IsTUFBTCxDQUFZN1AsS0FBWixDQUFrQkssR0FBbEIsQ0FBakIsQ0FBSjtBQUNBLFlBQUlnUSxTQUFTLENBQVQsRUFBWSxVQUFaLENBQUosRUFBNkI7QUFFN0JwUSxZQUFJNk8sSUFBSixlQUNRLEtBQUtlLE1BQUwsQ0FBWXBOLFdBQVosQ0FDSixpQkFESSxFQUVKLEVBRkksRUFHSjtBQUNFME4sc0JBQVl0UyxLQUFLc1MsVUFEbkI7QUFFRTlRLGVBQUtBLEdBRlA7QUFHRXVILHNCQUFZcUosU0FIZDtBQUlFM04sdUJBQWE7QUFKZixTQUhJLENBRFI7QUFXRCxPQXBCVyxDQUFaOztBQXNCQSxXQUFLLElBQUlnTyxNQUFULElBQW1CelMsS0FBSzBTLElBQXhCLEVBQThCO0FBQzVCLGdCQUFRRCxPQUFPRSxHQUFmO0FBQ0UsZUFBSyxJQUFMO0FBQ0UsMEJBQU1KLE1BQU1FLE9BQU9qUixHQUFiLENBQU47QUFDQTs7QUFDRixlQUFLLEtBQUw7QUFDRSwwQkFBTTZRLE9BQU9JLE9BQU9qUixHQUFkLENBQU47QUFDQTtBQU5KO0FBUUQ7O0FBRUQsYUFBTztBQUNMWSxhQUFLQTtBQURBLE9BQVA7QUFHRCxLQW5ERDtBQUFBOztBQXFETWlILG9CQUFOLENBQTBCckosSUFBMUI7QUFBQSxvQ0FBZ0M7QUFDOUIsVUFBSTRTLFlBQVk1UyxLQUFLc1MsVUFBckI7QUFDQSxVQUFJM0QsU0FBUzNPLEtBQUsyTyxNQUFsQjtBQUNBLFVBQUl5RCxZQUFZcFMsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVixDQUw4QixDQU85Qjs7QUFDQSxVQUFJSSxNQUFPLG9EQUFtRG9RLFNBQVUsRUFBeEU7QUFDQXhRLFVBQUk2TyxJQUFKLGVBQWUsS0FBS2UsTUFBTCxDQUFZN1AsS0FBWixDQUFrQkssR0FBbEIsQ0FBZixHQVQ4QixDQVc5Qjs7QUFDQSxXQUFLLElBQUlxUSxJQUFJLENBQWIsRUFBZ0JBLElBQUlsRSxPQUFPbUUsTUFBM0IsRUFBbUNELEdBQW5DLEVBQXdDO0FBQ3RDLHNCQUFNLEtBQUtiLE1BQUwsQ0FBWXBOLFdBQVosQ0FDSixtQkFESSxFQUNpQjtBQUNuQjBOLHNCQUFZTSxTQURPO0FBRW5CN0osc0JBQVlxSixTQUZPO0FBR25CVyxxQkFBV3BFLE9BQU9rRSxDQUFQLENBSFE7QUFJbkJHLGdCQUFNSCxJQUFJO0FBSlMsU0FEakIsRUFNRDtBQUNEcE8sdUJBQWE7QUFEWixTQU5DLENBQU47QUFVRDs7QUFFRCxhQUFPO0FBQ0xyQyxhQUFLQTtBQURBLE9BQVA7QUFHRCxLQTVCRDtBQUFBOztBQThCTWtILGVBQU4sQ0FBcUJ0SixJQUFyQjtBQUFBLG9DQUEyQjtBQUN6QixVQUFJaVQsYUFBYSxFQUFqQjtBQUNBLFVBQUlDLE9BQU8sRUFBWCxDQUZ5QixDQUl6Qjs7QUFFQUEsYUFBTyxDQUNMLFFBREssRUFFTCxNQUZLLEVBR0wsTUFISyxFQUlMLGtCQUpLLEVBS0wsb0JBTEssRUFNTCxhQU5LLEVBT0wsV0FQSyxDQUFQOztBQVNBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUlsVCxLQUFLbVQsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0JuVCxLQUFLbVQsQ0FBTCxDQUFoQjtBQUNkOztBQUVELG9CQUFNLEtBQUtuQixNQUFMLENBQVlFLFdBQVosQ0FDSixhQURJLEVBRUgsZ0JBQWVsUyxLQUFLc1MsVUFBVyxFQUY1QixFQUdKVyxVQUhJLEVBR1E7QUFDVnZPLHFCQUFhO0FBREgsT0FIUixDQUFOLEVBbkJ5QixDQTJCekI7O0FBRUF1TyxtQkFBYSxFQUFiO0FBQ0FDLGFBQU8sQ0FDTCxrQkFESyxFQUVMLGNBRkssRUFHTCxZQUhLLEVBSUwsU0FKSyxFQUtMLFNBTEssRUFNTCxjQU5LLENBQVA7O0FBUUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSWxULEtBQUttVCxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQm5ULEtBQUttVCxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQsVUFBSS9RLG9CQUFZLEtBQUs0UCxNQUFMLENBQVlFLFdBQVosQ0FDZCxtQkFEYyxFQUViLGdCQUFlbFMsS0FBS3NTLFVBQVcsRUFGbEIsRUFHZFcsVUFIYyxFQUdGO0FBQ1Z2TyxxQkFBYTtBQURILE9BSEUsQ0FBWixDQUFKO0FBUUEsYUFBTztBQUNMdEMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0FyREQ7QUFBQTs7QUF1RE02RyxlQUFOLENBQXFCakosSUFBckI7QUFBQSxvQ0FBMkI7QUFDekIsVUFBSW9TLFlBQVlwUyxLQUFLK0ksVUFBckI7QUFFQSxVQUFJM0csTUFBTSxFQUFWO0FBRUEsVUFBSTZRLGFBQWEsRUFBakI7QUFDQSxVQUFJQyxPQUFPLEVBQVg7QUFFQUEsYUFBTyxDQUNMLE1BREssRUFFTCxvQkFGSyxDQUFQLENBUnlCLENBWXpCO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUlsVCxLQUFLbVQsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0JuVCxLQUFLbVQsQ0FBTCxDQUFoQjtBQUNkOztBQUVEL1EsVUFBSWtRLFVBQUosaUJBQXVCLEtBQUtOLE1BQUwsQ0FBWXBOLFdBQVosQ0FDckIsYUFEcUIsRUFFckJxTyxVQUZxQixFQUVUO0FBQ1ZsSyxvQkFBWXFKLFNBREY7QUFFVjFQLGdCQUFRLENBRkU7QUFHVjhCLGNBQU0sTUFISTtBQUlWNE8sMEJBQWtCLE1BSlI7QUFLVkMscUJBQWEsTUFMSDtBQU1WQyxtQkFBVyxNQU5EO0FBT1Y3TyxxQkFBYSxPQVBIO0FBUVZDLHFCQUFhO0FBUkgsT0FGUyxDQUF2QjtBQWNBdU8sbUJBQWEsRUFBYjtBQUNBQyxhQUFPLENBQ0wsY0FESyxFQUVMLGlCQUZLLEVBR0wsU0FISyxFQUlMLFNBSkssRUFLTCxjQUxLLENBQVAsQ0FwQ3lCLENBMkN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUlsVCxLQUFLbVQsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0JuVCxLQUFLbVQsQ0FBTCxDQUFoQjtBQUNkOztBQUVEL1EsVUFBSXVHLGdCQUFKLGlCQUE2QixLQUFLcUosTUFBTCxDQUFZcE4sV0FBWixDQUMzQixtQkFEMkIsRUFFM0JxTyxVQUYyQixFQUVmO0FBQ1ZsSyxvQkFBWXFKLFNBREY7QUFFVkUsb0JBQVlsUSxJQUFJa1EsVUFGTjtBQUdWL0csZUFBTyxDQUhHO0FBSVY0Ryx5QkFBaUIsQ0FKUDtBQUtWb0IsNEJBQW9CLE1BTFY7QUFNVkMsNEJBQW9CLE1BTlY7QUFPVkMsMEJBQWtCLE1BUFI7QUFRVkMsb0JBQVksTUFSRjtBQVNWalAscUJBQWEsT0FUSDtBQVVWQyxxQkFBYTtBQVZILE9BRmUsQ0FBN0I7O0FBZ0JBLFdBQUssSUFBSXlPLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJbFQsS0FBS21ULENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCblQsS0FBS21ULENBQUwsQ0FBaEI7QUFDZDs7QUFFRC9RLFVBQUl1UixnQkFBSixpQkFBNkIsS0FBSzNCLE1BQUwsQ0FBWXBOLFdBQVosQ0FDM0IsbUJBRDJCLEVBQ04sRUFETSxFQUNGO0FBQ3ZCK0QsMEJBQWtCdkcsSUFBSXVHLGdCQURDO0FBRXZCSSxvQkFBWXFKLFNBRlc7QUFHdkI3RyxlQUFPLENBSGdCO0FBSXZCOUcscUJBQWEsT0FKVTtBQUt2QkMscUJBQWE7QUFMVSxPQURFLENBQTdCLEVBekV5QixDQW1GekI7O0FBQ0EsYUFBTztBQUNMdEMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0F2RkQ7QUFBQTs7QUF4S29CLEM7Ozs7Ozs7Ozs7O0FDRnRCNUQsT0FBT2lSLE1BQVAsQ0FBYztBQUFDbUUsbUJBQWdCLE1BQUlBLGVBQXJCO0FBQXFDQyxZQUFTLE1BQUlBLFFBQWxEO0FBQTJEQyxpQkFBYyxNQUFJQSxhQUE3RTtBQUEyRmxNLGlCQUFjLE1BQUlBLGFBQTdHO0FBQTJIdUUsc0JBQW1CLE1BQUlBO0FBQWxKLENBQWQ7QUFBcUwsSUFBSWhMLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJbVYsV0FBSjtBQUFnQnZWLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ3FWLGNBQVluVixDQUFaLEVBQWM7QUFBQ21WLGtCQUFZblYsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJOEssT0FBSjtBQUFZbEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlCQUFSLENBQWIsRUFBd0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM4SyxjQUFROUssQ0FBUjtBQUFVOztBQUF0QixDQUF4QyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJa1IsSUFBSjtBQUFTdFIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE1BQVIsQ0FBYixFQUE2QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2tSLFdBQUtsUixDQUFMO0FBQU87O0FBQW5CLENBQTdCLEVBQWtELENBQWxEO0FBQXFELElBQUltUixPQUFKO0FBQVl2UixPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDbVIsY0FBUW5SLENBQVI7QUFBVTs7QUFBdEIsQ0FBcEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSW9WLE1BQUo7QUFBV3hWLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ3NWLFNBQU9wVixDQUFQLEVBQVM7QUFBQ29WLGFBQU9wVixDQUFQO0FBQVM7O0FBQXBCLENBQS9CLEVBQXFELENBQXJEOztBQVM3aUIsTUFBTWdWLGVBQU4sQ0FBc0I7QUFDM0IxRCxjQUFhdkosSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsUUFBSXlOLFFBQUo7O0FBQ0EsWUFBUXROLEtBQUsySixJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UyRCxtQkFBVyxJQUFJSCxhQUFKLENBQWtCbk4sSUFBbEIsRUFBd0JILE9BQXhCLENBQVg7QUFGSjs7QUFLQSxXQUFPeU4sUUFBUDtBQUNEOztBQVQwQjs7QUFZdEIsTUFBTUosUUFBTixDQUFlO0FBQ3BCM0QsY0FBYXZKLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFNBQUtHLElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUtILE9BQUwsR0FBZUEsT0FBZjtBQUNEOztBQUVELFNBQU8wTixPQUFQLENBQWdCdk4sSUFBaEIsRUFBc0JILE9BQXRCLEVBQStCO0FBQzdCLFlBQVFHLEtBQUsySixJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UsZUFBTyxJQUFJd0QsYUFBSixDQUFrQm5OLElBQWxCLEVBQXdCSCxPQUF4QixDQUFQOztBQUNGO0FBQ0UsY0FBTSxJQUFJcUssS0FBSixDQUFVLG1CQUFWLENBQU47QUFKSjtBQU1EOztBQUVEc0QsYUFBWTtBQUNWLFdBQU8sS0FBS3hOLElBQVo7QUFDRDs7QUFFRHlOLGFBQVk7QUFDVixXQUFPLEtBQUt6TixJQUFMLENBQVUxRSxJQUFqQjtBQUNEOztBQUVEb1MsZ0JBQWU7QUFDYixXQUFPLEtBQUs3TixPQUFaO0FBQ0Q7O0FBRUQ4TixxQkFDRUMsS0FBSyxDQUFPOUQsV0FBV2xPLFVBQVUsQ0FBRSxDQUE5QixFQUFnQ21PLFVBQVU3TCxLQUFLLENBQUUsQ0FBakQsOEJBQXNELENBQUUsQ0FBeEQsQ0FEUCxFQUVFO0FBQ0EsU0FBSzJMLE1BQUwsR0FBYytELEVBQWQ7QUFDRDtBQUVEOzs7Ozs7Ozs7OztBQVNNbFMsU0FBTixDQUFlbVMsWUFBWSxFQUEzQjtBQUFBLG9DQUErQjtBQUM3QixVQUFJaE8sVUFBVSxLQUFLNk4sV0FBTCxFQUFkLENBRDZCLENBRzdCOztBQUNBN04sY0FBUXdLLE9BQVIsQ0FBZ0JDLElBQWhCLENBQXFCO0FBQ25CelEsY0FBTSxNQURhO0FBRW5CMkIsZUFBTztBQUZZLE9BQXJCO0FBS0EsVUFBSXNTLFVBQVUsRUFBZDs7QUFDQSxXQUFLLElBQUlDLENBQVQsSUFBY2xPLFFBQVF3SyxPQUF0QixFQUErQixDQUM5Qjs7QUFFRCxVQUFJQSxVQUFVLEVBQWQ7O0FBRUEsV0FBSyxJQUFJMEQsQ0FBVCxJQUFjbE8sUUFBUXdLLE9BQXRCLEVBQStCO0FBQzdCeUQsZ0JBQVFDLEVBQUVsVSxJQUFWLElBQWtCO0FBQ2hCMkIsaUJBQU91UyxFQUFFdlMsS0FETztBQUVoQndTLGlCQUFPLE9BQU9ELEVBQUVDLEtBQVQsS0FBbUIsV0FBbkIsR0FBaUNELEVBQUVDLEtBQW5DLEdBQTJDLENBRmxDO0FBR2hCekQsaUJBQU87QUFIUyxTQUFsQjtBQUtBRixnQkFBUUMsSUFBUixDQUNFO0FBQ0V6USxnQkFBTWtVLEVBQUVsVSxJQURWO0FBRUU0USxnQkFBTXRCLEtBQUtDLFFBQVFvQixRQUFSLENBQWlCdUQsRUFBRXZTLEtBQW5CLENBQUw7QUFGUixTQURGO0FBTUQ7O0FBRUQsb0JBQU0sS0FBS3FPLE1BQUwsQ0FDSixDQUFPak8sTUFBUCxFQUFlNkYsT0FBZiw4QkFBMkI7QUFDekIsYUFBSyxJQUFJc00sQ0FBVCxJQUFjMUQsT0FBZCxFQUF1QjtBQUNyQjtBQUNBLGNBQUk0RCxJQUFJSCxRQUFRQyxFQUFFbFUsSUFBVixDQUFSOztBQUNBLGNBQUlvVSxFQUFFRCxLQUFOLEVBQWE7QUFDWCxnQkFBSUMsRUFBRTFELEtBQUYsSUFBVzBELEVBQUVELEtBQWpCLEVBQXdCO0FBQ3RCO0FBQ0Q7QUFDRjs7QUFFRCxjQUFJRCxFQUFFdEQsSUFBRixDQUFPN08sTUFBUCxDQUFKLEVBQW9CO0FBQ2xCO0FBQ0FxUyxjQUFFMUQsS0FBRixHQUZrQixDQUlsQjs7QUFDQSxnQkFBSSxPQUFPc0QsVUFBVUUsRUFBRWxVLElBQVosQ0FBUCxLQUE2QixXQUFqQyxFQUE4QztBQUM1Qyw0QkFBTWdVLFVBQVVFLEVBQUVsVSxJQUFaLEVBQWtCK0IsTUFBbEIsRUFBMEI2RixPQUExQixDQUFOO0FBQ0Q7O0FBQ0Q7QUFDRDtBQUNGO0FBQ0YsT0FyQkQsQ0FESSxDQUFOLEVBN0I2QixDQXFEN0I7O0FBQ0EsYUFBT3FNLE9BQVA7QUFDRCxLQXZERDtBQUFBOztBQTFDb0I7O0FBb0dmLE1BQU1YLGFBQU4sU0FBNEJELFFBQTVCLENBQXFDO0FBQzFDM0QsY0FBYXZKLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFVBQU1HLElBQU4sRUFBWUgsT0FBWjtBQUVBLFFBQUl2RSxPQUFPLEtBQUttUyxRQUFMLEVBQVg7QUFFQSxTQUFLN0QsS0FBTCxHQUFhLElBQUlwUCxLQUFKLENBQVVjLElBQVYsQ0FBYjtBQUNBLFNBQUtxUyxrQkFBTCxDQUF3QixDQUFPN0QsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBQ25ELFVBQUlsTyxNQUFPLGlCQUFnQm1FLEtBQUtnSyxLQUFNLEVBQXRDO0FBQ0EsVUFBSXZPLG9CQUFZLEtBQUttTyxLQUFMLENBQVdLLGNBQVgsQ0FBMEJwTyxHQUExQixFQUErQmlPLFFBQS9CLEVBQTBDNUwsQ0FBRCxJQUFPO0FBQUUsY0FBTUEsQ0FBTjtBQUFTLE9BQTNELENBQVosQ0FBSjtBQUNBLGFBQU96QyxHQUFQO0FBQ0QsS0FKdUIsQ0FBeEI7QUFLRDs7QUFaeUM7O0FBbUJyQyxNQUFNd0YsYUFBTixTQUE0QmlNLFFBQTVCLENBQXFDO0FBQzFDM0QsY0FBYXZKLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFVBQU1HLElBQU4sRUFBWUgsT0FBWixFQUQwQixDQUcxQjs7QUFDQSxTQUFLOE4sa0JBQUwsQ0FBd0IsQ0FBTzdELFFBQVAsRUFBaUJDLE9BQWpCLDhCQUE2QjtBQUNuRCxVQUFJbUUsTUFBSjtBQUNBQSw2QkFBZWQsWUFBWWUsT0FBWixDQUFvQm5PLEtBQUtvRixHQUF6QixDQUFmLEVBRm1ELENBSW5EOztBQUNBLFVBQUl0RixLQUFLb08sT0FBT3BPLEVBQVAsQ0FBVUUsS0FBS29PLFFBQWYsQ0FBVDtBQUNBLFVBQUloTyxhQUFhTixHQUFHTSxVQUFILENBQWNKLEtBQUtJLFVBQW5CLENBQWpCO0FBRUEsVUFBSXFCLFVBQVU7QUFDWnlNLGdCQUFRQSxNQURJO0FBRVo5TixvQkFBWUEsVUFGQTtBQUdaZ08sa0JBQVV0TztBQUhFLE9BQWQ7QUFNQSxVQUFJb0QsTUFBTTlDLFdBQVdDLElBQVgsRUFBVixDQWRtRCxDQWdCbkQ7O0FBQ0E2QyxVQUFJbUwsYUFBSixDQUFrQixpQkFBbEIsRUFBcUMsSUFBckMsRUFqQm1ELENBbUJuRDs7QUFDQSxVQUFJO0FBQ0YsNkJBQWFuTCxJQUFJd0IsT0FBSixFQUFiLEdBQTRCO0FBQzFCLGNBQUkvSyxvQkFBWXVKLElBQUl5QixJQUFKLEVBQVosQ0FBSjtBQUNBLHdCQUFNbUYsU0FBU25RLEdBQVQsRUFBYzhILE9BQWQsQ0FBTjtBQUNEOztBQUFBO0FBQ0YsT0FMRCxTQUtVO0FBQ1I7QUFDQSxzQkFBTXlCLElBQUkyQixLQUFKLEVBQU47QUFDRDtBQUNGLEtBN0J1QixDQUF4QjtBQThCRDs7QUFuQ3lDOztBQXNDckMsTUFBTVcsa0JBQU4sU0FBaUMwSCxRQUFqQyxDQUEwQztBQUMvQzNELGNBQWF2SixJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixVQUFNRyxJQUFOLEVBQVlILE9BQVosRUFEMEIsQ0FHMUI7O0FBQ0EsU0FBSzhOLGtCQUFMLENBQXdCLENBQU83RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQ7QUFDQSxVQUFJN0UsVUFBVTlLLEtBQUtnSyxLQUFMLENBQVdoSyxLQUFLQyxTQUFMLENBQWUyRixJQUFmLENBQVgsQ0FBZDtBQUNBa0YsY0FBUUUsR0FBUixHQUFlLEdBQUVGLFFBQVFFLEdBQUksZUFBN0I7QUFDQSxVQUFJM0QsVUFBVTtBQUNaeUQsaUJBQVNBO0FBREcsT0FBZDs7QUFJQSxhQUFPLENBQVAsRUFBVTtBQUNSO0FBQ0EsWUFBSXpKLG9CQUFZc0gsUUFBUW1DLE9BQVIsQ0FBWixDQUFKO0FBQ0F6SixjQUFNNFIsT0FBTzVSLEdBQVAsRUFBWTtBQUFDNlMsbUJBQVM7QUFBVixTQUFaLENBQU47QUFFQSxZQUFJQyxXQUFXQyxPQUFPL1MsSUFBSXdJLFFBQUosQ0FBYXdLLFlBQWIsQ0FBMEJGLFFBQTFCLENBQW1DRyxLQUExQyxDQUFmO0FBQ0EsWUFBSUMsY0FBY0gsT0FBTy9TLElBQUl3SSxRQUFKLENBQWF3SyxZQUFiLENBQTBCRSxXQUExQixDQUFzQ0QsS0FBN0MsQ0FBbEI7QUFDQSxZQUFJRSxhQUFhSixPQUFPL1MsSUFBSXdJLFFBQUosQ0FBYXdLLFlBQWIsQ0FBMEJHLFVBQTFCLENBQXFDRixLQUE1QyxDQUFqQjtBQUNBLFlBQUlHLGVBQWVwVCxJQUFJd0ksUUFBSixDQUFhd0ssWUFBYixDQUEwQkksWUFBN0MsQ0FSUSxDQVVSOztBQUNBLFlBQUlBLHdCQUF3QkMsS0FBNUIsRUFBbUM7QUFDakM7QUFDQSxlQUFLLElBQUk1QyxJQUFJLENBQWIsRUFBZ0JBLElBQUl5QyxXQUFwQixFQUFpQ3pDLEdBQWpDLEVBQXNDO0FBQ3BDLDBCQUFNcEMsU0FBUytFLGFBQWEzQyxDQUFiLENBQVQsRUFBMEJ6SyxPQUExQixDQUFOO0FBQ0Q7QUFDRixTQUxELE1BS087QUFDTDtBQUNBLHdCQUFNcUksU0FBUytFLFlBQVQsRUFBdUJwTixPQUF2QixDQUFOO0FBQ0Q7O0FBRUQsWUFBSWtELE9BQU9pSyxhQUFhRCxXQUF4QjtBQUVBLFlBQUloSyxPQUFPNEosUUFBWCxFQUFxQjtBQUNyQnJKLGdCQUFRRyxFQUFSLENBQVd1SixVQUFYLEdBQXdCakssSUFBeEI7QUFDRDtBQUNGLEtBbEN1QixDQUF4QjtBQW1DRDs7QUF4QzhDLEM7Ozs7Ozs7Ozs7O0FDbExqRDlNLE9BQU9pUixNQUFQLENBQWM7QUFBQzlRLFdBQVEsTUFBSXdJO0FBQWIsQ0FBZDtBQUE0QyxJQUFJVCxlQUFKO0FBQW9CbEksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDZ0ksa0JBQWdCOUgsQ0FBaEIsRUFBa0I7QUFBQzhILHNCQUFnQjlILENBQWhCO0FBQWtCOztBQUF0QyxDQUF0QyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJRyxPQUFKO0FBQVlQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNLLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTlDLEVBQXNFLENBQXRFO0FBQXlFLElBQUk4VyxRQUFKO0FBQWFsWCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUNnWCxXQUFTOVcsQ0FBVCxFQUFXO0FBQUM4VyxlQUFTOVcsQ0FBVDtBQUFXOztBQUF4QixDQUE3QixFQUF1RCxDQUF2RDtBQUEwRCxJQUFJK1csUUFBSjtBQUFhblgsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQytXLGVBQVMvVyxDQUFUO0FBQVc7O0FBQXZCLENBQXJDLEVBQThELENBQTlEOztBQVczUyxNQUFNdUksY0FBTixDQUFxQjtBQUM1QkssTUFBTixDQUFZYixJQUFaO0FBQUEsb0NBQWtCO0FBQ2hCLFdBQUttRCxLQUFMLGlCQUFtQnBELGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCLE9BQTFCLENBQW5CO0FBQ0EsV0FBS2lQLFFBQUwsaUJBQXNCbFAsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEIsVUFBMUIsQ0FBdEI7QUFDRCxLQUhEO0FBQUE7O0FBS00yQixVQUFOLENBQWdCdU4sTUFBaEI7QUFBQSxvQ0FBd0I7QUFDdEIsVUFBSTFOLHFCQUFhLEtBQUsyQixLQUFMLENBQVdzRyxPQUFYLENBQW1CO0FBQ2xDN0gsYUFBS3NOO0FBRDZCLE9BQW5CLEVBRWQ7QUFDRGpQLG9CQUFZO0FBQ1YscUJBQVc7QUFERDtBQURYLE9BRmMsQ0FBYixDQUFKO0FBT0EsVUFBSWtQLGFBQWEzTixLQUFLNE4sT0FBdEIsQ0FSc0IsQ0FVdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxVQUFJQyxhQUFhLEVBQWpCOztBQUVBLFdBQUssSUFBSUMsVUFBVCxJQUF1QkgsVUFBdkIsRUFBbUM7QUFDakMsWUFBSUksY0FBYyxDQUFsQjs7QUFFQSxhQUFLLElBQUlsUixFQUFULElBQWVpUixXQUFXRSxHQUExQixFQUErQjtBQUM3QixjQUFJSix3QkFBZ0IsS0FBS0gsUUFBTCxDQUFjeEYsT0FBZCxDQUFzQjtBQUN4QzdILGlCQUFLdkQ7QUFEbUMsV0FBdEIsRUFFakI7QUFDRDRCLHdCQUFZO0FBQ1YsdUJBQVM7QUFEQztBQURYLFdBRmlCLENBQWhCLENBQUo7QUFPQSxjQUFJd1AsYUFBYUwsUUFBUXhLLEtBQXpCLENBUjZCLENBVTdCOztBQUNBLGVBQUssSUFBSUEsS0FBVCxJQUFrQjZLLFVBQWxCLEVBQThCO0FBQzVCRiwyQkFBZTNLLE1BQU1sRCxRQUFyQjtBQUNEO0FBQ0YsU0FqQmdDLENBbUJqQzs7O0FBQ0EyTixtQkFBVy9FLElBQVgsQ0FBZ0JvRixLQUFLQyxLQUFMLENBQVdKLGNBQWNELFdBQVd0RCxHQUFwQyxDQUFoQjtBQUNELE9BdkNxQixDQXlDdEI7OztBQUNBLFVBQUl0SyxXQUFXZ08sS0FBS0UsR0FBTCxDQUFTQyxLQUFULENBQWUsSUFBZixFQUFxQlIsVUFBckIsQ0FBZjtBQUVBLGFBQU8zTixRQUFQO0FBQ0QsS0E3Q0Q7QUFBQTtBQStDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQk1YLFVBQU4sQ0FBZ0I3SCxRQUFoQixFQUEwQnVILEtBQTFCLEVBQWlDQyxTQUFTLElBQTFDLEVBQWdEQyxTQUFTLElBQXpEO0FBQUEsb0NBQStEO0FBQzdEO0FBQ0EsVUFBSXFILFNBQVM1UCxRQUFRaUksSUFBUixDQUFhO0FBQ3hCbkgsa0JBQVVBO0FBRGMsT0FBYixFQUVWNFcsS0FGVSxHQUVGMUksR0FGRSxDQUVHblAsQ0FBRCxJQUFPQSxFQUFFNkIsZ0JBRlgsQ0FBYixDQUY2RCxDQU03RDs7QUFDQSxVQUFJbUIsU0FBUyxFQUFiO0FBQ0FBLGFBQU93RixLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQVl6RixPQUFPOFUsWUFBUCxHQUFzQnJQLE1BQXRCO0FBQ1osVUFBSUMsTUFBSixFQUFZMUYsT0FBTytVLFlBQVAsR0FBc0JyUCxNQUF0QjtBQUVaLFVBQUlsRixvQkFBWSxLQUFLMEgsS0FBTCxDQUFXOE0sVUFBWCxDQUNkaFYsTUFEYyxFQUNOO0FBQ053SixlQUFPO0FBQ0x1RCxrQkFBUTtBQUNOa0ksbUJBQU9sSTtBQUREO0FBREg7QUFERCxPQURNLENBQVosQ0FBSixDQVo2RCxDQXNCN0Q7O0FBQ0EsYUFBT0EsTUFBUDtBQUNELEtBeEJEO0FBQUE7QUEwQkE7Ozs7Ozs7Ozs7QUFRTWhILFlBQU4sQ0FBa0JQLEtBQWxCLEVBQXlCQyxTQUFTLElBQWxDLEVBQXdDQyxTQUFTLElBQWpEO0FBQUEsb0NBQXVEO0FBQ3JEO0FBQ0EsVUFBSTFGLFNBQVMsRUFBYjtBQUNBQSxhQUFPd0YsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFZekYsT0FBTzhVLFlBQVAsR0FBc0JyUCxNQUF0QjtBQUNaLFVBQUlDLE1BQUosRUFBWTFGLE9BQU8rVSxZQUFQLEdBQXNCclAsTUFBdEI7QUFFWixVQUFJbEYsb0JBQVksS0FBSzBILEtBQUwsQ0FBVzhNLFVBQVgsQ0FDZGhWLE1BRGMsRUFDTjtBQUNOdUgsY0FBTTtBQUNKd0Ysa0JBQVE7QUFESjtBQURBLE9BRE0sQ0FBWixDQUFKO0FBT0QsS0FkRDtBQUFBO0FBZ0JBOzs7Ozs7Ozs7Ozs7Ozs7O0FBY01tSSxjQUFOLENBQW9CM08sSUFBcEIsRUFBMEI0TyxPQUExQjtBQUFBLG9DQUFtQztBQUNqQzs7Ozs7Ozs7QUFRQSxVQUFJcEUsTUFBTSxDQUFDO0FBQ1RxRSxlQUFPLE1BREU7QUFFVEMsaUJBQVM5TyxLQUFLK08sUUFGTDtBQUdUSCxpQkFBUztBQUNQSSxpQkFBTztBQURBLFNBSEE7QUFNVGhWLGVBQU87QUFDTHVVLHdCQUFjdk8sS0FBS3VPLFlBRGQ7QUFFTEMsd0JBQWN4TyxLQUFLd087QUFGZDtBQU5FLE9BQUQsRUFXVjtBQUNFSyxlQUFPN08sS0FBS2lQLFdBRGQ7QUFFRUgsaUJBQVM5TyxLQUFLdU8sWUFGaEI7QUFHRUssaUJBQVM7QUFDUEksaUJBQU87QUFEQSxTQUhYO0FBTUVoVixlQUFPO0FBQ0wrVSxvQkFBVS9PLEtBQUsrTyxRQURWO0FBRUxQLHdCQUFjeE8sS0FBS3dPO0FBRmQ7QUFOVCxPQVhVLEVBc0JWO0FBQ0VLLGVBQU83TyxLQUFLa1AsV0FEZDtBQUVFSixpQkFBUzlPLEtBQUt3TyxZQUZoQjtBQUdFSSxpQkFBUztBQUNQSSxpQkFBTztBQURBLFNBSFg7QUFNRWhWLGVBQU87QUFDTCtVLG9CQUFVL08sS0FBSytPLFFBRFY7QUFFTFIsd0JBQWN2TyxLQUFLdU87QUFGZDtBQU5ULE9BdEJVLENBQVY7QUFtQ0EsVUFBSVksUUFBUSxFQUFaOztBQUVBLFdBQUssSUFBSUMsQ0FBVCxJQUFjNUUsR0FBZCxFQUFtQjtBQUNqQjJFLGNBQU1yRyxJQUFOLENBQVc7QUFDVDlGLG9DQUFrQixLQUFLckIsS0FBTCxDQUFXNUMsU0FBWCxDQUNoQixDQUFDO0FBQ0M2QyxvQkFBUWMsT0FBT0MsTUFBUCxDQUFjeU0sRUFBRXBWLEtBQWhCLEVBQXVCO0FBQzdCaUYscUJBQU9lLEtBQUtmO0FBRGlCLGFBQXZCO0FBRFQsV0FBRCxFQUtBO0FBQ0UrQyxzQkFBVVUsT0FBT0MsTUFBUCxDQUFjeU0sRUFBRVIsT0FBaEIsRUFBeUJBLE9BQXpCO0FBRFosV0FMQSxFQVFBO0FBQ0VTLG1CQUFPO0FBQ0xqUCxtQkFBSztBQURBO0FBRFQsV0FSQSxDQURnQixFQWVoQnRCLE9BZmdCLEVBQWxCLENBRFM7QUFpQlR3USxpQkFBT0Y7QUFqQkUsU0FBWDtBQW1CRDs7QUFFRCxXQUFLLElBQUlHLElBQVQsSUFBaUJKLEtBQWpCLEVBQXdCO0FBQ3RCLGFBQUssSUFBSTFZLENBQVQsSUFBYzhZLEtBQUt2TSxVQUFuQixFQUErQjtBQUM3QnZNLFlBQUUyTSxLQUFGLGlCQUFnQixLQUFLakQsUUFBTCxDQUFjMUosRUFBRTJKLEdBQWhCLENBQWhCO0FBQ0Q7QUFDRjs7QUFFRCxhQUFPK08sS0FBUDtBQUNELEtBM0VEO0FBQUEsR0ExSWtDLENBdU5sQztBQUNBOzs7QUFDTS9KLGVBQU4sQ0FBcUJpQixHQUFyQjtBQUFBLG9DQUEwQjtBQUN4QixVQUFJckcsSUFBSixDQUR3QixDQUV4Qjs7QUFDQSxVQUFJLE9BQU9xRyxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0IsWUFBSW1KLE1BQU0sSUFBSUMsTUFBSixDQUFZLEdBQUVwSixHQUFJLEdBQWxCLENBQVY7QUFDQSxZQUFJM0UsTUFBTSxLQUFLQyxLQUFMLENBQVc5QyxJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQzVCSixzQkFBWTtBQUNWUSxtQkFBTyxDQURHO0FBRVZzUCwwQkFBYyxDQUZKO0FBR1ZDLDBCQUFjO0FBSEo7QUFEZ0IsU0FBcEIsQ0FBVjs7QUFRQSxlQUFPLENBQVAsRUFBVTtBQUNSLGNBQUk7QUFDRnhPLGlDQUFhMEIsSUFBSXlCLElBQUosRUFBYjtBQUNBLGdCQUFJdU0sc0JBQWMxUCxLQUFLSSxHQUFMLENBQVN1UCxXQUFULEdBQXVCRCxLQUF2QixDQUE2QkYsR0FBN0IsQ0FBZCxDQUFKOztBQUNBLGdCQUFJRSxLQUFKLEVBQVc7QUFDVDtBQUNEO0FBQ0YsV0FORCxDQU1FLE9BQU9oVCxDQUFQLEVBQVU7QUFDVjtBQUNBZ0YsZ0JBQUkyQixLQUFKO0FBQ0EsbUJBQU9nRCxHQUFQO0FBQ0Q7QUFDRjs7QUFDRDNFLFlBQUkyQixLQUFKO0FBQ0QsT0F4QkQsTUF3Qk87QUFDTHJELGVBQU9xRyxHQUFQO0FBQ0Q7O0FBRUQsVUFBSXVKLGFBQWEsRUFBakI7QUFDQSxVQUFJNVAsS0FBS2YsS0FBVCxFQUFnQjJRLFdBQVc5RyxJQUFYLENBQWdCOUksS0FBS2YsS0FBckI7QUFDaEIsVUFBSWUsS0FBS3VPLFlBQVQsRUFBdUJxQixXQUFXOUcsSUFBWCxDQUFnQjlJLEtBQUt1TyxZQUFyQjtBQUN2QixVQUFJdk8sS0FBS3dPLFlBQVQsRUFBdUJvQixXQUFXOUcsSUFBWCxDQUFnQjlJLEtBQUt3TyxZQUFyQjtBQUN2QixhQUFPb0IsV0FBVy9KLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBUDtBQUNELEtBcENEO0FBQUE7O0FBc0NNbEYsa0JBQU4sQ0FBd0JzSixTQUF4QixFQUFtQ2pLLElBQW5DO0FBQUEsb0NBQXlDO0FBQ3ZDO0FBQ0EsVUFBSTZQLFlBQWFkLFFBQUQsSUFBY0EsYUFBYSxRQUFiLEdBQXdCLE9BQXhCLEdBQWtDQSxRQUFoRSxDQUZ1QyxDQUl2Qzs7O0FBQ0EsVUFBSXRFLFlBQVksSUFBaEI7QUFDQSxVQUFJbUYsYUFBYSxFQUFqQixDQU51QyxDQVF2QztBQUNBOztBQUNBLFVBQUk1UCxLQUFLZixLQUFULEVBQWdCMlEsV0FBVzlHLElBQVgsQ0FBZ0I5SSxLQUFLZixLQUFyQjtBQUNoQixVQUFJZSxLQUFLdU8sWUFBVCxFQUF1QnFCLFdBQVc5RyxJQUFYLENBQWdCOUksS0FBS3VPLFlBQXJCO0FBQ3ZCLFVBQUl2TyxLQUFLd08sWUFBVCxFQUF1Qm9CLFdBQVc5RyxJQUFYLENBQWdCOUksS0FBS3dPLFlBQXJCLEVBWmdCLENBY3ZDOztBQUNBLFVBQUlzQixhQUFKOztBQUNBLGNBQVE5UCxLQUFLK08sUUFBYjtBQUNFLGFBQUssS0FBTDtBQUNFZSwwQkFBZ0IsQ0FBaEI7QUFDQTs7QUFDRixhQUFLLFFBQUw7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7O0FBQ0Y7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7QUFUSixPQWhCdUMsQ0E0QnZDOzs7QUFDQSxVQUFJdkYsT0FBTyxFQUFYOztBQUNBLGNBQVF2SyxLQUFLK08sUUFBYjtBQUNFLGFBQUssS0FBTDtBQUNFeEUsZUFBS3pCLElBQUwsQ0FBVTtBQUNSelAsaUJBQUssQ0FERztBQUVSbVIsaUJBQUs7QUFGRyxXQUFWLEVBR0c7QUFDRG5SLGlCQUFLLENBREo7QUFFRG1SLGlCQUFLO0FBRkosV0FISDtBQU9BOztBQUNGLGFBQUssUUFBTDtBQUNFRCxlQUFLekIsSUFBTCxDQUFVO0FBQ1J6UCxpQkFBSyxDQURHO0FBRVJtUixpQkFBSztBQUZHLFdBQVYsRUFHRztBQUNEblIsaUJBQUssQ0FESjtBQUVEbVIsaUJBQUs7QUFGSixXQUhIO0FBT0E7QUFsQkosT0E5QnVDLENBbUR2Qzs7O0FBQ0EsVUFBSXVGLGNBQWMsSUFBbEI7O0FBQ0EsY0FBUS9QLEtBQUsrTyxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VnQix3QkFBYyxJQUFkO0FBQ0E7O0FBQ0YsYUFBSyxRQUFMO0FBQ0VBLHdCQUFjLEdBQWQ7QUFDQTtBQU5KLE9BckR1QyxDQThEdkM7QUFDQTtBQUNBOzs7QUFFQSxVQUFJWixzQkFBYyxLQUFLUixZQUFMLENBQWtCM08sSUFBbEIsRUFBd0I7QUFDeENtSyxvQkFBWTtBQUQ0QixPQUF4QixDQUFkLENBQUosQ0FsRXVDLENBc0V2QztBQUVBOztBQUNBZ0YsY0FBUUEsTUFBTXZKLEdBQU4sQ0FDTDJKLElBQUQsSUFBVTtBQUNSQSxhQUFLRCxLQUFMLENBQVdSLE9BQVgsR0FBcUJlLFVBQVVOLEtBQUtELEtBQUwsQ0FBV1IsT0FBckIsQ0FBckI7QUFDQVMsYUFBS3ZNLFVBQUwsR0FBa0J1TSxLQUFLdk0sVUFBTCxDQUFnQjRDLEdBQWhCLENBQ2ZvSyxTQUFELElBQWU7QUFDYkEsb0JBQVVoQixLQUFWLEdBQWtCYSxVQUFVRyxVQUFVaEIsS0FBcEIsQ0FBbEI7QUFDQSxpQkFBT2dCLFNBQVA7QUFDRCxTQUplLENBQWxCO0FBTUEsZUFBT1QsSUFBUDtBQUNELE9BVkssQ0FBUixDQXpFdUMsQ0FzRnZDOztBQUNBLFVBQUlVLGdCQUNGZCxNQUFNdkosR0FBTixDQUNHMkosSUFBRCxJQUNFLGtDQUNELG1CQURDLEdBRUQsaUVBRkMsR0FHRCxXQUFVQSxLQUFLRCxLQUFMLENBQVdULEtBQU0sV0FIMUIsR0FJRCxRQUpDLEdBS0ZVLEtBQUt2TSxVQUFMLENBQWdCNEMsR0FBaEIsQ0FDR29LLFNBQUQsSUFBZTtBQUNiLFlBQUlULEtBQUtELEtBQUwsQ0FBV1IsT0FBWCxLQUF1QmtCLFVBQVVoQixLQUFyQyxFQUE0QztBQUMxQztBQUNBLGlCQUFRLHdFQUF1RWdCLFVBQVVoQixLQUFNLG9CQUEvRjtBQUNELFNBSEQsTUFJQSxJQUFJZ0IsVUFBVTVNLEtBQVYsR0FBa0IsQ0FBdEIsRUFBeUI7QUFDdkI7QUFDQSxpQkFBUSw2QkFBNEI0TSxVQUFVN0YsVUFBVyxrRUFBaUU2RixVQUFVaEIsS0FBTSxlQUExSTtBQUNELFNBSEQsTUFHTztBQUNMO0FBQ0EsaUJBQVEsNEhBQTJIZ0IsVUFBVWhCLEtBQU0sV0FBbko7QUFDRDtBQUNGLE9BYkgsRUFjRW5KLElBZEYsQ0FjTyxFQWRQLENBTEUsR0FvQkYsUUFwQkUsR0FxQkYsUUF2QkYsRUF3QkVBLElBeEJGLENBd0JPLEVBeEJQLENBREY7QUEyQkEsVUFBSXFLLG9CQUFxQjs7TUFFdkJELGFBQWM7S0FGaEIsQ0FsSHVDLENBdUh2Qzs7QUFDQSxVQUFJcFksT0FBTztBQUNUc1Msb0JBQVlNLFNBREg7QUFFVDdKLG9CQUFZcUosU0FGSDtBQUdUNVIsY0FBTyxHQUFFdVgsV0FBVy9KLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBcUIsSUFBR2dLLFVBQVU3UCxLQUFLK08sUUFBZixDQUF5QixJQUFHL08sS0FBSzNILElBQUssSUFBRzJILEtBQUttUSxRQUFTLEVBSC9FO0FBSVRDLDRCQUFvQkYsaUJBSlg7QUFLVC9FLG1CQUFXbkwsS0FBS3FRLFdBQUwsR0FBbUIsR0FMckI7QUFNVEMsc0JBQWNWLFdBQVcvSixJQUFYLENBQWdCLEdBQWhCLENBTkw7QUFPVDBLLGlCQUFTdlEsS0FBS3dRLFlBUEw7QUFRVEMsaUJBQVN6USxLQUFLMFEsV0FBTCxHQUFtQixJQVJuQjtBQVF5QjtBQUNsQ2xLLGdCQUFReEcsS0FBS3dHLE1BVEo7QUFVVG1LLHlCQUFpQmIsYUFWUjtBQVdUdkYsY0FBTUEsSUFYRztBQVlUcUcsc0JBQWNiO0FBWkwsT0FBWDtBQWVBck4sYUFBT0MsTUFBUCxDQUFjOUssSUFBZCxFQUFvQm1JLEtBQUtNLElBQUwsQ0FBVUMsV0FBOUI7QUFFQSxhQUFPMUksSUFBUDtBQUNELEtBMUlEO0FBQUEsR0EvUGtDLENBMllsQzs7O0FBQ011UCxrQkFBTixDQUF3QnlKLEdBQXhCLEVBQTZCN1EsSUFBN0I7QUFBQSxvQ0FBbUM7QUFDakMsWUFBTThRLFdBQVcsRUFBakI7QUFDQSxZQUFNQyxjQUFjLEdBQXBCO0FBRUEsVUFBSXpLLFFBQVEsRUFBWixDQUppQyxDQUtqQzs7QUFDQUEsY0FBUTFOLEtBQUtnSyxLQUFMLENBQVdoSyxLQUFLQyxTQUFMLENBQWVnWSxJQUFJN1EsS0FBSytPLFFBQVQsQ0FBZixDQUFYLENBQVIsQ0FOaUMsQ0FRakM7O0FBQ0EsWUFBTWlDLFlBQVksSUFBbEI7O0FBQ0EsV0FBSyxJQUFJdEcsSUFBSSxDQUFiLEVBQWdCQSxJQUFJMUssS0FBS3dHLE1BQUwsQ0FBWW1FLE1BQWhDLEVBQXdDRCxHQUF4QyxFQUE2QztBQUMzQ3BFLGNBQU0wSyxhQUFhdEcsSUFBSSxDQUFqQixDQUFOLElBQTZCMUssS0FBS3dHLE1BQUwsQ0FBWWtFLENBQVosQ0FBN0I7QUFDRCxPQVpnQyxDQWNqQzs7O0FBQ0FwRSxZQUFNLE1BQU4sSUFBZ0J0RyxLQUFLTSxJQUFMLENBQVVnRyxLQUFWLENBQWdCMkssUUFBaEM7QUFDQTNLLFlBQU0sTUFBTixJQUFnQmtILFNBQVMwRCxPQUFULENBQWtCLEdBQUQsY0FBUyxLQUFLOUwsYUFBTCxDQUFtQnBGLElBQW5CLENBQVQsQ0FBa0MsSUFBR0EsS0FBSytPLFFBQVMsSUFBRy9PLEtBQUszSCxJQUFLLEVBQWpGLEVBQW9GMFksV0FBcEYsQ0FBaEI7QUFDQXpLLFlBQU0sTUFBTixJQUFnQnRHLEtBQUswUSxXQUFyQjtBQUNBcEssWUFBTSxNQUFOLElBQWdCdEcsS0FBSzBRLFdBQXJCO0FBQ0FwSyxZQUFNLE1BQU4sSUFBZ0J0RyxLQUFLSSxHQUFMLENBQVN1UCxXQUFULEdBQXVCM0osS0FBdkIsQ0FBNkIsQ0FBQzhLLFFBQTlCLENBQWhCO0FBQ0F4SyxZQUFNLElBQU4sSUFBY3RHLEtBQUtxUSxXQUFuQjtBQUNBL0osWUFBTSxnQkFBTixJQUEwQnRHLEtBQUttUSxRQUEvQjtBQUVBLGFBQU83SixLQUFQO0FBQ0QsS0F4QkQ7QUFBQTs7QUE1WWtDLEM7Ozs7Ozs7Ozs7O0FDWHBDalEsT0FBT2lSLE1BQVAsQ0FBYztBQUFDOVEsV0FBUSxNQUFJZ0w7QUFBYixDQUFkO0FBQXNDLElBQUlELE9BQUo7QUFBWWxMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxpQkFBUixDQUFiLEVBQXdDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDOEssY0FBUTlLLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSTBhLFFBQUo7QUFBYTlhLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQzRhLFdBQVMxYSxDQUFULEVBQVc7QUFBQzBhLGVBQVMxYSxDQUFUO0FBQVc7O0FBQXhCLENBQS9CLEVBQXlELENBQXpEO0FBQTRELElBQUlnTCxTQUFKO0FBQWNwTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDZ0wsZ0JBQVVoTCxDQUFWO0FBQVk7O0FBQXhCLENBQXRDLEVBQWdFLENBQWhFO0FBSTVNLE1BQU0yYSxXQUFXLHdDQUFqQjs7QUFFZSxNQUFNNVAsUUFBTixDQUFlO0FBQzVCdUcsY0FBYXZKLElBQWIsRUFBbUIyRCxNQUFuQixFQUEyQjtBQUN6QixTQUFLM0QsSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBSzJELE1BQUwsR0FBY0EsTUFBZDtBQUNELEdBSjJCLENBTTVCOzs7QUFDTUksWUFBTixDQUFrQkEsVUFBbEI7QUFBQSxvQ0FBOEI7QUFDNUIsVUFBSWhCLFVBQVcsb0JBQW1CLEtBQUtZLE1BQU8sd0JBQXVCZ1AsU0FBUzVPLFVBQVQsRUFBcUI7QUFBQ3VLLGlCQUFTO0FBQVYsT0FBckIsQ0FBc0MseUJBQTNHOztBQUNBLFVBQUk7QUFDRixZQUFJN1Msb0JBQVksS0FBS29YLFdBQUwsQ0FDZCxnQkFEYyxFQUVkOVAsT0FGYyxDQUFaLENBQUo7QUFJQSxlQUFPO0FBQUNrQixvQkFBVXhJLEdBQVg7QUFBZ0JxWCxzQkFBWS9QO0FBQTVCLFNBQVA7QUFDRCxPQU5ELENBTUUsT0FBTzdFLENBQVAsRUFBVTtBQUNWLGNBQU1nRyxPQUFPQyxNQUFQLENBQWNsQixVQUFVbUIsS0FBVixDQUFnQmxHLENBQWhCLENBQWQsRUFBa0M7QUFBQzRVLHNCQUFZL1A7QUFBYixTQUFsQyxDQUFOO0FBQ0Q7QUFDRixLQVhEO0FBQUE7O0FBYU04UCxhQUFOLENBQW1CRSxNQUFuQixFQUEyQnRaLElBQTNCO0FBQUEsb0NBQWlDO0FBQy9CO0FBQ0EsVUFBSXVaLGFBQWE7QUFDZkQsZ0JBQVEsTUFETztBQUVmM04sYUFBTSxHQUFFd04sUUFBUyxJQUFHRyxNQUFPLEVBRlo7QUFHZnRaLGNBQU1BLElBSFMsQ0FLakI7O0FBTGlCLE9BQWpCO0FBTUF5SyxhQUFPQyxNQUFQLENBQWM2TyxVQUFkLEVBQTBCLEtBQUtoVCxJQUEvQixFQVIrQixDQVUvQjs7QUFDQSxVQUFJdkUsb0JBQVlzSCxRQUFRaVEsVUFBUixDQUFaLENBQUo7QUFFQSxhQUFPdlgsR0FBUDtBQUNELEtBZEQ7QUFBQTs7QUFnQk1vRyxhQUFOLENBQW1Cb1IsZUFBbkI7QUFBQSxvQ0FBb0M7QUFDbEM7QUFDQSxVQUFJRCxhQUFhO0FBQ2ZELGdCQUFRLE1BRE87QUFFZjNOLGFBQU0sR0FBRXdOLFFBQVMsY0FGRixDQUlqQjs7QUFKaUIsT0FBakI7QUFLQTFPLGFBQU9DLE1BQVAsQ0FBYzZPLFVBQWQsRUFBMEIsS0FBS2hULElBQS9CO0FBRUFnVCxpQkFBV3ZaLElBQVgsaUJBQXdCLEtBQUt5Wiw0QkFBTCxDQUFrQ0QsZUFBbEMsQ0FBeEIsRUFUa0MsQ0FXbEM7O0FBQ0EsVUFBSXhYLG9CQUFZc0gsUUFBUWlRLFVBQVIsQ0FBWixDQUFKO0FBRUEsYUFBT3ZYLEdBQVA7QUFDRCxLQWZEO0FBQUE7O0FBaUJNeVgsOEJBQU4sQ0FBb0NELGVBQXBDO0FBQUEsb0NBQXFEO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxVQUFJRSxxQkFBcUIsRUFBekI7O0FBRUEsV0FBSyxJQUFJM1IsSUFBVCxJQUFpQnlSLGVBQWpCLEVBQWtDO0FBQ2hDO0FBQ0EsYUFBSyxJQUFJL1UsQ0FBVCxJQUFjc0QsS0FBS2dELFVBQW5CLEVBQStCO0FBQzdCO0FBQ0EsY0FBSXRHLEVBQUUwRyxLQUFGLEdBQVUsR0FBZCxFQUFtQjFHLEVBQUUwRyxLQUFGLEdBQVUsR0FBVjtBQUNwQjs7QUFFRHVPLDhCQUFzQixtQkFBdEI7QUFDQUEsOEJBQXVCLGFBQVkzUixLQUFLaUMsUUFBUyxhQUFqRCxDQVJnQyxDQVVoQztBQUNBO0FBQ0E7O0FBRUEsWUFBSTJQLE9BQU81UixLQUFLZ0QsVUFBTCxDQUFnQixDQUFoQixDQUFYOztBQUNBLFlBQUk0TyxLQUFLL08sMEJBQUwsS0FBb0MsRUFBcEMsSUFBMEMrTyxLQUFLOU8sd0JBQUwsS0FBa0MsRUFBaEYsRUFBb0Y7QUFDbEY7QUFDQTZPLGdDQUFzQixnQ0FBdEI7QUFDQUEsZ0NBQXVCLGVBQWNDLEtBQUt4TyxLQUFNLGVBQWhEO0FBQ0QsU0FKRCxNQUlPO0FBQ0w7QUFDQXVPLGdDQUFzQixnQ0FBdEIsQ0FGSyxDQUlMOztBQUNBLGVBQUssSUFBSTNCLFNBQVQsSUFBc0JoUSxLQUFLZ0QsVUFBM0IsRUFBdUM7QUFDckM7QUFDQWdOLHNCQUFVNkIsaUJBQVYsR0FBOEI3QixVQUFVNU0sS0FBeEM7QUFDQSxtQkFBTzRNLFVBQVU1TSxLQUFqQixDQUhxQyxDQUtyQzs7QUFDQXVPLGtDQUFzQixpQkFBdEI7O0FBQ0EsaUJBQUssSUFBSXRJLEdBQVQsSUFBZ0IzRyxPQUFPcUksSUFBUCxDQUFZaUYsU0FBWixDQUFoQixFQUF3QztBQUN0QzJCLG9DQUF1QixJQUFHdEksR0FBSSxJQUFHMkcsVUFBVTNHLEdBQVYsQ0FBZSxLQUFJQSxHQUFJLEdBQXhEO0FBQ0Q7O0FBQ0RzSSxrQ0FBc0Isa0JBQXRCO0FBQ0Q7QUFDRjs7QUFFREEsOEJBQXNCLG9CQUF0QjtBQUNELE9BekRrRCxDQTJEbkQ7OztBQUNBLFVBQUlHLGlCQUFrQjs7Y0FFWixLQUFLM1AsTUFBTztNQUNwQndQLGtCQUFtQjs7S0FIckIsQ0E1RG1ELENBbUVuRDs7QUFDQSxhQUFPRyxjQUFQO0FBQ0QsS0FyRUQ7QUFBQTs7QUFyRDRCLEM7Ozs7Ozs7Ozs7O0FDTjlCemIsT0FBT2lSLE1BQVAsQ0FBYztBQUFDOVEsV0FBUSxNQUFJaUw7QUFBYixDQUFkOztBQUFlLE1BQU1BLFNBQU4sQ0FBZ0I7QUFDN0IsU0FBT21CLEtBQVAsQ0FBY2xHLENBQWQsRUFBaUI7QUFDZixRQUFJekMsTUFBTSxFQUFWOztBQUVBLFFBQUl5QyxhQUFhZ00sS0FBakIsRUFBd0I7QUFDdEJ6TyxVQUFJOFgsT0FBSixHQUFjclYsRUFBRXFWLE9BQWhCO0FBQ0E5WCxVQUFJNUIsSUFBSixHQUFXcUUsRUFBRXJFLElBQWI7QUFDQTRCLFVBQUkrWCxRQUFKLEdBQWV0VixFQUFFc1YsUUFBakI7QUFDQS9YLFVBQUlnWSxVQUFKLEdBQWlCdlYsRUFBRXVWLFVBQW5CO0FBQ0FoWSxVQUFJaVksWUFBSixHQUFtQnhWLEVBQUV3VixZQUFyQjtBQUNBalksVUFBSWtZLEtBQUosR0FBWXpWLEVBQUV5VixLQUFkO0FBQ0QsS0FQRCxNQU9PO0FBQ0xsWSxZQUFNeUMsQ0FBTjtBQUNEOztBQUVELFdBQU96QyxHQUFQO0FBQ0Q7O0FBaEI0QixDOzs7Ozs7Ozs7OztBQ0EvQjVELE9BQU9pUixNQUFQLENBQWM7QUFBQy9JLG1CQUFnQixNQUFJQTtBQUFyQixDQUFkO0FBQXFELElBQUlxTixXQUFKO0FBQWdCdlYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDcVYsY0FBWW5WLENBQVosRUFBYztBQUFDbVYsa0JBQVluVixDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFOztBQUU5RCxNQUFNOEgsZUFBTixDQUFzQjtBQUMzQixTQUFhSSxHQUFiLENBQWtCSCxJQUFsQixFQUF3QkksVUFBeEI7QUFBQSxvQ0FBb0M7QUFDbEMsVUFBSThOLHVCQUFlZCxZQUFZZSxPQUFaLENBQW9Cbk8sS0FBS29GLEdBQXpCLENBQWYsQ0FBSjtBQUNBLFVBQUl0RixLQUFLb08sT0FBT3BPLEVBQVAsQ0FBVUUsS0FBS29PLFFBQWYsQ0FBVDtBQUNBLGFBQU90TyxHQUFHTSxVQUFILENBQWNBLFVBQWQsQ0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFEMkIsQzs7Ozs7Ozs7Ozs7QUNGN0J2SSxPQUFPaVIsTUFBUCxDQUFjO0FBQUM5USxXQUFRLE1BQUl3QztBQUFiLENBQWQ7QUFBbUMsSUFBSW9QLEtBQUo7QUFBVS9SLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxPQUFSLENBQWIsRUFBOEI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMyUixZQUFNM1IsQ0FBTjtBQUFROztBQUFwQixDQUE5QixFQUFvRCxDQUFwRDtBQUF1RCxJQUFJMmIsTUFBSjtBQUFXL2IsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzJiLGFBQU8zYixDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREOztBQUdoRyxNQUFNdUMsS0FBTixDQUFZO0FBQ3pCK08sY0FBYTFKLE9BQWIsRUFBc0I7QUFDcEI7QUFDQSxTQUFLZ1UsSUFBTCxHQUFZakssTUFBTWtLLFVBQU4sQ0FBaUJqVSxPQUFqQixDQUFaLENBRm9CLENBSXBCOztBQUNBLFFBQUlrVSxlQUFlO0FBQUNDLDBCQUFvQjtBQUFyQixLQUFuQjtBQUNBOVAsV0FBT0MsTUFBUCxDQUFjNFAsWUFBZCxFQUE0QmxVLE9BQTVCO0FBQ0EsU0FBS29VLFNBQUwsR0FBaUJySyxNQUFNa0ssVUFBTixDQUFpQkMsWUFBakIsQ0FBakI7QUFDRDs7QUFFRCxTQUFPRyxVQUFQLENBQW1CQyxJQUFuQixFQUF5QjtBQUN2QixXQUFPUCxPQUFPTyxJQUFQLEVBQWFDLE1BQWIsR0FBc0IxVixTQUF0QixDQUFnQyxDQUFoQyxFQUFtQyxFQUFuQyxFQUF1QzJWLE9BQXZDLENBQStDLEdBQS9DLEVBQW9ELEdBQXBELENBQVA7QUFDRDtBQUVEOzs7Ozs7QUFJQTdZLFFBQU9LLEdBQVAsRUFBWTtBQUNWO0FBQ0E7QUFDQSxXQUFPLEtBQUt5WSxNQUFMLEdBQ0pDLElBREksQ0FFRkMsR0FBRCxJQUFTO0FBQ1AsYUFBTyxJQUFJMUosT0FBSixDQUNMLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUNuQjtBQUNBd0osWUFBSWhaLEtBQUosQ0FBVUssR0FBVixFQUFlLENBQUNxQyxDQUFELEVBQUl6QyxHQUFKLEtBQVk7QUFDekI7QUFDQStZLGNBQUlDLE9BQUo7O0FBQ0EsY0FBSXZXLENBQUosRUFBTztBQUNMOE0sbUJBQU85TSxDQUFQO0FBQ0QsV0FGRCxNQUVPNk0sUUFBUXRQLEdBQVI7QUFDUixTQU5EO0FBT0QsT0FWSSxDQUFQO0FBWUQsS0FmRSxFQWlCSjBQLEtBakJJLENBaUJHak4sQ0FBRCxJQUFPO0FBQ1osWUFBTUEsQ0FBTjtBQUNELEtBbkJJLENBQVA7QUFvQkQ7O0FBRUt3VyxjQUFOLENBQW9CN1ksR0FBcEI7QUFBQSxvQ0FBeUI7QUFDdkIsVUFBSUosb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9KLElBQUlrWixRQUFYO0FBQ0QsS0FIRDtBQUFBO0FBS0E7Ozs7Ozs7O0FBTU0xVyxhQUFOLENBQW1CK0wsS0FBbkIsRUFBMEIzUSxPQUFPLEVBQWpDLEVBQXFDdWIsVUFBVSxFQUEvQztBQUFBLG9DQUFtRDtBQUNqRDtBQUNBO0FBRUEsVUFBSS9ZLE1BQU8sZUFBY21PLEtBQU0sR0FBL0I7QUFFQSxVQUFJNUMsTUFBTSxJQUFJeU4sR0FBSixFQUFWOztBQUNBLFdBQUssSUFBSXJJLENBQVQsSUFBY3RJLE9BQU9xSSxJQUFQLENBQVlsVCxJQUFaLENBQWQsRUFBaUM7QUFDL0IsWUFBSUEsS0FBS21ULENBQUwsTUFBWSxJQUFoQixFQUFzQjtBQUNwQnBGLGNBQUk0RSxHQUFKLENBQVFRLENBQVIsRUFBVyxNQUFYO0FBQ0QsU0FGRCxNQUVPLElBQUluVCxLQUFLbVQsQ0FBTCxFQUFRakQsV0FBUixDQUFvQjFQLElBQXBCLEtBQTZCLE1BQWpDLEVBQXlDO0FBQzlDO0FBQ0F1TixjQUFJNEUsR0FBSixDQUFRUSxDQUFSLEVBQVksSUFBR2hTLE1BQU0wWixVQUFOLENBQWlCN2EsS0FBS21ULENBQUwsQ0FBakIsQ0FBMEIsR0FBekM7QUFDRCxTQUhNLE1BR0E7QUFDTHBGLGNBQUk0RSxHQUFKLENBQVFRLENBQVIsRUFBWSxHQUFFNUMsTUFBTWtMLE1BQU4sQ0FBYXpiLEtBQUttVCxDQUFMLENBQWIsQ0FBc0IsRUFBcEM7QUFDRDtBQUNGOztBQUNELFdBQUssSUFBSUEsQ0FBVCxJQUFjdEksT0FBT3FJLElBQVAsQ0FBWXFJLE9BQVosQ0FBZCxFQUFvQztBQUNsQ3hOLFlBQUk0RSxHQUFKLENBQVFRLENBQVIsRUFBV29JLFFBQVFwSSxDQUFSLE1BQWUsSUFBZixHQUFzQixNQUF0QixHQUErQm9JLFFBQVFwSSxDQUFSLENBQTFDO0FBQ0Q7O0FBRUQzUSxhQUFRLEtBQUksQ0FBQyxHQUFHdUwsSUFBSW1GLElBQUosRUFBSixFQUFnQmxGLElBQWhCLENBQXFCLEdBQXJCLENBQTBCLEtBQXRDO0FBRUF4TCxhQUFRLFdBQVUsQ0FBQyxHQUFHdUwsSUFBSTJOLE1BQUosRUFBSixFQUFrQjFOLElBQWxCLENBQXVCLEdBQXZCLENBQTRCLEtBQTlDO0FBRUEsVUFBSTVMLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPSixJQUFJa1osUUFBWDtBQUNELEtBM0JEO0FBQUE7QUE2QkE7Ozs7Ozs7OztBQU9NcEosYUFBTixDQUFtQnZCLEtBQW5CLEVBQTBCL08sTUFBMUIsRUFBa0M1QixJQUFsQyxFQUF3Q3ViLE9BQXhDO0FBQUEsb0NBQWlEO0FBQy9DLFVBQUkvWSxNQUFPLFVBQVNtTyxLQUFNLE9BQTFCO0FBRUEsVUFBSWdMLFVBQVUsRUFBZDs7QUFDQSxXQUFLLElBQUl4SSxDQUFULElBQWN0SSxPQUFPcUksSUFBUCxDQUFZbFQsSUFBWixDQUFkLEVBQWlDO0FBQy9CMmIsZ0JBQVExSyxJQUFSLENBQWMsR0FBRWtDLENBQUUsSUFBRzVDLE1BQU1rTCxNQUFOLENBQWF6YixLQUFLbVQsQ0FBTCxDQUFiLENBQXNCLEVBQTNDO0FBQ0Q7O0FBQ0QsV0FBSyxJQUFJQSxDQUFULElBQWN0SSxPQUFPcUksSUFBUCxDQUFZcUksT0FBWixDQUFkLEVBQW9DO0FBQ2xDSSxnQkFBUTFLLElBQVIsQ0FBYyxHQUFFa0MsQ0FBRSxJQUFHb0ksUUFBUXBJLENBQVIsQ0FBVyxFQUFoQztBQUNEOztBQUNEM1EsYUFBT21aLFFBQVEzTixJQUFSLENBQWEsR0FBYixDQUFQO0FBRUF4TCxhQUFRLFVBQVNaLE1BQU8sR0FBeEI7QUFFQSxVQUFJUSxvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT0osR0FBUDtBQUNELEtBaEJEO0FBQUEsR0EzRnlCLENBNkd6Qjs7O0FBQ013WixZQUFOLENBQWtCcFosR0FBbEI7QUFBQSxvQ0FBdUI7QUFDckIsVUFBSXFaLFdBQVcsS0FBS3JCLElBQXBCO0FBQ0EsV0FBS0EsSUFBTCxHQUFZLEtBQUtJLFNBQWpCOztBQUNBLFVBQUk7QUFDRixZQUFJeFksb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGVBQU9KLEdBQVA7QUFDRCxPQUhELFNBR1U7QUFDUixhQUFLb1ksSUFBTCxHQUFZcUIsUUFBWjtBQUNEO0FBQ0YsS0FURDtBQUFBOztBQVdNQyxrQkFBTjtBQUFBLG9DQUEwQjtBQUN4QixvQkFBTSxLQUFLM1osS0FBTCxDQUFZLG9CQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSU00WixRQUFOO0FBQUEsb0NBQWdCO0FBQ2Qsb0JBQU0sS0FBSzVaLEtBQUwsQ0FBWSxTQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSU02WixVQUFOO0FBQUEsb0NBQWtCO0FBQ2hCLG9CQUFNLEtBQUs3WixLQUFMLENBQVksV0FBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlBeU8saUJBQWdCcE8sR0FBaEIsRUFBcUJpTyxXQUFZbE8sTUFBRCxJQUFZLENBQUUsQ0FBOUMsRUFBZ0RtTyxVQUFXN0wsQ0FBRCxJQUFPLENBQUUsQ0FBbkUsRUFBcUU7QUFDbkUsV0FBTyxLQUFLb1csTUFBTCxHQUNKQyxJQURJLENBRUZDLEdBQUQsSUFBUztBQUNQLGFBQU8sSUFBSTFKLE9BQUosQ0FDTCxDQUFPQyxPQUFQLEVBQWdCQyxNQUFoQiw4QkFBMkI7QUFDekI7QUFDQXdKLFlBQUloWixLQUFKLENBQVVLLEdBQVYsRUFDR3laLEVBREgsQ0FDTSxRQUROLEVBRUsxWixNQUFELElBQVk7QUFDVjRZLGNBQUllLEtBQUo7QUFDQXpMLG1CQUFTbE8sTUFBVDtBQUNBNFksY0FBSWdCLE1BQUo7QUFDRCxTQU5MLEVBT0dGLEVBUEgsQ0FPTSxPQVBOLEVBT2dCcFgsQ0FBRCxJQUFPO0FBQ2xCNkwsa0JBQVE3TCxDQUFSO0FBQ0QsU0FUSCxFQVVHb1gsRUFWSCxDQVVNLEtBVk4sRUFVYSxNQUFNO0FBQ2ZkLGNBQUlDLE9BQUo7QUFDQTFKO0FBQ0QsU0FiSDtBQWNELE9BaEJELENBREssQ0FBUDtBQW1CRCxLQXRCRSxFQXdCSkksS0F4QkksQ0F3QkdqTixDQUFELElBQU87QUFDWixZQUFNQSxDQUFOO0FBQ0QsS0ExQkksQ0FBUDtBQTJCRDs7QUFFRG9XLFdBQVU7QUFDUixXQUFPLElBQUl4SixPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ25CO0FBQ0EsV0FBSzZJLElBQUwsQ0FBVTRCLGFBQVYsQ0FBd0IsQ0FBQ3ZYLENBQUQsRUFBSXNXLEdBQUosS0FBWTtBQUNsQyxZQUFJdFcsQ0FBSixFQUFPO0FBQ0w4TSxpQkFBTzlNLENBQVA7QUFDRCxTQUZELE1BRU87QUFDTDZNLGtCQUFReUosR0FBUjtBQUNEO0FBQ0YsT0FORDtBQU9ELEtBVkksRUFZSnJKLEtBWkksQ0FhRmpOLENBQUQsSUFBTztBQUNMLFlBQU1BLENBQU47QUFDRCxLQWZFLENBQVA7QUFpQkQ7O0FBckx3QixDOzs7Ozs7Ozs7OztBQ0gzQnJHLE9BQU9pUixNQUFQLENBQWM7QUFBQzlRLFdBQVEsTUFBSXlOO0FBQWIsQ0FBZDs7QUFBZSxNQUFNQSxNQUFOLENBQWE7QUFDMUI4RCxjQUFheEMsVUFBYixFQUF5QjtBQUN2QixTQUFLQSxVQUFMLEdBQWtCQSxVQUFsQjtBQUNBLFNBQUtPLGFBQUwsR0FBcUIsSUFBckI7QUFDQSxTQUFLTSxRQUFMLEdBQWdCLElBQWhCO0FBQ0EsU0FBS1MsV0FBTCxHQUFtQixJQUFuQjtBQUNBLFNBQUtrQyxLQUFMLEdBQWEsQ0FBYjtBQUNBLFNBQUtoRCxXQUFMLEdBQW1CLENBQW5CO0FBQ0Q7O0FBRUtzQixRQUFOLENBQWNoQixHQUFkO0FBQUEsb0NBQW1CO0FBQ2pCO0FBQ0EsVUFBSSxLQUFLMEMsS0FBTCxHQUFhLEtBQUt4RCxVQUFsQixLQUFpQyxDQUFyQyxFQUF3QztBQUN0QyxZQUFJLEtBQUtPLGFBQVQsRUFBd0I7QUFDdEIsd0JBQU0sS0FBS0EsYUFBTCxDQUFtQixLQUFLQyxXQUF4QixDQUFOO0FBQ0Q7QUFDRjs7QUFDRCxVQUFJLEtBQUtLLFFBQVQsRUFBbUI7QUFDakIsc0JBQU0sS0FBS0EsUUFBTCxDQUFjQyxHQUFkLENBQU47QUFDRDs7QUFDRCxXQUFLMEMsS0FBTCxHQVZpQixDQVdqQjs7QUFDQSxVQUFJLEtBQUtBLEtBQUwsR0FBYSxLQUFLeEQsVUFBbEIsS0FBaUMsQ0FBckMsRUFBd0M7QUFDdEMsYUFBS2xDLEtBQUw7QUFDQSxhQUFLMEMsV0FBTDtBQUNEO0FBQ0YsS0FoQkQ7QUFBQTs7QUFpQkExQyxVQUFTO0FBQ1AsUUFBSSxLQUFLd0QsV0FBVCxFQUFzQjtBQUNwQixXQUFLQSxXQUFMLENBQWlCLEtBQUtkLFdBQXRCO0FBQ0Q7QUFDRjs7QUEvQnlCLEM7Ozs7Ozs7Ozs7O0FDQTVCMVAsT0FBT2lSLE1BQVAsQ0FBYztBQUFDOVEsV0FBUSxNQUFJeUM7QUFBYixDQUFkO0FBQW9DLElBQUl3SSxTQUFKO0FBQWNwTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDZ0wsZ0JBQVVoTCxDQUFWO0FBQVk7O0FBQXhCLENBQWhDLEVBQTBELENBQTFEO0FBQTZELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSW1ULElBQUo7QUFBU3ZULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUNxVCxPQUFLblQsQ0FBTCxFQUFPO0FBQUNtVCxXQUFLblQsQ0FBTDtBQUFPOztBQUFoQixDQUEzQyxFQUE2RCxDQUE3RDtBQUFnRSxJQUFJQyxNQUFKO0FBQVdMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7O0FBSzlQLE1BQU13QyxNQUFOLENBQWE7QUFDMUI4TyxnQkFBZTtBQUNiLFNBQUszTixNQUFMLEdBQWMsRUFBZDtBQUNBLFNBQUtpUyxTQUFMLEdBQWlCLEVBQWpCO0FBQ0EsU0FBSzZILFFBQUwsR0FBZ0IsSUFBaEI7QUFDRCxHQUx5QixDQU8xQjs7O0FBQ0FDLGdCQUFlQyxPQUFmLEVBQXdCO0FBQ3RCLFNBQUtGLFFBQUwsR0FBZ0IsSUFBSUcsUUFBSixDQUFhRCxPQUFiLENBQWhCO0FBQ0EsU0FBSy9ILFNBQUwsQ0FBZXZELElBQWYsQ0FBb0IsS0FBS29MLFFBQXpCO0FBQ0Q7O0FBRUtuYSxPQUFOLENBQWExQixPQUFPLEVBQXBCLEVBQXdCK1QsS0FBSywrQkFBWSxDQUFFLENBQWQsQ0FBN0I7QUFBQSxvQ0FBNkM7QUFDM0MsVUFBSWtJLE1BQU07QUFDUkYsaUJBQVMxZDtBQURELE9BQVY7QUFJQSxXQUFLeWQsYUFBTCxDQUFtQkcsSUFBSUYsT0FBdkI7O0FBRUEsVUFBSTtBQUNGLFlBQUluYSxvQkFBWW1TLElBQVosQ0FBSjtBQUVBMUosZUFBT0MsTUFBUCxDQUFjMlIsR0FBZCxFQUFtQjtBQUNqQm5NLGdCQUFNLFNBRFc7QUFFakJwTyxpQkFBTzFCLElBRlU7QUFHakJrYyxrQkFBUXRhO0FBSFMsU0FBbkI7QUFLRCxPQVJELENBUUUsT0FBT3lDLENBQVAsRUFBVTtBQUNWZ0csZUFBT0MsTUFBUCxDQUFjMlIsR0FBZCxFQUFtQjtBQUNqQm5NLGdCQUFNLE9BRFc7QUFFakJwTyxpQkFBTzFCLElBRlU7QUFHakJrYyxrQkFBUTlTLFVBQVVtQixLQUFWLENBQWdCbEcsQ0FBaEI7QUFIUyxTQUFuQjtBQUtELE9BZEQsU0FjVTtBQUNSO0FBQ0EsWUFBSSxLQUFLd1gsUUFBTCxDQUFjTSxNQUFkLENBQXFCQyxLQUF6QixFQUFnQztBQUM5Qi9SLGlCQUFPQyxNQUFQLENBQWMyUixHQUFkLEVBQW1CO0FBQ2pCSixzQkFBVSxLQUFLQSxRQUFMLENBQWNNO0FBRFAsV0FBbkI7QUFHRCxTQU5PLENBT1I7OztBQUNBRixZQUFJSSxTQUFKLEdBQWdCLElBQUlsUixJQUFKLEVBQWhCLENBUlEsQ0FTUjs7QUFDQW9HLGFBQUtuUixNQUFMLENBQVk2YixHQUFaLEVBVlEsQ0FZUjs7QUFDQSxhQUFLbGEsTUFBTCxDQUFZME8sSUFBWixDQUFpQndMLEdBQWpCO0FBQ0Q7QUFDRixLQXBDRDtBQUFBLEdBYjBCLENBbUQxQjtBQUNBOzs7QUFDTWxTLGlCQUFOLENBQXVCVixHQUF2QixFQUE0QjBLLEVBQTVCO0FBQUEsb0NBQWdDO0FBQzlCLDJCQUFhMUssSUFBSXdCLE9BQUosRUFBYixHQUE0QjtBQUMxQixZQUFJL0ssb0JBQVl1SixJQUFJeUIsSUFBSixFQUFaLENBQUo7O0FBQ0EsWUFBSTtBQUNGO0FBQ0EsY0FBSWxKLG9CQUFZbVMsR0FBR2pVLEdBQUgsQ0FBWixDQUFKO0FBQ0EsZUFBSzhJLFFBQUwsQ0FBY2hILEdBQWQ7QUFDRCxTQUpELENBSUUsT0FBT3lDLENBQVAsRUFBVTtBQUNWLGVBQUtDLE1BQUwsQ0FBWUQsQ0FBWjtBQUNEO0FBQ0Y7O0FBQ0RnRixVQUFJMkIsS0FBSjtBQUNELEtBWkQ7QUFBQTs7QUFjQXBDLFdBQVUwVCxTQUFWLEVBQXFCO0FBQ25CLFNBQUtULFFBQUwsQ0FBY1UsT0FBZCxDQUFzQkQsU0FBdEI7QUFDRDs7QUFFRGhZLFNBQVFnWSxTQUFSLEVBQW1CO0FBQ2pCLFNBQUtULFFBQUwsQ0FBYzFiLEtBQWQsQ0FBb0JpSixVQUFVbUIsS0FBVixDQUFnQitSLFNBQWhCLENBQXBCO0FBQ0Q7O0FBRURFLGlCQUFnQjtBQUNkLFFBQUlDLFdBQVcsS0FBS3pJLFNBQUwsQ0FBZXhOLElBQWYsQ0FBb0JuQyxLQUFLQSxFQUFFbVksWUFBRixFQUF6QixDQUFmO0FBQ0EsUUFBSUUsV0FBVyxLQUFmOztBQUNBLFNBQUssSUFBSVQsR0FBVCxJQUFnQixLQUFLbGEsTUFBckIsRUFBNkI7QUFDM0IsVUFBSWthLElBQUluTSxJQUFKLEtBQWEsT0FBakIsRUFBMEI7QUFDeEI0TSxtQkFBVyxJQUFYO0FBQ0E7QUFDRDtBQUNGOztBQUNELFdBQU9ELFlBQVlDLFFBQW5CO0FBQ0Q7O0FBRUQzVyxZQUFXO0FBQ1Q7QUFDQSxRQUFJLEtBQUt5VyxZQUFMLEVBQUosRUFBeUI7QUFDdkIsWUFBTSxJQUFJeGQsT0FBT3FSLEtBQVgsQ0FBaUIsS0FBS3RPLE1BQXRCLENBQU47QUFDRDs7QUFDRCxXQUFPLEtBQUtBLE1BQVo7QUFDRDs7QUE3RnlCOztBQWdHNUIsTUFBTWlhLFFBQU4sQ0FBZTtBQUNidE0sY0FBYXFNLE9BQWIsRUFBc0I7QUFDcEIsU0FBS0ksTUFBTCxHQUFjO0FBQ1pDLGFBQU8sQ0FESztBQUVaRyxlQUFTLENBRkc7QUFHWnBjLGFBQU8sQ0FISztBQUlaNGIsZUFBU0E7QUFKRyxLQUFkO0FBTUEsU0FBS1ksU0FBTCxHQUFpQixJQUFqQjtBQUNEOztBQUVESixVQUFTRCxTQUFULEVBQW9CO0FBQ2xCLFFBQUlBLFNBQUosRUFBZTtBQUNiLFdBQUtNLEdBQUwsQ0FBU04sU0FBVCxFQUFvQixJQUFwQjtBQUNEOztBQUNELFNBQUtILE1BQUwsQ0FBWUksT0FBWjtBQUNBLFNBQUtKLE1BQUwsQ0FBWUMsS0FBWjtBQUNEOztBQUVEamMsUUFBT21jLFNBQVAsRUFBa0I7QUFDaEI7QUFDQSxRQUFJL2IsS0FBS0MsU0FBTCxDQUFlLEtBQUttYyxTQUFwQixNQUFtQ3BjLEtBQUtDLFNBQUwsQ0FBZThiLFNBQWYsQ0FBdkMsRUFBa0U7QUFDaEUsVUFBSUEsYUFBYUEsY0FBYyxFQUEzQixJQUFpQ0EsY0FBYyxFQUFuRCxFQUF1RDtBQUNyRCxhQUFLTSxHQUFMLENBQVNOLFNBQVQsRUFBb0IsS0FBcEI7QUFDQSxhQUFLSyxTQUFMLEdBQWlCTCxTQUFqQjtBQUNEO0FBQ0Y7O0FBQ0QsU0FBS0gsTUFBTCxDQUFZaGMsS0FBWjtBQUNBLFNBQUtnYyxNQUFMLENBQVlDLEtBQVo7QUFDRDs7QUFFRFEsTUFBS04sU0FBTCxFQUFnQk87QUFBVTtBQUExQixJQUFtRTtBQUNqRSxRQUFJWixNQUFNO0FBQ1JNLGVBQVNNLFNBREQ7QUFFUmQsZUFBUyxLQUFLSSxNQUFMLENBQVlKLE9BRmI7QUFHUnJDLGVBQVM0QyxTQUhEO0FBSVJELGlCQUFXLElBQUlsUixJQUFKO0FBSkgsS0FBVjtBQU1Bb0csU0FBS25SLE1BQUwsQ0FBWTZiLEdBQVo7QUFDRDs7QUFFRE8saUJBQWdCO0FBQ2QsV0FBTyxLQUFLTCxNQUFMLENBQVloYyxLQUFuQjtBQUNEOztBQTNDWSxDOzs7Ozs7Ozs7OztBQ3JHZm5DLE9BQU9pUixNQUFQLENBQWM7QUFBQzlRLFdBQVEsTUFBSWdYO0FBQWIsQ0FBZDs7QUFBZSxNQUFNQSxRQUFOLENBQWU7QUFDNUIsU0FBTzBELE9BQVAsQ0FBZ0JpRSxJQUFoQixFQUFzQkMsR0FBdEIsRUFBMkJDLFVBQTNCLEVBQXVDO0FBQ3JDLFFBQUlBLGVBQWVDLFNBQW5CLEVBQThCO0FBQUVELG1CQUFhLEVBQWI7QUFBaUI7O0FBQ2pELFFBQUlFLFlBQVlKLEtBQUtLLEtBQUwsQ0FBVyxFQUFYLENBQWhCO0FBQ0EsUUFBSXpNLFFBQVEsQ0FBWjtBQUNBLFFBQUkwTSxNQUFNLEVBQVY7O0FBQ0EsU0FBSyxJQUFJL0ssSUFBSSxDQUFiLEVBQWdCQSxJQUFJNkssVUFBVTVLLE1BQTlCLEVBQXNDRCxHQUF0QyxFQUEyQztBQUN6QyxVQUFJZ0wsSUFBSXBDLE9BQU9pQyxVQUFVN0ssQ0FBVixDQUFQLENBQVI7QUFDQSxVQUFJZ0wsRUFBRS9LLE1BQUYsR0FBVyxDQUFmLEVBQWtCNUIsUUFBbEIsS0FDS0EsU0FBUyxDQUFUOztBQUNMLFVBQUlBLFFBQVFxTSxHQUFaLEVBQWlCO0FBQ2YsZUFBT0ssTUFBTUosVUFBYjtBQUNEOztBQUNESSxhQUFPTixLQUFLUSxNQUFMLENBQVlqTCxDQUFaLENBQVA7QUFDRDs7QUFDRCxXQUFPeUssSUFBUDtBQUNEOztBQWhCMkIsQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCAocmVxLCByZXMsIG5leHQpID0+IHtcclxuLy8gICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbi8vICAgcmVzLmVuZChgSGVsbG8gd29ybGQgZnJvbTogJHtNZXRlb3IucmVsZWFzZX1gKTtcclxuLy8gfSk7XHJcblxyXG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xyXG5pbXBvcnQgdW5pcWlkIGZyb20gJ3VuaXFpZCc7XHJcblxyXG4vLyBSZXF1aXJlcyBtdWx0aXBhcnR5IFxyXG5pbXBvcnQgbXVsdGlwYXJ0eSBmcm9tICdjb25uZWN0LW11bHRpcGFydHknO1xyXG5pbXBvcnQge1xyXG4gIFVwbG9hZHNcclxufSBmcm9tICcuLi8uLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcyc7XHJcbmxldCBtdWx0aXBhcnR5TWlkZGxld2FyZSA9IG11bHRpcGFydHkoKTtcclxuXHJcbmNvbnN0IHJvdXRlID0gJy91cGxvYWQvaW1hZ2UnO1xyXG5cclxuLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCBmdWMudXBsb2FkRmlsZSApO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgbXVsdGlwYXJ0eU1pZGRsZXdhcmUpO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgKHJlcSwgcmVzcCkgPT4ge1xyXG4gIC8vIGRvbid0IGZvcmdldCB0byBkZWxldGUgYWxsIHJlcS5maWxlcyB3aGVuIGRvbmVcclxuXHJcbiAgY29uc3QgcmVhZGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy5yZWFkRmlsZSk7XHJcbiAgY29uc3Qgd3JpdGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy53cml0ZUZpbGUpO1xyXG4gIGNvbnN0IHVwbG9hZElkID0gdW5pcWlkKCk7XHJcblxyXG4gIGZvciAobGV0IGZpbGUgb2YgcmVxLmZpbGVzLmZpbGUpIHtcclxuICAgIGNvbnN0IGRhdGEgPSByZWFkZXIoZmlsZS5wYXRoKTtcclxuICAgIC8vIOODleOCoeOCpOODq+WQjeOBrumHjeikh+OCkumBv+OBkeOCi+OBn+OCgeOAgeS4gOaEj+OBruODleOCoeOCpOODq+WQjeOCkuS9nOaIkOOBmeOCi1xyXG4gICAgLy8g5qW95aSp44Gu44OV44Kh44Kk44Or5ZCN5paH5a2X5pWw5Yi26ZmQMjDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBmaWxlbmFtZSA9IGAke3VuaXFpZCgpfS5qcGdgXHJcblxyXG4gICAgLy8gc2V0IHRoZSBjb3JyZWN0IHBhdGggZm9yIHRoZSBmaWxlIG5vdCB0aGUgdGVtcG9yYXJ5IG9uZSBmcm9tIHRoZSBBUEk6XHJcbiAgICBsZXQgc2F2ZVBhdGggPSByZXEuYm9keS5pbWFnZWRpciArICcvJyArIGZpbGVuYW1lO1xyXG5cclxuICAgIC8vIGNvcHkgdGhlIGRhdGEgZnJvbSB0aGUgcmVxLmZpbGVzLmZpbGUucGF0aCBhbmQgcGFzdGUgaXQgdG8gZmlsZS5wYXRoXHJcblxyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ57WQ5p6c44KS6KiY6Yyy44GZ44KLXHJcbiAgICBsZXQgZG9jID0ge1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICAgIGNsaWVudEZpbGVOYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgIHVwbG9hZGVkRmlsZU5hbWU6IGZpbGVuYW1lXHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICB0cnl7XHJcbiAgICAgIHdyaXRlcihzYXZlUGF0aCwgZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaChlcnIpe1xyXG4gICAgICBkb2MuZXJyb3IgPSBlcnI7XHJcbiAgICB9XHJcbiAgICBVcGxvYWRzLmluc2VydChkb2MpO1xyXG5cclxuICAgIGRlbGV0ZSBmaWxlO1xyXG5cclxuICB9O1xyXG4gIHJlc3Aud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgc2F2ZURpcjogcmVxLmJvZHkuaW1hZ2VkaXJcclxuICB9KSk7XHJcblxyXG59KTsiLCJpbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0bydcclxuXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBSZXBvcnQgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBHcm91cCxcclxuICBHcm91cEZhY3RvcnlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzJ1xyXG5pbXBvcnQge1xyXG4gIEZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlbWlnJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5taWdyYXRlYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIC8vIHNldHVwIGdyb3VwXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgRmlsdGVyKGNvbmZpZy5zcmNGaWx0ZXJJZClcclxuICAgIC8vIGxldCBwbHVnID0gZ3JvdXAuZ2V0UGx1ZygpO1xyXG5cclxuICAgIC8vIGNoZWNraW5nIGNvbm5lY3Rpb25cclxuICAgIC8vXHJcblxyXG4gICAgbGV0IHRlc3RRdWVyeSA9ICdTSE9XIERBVEFCQVNFUydcclxuXHJcbiAgICBsZXQgZHN0RGIgPSBuZXcgTXlTUUwoY29uZmlnLmRzdC5jcmVkKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnQ29ubmVjdCB0byBEZXN0aW5hdGlvbicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBhd2FpdCBkc3REYi5xdWVyeSh0ZXN0UXVlcnkpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcHJvY2VzcyBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICAvL1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnU2VsZWN0IGxvb3AgaW4gc291cmNlJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICBtb2JpbGVOdWxsOiBhc3luYyAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIC8vIOWApOOCkuaVtOeQhlxyXG4gICAgICAgICAgICAvLyBmb3IgKGxldCBrZXkgb2YgT2JqZWN0LmtleXMocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyAgIGlmIChyZWNvcmRba2V5XSA9PT0gbnVsbCk7XHJcbiAgICAgICAgICAgIC8vICAgZWxzZSBpZiAocmVjb3JkW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAvLyDml6Xku5jjgpLlpInmj5tcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gTXlTUUwuZm9ybWF0RGF0ZShyZWNvcmRba2V5XSk7XHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IGBcIiR7cmVjb3JkW2tleV19XCJgO1xyXG4gICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyIOOBq+S/neWtmFxyXG5cclxuICAgICAgICAgICAgbGV0IHNxbCA9IGBcclxuXHJcbiAgICAgICAgICAgICAgICBJTlNFUlQgZHRiX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAoIFxcYGN1c3RvbWVyX2lkXFxgLCBcXGBzdGF0dXNcXGAsIFxcYHNleFxcYCwgXFxgam9iXFxgLCBcXGBjb3VudHJ5X2lkXFxgLCBcXGBwcmVmXFxgLCBcXGBuYW1lMDFcXGAsIFxcYG5hbWUwMlxcYCwgXFxga2FuYTAxXFxgLCBcXGBrYW5hMDJcXGAsIFxcYGNvbXBhbnlfbmFtZVxcYCwgXFxgemlwMDFcXGAsIFxcYHppcDAyXFxgLCBcXGB6aXBjb2RlXFxgLCBcXGBhZGRyMDFcXGAsIFxcYGFkZHIwMlxcYCwgXFxgZW1haWxcXGAsIFxcYHRlbDAxXFxgLCBcXGB0ZWwwMlxcYCwgXFxgdGVsMDNcXGAsIFxcYGZheDAxXFxgLCBcXGBmYXgwMlxcYCwgXFxgZmF4MDNcXGAsIFxcYGJpcnRoXFxgLCBcXGBwYXNzd29yZFxcYCwgXFxgc2FsdFxcYCwgXFxgc2VjcmV0X2tleVxcYCwgXFxgZmlyc3RfYnV5X2RhdGVcXGAsIFxcYGxhc3RfYnV5X2RhdGVcXGAsIFxcYGJ1eV90aW1lc1xcYCwgXFxgYnV5X3RvdGFsXFxgLCBcXGBub3RlXFxgLCBcXGBjcmVhdGVfZGF0ZVxcYCwgXFxgdXBkYXRlX2RhdGVcXGAsIFxcYGRlbF9mbGdcXGAgKVxyXG5cclxuICAgICAgICAgICAgICAgIFZBTFVFUyggJHtyZWNvcmQuY3VzdG9tZXJfaWR9ICwgJHtyZWNvcmQuc3RhdHVzfSAsICR7cmVjb3JkLnNleH0gLCAke3JlY29yZC5qb2J9ICwgJHtyZWNvcmQuY291bnRyeV9pZH0gLCAke3JlY29yZC5wcmVmfSAsICR7cmVjb3JkLm5hbWUwMX0gLCAke3JlY29yZC5uYW1lMDJ9ICwgJHtyZWNvcmQua2FuYTAxfSAsICR7cmVjb3JkLmthbmEwMn0gLCAke3JlY29yZC5jb21wYW55X25hbWV9ICwgJHtyZWNvcmQuemlwMDF9ICwgJHtyZWNvcmQuemlwMDJ9ICwgJHtyZWNvcmQuemlwY29kZX0gLCAke3JlY29yZC5hZGRyMDF9ICwgJHtyZWNvcmQuYWRkcjAyfSAsICR7cmVjb3JkLmVtYWlsfSAsICR7cmVjb3JkLnRlbDAxfSAsICR7cmVjb3JkLnRlbDAyfSAsICR7cmVjb3JkLnRlbDAzfSAsICR7cmVjb3JkLmZheDAxfSAsICR7cmVjb3JkLmZheDAyfSAsICR7cmVjb3JkLmZheDAzfSAsICR7cmVjb3JkLmJpcnRofSAsICR7cmVjb3JkLnBhc3N3b3JkfSAsICR7cmVjb3JkLnNhbHR9ICwgJHtyZWNvcmQuc2VjcmV0X2tleX0gLCAke3JlY29yZC5maXJzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5sYXN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmJ1eV90aW1lc30gLCAke3JlY29yZC5idXlfdG90YWx9ICwgJHtyZWNvcmQubm90ZX0gLCAke3JlY29yZC5jcmVhdGVfZGF0ZX0gLCAke3JlY29yZC51cGRhdGVfZGF0ZX0gLCAke3JlY29yZC5kZWxfZmxnfSApXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBzdGF0dXM6IHJlY29yZC5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgIHNleDogcmVjb3JkLnNleCxcclxuICAgICAgICAgICAgICAgICAgam9iOiByZWNvcmQuam9iLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIGVtYWlsOiByZWNvcmQuZW1haWwsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGJpcnRoOiByZWNvcmQuYmlydGgsXHJcbiAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiByZWNvcmQucGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICAgIHNhbHQ6IHJlY29yZC5zYWx0LFxyXG4gICAgICAgICAgICAgICAgICBzZWNyZXRfa2V5OiByZWNvcmQuc2VjcmV0X2tleSxcclxuICAgICAgICAgICAgICAgICAgZmlyc3RfYnV5X2RhdGU6IHJlY29yZC5maXJzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgbGFzdF9idXlfZGF0ZTogcmVjb3JkLmxhc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90aW1lczogcmVjb3JkLmJ1eV90aW1lcyxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RvdGFsOiByZWNvcmQuYnV5X3RvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBub3RlOiByZWNvcmQubm90ZSxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lcl9hZGRyZXNzXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyX2FkZHJlc3MnLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2FkZHJlc3NfaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOODoeODq+ODnuOCrOODl+ODqeOCsOOCpOODsyBwbGdfbWFpbG1hZ2FfY3VzdG9tZXJcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfbWFpbG1hZ2FfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGlkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBtYWlsbWFnYV9mbGc6IHJlY29yZC5tYWlsbWFnYV9mbGcsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjgq/jg7zjg53jg7PnmbrooYzvvIhFQ0NVQkUy44Gu44Od44Kk44Oz44OI6YKE5YWD77yJXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uQ2QgPSBjcnlwdG8ucmFuZG9tQnl0ZXMoOCkudG9TdHJpbmcoJ2Jhc2U2NCcpLnN1YnN0cmluZygwLCAxMSlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25OYW1lID0gYCR7cmVjb3JkLm5hbWUwMX0gJHtyZWNvcmQubmFtZTAyfSDmp5gg44GU5YSq5b6F44Kv44O844Od44OzIOS8muWToeeVquWPtzoke3JlY29yZC5jdXN0b21lcl9pZH1gXHJcblxyXG4gICAgICAgICAgICBsZXQgZGlzY291bnRQcmljZSA9IHJlY29yZC5wb2ludCArIDUwMFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX2NvdXBvbicsIHtcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fY2Q6IGNvdXBvbkNkLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdHlwZTogMywgLy8g5YWo5ZWG5ZOBXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9uYW1lOiBjb3Vwb25OYW1lLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF90eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdXNlX3RpbWU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9yZWxlYXNlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9wcmljZTogZGlzY291bnRQcmljZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcmF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgZW5hYmxlX2ZsYWc6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9tZW1iZXI6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9sb3dlcl9saW1pdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX2Zyb21fZGF0ZTogJzIwMTgtMDQtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfdG9fZGF0ZTogJzIwMTktMDUtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiAwXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyAnY3ViZW1pZy5zZXJ2ZXJDaGVjaycgKHByb2ZpbGUpIHtcclxuICAgIGxldCBkYiA9IG5ldyBNeVNRTChwcm9maWxlKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGRiLnF1ZXJ5KCdTSE9XIERBVEFCQVNFUycpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IHsgTW9uZ29Db2xsZWN0aW9uIH0gZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL21vbmdvJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuY29sbGVjdGlvbidcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZmluZGBdIChwbHVnLCBxdWVyeSA9IHt9LCBwcm9qZWN0aW9uID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5maW5kKHF1ZXJ5LCB7cHJvamVjdGlvbjogcHJvamVjdGlvbn0pLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmFnZ3JlZ2F0ZWBdIChwbHVnLCBxdWVyeSA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuYWdncmVnYXRlKHF1ZXJ5KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuaXRlbXMnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z44Kz44Os44Kv44K344On44Oz5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44G+44GZ44CCXHJcbiAgICogQHBhcmFtXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uc2V0SW1hZ2VgXSAocGx1ZywgdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGxldCB1cGxvYWRlZCA9IGF3YWl0IGl0ZW1jb24uc2V0SW1hZ2UodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICAgIHJldHVybiB1cGxvYWRlZFxyXG4gIH0sXHJcblxyXG4gIC8qKlxyXG4gICAqIOOCouOCpOODhuODoOaDheWgseODh+ODvOOCv+ODmeODvOOCueOBrueUu+WDj+eZu+mMsuOCkuWJiumZpOOBmeOCi++8iOeUu+WDj+iHquS9k+OBr+WJiumZpOOBl+OBquOBhO+8iVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LmNsZWFuSW1hZ2VgXSAocGx1ZywgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5jbGVhbkltYWdlKG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IHtcclxuICBDdWJlM0FwaVxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9jdWJlM2FwaSdcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWcqOW6q+abtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVTdG9ja2BdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpXHJcbiAgICBsZXQgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+WcqOW6q+OBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdVUERBVEUnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseeZu+mMsuOBqOabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYkl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKVxyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQilcclxuXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdFQ0NVQkUz44G444Gu5ZWG5ZOB55m76YyyJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnSU5TRVJUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvblxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKVxyXG5cclxuICAgICAgICAgICAgICBsZXQgaW5zZXJ0UmVzID0gYXdhaXQgYXBpLnByb2R1Y3RDcmVhdGUoY3ViZUl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIC8vIGl0ZW0g44OH44O844K/44OZ44O844K544G444Gu55m76YyyXHJcbiAgICAgICAgICAgICAgYXdhaXQgY29sLnVwZGF0ZSh7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkXHJcbiAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcCc6IGluc2VydFJlcy5yZXNcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9KVxyXG5cclxuICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdFQ0NVQkUz5ZWG5ZOB5oOF5aCx44Gu5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnVVBEQVRFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvblxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKVxyXG5cclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdEltYWdlVXBkYXRlKGN1YmVJdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VXBkYXRlKGN1YmVJdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VGFnVXBkYXRlKGN1YmVJdGVtKVxyXG5cclxuICAgICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5KVxyXG5cclxuICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAndG9vbCdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udGVzdGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcblxyXG4gICAgY29uc3QgbmV3TG9jYWwgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7fSwgYXN5bmMgKGUpID0+IHtcclxuICAgICAgdGhyb3cgZVxyXG4gICAgfSlcclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODleOCo+ODq+OCv+ODvOODhuOCueODiCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gbmV3TG9jYWxcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5pbXBvcnQgV293bWFBcGkgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL3dvd21hQXBpJ1xyXG5pbXBvcnQgdXRpbEVycm9yIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9lcnJvcidcclxuXHJcbmNvbnN0IHRhZyA9ICd3b3dtYSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDllYblk4Hjg4fjg7zjgr/jg5njg7zjgrnkuIrjga7llYblk4HjgpLlhazplovjgZnjgotcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlSXRlbS5vcGVuYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV293bWEhIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueS4iuOBruWVhuWTgeOCkuWFrOmWi+OBmeOCiycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIGpsaW5lX2VuZ2luZSDllYblk4Hjg4fjg7zjgr/jg5njg7zjgrnjgbjjga7mjqXntppcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyDllYblk4Hmg4XloLHjga7kvZzmiJBcclxuICAgICAgICBsZXQgY3VyID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgICAgICAkYW5kOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6IHsgJGV4aXN0czogMSB9XHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIC8vIOODhuOCueODiOaknOe0ouadoeS7tuioreWumlxyXG4gICAgICAgICAgICAgICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJ2drLTE2MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDU0MDInXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDc0MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICBdXHJcbiAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4HjgrPjg7zjg4njga7kuIDopqfjgpLkvZzjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRtYWxsLndvd21hLml0ZW1Db2RlJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyDlvpfjgonjgozjgZ/llYblk4HjgZTjgajjgatBUEnjg6rjgq/jgqjjgrnjg4jjgpLnmbrooYxcclxuICAgICAgICBsZXQgYXBpID0gbmV3IFdvd21hQXBpKGNvbmZpZy53b3dtYUFwaVBvc3QsIGNvbmZpZy5zaG9wSWQpXHJcbiAgICAgICAgYXdhaXQgcmVwb3J0LmZvckVhY2hPbkN1cnNvcihcclxuICAgICAgICAgIGN1cixcclxuICAgICAgICAgIGFzeW5jIGl0ZW0gPT4ge1xyXG4gICAgICAgICAgICBpdGVtLnNhbGVTdGF0dXMgPSAxXHJcbiAgICAgICAgICAgIGl0ZW0ubGltaXRlZFBhc3N3ZCA9ICdOVUxMJ1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlSXRlbShpdGVtKVxyXG4gICAgICAgICAgICAgIHJldHVybiB7cmVxdWVzdEJvZHk6IGl0ZW0sIHJlc3BvbnNlOiByZXN9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICB0aHJvdyBPYmplY3QuYXNzaWduKHtyZXF1ZXN0Qm9keTogaXRlbX0sIHV0aWxFcnJvci5wYXJzZShlKSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDlnKjluqvmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlU3RvY2tgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5Zyo5bqr5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5Zyo5bqr5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgIC8vICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAkb3I6IFtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDU0MDInXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAse1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAse1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDc0MydcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICBdXHJcbiAgICAgICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDphY3pgIHmlrnms5Xjga7pgZXjgYTjgpLnnIHjgY9cclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDoge1xyXG4gICAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRtYWxsLndvd21hLml0ZW1Db2RlJyxcclxuICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGU6ICckbWFsbC53b3dtYS5IQ2hvaWNlTmFtZScsXHJcbiAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogJyRtYWxsLndvd21hLlZDaG9pY2VOYW1lJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGl0ZW06IHtcclxuICAgICAgICAgICAgICAgICAgJGZpcnN0OiAnJF9pZCdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4Hjg5rjg7zjgrjjgZTjgajvvIjllYblk4HjgrPjg7zjg4nvvInjgavjgrDjg6vjg7zjg5fljJbjgZnjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRfaWQuaXRlbUNvZGUnLFxyXG4gICAgICAgICAgICAgICAgdmFyaWF0aW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAkcHVzaDoge1xyXG4gICAgICAgICAgICAgICAgICAgIF9pZDogJyRpdGVtJyxcclxuICAgICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZTogJyRfaWQuY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogJyRfaWQuY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlJ1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJHByb2plY3Q6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogMCxcclxuICAgICAgICAgICAgICAgIGl0ZW1Db2RlOiAnJF9pZCcsXHJcbiAgICAgICAgICAgICAgICB2YXJpYXRpb25zOiAnJHZhcmlhdGlvbnMnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyBsZXQgcmVzTW9uZ28gPSBhd2FpdCBjdXIudG9BcnJheSgpXHJcbiAgICAgICAgLy8gcmV0dXJuIHJlc01vbmdvXHJcblxyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo1xyXG4gICAgICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XHJcbiAgICAgICAgICBsZXQgaXRlbSA9IGF3YWl0IGN1ci5uZXh0KClcclxuXHJcbiAgICAgICAgICAvLyDlnKjluqvjgpLoqK3lrprjgZnjgotcclxuICAgICAgICAgIGZvciAobGV0IGUgb2YgaXRlbS52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgICAgIGUuc3RvY2sgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhlLl9pZClcclxuICAgICAgICAgICAgZGVsZXRlIGUuX2lkXHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgLy9cclxuICAgICAgICAgIC8vIOWcqOW6q+abtOaWsOODquOCr+OCqOOCueODiFxyXG4gICAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS51cGRhdGVTdG9jayhbaXRlbV0pXHJcbiAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhyZXMpXHJcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY3VyLmNsb3NlKClcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB5qSc57SiXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnNlYXJjaEl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5ZWG5ZOB5oOF5aCx5Y+W5b6XJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gQVBJ44GL44KJ5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9pdGVtc18keyhuZXcgRGF0ZSgpKS5nZXRUaW1lKCl9YFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IG9wdGlvbnMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGNvbmZpZy53b3dtYUFwaSkpXHJcbiAgICAgICAgICAgIG9wdGlvbnMudXJpID0gYCR7b3B0aW9ucy51cml9L3NlYXJjaEl0ZW1JbmZvYFxyXG4gICAgICAgICAgICBvcHRpb25zLnFzLml0ZW1Db2RlID0gaXRlbS5tYWxsLndvd21hLml0ZW1Db2RlXHJcblxyXG4gICAgICAgICAgICBsZXQgcmVwb3MgPSBhd2FpdCByZXF1ZXN0KG9wdGlvbnMpXHJcbiAgICAgICAgICAgIGxldCBmaWxlbmFtZSA9IGAke3dvcmtkaXJ9LyR7aXRlbS5tb2RlbH0ueG1sYFxyXG5cclxuICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS53cml0ZUZpbGUoZmlsZW5hbWUsIHJlcG9zKVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIFdvd21hQXBpSXRlbUZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxuY29uc3QgdGFnID0gJ3dvd21hQXBpJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIFdPV01B5ZWG5ZOB5oOF5aCx5Y+W5b6XXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmdldEl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5ZWG5ZOB5oOF5aCx5Y+W5b6XJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBXb3dtYUFwaUl0ZW1GaWx0ZXIoY29uZmlnLndvd21hQXBpLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8gLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgLy8gdHJ5IHtcclxuICAgICAgICAvLyAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgLy8gfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gLy8gQVBJ44GL44KJ5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgLy8gY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9pdGVtc18keyhuZXcgRGF0ZSgpKS5nZXRUaW1lKCl9YFxyXG4gICAgICAgIC8vIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIC8vIHRyeSB7XHJcbiAgICAgICAgLy8gICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgLy8gfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKGl0ZW0pXHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IFBhY2tldCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcGFja2V0J1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgYXJjaGl2ZXIgZnJvbSAnYXJjaGl2ZXInXHJcbmltcG9ydCBjc3YgZnJvbSAnY3N2J1xyXG5pbXBvcnQgeyBQYXNzVGhyb3VnaCwgVHJhbnNmb3JtIH0gZnJvbSAnc3RyZWFtJ1xyXG5cclxuY29uc3QgcHJlZml4ID0gJ3BhY2tldCdcclxuY29uc3QgdGFnID0gJ3lhdWN0J1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOODpOODleOCquOCr+WPl+azqOODleOCoeOCpOODq1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5vcmRlcmBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODpOODleOCquOCr+WPl+azqCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L29yZGVyYFxyXG4gICAgICAgIGNvbnN0IHIgPSBmc0V4dHJhLmNyZWF0ZVJlYWRTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJMb2FkZmlsZX1gKVxyXG4gICAgICAgIGNvbnN0IHcgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyU2F2ZWZpbGV9YClcclxuICAgICAgICByLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAucGlwZShjc3YucGFyc2Uoe2NvbHVtbnM6IHRydWV9KSlcclxuICAgICAgICAgIC5waXBlKGNzdi50cmFuc2Zvcm0oXHJcbiAgICAgICAgICAgIGFzeW5jIChyZWNvcmQsIGNhbGxiYWNrKSA9PiB7XHJcbiAgICAgICAgICAgICAgbGV0IGVyciA9IG51bGxcclxuICAgICAgICAgICAgICAvLyDnrqHnkIbnlarlj7fjgpLnva7jgY3mj5vjgYjjgotcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgcmVjb3JkWyfnrqHnkIbnlarlj7cnXSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldE1vZGVsQ2xhc3MocmVjb3JkWyfnrqHnkIbnlarlj7cnXSlcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBlcnIgPSBlXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNhbGxiYWNrKGVyciwgcmVjb3JkKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC5waXBlKHcpXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOODpOODleOCquOCr+WHuuWTgeODleOCoeOCpOODq1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYml0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44Ok44OV44Kq44Kv5Ye65ZOBJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g57mw44KK6L+U44GX5Yem55CG44KS5Lu75oSP44Gu77yIcGFja2V0U2l6Ze+8ieOBp+WIhuWJslxyXG4gICAgICAgIGNvbnN0IHBhY2tldCA9IG5ldyBQYWNrZXQoY29uZmlnLnBhY2tldFNpemUpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIENTVuODleOCoeOCpOODq+OCkuS9nOaIkOOBl+eUu+WDj+ODh+ODvOOCv+OCkuWPjumbhuOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vd29ya2BcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh3b3JrZGlyKVxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuXHJcbiAgICAgICAgLy8gWklQ44OV44Kh44Kk44Or44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3QgdXBsb2FkZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L3VwbG9hZGBcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh1cGxvYWRkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih1cGxvYWRkaXIpXHJcblxyXG4gICAgICAgIGxldCBjZCA9IG51bGwgLy8g44OR44Kx44OD44OI44OV44Kp44Or44OAXHJcbiAgICAgICAgbGV0IGZpbGVuYW1lID0gbnVsbCAvLyBjc3bjg5XjgqHjgqTjg6tcclxuICAgICAgICBsZXQgbmFtZSA9IG51bGwgLy8g44OR44Kx44OD44OI55Wq5Y+3XHJcblxyXG4gICAgICAgIC8vIENTVuODleOCo+ODvOODq+ODieOCkuWumue+qeOBl+OAgemghueVquOCkueiuuWumuOBmeOCi1xyXG4gICAgICAgIGxldCBmaWVsZHMgPSBbJ+euoeeQhueVquWPtycsICfjgqvjg4bjgrTjg6onLCAn44K/44Kk44OI44OrJywgJ+iqrOaYjicsICfjgrnjg4jjgqLlhoXllYblk4HmpJzntKLnlKjjgq3jg7zjg6/jg7zjg4knLCAn6ZaL5aeL5L6h5qC8JywgJ+WNs+axuuS+oeagvCcsICflgKTkuIvjgZLkuqTmuIknLCAn5YCL5pWwJywgJ+WFpeacreWAi+aVsOWItumZkCcsICfmnJ/plpMnLCAn57WC5LqG5pmC6ZaTJywgJ+WVhuWTgeeZuumAgeWFg+OBrumDvemBk+W6nOecjCcsICfllYblk4HnmbrpgIHlhYPjga7luILljLrnlLrmnZEnLCAn6YCB5paZ6LKg5ouFJywgJ+S7o+mHkeWFiOaJleOBhOOAgeW+jOaJleOBhCcsICfokL3mnK3jg4rjg5PmsbrmuIjmlrnms5XoqK3lrponLCAn5ZWG5ZOB44Gu54q25oWLJywgJ+WVhuWTgeOBrueKtuaFi+WCmeiAgycsICfov5Tlk4Hjga7lj6/lkKYnLCAn6L+U5ZOB44Gu5Y+v5ZCm5YKZ6ICDJywgJ+eUu+WDjzEnLCAn55S75YOPMeOCs+ODoeODs+ODiCcsICfnlLvlg48yJywgJ+eUu+WDjzLjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMycsICfnlLvlg48z44Kz44Oh44Oz44OIJywgJ+eUu+WDjzQnLCAn55S75YOPNOOCs+ODoeODs+ODiCcsICfnlLvlg481JywgJ+eUu+WDjzXjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNicsICfnlLvlg48244Kz44Oh44Oz44OIJywgJ+eUu+WDjzcnLCAn55S75YOPN+OCs+ODoeODs+ODiCcsICfnlLvlg484JywgJ+eUu+WDjzjjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOScsICfnlLvlg48544Kz44Oh44Oz44OIJywgJ+eUu+WDjzEwJywgJ+eUu+WDjzEw44Kz44Oh44Oz44OIJywgJ+acgOS9juipleS+oScsICfmgqroqZXlibLlkIjliLbpmZAnLCAn5YWl5pyt6ICF6KqN6Ki85Yi26ZmQJywgJ+iHquWLleW7tumVtycsICfml6nmnJ/ntYLkuoYnLCAn5ZWG5ZOB44Gu6Ieq5YuV5YaN5Ye65ZOBJywgJ+iHquWLleWApOS4i+OBkicsICfmnIDkvY7okL3mnK3kvqHmoLwnLCAn44OB44Oj44Oq44OG44Kj44O8JywgJ+azqOebruOBruOCquODvOOCr+OCt+ODp+ODsycsICflpKrlrZfjg4bjgq3jgrnjg4gnLCAn6IOM5pmv6ImyJywgJ+OCueODiOOCouODm+ODg+ODiOOCquODvOOCr+OCt+ODp+ODsycsICfnm67nq4vjgaHjgqLjgqTjgrPjg7MnLCAn6LSI562U5ZOB44Ki44Kk44Kz44OzJywgJ1Tjg53jgqTjg7Pjg4jjgqrjg5fjgrfjg6fjg7MnLCAn44Ki44OV44Kj44Oq44Ko44Kk44OI44Kq44OX44K344On44OzJywgJ+iNt+eJqeOBruWkp+OBjeOBlScsICfojbfnianjga7ph43ph48nLCAn44Gv44GTQk9PTicsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxJywgJ+OBneOBruS7lumFjemAgeaWueazlTHmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UyJywgJ+OBneOBruS7lumFjemAgeaWueazlTLmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UzJywgJ+OBneOBruS7lumFjemAgeaWueazlTPmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U0JywgJ+OBneOBruS7lumFjemAgeaWueazlTTmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U1JywgJ+OBneOBruS7lumFjemAgeaWueazlTXmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U2JywgJ+OBneOBruS7lumFjemAgeaWueazlTbmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U3JywgJ+OBneOBruS7lumFjemAgeaWueazlTfmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U4JywgJ+OBneOBruS7lumFjemAgeaWueazlTjmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U5JywgJ+OBneOBruS7lumFjemAgeaWueazlTnmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOWFqOWbveS4gOW+i+S+oeagvCcsICfmtbflpJbnmbrpgIEnLCAn6YWN6YCB5pa55rOV44O76YCB5paZ6Kit5a6aJywgJ+S7o+W8leaJi+aVsOaWmeioreWumicsICfmtojosrvnqI7oqK3lrponLCAnSkFO44Kz44O844OJ44O7SVNCTuOCs+ODvOODiSddXHJcbiAgICAgICAgbGV0IGhlYWRlciA9IGZpZWxkcy5tYXAodiA9PiBgXCIke3Z9XCJgKS5qb2luKCcsJykgKyAnXFxuJ1xyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbplovlp4vmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXRTdGFydCA9IGFzeW5jIChwYWNrZXRDb3VudCkgPT4ge1xyXG4gICAgICAgICAgbmFtZSA9IHByZWZpeCArICgnMDAwMDAnICsgcGFja2V0Q291bnQpLnNsaWNlKC01KVxyXG4gICAgICAgICAgY2QgPSBgJHt3b3JrZGlyfS8ke25hbWV9YFxyXG4gICAgICAgICAgZmlsZW5hbWUgPSBgJHtjZH0vJHtjb25maWcuY3N2RmlsZU5hbWV9YFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2RpcihjZClcclxuICAgICAgICAgIC8vIENTVuODleOCoeOCpOODq+OBq+ODleOCo+ODvOODq+ODieOCkuioreWumuOBmeOCi1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUoaGVhZGVyLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXQgPSBhc3luYyAoYXJnKSA9PiB7XHJcbiAgICAgICAgICBsZXQgeWF1Y3QgPSBhcmcueWF1Y3RcclxuICAgICAgICAgIGxldCBpdGVtID0gYXJnLml0ZW1cclxuICAgICAgICAgIC8vIGNzduODleOCoeOCpOODq+OBq+ODrOOCs+ODvOODie+8iOWVhuWTgeODhuODs+ODl+ODrOODvOODiO+8ieOCkui/veWKoOOBmeOCi1xyXG4gICAgICAgICAgbGV0IHJlY29yZCA9IGZpZWxkcy5tYXAodiA9PiB7IHJldHVybiB5YXVjdFt2XSA/IGBcIiR7eWF1Y3Rbdl19XCJgIDogJ1wiXCInIH0pLmpvaW4oJywnKSArICdcXG4nXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShyZWNvcmQsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICAgIC8vIOeUu+WDj+ODleOCoeOCpOODq+OCkuOCs+ODlOODvFxyXG4gICAgICAgICAgZm9yIChsZXQgaW1nIG9mIGl0ZW0uaW1hZ2VzKSB7XHJcbiAgICAgICAgICAgIGxldCBpbWdTcmMgPSBgJHtjb25maWcuaW1hZ2VkaXJ9LyR7aW1nfWBcclxuICAgICAgICAgICAgbGV0IGltZ1RndCA9IGAke2NkfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgLy8g5ZCM44GY44OV44Kh44Kk44Or44GM44GC44KL5aC05ZCI44Gv44Kz44OU44O844GX44Gq44GEXHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5hY2Nlc3MoaW1nVGd0KVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5jb3B5RmlsZShpbWdTcmMsIGltZ1RndClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI57WC5LqG5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0RW5kID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB6aXAgPSBhcmNoaXZlcignemlwJylcclxuICAgICAgICAgIGNvbnN0IHppcG5hbWUgPSBgJHt1cGxvYWRkaXJ9LyR7bmFtZX0uemlwYFxyXG4gICAgICAgICAgY29uc3Qgb3V0cHV0ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbSh6aXBuYW1lKVxyXG4gICAgICAgICAgemlwLnBpcGUob3V0cHV0KVxyXG4gICAgICAgICAgemlwLmRpcmVjdG9yeShjZCwgZmFsc2UpXHJcbiAgICAgICAgICB6aXAuZmluYWxpemUoKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgIC8vIGl0ZW3jgavlrprnvqnjgZXjgozjgabjgYTjgovmnIDkvY7lv4XopoHlnKjluqvjgojjgorlpJrjgYTllYblk4HjgpLlh7rlk4HjgZnjgotcclxuICAgICAgICAgICAgaWYgKHF1YW50aXR5ID49IGl0ZW0ubWFsbC55YXVjdC5taW5RdWFudGl0eSkge1xyXG4gICAgICAgICAgICAgIGxldCB5YXVjdCA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtWWF1Y3QoY29uZmlnLmRlZmF1bHQsIGl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgcGFja2V0LnN1Ym1pdCh7eWF1Y3Q6IHlhdWN0LCBpdGVtOiBpdGVtfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHBhY2tldC5jbG9zZSgpXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCAnLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MnXHJcblxyXG5pbXBvcnQgJy4vcm91dGUvdXBsb2FkL2ltYWdlJ1xyXG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcclxuXHJcbmV4cG9ydCBjb25zdCBDb25maWdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NvbmZpZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuXHJcbi8vIE1ldGVvci5tZXRob2RzKHtcclxuLy8gICBhc3luYyAnbXlzcWxTZXJ2ZXJzLmluc2VydCcgKCBuZXdTZXJ2ZXIgKXtcclxuLy8gICAgIHJldHVybiBhd2FpdCBNeXNxbFNlcnZlcnMuaW5zZXJ0KG5ld1NlcnZlcik7XHJcbi8vICAgfVxyXG4vLyB9KTtcclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXHJcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnO1xyXG5pbXBvcnQgbW9iamVjdCBmcm9tICdtb25nb29iamVjdCc7XHJcbmltcG9ydCB7IEdyb3VwQmFzZSB9IGZyb20gJy4vZ3JvdXBzJztcclxuXHJcbmNvbnN0IEZpbHRlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZmlsdGVycycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgRmlsdGVyIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZmlsdGVySWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEZpbHRlcnMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZmlsdGVySWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuXHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoIG9uUmVzdWx0ID0gKHJlY29yZCk9Pnt9LCBvbkVycm9yID0gKGUpPT57fSApID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbGF0Zm9ybSB0eXBlJyk7XHJcblxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHt7IGZpbHRlclR5cGU6IGFzeW5jIChyZWNvcmQgKSA9PiB7fSB9fSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGFzeW5jIGZvcmVhY2goY2FsbGJhY2tzID0ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZSgpO1xyXG5cclxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXHJcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XHJcbiAgICAgIHR5cGU6ICdtaXNjJyxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBjb3VudCA9IHt9O1xyXG4gICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICBjb3VudFtmaWx0ZXIudHlwZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGZpbHRlci5xdWVyeSxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkKT0+e1xyXG4gICAgICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgICAgIGxldCBxdWVyeSA9IG1vYmplY3QudW5lc2NhcGUoZmlsdGVyLnF1ZXJ5KTtcclxuICAgICAgICAgIGxldCBleGFtID0gc2lmdCggcXVlcnkgKTtcclxuICAgICAgICAgIGlmKCBleGFtKHJlY29yZCkgKXtcclxuICAgICAgICAgICAgY291bnRbZmlsdGVyLnR5cGVdLmNvdW50Kys7XHJcbiAgICAgICAgICAgIGlmKCB0eXBlb2YgY2FsbGJhY2tzW2ZpbHRlci50eXBlXSAhPT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0ocmVjb3JkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIG9uRXJyb3JcclxuICAgICk7XHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudDtcclxuXHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuY29uc3QgR3JvdXBzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2dyb3VwcycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXBCYXNlIHtcclxuXHJcbiAgcHJvZmlsZTtcclxuXHJcbiAgY29uc3RydWN0b3IocHJvZmlsZSkge1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGdldHMgJ1BsdWcnIHdpdGNoIGlzIGEgc2V0IG9mIHByb3BlcnRpZXMgbmVlZGVkXHJcbiAgICogd2hlbiBjb25uZWN0IHRvIHNvbWUgcGxhdGZvcm1zXHJcbiAgICogdG8gZ2V0IGRhdGFzKE1lbWJlcnMgb2YgdGhlIEdyb3VwKVxyXG4gICAqL1xyXG4gIGdldFBsdWcoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlLnBsYXRmb3JtUGx1ZztcclxuICB9XHJcblxyXG4gIGdldFByb2ZpbGUoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7fTtcclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cCBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGdyb3VwSWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEdyb3Vwcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBncm91cElkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoZG9jKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfSBXSEVSRSBcXGAke2RvYy5rZXl9XFxgID0gXCIke2RvYy5pZH1cImA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIGdyb3VwIHR5cGUnKTtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHthc3luYyAocmVjb3JkKT0+dm9pZH0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgY3VyID0gR3JvdXBzLmZpbmQoe1xyXG4gICAgICBncm91cElkOiB0aGlzLnByb2ZpbGUuX2lkXHJcbiAgICB9LCB7XHJcbiAgICAgIGZpZWxkczoge1xyXG4gICAgICAgIF9pZDogMCxcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICBrZXk6IDFcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY3VyLmZvckVhY2goXHJcbiAgICAgICAgICBhc3luYyAoZG9jLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZWNvcmQgPSBhd2FpdCB0aGlzLmltcG9ydChkb2MpO1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBvbkVycm9yKGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpbmRleCArIDEgPT09IGN1ci5jb3VudCgpKSB7XHJcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgIH1cclxuICAgICkuY2F0Y2goXHJcbiAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgfVxyXG5cclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbG9ncycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbiBcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2Fkcycse2lkR2VuZXJhdGlvbjonTU9OR08nfSk7XHJcblxyXG4iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5cclxuZXhwb3J0IGNsYXNzIEN1YmUzQXBpIHtcclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7TXlTUUx9IG15c3FsXHJcbiAgICovXHJcbiAgY29uc3RydWN0b3IgKG15c3FsKSB7XHJcbiAgICB0aGlzLm15c3FsXyA9IG15c3FsXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9jayAocHJvZHVjdENsYXNzSWQsIHF1YW50aXR5ID0gMCkge1xyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIGBwcm9kdWN0X2NsYXNzX2lkID0gJHtwcm9kdWN0Q2xhc3NJZH1gLFxyXG4gICAgICB7fSwge1xyXG4gICAgICAgIHN0b2NrOiBxdWFudGl0eSxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcclxuICAgICAge30sIHtcclxuICAgICAgICBzdG9jazogcXVhbnRpdHksXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdFRhZ1VwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSBbXVxyXG5cclxuICAgIC8vIOWJiumZpOOBmeOCi+OCv+OCsFxyXG4gICAgbGV0IHRhZ29mZiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgbGV0IHNxbCA9IGBcclxuICAgICAgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfdGFnIFxyXG4gICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9IEFORCB0YWcgPSAke3RhZ31cclxuICAgICAgYFxyXG4gICAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOihqOekuuOBmeOCi+OCv+OCsFxyXG4gICAgbGV0IHRhZ29uID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICAvLyDjgZnjgafjgavooajnpLrjgZXjgozjgabjgYTjgovjgr/jgrDjgYzjgYLjgozjgbDkvZXjgoLjgZfjgarjgYRcclxuICAgICAgbGV0IHNxbCA9IGBcclxuICAgICAgU0VMRUNUIENPVU5UKCopIEZST00gZHRiX3Byb2R1Y3RfdGFnIFxyXG4gICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9IEFORCB0YWcgPSAke3RhZ31cclxuICAgICAgYFxyXG4gICAgICBsZXQgY291bnRSZXMgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpXHJcbiAgICAgIGlmIChjb3VudFJlc1swXVsnQ09VTlQoKiknXSkgcmV0dXJuXHJcblxyXG4gICAgICByZXMucHVzaChcclxuICAgICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAgICdkdGJfcHJvZHVjdF90YWcnLFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGRhdGEucHJvZHVjdF9pZCxcclxuICAgICAgICAgICAgdGFnOiB0YWcsXHJcbiAgICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICAgIH1cclxuICAgICAgICApKVxyXG4gICAgfVxyXG5cclxuICAgIGZvciAobGV0IHRhZ1NldCBvZiBkYXRhLnRhZ3MpIHtcclxuICAgICAgc3dpdGNoICh0YWdTZXQuc2V0KSB7XHJcbiAgICAgICAgY2FzZSAnb24nOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb24odGFnU2V0LnRhZylcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgY2FzZSAnb2ZmJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29mZih0YWdTZXQudGFnKVxyXG4gICAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0SW1hZ2VVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCBwcm9kdWN0SWQgPSBkYXRhLnByb2R1Y3RfaWRcclxuICAgIGxldCBpbWFnZXMgPSBkYXRhLmltYWdlc1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSBbXVxyXG5cclxuICAgIC8vIOWVhuWTgeOBq+mWoumAo+OBmeOCi+OBmeOBueOBpuOBrueUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi1xyXG4gICAgbGV0IHNxbCA9IGBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF9pbWFnZSBXSEVSRSBwcm9kdWN0X2lkID0gJHtwcm9kdWN0SWR9YFxyXG4gICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSlcclxuXHJcbiAgICAvLyDmlLnjgoHjgabnlLvlg4/jgpLnmbvpjLLjgZfjgarjgYrjgZlcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICdkdGJfcHJvZHVjdF9pbWFnZScsIHtcclxuICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcclxuICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICAgIGZpbGVfbmFtZTogaW1hZ2VzW2ldLFxyXG4gICAgICAgICAgcmFuazogaSArIDFcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBsZXQga2V5cyA9IFtdXHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RcclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnc3RhdHVzJyxcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnbm90ZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9saXN0JyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXHJcbiAgICAgICdzZWFyY2hfd29yZCcsXHJcbiAgICAgICdmcmVlX2FyZWEnXHJcbiAgICBdXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBkdGJfcHJvZHVjdF9jbGFzc1xyXG5cclxuICAgIHVwZGF0ZURhdGEgPSB7fVxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ2RlbGl2ZXJ5X2RhdGVfaWQnLFxyXG4gICAgICAncHJvZHVjdF9jb2RlJyxcclxuICAgICAgJ3NhbGVfbGltaXQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJyxcclxuICAgICAgJ2RlbGl2ZXJ5X2ZlZSdcclxuICAgIF1cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdENyZWF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSB7fVxyXG5cclxuICAgIGxldCB1cGRhdGVEYXRhID0ge31cclxuICAgIGxldCBrZXlzID0gW11cclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnbmFtZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnXHJcbiAgICBdXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgIC8vICAgZGVzY3JpcHRpb25fZGV0YWlsOiBpdGVtLmRlc2NyaXB0aW9uLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBzdGF0dXM6IDEsXHJcbiAgICAgICAgbm90ZTogJ05VTEwnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uX2xpc3Q6ICdOVUxMJyxcclxuICAgICAgICBzZWFyY2hfd29yZDogJ05VTEwnLFxyXG4gICAgICAgIGZyZWVfYXJlYTogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICB1cGRhdGVEYXRhID0ge31cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAncHJvZHVjdF90eXBlX2lkJyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIHByb2R1Y3RfY29kZTogaXRlbS5tb2RlbCxcclxuICAgIC8vICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAvLyAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9jbGFzc19pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHByb2R1Y3RfaWQ6IHJlcy5wcm9kdWN0X2lkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDE6ICdOVUxMJyxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDI6ICdOVUxMJyxcclxuICAgICAgICBkZWxpdmVyeV9kYXRlX2lkOiAnTlVMTCcsXHJcbiAgICAgICAgc2FsZV9saW1pdDogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3Rfc3RvY2tfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJywge30sIHtcclxuICAgICAgICBwcm9kdWN0X2NsYXNzX2lkOiByZXMucHJvZHVjdF9jbGFzc19pZCxcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgc3RvY2s6IDAsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIGZvciB0ZXN0XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNb25nb0NsaWVudH0gZnJvbSAnbW9uZ29kYidcclxuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCdcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnXHJcbmltcG9ydCB7IHhtbDJqcyB9IGZyb20gJ3htbC1qcydcclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlckZhY3Rvcnkge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBsZXQgaW5zdGFuY2VcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICBpbnN0YW5jZSA9IG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGluc3RhbmNlXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnXHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlXHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZmFjdG9yeSAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHJldHVybiBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKVxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbHVnIHR5cGUnKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0UGx1Z18gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Z1xyXG4gIH1cclxuXHJcbiAgZ2V0Q3JlZF8gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Zy5jcmVkXHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlXHJcbiAgfVxyXG5cclxuICBzZXRJbXBvcnRGdW5jdGlvbl8gKFxyXG4gICAgZm4gPSBhc3luYyAob25SZXN1bHQgPSByZWNvcmQgPT4ge30sIG9uRXJyb3IgPSBlID0+IHt9KSA9PiB7fVxyXG4gICkge1xyXG4gICAgdGhpcy5pbXBvcnQgPSBmblxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogdXNlYWdlOlxyXG4gICAqXHJcbiAgICpcclxuICAgKiBAcGFyYW0geyBPYmplY3QgfSBpdGVyYXRvcnMgeyBmaWx0ZXJOYW1lOiBhc3luYyAoZG9jLGNvbnRleHQpPT57fSwgLi4uIH0gaXRlcmF0b3IgZm9yIGVhY2ggZmlsdGVyc1xyXG4gICAqIEBwYXJhbSB7IGFzeW5jIGZ1bmN0aW9uIH0gb25FcnJvciBlcnJvciBoYW5kbGVyIHdoaWxlIGl0ZXJhdGluZ1xyXG4gICAqIEByZXR1cm5zIHsgT2JqZWN0IH0geyBmaWx0ZXJOYW1lOiB7IHF1ZXJ5OiBhbnksIGNvdW50OiBudW1iZXIgfSwgLi4uIH1cclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoIChpdGVyYXRvcnMgPSB7fSkge1xyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGVfKClcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICBuYW1lOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnRlciA9IHt9XHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBmaWx0ZXJzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgICBjb3VudGVyW2YubmFtZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGYucXVlcnksXHJcbiAgICAgICAgbGltaXQ6IHR5cGVvZiBmLmxpbWl0ICE9PSAndW5kZWZpbmVkJyA/IGYubGltaXQgOiAwLFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH1cclxuICAgICAgZmlsdGVycy5wdXNoKFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6IGYubmFtZSxcclxuICAgICAgICAgIGV4YW06IHNpZnQobW9iamVjdC51bmVzY2FwZShmLnF1ZXJ5KSlcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgIGZvciAobGV0IGYgb2YgZmlsdGVycykge1xyXG4gICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXHJcbiAgICAgICAgICBsZXQgYyA9IGNvdW50ZXJbZi5uYW1lXVxyXG4gICAgICAgICAgaWYgKGMubGltaXQpIHtcclxuICAgICAgICAgICAgaWYgKGMuY291bnQgPj0gYy5saW1pdCkge1xyXG4gICAgICAgICAgICAgIGNvbnRpbnVlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZi5leGFtKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXHJcbiAgICAgICAgICAgIGMuY291bnQrK1xyXG5cclxuICAgICAgICAgICAgLy8gaXRlcmF0b3JcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVyYXRvcnNbZi5uYW1lXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICBhd2FpdCBpdGVyYXRvcnNbZi5uYW1lXShyZWNvcmQsIGNvbnRleHQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudGVyXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTXlzcWxEQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKVxyXG5cclxuICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwoY3JlZClcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWBcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgKGUpID0+IHsgdGhyb3cgZSB9KVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuLy8gaW1wb3J0IE1vbmdvTmF0aXZlIGZyb20gJ21vbmdvZGInO1xyXG4vLyBjb25zdCBNb25nb0NsaWVudCA9IE1vbmdvTmF0aXZlLk1vbmdvQ2xpZW50O1xyXG4vLyBjb25zdCBNb25nb0NsaWVudCA9IHJlcXVpcmUoJ21vbmdvZGInKS5Nb25nb0NsaWVudDtcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKVxyXG5cclxuICAgIC8vIG1vbmdvIOOBuOaOpee2mlxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBjbGllbnRcclxuICAgICAgY2xpZW50ID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSlcclxuXHJcbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xyXG4gICAgICBsZXQgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSlcclxuICAgICAgbGV0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbilcclxuXHJcbiAgICAgIGxldCBjb250ZXh0ID0ge1xyXG4gICAgICAgIGNsaWVudDogY2xpZW50LFxyXG4gICAgICAgIGNvbGxlY3Rpb246IGNvbGxlY3Rpb24sXHJcbiAgICAgICAgZGF0YWJhc2U6IGRiXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKVxyXG5cclxuICAgICAgLy8g44Kr44O844K944Or44Gu44K/44Kk44Og44Ki44Km44OI44KS6Kej6ZmkXHJcbiAgICAgIGN1ci5hZGRDdXJzb3JGbGFnKCdub0N1cnNvclRpbWVvdXQnLCB0cnVlKVxyXG5cclxuICAgICAgLy8g44GZ44G544Gm44Gu44OJ44Kt44Ol44Oh44Oz44OI44KS44Or44O844OXXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgICAgIGxldCBkb2MgPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgICAgICBhd2FpdCBvblJlc3VsdChkb2MsIGNvbnRleHQpXHJcbiAgICAgICAgfTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAvLyDjgqvjg7zjgr3jg6vjgpLplovmlL5cclxuICAgICAgICBhd2FpdCBjdXIuY2xvc2UoKVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIFdvd21hQXBpSXRlbUZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICAvLyDllYblk4Hmg4XloLHjga7lj5blvpfjg6vjg7zjg5fjgpLlrprnvqlcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcclxuICAgICAgbGV0IG9wdGlvbnMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHBsdWcpKVxyXG4gICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hTdG9ja3NgXHJcbiAgICAgIGxldCBjb250ZXh0ID0ge1xyXG4gICAgICAgIG9wdGlvbnM6IG9wdGlvbnNcclxuICAgICAgfVxyXG5cclxuICAgICAgd2hpbGUgKDEpIHtcclxuICAgICAgICAvLyBXb3dtYSBBcGkg44GL44KJ5ZWG5ZOB5oOF5aCx44KS5Y+W5b6XXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3Qob3B0aW9ucylcclxuICAgICAgICByZXMgPSB4bWwyanMocmVzLCB7Y29tcGFjdDogdHJ1ZX0pXHJcblxyXG4gICAgICAgIGxldCBtYXhDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0Lm1heENvdW50Ll90ZXh0KVxyXG4gICAgICAgIGxldCByZXN1bHRDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0LnJlc3VsdENvdW50Ll90ZXh0KVxyXG4gICAgICAgIGxldCBzdGFydENvdW50ID0gTnVtYmVyKHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQuc3RhcnRDb3VudC5fdGV4dClcclxuICAgICAgICBsZXQgcmVzdWx0U3RvY2tzID0gcmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5yZXN1bHRTdG9ja3NcclxuXHJcbiAgICAgICAgLy8g5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS44Kr44K544K/44Og44OX44Ot44K744K544Gr5rih44GZXHJcbiAgICAgICAgaWYgKHJlc3VsdFN0b2NrcyBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICAgICAgICAvLyDlj5blvpfjgZfjgZ/jg4fjg7zjgr/jgYzopIfmlbDllYblk4Hjga7loLTlkIhcclxuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0Q291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICBhd2FpdCBvblJlc3VsdChyZXN1bHRTdG9ja3NbaV0sIGNvbnRleHQpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIOWPluW+l+OBl+OBn+ODh+ODvOOCv+OBjOWNmOaVsOWVhuWTgeOBruWgtOWQiFxyXG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQocmVzdWx0U3RvY2tzLCBjb250ZXh0KVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG5leHQgPSBzdGFydENvdW50ICsgcmVzdWx0Q291bnRcclxuXHJcbiAgICAgICAgaWYgKG5leHQgPiBtYXhDb3VudCkgYnJlYWtcclxuICAgICAgICBvcHRpb25zLnFzLnN0YXJ0Q291bnQgPSBuZXh0XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbi8vICAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xyXG4vLyAgICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XHJcblxyXG4vLyAgICAgLy8gbW9uZ28g44G45o6l57aaXHJcbi8vICAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuLy8gICAgIGxldCBjb251cmkgPSBgbW9uZ29kYjovLyR7Y3JlZC5ob3N0fToke2NyZWQucG9ydH0vJHtjcmVkLmRhdGFiYXNlfWA7XHJcbi8vICAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KGNvbnVyaSk7XHJcblxyXG4vLyAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5L2c44KLXHJcbi8vICAgICBsZXQgY29sbGVjdGlvbiA9IG1vbmdvb3NlLmNvbm5lY3Rpb24uY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG5cclxuLy8gICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4vLyAgICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XHJcblxyXG4vLyAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH1cclxuLy8gfVxyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvQ29sbGVjdGlvblxyXG59IGZyb20gJy4uL3V0aWwvbW9uZ28nXHJcbmltcG9ydCB7XHJcbiAgVXBsb2Fkc1xyXG59IGZyb20gJy4uL2NvbGxlY3Rpb24vdXBsb2FkcydcclxuaW1wb3J0IHtcclxuICBPYmplY3RJRFxyXG59IGZyb20gJ2Jzb24nXHJcbmltcG9ydCBUZXh0VXRpbCBmcm9tICcuLi91dGlsL3RleHQnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtQ29udHJvbGxlciB7XHJcbiAgYXN5bmMgaW5pdCAocGx1Zykge1xyXG4gICAgdGhpcy5JdGVtcyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ2l0ZW1zJylcclxuICAgIHRoaXMuUHJvZHVjdHMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdwcm9kdWN0cycpXHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTdG9jayAoaXRlbUlkKSB7XHJcbiAgICBsZXQgaXRlbSA9IGF3YWl0IHRoaXMuSXRlbXMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogaXRlbUlkXHJcbiAgICB9LCB7XHJcbiAgICAgIHByb2plY3Rpb246IHtcclxuICAgICAgICAncHJvZHVjdCc6IDFcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIGxldCBwcm9kdWN0U2V0ID0gaXRlbS5wcm9kdWN0XHJcblxyXG4gICAgLy8gcHJvZHVjdCAqIDwtPiAqIGl0ZW1cclxuICAgIC8vIHByb2R1Y3RbXTog6KSH5pWw44Gu5ZWG5ZOB44KSMeODkeODg+OCseODvOOCuOOBqOOBl+OBpuiyqeWjslxyXG4gICAgLy8gcHJvZHVjdFt7aWRzOls8T2JqZWN0SWQ+XSxzZXQ6PE51bWJlcj59XTog55Ww44Gq44KL5rWB6YCa57WM6Lev44CB55Ww44Gq44KL5Y6f5L6h44O75LuV5YWl44KM5YCkXHJcbiAgICAvLyBpdGVtOiDnlbDjgarjgovjgrvjg7zjg6vjgIHosqnlo7LlvaLmhYtcclxuICAgIC8vIOKAuyBwcm9kdWN0IOOBi+OCieOBr+OAgeiyqeWjsuWPr+iDveOBquWcqOW6q+OAgeWIqeebiuioiOeul+OBruOBn+OCgeOBruaDheWgseOCkuW+l+OCi1xyXG5cclxuICAgIGxldCBxdWFudGl0aWVzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBwcm9kdWN0UmVmIG9mIHByb2R1Y3RTZXQpIHtcclxuICAgICAgbGV0IHByZFF1YW50aXR5ID0gMFxyXG5cclxuICAgICAgZm9yIChsZXQgaWQgb2YgcHJvZHVjdFJlZi5pZHMpIHtcclxuICAgICAgICBsZXQgcHJvZHVjdCA9IGF3YWl0IHRoaXMuUHJvZHVjdHMuZmluZE9uZSh7XHJcbiAgICAgICAgICBfaWQ6IGlkXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgICAnc3RvY2snOiAxXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBsZXQgc3RvY2tBcnJheSA9IHByb2R1Y3Quc3RvY2tcclxuXHJcbiAgICAgICAgLy8g5Y2Y57SU44Gr44GZ44G544Gm44Gu5Zyo5bqr5ZWG5ZOB44CB55+t5pyf6ZaT5Y+W44KK5a+E44Gb5Y+v6IO95ZWG5ZOB44KS5ZCI566XXHJcbiAgICAgICAgZm9yIChsZXQgc3RvY2sgb2Ygc3RvY2tBcnJheSkge1xyXG4gICAgICAgICAgcHJkUXVhbnRpdHkgKz0gc3RvY2sucXVhbnRpdHlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIOWVhuWTgShpdGVtKeOBruWcqOW6q+aVsCA9IOijveWTgeWcqOW6q+aVsChwcmRRdWFudGl0eSkgLyDlv4XopoHjgrvjg4Pjg4jmlbAocHJvZHVjdFJlZi5zZXQpXHJcbiAgICAgIHF1YW50aXRpZXMucHVzaChNYXRoLmZsb29yKHByZFF1YW50aXR5IC8gcHJvZHVjdFJlZi5zZXQpKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCu+ODg+ODiOWVhuWTgeOBruWgtOWQiOOAgeS4gOeVquWwkeOBquOBhOWVhuWTgeaVsOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IHF1YW50aXR5ID0gTWF0aC5taW4uYXBwbHkobnVsbCwgcXVhbnRpdGllcylcclxuXHJcbiAgICByZXR1cm4gcXVhbnRpdHlcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgovjgIJcclxuICAgKlxyXG4gICAqIOODoeODvOOCq+ODvOODouODh+ODq+OBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog54m55a6a44Gu5bGe5oCn77yI44Kr44Op44O844Gq44Gp77yJ44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXHJcbiAgICogY2xhc3Mx44Gr5YCk44KS5oyH5a6a44GX44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXHJcbiAgICog44KC44GXY2xhc3My44Gu44G/5oyH5a6a44GX44Gf44GE5aC05ZCI44GvY2xhc3Mx44GrbnVsbOOCkuaMh+WumuOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog5L6L77yaSkstMTAw44GuQkxBQ0vjga7llYblk4HnlLvlg4/jgpJcclxuICAgKiDjgZnjgbnjgabjga7jgrXjgqTjgrrvvIhTLE0sTCxYTCwyWEwsM1hMLDRYTOKApu+8ieOBq+mWoumAo+S7mOOBkeOCi+WgtOWQiFxyXG4gICAqIHNldEltYWdlKCB1cGxvYWRJZCwgJ0pLLTEwMCcsICdCTEFDSycgKTtcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB1cGxvYWRJZCDkuIDlm57jga7jgqLjg4Pjg5fjg63jg7zjg4nnlLvlg4/jgpLmnZ/jga3jgabjgYTjgotJROOAgm1ldGVvcuODh+ODvOOCv+ODmeODvOOCueOAgVVwbG9hZHPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjg4njgq3jg6Xjg6Hjg7Pjg4jjga51cGxvYWRJZOODl+ODreODkeODhuOCo1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgc2V0SW1hZ2UgKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44Gu5oOF5aCx5Y+W5b6XXHJcbiAgICBsZXQgaW1hZ2VzID0gVXBsb2Fkcy5maW5kKHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkXHJcbiAgICB9KS5mZXRjaCgpLm1hcCgodikgPT4gdi51cGxvYWRlZEZpbGVOYW1lKVxyXG5cclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlciwge1xyXG4gICAgICAgICRwdXNoOiB7XHJcbiAgICAgICAgICBpbWFnZXM6IHtcclxuICAgICAgICAgICAgJGVhY2g6IGltYWdlc1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIOeZu+mMsuOBl+OBn+eUu+WDj+ODleOCoeOCpOODq+WQjeS4gOimp1xyXG4gICAgcmV0dXJuIGltYWdlc1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+eZu+mMsuOBleOCjOOBpuOBhOOCi+eUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKi9cclxuICBhc3luYyBjbGVhbkltYWdlIChtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge31cclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsXHJcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxXHJcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLCB7XHJcbiAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44Gu5ZWG5ZOB44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gu5bGe5oCn5Yil44Gu5ZWG5ZOB5oOF5aCx44KS6L+U44GZ44CCXHJcbiAgICpcclxuICAgKiDlvJXmlbDjgajjgZfjgablj5fjgZHlj5bjgotpdGVt44Gv5Lu75oSP44Gu5ZWG5ZOB5oOF5aCx44CCXHJcbiAgICogaXRlbeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBq+OBpOOBhOOBpuW/heimgeOBquaDheWgseOCkuaVtOeQhuOBl+i/lOOBmeOAglxyXG4gICAqXHJcbiAgICogcHJvamVjdOOBq+WPgueFp+OBl+OBn+OBhOWVhuWTgeaDheWgseODleOCo+ODvOODq+ODieOCkuWumue+qeOBmeOCi+OAglxyXG4gICAqIOODoeOCveODg+ODieOBruWRvOOBs+WHuuOBl+aZguOBq+W/heimgeOBq+W/nOOBmOOBpnByb2plY3TjgpLoqK3lrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS9leOBq+azqOebruOBl+OBpuWVhuWTgeOBrumWoumAo+aAp+OCkuaknOWHuuOBmeOCi+OBi+OBr+OAgeOBk+OBruODoeOCveODg+ODieWGheOBp+Wumue+qeOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGl0ZW1cclxuICAgKiBAcGFyYW0ge09iamVjdH0gcHJvamVjdFxyXG4gICAqL1xyXG4gIGFzeW5jIGdldFZhcmlhdGlvbiAoaXRlbSwgcHJvamVjdCkge1xyXG4gICAgLyoqXHJcbiAgICAgKiBhZ2dyZWdhdGlvbuioreWumlxyXG4gICAgICpcclxuICAgICAqIGxhYmVsOiDlsZ7mgKflkI3vvIjphY3pgIHmlrnms5XjgIHjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganvvIlcclxuICAgICAqIGN1cnJlbnQ6IOaMh+WumuOBleOCjOOBn+OCouOCpOODhuODoO+8iGl0ZW3vvInjgYzoqbLlvZPjgZnjgovpoIXnm65cclxuICAgICAqIHBvcmplY3Q6IOODkOODquOCqOODvOOCt+ODp+ODs+aknOe0ouOBruOCreODvOOBqOOBquOCi2l0ZW3lhoXjga7jg5XjgqPjg7zjg6vjg4nlkI0gJFvjg5XjgqPjg7zjg6vjg4nlkI1d5b2i5byPXHJcbiAgICAgKiBxdWVyeTogYWdncmVnYXRpb27lr77osaHjgajjgZnjgovjg4njgq3jg6Xjg6Hjg7Pjg4jjga7mpJzntKLmnaHku7ZcclxuICAgICAqL1xyXG4gICAgbGV0IHNldCA9IFt7XHJcbiAgICAgIGxhYmVsOiAn6YWN6YCB5pa55rOVJyxcclxuICAgICAgY3VycmVudDogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgIHZhbHVlOiAnJGRlbGl2ZXJ5J1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogaXRlbS5jbGFzczFfbmFtZSxcclxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRjbGFzczFfdmFsdWUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogaXRlbS5jbGFzczJfbmFtZSxcclxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczJfdmFsdWUsXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRjbGFzczJfdmFsdWUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgICAgY2xhc3MxX3ZhbHVlOiBpdGVtLmNsYXNzMV92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBdXHJcblxyXG4gICAgbGV0IGF0dHJzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBzIG9mIHNldCkge1xyXG4gICAgICBhdHRycy5wdXNoKHtcclxuICAgICAgICB2YXJpYXRpb25zOiBhd2FpdCB0aGlzLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFt7XHJcbiAgICAgICAgICAgICRtYXRjaDogT2JqZWN0LmFzc2lnbihzLnF1ZXJ5LCB7XHJcbiAgICAgICAgICAgICAgbW9kZWw6IGl0ZW0ubW9kZWxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICRwcm9qZWN0OiBPYmplY3QuYXNzaWduKHMucHJvamVjdCwgcHJvamVjdClcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICRzb3J0OiB7XHJcbiAgICAgICAgICAgICAgX2lkOiAxXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIF1cclxuICAgICAgICApLnRvQXJyYXkoKSxcclxuICAgICAgICBwcm9wczogc1xyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIGZvciAobGV0IGF0dHIgb2YgYXR0cnMpIHtcclxuICAgICAgZm9yIChsZXQgdiBvZiBhdHRyLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICB2LnN0b2NrID0gYXdhaXQgdGhpcy5nZXRTdG9jayh2Ll9pZClcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBhdHRyc1xyXG4gIH1cclxuXHJcbiAgLy8g44Oi44OH44Or44Kv44Op44K55b2i5byP44KS5L2c44KLXHJcbiAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gIGFzeW5jIGdldE1vZGVsQ2xhc3MgKGFyZykge1xyXG4gICAgbGV0IGl0ZW1cclxuICAgIC8vIGl0ZW0g44GM5paH5a2X5YiX44Gq44KJ44CBaXRlbeOBr+S7u+aEj+OBruOCquODluOCuOOCp+OCr+ODiElE44Gu5pyr5bC+44GL44KJ5Lu75oSP44Gu5qGB5pWw44GuMTbpgLLmlbBcclxuICAgIGlmICh0eXBlb2YgYXJnID09PSAnc3RyaW5nJykge1xyXG4gICAgICBsZXQgZXhwID0gbmV3IFJlZ0V4cChgJHthcmd9JGApXHJcbiAgICAgIGxldCBjdXIgPSB0aGlzLkl0ZW1zLmZpbmQoe30sIHtcclxuICAgICAgICBwcm9qZWN0aW9uOiB7XHJcbiAgICAgICAgICBtb2RlbDogMSxcclxuICAgICAgICAgIGNsYXNzMV92YWx1ZTogMSxcclxuICAgICAgICAgIGNsYXNzMl92YWx1ZTogMVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICAgIHdoaWxlICgxKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgICAgICBsZXQgbWF0Y2ggPSBhd2FpdCBpdGVtLl9pZC50b0hleFN0cmluZygpLm1hdGNoKGV4cClcclxuICAgICAgICAgIGlmIChtYXRjaCkge1xyXG4gICAgICAgICAgICBicmVha1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIC8vIOipsuW9k+OBmeOCi2l0ZW3jg4fjg7zjgr/jgYzjgarjgYRcclxuICAgICAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICAgICAgICByZXR1cm4gYXJnXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpdGVtID0gYXJnXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuICAgIHJldHVybiBtb2RlbENsYXNzLmpvaW4oJy8nKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlMyAoY3JlYXRvcklkLCBpdGVtKSB7XHJcbiAgICAvLyDlgKTlpInmj5tcclxuICAgIGxldCBjb252RGVsaXYgPSAoZGVsaXZlcnkpID0+IGRlbGl2ZXJ5ID09PSAn44KG44GG44OR44Kx44OD44OIJyA/ICfjg53jgrnjg4jmipXlh70nIDogZGVsaXZlcnlcclxuXHJcbiAgICAvLyBwcm9kdWN0X2lkXHJcbiAgICBsZXQgcHJvZHVjdElkID0gbnVsbFxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG5cclxuICAgIC8vIOS4i+iomOOBruW9ouW8j+OCkuS9nOOCi1xyXG4gICAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuXHJcbiAgICAvLyDllYblk4HnqK7liKXjgpLlibLjgorlvZPjgabjgotcclxuICAgIGxldCBwcm9kdWN0VHlwZUlkXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDJcclxuICAgICAgICBicmVha1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCB0YWdzID0gW11cclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeWIpemAgeaWmeOCkuioreWumuOBmeOCi1xyXG4gICAgbGV0IGRlbGl2ZXJ5RmVlID0gbnVsbFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBudWxsXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICBkZWxpdmVyeUZlZSA9IDI0MFxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy9cclxuICAgIC8vIOmhp+WuouWQkeOBkeODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgemBuOaKnuapn+iDveOBruWun+ijhVxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6ICckbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJ1xyXG4gICAgfSlcclxuXHJcbiAgICAvLyBIVE1MIOODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgeOBlOOBqOOBruODquODs+OCr+S7mOOBjeODnOOCv+ODs+OCkuihqOekuuOBmeOCi1xyXG5cclxuICAgIC8vIOWApOOBruWkieaPm1xyXG4gICAgYXR0cnMgPSBhdHRycy5tYXAoXHJcbiAgICAgIChhdHRyKSA9PiB7XHJcbiAgICAgICAgYXR0ci5wcm9wcy5jdXJyZW50ID0gY29udkRlbGl2KGF0dHIucHJvcHMuY3VycmVudClcclxuICAgICAgICBhdHRyLnZhcmlhdGlvbnMgPSBhdHRyLnZhcmlhdGlvbnMubWFwKFxyXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xyXG4gICAgICAgICAgICB2YXJpYXRpb24udmFsdWUgPSBjb252RGVsaXYodmFyaWF0aW9uLnZhbHVlKVxyXG4gICAgICAgICAgICByZXR1cm4gdmFyaWF0aW9uXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIHJldHVybiBhdHRyXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBIVE1M55Sf5oiQXHJcbiAgICBsZXQgdmFyaWF0aW9uSHRtbCA9XHJcbiAgICAgIGF0dHJzLm1hcChcclxuICAgICAgICAoYXR0cikgPT5cclxuICAgICAgICAgICc8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWZsdWlkXCI+JyArXHJcbiAgICAgICAgYDxkaXYgY2xhc3M9XCJyb3dcIj5gICtcclxuICAgICAgICBgPGRpdiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLWJsb2NrIGJ0bi14c1wiPmAgK1xyXG4gICAgICAgIGA8c3Ryb25nPiR7YXR0ci5wcm9wcy5sYWJlbH08L3N0cm9uZz5gICtcclxuICAgICAgICBgPC9kaXY+YCArXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgaWYgKGF0dHIucHJvcHMuY3VycmVudCA9PT0gdmFyaWF0aW9uLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgLy8g6KGo56S65Lit44Gu5ZWG5ZOB44Oc44K/44OzXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zdWNjZXNzIGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj48c3Ryb25nPiR7dmFyaWF0aW9uLnZhbHVlfTwvc3Ryb25nPjwvYnV0dG9uPmBcclxuICAgICAgICAgICAgfSBlbHNlXHJcbiAgICAgICAgICAgIGlmICh2YXJpYXRpb24uc3RvY2sgPiAwKSB7XHJcbiAgICAgICAgICAgICAgLy8g6LKp5aOy5Y+v6IO95ZWG5ZOB44Gu44Oc44K/44OzXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YSBocmVmPVwiL3Byb2R1Y3RzL2RldGFpbC8ke3ZhcmlhdGlvbi5wcm9kdWN0X2lkfVwiPjxidXR0b24gY2xhc3M9XCJidG4gYnRuLWRlZmF1bHQgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPiR7dmFyaWF0aW9uLnZhbHVlfTwvYnV0dG9uPjwvYT5gXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgLy8g6LKp5aOy5LiN5Y+v6IO95ZWG5ZOB44Gu44Oc44K/44Oz77yI5Zyo5bqr44Gq44GX77yJXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgZGF0YS10b2dnbGU9XCJ0b29sdGlwXCIgdGl0bGU9XCLlnKjluqvjgYzjgZTjgZbjgYTjgb7jgZvjgpNcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj5gXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApLmpvaW4oJycpICtcclxuICAgICAgICAnPC9kaXY+JyArXHJcbiAgICAgICAgJzwvZGl2PidcclxuICAgICAgKS5qb2luKCcnKVxyXG5cclxuICAgIGxldCBkZXNjcmlwdGlvbkRldGFpbCA9IGBcclxuICAgIDxzbWFsbD7igLsg6YWN6YCB5pa55rOV44O744Kr44Op44O844O744K144Kk44K644Gv5LiL6KiY44GL44KJ44GK6YG444Gz44GP44Gg44GV44GE44CCPC9zbWFsbD5cclxuICAgICR7dmFyaWF0aW9uSHRtbH1cclxuICAgIGBcclxuXHJcbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcclxuICAgIGxldCBkYXRhID0ge1xyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7Y29udkRlbGl2KGl0ZW0uZGVsaXZlcnkpfSAke2l0ZW0ubmFtZX0gJHtpdGVtLmphbl9jb2RlfWAsXHJcbiAgICAgIGRlc2NyaXB0aW9uX2RldGFpbDogZGVzY3JpcHRpb25EZXRhaWwsXHJcbiAgICAgIGZyZWVfYXJlYTogaXRlbS5kZXNjcmlwdGlvbiArICcgJyxcclxuICAgICAgcHJvZHVjdF9jb2RlOiBtb2RlbENsYXNzLmpvaW4oJy8nKSxcclxuICAgICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UgKiAwLjk1LCAvLyDmpb3lpKnkvqHmoLzjgYvjgok1JeWApOW8leOBjVxyXG4gICAgICBpbWFnZXM6IGl0ZW0uaW1hZ2VzLFxyXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RUeXBlSWQsXHJcbiAgICAgIHRhZ3M6IHRhZ3MsXHJcbiAgICAgIGRlbGl2ZXJ5X2ZlZTogZGVsaXZlcnlGZWVcclxuICAgIH1cclxuXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcClcclxuXHJcbiAgICByZXR1cm4gZGF0YVxyXG4gIH1cclxuXHJcbiAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44G444Gu5aSJ5o+bXHJcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdCAoZGVmLCBpdGVtKSB7XHJcbiAgICBjb25zdCBpZExlbmd0aCA9IDIwXHJcbiAgICBjb25zdCB0aXRsZUxlbmd0aCA9IDEzMFxyXG5cclxuICAgIGxldCB5YXVjdCA9IHt9XHJcbiAgICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjga7liJ3mnJ/lgKTvvIjjgobjgYbjg5HjgrHjg4Pjg4jjg7vlroXphY3kvr/jgafnlbDjgarjgovvvIlcclxuICAgIHlhdWN0ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkZWZbaXRlbS5kZWxpdmVyeV0pKVxyXG5cclxuICAgIC8vIOeUu+WDj+OBruiomOi/sFxyXG4gICAgY29uc3QgaW1nUHJlZml4ID0gJ+eUu+WDjydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgeWF1Y3RbaW1nUHJlZml4ICsgKGkgKyAxKV0gPSBpdGVtLmltYWdlc1tpXVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCv+OCpOODiOODq1xyXG4gICAgeWF1Y3RbJ+OCq+ODhuOCtOODqiddID0gaXRlbS5tYWxsLnlhdWN0LmNhdGVnb3J5XHJcbiAgICB5YXVjdFsn44K/44Kk44OI44OrJ10gPSBUZXh0VXRpbC5zdWJzdHI4KGAke2F3YWl0IHRoaXMuZ2V0TW9kZWxDbGFzcyhpdGVtKX0gJHtpdGVtLmRlbGl2ZXJ5fSAke2l0ZW0ubmFtZX1gLCB0aXRsZUxlbmd0aClcclxuICAgIHlhdWN0Wyfplovlp4vkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfljbPmsbrkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfnrqHnkIbnlarlj7cnXSA9IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkuc2xpY2UoLWlkTGVuZ3RoKVxyXG4gICAgeWF1Y3RbJ+iqrOaYjiddID0gaXRlbS5kZXNjcmlwdGlvblxyXG4gICAgeWF1Y3RbJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXSA9IGl0ZW0uamFuX2NvZGVcclxuXHJcbiAgICByZXR1cm4geWF1Y3RcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5pbXBvcnQgeyBqc29uMnhtbCB9IGZyb20gJ3htbC1qcydcclxuaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuLi91dGlsL2Vycm9yJ1xyXG5cclxuY29uc3QgQkFTRV9VUkkgPSAnaHR0cHM6Ly9hcGkubWFuYWdlci53b3dtYS5qcC93bXNob3BhcGknXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBXb3dtYUFwaSB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHNob3BJZCkge1xyXG4gICAgdGhpcy5wbHVnID0gcGx1Z1xyXG4gICAgdGhpcy5zaG9wSWQgPSBzaG9wSWRcclxuICB9XHJcblxyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG4gIGFzeW5jIHVwZGF0ZUl0ZW0gKHVwZGF0ZUl0ZW0pIHtcclxuICAgIGxldCByZXF1ZXN0ID0gYDxyZXF1ZXN0PjxzaG9wSWQ+JHt0aGlzLnNob3BJZH08L3Nob3BJZD48dXBkYXRlSXRlbT4ke2pzb24yeG1sKHVwZGF0ZUl0ZW0sIHtjb21wYWN0OiB0cnVlfSl9PC91cGRhdGVJdGVtPjwvcmVxdWVzdD5gXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5yZXF1ZXN0UG9zdChcclxuICAgICAgICAndXBkYXRlSXRlbUluZm8nLFxyXG4gICAgICAgIHJlcXVlc3RcclxuICAgICAgKVxyXG4gICAgICByZXR1cm4ge3Jlc3BvbnNlOiByZXMsIHJlcXVlc3RYTUw6IHJlcXVlc3R9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIHRocm93IE9iamVjdC5hc3NpZ24odXRpbEVycm9yLnBhcnNlKGUpLCB7cmVxdWVzdFhNTDogcmVxdWVzdH0pXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyByZXF1ZXN0UG9zdCAobWV0aG9kLCBib2R5KSB7XHJcbiAgICAvLyDmjqXntprjgqrjg5fjgrfjg6fjg7Pjga7kvZzmiJBcclxuICAgIGxldCBhcGlSZXF1ZXN0ID0ge1xyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgdXJpOiBgJHtCQVNFX1VSSX0vJHttZXRob2R9YCxcclxuICAgICAgYm9keTogYm9keVxyXG4gICAgfVxyXG4gICAgLy8g5YWx6YCa44Gu5o6l57aa6Kit5a6a44Go57WQ5ZCI44GZ44KLXHJcbiAgICBPYmplY3QuYXNzaWduKGFwaVJlcXVlc3QsIHRoaXMucGx1ZylcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgIGxldCByZXMgPSBhd2FpdCByZXF1ZXN0KGFwaVJlcXVlc3QpXHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHN0b2NrVXBkYXRlSXRlbSkge1xyXG4gICAgLy8g5o6l57aa44Kq44OX44K344On44Oz44Gu5L2c5oiQXHJcbiAgICBsZXQgYXBpUmVxdWVzdCA9IHtcclxuICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgIHVyaTogYCR7QkFTRV9VUkl9L3VwZGF0ZVN0b2NrYFxyXG4gICAgfVxyXG4gICAgLy8g5YWx6YCa44Gu5o6l57aa6Kit5a6a44Go57WQ5ZCI44GZ44KLXHJcbiAgICBPYmplY3QuYXNzaWduKGFwaVJlcXVlc3QsIHRoaXMucGx1ZylcclxuXHJcbiAgICBhcGlSZXF1ZXN0LmJvZHkgPSBhd2FpdCB0aGlzLnVwZGF0ZVN0b2NrQ3JlYXRlUmVxdWVzdEJvZHkoc3RvY2tVcGRhdGVJdGVtKVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3QoYXBpUmVxdWVzdClcclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9ja0NyZWF0ZVJlcXVlc3RCb2R5IChzdG9ja1VwZGF0ZUl0ZW0pIHtcclxuICAgIC8vXHJcbiAgICAvLyBzdG9ja1VwZGF0ZUl0ZW0gPVxyXG4gICAgLy8gW1xyXG4gICAgLy8gICB7XHJcbiAgICAvLyAgICAgaXRlbUNvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgIHZhcmlhdGlvbnM6IFtcclxuICAgIC8vICAgICAgICB7XHJcbiAgICAvLyAgICAgICAgICBjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgICAgICAgc3RvY2s6IDxOdW1iZXI+XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgIF1cclxuICAgIC8vICAgfVxyXG4gICAgLy8gXVxyXG5cclxuICAgIGxldCBzdG9ja1VwZGF0ZUl0ZW1YTUwgPSAnJ1xyXG5cclxuICAgIGZvciAobGV0IGl0ZW0gb2Ygc3RvY2tVcGRhdGVJdGVtKSB7XHJcbiAgICAgIC8vIOWApOOBruODgeOCp+ODg+OCr1xyXG4gICAgICBmb3IgKGxldCBlIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgIC8vIOWcqOW6q+aVsOOBruS4iumZkDEwMFxyXG4gICAgICAgIGlmIChlLnN0b2NrID4gMTAwKSBlLnN0b2NrID0gMTAwXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrVXBkYXRlSXRlbT4nXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPGl0ZW1Db2RlPiR7aXRlbS5pdGVtQ29kZX08L2l0ZW1Db2RlPmBcclxuXHJcbiAgICAgIC8vIOWVhuWTgeWcqOW6q+eoruWIpeOCkuaMr+OCiuWIhuOBkVxyXG4gICAgICAvLyAxIC0+IOmAmuW4uOWVhuWTgVxyXG4gICAgICAvLyAyIC0+IOmBuOaKnuiCouWIpeWcqOW6q1xyXG5cclxuICAgICAgbGV0IHZhcjAgPSBpdGVtLnZhcmlhdGlvbnNbMF1cclxuICAgICAgaWYgKHZhcjAuY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGUgPT09ICcnICYmIHZhcjAuY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlID09PSAnJykge1xyXG4gICAgICAgIC8vIOmAmuW4uOWVhuWTgVxyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrU2VnbWVudD4xPC9zdG9ja1NlZ21lbnQ+J1xyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPHN0b2NrQ291bnQ+JHt2YXIwLnN0b2NrfTwvc3RvY2tDb3VudD5gXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8g6YG45oqe6IKi5Yil5Zyo5bqrXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tTZWdtZW50PjI8L3N0b2NrU2VnbWVudD4nXHJcblxyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIGZvciAobGV0IHZhcmlhdGlvbiBvZiBpdGVtLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICAgIC8vIOWcqOW6q+ioreWumuOCv+OCsOOBruWQjeWJjeOCkuW3ruOBl+abv+OBiOOCi1xyXG4gICAgICAgICAgdmFyaWF0aW9uLmNob2ljZXNTdG9ja0NvdW50ID0gdmFyaWF0aW9uLnN0b2NrXHJcbiAgICAgICAgICBkZWxldGUgdmFyaWF0aW9uLnN0b2NrXHJcblxyXG4gICAgICAgICAgLy8geG1s44KS5qeL5oiQ44GZ44KLXHJcbiAgICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxjaG9pY2VzU3RvY2tzPidcclxuICAgICAgICAgIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyh2YXJpYXRpb24pKSB7XHJcbiAgICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPCR7a2V5fT4ke3ZhcmlhdGlvbltrZXldfTwvJHtrZXl9PmBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPC9jaG9pY2VzU3RvY2tzPidcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPC9zdG9ja1VwZGF0ZUl0ZW0+J1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OBruS9nOaIkFxyXG4gICAgbGV0IGFwaVJlcXVlc3RCb2R5ID0gYFxyXG4gICAgPHJlcXVlc3Q+XHJcbiAgICA8c2hvcElkPiR7dGhpcy5zaG9wSWR9PC9zaG9wSWQ+XHJcbiAgICAke3N0b2NrVXBkYXRlSXRlbVhNTH1cclxuICAgIDwvcmVxdWVzdD5cclxuICAgIGBcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqPjgpLov5TjgZlcclxuICAgIHJldHVybiBhcGlSZXF1ZXN0Qm9keVxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyB1dGlsRXJyb3Ige1xyXG4gIHN0YXRpYyBwYXJzZSAoZSkge1xyXG4gICAgbGV0IHJlcyA9IHt9XHJcblxyXG4gICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICByZXMubWVzc2FnZSA9IGUubWVzc2FnZVxyXG4gICAgICByZXMubmFtZSA9IGUubmFtZVxyXG4gICAgICByZXMuZmlsZU5hbWUgPSBlLmZpbGVOYW1lXHJcbiAgICAgIHJlcy5saW5lTnVtYmVyID0gZS5saW5lTnVtYmVyXHJcbiAgICAgIHJlcy5jb2x1bW5OdW1iZXIgPSBlLmNvbHVtbk51bWJlclxyXG4gICAgICByZXMuc3RhY2sgPSBlLnN0YWNrXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXMgPSBlXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInXHJcblxyXG5leHBvcnQgY2xhc3MgTW9uZ29Db2xsZWN0aW9uIHtcclxuICBzdGF0aWMgYXN5bmMgZ2V0IChwbHVnLCBjb2xsZWN0aW9uKSB7XHJcbiAgICBsZXQgY2xpZW50ID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSlcclxuICAgIGxldCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKVxyXG4gICAgcmV0dXJuIGRiLmNvbGxlY3Rpb24oY29sbGVjdGlvbilcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IG15c3FsIGZyb20gJ215c3FsJ1xyXG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE15U1FMIHtcclxuICBjb25zdHJ1Y3RvciAocHJvZmlsZSkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz44OX44O844Or5Yid5pyf5YyWXHJcbiAgICB0aGlzLnBvb2wgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGUpXHJcblxyXG4gICAgLy8g6KSH5pWw6KGM44K544OG44O844OI44Oh44Oz44OI5a++5b+cXHJcbiAgICBsZXQgcHJvZmlsZU11bHRpID0ge211bHRpcGxlU3RhdGVtZW50czogdHJ1ZX1cclxuICAgIE9iamVjdC5hc3NpZ24ocHJvZmlsZU11bHRpLCBwcm9maWxlKVxyXG4gICAgdGhpcy5wb29sTXVsdGkgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGVNdWx0aSlcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmb3JtYXREYXRlIChkYXRlKSB7XHJcbiAgICByZXR1cm4gbW9tZW50KGRhdGUpLmZvcm1hdCgpLnN1YnN0cmluZygwLCAxOSkucmVwbGFjZSgnVCcsICcgJylcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNxbFxyXG4gICAqL1xyXG4gIHF1ZXJ5IChzcWwpIHtcclxuICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+eiuueri1xyXG4gICAgLy8gbGV0IGNvbiA9IGF3YWl0IHRoaXMuZ2V0Q29uKCk7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxyXG4gICAgICAudGhlbihcclxuICAgICAgICAoY29uKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcclxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsLCAoZSwgcmVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7PplovmlL5cclxuICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgIGlmIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgIHJlamVjdChlKVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHJlc29sdmUocmVzKVxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZVxyXG4gICAgICB9KVxyXG4gIH07XHJcblxyXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0XyAoc3FsKSB7XHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzLmluc2VydElkXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB0YWJsZVxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvOOAgW51bGzjgIFqYXZhc2NyaXB0LT5teXNxbOaXpeS7mOWkieaPm+OBq+OCguWvvuW/nFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhU3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xyXG4gICAqL1xyXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0ICh0YWJsZSwgZGF0YSA9IHt9LCBkYXRhU3FsID0ge30pIHtcclxuICAgIC8vIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XHJcbiAgICAvLyByZXR1cm4gcmVzLmluc2VydElkO1xyXG5cclxuICAgIGxldCBzcWwgPSBgSU5TRVJUIElOVE8gJHt0YWJsZX0gYFxyXG5cclxuICAgIGxldCBtYXAgPSBuZXcgTWFwKClcclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YSkpIHtcclxuICAgICAgaWYgKGRhdGFba10gPT09IG51bGwpIHtcclxuICAgICAgICBtYXAuc2V0KGssICdOVUxMJylcclxuICAgICAgfSBlbHNlIGlmIChkYXRhW2tdLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgIG1hcC5zZXQoaywgYFwiJHtNeVNRTC5mb3JtYXREYXRlKGRhdGFba10pfVwiYClcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBtYXAuc2V0KGssIGAke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGFTcWwpKSB7XHJcbiAgICAgIG1hcC5zZXQoaywgZGF0YVNxbFtrXSA9PT0gbnVsbCA/ICdOVUxMJyA6IGRhdGFTcWxba10pXHJcbiAgICB9XHJcblxyXG4gICAgc3FsICs9IGAoICR7Wy4uLm1hcC5rZXlzKCldLmpvaW4oJywnKX0gKSBgXHJcblxyXG4gICAgc3FsICs9IGBWQUxVRVMoICR7Wy4uLm1hcC52YWx1ZXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzLmluc2VydElkXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB0YWJsZVxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBmaWx0ZXIgU1FMIFVQREFUReOCueODhuODvOODiOODoeODs+ODiOOBrldIRVJF5Y+lXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O8XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlVcGRhdGUgKHRhYmxlLCBmaWx0ZXIsIGRhdGEsIGRhdGFTcWwpIHtcclxuICAgIGxldCBzcWwgPSBgVVBEQVRFICR7dGFibGV9IFNFVCBgXHJcblxyXG4gICAgbGV0IHVwZGF0ZXMgPSBbXVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtteXNxbC5lc2NhcGUoZGF0YVtrXSl9YClcclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgdXBkYXRlcy5wdXNoKGAke2t9PSR7ZGF0YVNxbFtrXX1gKVxyXG4gICAgfVxyXG4gICAgc3FsICs9IHVwZGF0ZXMuam9pbignLCcpXHJcblxyXG4gICAgc3FsICs9IGAgV0hFUkUgJHtmaWx0ZXJ9IGBcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICAvLyBlbmFibGUgdG8gdXNlIG11bHRpcGxlIHN0YXRlbWVudHNcclxuICBhc3luYyBxdWVyeU11bHRpIChzcWwpIHtcclxuICAgIGxldCBwb29sU3dhcCA9IHRoaXMucG9vbFxyXG4gICAgdGhpcy5wb29sID0gdGhpcy5wb29sTXVsdGlcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgICAgcmV0dXJuIHJlc1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgdGhpcy5wb29sID0gcG9vbFN3YXBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHN0YXJ0VHJhbnNhY3Rpb24gKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgU1RBUlQgVFJBTlNBQ1RJT047YClcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbW1pdCAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBDT01NSVQ7YClcclxuICB9XHJcblxyXG4gIGFzeW5jIHJvbGxiYWNrICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYFJPTExCQUNLO2ApXHJcbiAgfVxyXG5cclxuICBzdHJlYW1pbmdRdWVyeSAoc3FsLCBvblJlc3VsdCA9IChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gKGUpID0+IHt9KSB7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxyXG4gICAgICAudGhlbihcclxuICAgICAgICAoY29uKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgICAgIGFzeW5jIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcclxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsKVxyXG4gICAgICAgICAgICAgICAgLm9uKCdyZXN1bHQnLFxyXG4gICAgICAgICAgICAgICAgICAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uLnBhdXNlKClcclxuICAgICAgICAgICAgICAgICAgICBvblJlc3VsdChyZWNvcmQpXHJcbiAgICAgICAgICAgICAgICAgICAgY29uLnJlc3VtZSgpXHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2Vycm9yJywgKGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgb25FcnJvcihlKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZW5kJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpXHJcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUoKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfVxyXG5cclxuICBnZXRDb24gKCkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgLy8g44OX44O844Or44GL44KJ44Gu44Kz44ON44Kv44K344On44Oz542y5b6XXHJcbiAgICAgICAgdGhpcy5wb29sLmdldENvbm5lY3Rpb24oKGUsIGNvbikgPT4ge1xyXG4gICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXNvbHZlKGNvbilcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC5jYXRjaChcclxuICAgICAgICAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gIH07XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGFja2V0IHtcclxuICBjb25zdHJ1Y3RvciAocGFja2V0U2l6ZSkge1xyXG4gICAgdGhpcy5wYWNrZXRTaXplID0gcGFja2V0U2l6ZVxyXG4gICAgdGhpcy5vblBhY2tldFN0YXJ0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldCA9IG51bGxcclxuICAgIHRoaXMub25QYWNrZXRFbmQgPSBudWxsXHJcbiAgICB0aGlzLmNvdW50ID0gMFxyXG4gICAgdGhpcy5wYWNrZXRDb3VudCA9IDBcclxuICB9XHJcblxyXG4gIGFzeW5jIHN1Ym1pdCAoYXJnKSB7XHJcbiAgICAvLyBwYWNrZXRTaXpl44Gu5Zue5pWw44GU44Go44Gr44CB5Yid5pyf5YyW44KS5ZG844Gz5Ye644GZXHJcbiAgICBpZiAodGhpcy5jb3VudCAlIHRoaXMucGFja2V0U2l6ZSA9PT0gMCkge1xyXG4gICAgICBpZiAodGhpcy5vblBhY2tldFN0YXJ0KSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5vblBhY2tldFN0YXJ0KHRoaXMucGFja2V0Q291bnQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLm9uUGFja2V0KSB7XHJcbiAgICAgIGF3YWl0IHRoaXMub25QYWNrZXQoYXJnKVxyXG4gICAgfVxyXG4gICAgdGhpcy5jb3VudCsrXHJcbiAgICAvLyBwYWNrZXRTaXpl44Gu5Zue5pWw44GU44Go44Gr44CB57WC5LqG5Yem55CG44KS5ZG844Gz5Ye644GZXHJcbiAgICBpZiAodGhpcy5jb3VudCAlIHRoaXMucGFja2V0U2l6ZSA9PT0gMCkge1xyXG4gICAgICB0aGlzLmNsb3NlKClcclxuICAgICAgdGhpcy5wYWNrZXRDb3VudCsrXHJcbiAgICB9XHJcbiAgfVxyXG4gIGNsb3NlICgpIHtcclxuICAgIGlmICh0aGlzLm9uUGFja2V0RW5kKSB7XHJcbiAgICAgIHRoaXMub25QYWNrZXRFbmQodGhpcy5wYWNrZXRDb3VudClcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuL2Vycm9yJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IHsgTG9ncyB9IGZyb20gJy4uL2NvbGxlY3Rpb24vbG9ncydcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZXBvcnQge1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMucmVjb3JkID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3JzID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3IgPSBudWxsXHJcbiAgfVxyXG5cclxuICAvLyBwcml2YXRlXHJcbiAgc2V0dXBJdGVyYXRvciAocGhhc2VJZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvciA9IG5ldyBJdGVyYXRvcihwaGFzZUlkKVxyXG4gICAgdGhpcy5pdGVyYXRvcnMucHVzaCh0aGlzLml0ZXJhdG9yKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGhhc2UgKG5hbWUgPSAnJywgZm4gPSBhc3luYyAoKSA9PiB7fSkge1xyXG4gICAgbGV0IHJlYyA9IHtcclxuICAgICAgcGhhc2VJZDogdW5pcWlkKClcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnNldHVwSXRlcmF0b3IocmVjLnBoYXNlSWQpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGZuKClcclxuXHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogcmVzXHJcbiAgICAgIH0pXHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHV0aWxFcnJvci5wYXJzZShlKVxyXG4gICAgICB9KVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgLy8g44Or44O844OX5Yem55CG44Gu44Os44Od44O844OI44KS5L2c5oiQXHJcbiAgICAgIGlmICh0aGlzLml0ZXJhdG9yLm1ldHJpYy50b3RhbCkge1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgICBpdGVyYXRvcjogdGhpcy5pdGVyYXRvci5tZXRyaWNcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICAgIC8vIOOCv+OCpOODoOOCueOCv+ODs+ODl1xyXG4gICAgICByZWMudGltZVN0YW1wID0gbmV3IERhdGUoKVxyXG4gICAgICAvLyDjg6zjg53jg7zjg4jjgpLjg4fjg7zjgr/jg5njg7zjgrnjgavoqJjpjLJcclxuICAgICAgTG9ncy5pbnNlcnQocmVjKVxyXG5cclxuICAgICAgLy8g5ZG844Gz5Ye644GX5YWD55So44Os44Od44O844OI44Gr6L+95YqgXHJcbiAgICAgIHRoaXMucmVjb3JkLnB1c2gocmVjKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8g44Kr44O844K944Or44KS44Or44O844OX44GX44CB5LiO44GI44KJ44KM44Gf6Zai5pWw44KS5a6f6KGMXHJcbiAgLy8g5ZG844Gz5Ye644GZ6Zai5pWw44Gu5byV5pWw44Gr44Gv44Kr44O844K944Or44GL44KJ5b6X44KJ44KM44Gf44OJ44Kt44Ol44Oh44Oz44OI44KS5rih44GZXHJcbiAgYXN5bmMgZm9yRWFjaE9uQ3Vyc29yIChjdXIsIGZuKSB7XHJcbiAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICBsZXQgZG9jID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmbihkb2MpXHJcbiAgICAgICAgdGhpcy5pU3VjY2VzcyhyZXMpXHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICB0aGlzLmlFcnJvcihlKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBjdXIuY2xvc2UoKVxyXG4gIH1cclxuXHJcbiAgaVN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5zdWNjZXNzKG5ld1JlY29yZClcclxuICB9XHJcblxyXG4gIGlFcnJvciAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLmVycm9yKHV0aWxFcnJvci5wYXJzZShuZXdSZWNvcmQpKVxyXG4gIH1cclxuXHJcbiAgZXJyb3JPY3VycmVkICgpIHtcclxuICAgIGxldCBpdGVFcnJvciA9IHRoaXMuaXRlcmF0b3JzLmZpbmQoZSA9PiBlLmVycm9yT2N1cnJlZCgpKVxyXG4gICAgbGV0IHBoYUVycm9yID0gZmFsc2VcclxuICAgIGZvciAobGV0IHJlYyBvZiB0aGlzLnJlY29yZCkge1xyXG4gICAgICBpZiAocmVjLnR5cGUgPT09ICdlcnJvcicpIHtcclxuICAgICAgICBwaGFFcnJvciA9IHRydWVcclxuICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXRlRXJyb3IgfHwgcGhhRXJyb3JcclxuICB9XHJcblxyXG4gIHB1Ymxpc2ggKCkge1xyXG4gICAgLy8g5ZG844Gz5Ye644GX5YWD44G444Os44Od44O844OIXHJcbiAgICBpZiAodGhpcy5lcnJvck9jdXJyZWQoKSkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKHRoaXMucmVjb3JkKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMucmVjb3JkXHJcbiAgfVxyXG59XHJcblxyXG5jbGFzcyBJdGVyYXRvciB7XHJcbiAgY29uc3RydWN0b3IgKHBoYXNlSWQpIHtcclxuICAgIHRoaXMubWV0cmljID0ge1xyXG4gICAgICB0b3RhbDogMCxcclxuICAgICAgc3VjY2VzczogMCxcclxuICAgICAgZXJyb3I6IDAsXHJcbiAgICAgIHBoYXNlSWQ6IHBoYXNlSWRcclxuICAgIH1cclxuICAgIHRoaXMubGFzdEVycm9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgc3VjY2VzcyAobmV3UmVjb3JkKSB7XHJcbiAgICBpZiAobmV3UmVjb3JkKSB7XHJcbiAgICAgIHRoaXMubG9nKG5ld1JlY29yZCwgdHJ1ZSlcclxuICAgIH1cclxuICAgIHRoaXMubWV0cmljLnN1Y2Nlc3MrK1xyXG4gICAgdGhpcy5tZXRyaWMudG90YWwrK1xyXG4gIH1cclxuXHJcbiAgZXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgLy8g55u05YmN44Go5ZCM44GY44Ko44Op44O844Gv55yB44GPXHJcbiAgICBpZiAoSlNPTi5zdHJpbmdpZnkodGhpcy5sYXN0RXJyb3IpICE9PSBKU09OLnN0cmluZ2lmeShuZXdSZWNvcmQpKSB7XHJcbiAgICAgIGlmIChuZXdSZWNvcmQgJiYgbmV3UmVjb3JkICE9PSB7fSAmJiBuZXdSZWNvcmQgIT09ICcnKSB7XHJcbiAgICAgICAgdGhpcy5sb2cobmV3UmVjb3JkLCBmYWxzZSlcclxuICAgICAgICB0aGlzLmxhc3RFcnJvciA9IG5ld1JlY29yZFxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aGlzLm1ldHJpYy5lcnJvcisrXHJcbiAgICB0aGlzLm1ldHJpYy50b3RhbCsrXHJcbiAgfVxyXG5cclxuICBsb2cgKG5ld1JlY29yZCwgaXNTdWNjZXNzIC8qIHRydWUgPT4gc3VjY2VzcyBvciBmYWxzZSA9PiBlcnJvciAqLykge1xyXG4gICAgbGV0IHJlYyA9IHtcclxuICAgICAgc3VjY2VzczogaXNTdWNjZXNzLFxyXG4gICAgICBwaGFzZUlkOiB0aGlzLm1ldHJpYy5waGFzZUlkLFxyXG4gICAgICBtZXNzYWdlOiBuZXdSZWNvcmQsXHJcbiAgICAgIHRpbWVTdGFtcDogbmV3IERhdGUoKVxyXG4gICAgfVxyXG4gICAgTG9ncy5pbnNlcnQocmVjKVxyXG4gIH1cclxuXHJcbiAgZXJyb3JPY3VycmVkICgpIHtcclxuICAgIHJldHVybiB0aGlzLm1ldHJpYy5lcnJvclxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBUZXh0VXRpbCB7XHJcbiAgc3RhdGljIHN1YnN0cjggKHRleHQsIGxlbiwgdHJ1bmNhdGlvbikge1xyXG4gICAgaWYgKHRydW5jYXRpb24gPT09IHVuZGVmaW5lZCkgeyB0cnVuY2F0aW9uID0gJycgfVxyXG4gICAgdmFyIHRleHRBcnJheSA9IHRleHQuc3BsaXQoJycpXHJcbiAgICB2YXIgY291bnQgPSAwXHJcbiAgICB2YXIgc3RyID0gJydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGV4dEFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHZhciBuID0gZXNjYXBlKHRleHRBcnJheVtpXSlcclxuICAgICAgaWYgKG4ubGVuZ3RoIDwgNCkgY291bnQrK1xyXG4gICAgICBlbHNlIGNvdW50ICs9IDJcclxuICAgICAgaWYgKGNvdW50ID4gbGVuKSB7XHJcbiAgICAgICAgcmV0dXJuIHN0ciArIHRydW5jYXRpb25cclxuICAgICAgfVxyXG4gICAgICBzdHIgKz0gdGV4dC5jaGFyQXQoaSlcclxuICAgIH1cclxuICAgIHJldHVybiB0ZXh0XHJcbiAgfVxyXG59XHJcbiJdfQ==
