var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/route/upload/image.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/cube/cubemig.js                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 3);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 4);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 5);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let couponCd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let couponName = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discountPrice = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: couponCd,
                coupon_type: 3,
                // 全商品
                coupon_name: couponName,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discountPrice,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                customer_id: record.customer_id,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
        return res;
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/jline/collection.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
      return res;
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.aggregate(query).toArray());
      return res;
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/jline/items.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let ItemController;
module.watch(require("../../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/cube.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/service/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 5);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  //
  // 商品情報登録と更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop.product_id': insertRes.res.product_id,
                  'mall.sharakuShop.product_class_id': insertRes.res.product_class_id,
                  'mall.sharakuShop.product_stock_id': insertRes.res.product_stock_id
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              let quantity = Promise.await(itemController.getStock(item._id));
              Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      return report.publish();
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/robotin.js                                                                                              //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
const tag = 'robotinPostlabel';
const ORDER_NO_PREFIX = '受注番号：';
Meteor.methods({
  //
  // Robot-in
  // 送り状に商品コードを記載
  [`${tag}.addItemCode`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('Robot-in 送り状に商品コードを記載', () => Promise.asyncApply(() => {
        const workdir = `${config.workdir}/postlabel`; // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {}

        try {
          Promise.await(fsExtra.mkdir(workdir));
        } catch (e) {
          // workdir が準備されていたら実行する
          // const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`)
          let orderCsv = Promise.await(fsExtra.readFile(`${workdir}/${config.orderCsvPrefix}.csv`));
          orderCsv = Promise.await(iconv.decode(orderCsv, 'SJIS'));
          orderCsv = Promise.await(iconv.encode(orderCsv, 'UTF-8')); // orderCsv.pipe(iconv.decodeStream('SJIS'))
          //   .pipe(iconv.encodeStream('UTF-8'))
          //   .pipe(csv.parse({
          //     columns: true
          //   }))
          //   .pipe(csv.transform(
          //     async (recOrder, callback) => {
          //       let err = null
          //       try {
          // 送り状の種類ごとに繰り返す

          Promise.await(config.postages.forEach(e => Promise.asyncApply(() => {
            console.log(`csvPrefix: ${e.csvPrefix}`); // await e.id.forEach(
            //   async id => {
            //     console.log(`${id.order}: ${recOrder[id.order]}`)
            //   }
            // )
            // console.log(`${config.itemCodeColumn}: ${recOrder[config.itemCodeColumn]}`)
            // 送り状CSVを開き、配送ごとに商品コードを記載する

            const postCSV = fsExtra.createReadStream(`${workdir}/${e.csvPrefix}.csv`);
            postCSV.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
              columns: true
            }));
          }))); //       } catch (e) {
          //         err = e
          //       }
          //       callback(err, recOrder)
          //     }
          //   ))
          // .pipe(csv.stringify({header: true}))
          // .pipe(iconv.decodeStream('UTF-8'))
          // .pipe(iconv.encodeStream('SJIS'))
          // .pipe(w)
        }

        throw new Meteor.Error(`正しい作業ディレクトリが用意されていませんでした。下記のフォルダへ受注CSV、送り状CSVをコピーしてください。\n[${workdir}]`);
      })));
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/tooltest.js                                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      const newLocal = Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
        throw e;
      })));
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return newLocal;
      })));
      return report.publish();
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/wowma.js                                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 4);
let request;
module.watch(require("request-promise"), {
  default(v) {
    request = v;
  }

}, 5);
let WowmaApi;
module.watch(require("../imports/service/wowmaApi"), {
  default(v) {
    WowmaApi = v;
  }

}, 6);
let utilError;
module.watch(require("../imports/util/error"), {
  default(v) {
    utilError = v;
  }

}, 7);
const tag = 'wowma';
Meteor.methods({
  //
  // WOWMA 商品の配送方法を設定する
  [`${tag}.updateItem.deliveryMethod`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('Wowma! 商品の配送方法を設定する', () => Promise.asyncApply(() => {
        //
        // jline_engine 商品データベースへの接続
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); //
        // 商品情報の作成

        let cur = Promise.await(itemController.Items.aggregate([{
          $match: {
            $and: [{
              'mall.wowma.itemCode': {
                $exists: 1
              }
            }]
          }
        }, {
          // 商品コードの一覧を作る
          $group: {
            _id: '$mall.wowma.itemCode'
          }
        }, {
          $project: {
            _id: 0,
            itemCode: '$_id'
          }
        }])); // 得られた商品ごとにAPIリクエストを発行

        let api = new WowmaApi(config.wowmaApiPost, config.shopId);
        Promise.await(report.forEachOnCursor(cur, item => Promise.asyncApply(() => {
          Object.assign(item, Promise.await(itemController.convertItemWowmaCreateDeliveryMethod(item.itemCode)));

          try {
            let res = Promise.await(api.updateItem(item));
            return {
              requestBody: item,
              response: res
            };
          } catch (e) {
            throw Object.assign({
              requestBody: item
            }, utilError.parse(e));
          }
        })));
      })));
      return report.publish();
    });
  },

  //
  // WOWMA 商品データベース上の商品を公開する
  [`${tag}.updateItem.open`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('Wowma! 商品データベース上の商品を公開する', () => Promise.asyncApply(() => {
        //
        // jline_engine 商品データベースへの接続
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); //
        // 商品情報の作成

        let cur = Promise.await(itemController.Items.aggregate([{
          $match: {
            $and: [{
              'mall.wowma.itemCode': {
                $exists: 1
              } // テスト検索条件設定
              // {
              //   $or: [
              //     {
              //       'mall.wowma.itemCode': 'gk-163'
              //     }
              //     // {
              //     //   'mall.wowma.itemCode': '10005402'
              //     // },
              //     // {
              //     //   'mall.wowma.itemCode': '10004743'
              //     // }
              //   ]
              // }

            }]
          }
        }, {
          // 商品コードの一覧を作る
          $group: {
            _id: '$mall.wowma.itemCode'
          }
        }, {
          $project: {
            _id: 0,
            itemCode: '$_id'
          }
        }])); // 得られた商品ごとにAPIリクエストを発行

        let api = new WowmaApi(config.wowmaApiPost, config.shopId);
        Promise.await(report.forEachOnCursor(cur, item => Promise.asyncApply(() => {
          item.saleStatus = 1;
          item.limitedPasswd = 'NULL';

          try {
            let res = Promise.await(api.updateItem(item));
            return {
              requestBody: item,
              response: res
            };
          } catch (e) {
            throw Object.assign({
              requestBody: item
            }, utilError.parse(e));
          }
        })));
      })));
      return report.publish();
    });
  },

  //
  // WOWMA 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('WOWMA! 在庫更新', () => Promise.asyncApply(() => {
        //
        // 在庫情報の作成
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        let cur = Promise.await(itemController.Items.aggregate([{
          $match: {
            $and: [{
              'mall.wowma.itemCode': {
                $exists: 1
              } // テスト検索条件設定
              //   ,{
              //     $or: [
              //       {
              //         'mall.wowma.itemCode': '10005402'
              //       }
              //       ,{
              //         'mall.wowma.itemCode': 'gk-163'
              //       }
              //       ,{
              //         'mall.wowma.itemCode': '10004743'
              //       }
              //     ]
              //   }

            }]
          }
        }, {
          // 配送方法の違いを省く
          $group: {
            _id: {
              itemCode: '$mall.wowma.itemCode',
              choicesStockHorizontalCode: '$mall.wowma.HChoiceName',
              choicesStockVerticalCode: '$mall.wowma.VChoiceName'
            },
            item: {
              $first: '$_id'
            }
          }
        }, {
          // 商品ページごと（商品コード）にグループ化する
          $group: {
            _id: '$_id.itemCode',
            variations: {
              $push: {
                _id: '$item',
                choicesStockHorizontalCode: '$_id.choicesStockHorizontalCode',
                choicesStockVerticalCode: '$_id.choicesStockVerticalCode'
              }
            }
          }
        }, {
          $project: {
            _id: 0,
            itemCode: '$_id',
            variations: '$variations'
          }
        }])); // let resMongo = await cur.toArray()
        // return resMongo
        // リクエストボディ

        while (Promise.await(cur.hasNext())) {
          let item = Promise.await(cur.next()); // 在庫を設定する

          for (let e of item.variations) {
            e.stock = Promise.await(itemController.getStock(e._id));
            delete e._id;
          } //
          // 在庫更新リクエスト


          let api = new WowmaApi(config.wowmaApiPost, config.shopId);

          try {
            let res = Promise.await(api.updateStock([item]));
            report.iSuccess(res);
          } catch (e) {
            report.iError(e);
          }
        }

        cur.close();
      })));
      return report.publish();
    });
  },

  //
  // WOWMA 商品検索
  [`${tag}.searchItem`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('WOWMA! 商品情報取得', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // APIから取得した商品情報を保存する場所


        const workdir = `${config.workdir}/items_${new Date().getTime()}`; // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(workdir));
        } catch (e) {} // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let options = JSON.parse(JSON.stringify(config.wowmaApi));
            options.uri = `${options.uri}/searchItemInfo`;
            options.qs.itemCode = item.mall.wowma.itemCode;
            let repos = Promise.await(request(options));
            let filename = `${workdir}/${item.model}.xml`;
            Promise.await(fsExtra.writeFile(filename, repos));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/wowmaApi.js                                                                                             //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let WowmaApiItemFilter;
module.watch(require("../imports/service/dbfilter"), {
  WowmaApiItemFilter(v) {
    WowmaApiItemFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
const tag = 'wowmaApi';
Meteor.methods({
  //
  // WOWMA商品情報取得
  [`${tag}.getItem`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('WOWMA! 商品情報取得', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new WowmaApiItemFilter(config.wowmaApi, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // // 作業フォルダを作成する
        // try {
        //   await fsExtra.mkdir(config.workdir)
        // } catch (e) {}
        // // APIから取得した商品情報を保存する場所
        // const workdir = `${config.workdir}/items_${(new Date()).getTime()}`
        // // 作業フォルダを作成する
        // try {
        //   await fsExtra.mkdir(workdir)
        // } catch (e) {}
        // メインループ
        //

        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            report.iSuccess(item);
          })
        }));
        return res;
      })));
      return report.publish();
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/yauct.js                                                                                                //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
let PassThrough, Transform;
module.watch(require("stream"), {
  PassThrough(v) {
    PassThrough = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 9);
const prefix = 'packet';
const tag = 'yauct';
Meteor.methods({
  //
  // ヤフオク受注ファイル
  [`${tag}.order`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク受注', () => Promise.asyncApply(() => {
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        const workdir = `${config.workdir}/order`;
        const r = fsExtra.createReadStream(`${workdir}/${config.orderLoadfile}`);
        const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`);
        r.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
          columns: true
        })).pipe(csv.transform((record, callback) => Promise.asyncApply(() => {
          let err = null; // 管理番号を置き換える

          try {
            record['管理番号'] = Promise.await(itemController.getModelClass(record['管理番号']));
          } catch (e) {
            err = e;
          }

          callback(err, record);
        }))).pipe(csv.stringify({
          header: true
        })).pipe(iconv.decodeStream('UTF-8')).pipe(iconv.encodeStream('SJIS')).pipe(w);
      })));
    });
  },

  //
  // ヤフオク出品ファイル
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク出品', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 繰り返し処理を任意の（packetSize）で分割

        const packet = new Packet(config.packetSize); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // CSVファイルを作成し画像データを収集する場所


        const workdir = `${config.workdir}/work`;
        Promise.await(fsExtra.remove(workdir));
        Promise.await(fsExtra.mkdir(workdir)); // ZIPファイルを保存する場所

        const uploaddir = `${config.workdir}/upload`;
        Promise.await(fsExtra.remove(uploaddir));
        Promise.await(fsExtra.mkdir(uploaddir));
        let cd = null; // パケットフォルダ

        let filename = null; // csvファイル

        let name = null; // パケット番号
        // CSVフィールドを定義し、順番を確定する

        let fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
        let header = fields.map(v => `"${v}"`).join(',') + '\n'; // パケット化開始時

        packet.onPacketStart = packetCount => Promise.asyncApply(() => {
          name = prefix + ('00000' + packetCount).slice(-5);
          cd = `${workdir}/${name}`;
          filename = `${cd}/${config.csvFileName}`;
          Promise.await(fsExtra.mkdir(cd)); // CSVファイルにフィールドを設定する

          Promise.await(fsExtra.appendFile(filename, iconv.encode(header, 'Shift_JIS')));
        }); // パケット化時


        packet.onPacket = arg => Promise.asyncApply(() => {
          let yauct = arg.yauct;
          let item = arg.item; // csvファイルにレコード（商品テンプレート）を追加する

          let record = fields.map(v => {
            return yauct[v] ? `"${yauct[v]}"` : '""';
          }).join(',') + '\n';
          Promise.await(fsExtra.appendFile(filename, iconv.encode(record, 'Shift_JIS'))); // 画像ファイルをコピー

          for (let img of item.images) {
            let imgSrc = `${config.imagedir}/${img}`;
            let imgTgt = `${cd}/${img}`;

            try {
              // 同じファイルがある場合はコピーしない
              Promise.await(fsExtra.access(imgTgt));
            } catch (e) {
              Promise.await(fsExtra.copyFile(imgSrc, imgTgt));
            }
          }
        }); // パケット終了時


        packet.onPacketEnd = packetCount => Promise.asyncApply(() => {
          const zip = archiver('zip');
          const zipname = `${uploaddir}/${name}.zip`;
          const output = fsExtra.createWriteStream(zipname);
          zip.pipe(output);
          zip.directory(cd, false);
          zip.finalize();
        }); // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id)); // itemに定義されている最低必要在庫より多い商品を出品する

            if (quantity >= item.mall.yauct.minQuantity) {
              let yauct = Promise.await(itemController.convertItemYauct(config.default, item));
              Promise.await(packet.submit({
                yauct: yauct,
                item: item
              }));
            }
          })
        }));
        packet.close();
        return res;
      })));
      return report.publish();
    });
  }

});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// server/main.js                                                                                                 //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/collection/configs.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/collection/filters.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/collection/groups.js                                                                                   //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"logs.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/collection/logs.js                                                                                     //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Logs: () => Logs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Logs = new Mongo.Collection('logs', {
  idGeneration: 'MONGO'
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/collection/uploads.js                                                                                  //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/service/cube3api.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);

class Cube3Api {
  /**
   *
   * @param {MySQL} mysql
   */
  constructor(mysql) {
    this.mysql_ = mysql;
  }

  updateStock(productClassId, quantity = 0) {
    return Promise.asyncApply(() => {
      Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      }));
      Promise.await(this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      }));
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = []; // 削除するタグ

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      }); // 表示するタグ


      let tagon = tag => Promise.asyncApply(() => {
        // すでに表示されているタグがあれば何もしない
        let sql = `
      SELECT COUNT(*) FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        let countRes = Promise.await(this.mysql_.query(sql));
        if (countRes[0]['COUNT(*)']) return;
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creatorId,
          create_date: 'NOW()'
        })));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let productId = data.product_id;
      let images = data.images;
      let creatorId = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${productId}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        Promise.await(this.mysql_.queryInsert('dtb_product_image', {
          product_id: productId,
          creator_id: creatorId,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        }));
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let updateData = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      Promise.await(this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      })); // dtb_product_class

      updateData = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      let res = Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      }));
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = {};
      let updateData = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', updateData, {
        creator_id: creatorId,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      updateData = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', updateData, {
        creator_id: creatorId,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creatorId,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/service/dbfilter.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter,
  WowmaApiItemFilter: () => WowmaApiItemFilter
});
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 1);
let request;
module.watch(require("request-promise"), {
  default(v) {
    request = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let xml2js;
module.watch(require("xml-js"), {
  xml2js(v) {
    xml2js = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case 'mysql':
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    switch (plug.type) {
      case 'mysql':
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error('invalid plug type');
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   *
   *
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== 'undefined') {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      let res = Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
      return res;
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find(); // カーソルのタイムアウトを解除

      cur.addCursorFlag('noCursorTimeout', true); // すべてのドキュメントをループ

      try {
        while (Promise.await(cur.hasNext())) {
          let doc = Promise.await(cur.next());
          Promise.await(onResult(doc, context));
        }

        ;
      } finally {
        // カーソルを開放
        Promise.await(cur.close());
      }
    }));
  }

}

class WowmaApiItemFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // 商品情報の取得ループを定義

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      // コレクションを取得
      let options = JSON.parse(JSON.stringify(plug));
      options.uri = `${options.uri}/searchStocks`;
      let context = {
        options: options
      };

      while (1) {
        // Wowma Api から商品情報を取得
        let res = Promise.await(request(options));
        res = xml2js(res, {
          compact: true
        });
        let maxCount = Number(res.response.searchResult.maxCount._text);
        let resultCount = Number(res.response.searchResult.resultCount._text);
        let startCount = Number(res.response.searchResult.startCount._text);
        let resultStocks = res.response.searchResult.resultStocks; // 取得した商品情報をカスタムプロセスに渡す

        if (resultStocks instanceof Array) {
          // 取得したデータが複数商品の場合
          for (let i = 0; i < resultCount; i++) {
            Promise.await(onResult(resultStocks[i], context));
          }
        } else {
          // 取得したデータが単数商品の場合
          Promise.await(onResult(resultStocks, context));
        }

        let next = startCount + resultCount;
        if (next > maxCount) break;
        options.qs.startCount = next;
      }
    }));
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/service/items.js                                                                                       //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);
let ObjectID;
module.watch(require("bson"), {
  ObjectID(v) {
    ObjectID = v;
  }

}, 2);
let TextUtil;
module.watch(require("../util/text"), {
  default(v) {
    TextUtil = v;
  }

}, 3);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(itemId) {
    return Promise.asyncApply(() => {
      let item = Promise.await(this.Items.findOne({
        _id: itemId
      }, {
        projection: {
          'product': 1
        }
      }));
      let productSet = item.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[{ids:[<ObjectId>],set:<Number>}]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let productRef of productSet) {
        let prdQuantity = 0;

        for (let id of productRef.ids) {
          let product = Promise.await(this.Products.findOne({
            _id: id
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stockArray = product.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stockArray) {
            prdQuantity += stock.quantity;
          }
        } // 商品(item)の在庫数 = 製品在庫数(prdQuantity) / 必要セット数(productRef.set)


        quantities.push(Math.floor(prdQuantity / productRef.set));
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   *
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   *
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   *
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   *
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   *
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }
  /**
   * 指定の商品に関連する商品群の属性別の商品情報を返す。
   *
   * 引数として受け取るitemは任意の商品情報。
   * itemに関連する商品群について必要な情報を整理し返す。
   *
   * projectに参照したい商品情報フィールドを定義する。
   * メソッドの呼び出し時に必要に応じてprojectを設定する。
   *
   * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
   *
   * @param {Object} item
   * @param {Object} project
   */


  getVariation(item, project) {
    return Promise.asyncApply(() => {
      /**
       * aggregation設定
       *
       * label: 属性名（配送方法、カラー、サイズなど）
       * current: 指定されたアイテム（item）が該当する項目
       * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
       * query: aggregation対象とするドキュメントの検索条件
       */
      let set = [{
        label: '配送方法',
        current: item.delivery,
        project: {
          value: '$delivery'
        },
        query: {
          class1_value: item.class1_value,
          class2_value: item.class2_value
        }
      }, {
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          delivery: item.delivery,
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          delivery: item.delivery,
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }, {
            $sort: {
              _id: 1
            }
          }]).toArray()),
          props: s
        });
      }

      for (let attr of attrs) {
        for (let v of attr.variations) {
          v.stock = Promise.await(this.getStock(v._id));
        }
      }

      return attrs;
    });
  } // モデルクラス形式を作る
  // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]


  getModelClass(arg) {
    return Promise.asyncApply(() => {
      let item; // item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

      if (typeof arg === 'string') {
        let exp = new RegExp(`${arg}$`);
        let cur = this.Items.find({}, {
          projection: {
            model: 1,
            class1_value: 1,
            class2_value: 1
          }
        });

        while (1) {
          try {
            item = Promise.await(cur.next());
            let match = Promise.await(item._id.toHexString().match(exp));

            if (match) {
              break;
            }
          } catch (e) {
            // 該当するitemデータがない
            cur.close();
            return arg;
          }
        }

        cur.close();
      } else {
        item = arg;
      }

      let modelClass = [];
      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value);
      return modelClass.join('/');
    });
  }

  convertItemCube3(creatorId, item) {
    return Promise.asyncApply(() => {
      // 値変換
      let convDeliv = delivery => delivery === 'ゆうパケット' ? 'ポスト投函' : delivery; // product_id


      let productId = null;
      let modelClass = []; // 下記の形式を作る
      // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]

      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let productTypeId;

      switch (item.delivery) {
        case '宅配便':
          productTypeId = 1;
          break;

        case 'ゆうパケット':
          productTypeId = 2;
          break;

        default:
          productTypeId = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let deliveryFee = null;

      switch (item.delivery) {
        case '宅配便':
          deliveryFee = null;
          break;

        case 'ゆうパケット':
          deliveryFee = 240;
          break;
      } //
      // 顧客向けバリエーション商品選択機能の実装
      //


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      })); // HTML バリエーション商品ごとのリンク付きボタンを表示する
      // 値の変換

      attrs = attrs.map(attr => {
        attr.props.current = convDeliv(attr.props.current);
        attr.variations = attr.variations.map(variation => {
          variation.value = convDeliv(variation.value);
          return variation;
        });
        return attr;
      }); // HTML生成

      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row">` + `<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">` + `<strong>${attr.props.label}</strong>` + `</div>` + attr.variations.map(variation => {
        if (attr.props.current === variation.value) {
          // 表示中の商品ボタン
          return `<button class="btn btn-success btn-sm btn-item-class-select"><strong>${variation.value}</strong></button>`;
        } else if (variation.stock > 0) {
          // 販売可能商品のボタン
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-sm btn-item-class-select">${variation.value}</button></a>`;
        } else {
          // 販売不可能商品のボタン（在庫なし）
          return `<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">${variation.value}</button>`;
        }
      }).join('') + '</div>' + '</div>').join('');
      let descriptionDetail = `
    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>
    ${variationHtml}
    `; // 商品データを作る

      let data = {
        product_id: productId,
        creator_id: creatorId,
        name: `${modelClass.join('/')} ${convDeliv(item.delivery)} ${item.name}${item.jan_code ? ' ' + item.jan_code : ''}`,
        description_detail: descriptionDetail,
        // free_area: await this.convertItemCube3createFreeArea(item),
        product_code: modelClass.join('/'),
        price01: item.retail_price,
        // price02: await this.convertItemCube3createPrice02(item),
        // images: await this.convertItemCube3createImages(item),
        product_type_id: productTypeId,
        tags: tags,
        delivery_fee: deliveryFee
      };
      Object.assign(data, Promise.await(this.convertItemCube3createFreeArea(item)));
      Object.assign(data, Promise.await(this.convertItemCube3createPrice02(item)));
      Object.assign(data, Promise.await(this.convertItemCube3createImages(item)));
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  }

  convertItemCube3createFreeArea(item) {
    return Promise.asyncApply(() => {
      let freeArea = ''; // 商品情報テキストを記載する

      freeArea += item.description; // 2番目以降の画像をフリーエリアに記載する

      for (let i = 1; i < item.images.length; i++) {
        freeArea += `<img src="/upload/save_image/${item.images[i]}"><br>`;
      } // 情報のクリア


      freeArea += ' ';
      return {
        free_area: freeArea
      };
    });
  }

  convertItemCube3createPrice02(item) {
    return Promise.asyncApply(() => {
      // 価格を返す
      return {
        price02: item.mall.sharakuShop.price
      };
    });
  }

  convertItemCube3createImages(item) {
    return Promise.asyncApply(() => {
      // 画像リストのうち1つめだけを返す
      let arr = typeof item.images[0] === 'undefined' ? [] : [item.images[0]];
      return {
        images: arr
      };
    });
  } // ヤフオクテンプレートへの変換


  convertItemYauct(def, item) {
    return Promise.asyncApply(() => {
      const idLength = 20;
      const titleLength = 130;
      let yauct = {}; // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）

      yauct = JSON.parse(JSON.stringify(def[item.delivery])); // 画像の記述

      const imgPrefix = '画像';

      for (let i = 0; i < item.images.length; i++) {
        yauct[imgPrefix + (i + 1)] = item.images[i];
      } // タイトル


      yauct['カテゴリ'] = item.mall.yauct.category;
      yauct['タイトル'] = TextUtil.substr8(`${Promise.await(this.getModelClass(item))} ${item.delivery} ${item.name}`, titleLength);
      yauct['開始価格'] = item.sales_price;
      yauct['即決価格'] = item.sales_price;
      yauct['管理番号'] = item._id.toHexString().slice(-idLength);
      yauct['説明'] = item.description;
      yauct['JANコード・ISBNコード'] = item.jan_code;
      return yauct;
    });
  }

  convertItemWowmaCreateDeliveryMethod(itemCode) {
    return Promise.asyncApply(() => {
      let id = 'mall.wowma.itemCode';
      let set = 'delivery';
      let metrics = {
        'ゆうパケット': ['Post'],
        '宅配便': ['YU-Pack', 'Kangaroo'] // deliveryMethodSeq

      };
      let aggr = Promise.await(this.Items.aggregate([{
        $match: {
          [id]: itemCode
        }
      }, {
        $group: {
          _id: `$${id}`,
          [set]: {
            $addToSet: `$${set}`
          }
        }
      }, {
        $project: {
          _id: 0,
          itemCode: '$_id',
          [set]: `$${set}`
        }
      }]).toArray());
      let acceptDeliv = [];

      for (let del of aggr[0].delivery) {
        acceptDeliv = acceptDeliv.concat(metrics[`${del}`]);
      }

      let deliveryMethod = new Array(5);

      for (let i = 0; i < deliveryMethod.length; i++) {
        let id = typeof acceptDeliv[i] === 'undefined' ? 'NULL' : acceptDeliv[i];
        deliveryMethod[i] = {
          deliveryMethodSeq: i + 1,
          deliveryMethodId: id
        };
      }

      return {
        deliveryMethod: deliveryMethod
      };
    });
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/service/wowmaApi.js                                                                                    //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  default: () => WowmaApi
});
let request;
module.watch(require("request-promise"), {
  default(v) {
    request = v;
  }

}, 0);
let json2xml;
module.watch(require("xml-js"), {
  json2xml(v) {
    json2xml = v;
  }

}, 1);
let utilError;
module.watch(require("../util/error"), {
  default(v) {
    utilError = v;
  }

}, 2);
const BASE_URI = 'https://api.manager.wowma.jp/wmshopapi';

class WowmaApi {
  constructor(plug, shopId) {
    this.plug = plug;
    this.shopId = shopId;
  } // 商品情報更新


  updateItem(updateItem) {
    return Promise.asyncApply(() => {
      let request = `<request><shopId>${this.shopId}</shopId><updateItem>${json2xml(updateItem, {
        compact: true
      })}</updateItem></request>`;

      try {
        let res = Promise.await(this.requestPost('updateItemInfo', request));
        return {
          response: res,
          requestXML: request
        };
      } catch (e) {
        throw Object.assign(utilError.parse(e), {
          requestXML: request
        });
      }
    });
  }

  requestPost(method, body) {
    return Promise.asyncApply(() => {
      // 接続オプションの作成
      let apiRequest = {
        method: 'POST',
        uri: `${BASE_URI}/${method}`,
        body: body // 共通の接続設定と結合する

      };
      Object.assign(apiRequest, this.plug); // リクエスト発行

      let res = Promise.await(request(apiRequest));
      return res;
    });
  }

  updateStock(stockUpdateItem) {
    return Promise.asyncApply(() => {
      // 接続オプションの作成
      let apiRequest = {
        method: 'POST',
        uri: `${BASE_URI}/updateStock` // 共通の接続設定と結合する

      };
      Object.assign(apiRequest, this.plug);
      apiRequest.body = Promise.await(this.updateStockCreateRequestBody(stockUpdateItem)); // リクエスト発行

      let res = Promise.await(request(apiRequest));
      return res;
    });
  }

  updateStockCreateRequestBody(stockUpdateItem) {
    return Promise.asyncApply(() => {
      //
      // stockUpdateItem =
      // [
      //   {
      //     itemCode: <String>,
      //     variations: [
      //        {
      //          choicesStockHorizontalCode: <String>,
      //          choicesStockVerticalCode: <String>,
      //          stock: <Number>
      //        }
      //     ]
      //   }
      // ]
      let stockUpdateItemXML = '';

      for (let item of stockUpdateItem) {
        // 値のチェック
        for (let e of item.variations) {
          // 在庫数の上限100
          if (e.stock > 100) e.stock = 100;
        }

        stockUpdateItemXML += '<stockUpdateItem>';
        stockUpdateItemXML += `<itemCode>${item.itemCode}</itemCode>`; // 商品在庫種別を振り分け
        // 1 -> 通常商品
        // 2 -> 選択肢別在庫

        let var0 = item.variations[0];

        if (var0.choicesStockHorizontalCode === '' && var0.choicesStockVerticalCode === '') {
          // 通常商品
          stockUpdateItemXML += '<stockSegment>1</stockSegment>';
          stockUpdateItemXML += `<stockCount>${var0.stock}</stockCount>`;
        } else {
          // 選択肢別在庫
          stockUpdateItemXML += '<stockSegment>2</stockSegment>'; // リクエストボディを作成する

          for (let variation of item.variations) {
            // 在庫設定タグの名前を差し替える
            variation.choicesStockCount = variation.stock;
            delete variation.stock; // xmlを構成する

            stockUpdateItemXML += '<choicesStocks>';

            for (let key of Object.keys(variation)) {
              stockUpdateItemXML += `<${key}>${variation[key]}</${key}>`;
            }

            stockUpdateItemXML += '</choicesStocks>';
          }
        }

        stockUpdateItemXML += '</stockUpdateItem>';
      } // リクエストボディの作成


      let apiRequestBody = `
    <request>
    <shopId>${this.shopId}</shopId>
    ${stockUpdateItemXML}
    </request>
    `; // リクエストボディを返す

      return apiRequestBody;
    });
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/util/error.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/util/mongo.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/util/mysql.js                                                                                          //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   *
   * @param {String} sql
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, dataSql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(dataSql)) {
        map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, dataSql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(dataSql)) {
        updates.push(`${k}=${dataSql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/util/packet.js                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  default: () => Packet
});

class Packet {
  constructor(packetSize) {
    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  submit(arg) {
    return Promise.asyncApply(() => {
      // packetSizeの回数ごとに、初期化を呼び出す
      if (this.count % this.packetSize === 0) {
        if (this.onPacketStart) {
          Promise.await(this.onPacketStart(this.packetCount));
        }
      }

      if (this.onPacket) {
        Promise.await(this.onPacket(arg));
      }

      this.count++; // packetSizeの回数ごとに、終了処理を呼び出す

      if (this.count % this.packetSize === 0) {
        this.close();
        this.packetCount++;
      }
    });
  }

  close() {
    if (this.onPacketEnd) {
      this.onPacketEnd(this.packetCount);
    }
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/util/report.js                                                                                         //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let Logs;
module.watch(require("../collection/logs"), {
  Logs(v) {
    Logs = v;
  }

}, 2);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 3);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  } // private


  setupIterator(phaseId) {
    this.iterator = new Iterator(phaseId);
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let rec = {
        phaseId: uniqid()
      };
      this.setupIterator(rec.phaseId);

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        // ループ処理のレポートを作成
        if (this.iterator.metric.total) {
          Object.assign(rec, {
            iterator: this.iterator.metric
          });
        } // タイムスタンプ


        rec.timeStamp = new Date(); // レポートをデータベースに記録

        Logs.insert(rec); // 呼び出し元用レポートに追加

        this.record.push(rec);
      }
    });
  } // カーソルをループし、与えられた関数を実行
  // 呼び出す関数の引数にはカーソルから得られたドキュメントを渡す


  forEachOnCursor(cur, fn) {
    return Promise.asyncApply(() => {
      while (Promise.await(cur.hasNext())) {
        let doc = Promise.await(cur.next());

        try {
          // リクエスト発行
          let res = Promise.await(fn(doc));
          this.iSuccess(res);
        } catch (e) {
          this.iError(e);
        }
      }

      cur.close();
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    // 呼び出し元へレポート
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor(phaseId) {
    this.metric = {
      total: 0,
      success: 0,
      error: 0,
      phaseId: phaseId
    };
    this.lastError = null;
  }

  success(newRecord) {
    if (newRecord) {
      this.log(newRecord, true);
    }

    this.metric.success++;
    this.metric.total++;
  }

  error(newRecord) {
    // 直前と同じエラーは省く
    if (JSON.stringify(this.lastError) !== JSON.stringify(newRecord)) {
      if (newRecord && newRecord !== {} && newRecord !== '') {
        this.log(newRecord, false);
        this.lastError = newRecord;
      }
    }

    this.metric.error++;
    this.metric.total++;
  }

  log(newRecord, isSuccess
  /* true => success or false => error */
  ) {
    let rec = {
      success: isSuccess,
      phaseId: this.metric.phaseId,
      message: newRecord,
      timeStamp: new Date()
    };
    Logs.insert(rec);
  }

  errorOcurred() {
    return this.metric.error;
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                //
// imports/util/text.js                                                                                           //
//                                                                                                                //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                  //
module.export({
  default: () => TextUtil
});

class TextUtil {
  static substr8(text, len, truncation) {
    if (truncation === undefined) {
      truncation = '';
    }

    var textArray = text.split('');
    var count = 0;
    var str = '';

    for (let i = 0; i < textArray.length; i++) {
      var n = escape(textArray[i]);
      if (n.length < 4) count++;else count += 2;

      if (count > len) {
        return str + truncation;
      }

      str += text.charAt(i);
    }

    return text;
  }

}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/robotin.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/wowmaApi.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yb2JvdGluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdG9vbHRlc3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci93b3dtYS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIveWF1Y3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vY29uZmlncy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2ZpbHRlcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9ncm91cHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9sb2dzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvZXJyb3IuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9tb25nby5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL215c3FsLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvcGFja2V0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvcmVwb3J0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvdGV4dC5qcyJdLCJuYW1lcyI6WyJmcyIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsImRlZmF1bHQiLCJ2IiwidW5pcWlkIiwibXVsdGlwYXJ0eSIsIlVwbG9hZHMiLCJtdWx0aXBhcnR5TWlkZGxld2FyZSIsInJvdXRlIiwiV2ViQXBwIiwiY29ubmVjdEhhbmRsZXJzIiwidXNlIiwicmVxIiwicmVzcCIsInJlYWRlciIsIk1ldGVvciIsIndyYXBBc3luYyIsInJlYWRGaWxlIiwid3JpdGVyIiwid3JpdGVGaWxlIiwidXBsb2FkSWQiLCJmaWxlIiwiZmlsZXMiLCJkYXRhIiwicGF0aCIsImZpbGVuYW1lIiwic2F2ZVBhdGgiLCJib2R5IiwiaW1hZ2VkaXIiLCJkb2MiLCJjbGllbnRGaWxlTmFtZSIsIm5hbWUiLCJ1cGxvYWRlZEZpbGVOYW1lIiwiZXJyIiwiZXJyb3IiLCJpbnNlcnQiLCJ3cml0ZUhlYWQiLCJlbmQiLCJKU09OIiwic3RyaW5naWZ5Iiwic2F2ZURpciIsImNyeXB0byIsIk15U1FMIiwiUmVwb3J0IiwiR3JvdXAiLCJHcm91cEZhY3RvcnkiLCJGaWx0ZXIiLCJ0YWciLCJtZXRob2RzIiwiY29uZmlnIiwicmVwb3J0IiwiZmlsdGVyIiwic3JjRmlsdGVySWQiLCJ0ZXN0UXVlcnkiLCJkc3REYiIsImRzdCIsImNyZWQiLCJwaGFzZSIsInF1ZXJ5IiwicmVzIiwiZm9yZWFjaCIsIm1vYmlsZU51bGwiLCJyZWNvcmQiLCJzcWwiLCJjdXN0b21lcl9pZCIsInN0YXR1cyIsInNleCIsImpvYiIsImNvdW50cnlfaWQiLCJwcmVmIiwibmFtZTAxIiwibmFtZTAyIiwia2FuYTAxIiwia2FuYTAyIiwiY29tcGFueV9uYW1lIiwiemlwMDEiLCJ6aXAwMiIsInppcGNvZGUiLCJhZGRyMDEiLCJhZGRyMDIiLCJlbWFpbCIsInRlbDAxIiwidGVsMDIiLCJ0ZWwwMyIsImZheDAxIiwiZmF4MDIiLCJmYXgwMyIsImJpcnRoIiwicGFzc3dvcmQiLCJzYWx0Iiwic2VjcmV0X2tleSIsImZpcnN0X2J1eV9kYXRlIiwibGFzdF9idXlfZGF0ZSIsImJ1eV90aW1lcyIsImJ1eV90b3RhbCIsIm5vdGUiLCJjcmVhdGVfZGF0ZSIsInVwZGF0ZV9kYXRlIiwiZGVsX2ZsZyIsInF1ZXJ5SW5zZXJ0IiwiZSIsImlFcnJvciIsImN1c3RvbWVyX2FkZHJlc3NfaWQiLCJpZCIsIm1haWxtYWdhX2ZsZyIsImNvdXBvbkNkIiwicmFuZG9tQnl0ZXMiLCJ0b1N0cmluZyIsInN1YnN0cmluZyIsImNvdXBvbk5hbWUiLCJkaXNjb3VudFByaWNlIiwicG9pbnQiLCJjb3Vwb25faWQiLCJjb3Vwb25fY2QiLCJjb3Vwb25fdHlwZSIsImNvdXBvbl9uYW1lIiwiZGlzY291bnRfdHlwZSIsImNvdXBvbl91c2VfdGltZSIsImNvdXBvbl9yZWxlYXNlIiwiZGlzY291bnRfcHJpY2UiLCJkaXNjb3VudF9yYXRlIiwiZW5hYmxlX2ZsYWciLCJjb3Vwb25fbWVtYmVyIiwiY291cG9uX2xvd2VyX2xpbWl0IiwiYXZhaWxhYmxlX2Zyb21fZGF0ZSIsImF2YWlsYWJsZV90b19kYXRlIiwicHVibGlzaCIsInByb2ZpbGUiLCJkYiIsIk1vbmdvQ29sbGVjdGlvbiIsInBsdWciLCJwcm9qZWN0aW9uIiwiY29sbCIsImdldCIsImNvbGxlY3Rpb24iLCJmaW5kIiwidG9BcnJheSIsImFnZ3JlZ2F0ZSIsIkl0ZW1Db250cm9sbGVyIiwibW9kZWwiLCJjbGFzczEiLCJjbGFzczIiLCJpdGVtY29uIiwiaW5pdCIsInVwbG9hZGVkIiwic2V0SW1hZ2UiLCJjbGVhbkltYWdlIiwiTW9uZ29EQkZpbHRlciIsIkN1YmUzQXBpIiwiaXRlbXNEQiIsIml0ZW1Db250cm9sbGVyIiwidGFyZ2V0REIiLCJjdWJlM0RCIiwiYXBpIiwiaXRlbSIsImNvbnRleHQiLCJxdWFudGl0eSIsImdldFN0b2NrIiwiX2lkIiwidXBkYXRlU3RvY2siLCJtYWxsIiwic2hhcmFrdVNob3AiLCJwcm9kdWN0X2NsYXNzX2lkIiwiY29sIiwiY3ViZUl0ZW0iLCJjb252ZXJ0SXRlbUN1YmUzIiwiY3JlYXRvcl9pZCIsImluc2VydFJlcyIsInByb2R1Y3RDcmVhdGUiLCJ1cGRhdGUiLCIkc2V0IiwicHJvZHVjdF9pZCIsInByb2R1Y3Rfc3RvY2tfaWQiLCJpU3VjY2VzcyIsInByb2R1Y3RJbWFnZVVwZGF0ZSIsInByb2R1Y3RVcGRhdGUiLCJwcm9kdWN0VGFnVXBkYXRlIiwiUGFja2V0IiwiZnNFeHRyYSIsImljb252IiwiYXJjaGl2ZXIiLCJjc3YiLCJPUkRFUl9OT19QUkVGSVgiLCJ3b3JrZGlyIiwibWtkaXIiLCJvcmRlckNzdiIsIm9yZGVyQ3N2UHJlZml4IiwiZGVjb2RlIiwiZW5jb2RlIiwicG9zdGFnZXMiLCJmb3JFYWNoIiwiY29uc29sZSIsImxvZyIsImNzdlByZWZpeCIsInBvc3RDU1YiLCJjcmVhdGVSZWFkU3RyZWFtIiwicGlwZSIsImRlY29kZVN0cmVhbSIsImVuY29kZVN0cmVhbSIsInBhcnNlIiwiY29sdW1ucyIsIkVycm9yIiwibmV3TG9jYWwiLCJyZXF1ZXN0IiwiV293bWFBcGkiLCJ1dGlsRXJyb3IiLCJjdXIiLCJJdGVtcyIsIiRtYXRjaCIsIiRhbmQiLCIkZXhpc3RzIiwiJGdyb3VwIiwiJHByb2plY3QiLCJpdGVtQ29kZSIsIndvd21hQXBpUG9zdCIsInNob3BJZCIsImZvckVhY2hPbkN1cnNvciIsIk9iamVjdCIsImFzc2lnbiIsImNvbnZlcnRJdGVtV293bWFDcmVhdGVEZWxpdmVyeU1ldGhvZCIsInVwZGF0ZUl0ZW0iLCJyZXF1ZXN0Qm9keSIsInJlc3BvbnNlIiwic2FsZVN0YXR1cyIsImxpbWl0ZWRQYXNzd2QiLCJjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZSIsImNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZSIsIiRmaXJzdCIsInZhcmlhdGlvbnMiLCIkcHVzaCIsImhhc05leHQiLCJuZXh0Iiwic3RvY2siLCJjbG9zZSIsIkRhdGUiLCJnZXRUaW1lIiwib3B0aW9ucyIsIndvd21hQXBpIiwidXJpIiwicXMiLCJ3b3dtYSIsInJlcG9zIiwiV293bWFBcGlJdGVtRmlsdGVyIiwiUGFzc1Rocm91Z2giLCJUcmFuc2Zvcm0iLCJwcmVmaXgiLCJyIiwib3JkZXJMb2FkZmlsZSIsInciLCJjcmVhdGVXcml0ZVN0cmVhbSIsIm9yZGVyU2F2ZWZpbGUiLCJ0cmFuc2Zvcm0iLCJjYWxsYmFjayIsImdldE1vZGVsQ2xhc3MiLCJoZWFkZXIiLCJwYWNrZXQiLCJwYWNrZXRTaXplIiwicmVtb3ZlIiwidXBsb2FkZGlyIiwiY2QiLCJmaWVsZHMiLCJtYXAiLCJqb2luIiwib25QYWNrZXRTdGFydCIsInBhY2tldENvdW50Iiwic2xpY2UiLCJjc3ZGaWxlTmFtZSIsImFwcGVuZEZpbGUiLCJvblBhY2tldCIsImFyZyIsInlhdWN0IiwiaW1nIiwiaW1hZ2VzIiwiaW1nU3JjIiwiaW1nVGd0IiwiYWNjZXNzIiwiY29weUZpbGUiLCJvblBhY2tldEVuZCIsInppcCIsInppcG5hbWUiLCJvdXRwdXQiLCJkaXJlY3RvcnkiLCJmaW5hbGl6ZSIsIm1pblF1YW50aXR5IiwiY29udmVydEl0ZW1ZYXVjdCIsInN1Ym1pdCIsImV4cG9ydCIsIkNvbmZpZ3MiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJpZEdlbmVyYXRpb24iLCJzaWZ0IiwibW9iamVjdCIsIkdyb3VwQmFzZSIsIkZpbHRlcnMiLCJjb25zdHJ1Y3RvciIsImZpbHRlcklkIiwiZmluZE9uZSIsImdldFBsdWciLCJ0eXBlIiwibXlzcWwiLCJpbXBvcnQiLCJvblJlc3VsdCIsIm9uRXJyb3IiLCJ0YWJsZSIsInN0cmVhbWluZ1F1ZXJ5IiwiY2FsbGJhY2tzIiwiZ2V0UHJvZmlsZSIsImZpbHRlcnMiLCJwdXNoIiwiY291bnQiLCJ1bmVzY2FwZSIsImV4YW0iLCJHcm91cHMiLCJwbGF0Zm9ybVBsdWciLCJncm91cElkIiwia2V5IiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJpbmRleCIsImNhdGNoIiwiTG9ncyIsIm15c3FsXyIsInByb2R1Y3RDbGFzc0lkIiwicXVlcnlVcGRhdGUiLCJzdG9ja191bmxpbWl0ZWQiLCJjcmVhdG9ySWQiLCJ0YWdvZmYiLCJ0YWdvbiIsImNvdW50UmVzIiwidGFnU2V0IiwidGFncyIsInNldCIsInByb2R1Y3RJZCIsImkiLCJsZW5ndGgiLCJmaWxlX25hbWUiLCJyYW5rIiwidXBkYXRlRGF0YSIsImtleXMiLCJrIiwiZGVzY3JpcHRpb25fbGlzdCIsInNlYXJjaF93b3JkIiwiZnJlZV9hcmVhIiwiY2xhc3NfY2F0ZWdvcnlfaWQxIiwiY2xhc3NfY2F0ZWdvcnlfaWQyIiwiZGVsaXZlcnlfZGF0ZV9pZCIsInNhbGVfbGltaXQiLCJEQkZpbHRlckZhY3RvcnkiLCJEQkZpbHRlciIsIk15c3FsREJGaWx0ZXIiLCJNb25nb0NsaWVudCIsInhtbDJqcyIsImluc3RhbmNlIiwiZmFjdG9yeSIsImdldFBsdWdfIiwiZ2V0Q3JlZF8iLCJnZXRQcm9maWxlXyIsInNldEltcG9ydEZ1bmN0aW9uXyIsImZuIiwiaXRlcmF0b3JzIiwiY291bnRlciIsImYiLCJsaW1pdCIsImMiLCJjbGllbnQiLCJjb25uZWN0IiwiZGF0YWJhc2UiLCJhZGRDdXJzb3JGbGFnIiwiY29tcGFjdCIsIm1heENvdW50IiwiTnVtYmVyIiwic2VhcmNoUmVzdWx0IiwiX3RleHQiLCJyZXN1bHRDb3VudCIsInN0YXJ0Q291bnQiLCJyZXN1bHRTdG9ja3MiLCJBcnJheSIsIk9iamVjdElEIiwiVGV4dFV0aWwiLCJQcm9kdWN0cyIsIml0ZW1JZCIsInByb2R1Y3RTZXQiLCJwcm9kdWN0IiwicXVhbnRpdGllcyIsInByb2R1Y3RSZWYiLCJwcmRRdWFudGl0eSIsImlkcyIsInN0b2NrQXJyYXkiLCJNYXRoIiwiZmxvb3IiLCJtaW4iLCJhcHBseSIsImZldGNoIiwiY2xhc3MxX3ZhbHVlIiwiY2xhc3MyX3ZhbHVlIiwidXBkYXRlTWFueSIsIiRlYWNoIiwiZ2V0VmFyaWF0aW9uIiwicHJvamVjdCIsImxhYmVsIiwiY3VycmVudCIsImRlbGl2ZXJ5IiwidmFsdWUiLCJjbGFzczFfbmFtZSIsImNsYXNzMl9uYW1lIiwiYXR0cnMiLCJzIiwiJHNvcnQiLCJwcm9wcyIsImF0dHIiLCJleHAiLCJSZWdFeHAiLCJtYXRjaCIsInRvSGV4U3RyaW5nIiwibW9kZWxDbGFzcyIsImNvbnZEZWxpdiIsInByb2R1Y3RUeXBlSWQiLCJkZWxpdmVyeUZlZSIsInZhcmlhdGlvbiIsInZhcmlhdGlvbkh0bWwiLCJkZXNjcmlwdGlvbkRldGFpbCIsImphbl9jb2RlIiwiZGVzY3JpcHRpb25fZGV0YWlsIiwicHJvZHVjdF9jb2RlIiwicHJpY2UwMSIsInJldGFpbF9wcmljZSIsInByb2R1Y3RfdHlwZV9pZCIsImRlbGl2ZXJ5X2ZlZSIsImNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVGcmVlQXJlYSIsImNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyIiwiY29udmVydEl0ZW1DdWJlM2NyZWF0ZUltYWdlcyIsImZyZWVBcmVhIiwiZGVzY3JpcHRpb24iLCJwcmljZTAyIiwicHJpY2UiLCJhcnIiLCJkZWYiLCJpZExlbmd0aCIsInRpdGxlTGVuZ3RoIiwiaW1nUHJlZml4IiwiY2F0ZWdvcnkiLCJzdWJzdHI4Iiwic2FsZXNfcHJpY2UiLCJtZXRyaWNzIiwiYWdnciIsIiRhZGRUb1NldCIsImFjY2VwdERlbGl2IiwiZGVsIiwiY29uY2F0IiwiZGVsaXZlcnlNZXRob2QiLCJkZWxpdmVyeU1ldGhvZFNlcSIsImRlbGl2ZXJ5TWV0aG9kSWQiLCJqc29uMnhtbCIsIkJBU0VfVVJJIiwicmVxdWVzdFBvc3QiLCJyZXF1ZXN0WE1MIiwibWV0aG9kIiwiYXBpUmVxdWVzdCIsInN0b2NrVXBkYXRlSXRlbSIsInVwZGF0ZVN0b2NrQ3JlYXRlUmVxdWVzdEJvZHkiLCJzdG9ja1VwZGF0ZUl0ZW1YTUwiLCJ2YXIwIiwiY2hvaWNlc1N0b2NrQ291bnQiLCJhcGlSZXF1ZXN0Qm9keSIsIm1lc3NhZ2UiLCJmaWxlTmFtZSIsImxpbmVOdW1iZXIiLCJjb2x1bW5OdW1iZXIiLCJzdGFjayIsIm1vbWVudCIsInBvb2wiLCJjcmVhdGVQb29sIiwicHJvZmlsZU11bHRpIiwibXVsdGlwbGVTdGF0ZW1lbnRzIiwicG9vbE11bHRpIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJmb3JtYXQiLCJyZXBsYWNlIiwiZ2V0Q29uIiwidGhlbiIsImNvbiIsInJlbGVhc2UiLCJxdWVyeUluc2VydF8iLCJpbnNlcnRJZCIsImRhdGFTcWwiLCJNYXAiLCJlc2NhcGUiLCJ2YWx1ZXMiLCJ1cGRhdGVzIiwicXVlcnlNdWx0aSIsInBvb2xTd2FwIiwic3RhcnRUcmFuc2FjdGlvbiIsImNvbW1pdCIsInJvbGxiYWNrIiwib24iLCJwYXVzZSIsInJlc3VtZSIsImdldENvbm5lY3Rpb24iLCJpdGVyYXRvciIsInNldHVwSXRlcmF0b3IiLCJwaGFzZUlkIiwiSXRlcmF0b3IiLCJyZWMiLCJyZXN1bHQiLCJtZXRyaWMiLCJ0b3RhbCIsInRpbWVTdGFtcCIsIm5ld1JlY29yZCIsInN1Y2Nlc3MiLCJlcnJvck9jdXJyZWQiLCJpdGVFcnJvciIsInBoYUVycm9yIiwibGFzdEVycm9yIiwiaXNTdWNjZXNzIiwidGV4dCIsImxlbiIsInRydW5jYXRpb24iLCJ1bmRlZmluZWQiLCJ0ZXh0QXJyYXkiLCJzcGxpdCIsInN0ciIsIm4iLCJjaGFyQXQiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsRUFBSjtBQUFPQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsSUFBUixDQUFiLEVBQTJCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDTCxTQUFHSyxDQUFIO0FBQUs7O0FBQWpCLENBQTNCLEVBQThDLENBQTlDO0FBQWlELElBQUlDLE1BQUo7QUFBV0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJRSxVQUFKO0FBQWVOLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDRSxpQkFBV0YsQ0FBWDtBQUFhOztBQUF6QixDQUEzQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJRyxPQUFKO0FBQVlQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQ0FBUixDQUFiLEVBQTREO0FBQUNLLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTVELEVBQW9GLENBQXBGO0FBYWhPLElBQUlJLHVCQUF1QkYsWUFBM0I7QUFFQSxNQUFNRyxRQUFRLGVBQWQsQyxDQUVBOztBQUNBQyxPQUFPQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQkgsS0FBM0IsRUFBa0NELG9CQUFsQztBQUNBRSxPQUFPQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQkgsS0FBM0IsRUFBa0MsQ0FBQ0ksR0FBRCxFQUFNQyxJQUFOLEtBQWU7QUFDL0M7QUFFQSxRQUFNQyxTQUFTQyxPQUFPQyxTQUFQLENBQWlCbEIsR0FBR21CLFFBQXBCLENBQWY7QUFDQSxRQUFNQyxTQUFTSCxPQUFPQyxTQUFQLENBQWlCbEIsR0FBR3FCLFNBQXBCLENBQWY7QUFDQSxRQUFNQyxXQUFXaEIsUUFBakI7O0FBRUEsT0FBSyxJQUFJaUIsSUFBVCxJQUFpQlQsSUFBSVUsS0FBSixDQUFVRCxJQUEzQixFQUFpQztBQUMvQixVQUFNRSxPQUFPVCxPQUFPTyxLQUFLRyxJQUFaLENBQWIsQ0FEK0IsQ0FFL0I7QUFDQTs7QUFDQSxRQUFJQyxXQUFZLEdBQUVyQixRQUFTLE1BQTNCLENBSitCLENBTS9COztBQUNBLFFBQUlzQixXQUFXZCxJQUFJZSxJQUFKLENBQVNDLFFBQVQsR0FBb0IsR0FBcEIsR0FBMEJILFFBQXpDLENBUCtCLENBUy9CO0FBRUE7O0FBQ0EsUUFBSUksTUFBTTtBQUNSVCxnQkFBVUEsUUFERjtBQUVSVSxzQkFBZ0JULEtBQUtVLElBRmI7QUFHUkMsd0JBQWtCUDtBQUhWLEtBQVY7O0FBTUEsUUFBRztBQUNEUCxhQUFPUSxRQUFQLEVBQWlCSCxJQUFqQjtBQUNELEtBRkQsQ0FHQSxPQUFNVSxHQUFOLEVBQVU7QUFDUkosVUFBSUssS0FBSixHQUFZRCxHQUFaO0FBQ0Q7O0FBQ0QzQixZQUFRNkIsTUFBUixDQUFlTixHQUFmO0FBRUEsV0FBT1IsSUFBUDtBQUVEOztBQUFBO0FBQ0RSLE9BQUt1QixTQUFMLENBQWUsR0FBZjtBQUNBdkIsT0FBS3dCLEdBQUwsQ0FBU0MsS0FBS0MsU0FBTCxDQUFlO0FBQ3RCbkIsY0FBVUEsUUFEWTtBQUV0Qm9CLGFBQVM1QixJQUFJZSxJQUFKLENBQVNDO0FBRkksR0FBZixDQUFUO0FBS0QsQ0ExQ0QsRTs7Ozs7Ozs7Ozs7QUNuQkEsSUFBSWEsTUFBSjtBQUFXMUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3NDLGFBQU90QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBakQsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSXdDLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwyQkFBUixDQUFiLEVBQWtEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBbEQsRUFBeUUsQ0FBekU7QUFBNEUsSUFBSXlDLEtBQUosRUFBVUMsWUFBVjtBQUF1QjlDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxpQ0FBUixDQUFiLEVBQXdEO0FBQUMyQyxRQUFNekMsQ0FBTixFQUFRO0FBQUN5QyxZQUFNekMsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQjBDLGVBQWExQyxDQUFiLEVBQWU7QUFBQzBDLG1CQUFhMUMsQ0FBYjtBQUFlOztBQUFsRCxDQUF4RCxFQUE0RyxDQUE1RztBQUErRyxJQUFJMkMsTUFBSjtBQUFXL0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtDQUFSLENBQWIsRUFBeUQ7QUFBQzZDLFNBQU8zQyxDQUFQLEVBQVM7QUFBQzJDLGFBQU8zQyxDQUFQO0FBQVM7O0FBQXBCLENBQXpELEVBQStFLENBQS9FO0FBYTFjLElBQUk0QyxNQUFNLFNBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYixHQUFRLEdBQUVELEdBQUksVUFBZCxFQUEwQkUsTUFBMUI7QUFBQSxvQ0FBa0M7QUFDaEMsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWIsQ0FEZ0MsQ0FHaEM7QUFDQTs7QUFFQSxVQUFJUSxTQUFTLElBQUlMLE1BQUosQ0FBV0csT0FBT0csV0FBbEIsQ0FBYixDQU5nQyxDQU9oQztBQUVBO0FBQ0E7O0FBRUEsVUFBSUMsWUFBWSxnQkFBaEI7QUFFQSxVQUFJQyxRQUFRLElBQUlaLEtBQUosQ0FBVU8sT0FBT00sR0FBUCxDQUFXQyxJQUFyQixDQUFaO0FBRUEsb0JBQU1OLE9BQU9PLEtBQVAsQ0FBYSx3QkFBYixFQUNKLCtCQUFZO0FBQ1Ysc0JBQU1ILE1BQU1JLEtBQU4sQ0FBWUwsU0FBWixDQUFOO0FBQ0QsT0FGRCxDQURJLENBQU4sRUFoQmdDLENBcUJoQztBQUNBOztBQUVBLG9CQUFNSCxPQUFPTyxLQUFQLENBQWEsdUJBQWIsRUFDSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFDN0JDLHNCQUFtQkMsTUFBUCw2QkFBa0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQSxnQkFBSUMsTUFBTzs7Ozs7MEJBS0dELE9BQU9FLFdBQVksTUFBS0YsT0FBT0csTUFBTyxNQUFLSCxPQUFPSSxHQUFJLE1BQUtKLE9BQU9LLEdBQUksTUFBS0wsT0FBT00sVUFBVyxNQUFLTixPQUFPTyxJQUFLLE1BQUtQLE9BQU9RLE1BQU8sTUFBS1IsT0FBT1MsTUFBTyxNQUFLVCxPQUFPVSxNQUFPLE1BQUtWLE9BQU9XLE1BQU8sTUFBS1gsT0FBT1ksWUFBYSxNQUFLWixPQUFPYSxLQUFNLE1BQUtiLE9BQU9jLEtBQU0sTUFBS2QsT0FBT2UsT0FBUSxNQUFLZixPQUFPZ0IsTUFBTyxNQUFLaEIsT0FBT2lCLE1BQU8sTUFBS2pCLE9BQU9rQixLQUFNLE1BQUtsQixPQUFPbUIsS0FBTSxNQUFLbkIsT0FBT29CLEtBQU0sTUFBS3BCLE9BQU9xQixLQUFNLE1BQUtyQixPQUFPc0IsS0FBTSxNQUFLdEIsT0FBT3VCLEtBQU0sTUFBS3ZCLE9BQU93QixLQUFNLE1BQUt4QixPQUFPeUIsS0FBTSxNQUFLekIsT0FBTzBCLFFBQVMsTUFBSzFCLE9BQU8yQixJQUFLLE1BQUszQixPQUFPNEIsVUFBVyxNQUFLNUIsT0FBTzZCLGNBQWUsTUFBSzdCLE9BQU84QixhQUFjLE1BQUs5QixPQUFPK0IsU0FBVSxNQUFLL0IsT0FBT2dDLFNBQVUsTUFBS2hDLE9BQU9pQyxJQUFLLE1BQUtqQyxPQUFPa0MsV0FBWSxNQUFLbEMsT0FBT21DLFdBQVksTUFBS25DLE9BQU9vQyxPQUFROztpQkFMbHNCOztBQVNBLGdCQUFJO0FBQ0YsNEJBQU01QyxNQUFNNkMsV0FBTixDQUNKLGNBREksRUFDWTtBQUNkbkMsNkJBQWFGLE9BQU9FLFdBRE47QUFFZEMsd0JBQVFILE9BQU9HLE1BRkQ7QUFHZEMscUJBQUtKLE9BQU9JLEdBSEU7QUFJZEMscUJBQUtMLE9BQU9LLEdBSkU7QUFLZEMsNEJBQVlOLE9BQU9NLFVBTEw7QUFNZEMsc0JBQU1QLE9BQU9PLElBTkM7QUFPZEMsd0JBQVFSLE9BQU9RLE1BUEQ7QUFRZEMsd0JBQVFULE9BQU9TLE1BUkQ7QUFTZEMsd0JBQVFWLE9BQU9VLE1BVEQ7QUFVZEMsd0JBQVFYLE9BQU9XLE1BVkQ7QUFXZEMsOEJBQWNaLE9BQU9ZLFlBWFA7QUFZZEMsdUJBQU9iLE9BQU9hLEtBWkE7QUFhZEMsdUJBQU9kLE9BQU9jLEtBYkE7QUFjZEMseUJBQVNmLE9BQU9lLE9BZEY7QUFlZEMsd0JBQVFoQixPQUFPZ0IsTUFmRDtBQWdCZEMsd0JBQVFqQixPQUFPaUIsTUFoQkQ7QUFpQmRDLHVCQUFPbEIsT0FBT2tCLEtBakJBO0FBa0JkQyx1QkFBT25CLE9BQU9tQixLQWxCQTtBQW1CZEMsdUJBQU9wQixPQUFPb0IsS0FuQkE7QUFvQmRDLHVCQUFPckIsT0FBT3FCLEtBcEJBO0FBcUJkQyx1QkFBT3RCLE9BQU9zQixLQXJCQTtBQXNCZEMsdUJBQU92QixPQUFPdUIsS0F0QkE7QUF1QmRDLHVCQUFPeEIsT0FBT3dCLEtBdkJBO0FBd0JkQyx1QkFBT3pCLE9BQU95QixLQXhCQTtBQXlCZEMsMEJBQVUxQixPQUFPMEIsUUF6Qkg7QUEwQmRDLHNCQUFNM0IsT0FBTzJCLElBMUJDO0FBMkJkQyw0QkFBWTVCLE9BQU80QixVQTNCTDtBQTRCZEMsZ0NBQWdCN0IsT0FBTzZCLGNBNUJUO0FBNkJkQywrQkFBZTlCLE9BQU84QixhQTdCUjtBQThCZEMsMkJBQVcvQixPQUFPK0IsU0E5Qko7QUErQmRDLDJCQUFXaEMsT0FBT2dDLFNBL0JKO0FBZ0NkQyxzQkFBTWpDLE9BQU9pQyxJQWhDQztBQWlDZEMsNkJBQWFsQyxPQUFPa0MsV0FqQ047QUFrQ2RDLDZCQUFhbkMsT0FBT21DLFdBbENOO0FBbUNkQyx5QkFBU3BDLE9BQU9vQztBQW5DRixlQURaLENBQU47QUF1Q0QsYUF4Q0QsQ0F3Q0UsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBaEUyQixDQWtFNUI7OztBQUNBLGdCQUFJO0FBQ0YsNEJBQU05QyxNQUFNNkMsV0FBTixDQUNKLHNCQURJLEVBQ29CO0FBQ3RCRyxxQ0FBcUIsSUFEQztBQUV0QnRDLDZCQUFhRixPQUFPRSxXQUZFO0FBR3RCSSw0QkFBWU4sT0FBT00sVUFIRztBQUl0QkMsc0JBQU1QLE9BQU9PLElBSlM7QUFLdEJDLHdCQUFRUixPQUFPUSxNQUxPO0FBTXRCQyx3QkFBUVQsT0FBT1MsTUFOTztBQU90QkMsd0JBQVFWLE9BQU9VLE1BUE87QUFRdEJDLHdCQUFRWCxPQUFPVyxNQVJPO0FBU3RCQyw4QkFBY1osT0FBT1ksWUFUQztBQVV0QkMsdUJBQU9iLE9BQU9hLEtBVlE7QUFXdEJDLHVCQUFPZCxPQUFPYyxLQVhRO0FBWXRCQyx5QkFBU2YsT0FBT2UsT0FaTTtBQWF0QkMsd0JBQVFoQixPQUFPZ0IsTUFiTztBQWN0QkMsd0JBQVFqQixPQUFPaUIsTUFkTztBQWV0QkUsdUJBQU9uQixPQUFPbUIsS0FmUTtBQWdCdEJDLHVCQUFPcEIsT0FBT29CLEtBaEJRO0FBaUJ0QkMsdUJBQU9yQixPQUFPcUIsS0FqQlE7QUFrQnRCQyx1QkFBT3RCLE9BQU9zQixLQWxCUTtBQW1CdEJDLHVCQUFPdkIsT0FBT3VCLEtBbkJRO0FBb0J0QkMsdUJBQU94QixPQUFPd0IsS0FwQlE7QUFxQnRCVSw2QkFBYWxDLE9BQU9rQyxXQXJCRTtBQXNCdEJDLDZCQUFhbkMsT0FBT21DLFdBdEJFO0FBdUJ0QkMseUJBQVNwQyxPQUFPb0M7QUF2Qk0sZUFEcEIsQ0FBTjtBQTJCRCxhQTVCRCxDQTRCRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFqRzJCLENBbUc1Qjs7O0FBQ0EsZ0JBQUk7QUFDRiw0QkFBTTlDLE1BQU02QyxXQUFOLENBQ0osdUJBREksRUFDcUI7QUFDdkJJLG9CQUFJLElBRG1CO0FBRXZCdkMsNkJBQWFGLE9BQU9FLFdBRkc7QUFHdkJ3Qyw4QkFBYzFDLE9BQU8wQyxZQUhFO0FBSXZCUiw2QkFBYWxDLE9BQU9rQyxXQUpHO0FBS3ZCQyw2QkFBYW5DLE9BQU9tQyxXQUxHO0FBTXZCQyx5QkFBU3BDLE9BQU9vQztBQU5PLGVBRHJCLENBQU47QUFVRCxhQVhELENBV0UsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBakgyQixDQW1INUI7OztBQUVBLGdCQUFJSyxXQUFXaEUsT0FBT2lFLFdBQVAsQ0FBbUIsQ0FBbkIsRUFBc0JDLFFBQXRCLENBQStCLFFBQS9CLEVBQXlDQyxTQUF6QyxDQUFtRCxDQUFuRCxFQUFzRCxFQUF0RCxDQUFmO0FBRUEsZ0JBQUlDLGFBQWMsR0FBRS9DLE9BQU9RLE1BQU8sSUFBR1IsT0FBT1MsTUFBTyxtQkFBa0JULE9BQU9FLFdBQVksRUFBeEY7QUFFQSxnQkFBSThDLGdCQUFnQmhELE9BQU9pRCxLQUFQLEdBQWUsR0FBbkM7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSXBELG9CQUFZTCxNQUFNNkMsV0FBTixDQUNkLFlBRGMsRUFDQTtBQUNaYSwyQkFBVyxJQURDO0FBRVpDLDJCQUFXUixRQUZDO0FBR1pTLDZCQUFhLENBSEQ7QUFHSTtBQUNoQkMsNkJBQWFOLFVBSkQ7QUFLWk8sK0JBQWUsQ0FMSDtBQU1aQyxpQ0FBaUIsQ0FOTDtBQU9aQyxnQ0FBZ0IsQ0FQSjtBQVFaQyxnQ0FBZ0JULGFBUko7QUFTWlUsK0JBQWUsSUFUSDtBQVVaQyw2QkFBYSxDQVZEO0FBV1pDLCtCQUFlLENBWEg7QUFZWkMsb0NBQW9CLElBWlI7QUFhWjNELDZCQUFhRixPQUFPRSxXQWJSO0FBY1o0RCxxQ0FBcUIscUJBZFQ7QUFlWkMsbUNBQW1CLHFCQWZQO0FBZ0JaM0IseUJBQVM7QUFoQkcsZUFEQSxFQWtCWDtBQUNERiw2QkFBYSxPQURaO0FBRURDLDZCQUFhO0FBRlosZUFsQlcsQ0FBWixDQUFKO0FBdUJELGFBeEJELENBd0JFLE9BQU9HLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBdEpXO0FBRGlCLFNBQWYsRUF5SlRBLENBQVAsNkJBQWE7QUFDWGxELGlCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsU0FGRCxDQXpKZ0IsQ0FBWixDQUFKO0FBOEpBLGVBQU96QyxHQUFQO0FBQ0QsT0FoS0QsQ0FESSxDQUFOO0FBbUtBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTVMRDtBQUFBLEdBRmE7O0FBZ01QLHVCQUFOLENBQTZCQyxPQUE3QjtBQUFBLG9DQUFzQztBQUNwQyxVQUFJQyxLQUFLLElBQUl0RixLQUFKLENBQVVxRixPQUFWLENBQVQ7QUFDQSxVQUFJcEUsb0JBQVlxRSxHQUFHdEUsS0FBSCxDQUFTLGdCQUFULENBQVosQ0FBSjtBQUNBLGFBQU9DLEdBQVA7QUFDRCxLQUpEO0FBQUE7O0FBaE1hLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQSxJQUFJc0UsZUFBSjtBQUFvQmxJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNnSSxrQkFBZ0I5SCxDQUFoQixFQUFrQjtBQUFDOEgsc0JBQWdCOUgsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQWpELEVBQXlGLENBQXpGO0FBQTRGLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHM0gsSUFBSTRDLE1BQU0sa0JBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYixHQUFRLEdBQUVELEdBQUksT0FBZCxFQUF1Qm1GLElBQXZCLEVBQTZCeEUsUUFBUSxFQUFyQyxFQUF5Q3lFLGFBQWEsRUFBdEQ7QUFBQSxvQ0FBMEQ7QUFDeEQsVUFBSUMscUJBQWFILGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCQSxLQUFLSSxVQUEvQixDQUFiLENBQUo7QUFDQSxVQUFJM0Usb0JBQVl5RSxLQUFLRyxJQUFMLENBQVU3RSxLQUFWLEVBQWlCO0FBQUN5RSxvQkFBWUE7QUFBYixPQUFqQixFQUEyQ0ssT0FBM0MsRUFBWixDQUFKO0FBQ0EsYUFBTzdFLEdBQVA7QUFDRCxLQUpEO0FBQUEsR0FGYTs7QUFRYixHQUFRLEdBQUVaLEdBQUksWUFBZCxFQUE0Qm1GLElBQTVCLEVBQWtDeEUsUUFBUSxFQUExQztBQUFBLG9DQUE4QztBQUM1QyxVQUFJMEUscUJBQWFILGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCQSxLQUFLSSxVQUEvQixDQUFiLENBQUo7QUFDQSxVQUFJM0Usb0JBQVl5RSxLQUFLSyxTQUFMLENBQWUvRSxLQUFmLEVBQXNCOEUsT0FBdEIsRUFBWixDQUFKO0FBQ0EsYUFBTzdFLEdBQVA7QUFDRCxLQUpEO0FBQUE7O0FBUmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBLElBQUkrRSxjQUFKO0FBQW1CM0ksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1SSxxQkFBZXZJLENBQWY7QUFBaUI7O0FBQTdCLENBQXBELEVBQW1GLENBQW5GO0FBQXNGLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHcEgsSUFBSTRDLE1BQU0sYUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViOzs7OztBQUtBLEdBQVEsR0FBRUQsR0FBSSxXQUFkLEVBQTJCbUYsSUFBM0IsRUFBaUM5RyxRQUFqQyxFQUEyQ3VILEtBQTNDLEVBQWtEQyxTQUFTLElBQTNELEVBQWlFQyxTQUFTLElBQTFFO0FBQUEsb0NBQWdGO0FBQzlFLFVBQUlDLFVBQVUsSUFBSUosY0FBSixFQUFkO0FBQ0Esb0JBQU1JLFFBQVFDLElBQVIsQ0FBYWIsSUFBYixDQUFOO0FBQ0EsVUFBSWMseUJBQWlCRixRQUFRRyxRQUFSLENBQWlCN0gsUUFBakIsRUFBMkJ1SCxLQUEzQixFQUFrQ0MsTUFBbEMsRUFBMENDLE1BQTFDLENBQWpCLENBQUo7QUFDQSxhQUFPRyxRQUFQO0FBQ0QsS0FMRDtBQUFBLEdBUGE7O0FBY2I7OztBQUdBLEdBQVEsR0FBRWpHLEdBQUksYUFBZCxFQUE2Qm1GLElBQTdCLEVBQW1DUyxLQUFuQyxFQUEwQ0MsU0FBUyxJQUFuRCxFQUF5REMsU0FBUyxJQUFsRTtBQUFBLG9DQUF3RTtBQUN0RSxVQUFJQyxVQUFVLElBQUlKLGNBQUosRUFBZDtBQUNBLG9CQUFNSSxRQUFRQyxJQUFSLENBQWFiLElBQWIsQ0FBTjtBQUNBLG9CQUFNWSxRQUFRSSxVQUFSLENBQW1CUCxLQUFuQixFQUEwQkMsTUFBMUIsRUFBa0NDLE1BQWxDLENBQU47QUFDRCxLQUpEO0FBQUE7O0FBakJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJbEcsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSWlKLFFBQUo7QUFBYXJKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNtSixXQUFTakosQ0FBVCxFQUFXO0FBQUNpSixlQUFTakosQ0FBVDtBQUFXOztBQUF4QixDQUFwRCxFQUE4RSxDQUE5RTtBQUFpRixJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUE5QyxFQUFvRSxDQUFwRTtBQUF1RSxJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBWWplLElBQUk0QyxNQUFNLE1BQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLGNBQWQsRUFBOEJFLE1BQTlCO0FBQUEsb0NBQXNDO0FBQ3BDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxVQUFJUSxTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWI7QUFDQSxVQUFJdUIsaUJBQWlCLElBQUlaLGNBQUosRUFBckI7QUFDQSxvQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOO0FBRUEsVUFBSUUsV0FBVyxJQUFJN0csS0FBSixDQUFVTyxPQUFPdUcsT0FBakIsQ0FBZjtBQUNBLFVBQUlDLE1BQU0sSUFBSUwsUUFBSixDQUFhRyxRQUFiLENBQVY7QUFFQSxvQkFBTXJHLE9BQU9PLEtBQVAsQ0FDSixPQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBRTdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJQyx5QkFBaUJOLGVBQWVPLFFBQWYsQ0FBd0JILEtBQUtJLEdBQTdCLENBQWpCLENBQUo7QUFDQSwwQkFBTUwsSUFBSU0sV0FBSixDQUFnQkwsS0FBS00sSUFBTCxDQUFVQyxXQUFWLENBQXNCQyxnQkFBdEMsRUFBd0ROLFFBQXhELENBQU47QUFDRCxXQUhTO0FBRm1CLFNBQWYsQ0FBWixDQUFKO0FBT0EsZUFBT2pHLEdBQVA7QUFDRCxPQVRELENBRkksQ0FBTjtBQWFBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQXpCRDtBQUFBLEdBTGE7O0FBZ0NiO0FBQ0E7QUFFQSxHQUFRLEdBQUUvRSxHQUFJLFlBQWQsRUFBNEJFLE1BQTVCO0FBQUEsb0NBQW9DO0FBQ2xDLFVBQUlFLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBYjtBQUNBLFVBQUl3QixXQUFXLElBQUk3RyxLQUFKLENBQVVPLE9BQU91RyxPQUFqQixDQUFmO0FBQ0EsVUFBSUMsTUFBTSxJQUFJTCxRQUFKLENBQWFHLFFBQWIsQ0FBVjtBQUVBLFVBQUlELGlCQUFpQixJQUFJWixjQUFKLEVBQXJCO0FBQ0Esb0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTixFQU5rQyxDQVFsQzs7QUFDQSxVQUFJbkcsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLGVBREksRUFFSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFDN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlRLE1BQU1SLFFBQVFyQixVQUFsQjs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJOEIseUJBQWlCZCxlQUFlZSxnQkFBZixDQUFnQ3BILE9BQU9xSCxVQUF2QyxFQUFtRFosSUFBbkQsQ0FBakIsQ0FBSjtBQUVBLGtCQUFJYSwwQkFBa0JkLElBQUllLGFBQUosQ0FBa0JKLFFBQWxCLENBQWxCLENBQUosQ0FIRSxDQUtGOztBQUNBLDRCQUFNRCxJQUFJTSxNQUFKLENBQVc7QUFDZlgscUJBQUtKLEtBQUtJO0FBREssZUFBWCxFQUVIO0FBQ0RZLHNCQUFNO0FBQ0osaURBQStCSCxVQUFVNUcsR0FBVixDQUFjZ0gsVUFEekM7QUFFSix1REFBcUNKLFVBQVU1RyxHQUFWLENBQWN1RyxnQkFGL0M7QUFHSix1REFBcUNLLFVBQVU1RyxHQUFWLENBQWNpSDtBQUgvQztBQURMLGVBRkcsQ0FBTjtBQVVBMUgscUJBQU8ySCxRQUFQO0FBQ0QsYUFqQkQsQ0FpQkUsT0FBT3pFLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBdkJTO0FBRG1CLFNBQWYsRUEwQlRBLENBQVAsNkJBQWE7QUFDWCxnQkFBTUEsQ0FBTjtBQUNELFNBRkQsQ0ExQmdCLENBQVosQ0FBSjtBQThCQSxlQUFPekMsR0FBUDtBQUNELE9BaENELENBRkksQ0FBTjtBQW9DQSxvQkFBTVQsT0FBT08sS0FBUCxDQUNKLGdCQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJUSxNQUFNUixRQUFRckIsVUFBbEI7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSThCLHlCQUFpQmQsZUFBZWUsZ0JBQWYsQ0FBZ0NwSCxPQUFPcUgsVUFBdkMsRUFBbURaLElBQW5ELENBQWpCLENBQUo7QUFFQSw0QkFBTUQsSUFBSXFCLGtCQUFKLENBQXVCVixRQUF2QixDQUFOO0FBQ0EsNEJBQU1YLElBQUlzQixhQUFKLENBQWtCWCxRQUFsQixDQUFOO0FBQ0EsNEJBQU1YLElBQUl1QixnQkFBSixDQUFxQlosUUFBckIsQ0FBTjtBQUVBLGtCQUFJUix5QkFBaUJOLGVBQWVPLFFBQWYsQ0FBd0JILEtBQUtJLEdBQTdCLENBQWpCLENBQUo7QUFDQSw0QkFBTUwsSUFBSU0sV0FBSixDQUFnQkwsS0FBS00sSUFBTCxDQUFVQyxXQUFWLENBQXNCQyxnQkFBdEMsRUFBd0ROLFFBQXhELENBQU47QUFFQTFHLHFCQUFPMkgsUUFBUDtBQUNELGFBWEQsQ0FXRSxPQUFPekUsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0FqQlM7QUFEbUIsU0FBZixFQW9CVEEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQXBCZ0IsQ0FBWixDQUFKO0FBd0JBLGVBQU96QyxHQUFQO0FBQ0QsT0ExQkQsQ0FGSSxDQUFOO0FBOEJBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTlFRDtBQUFBOztBQW5DYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZEEsSUFBSW5GLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWdKLGFBQUo7QUFBa0JwSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDa0osZ0JBQWNoSixDQUFkLEVBQWdCO0FBQUNnSixvQkFBY2hKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUl1SSxjQUFKO0FBQW1CM0ksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1SSxxQkFBZXZJLENBQWY7QUFBaUI7O0FBQTdCLENBQWpELEVBQWdGLENBQWhGO0FBQW1GLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSThLLE1BQUo7QUFBV2xMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDOEssYUFBTzlLLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSStLLE9BQUo7QUFBWW5MLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMrSyxjQUFRL0ssQ0FBUjtBQUFVOztBQUF0QixDQUFqQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJZ0wsS0FBSjtBQUFVcEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2dMLFlBQU1oTCxDQUFOO0FBQVE7O0FBQXBCLENBQW5DLEVBQXlELENBQXpEO0FBQTRELElBQUlpTCxRQUFKO0FBQWFyTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDaUwsZUFBU2pMLENBQVQ7QUFBVzs7QUFBdkIsQ0FBakMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSWtMLEdBQUo7QUFBUXRMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxLQUFSLENBQWIsRUFBNEI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNrTCxVQUFJbEwsQ0FBSjtBQUFNOztBQUFsQixDQUE1QixFQUFnRCxDQUFoRDtBQWdCcnFCLE1BQU00QyxNQUFNLGtCQUFaO0FBRUEsTUFBTXVJLGtCQUFrQixPQUF4QjtBQUVBdkssT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxjQUFkLEVBQThCRSxNQUE5QjtBQUFBLG9DQUFzQztBQUNwQztBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSix1QkFESSxFQUVKLCtCQUFZO0FBQ1YsY0FBTThILFVBQVcsR0FBRXRJLE9BQU9zSSxPQUFRLFlBQWxDLENBRFUsQ0FFVjs7QUFDQSxZQUFJO0FBQ0Ysd0JBQU1MLFFBQVFNLEtBQVIsQ0FBY3ZJLE9BQU9zSSxPQUFyQixDQUFOO0FBQ0QsU0FGRCxDQUVFLE9BQU9uRixDQUFQLEVBQVUsQ0FBRTs7QUFDZCxZQUFJO0FBQ0Ysd0JBQU04RSxRQUFRTSxLQUFSLENBQWNELE9BQWQsQ0FBTjtBQUNELFNBRkQsQ0FFRSxPQUFPbkYsQ0FBUCxFQUFVO0FBQ1Y7QUFFQTtBQUVBLGNBQUlxRix5QkFBaUJQLFFBQVFqSyxRQUFSLENBQWtCLEdBQUVzSyxPQUFRLElBQUd0SSxPQUFPeUksY0FBZSxNQUFyRCxDQUFqQixDQUFKO0FBQ0FELG1DQUFpQk4sTUFBTVEsTUFBTixDQUFhRixRQUFiLEVBQXVCLE1BQXZCLENBQWpCO0FBQ0FBLG1DQUFpQk4sTUFBTVMsTUFBTixDQUFhSCxRQUFiLEVBQXVCLE9BQXZCLENBQWpCLEVBUFUsQ0FTVjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFDQSx3QkFBTXhJLE9BQU80SSxRQUFQLENBQWdCQyxPQUFoQixDQUNFMUYsQ0FBTiw2QkFBVztBQUNUMkYsb0JBQVFDLEdBQVIsQ0FBYSxjQUFhNUYsRUFBRTZGLFNBQVUsRUFBdEMsRUFEUyxDQUVUO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBOztBQUNBLGtCQUFNQyxVQUFVaEIsUUFBUWlCLGdCQUFSLENBQTBCLEdBQUVaLE9BQVEsSUFBR25GLEVBQUU2RixTQUFVLE1BQW5ELENBQWhCO0FBQ0FDLG9CQUFRRSxJQUFSLENBQWFqQixNQUFNa0IsWUFBTixDQUFtQixNQUFuQixDQUFiLEVBQ0dELElBREgsQ0FDUWpCLE1BQU1tQixZQUFOLENBQW1CLE9BQW5CLENBRFIsRUFFR0YsSUFGSCxDQUVRZixJQUFJa0IsS0FBSixDQUFVO0FBQ2RDLHVCQUFTO0FBREssYUFBVixDQUZSO0FBS0QsV0FoQkQsQ0FESSxDQUFOLEVBbkJVLENBc0NWO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0Q7O0FBQ0QsY0FBTSxJQUFJekwsT0FBTzBMLEtBQVgsQ0FBa0IsOERBQTZEbEIsT0FBUSxHQUF2RixDQUFOO0FBQ0QsT0ExREQsQ0FGSSxDQUFOO0FBOERELEtBbEVEO0FBQUE7O0FBTmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ3BCQSxJQUFJNUksTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQU83UixJQUFJNEMsTUFBTSxNQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXVCRSxNQUF2QjtBQUFBLG9DQUErQjtBQUM3QjtBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsVUFBSVEsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBRUEsWUFBTTJFLHlCQUFpQnZKLE9BQU9TLE9BQVAsQ0FBZSxFQUFmLEVBQTBCd0MsQ0FBUCw2QkFBYTtBQUNyRCxjQUFNQSxDQUFOO0FBQ0QsT0FGeUMsQ0FBbkIsQ0FBakIsQ0FBTjtBQUdBLG9CQUFNbEQsT0FBT08sS0FBUCxDQUNKLFVBREksRUFFSiwrQkFBWTtBQUNWLGVBQU9pSixRQUFQO0FBQ0QsT0FGRCxDQUZJLENBQU47QUFNQSxhQUFPeEosT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBaEJEO0FBQUE7O0FBTGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ1RBLElBQUluRixNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUkrSyxPQUFKO0FBQVluTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDK0ssY0FBUS9LLENBQVI7QUFBVTs7QUFBdEIsQ0FBakMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXdNLE9BQUo7QUFBWTVNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxpQkFBUixDQUFiLEVBQXdDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd00sY0FBUXhNLENBQVI7QUFBVTs7QUFBdEIsQ0FBeEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSXlNLFFBQUo7QUFBYTdNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDeU0sZUFBU3pNLENBQVQ7QUFBVzs7QUFBdkIsQ0FBcEQsRUFBNkUsQ0FBN0U7QUFBZ0YsSUFBSTBNLFNBQUo7QUFBYzlNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDME0sZ0JBQVUxTSxDQUFWO0FBQVk7O0FBQXhCLENBQTlDLEVBQXdFLENBQXhFO0FBYW5uQixNQUFNNEMsTUFBTSxPQUFaO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSw0QkFBZCxFQUE0Q0UsTUFBNUM7QUFBQSxvQ0FBb0Q7QUFDbEQ7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0oscUJBREksRUFFSiwrQkFBWTtBQUNWO0FBQ0E7QUFDQSxjQUFNNkYsaUJBQWlCLElBQUlaLGNBQUosRUFBdkI7QUFDQSxzQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOLEVBSlUsQ0FNVjtBQUNBOztBQUNBLFlBQUl5RCxvQkFBWXhELGVBQWV5RCxLQUFmLENBQXFCdEUsU0FBckIsQ0FDZCxDQUNFO0FBQ0V1RSxrQkFBUTtBQUNOQyxrQkFBTSxDQUNKO0FBQ0UscUNBQXVCO0FBQUVDLHlCQUFTO0FBQVg7QUFEekIsYUFESTtBQURBO0FBRFYsU0FERixFQTJCRTtBQUNFO0FBQ0FDLGtCQUFRO0FBQ05yRCxpQkFBSztBQURDO0FBRlYsU0EzQkYsRUFpQ0U7QUFDRXNELG9CQUFVO0FBQ1J0RCxpQkFBSyxDQURHO0FBRVJ1RCxzQkFBVTtBQUZGO0FBRFosU0FqQ0YsQ0FEYyxDQUFaLENBQUosQ0FSVSxDQW1EVjs7QUFDQSxZQUFJNUQsTUFBTSxJQUFJbUQsUUFBSixDQUFhM0osT0FBT3FLLFlBQXBCLEVBQWtDckssT0FBT3NLLE1BQXpDLENBQVY7QUFDQSxzQkFBTXJLLE9BQU9zSyxlQUFQLENBQ0pWLEdBREksRUFFRXBELElBQU4sNkJBQWM7QUFDWitELGlCQUFPQyxNQUFQLENBQWNoRSxJQUFkLGdCQUEwQkosZUFBZXFFLG9DQUFmLENBQW9EakUsS0FBSzJELFFBQXpELENBQTFCOztBQUNBLGNBQUk7QUFDRixnQkFBSTFKLG9CQUFZOEYsSUFBSW1FLFVBQUosQ0FBZWxFLElBQWYsQ0FBWixDQUFKO0FBQ0EsbUJBQU87QUFBQ21FLDJCQUFhbkUsSUFBZDtBQUFvQm9FLHdCQUFVbks7QUFBOUIsYUFBUDtBQUNELFdBSEQsQ0FHRSxPQUFPeUMsQ0FBUCxFQUFVO0FBQ1Ysa0JBQU1xSCxPQUFPQyxNQUFQLENBQWM7QUFBQ0csMkJBQWFuRTtBQUFkLGFBQWQsRUFBbUNtRCxVQUFVTixLQUFWLENBQWdCbkcsQ0FBaEIsQ0FBbkMsQ0FBTjtBQUNEO0FBQ0YsU0FSRCxDQUZJLENBQU47QUFZRCxPQWpFRCxDQUZJLENBQU47QUFzRUEsYUFBT2xELE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTNFRDtBQUFBLEdBTGE7O0FBa0ZiO0FBQ0E7QUFFQSxHQUFRLEdBQUUvRSxHQUFJLGtCQUFkLEVBQWtDRSxNQUFsQztBQUFBLG9DQUEwQztBQUN4QztBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSiwwQkFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUNBLGNBQU02RixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFKVSxDQU1WO0FBQ0E7O0FBQ0EsWUFBSXlELG9CQUFZeEQsZUFBZXlELEtBQWYsQ0FBcUJ0RSxTQUFyQixDQUNkLENBQ0U7QUFDRXVFLGtCQUFRO0FBQ05DLGtCQUFNLENBQ0o7QUFDRSxxQ0FBdUI7QUFBRUMseUJBQVM7QUFBWCxlQUR6QixDQUdBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBaEJBLGFBREk7QUFEQTtBQURWLFNBREYsRUF3QkU7QUFDRTtBQUNBQyxrQkFBUTtBQUNOckQsaUJBQUs7QUFEQztBQUZWLFNBeEJGLEVBOEJFO0FBQ0VzRCxvQkFBVTtBQUNSdEQsaUJBQUssQ0FERztBQUVSdUQsc0JBQVU7QUFGRjtBQURaLFNBOUJGLENBRGMsQ0FBWixDQUFKLENBUlUsQ0FnRFY7O0FBQ0EsWUFBSTVELE1BQU0sSUFBSW1ELFFBQUosQ0FBYTNKLE9BQU9xSyxZQUFwQixFQUFrQ3JLLE9BQU9zSyxNQUF6QyxDQUFWO0FBQ0Esc0JBQU1ySyxPQUFPc0ssZUFBUCxDQUNKVixHQURJLEVBRUVwRCxJQUFOLDZCQUFjO0FBQ1pBLGVBQUtxRSxVQUFMLEdBQWtCLENBQWxCO0FBQ0FyRSxlQUFLc0UsYUFBTCxHQUFxQixNQUFyQjs7QUFDQSxjQUFJO0FBQ0YsZ0JBQUlySyxvQkFBWThGLElBQUltRSxVQUFKLENBQWVsRSxJQUFmLENBQVosQ0FBSjtBQUNBLG1CQUFPO0FBQUNtRSwyQkFBYW5FLElBQWQ7QUFBb0JvRSx3QkFBVW5LO0FBQTlCLGFBQVA7QUFDRCxXQUhELENBR0UsT0FBT3lDLENBQVAsRUFBVTtBQUNWLGtCQUFNcUgsT0FBT0MsTUFBUCxDQUFjO0FBQUNHLDJCQUFhbkU7QUFBZCxhQUFkLEVBQW1DbUQsVUFBVU4sS0FBVixDQUFnQm5HLENBQWhCLENBQW5DLENBQU47QUFDRDtBQUNGLFNBVEQsQ0FGSSxDQUFOO0FBYUQsT0EvREQsQ0FGSSxDQUFOO0FBb0VBLGFBQU9sRCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0F6RUQ7QUFBQSxHQXJGYTs7QUFnS2I7QUFDQTtBQUVBLEdBQVEsR0FBRS9FLEdBQUksY0FBZCxFQUE4QkUsTUFBOUI7QUFBQSxvQ0FBc0M7QUFDcEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osYUFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUNBLGNBQU02RixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU47QUFFQSxZQUFJeUQsb0JBQVl4RCxlQUFleUQsS0FBZixDQUFxQnRFLFNBQXJCLENBQ2QsQ0FDRTtBQUNFdUUsa0JBQVE7QUFDTkMsa0JBQU0sQ0FDSjtBQUNFLHFDQUF1QjtBQUFFQyx5QkFBUztBQUFYLGVBRHpCLENBR0E7QUFDRjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFoQkUsYUFESTtBQURBO0FBRFYsU0FERixFQXdCRTtBQUNFO0FBQ0FDLGtCQUFRO0FBQ05yRCxpQkFBSztBQUNIdUQsd0JBQVUsc0JBRFA7QUFFSFksMENBQTRCLHlCQUZ6QjtBQUdIQyx3Q0FBMEI7QUFIdkIsYUFEQztBQU1OeEUsa0JBQU07QUFDSnlFLHNCQUFRO0FBREo7QUFOQTtBQUZWLFNBeEJGLEVBcUNFO0FBQ0U7QUFDQWhCLGtCQUFRO0FBQ05yRCxpQkFBSyxlQURDO0FBRU5zRSx3QkFBWTtBQUNWQyxxQkFBTztBQUNMdkUscUJBQUssT0FEQTtBQUVMbUUsNENBQTRCLGlDQUZ2QjtBQUdMQywwQ0FBMEI7QUFIckI7QUFERztBQUZOO0FBRlYsU0FyQ0YsRUFrREU7QUFDRWQsb0JBQVU7QUFDUnRELGlCQUFLLENBREc7QUFFUnVELHNCQUFVLE1BRkY7QUFHUmUsd0JBQVk7QUFISjtBQURaLFNBbERGLENBRGMsQ0FBWixDQUFKLENBTlUsQ0FtRVY7QUFDQTtBQUVBOztBQUNBLDZCQUFhdEIsSUFBSXdCLE9BQUosRUFBYixHQUE0QjtBQUMxQixjQUFJNUUscUJBQWFvRCxJQUFJeUIsSUFBSixFQUFiLENBQUosQ0FEMEIsQ0FHMUI7O0FBQ0EsZUFBSyxJQUFJbkksQ0FBVCxJQUFjc0QsS0FBSzBFLFVBQW5CLEVBQStCO0FBQzdCaEksY0FBRW9JLEtBQUYsaUJBQWdCbEYsZUFBZU8sUUFBZixDQUF3QnpELEVBQUUwRCxHQUExQixDQUFoQjtBQUNBLG1CQUFPMUQsRUFBRTBELEdBQVQ7QUFDRCxXQVB5QixDQVMxQjtBQUNBOzs7QUFDQSxjQUFJTCxNQUFNLElBQUltRCxRQUFKLENBQWEzSixPQUFPcUssWUFBcEIsRUFBa0NySyxPQUFPc0ssTUFBekMsQ0FBVjs7QUFDQSxjQUFJO0FBQ0YsZ0JBQUk1SixvQkFBWThGLElBQUlNLFdBQUosQ0FBZ0IsQ0FBQ0wsSUFBRCxDQUFoQixDQUFaLENBQUo7QUFDQXhHLG1CQUFPMkgsUUFBUCxDQUFnQmxILEdBQWhCO0FBQ0QsV0FIRCxDQUdFLE9BQU95QyxDQUFQLEVBQVU7QUFDVmxELG1CQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRjs7QUFDRDBHLFlBQUkyQixLQUFKO0FBQ0QsT0EzRkQsQ0FGSSxDQUFOO0FBK0ZBLGFBQU92TCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0FwR0Q7QUFBQSxHQW5LYTs7QUF5UWI7QUFDQTtBQUVBLEdBQVEsR0FBRS9FLEdBQUksYUFBZCxFQUE2QkUsTUFBN0I7QUFBQSxvQ0FBcUM7QUFDbkM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osZUFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUVBLGNBQU1OLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBZjtBQUNBLGNBQU11QixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOVSxDQVFWOztBQUNBLFlBQUk7QUFDRix3QkFBTTZCLFFBQVFNLEtBQVIsQ0FBY3ZJLE9BQU9zSSxPQUFyQixDQUFOO0FBQ0QsU0FGRCxDQUVFLE9BQU9uRixDQUFQLEVBQVUsQ0FBRSxDQVhKLENBYVY7OztBQUNBLGNBQU1tRixVQUFXLEdBQUV0SSxPQUFPc0ksT0FBUSxVQUFVLElBQUltRCxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUF1QixFQUFsRSxDQWRVLENBZVY7O0FBQ0EsWUFBSTtBQUNGLHdCQUFNekQsUUFBUU0sS0FBUixDQUFjRCxPQUFkLENBQU47QUFDRCxTQUZELENBRUUsT0FBT25GLENBQVAsRUFBVSxDQUFFLENBbEJKLENBb0JWO0FBQ0E7OztBQUVBLFlBQUl6QyxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBRTdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJaUYsVUFBVXRNLEtBQUtpSyxLQUFMLENBQVdqSyxLQUFLQyxTQUFMLENBQWVVLE9BQU80TCxRQUF0QixDQUFYLENBQWQ7QUFDQUQsb0JBQVFFLEdBQVIsR0FBZSxHQUFFRixRQUFRRSxHQUFJLGlCQUE3QjtBQUNBRixvQkFBUUcsRUFBUixDQUFXMUIsUUFBWCxHQUFzQjNELEtBQUtNLElBQUwsQ0FBVWdGLEtBQVYsQ0FBZ0IzQixRQUF0QztBQUVBLGdCQUFJNEIsc0JBQWN0QyxRQUFRaUMsT0FBUixDQUFkLENBQUo7QUFDQSxnQkFBSW5OLFdBQVksR0FBRThKLE9BQVEsSUFBRzdCLEtBQUtmLEtBQU0sTUFBeEM7QUFFQSwwQkFBTXVDLFFBQVEvSixTQUFSLENBQWtCTSxRQUFsQixFQUE0QndOLEtBQTVCLENBQU47QUFDRCxXQVRTO0FBRm1CLFNBQWYsQ0FBWixDQUFKO0FBYUEsZUFBT3RMLEdBQVA7QUFDRCxPQXJDRCxDQUZJLENBQU47QUF5Q0EsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBOUNEO0FBQUE7O0FBNVFhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQSxJQUFJbkYsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJK08sa0JBQUo7QUFBdUJuUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDaVAscUJBQW1CL08sQ0FBbkIsRUFBcUI7QUFBQytPLHlCQUFtQi9PLENBQW5CO0FBQXFCOztBQUE1QyxDQUFwRCxFQUFrRyxDQUFsRztBQUFxRyxJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBUWpVLE1BQU00QyxNQUFNLFVBQVo7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLFVBQWQsRUFBMEJFLE1BQTFCO0FBQUEsb0NBQWtDO0FBQ2hDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLGVBREksRUFFSiwrQkFBWTtBQUNWO0FBQ0E7QUFFQSxjQUFNTixTQUFTLElBQUkrTCxrQkFBSixDQUF1QmpNLE9BQU80TCxRQUE5QixFQUF3QzVMLE9BQU84RSxPQUEvQyxDQUFmO0FBQ0EsY0FBTXVCLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTixFQU5VLENBUVY7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUNBOztBQUVBLFlBQUkxRixvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBRTdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDekcsbUJBQU8ySCxRQUFQLENBQWdCbkIsSUFBaEI7QUFDRCxXQUZTO0FBRm1CLFNBQWYsQ0FBWixDQUFKO0FBTUEsZUFBTy9GLEdBQVA7QUFDRCxPQTlCRCxDQUZJLENBQU47QUFrQ0EsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBdkNEO0FBQUE7O0FBTGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ1ZBLElBQUluRixNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk4SyxNQUFKO0FBQVdsTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzhLLGFBQU85SyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUkrSyxPQUFKO0FBQVluTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDK0ssY0FBUS9LLENBQVI7QUFBVTs7QUFBdEIsQ0FBakMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSWdMLEtBQUo7QUFBVXBMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNnTCxZQUFNaEwsQ0FBTjtBQUFROztBQUFwQixDQUFuQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJaUwsUUFBSjtBQUFhckwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2lMLGVBQVNqTCxDQUFUO0FBQVc7O0FBQXZCLENBQWpDLEVBQTBELENBQTFEO0FBQTZELElBQUlrTCxHQUFKO0FBQVF0TCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsS0FBUixDQUFiLEVBQTRCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDa0wsVUFBSWxMLENBQUo7QUFBTTs7QUFBbEIsQ0FBNUIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSWdQLFdBQUosRUFBZ0JDLFNBQWhCO0FBQTBCclAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDa1AsY0FBWWhQLENBQVosRUFBYztBQUFDZ1Asa0JBQVloUCxDQUFaO0FBQWMsR0FBOUI7O0FBQStCaVAsWUFBVWpQLENBQVYsRUFBWTtBQUFDaVAsZ0JBQVVqUCxDQUFWO0FBQVk7O0FBQXhELENBQS9CLEVBQXlGLENBQXpGO0FBZWx2QixNQUFNa1AsU0FBUyxRQUFmO0FBQ0EsTUFBTXRNLE1BQU0sT0FBWjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksUUFBZCxFQUF3QkUsTUFBeEI7QUFBQSxvQ0FBZ0M7QUFDOUI7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osUUFESSxFQUVKLCtCQUFZO0FBQ1YsY0FBTTZGLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTjtBQUNBLGNBQU1rQyxVQUFXLEdBQUV0SSxPQUFPc0ksT0FBUSxRQUFsQztBQUNBLGNBQU0rRCxJQUFJcEUsUUFBUWlCLGdCQUFSLENBQTBCLEdBQUVaLE9BQVEsSUFBR3RJLE9BQU9zTSxhQUFjLEVBQTVELENBQVY7QUFDQSxjQUFNQyxJQUFJdEUsUUFBUXVFLGlCQUFSLENBQTJCLEdBQUVsRSxPQUFRLElBQUd0SSxPQUFPeU0sYUFBYyxFQUE3RCxDQUFWO0FBQ0FKLFVBQUVsRCxJQUFGLENBQU9qQixNQUFNa0IsWUFBTixDQUFtQixNQUFuQixDQUFQLEVBQ0dELElBREgsQ0FDUWpCLE1BQU1tQixZQUFOLENBQW1CLE9BQW5CLENBRFIsRUFFR0YsSUFGSCxDQUVRZixJQUFJa0IsS0FBSixDQUFVO0FBQUNDLG1CQUFTO0FBQVYsU0FBVixDQUZSLEVBR0dKLElBSEgsQ0FHUWYsSUFBSXNFLFNBQUosQ0FDSixDQUFPN0wsTUFBUCxFQUFlOEwsUUFBZiw4QkFBNEI7QUFDMUIsY0FBSTNOLE1BQU0sSUFBVixDQUQwQixDQUUxQjs7QUFDQSxjQUFJO0FBQ0Y2QixtQkFBTyxNQUFQLGtCQUF1QndGLGVBQWV1RyxhQUFmLENBQTZCL0wsT0FBTyxNQUFQLENBQTdCLENBQXZCO0FBQ0QsV0FGRCxDQUVFLE9BQU9zQyxDQUFQLEVBQVU7QUFDVm5FLGtCQUFNbUUsQ0FBTjtBQUNEOztBQUNEd0osbUJBQVMzTixHQUFULEVBQWM2QixNQUFkO0FBQ0QsU0FURCxDQURJLENBSFIsRUFlR3NJLElBZkgsQ0FlUWYsSUFBSTlJLFNBQUosQ0FBYztBQUFDdU4sa0JBQVE7QUFBVCxTQUFkLENBZlIsRUFnQkcxRCxJQWhCSCxDQWdCUWpCLE1BQU1rQixZQUFOLENBQW1CLE9BQW5CLENBaEJSLEVBaUJHRCxJQWpCSCxDQWlCUWpCLE1BQU1tQixZQUFOLENBQW1CLE1BQW5CLENBakJSLEVBa0JHRixJQWxCSCxDQWtCUW9ELENBbEJSO0FBbUJELE9BekJELENBRkksQ0FBTjtBQTZCRCxLQWpDRDtBQUFBLEdBTGE7O0FBd0NiO0FBQ0E7QUFFQSxHQUFRLEdBQUV6TSxHQUFJLFVBQWQsRUFBMEJFLE1BQTFCO0FBQUEsb0NBQWtDO0FBQ2hDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLFFBREksRUFFSiwrQkFBWTtBQUNWO0FBQ0E7QUFFQSxjQUFNTixTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWY7QUFDQSxjQUFNdUIsaUJBQWlCLElBQUlaLGNBQUosRUFBdkI7QUFDQSxzQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOLEVBTlUsQ0FRVjs7QUFDQSxjQUFNMEcsU0FBUyxJQUFJOUUsTUFBSixDQUFXaEksT0FBTytNLFVBQWxCLENBQWYsQ0FUVSxDQVdWOztBQUNBLFlBQUk7QUFDRix3QkFBTTlFLFFBQVFNLEtBQVIsQ0FBY3ZJLE9BQU9zSSxPQUFyQixDQUFOO0FBQ0QsU0FGRCxDQUVFLE9BQU9uRixDQUFQLEVBQVUsQ0FBRSxDQWRKLENBZ0JWOzs7QUFDQSxjQUFNbUYsVUFBVyxHQUFFdEksT0FBT3NJLE9BQVEsT0FBbEM7QUFDQSxzQkFBTUwsUUFBUStFLE1BQVIsQ0FBZTFFLE9BQWYsQ0FBTjtBQUNBLHNCQUFNTCxRQUFRTSxLQUFSLENBQWNELE9BQWQsQ0FBTixFQW5CVSxDQXFCVjs7QUFDQSxjQUFNMkUsWUFBYSxHQUFFak4sT0FBT3NJLE9BQVEsU0FBcEM7QUFDQSxzQkFBTUwsUUFBUStFLE1BQVIsQ0FBZUMsU0FBZixDQUFOO0FBQ0Esc0JBQU1oRixRQUFRTSxLQUFSLENBQWMwRSxTQUFkLENBQU47QUFFQSxZQUFJQyxLQUFLLElBQVQsQ0ExQlUsQ0EwQkk7O0FBQ2QsWUFBSTFPLFdBQVcsSUFBZixDQTNCVSxDQTJCVTs7QUFDcEIsWUFBSU0sT0FBTyxJQUFYLENBNUJVLENBNEJNO0FBRWhCOztBQUNBLFlBQUlxTyxTQUFTLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsTUFBakIsRUFBeUIsSUFBekIsRUFBK0IsZ0JBQS9CLEVBQWlELE1BQWpELEVBQXlELE1BQXpELEVBQWlFLE9BQWpFLEVBQTBFLElBQTFFLEVBQWdGLFFBQWhGLEVBQTBGLElBQTFGLEVBQWdHLE1BQWhHLEVBQXdHLFlBQXhHLEVBQXNILFlBQXRILEVBQW9JLE1BQXBJLEVBQTRJLFdBQTVJLEVBQXlKLFlBQXpKLEVBQXVLLE9BQXZLLEVBQWdMLFNBQWhMLEVBQTJMLE9BQTNMLEVBQW9NLFNBQXBNLEVBQStNLEtBQS9NLEVBQXNOLFNBQXROLEVBQWlPLEtBQWpPLEVBQXdPLFNBQXhPLEVBQW1QLEtBQW5QLEVBQTBQLFNBQTFQLEVBQXFRLEtBQXJRLEVBQTRRLFNBQTVRLEVBQXVSLEtBQXZSLEVBQThSLFNBQTlSLEVBQXlTLEtBQXpTLEVBQWdULFNBQWhULEVBQTJULEtBQTNULEVBQWtVLFNBQWxVLEVBQTZVLEtBQTdVLEVBQW9WLFNBQXBWLEVBQStWLEtBQS9WLEVBQXNXLFNBQXRXLEVBQWlYLE1BQWpYLEVBQXlYLFVBQXpYLEVBQXFZLE1BQXJZLEVBQTZZLFFBQTdZLEVBQXVaLFNBQXZaLEVBQWthLE1BQWxhLEVBQTBhLE1BQTFhLEVBQWtiLFVBQWxiLEVBQThiLE9BQTliLEVBQXVjLFFBQXZjLEVBQWlkLFFBQWpkLEVBQTJkLFdBQTNkLEVBQXdlLFFBQXhlLEVBQWtmLEtBQWxmLEVBQXlmLGNBQXpmLEVBQXlnQixTQUF6Z0IsRUFBb2hCLFNBQXBoQixFQUEraEIsWUFBL2hCLEVBQTZpQixjQUE3aUIsRUFBNmpCLFFBQTdqQixFQUF1a0IsT0FBdmtCLEVBQWdsQixRQUFobEIsRUFBMGxCLFVBQTFsQixFQUFzbUIsbUJBQXRtQixFQUEybkIsZ0JBQTNuQixFQUE2b0IsVUFBN29CLEVBQXlwQixtQkFBenBCLEVBQThxQixnQkFBOXFCLEVBQWdzQixVQUFoc0IsRUFBNHNCLG1CQUE1c0IsRUFBaXVCLGdCQUFqdUIsRUFBbXZCLFVBQW52QixFQUErdkIsbUJBQS92QixFQUFveEIsZ0JBQXB4QixFQUFzeUIsVUFBdHlCLEVBQWt6QixtQkFBbHpCLEVBQXUwQixnQkFBdjBCLEVBQXkxQixVQUF6MUIsRUFBcTJCLG1CQUFyMkIsRUFBMDNCLGdCQUExM0IsRUFBNDRCLFVBQTU0QixFQUF3NUIsbUJBQXg1QixFQUE2NkIsZ0JBQTc2QixFQUErN0IsVUFBLzdCLEVBQTI4QixtQkFBMzhCLEVBQWcrQixnQkFBaCtCLEVBQWsvQixVQUFsL0IsRUFBOC9CLG1CQUE5L0IsRUFBbWhDLGdCQUFuaEMsRUFBcWlDLFdBQXJpQyxFQUFrakMsb0JBQWxqQyxFQUF3a0MsaUJBQXhrQyxFQUEybEMsTUFBM2xDLEVBQW1tQyxXQUFubUMsRUFBZ25DLFNBQWhuQyxFQUEybkMsT0FBM25DLEVBQW9vQyxnQkFBcG9DLENBQWI7QUFDQSxZQUFJTixTQUFTTSxPQUFPQyxHQUFQLENBQVdsUSxLQUFNLElBQUdBLENBQUUsR0FBdEIsRUFBMEJtUSxJQUExQixDQUErQixHQUEvQixJQUFzQyxJQUFuRCxDQWhDVSxDQWtDVjs7QUFDQVAsZUFBT1EsYUFBUCxHQUE4QkMsV0FBUCw2QkFBdUI7QUFDNUN6TyxpQkFBT3NOLFNBQVMsQ0FBQyxVQUFVbUIsV0FBWCxFQUF3QkMsS0FBeEIsQ0FBOEIsQ0FBQyxDQUEvQixDQUFoQjtBQUNBTixlQUFNLEdBQUU1RSxPQUFRLElBQUd4SixJQUFLLEVBQXhCO0FBQ0FOLHFCQUFZLEdBQUUwTyxFQUFHLElBQUdsTixPQUFPeU4sV0FBWSxFQUF2QztBQUNBLHdCQUFNeEYsUUFBUU0sS0FBUixDQUFjMkUsRUFBZCxDQUFOLEVBSjRDLENBSzVDOztBQUNBLHdCQUFNakYsUUFBUXlGLFVBQVIsQ0FBbUJsUCxRQUFuQixFQUE2QjBKLE1BQU1TLE1BQU4sQ0FBYWtFLE1BQWIsRUFBcUIsV0FBckIsQ0FBN0IsQ0FBTjtBQUNELFNBUHNCLENBQXZCLENBbkNVLENBNENWOzs7QUFDQUMsZUFBT2EsUUFBUCxHQUF5QkMsR0FBUCw2QkFBZTtBQUMvQixjQUFJQyxRQUFRRCxJQUFJQyxLQUFoQjtBQUNBLGNBQUlwSCxPQUFPbUgsSUFBSW5ILElBQWYsQ0FGK0IsQ0FHL0I7O0FBQ0EsY0FBSTVGLFNBQVNzTSxPQUFPQyxHQUFQLENBQVdsUSxLQUFLO0FBQUUsbUJBQU8yUSxNQUFNM1EsQ0FBTixJQUFZLElBQUcyUSxNQUFNM1EsQ0FBTixDQUFTLEdBQXhCLEdBQTZCLElBQXBDO0FBQTBDLFdBQTVELEVBQThEbVEsSUFBOUQsQ0FBbUUsR0FBbkUsSUFBMEUsSUFBdkY7QUFDQSx3QkFBTXBGLFFBQVF5RixVQUFSLENBQW1CbFAsUUFBbkIsRUFBNkIwSixNQUFNUyxNQUFOLENBQWE5SCxNQUFiLEVBQXFCLFdBQXJCLENBQTdCLENBQU4sRUFMK0IsQ0FNL0I7O0FBQ0EsZUFBSyxJQUFJaU4sR0FBVCxJQUFnQnJILEtBQUtzSCxNQUFyQixFQUE2QjtBQUMzQixnQkFBSUMsU0FBVSxHQUFFaE8sT0FBT3JCLFFBQVMsSUFBR21QLEdBQUksRUFBdkM7QUFDQSxnQkFBSUcsU0FBVSxHQUFFZixFQUFHLElBQUdZLEdBQUksRUFBMUI7O0FBQ0EsZ0JBQUk7QUFDRjtBQUNBLDRCQUFNN0YsUUFBUWlHLE1BQVIsQ0FBZUQsTUFBZixDQUFOO0FBQ0QsYUFIRCxDQUdFLE9BQU85SyxDQUFQLEVBQVU7QUFDViw0QkFBTThFLFFBQVFrRyxRQUFSLENBQWlCSCxNQUFqQixFQUF5QkMsTUFBekIsQ0FBTjtBQUNEO0FBQ0Y7QUFDRixTQWpCaUIsQ0FBbEIsQ0E3Q1UsQ0FnRVY7OztBQUNBbkIsZUFBT3NCLFdBQVAsR0FBNEJiLFdBQVAsNkJBQXVCO0FBQzFDLGdCQUFNYyxNQUFNbEcsU0FBUyxLQUFULENBQVo7QUFDQSxnQkFBTW1HLFVBQVcsR0FBRXJCLFNBQVUsSUFBR25PLElBQUssTUFBckM7QUFDQSxnQkFBTXlQLFNBQVN0RyxRQUFRdUUsaUJBQVIsQ0FBMEI4QixPQUExQixDQUFmO0FBQ0FELGNBQUlsRixJQUFKLENBQVNvRixNQUFUO0FBQ0FGLGNBQUlHLFNBQUosQ0FBY3RCLEVBQWQsRUFBa0IsS0FBbEI7QUFDQW1CLGNBQUlJLFFBQUo7QUFDRCxTQVBvQixDQUFyQixDQWpFVSxDQTBFVjtBQUNBOzs7QUFFQSxZQUFJL04sb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSUMseUJBQWlCTixlQUFlTyxRQUFmLENBQXdCSCxLQUFLSSxHQUE3QixDQUFqQixDQUFKLENBRGlDLENBRWpDOztBQUNBLGdCQUFJRixZQUFZRixLQUFLTSxJQUFMLENBQVU4RyxLQUFWLENBQWdCYSxXQUFoQyxFQUE2QztBQUMzQyxrQkFBSWIsc0JBQWN4SCxlQUFlc0ksZ0JBQWYsQ0FBZ0MzTyxPQUFPL0MsT0FBdkMsRUFBZ0R3SixJQUFoRCxDQUFkLENBQUo7QUFDQSw0QkFBTXFHLE9BQU84QixNQUFQLENBQWM7QUFBQ2YsdUJBQU9BLEtBQVI7QUFBZXBILHNCQUFNQTtBQUFyQixlQUFkLENBQU47QUFDRDtBQUNGLFdBUFM7QUFGbUIsU0FBZixDQUFaLENBQUo7QUFXQXFHLGVBQU90QixLQUFQO0FBRUEsZUFBTzlLLEdBQVA7QUFDRCxPQTNGRCxDQUZJLENBQU47QUErRkEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBcEdEO0FBQUE7O0FBM0NhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNsQkEvSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsK0JBQVIsQ0FBYjtBQUF1REYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBdkRGLE9BQU8rUixNQUFQLENBQWM7QUFBQ0MsV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSUMsS0FBSjtBQUFValMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDK1IsUUFBTTdSLENBQU4sRUFBUTtBQUFDNlIsWUFBTTdSLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFeEMsTUFBTTRSLFVBQVUsSUFBSUMsTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUFnQztBQUFDQyxnQkFBYztBQUFmLENBQWhDLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDRlBuUyxPQUFPK1IsTUFBUCxDQUFjO0FBQUNoUCxVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJa1AsS0FBSjtBQUFValMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDK1IsUUFBTTdSLENBQU4sRUFBUTtBQUFDNlIsWUFBTTdSLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlnUyxJQUFKO0FBQVNwUyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDZ1MsV0FBS2hTLENBQUw7QUFBTzs7QUFBbkIsQ0FBN0IsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSWlTLE9BQUo7QUFBWXJTLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNpUyxjQUFRalMsQ0FBUjtBQUFVOztBQUF0QixDQUFwQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJa1MsU0FBSjtBQUFjdFMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDb1MsWUFBVWxTLENBQVYsRUFBWTtBQUFDa1MsZ0JBQVVsUyxDQUFWO0FBQVk7O0FBQTFCLENBQWpDLEVBQTZELENBQTdEO0FBYW5aLE1BQU1tUyxVQUFVLElBQUlOLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBZ0M7QUFDOUNDLGdCQUFjO0FBRGdDLENBQWhDLENBQWhCOztBQUlPLE1BQU1wUCxNQUFOLFNBQXFCdVAsU0FBckIsQ0FBK0I7QUFFcENFLGNBQVlDLFFBQVosRUFBc0I7QUFFcEIsUUFBSXpLLFVBQVV1SyxRQUFRRyxPQUFSLENBQWdCO0FBQzVCM0ksV0FBSzBJO0FBRHVCLEtBQWhCLENBQWQ7QUFJQSxVQUFNekssT0FBTjtBQUVBLFFBQUlHLE9BQU8sS0FBS3dLLE9BQUwsRUFBWDs7QUFFQSxZQUFReEssS0FBS3lLLElBQWI7QUFFRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSWxRLEtBQUosQ0FBVXdGLEtBQUsxRSxJQUFmLENBQWI7O0FBQ0EsYUFBS3FQLE1BQUwsR0FBYyxDQUFRQyxXQUFZaFAsTUFBRCxJQUFVLENBQUUsQ0FBL0IsRUFBaUNpUCxVQUFXM00sQ0FBRCxJQUFLLENBQUUsQ0FBbEQsOEJBQXdEO0FBQ3BFLGNBQUlyQyxNQUFPLGlCQUFnQm1FLEtBQUs4SyxLQUFNLEVBQXRDO0FBQ0EsK0JBQWEsS0FBS0osS0FBTCxDQUFXSyxjQUFYLENBQTBCbFAsR0FBMUIsRUFBK0IrTyxRQUEvQixFQUF5Q0MsT0FBekMsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFFRjtBQUNFLGNBQU0sSUFBSXRHLEtBQUosQ0FBVSx1QkFBVixDQUFOO0FBWEo7QUFjRDtBQUVEOzs7Ozs7QUFJTTdJLFNBQU4sQ0FBY3NQLFlBQVksRUFBMUIsRUFBOEJILFVBQWlCM00sQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBeEM7QUFBQSxvQ0FBeUQ7QUFFdkQsVUFBSTJCLFVBQVUsS0FBS29MLFVBQUwsRUFBZCxDQUZ1RCxDQUl2RDs7QUFDQXBMLGNBQVFxTCxPQUFSLENBQWdCQyxJQUFoQixDQUFxQjtBQUNuQlYsY0FBTSxNQURhO0FBRW5CalAsZUFBTztBQUZZLE9BQXJCO0FBS0EsVUFBSTRQLFFBQVEsRUFBWjs7QUFDQSxXQUFLLElBQUluUSxNQUFULElBQW1CNEUsUUFBUXFMLE9BQTNCLEVBQW9DO0FBQ2xDRSxjQUFNblEsT0FBT3dQLElBQWIsSUFBcUI7QUFDbkJqUCxpQkFBT1AsT0FBT08sS0FESztBQUVuQjRQLGlCQUFPO0FBRlksU0FBckI7QUFJRDs7QUFFRCxvQkFBTSxLQUFLVCxNQUFMLENBQ0cvTyxNQUFQLDZCQUFnQjtBQUNkLGFBQUssSUFBSVgsTUFBVCxJQUFtQjRFLFFBQVFxTCxPQUEzQixFQUFvQztBQUNsQyxjQUFJMVAsUUFBUTBPLFFBQVFtQixRQUFSLENBQWlCcFEsT0FBT08sS0FBeEIsQ0FBWjtBQUNBLGNBQUk4UCxPQUFPckIsS0FBTXpPLEtBQU4sQ0FBWDs7QUFDQSxjQUFJOFAsS0FBSzFQLE1BQUwsQ0FBSixFQUFrQjtBQUNoQndQLGtCQUFNblEsT0FBT3dQLElBQWIsRUFBbUJXLEtBQW5COztBQUNBLGdCQUFJLE9BQU9KLFVBQVUvUCxPQUFPd1AsSUFBakIsQ0FBUCxLQUFrQyxXQUF0QyxFQUFrRDtBQUNoRCw0QkFBTU8sVUFBVS9QLE9BQU93UCxJQUFqQixFQUF1QjdPLE1BQXZCLENBQU47QUFDRDs7QUFDRDtBQUNEO0FBQ0Y7QUFDRixPQVpELENBREksRUFjSmlQLE9BZEksQ0FBTixFQWxCdUQsQ0FtQ3ZEOztBQUNBLGFBQU9PLEtBQVA7QUFFRCxLQXRDRDtBQUFBOztBQWhDb0MsQzs7Ozs7Ozs7Ozs7QUNqQnRDdlQsT0FBTytSLE1BQVAsQ0FBYztBQUFDTyxhQUFVLE1BQUlBLFNBQWY7QUFBeUJ6UCxTQUFNLE1BQUlBO0FBQW5DLENBQWQ7QUFBeUQsSUFBSW9QLEtBQUo7QUFBVWpTLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQytSLFFBQU03UixDQUFOLEVBQVE7QUFBQzZSLFlBQU03UixDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQVFuTixNQUFNc1QsU0FBUyxJQUFJekIsTUFBTUMsVUFBVixDQUFxQixRQUFyQixFQUErQjtBQUM1Q0MsZ0JBQWM7QUFEOEIsQ0FBL0IsQ0FBZjs7QUFJTyxNQUFNRyxTQUFOLENBQWdCO0FBSXJCRSxjQUFZeEssT0FBWixFQUFxQjtBQUNuQixTQUFLQSxPQUFMLEdBQWVBLE9BQWY7QUFDRDtBQUVEOzs7Ozs7O0FBS0EySyxZQUFVO0FBQ1IsV0FBTyxLQUFLM0ssT0FBTCxDQUFhMkwsWUFBcEI7QUFDRDs7QUFFRFAsZUFBYTtBQUNYLFdBQU8sS0FBS3BMLE9BQVo7QUFDRDs7QUFFRG5FLFVBQVFnTSxXQUFrQjlMLE1BQVAsNkJBQWtCLENBQUUsQ0FBcEIsQ0FBbkIsRUFBeUNpUCxVQUFpQjNNLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQW5ELEVBQW9FLENBQUU7O0FBckJqRDs7QUF5QmhCLE1BQU14RCxLQUFOLFNBQW9CeVAsU0FBcEIsQ0FBOEI7QUFFbkNFLGNBQVlvQixPQUFaLEVBQXFCO0FBRW5CLFFBQUk1TCxVQUFVMEwsT0FBT2hCLE9BQVAsQ0FBZTtBQUMzQjNJLFdBQUs2SjtBQURzQixLQUFmLENBQWQ7QUFJQSxVQUFNNUwsT0FBTjtBQUVBLFFBQUlHLE9BQU8sS0FBS3dLLE9BQUwsRUFBWDs7QUFFQSxZQUFReEssS0FBS3lLLElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSWxRLEtBQUosQ0FBVXdGLEtBQUsxRSxJQUFmLENBQWI7O0FBQ0EsYUFBS3FQLE1BQUwsR0FBcUJoUixHQUFQLDZCQUFlO0FBQzNCLGNBQUlrQyxNQUFPLGlCQUFnQm1FLEtBQUs4SyxLQUFNLFlBQVduUixJQUFJK1IsR0FBSSxTQUFRL1IsSUFBSTBFLEVBQUcsR0FBeEU7QUFDQSwrQkFBYSxLQUFLcU0sS0FBTCxDQUFXbFAsS0FBWCxDQUFpQkssR0FBakIsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFDRjtBQUNFLGNBQU0sSUFBSTBJLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBVEo7QUFZRDtBQUdEOzs7Ozs7QUFJQTdJLFVBQVFnTSxXQUFrQjlMLE1BQVAsNkJBQWtCLENBQUUsQ0FBcEIsQ0FBbkIsRUFBeUNpUCxVQUFpQjNNLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQW5ELEVBQW9FO0FBRWxFLFFBQUkwRyxNQUFNMkcsT0FBT2xMLElBQVAsQ0FBWTtBQUNwQm9MLGVBQVMsS0FBSzVMLE9BQUwsQ0FBYStCO0FBREYsS0FBWixFQUVQO0FBQ0RzRyxjQUFRO0FBQ050RyxhQUFLLENBREM7QUFFTnZELFlBQUksQ0FGRTtBQUdOcU4sYUFBSztBQUhDO0FBRFAsS0FGTyxDQUFWO0FBVUEsV0FBTyxJQUFJQyxPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBRW5CakgsVUFBSWhCLE9BQUosQ0FDRSxDQUFPakssR0FBUCxFQUFZbVMsS0FBWiw4QkFBc0I7QUFDcEIsWUFBSTtBQUNGLGNBQUlsUSx1QkFBZSxLQUFLK08sTUFBTCxDQUFZaFIsR0FBWixDQUFmLENBQUo7QUFDQSx3QkFBTStOLFNBQVM5TCxNQUFULENBQU47QUFDRCxTQUhELENBR0UsT0FBT3NDLENBQVAsRUFBVTtBQUNWMk0sa0JBQVEzTSxDQUFSO0FBQ0Q7O0FBQ0QsWUFBSTROLFFBQVEsQ0FBUixLQUFjbEgsSUFBSXdHLEtBQUosRUFBbEIsRUFBK0I7QUFDN0JRO0FBQ0Q7QUFDRixPQVZELENBREY7QUFhRCxLQWhCSSxFQWlCTEcsS0FqQkssQ0FrQko3TixDQUFELElBQU87QUFDTCxZQUFNQSxDQUFOO0FBQ0QsS0FwQkksQ0FBUDtBQXVCRDs7QUFsRWtDLEM7Ozs7Ozs7Ozs7O0FDckNyQ3JHLE9BQU8rUixNQUFQLENBQWM7QUFBQ29DLFFBQUssTUFBSUE7QUFBVixDQUFkO0FBQStCLElBQUlsQyxLQUFKO0FBQVVqUyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUMrUixRQUFNN1IsQ0FBTixFQUFRO0FBQUM2UixZQUFNN1IsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUVsQyxNQUFNK1QsT0FBTyxJQUFJbEMsTUFBTUMsVUFBVixDQUFxQixNQUFyQixFQUE2QjtBQUFDQyxnQkFBYztBQUFmLENBQTdCLENBQWIsQzs7Ozs7Ozs7Ozs7QUNGUG5TLE9BQU8rUixNQUFQLENBQWM7QUFBQ3hSLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUkwUixLQUFKO0FBQVVqUyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUMrUixRQUFNN1IsQ0FBTixFQUFRO0FBQUM2UixZQUFNN1IsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUV4QyxNQUFNRyxVQUFVLElBQUkwUixNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQStCO0FBQUNDLGdCQUFhO0FBQWQsQ0FBL0IsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNGUG5TLE9BQU8rUixNQUFQLENBQWM7QUFBQzFJLFlBQVMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUkxRyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFOztBQUUxQyxNQUFNaUosUUFBTixDQUFlO0FBQ3BCOzs7O0FBSUFtSixjQUFhSyxLQUFiLEVBQW9CO0FBQ2xCLFNBQUt1QixNQUFMLEdBQWN2QixLQUFkO0FBQ0Q7O0FBRUs3SSxhQUFOLENBQW1CcUssY0FBbkIsRUFBbUN4SyxXQUFXLENBQTlDO0FBQUEsb0NBQWlEO0FBQy9DLG9CQUFNLEtBQUt1SyxNQUFMLENBQVlFLFdBQVosQ0FDSixtQkFESSxFQUVILHNCQUFxQkQsY0FBZSxFQUZqQyxFQUdKLEVBSEksRUFHQTtBQUNGNUYsZUFBTzVFLFFBREw7QUFFRjBLLHlCQUFpQixDQUZmO0FBR0ZyTyxxQkFBYTtBQUhYLE9BSEEsQ0FBTjtBQVVBLG9CQUFNLEtBQUtrTyxNQUFMLENBQVlFLFdBQVosQ0FDSixtQkFESSxFQUVILHNCQUFxQkQsY0FBZSxFQUZqQyxFQUdKLEVBSEksRUFHQTtBQUNGNUYsZUFBTzVFLFFBREw7QUFFRjNELHFCQUFhO0FBRlgsT0FIQSxDQUFOO0FBUUQsS0FuQkQ7QUFBQTs7QUFxQk0rRSxrQkFBTixDQUF3QnpKLElBQXhCO0FBQUEsb0NBQThCO0FBQzVCLFVBQUlnVCxZQUFZaFQsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVixDQUg0QixDQUs1Qjs7QUFDQSxVQUFJNlEsU0FBZ0J6UixHQUFQLDZCQUFlO0FBQzFCLFlBQUlnQixNQUFPOzsyQkFFVXhDLEtBQUtvSixVQUFXLGNBQWE1SCxHQUFJO09BRnREO0FBSUFZLFlBQUkwUCxJQUFKLGVBQWUsS0FBS2MsTUFBTCxDQUFZelEsS0FBWixDQUFrQkssR0FBbEIsQ0FBZjtBQUNELE9BTlksQ0FBYixDQU40QixDQWM1Qjs7O0FBQ0EsVUFBSTBRLFFBQWUxUixHQUFQLDZCQUFlO0FBQ3pCO0FBQ0EsWUFBSWdCLE1BQU87OzJCQUVVeEMsS0FBS29KLFVBQVcsY0FBYTVILEdBQUk7T0FGdEQ7QUFJQSxZQUFJMlIseUJBQWlCLEtBQUtQLE1BQUwsQ0FBWXpRLEtBQVosQ0FBa0JLLEdBQWxCLENBQWpCLENBQUo7QUFDQSxZQUFJMlEsU0FBUyxDQUFULEVBQVksVUFBWixDQUFKLEVBQTZCO0FBRTdCL1EsWUFBSTBQLElBQUosZUFDUSxLQUFLYyxNQUFMLENBQVloTyxXQUFaLENBQ0osaUJBREksRUFFSixFQUZJLEVBR0o7QUFDRXdFLHNCQUFZcEosS0FBS29KLFVBRG5CO0FBRUU1SCxlQUFLQSxHQUZQO0FBR0V1SCxzQkFBWWlLLFNBSGQ7QUFJRXZPLHVCQUFhO0FBSmYsU0FISSxDQURSO0FBV0QsT0FwQlcsQ0FBWjs7QUFzQkEsV0FBSyxJQUFJMk8sTUFBVCxJQUFtQnBULEtBQUtxVCxJQUF4QixFQUE4QjtBQUM1QixnQkFBUUQsT0FBT0UsR0FBZjtBQUNFLGVBQUssSUFBTDtBQUNFLDBCQUFNSixNQUFNRSxPQUFPNVIsR0FBYixDQUFOO0FBQ0E7O0FBQ0YsZUFBSyxLQUFMO0FBQ0UsMEJBQU15UixPQUFPRyxPQUFPNVIsR0FBZCxDQUFOO0FBQ0E7QUFOSjtBQVFEOztBQUVELGFBQU87QUFDTFksYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0FuREQ7QUFBQTs7QUFxRE1tSCxvQkFBTixDQUEwQnZKLElBQTFCO0FBQUEsb0NBQWdDO0FBQzlCLFVBQUl1VCxZQUFZdlQsS0FBS29KLFVBQXJCO0FBQ0EsVUFBSXFHLFNBQVN6UCxLQUFLeVAsTUFBbEI7QUFDQSxVQUFJdUQsWUFBWWhULEtBQUsrSSxVQUFyQjtBQUVBLFVBQUkzRyxNQUFNLEVBQVYsQ0FMOEIsQ0FPOUI7O0FBQ0EsVUFBSUksTUFBTyxvREFBbUQrUSxTQUFVLEVBQXhFO0FBQ0FuUixVQUFJMFAsSUFBSixlQUFlLEtBQUtjLE1BQUwsQ0FBWXpRLEtBQVosQ0FBa0JLLEdBQWxCLENBQWYsR0FUOEIsQ0FVOUI7O0FBQ0EsV0FBSyxJQUFJZ1IsSUFBSSxDQUFiLEVBQWdCQSxJQUFJL0QsT0FBT2dFLE1BQTNCLEVBQW1DRCxHQUFuQyxFQUF3QztBQUN0QyxzQkFBTSxLQUFLWixNQUFMLENBQVloTyxXQUFaLENBQ0osbUJBREksRUFDaUI7QUFDbkJ3RSxzQkFBWW1LLFNBRE87QUFFbkJ4SyxzQkFBWWlLLFNBRk87QUFHbkJVLHFCQUFXakUsT0FBTytELENBQVAsQ0FIUTtBQUluQkcsZ0JBQU1ILElBQUk7QUFKUyxTQURqQixFQU1EO0FBQ0QvTyx1QkFBYTtBQURaLFNBTkMsQ0FBTjtBQVVEOztBQUVELGFBQU87QUFDTHJDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBM0JEO0FBQUE7O0FBNkJNb0gsZUFBTixDQUFxQnhKLElBQXJCO0FBQUEsb0NBQTJCO0FBQ3pCLFVBQUk0VCxhQUFhLEVBQWpCO0FBQ0EsVUFBSUMsT0FBTyxFQUFYLENBRnlCLENBSXpCOztBQUVBQSxhQUFPLENBQ0wsUUFESyxFQUVMLE1BRkssRUFHTCxNQUhLLEVBSUwsa0JBSkssRUFLTCxvQkFMSyxFQU1MLGFBTkssRUFPTCxXQVBLLENBQVA7O0FBU0EsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSTdULEtBQUs4VCxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQjlULEtBQUs4VCxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQsb0JBQU0sS0FBS2xCLE1BQUwsQ0FBWUUsV0FBWixDQUNKLGFBREksRUFFSCxnQkFBZTlTLEtBQUtvSixVQUFXLEVBRjVCLEVBR0p3SyxVQUhJLEVBR1E7QUFDVmxQLHFCQUFhO0FBREgsT0FIUixDQUFOLEVBbkJ5QixDQTJCekI7O0FBRUFrUCxtQkFBYSxFQUFiO0FBQ0FDLGFBQU8sQ0FDTCxrQkFESyxFQUVMLGNBRkssRUFHTCxZQUhLLEVBSUwsU0FKSyxFQUtMLFNBTEssRUFNTCxjQU5LLENBQVA7O0FBUUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSTdULEtBQUs4VCxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQjlULEtBQUs4VCxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQsVUFBSTFSLG9CQUFZLEtBQUt3USxNQUFMLENBQVlFLFdBQVosQ0FDZCxtQkFEYyxFQUViLGdCQUFlOVMsS0FBS29KLFVBQVcsRUFGbEIsRUFHZHdLLFVBSGMsRUFHRjtBQUNWbFAscUJBQWE7QUFESCxPQUhFLENBQVosQ0FBSjtBQVFBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBckREO0FBQUE7O0FBdURNNkcsZUFBTixDQUFxQmpKLElBQXJCO0FBQUEsb0NBQTJCO0FBQ3pCLFVBQUlnVCxZQUFZaFQsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVjtBQUVBLFVBQUl3UixhQUFhLEVBQWpCO0FBQ0EsVUFBSUMsT0FBTyxFQUFYO0FBRUFBLGFBQU8sQ0FDTCxNQURLLEVBRUwsb0JBRkssQ0FBUCxDQVJ5QixDQVl6QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1QsS0FBSzhULENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVQsS0FBSzhULENBQUwsQ0FBaEI7QUFDZDs7QUFFRDFSLFVBQUlnSCxVQUFKLGlCQUF1QixLQUFLd0osTUFBTCxDQUFZaE8sV0FBWixDQUNyQixhQURxQixFQUVyQmdQLFVBRnFCLEVBRVQ7QUFDVjdLLG9CQUFZaUssU0FERjtBQUVWdFEsZ0JBQVEsQ0FGRTtBQUdWOEIsY0FBTSxNQUhJO0FBSVZ1UCwwQkFBa0IsTUFKUjtBQUtWQyxxQkFBYSxNQUxIO0FBTVZDLG1CQUFXLE1BTkQ7QUFPVnhQLHFCQUFhLE9BUEg7QUFRVkMscUJBQWE7QUFSSCxPQUZTLENBQXZCO0FBY0FrUCxtQkFBYSxFQUFiO0FBQ0FDLGFBQU8sQ0FDTCxjQURLLEVBRUwsaUJBRkssRUFHTCxTQUhLLEVBSUwsU0FKSyxFQUtMLGNBTEssQ0FBUCxDQXBDeUIsQ0EyQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSTdULEtBQUs4VCxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQjlULEtBQUs4VCxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQxUixVQUFJdUcsZ0JBQUosaUJBQTZCLEtBQUtpSyxNQUFMLENBQVloTyxXQUFaLENBQzNCLG1CQUQyQixFQUUzQmdQLFVBRjJCLEVBRWY7QUFDVjdLLG9CQUFZaUssU0FERjtBQUVWNUosb0JBQVloSCxJQUFJZ0gsVUFGTjtBQUdWNkQsZUFBTyxDQUhHO0FBSVY4Rix5QkFBaUIsQ0FKUDtBQUtWbUIsNEJBQW9CLE1BTFY7QUFNVkMsNEJBQW9CLE1BTlY7QUFPVkMsMEJBQWtCLE1BUFI7QUFRVkMsb0JBQVksTUFSRjtBQVNWNVAscUJBQWEsT0FUSDtBQVVWQyxxQkFBYTtBQVZILE9BRmUsQ0FBN0I7O0FBZ0JBLFdBQUssSUFBSW9QLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1QsS0FBSzhULENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVQsS0FBSzhULENBQUwsQ0FBaEI7QUFDZDs7QUFFRDFSLFVBQUlpSCxnQkFBSixpQkFBNkIsS0FBS3VKLE1BQUwsQ0FBWWhPLFdBQVosQ0FDM0IsbUJBRDJCLEVBQ04sRUFETSxFQUNGO0FBQ3ZCK0QsMEJBQWtCdkcsSUFBSXVHLGdCQURDO0FBRXZCSSxvQkFBWWlLLFNBRlc7QUFHdkIvRixlQUFPLENBSGdCO0FBSXZCeEkscUJBQWEsT0FKVTtBQUt2QkMscUJBQWE7QUFMVSxPQURFLENBQTdCLEVBekV5QixDQW1GekI7O0FBQ0EsYUFBTztBQUNMdEMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0F2RkQ7QUFBQTs7QUF2S29CLEM7Ozs7Ozs7Ozs7O0FDRnRCNUQsT0FBTytSLE1BQVAsQ0FBYztBQUFDK0QsbUJBQWdCLE1BQUlBLGVBQXJCO0FBQXFDQyxZQUFTLE1BQUlBLFFBQWxEO0FBQTJEQyxpQkFBYyxNQUFJQSxhQUE3RTtBQUEyRjVNLGlCQUFjLE1BQUlBLGFBQTdHO0FBQTJIK0Ysc0JBQW1CLE1BQUlBO0FBQWxKLENBQWQ7QUFBcUwsSUFBSXhNLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJNlYsV0FBSjtBQUFnQmpXLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQytWLGNBQVk3VixDQUFaLEVBQWM7QUFBQzZWLGtCQUFZN1YsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJd00sT0FBSjtBQUFZNU0sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlCQUFSLENBQWIsRUFBd0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3TSxjQUFReE0sQ0FBUjtBQUFVOztBQUF0QixDQUF4QyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJZ1MsSUFBSjtBQUFTcFMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE1BQVIsQ0FBYixFQUE2QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2dTLFdBQUtoUyxDQUFMO0FBQU87O0FBQW5CLENBQTdCLEVBQWtELENBQWxEO0FBQXFELElBQUlpUyxPQUFKO0FBQVlyUyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDaVMsY0FBUWpTLENBQVI7QUFBVTs7QUFBdEIsQ0FBcEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSThWLE1BQUo7QUFBV2xXLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ2dXLFNBQU85VixDQUFQLEVBQVM7QUFBQzhWLGFBQU85VixDQUFQO0FBQVM7O0FBQXBCLENBQS9CLEVBQXFELENBQXJEOztBQVM3aUIsTUFBTTBWLGVBQU4sQ0FBc0I7QUFDM0J0RCxjQUFhckssSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsUUFBSW1PLFFBQUo7O0FBQ0EsWUFBUWhPLEtBQUt5SyxJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0V1RCxtQkFBVyxJQUFJSCxhQUFKLENBQWtCN04sSUFBbEIsRUFBd0JILE9BQXhCLENBQVg7QUFGSjs7QUFLQSxXQUFPbU8sUUFBUDtBQUNEOztBQVQwQjs7QUFZdEIsTUFBTUosUUFBTixDQUFlO0FBQ3BCdkQsY0FBYXJLLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFNBQUtHLElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUtILE9BQUwsR0FBZUEsT0FBZjtBQUNEOztBQUVELFNBQU9vTyxPQUFQLENBQWdCak8sSUFBaEIsRUFBc0JILE9BQXRCLEVBQStCO0FBQzdCLFlBQVFHLEtBQUt5SyxJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UsZUFBTyxJQUFJb0QsYUFBSixDQUFrQjdOLElBQWxCLEVBQXdCSCxPQUF4QixDQUFQOztBQUNGO0FBQ0UsY0FBTSxJQUFJMEUsS0FBSixDQUFVLG1CQUFWLENBQU47QUFKSjtBQU1EOztBQUVEMkosYUFBWTtBQUNWLFdBQU8sS0FBS2xPLElBQVo7QUFDRDs7QUFFRG1PLGFBQVk7QUFDVixXQUFPLEtBQUtuTyxJQUFMLENBQVUxRSxJQUFqQjtBQUNEOztBQUVEOFMsZ0JBQWU7QUFDYixXQUFPLEtBQUt2TyxPQUFaO0FBQ0Q7O0FBRUR3TyxxQkFDRUMsS0FBSyxDQUFPMUQsV0FBV2hQLFVBQVUsQ0FBRSxDQUE5QixFQUFnQ2lQLFVBQVUzTSxLQUFLLENBQUUsQ0FBakQsOEJBQXNELENBQUUsQ0FBeEQsQ0FEUCxFQUVFO0FBQ0EsU0FBS3lNLE1BQUwsR0FBYzJELEVBQWQ7QUFDRDtBQUVEOzs7Ozs7Ozs7OztBQVNNNVMsU0FBTixDQUFlNlMsWUFBWSxFQUEzQjtBQUFBLG9DQUErQjtBQUM3QixVQUFJMU8sVUFBVSxLQUFLdU8sV0FBTCxFQUFkLENBRDZCLENBRzdCOztBQUNBdk8sY0FBUXFMLE9BQVIsQ0FBZ0JDLElBQWhCLENBQXFCO0FBQ25CdFIsY0FBTSxNQURhO0FBRW5CMkIsZUFBTztBQUZZLE9BQXJCO0FBS0EsVUFBSWdULFVBQVUsRUFBZDs7QUFDQSxXQUFLLElBQUlDLENBQVQsSUFBYzVPLFFBQVFxTCxPQUF0QixFQUErQixDQUM5Qjs7QUFFRCxVQUFJQSxVQUFVLEVBQWQ7O0FBRUEsV0FBSyxJQUFJdUQsQ0FBVCxJQUFjNU8sUUFBUXFMLE9BQXRCLEVBQStCO0FBQzdCc0QsZ0JBQVFDLEVBQUU1VSxJQUFWLElBQWtCO0FBQ2hCMkIsaUJBQU9pVCxFQUFFalQsS0FETztBQUVoQmtULGlCQUFPLE9BQU9ELEVBQUVDLEtBQVQsS0FBbUIsV0FBbkIsR0FBaUNELEVBQUVDLEtBQW5DLEdBQTJDLENBRmxDO0FBR2hCdEQsaUJBQU87QUFIUyxTQUFsQjtBQUtBRixnQkFBUUMsSUFBUixDQUNFO0FBQ0V0UixnQkFBTTRVLEVBQUU1VSxJQURWO0FBRUV5UixnQkFBTXJCLEtBQUtDLFFBQVFtQixRQUFSLENBQWlCb0QsRUFBRWpULEtBQW5CLENBQUw7QUFGUixTQURGO0FBTUQ7O0FBRUQsb0JBQU0sS0FBS21QLE1BQUwsQ0FDSixDQUFPL08sTUFBUCxFQUFlNkYsT0FBZiw4QkFBMkI7QUFDekIsYUFBSyxJQUFJZ04sQ0FBVCxJQUFjdkQsT0FBZCxFQUF1QjtBQUNyQjtBQUNBLGNBQUl5RCxJQUFJSCxRQUFRQyxFQUFFNVUsSUFBVixDQUFSOztBQUNBLGNBQUk4VSxFQUFFRCxLQUFOLEVBQWE7QUFDWCxnQkFBSUMsRUFBRXZELEtBQUYsSUFBV3VELEVBQUVELEtBQWpCLEVBQXdCO0FBQ3RCO0FBQ0Q7QUFDRjs7QUFFRCxjQUFJRCxFQUFFbkQsSUFBRixDQUFPMVAsTUFBUCxDQUFKLEVBQW9CO0FBQ2xCO0FBQ0ErUyxjQUFFdkQsS0FBRixHQUZrQixDQUlsQjs7QUFDQSxnQkFBSSxPQUFPbUQsVUFBVUUsRUFBRTVVLElBQVosQ0FBUCxLQUE2QixXQUFqQyxFQUE4QztBQUM1Qyw0QkFBTTBVLFVBQVVFLEVBQUU1VSxJQUFaLEVBQWtCK0IsTUFBbEIsRUFBMEI2RixPQUExQixDQUFOO0FBQ0Q7O0FBQ0Q7QUFDRDtBQUNGO0FBQ0YsT0FyQkQsQ0FESSxDQUFOLEVBN0I2QixDQXFEN0I7O0FBQ0EsYUFBTytNLE9BQVA7QUFDRCxLQXZERDtBQUFBOztBQTFDb0I7O0FBb0dmLE1BQU1YLGFBQU4sU0FBNEJELFFBQTVCLENBQXFDO0FBQzFDdkQsY0FBYXJLLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFVBQU1HLElBQU4sRUFBWUgsT0FBWjtBQUVBLFFBQUl2RSxPQUFPLEtBQUs2UyxRQUFMLEVBQVg7QUFFQSxTQUFLekQsS0FBTCxHQUFhLElBQUlsUSxLQUFKLENBQVVjLElBQVYsQ0FBYjtBQUNBLFNBQUsrUyxrQkFBTCxDQUF3QixDQUFPekQsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBQ25ELFVBQUloUCxNQUFPLGlCQUFnQm1FLEtBQUs4SyxLQUFNLEVBQXRDO0FBQ0EsVUFBSXJQLG9CQUFZLEtBQUtpUCxLQUFMLENBQVdLLGNBQVgsQ0FBMEJsUCxHQUExQixFQUErQitPLFFBQS9CLEVBQTBDMU0sQ0FBRCxJQUFPO0FBQUUsY0FBTUEsQ0FBTjtBQUFTLE9BQTNELENBQVosQ0FBSjtBQUNBLGFBQU96QyxHQUFQO0FBQ0QsS0FKdUIsQ0FBeEI7QUFLRDs7QUFaeUM7O0FBbUJyQyxNQUFNd0YsYUFBTixTQUE0QjJNLFFBQTVCLENBQXFDO0FBQzFDdkQsY0FBYXJLLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFVBQU1HLElBQU4sRUFBWUgsT0FBWixFQUQwQixDQUcxQjs7QUFDQSxTQUFLd08sa0JBQUwsQ0FBd0IsQ0FBT3pELFFBQVAsRUFBaUJDLE9BQWpCLDhCQUE2QjtBQUNuRCxVQUFJK0QsTUFBSjtBQUNBQSw2QkFBZWQsWUFBWWUsT0FBWixDQUFvQjdPLEtBQUs0RyxHQUF6QixDQUFmLEVBRm1ELENBSW5EOztBQUNBLFVBQUk5RyxLQUFLOE8sT0FBTzlPLEVBQVAsQ0FBVUUsS0FBSzhPLFFBQWYsQ0FBVDtBQUNBLFVBQUkxTyxhQUFhTixHQUFHTSxVQUFILENBQWNKLEtBQUtJLFVBQW5CLENBQWpCO0FBRUEsVUFBSXFCLFVBQVU7QUFDWm1OLGdCQUFRQSxNQURJO0FBRVp4TyxvQkFBWUEsVUFGQTtBQUdaME8sa0JBQVVoUDtBQUhFLE9BQWQ7QUFNQSxVQUFJOEUsTUFBTXhFLFdBQVdDLElBQVgsRUFBVixDQWRtRCxDQWdCbkQ7O0FBQ0F1RSxVQUFJbUssYUFBSixDQUFrQixpQkFBbEIsRUFBcUMsSUFBckMsRUFqQm1ELENBbUJuRDs7QUFDQSxVQUFJO0FBQ0YsNkJBQWFuSyxJQUFJd0IsT0FBSixFQUFiLEdBQTRCO0FBQzFCLGNBQUl6TSxvQkFBWWlMLElBQUl5QixJQUFKLEVBQVosQ0FBSjtBQUNBLHdCQUFNdUUsU0FBU2pSLEdBQVQsRUFBYzhILE9BQWQsQ0FBTjtBQUNEOztBQUFBO0FBQ0YsT0FMRCxTQUtVO0FBQ1I7QUFDQSxzQkFBTW1ELElBQUkyQixLQUFKLEVBQU47QUFDRDtBQUNGLEtBN0J1QixDQUF4QjtBQThCRDs7QUFuQ3lDOztBQXNDckMsTUFBTVMsa0JBQU4sU0FBaUM0RyxRQUFqQyxDQUEwQztBQUMvQ3ZELGNBQWFySyxJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixVQUFNRyxJQUFOLEVBQVlILE9BQVosRUFEMEIsQ0FHMUI7O0FBQ0EsU0FBS3dPLGtCQUFMLENBQXdCLENBQU96RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQ7QUFDQSxVQUFJbkUsVUFBVXRNLEtBQUtpSyxLQUFMLENBQVdqSyxLQUFLQyxTQUFMLENBQWUyRixJQUFmLENBQVgsQ0FBZDtBQUNBMEcsY0FBUUUsR0FBUixHQUFlLEdBQUVGLFFBQVFFLEdBQUksZUFBN0I7QUFDQSxVQUFJbkYsVUFBVTtBQUNaaUYsaUJBQVNBO0FBREcsT0FBZDs7QUFJQSxhQUFPLENBQVAsRUFBVTtBQUNSO0FBQ0EsWUFBSWpMLG9CQUFZZ0osUUFBUWlDLE9BQVIsQ0FBWixDQUFKO0FBQ0FqTCxjQUFNc1MsT0FBT3RTLEdBQVAsRUFBWTtBQUFDdVQsbUJBQVM7QUFBVixTQUFaLENBQU47QUFFQSxZQUFJQyxXQUFXQyxPQUFPelQsSUFBSW1LLFFBQUosQ0FBYXVKLFlBQWIsQ0FBMEJGLFFBQTFCLENBQW1DRyxLQUExQyxDQUFmO0FBQ0EsWUFBSUMsY0FBY0gsT0FBT3pULElBQUltSyxRQUFKLENBQWF1SixZQUFiLENBQTBCRSxXQUExQixDQUFzQ0QsS0FBN0MsQ0FBbEI7QUFDQSxZQUFJRSxhQUFhSixPQUFPelQsSUFBSW1LLFFBQUosQ0FBYXVKLFlBQWIsQ0FBMEJHLFVBQTFCLENBQXFDRixLQUE1QyxDQUFqQjtBQUNBLFlBQUlHLGVBQWU5VCxJQUFJbUssUUFBSixDQUFhdUosWUFBYixDQUEwQkksWUFBN0MsQ0FSUSxDQVVSOztBQUNBLFlBQUlBLHdCQUF3QkMsS0FBNUIsRUFBbUM7QUFDakM7QUFDQSxlQUFLLElBQUkzQyxJQUFJLENBQWIsRUFBZ0JBLElBQUl3QyxXQUFwQixFQUFpQ3hDLEdBQWpDLEVBQXNDO0FBQ3BDLDBCQUFNakMsU0FBUzJFLGFBQWExQyxDQUFiLENBQVQsRUFBMEJwTCxPQUExQixDQUFOO0FBQ0Q7QUFDRixTQUxELE1BS087QUFDTDtBQUNBLHdCQUFNbUosU0FBUzJFLFlBQVQsRUFBdUI5TixPQUF2QixDQUFOO0FBQ0Q7O0FBRUQsWUFBSTRFLE9BQU9pSixhQUFhRCxXQUF4QjtBQUVBLFlBQUloSixPQUFPNEksUUFBWCxFQUFxQjtBQUNyQnZJLGdCQUFRRyxFQUFSLENBQVd5SSxVQUFYLEdBQXdCakosSUFBeEI7QUFDRDtBQUNGLEtBbEN1QixDQUF4QjtBQW1DRDs7QUF4QzhDLEM7Ozs7Ozs7Ozs7O0FDbExqRHhPLE9BQU8rUixNQUFQLENBQWM7QUFBQzVSLFdBQVEsTUFBSXdJO0FBQWIsQ0FBZDtBQUE0QyxJQUFJVCxlQUFKO0FBQW9CbEksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDZ0ksa0JBQWdCOUgsQ0FBaEIsRUFBa0I7QUFBQzhILHNCQUFnQjlILENBQWhCO0FBQWtCOztBQUF0QyxDQUF0QyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJRyxPQUFKO0FBQVlQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNLLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTlDLEVBQXNFLENBQXRFO0FBQXlFLElBQUl3WCxRQUFKO0FBQWE1WCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUMwWCxXQUFTeFgsQ0FBVCxFQUFXO0FBQUN3WCxlQUFTeFgsQ0FBVDtBQUFXOztBQUF4QixDQUE3QixFQUF1RCxDQUF2RDtBQUEwRCxJQUFJeVgsUUFBSjtBQUFhN1gsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lYLGVBQVN6WCxDQUFUO0FBQVc7O0FBQXZCLENBQXJDLEVBQThELENBQTlEOztBQVczUyxNQUFNdUksY0FBTixDQUFxQjtBQUM1QkssTUFBTixDQUFZYixJQUFaO0FBQUEsb0NBQWtCO0FBQ2hCLFdBQUs2RSxLQUFMLGlCQUFtQjlFLGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCLE9BQTFCLENBQW5CO0FBQ0EsV0FBSzJQLFFBQUwsaUJBQXNCNVAsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEIsVUFBMUIsQ0FBdEI7QUFDRCxLQUhEO0FBQUE7O0FBS00yQixVQUFOLENBQWdCaU8sTUFBaEI7QUFBQSxvQ0FBd0I7QUFDdEIsVUFBSXBPLHFCQUFhLEtBQUtxRCxLQUFMLENBQVcwRixPQUFYLENBQW1CO0FBQ2xDM0ksYUFBS2dPO0FBRDZCLE9BQW5CLEVBRWQ7QUFDRDNQLG9CQUFZO0FBQ1YscUJBQVc7QUFERDtBQURYLE9BRmMsQ0FBYixDQUFKO0FBT0EsVUFBSTRQLGFBQWFyTyxLQUFLc08sT0FBdEIsQ0FSc0IsQ0FVdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxVQUFJQyxhQUFhLEVBQWpCOztBQUVBLFdBQUssSUFBSUMsVUFBVCxJQUF1QkgsVUFBdkIsRUFBbUM7QUFDakMsWUFBSUksY0FBYyxDQUFsQjs7QUFFQSxhQUFLLElBQUk1UixFQUFULElBQWUyUixXQUFXRSxHQUExQixFQUErQjtBQUM3QixjQUFJSix3QkFBZ0IsS0FBS0gsUUFBTCxDQUFjcEYsT0FBZCxDQUFzQjtBQUN4QzNJLGlCQUFLdkQ7QUFEbUMsV0FBdEIsRUFFakI7QUFDRDRCLHdCQUFZO0FBQ1YsdUJBQVM7QUFEQztBQURYLFdBRmlCLENBQWhCLENBQUo7QUFPQSxjQUFJa1EsYUFBYUwsUUFBUXhKLEtBQXpCLENBUjZCLENBVTdCOztBQUNBLGVBQUssSUFBSUEsS0FBVCxJQUFrQjZKLFVBQWxCLEVBQThCO0FBQzVCRiwyQkFBZTNKLE1BQU01RSxRQUFyQjtBQUNEO0FBQ0YsU0FqQmdDLENBbUJqQzs7O0FBQ0FxTyxtQkFBVzVFLElBQVgsQ0FBZ0JpRixLQUFLQyxLQUFMLENBQVdKLGNBQWNELFdBQVdyRCxHQUFwQyxDQUFoQjtBQUNELE9BdkNxQixDQXlDdEI7OztBQUNBLFVBQUlqTCxXQUFXME8sS0FBS0UsR0FBTCxDQUFTQyxLQUFULENBQWUsSUFBZixFQUFxQlIsVUFBckIsQ0FBZjtBQUVBLGFBQU9yTyxRQUFQO0FBQ0QsS0E3Q0Q7QUFBQTtBQStDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQk1YLFVBQU4sQ0FBZ0I3SCxRQUFoQixFQUEwQnVILEtBQTFCLEVBQWlDQyxTQUFTLElBQTFDLEVBQWdEQyxTQUFTLElBQXpEO0FBQUEsb0NBQStEO0FBQzdEO0FBQ0EsVUFBSW1JLFNBQVMxUSxRQUFRaUksSUFBUixDQUFhO0FBQ3hCbkgsa0JBQVVBO0FBRGMsT0FBYixFQUVWc1gsS0FGVSxHQUVGckksR0FGRSxDQUVHbFEsQ0FBRCxJQUFPQSxFQUFFNkIsZ0JBRlgsQ0FBYixDQUY2RCxDQU03RDs7QUFDQSxVQUFJbUIsU0FBUyxFQUFiO0FBQ0FBLGFBQU93RixLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQVl6RixPQUFPd1YsWUFBUCxHQUFzQi9QLE1BQXRCO0FBQ1osVUFBSUMsTUFBSixFQUFZMUYsT0FBT3lWLFlBQVAsR0FBc0IvUCxNQUF0QjtBQUVaLFVBQUlsRixvQkFBWSxLQUFLb0osS0FBTCxDQUFXOEwsVUFBWCxDQUNkMVYsTUFEYyxFQUNOO0FBQ05rTCxlQUFPO0FBQ0wyQyxrQkFBUTtBQUNOOEgsbUJBQU85SDtBQUREO0FBREg7QUFERCxPQURNLENBQVosQ0FBSixDQVo2RCxDQXNCN0Q7O0FBQ0EsYUFBT0EsTUFBUDtBQUNELEtBeEJEO0FBQUE7QUEwQkE7Ozs7Ozs7Ozs7QUFRTTlILFlBQU4sQ0FBa0JQLEtBQWxCLEVBQXlCQyxTQUFTLElBQWxDLEVBQXdDQyxTQUFTLElBQWpEO0FBQUEsb0NBQXVEO0FBQ3JEO0FBQ0EsVUFBSTFGLFNBQVMsRUFBYjtBQUNBQSxhQUFPd0YsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFZekYsT0FBT3dWLFlBQVAsR0FBc0IvUCxNQUF0QjtBQUNaLFVBQUlDLE1BQUosRUFBWTFGLE9BQU95VixZQUFQLEdBQXNCL1AsTUFBdEI7QUFFWixVQUFJbEYsb0JBQVksS0FBS29KLEtBQUwsQ0FBVzhMLFVBQVgsQ0FDZDFWLE1BRGMsRUFDTjtBQUNOdUgsY0FBTTtBQUNKc0csa0JBQVE7QUFESjtBQURBLE9BRE0sQ0FBWixDQUFKO0FBT0QsS0FkRDtBQUFBO0FBZ0JBOzs7Ozs7Ozs7Ozs7Ozs7O0FBY00rSCxjQUFOLENBQW9CclAsSUFBcEIsRUFBMEJzUCxPQUExQjtBQUFBLG9DQUFtQztBQUNqQzs7Ozs7Ozs7QUFRQSxVQUFJbkUsTUFBTSxDQUFDO0FBQ1RvRSxlQUFPLE1BREU7QUFFVEMsaUJBQVN4UCxLQUFLeVAsUUFGTDtBQUdUSCxpQkFBUztBQUNQSSxpQkFBTztBQURBLFNBSEE7QUFNVDFWLGVBQU87QUFDTGlWLHdCQUFjalAsS0FBS2lQLFlBRGQ7QUFFTEMsd0JBQWNsUCxLQUFLa1A7QUFGZDtBQU5FLE9BQUQsRUFXVjtBQUNFSyxlQUFPdlAsS0FBSzJQLFdBRGQ7QUFFRUgsaUJBQVN4UCxLQUFLaVAsWUFGaEI7QUFHRUssaUJBQVM7QUFDUEksaUJBQU87QUFEQSxTQUhYO0FBTUUxVixlQUFPO0FBQ0x5VixvQkFBVXpQLEtBQUt5UCxRQURWO0FBRUxQLHdCQUFjbFAsS0FBS2tQO0FBRmQ7QUFOVCxPQVhVLEVBc0JWO0FBQ0VLLGVBQU92UCxLQUFLNFAsV0FEZDtBQUVFSixpQkFBU3hQLEtBQUtrUCxZQUZoQjtBQUdFSSxpQkFBUztBQUNQSSxpQkFBTztBQURBLFNBSFg7QUFNRTFWLGVBQU87QUFDTHlWLG9CQUFVelAsS0FBS3lQLFFBRFY7QUFFTFIsd0JBQWNqUCxLQUFLaVA7QUFGZDtBQU5ULE9BdEJVLENBQVY7QUFtQ0EsVUFBSVksUUFBUSxFQUFaOztBQUVBLFdBQUssSUFBSUMsQ0FBVCxJQUFjM0UsR0FBZCxFQUFtQjtBQUNqQjBFLGNBQU1sRyxJQUFOLENBQVc7QUFDVGpGLG9DQUFrQixLQUFLckIsS0FBTCxDQUFXdEUsU0FBWCxDQUNoQixDQUFDO0FBQ0N1RSxvQkFBUVMsT0FBT0MsTUFBUCxDQUFjOEwsRUFBRTlWLEtBQWhCLEVBQXVCO0FBQzdCaUYscUJBQU9lLEtBQUtmO0FBRGlCLGFBQXZCO0FBRFQsV0FBRCxFQUtBO0FBQ0V5RSxzQkFBVUssT0FBT0MsTUFBUCxDQUFjOEwsRUFBRVIsT0FBaEIsRUFBeUJBLE9BQXpCO0FBRFosV0FMQSxFQVFBO0FBQ0VTLG1CQUFPO0FBQ0wzUCxtQkFBSztBQURBO0FBRFQsV0FSQSxDQURnQixFQWVoQnRCLE9BZmdCLEVBQWxCLENBRFM7QUFpQlRrUixpQkFBT0Y7QUFqQkUsU0FBWDtBQW1CRDs7QUFFRCxXQUFLLElBQUlHLElBQVQsSUFBaUJKLEtBQWpCLEVBQXdCO0FBQ3RCLGFBQUssSUFBSXBaLENBQVQsSUFBY3daLEtBQUt2TCxVQUFuQixFQUErQjtBQUM3QmpPLFlBQUVxTyxLQUFGLGlCQUFnQixLQUFLM0UsUUFBTCxDQUFjMUosRUFBRTJKLEdBQWhCLENBQWhCO0FBQ0Q7QUFDRjs7QUFFRCxhQUFPeVAsS0FBUDtBQUNELEtBM0VEO0FBQUEsR0ExSWtDLENBdU5sQztBQUNBOzs7QUFDTTFKLGVBQU4sQ0FBcUJnQixHQUFyQjtBQUFBLG9DQUEwQjtBQUN4QixVQUFJbkgsSUFBSixDQUR3QixDQUV4Qjs7QUFDQSxVQUFJLE9BQU9tSCxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0IsWUFBSStJLE1BQU0sSUFBSUMsTUFBSixDQUFZLEdBQUVoSixHQUFJLEdBQWxCLENBQVY7QUFDQSxZQUFJL0QsTUFBTSxLQUFLQyxLQUFMLENBQVd4RSxJQUFYLENBQWdCLEVBQWhCLEVBQW9CO0FBQzVCSixzQkFBWTtBQUNWUSxtQkFBTyxDQURHO0FBRVZnUSwwQkFBYyxDQUZKO0FBR1ZDLDBCQUFjO0FBSEo7QUFEZ0IsU0FBcEIsQ0FBVjs7QUFRQSxlQUFPLENBQVAsRUFBVTtBQUNSLGNBQUk7QUFDRmxQLGlDQUFhb0QsSUFBSXlCLElBQUosRUFBYjtBQUNBLGdCQUFJdUwsc0JBQWNwUSxLQUFLSSxHQUFMLENBQVNpUSxXQUFULEdBQXVCRCxLQUF2QixDQUE2QkYsR0FBN0IsQ0FBZCxDQUFKOztBQUNBLGdCQUFJRSxLQUFKLEVBQVc7QUFDVDtBQUNEO0FBQ0YsV0FORCxDQU1FLE9BQU8xVCxDQUFQLEVBQVU7QUFDVjtBQUNBMEcsZ0JBQUkyQixLQUFKO0FBQ0EsbUJBQU9vQyxHQUFQO0FBQ0Q7QUFDRjs7QUFDRC9ELFlBQUkyQixLQUFKO0FBQ0QsT0F4QkQsTUF3Qk87QUFDTC9FLGVBQU9tSCxHQUFQO0FBQ0Q7O0FBRUQsVUFBSW1KLGFBQWEsRUFBakI7QUFDQSxVQUFJdFEsS0FBS2YsS0FBVCxFQUFnQnFSLFdBQVczRyxJQUFYLENBQWdCM0osS0FBS2YsS0FBckI7QUFDaEIsVUFBSWUsS0FBS2lQLFlBQVQsRUFBdUJxQixXQUFXM0csSUFBWCxDQUFnQjNKLEtBQUtpUCxZQUFyQjtBQUN2QixVQUFJalAsS0FBS2tQLFlBQVQsRUFBdUJvQixXQUFXM0csSUFBWCxDQUFnQjNKLEtBQUtrUCxZQUFyQjtBQUN2QixhQUFPb0IsV0FBVzFKLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBUDtBQUNELEtBcENEO0FBQUE7O0FBc0NNakcsa0JBQU4sQ0FBd0JrSyxTQUF4QixFQUFtQzdLLElBQW5DO0FBQUEsb0NBQXlDO0FBQ3ZDO0FBQ0EsVUFBSXVRLFlBQWFkLFFBQUQsSUFBY0EsYUFBYSxRQUFiLEdBQXdCLE9BQXhCLEdBQWtDQSxRQUFoRSxDQUZ1QyxDQUl2Qzs7O0FBQ0EsVUFBSXJFLFlBQVksSUFBaEI7QUFDQSxVQUFJa0YsYUFBYSxFQUFqQixDQU51QyxDQVF2QztBQUNBOztBQUNBLFVBQUl0USxLQUFLZixLQUFULEVBQWdCcVIsV0FBVzNHLElBQVgsQ0FBZ0IzSixLQUFLZixLQUFyQjtBQUNoQixVQUFJZSxLQUFLaVAsWUFBVCxFQUF1QnFCLFdBQVczRyxJQUFYLENBQWdCM0osS0FBS2lQLFlBQXJCO0FBQ3ZCLFVBQUlqUCxLQUFLa1AsWUFBVCxFQUF1Qm9CLFdBQVczRyxJQUFYLENBQWdCM0osS0FBS2tQLFlBQXJCLEVBWmdCLENBY3ZDOztBQUNBLFVBQUlzQixhQUFKOztBQUNBLGNBQVF4USxLQUFLeVAsUUFBYjtBQUNFLGFBQUssS0FBTDtBQUNFZSwwQkFBZ0IsQ0FBaEI7QUFDQTs7QUFDRixhQUFLLFFBQUw7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7O0FBQ0Y7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7QUFUSixPQWhCdUMsQ0E0QnZDOzs7QUFDQSxVQUFJdEYsT0FBTyxFQUFYOztBQUNBLGNBQVFsTCxLQUFLeVAsUUFBYjtBQUNFLGFBQUssS0FBTDtBQUNFdkUsZUFBS3ZCLElBQUwsQ0FBVTtBQUNSdFEsaUJBQUssQ0FERztBQUVSOFIsaUJBQUs7QUFGRyxXQUFWLEVBR0c7QUFDRDlSLGlCQUFLLENBREo7QUFFRDhSLGlCQUFLO0FBRkosV0FISDtBQU9BOztBQUNGLGFBQUssUUFBTDtBQUNFRCxlQUFLdkIsSUFBTCxDQUFVO0FBQ1J0USxpQkFBSyxDQURHO0FBRVI4UixpQkFBSztBQUZHLFdBQVYsRUFHRztBQUNEOVIsaUJBQUssQ0FESjtBQUVEOFIsaUJBQUs7QUFGSixXQUhIO0FBT0E7QUFsQkosT0E5QnVDLENBbUR2Qzs7O0FBQ0EsVUFBSXNGLGNBQWMsSUFBbEI7O0FBQ0EsY0FBUXpRLEtBQUt5UCxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VnQix3QkFBYyxJQUFkO0FBQ0E7O0FBQ0YsYUFBSyxRQUFMO0FBQ0VBLHdCQUFjLEdBQWQ7QUFDQTtBQU5KLE9BckR1QyxDQThEdkM7QUFDQTtBQUNBOzs7QUFFQSxVQUFJWixzQkFBYyxLQUFLUixZQUFMLENBQWtCclAsSUFBbEIsRUFBd0I7QUFDeENpQixvQkFBWTtBQUQ0QixPQUF4QixDQUFkLENBQUosQ0FsRXVDLENBc0V2QztBQUVBOztBQUNBNE8sY0FBUUEsTUFBTWxKLEdBQU4sQ0FDTHNKLElBQUQsSUFBVTtBQUNSQSxhQUFLRCxLQUFMLENBQVdSLE9BQVgsR0FBcUJlLFVBQVVOLEtBQUtELEtBQUwsQ0FBV1IsT0FBckIsQ0FBckI7QUFDQVMsYUFBS3ZMLFVBQUwsR0FBa0J1TCxLQUFLdkwsVUFBTCxDQUFnQmlDLEdBQWhCLENBQ2YrSixTQUFELElBQWU7QUFDYkEsb0JBQVVoQixLQUFWLEdBQWtCYSxVQUFVRyxVQUFVaEIsS0FBcEIsQ0FBbEI7QUFDQSxpQkFBT2dCLFNBQVA7QUFDRCxTQUplLENBQWxCO0FBTUEsZUFBT1QsSUFBUDtBQUNELE9BVkssQ0FBUixDQXpFdUMsQ0FzRnZDOztBQUNBLFVBQUlVLGdCQUNGZCxNQUFNbEosR0FBTixDQUNHc0osSUFBRCxJQUNFLGtDQUNELG1CQURDLEdBRUQsaUVBRkMsR0FHRCxXQUFVQSxLQUFLRCxLQUFMLENBQVdULEtBQU0sV0FIMUIsR0FJRCxRQUpDLEdBS0ZVLEtBQUt2TCxVQUFMLENBQWdCaUMsR0FBaEIsQ0FDRytKLFNBQUQsSUFBZTtBQUNiLFlBQUlULEtBQUtELEtBQUwsQ0FBV1IsT0FBWCxLQUF1QmtCLFVBQVVoQixLQUFyQyxFQUE0QztBQUMxQztBQUNBLGlCQUFRLHdFQUF1RWdCLFVBQVVoQixLQUFNLG9CQUEvRjtBQUNELFNBSEQsTUFJQSxJQUFJZ0IsVUFBVTVMLEtBQVYsR0FBa0IsQ0FBdEIsRUFBeUI7QUFDdkI7QUFDQSxpQkFBUSw2QkFBNEI0TCxVQUFVelAsVUFBVyxrRUFBaUV5UCxVQUFVaEIsS0FBTSxlQUExSTtBQUNELFNBSEQsTUFHTztBQUNMO0FBQ0EsaUJBQVEsNEhBQTJIZ0IsVUFBVWhCLEtBQU0sV0FBbko7QUFDRDtBQUNGLE9BYkgsRUFjRTlJLElBZEYsQ0FjTyxFQWRQLENBTEUsR0FvQkYsUUFwQkUsR0FxQkYsUUF2QkYsRUF3QkVBLElBeEJGLENBd0JPLEVBeEJQLENBREY7QUEyQkEsVUFBSWdLLG9CQUFxQjs7TUFFdkJELGFBQWM7S0FGaEIsQ0FsSHVDLENBdUh2Qzs7QUFDQSxVQUFJOVksT0FBTztBQUNUb0osb0JBQVltSyxTQURIO0FBRVR4SyxvQkFBWWlLLFNBRkg7QUFHVHhTLGNBQU8sR0FBRWlZLFdBQVcxSixJQUFYLENBQWdCLEdBQWhCLENBQXFCLElBQUcySixVQUFVdlEsS0FBS3lQLFFBQWYsQ0FBeUIsSUFBR3pQLEtBQUszSCxJQUFLLEdBQUUySCxLQUFLNlEsUUFBTCxHQUFnQixNQUFNN1EsS0FBSzZRLFFBQTNCLEdBQXNDLEVBQUcsRUFIekc7QUFJVEMsNEJBQW9CRixpQkFKWDtBQUtUO0FBQ0FHLHNCQUFjVCxXQUFXMUosSUFBWCxDQUFnQixHQUFoQixDQU5MO0FBT1RvSyxpQkFBU2hSLEtBQUtpUixZQVBMO0FBUVQ7QUFDQTtBQUNBQyx5QkFBaUJWLGFBVlI7QUFXVHRGLGNBQU1BLElBWEc7QUFZVGlHLHNCQUFjVjtBQVpMLE9BQVg7QUFlQTFNLGFBQU9DLE1BQVAsQ0FBY25NLElBQWQsZ0JBQTBCLEtBQUt1Wiw4QkFBTCxDQUFvQ3BSLElBQXBDLENBQTFCO0FBQ0ErRCxhQUFPQyxNQUFQLENBQWNuTSxJQUFkLGdCQUEwQixLQUFLd1osNkJBQUwsQ0FBbUNyUixJQUFuQyxDQUExQjtBQUNBK0QsYUFBT0MsTUFBUCxDQUFjbk0sSUFBZCxnQkFBMEIsS0FBS3laLDRCQUFMLENBQWtDdFIsSUFBbEMsQ0FBMUI7QUFFQStELGFBQU9DLE1BQVAsQ0FBY25NLElBQWQsRUFBb0JtSSxLQUFLTSxJQUFMLENBQVVDLFdBQTlCO0FBRUEsYUFBTzFJLElBQVA7QUFDRCxLQTlJRDtBQUFBOztBQWdKTXVaLGdDQUFOLENBQXNDcFIsSUFBdEM7QUFBQSxvQ0FBNEM7QUFDMUMsVUFBSXVSLFdBQVcsRUFBZixDQUQwQyxDQUUxQzs7QUFDQUEsa0JBQVl2UixLQUFLd1IsV0FBakIsQ0FIMEMsQ0FJMUM7O0FBQ0EsV0FBSyxJQUFJbkcsSUFBSSxDQUFiLEVBQWdCQSxJQUFJckwsS0FBS3NILE1BQUwsQ0FBWWdFLE1BQWhDLEVBQXdDRCxHQUF4QyxFQUE2QztBQUMzQ2tHLG9CQUFhLGdDQUErQnZSLEtBQUtzSCxNQUFMLENBQVkrRCxDQUFaLENBQWUsUUFBM0Q7QUFDRCxPQVB5QyxDQVExQzs7O0FBQ0FrRyxrQkFBWSxHQUFaO0FBQ0EsYUFBTztBQUFDekYsbUJBQVd5RjtBQUFaLE9BQVA7QUFDRCxLQVhEO0FBQUE7O0FBYU1GLCtCQUFOLENBQXFDclIsSUFBckM7QUFBQSxvQ0FBMkM7QUFDekM7QUFDQSxhQUFPO0FBQUN5UixpQkFBU3pSLEtBQUtNLElBQUwsQ0FBVUMsV0FBVixDQUFzQm1SO0FBQWhDLE9BQVA7QUFDRCxLQUhEO0FBQUE7O0FBS01KLDhCQUFOLENBQW9DdFIsSUFBcEM7QUFBQSxvQ0FBMEM7QUFDeEM7QUFDQSxVQUFJMlIsTUFBTSxPQUFPM1IsS0FBS3NILE1BQUwsQ0FBWSxDQUFaLENBQVAsS0FBMEIsV0FBMUIsR0FBd0MsRUFBeEMsR0FBNkMsQ0FBRXRILEtBQUtzSCxNQUFMLENBQVksQ0FBWixDQUFGLENBQXZEO0FBQ0EsYUFBTztBQUFFQSxnQkFBUXFLO0FBQVYsT0FBUDtBQUNELEtBSkQ7QUFBQSxHQWpha0MsQ0F1YWxDOzs7QUFDTXpKLGtCQUFOLENBQXdCMEosR0FBeEIsRUFBNkI1UixJQUE3QjtBQUFBLG9DQUFtQztBQUNqQyxZQUFNNlIsV0FBVyxFQUFqQjtBQUNBLFlBQU1DLGNBQWMsR0FBcEI7QUFFQSxVQUFJMUssUUFBUSxFQUFaLENBSmlDLENBS2pDOztBQUNBQSxjQUFReE8sS0FBS2lLLEtBQUwsQ0FBV2pLLEtBQUtDLFNBQUwsQ0FBZStZLElBQUk1UixLQUFLeVAsUUFBVCxDQUFmLENBQVgsQ0FBUixDQU5pQyxDQVFqQzs7QUFDQSxZQUFNc0MsWUFBWSxJQUFsQjs7QUFDQSxXQUFLLElBQUkxRyxJQUFJLENBQWIsRUFBZ0JBLElBQUlyTCxLQUFLc0gsTUFBTCxDQUFZZ0UsTUFBaEMsRUFBd0NELEdBQXhDLEVBQTZDO0FBQzNDakUsY0FBTTJLLGFBQWExRyxJQUFJLENBQWpCLENBQU4sSUFBNkJyTCxLQUFLc0gsTUFBTCxDQUFZK0QsQ0FBWixDQUE3QjtBQUNELE9BWmdDLENBY2pDOzs7QUFDQWpFLFlBQU0sTUFBTixJQUFnQnBILEtBQUtNLElBQUwsQ0FBVThHLEtBQVYsQ0FBZ0I0SyxRQUFoQztBQUNBNUssWUFBTSxNQUFOLElBQWdCOEcsU0FBUytELE9BQVQsQ0FBa0IsR0FBRCxjQUFTLEtBQUs5TCxhQUFMLENBQW1CbkcsSUFBbkIsQ0FBVCxDQUFrQyxJQUFHQSxLQUFLeVAsUUFBUyxJQUFHelAsS0FBSzNILElBQUssRUFBakYsRUFBb0Z5WixXQUFwRixDQUFoQjtBQUNBMUssWUFBTSxNQUFOLElBQWdCcEgsS0FBS2tTLFdBQXJCO0FBQ0E5SyxZQUFNLE1BQU4sSUFBZ0JwSCxLQUFLa1MsV0FBckI7QUFDQTlLLFlBQU0sTUFBTixJQUFnQnBILEtBQUtJLEdBQUwsQ0FBU2lRLFdBQVQsR0FBdUJ0SixLQUF2QixDQUE2QixDQUFDOEssUUFBOUIsQ0FBaEI7QUFDQXpLLFlBQU0sSUFBTixJQUFjcEgsS0FBS3dSLFdBQW5CO0FBQ0FwSyxZQUFNLGdCQUFOLElBQTBCcEgsS0FBSzZRLFFBQS9CO0FBRUEsYUFBT3pKLEtBQVA7QUFDRCxLQXhCRDtBQUFBOztBQTBCTW5ELHNDQUFOLENBQTRDTixRQUE1QztBQUFBLG9DQUFzRDtBQUNwRCxVQUFJOUcsS0FBSyxxQkFBVDtBQUNBLFVBQUlzTyxNQUFNLFVBQVY7QUFDQSxVQUFJZ0gsVUFBVTtBQUNaLGtCQUFVLENBQUMsTUFBRCxDQURFO0FBRVosZUFBTyxDQUFDLFNBQUQsRUFBWSxVQUFaLENBRkssQ0FJZDs7QUFKYyxPQUFkO0FBTUEsVUFBSUMscUJBQWEsS0FBSy9PLEtBQUwsQ0FBV3RFLFNBQVgsQ0FDZixDQUNFO0FBQ0V1RSxnQkFBUTtBQUNOLFdBQUN6RyxFQUFELEdBQU04RztBQURBO0FBRFYsT0FERixFQU1FO0FBQ0VGLGdCQUFRO0FBQ05yRCxlQUFNLElBQUd2RCxFQUFHLEVBRE47QUFFTixXQUFDc08sR0FBRCxHQUFPO0FBQUVrSCx1QkFBWSxJQUFHbEgsR0FBSTtBQUFyQjtBQUZEO0FBRFYsT0FORixFQVlFO0FBQ0V6SCxrQkFBVTtBQUNSdEQsZUFBSyxDQURHO0FBRVJ1RCxvQkFBVSxNQUZGO0FBR1IsV0FBQ3dILEdBQUQsR0FBUSxJQUFHQSxHQUFJO0FBSFA7QUFEWixPQVpGLENBRGUsRUFxQmZyTSxPQXJCZSxFQUFiLENBQUo7QUF1QkEsVUFBSXdULGNBQWMsRUFBbEI7O0FBQ0EsV0FBSyxJQUFJQyxHQUFULElBQWdCSCxLQUFLLENBQUwsRUFBUTNDLFFBQXhCLEVBQWtDO0FBQ2hDNkMsc0JBQWNBLFlBQVlFLE1BQVosQ0FBbUJMLFFBQVMsR0FBRUksR0FBSSxFQUFmLENBQW5CLENBQWQ7QUFDRDs7QUFDRCxVQUFJRSxpQkFBaUIsSUFBSXpFLEtBQUosQ0FBVSxDQUFWLENBQXJCOztBQUNBLFdBQUssSUFBSTNDLElBQUksQ0FBYixFQUFnQkEsSUFBSW9ILGVBQWVuSCxNQUFuQyxFQUEyQ0QsR0FBM0MsRUFBZ0Q7QUFDOUMsWUFBSXhPLEtBQUssT0FBT3lWLFlBQVlqSCxDQUFaLENBQVAsS0FBMEIsV0FBMUIsR0FBd0MsTUFBeEMsR0FBaURpSCxZQUFZakgsQ0FBWixDQUExRDtBQUNBb0gsdUJBQWVwSCxDQUFmLElBQW9CO0FBQUNxSCw2QkFBbUJySCxJQUFJLENBQXhCO0FBQTJCc0gsNEJBQWtCOVY7QUFBN0MsU0FBcEI7QUFDRDs7QUFFRCxhQUFPO0FBQUM0Vix3QkFBZ0JBO0FBQWpCLE9BQVA7QUFDRCxLQTNDRDtBQUFBOztBQWxja0MsQzs7Ozs7Ozs7Ozs7QUNYcENwYyxPQUFPK1IsTUFBUCxDQUFjO0FBQUM1UixXQUFRLE1BQUkwTTtBQUFiLENBQWQ7QUFBc0MsSUFBSUQsT0FBSjtBQUFZNU0sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlCQUFSLENBQWIsRUFBd0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3TSxjQUFReE0sQ0FBUjtBQUFVOztBQUF0QixDQUF4QyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJbWMsUUFBSjtBQUFhdmMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDcWMsV0FBU25jLENBQVQsRUFBVztBQUFDbWMsZUFBU25jLENBQVQ7QUFBVzs7QUFBeEIsQ0FBL0IsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSTBNLFNBQUo7QUFBYzlNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMwTSxnQkFBVTFNLENBQVY7QUFBWTs7QUFBeEIsQ0FBdEMsRUFBZ0UsQ0FBaEU7QUFJNU0sTUFBTW9jLFdBQVcsd0NBQWpCOztBQUVlLE1BQU0zUCxRQUFOLENBQWU7QUFDNUIyRixjQUFhckssSUFBYixFQUFtQnFGLE1BQW5CLEVBQTJCO0FBQ3pCLFNBQUtyRixJQUFMLEdBQVlBLElBQVo7QUFDQSxTQUFLcUYsTUFBTCxHQUFjQSxNQUFkO0FBQ0QsR0FKMkIsQ0FNNUI7OztBQUNNSyxZQUFOLENBQWtCQSxVQUFsQjtBQUFBLG9DQUE4QjtBQUM1QixVQUFJakIsVUFBVyxvQkFBbUIsS0FBS1ksTUFBTyx3QkFBdUIrTyxTQUFTMU8sVUFBVCxFQUFxQjtBQUFDc0osaUJBQVM7QUFBVixPQUFyQixDQUFzQyx5QkFBM0c7O0FBQ0EsVUFBSTtBQUNGLFlBQUl2VCxvQkFBWSxLQUFLNlksV0FBTCxDQUNkLGdCQURjLEVBRWQ3UCxPQUZjLENBQVosQ0FBSjtBQUlBLGVBQU87QUFBQ21CLG9CQUFVbkssR0FBWDtBQUFnQjhZLHNCQUFZOVA7QUFBNUIsU0FBUDtBQUNELE9BTkQsQ0FNRSxPQUFPdkcsQ0FBUCxFQUFVO0FBQ1YsY0FBTXFILE9BQU9DLE1BQVAsQ0FBY2IsVUFBVU4sS0FBVixDQUFnQm5HLENBQWhCLENBQWQsRUFBa0M7QUFBQ3FXLHNCQUFZOVA7QUFBYixTQUFsQyxDQUFOO0FBQ0Q7QUFDRixLQVhEO0FBQUE7O0FBYU02UCxhQUFOLENBQW1CRSxNQUFuQixFQUEyQi9hLElBQTNCO0FBQUEsb0NBQWlDO0FBQy9CO0FBQ0EsVUFBSWdiLGFBQWE7QUFDZkQsZ0JBQVEsTUFETztBQUVmNU4sYUFBTSxHQUFFeU4sUUFBUyxJQUFHRyxNQUFPLEVBRlo7QUFHZi9hLGNBQU1BLElBSFMsQ0FLakI7O0FBTGlCLE9BQWpCO0FBTUE4TCxhQUFPQyxNQUFQLENBQWNpUCxVQUFkLEVBQTBCLEtBQUt6VSxJQUEvQixFQVIrQixDQVUvQjs7QUFDQSxVQUFJdkUsb0JBQVlnSixRQUFRZ1EsVUFBUixDQUFaLENBQUo7QUFFQSxhQUFPaFosR0FBUDtBQUNELEtBZEQ7QUFBQTs7QUFnQk1vRyxhQUFOLENBQW1CNlMsZUFBbkI7QUFBQSxvQ0FBb0M7QUFDbEM7QUFDQSxVQUFJRCxhQUFhO0FBQ2ZELGdCQUFRLE1BRE87QUFFZjVOLGFBQU0sR0FBRXlOLFFBQVMsY0FGRixDQUlqQjs7QUFKaUIsT0FBakI7QUFLQTlPLGFBQU9DLE1BQVAsQ0FBY2lQLFVBQWQsRUFBMEIsS0FBS3pVLElBQS9CO0FBRUF5VSxpQkFBV2hiLElBQVgsaUJBQXdCLEtBQUtrYiw0QkFBTCxDQUFrQ0QsZUFBbEMsQ0FBeEIsRUFUa0MsQ0FXbEM7O0FBQ0EsVUFBSWpaLG9CQUFZZ0osUUFBUWdRLFVBQVIsQ0FBWixDQUFKO0FBRUEsYUFBT2haLEdBQVA7QUFDRCxLQWZEO0FBQUE7O0FBaUJNa1osOEJBQU4sQ0FBb0NELGVBQXBDO0FBQUEsb0NBQXFEO0FBQ25EO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQSxVQUFJRSxxQkFBcUIsRUFBekI7O0FBRUEsV0FBSyxJQUFJcFQsSUFBVCxJQUFpQmtULGVBQWpCLEVBQWtDO0FBQ2hDO0FBQ0EsYUFBSyxJQUFJeFcsQ0FBVCxJQUFjc0QsS0FBSzBFLFVBQW5CLEVBQStCO0FBQzdCO0FBQ0EsY0FBSWhJLEVBQUVvSSxLQUFGLEdBQVUsR0FBZCxFQUFtQnBJLEVBQUVvSSxLQUFGLEdBQVUsR0FBVjtBQUNwQjs7QUFFRHNPLDhCQUFzQixtQkFBdEI7QUFDQUEsOEJBQXVCLGFBQVlwVCxLQUFLMkQsUUFBUyxhQUFqRCxDQVJnQyxDQVVoQztBQUNBO0FBQ0E7O0FBRUEsWUFBSTBQLE9BQU9yVCxLQUFLMEUsVUFBTCxDQUFnQixDQUFoQixDQUFYOztBQUNBLFlBQUkyTyxLQUFLOU8sMEJBQUwsS0FBb0MsRUFBcEMsSUFBMEM4TyxLQUFLN08sd0JBQUwsS0FBa0MsRUFBaEYsRUFBb0Y7QUFDbEY7QUFDQTRPLGdDQUFzQixnQ0FBdEI7QUFDQUEsZ0NBQXVCLGVBQWNDLEtBQUt2TyxLQUFNLGVBQWhEO0FBQ0QsU0FKRCxNQUlPO0FBQ0w7QUFDQXNPLGdDQUFzQixnQ0FBdEIsQ0FGSyxDQUlMOztBQUNBLGVBQUssSUFBSTFDLFNBQVQsSUFBc0IxUSxLQUFLMEUsVUFBM0IsRUFBdUM7QUFDckM7QUFDQWdNLHNCQUFVNEMsaUJBQVYsR0FBOEI1QyxVQUFVNUwsS0FBeEM7QUFDQSxtQkFBTzRMLFVBQVU1TCxLQUFqQixDQUhxQyxDQUtyQzs7QUFDQXNPLGtDQUFzQixpQkFBdEI7O0FBQ0EsaUJBQUssSUFBSWxKLEdBQVQsSUFBZ0JuRyxPQUFPMkgsSUFBUCxDQUFZZ0YsU0FBWixDQUFoQixFQUF3QztBQUN0QzBDLG9DQUF1QixJQUFHbEosR0FBSSxJQUFHd0csVUFBVXhHLEdBQVYsQ0FBZSxLQUFJQSxHQUFJLEdBQXhEO0FBQ0Q7O0FBQ0RrSixrQ0FBc0Isa0JBQXRCO0FBQ0Q7QUFDRjs7QUFFREEsOEJBQXNCLG9CQUF0QjtBQUNELE9BekRrRCxDQTJEbkQ7OztBQUNBLFVBQUlHLGlCQUFrQjs7Y0FFWixLQUFLMVAsTUFBTztNQUNwQnVQLGtCQUFtQjs7S0FIckIsQ0E1RG1ELENBbUVuRDs7QUFDQSxhQUFPRyxjQUFQO0FBQ0QsS0FyRUQ7QUFBQTs7QUFyRDRCLEM7Ozs7Ozs7Ozs7O0FDTjlCbGQsT0FBTytSLE1BQVAsQ0FBYztBQUFDNVIsV0FBUSxNQUFJMk07QUFBYixDQUFkOztBQUFlLE1BQU1BLFNBQU4sQ0FBZ0I7QUFDN0IsU0FBT04sS0FBUCxDQUFjbkcsQ0FBZCxFQUFpQjtBQUNmLFFBQUl6QyxNQUFNLEVBQVY7O0FBRUEsUUFBSXlDLGFBQWFxRyxLQUFqQixFQUF3QjtBQUN0QjlJLFVBQUl1WixPQUFKLEdBQWM5VyxFQUFFOFcsT0FBaEI7QUFDQXZaLFVBQUk1QixJQUFKLEdBQVdxRSxFQUFFckUsSUFBYjtBQUNBNEIsVUFBSXdaLFFBQUosR0FBZS9XLEVBQUUrVyxRQUFqQjtBQUNBeFosVUFBSXlaLFVBQUosR0FBaUJoWCxFQUFFZ1gsVUFBbkI7QUFDQXpaLFVBQUkwWixZQUFKLEdBQW1CalgsRUFBRWlYLFlBQXJCO0FBQ0ExWixVQUFJMlosS0FBSixHQUFZbFgsRUFBRWtYLEtBQWQ7QUFDRCxLQVBELE1BT087QUFDTDNaLFlBQU15QyxDQUFOO0FBQ0Q7O0FBRUQsV0FBT3pDLEdBQVA7QUFDRDs7QUFoQjRCLEM7Ozs7Ozs7Ozs7O0FDQS9CNUQsT0FBTytSLE1BQVAsQ0FBYztBQUFDN0osbUJBQWdCLE1BQUlBO0FBQXJCLENBQWQ7QUFBcUQsSUFBSStOLFdBQUo7QUFBZ0JqVyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUMrVixjQUFZN1YsQ0FBWixFQUFjO0FBQUM2VixrQkFBWTdWLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7O0FBRTlELE1BQU04SCxlQUFOLENBQXNCO0FBQzNCLFNBQWFJLEdBQWIsQ0FBa0JILElBQWxCLEVBQXdCSSxVQUF4QjtBQUFBLG9DQUFvQztBQUNsQyxVQUFJd08sdUJBQWVkLFlBQVllLE9BQVosQ0FBb0I3TyxLQUFLNEcsR0FBekIsQ0FBZixDQUFKO0FBQ0EsVUFBSTlHLEtBQUs4TyxPQUFPOU8sRUFBUCxDQUFVRSxLQUFLOE8sUUFBZixDQUFUO0FBQ0EsYUFBT2hQLEdBQUdNLFVBQUgsQ0FBY0EsVUFBZCxDQUFQO0FBQ0QsS0FKRDtBQUFBOztBQUQyQixDOzs7Ozs7Ozs7OztBQ0Y3QnZJLE9BQU8rUixNQUFQLENBQWM7QUFBQzVSLFdBQVEsTUFBSXdDO0FBQWIsQ0FBZDtBQUFtQyxJQUFJa1EsS0FBSjtBQUFVN1MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lTLFlBQU16UyxDQUFOO0FBQVE7O0FBQXBCLENBQTlCLEVBQW9ELENBQXBEO0FBQXVELElBQUlvZCxNQUFKO0FBQVd4ZCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDb2QsYUFBT3BkLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7O0FBR2hHLE1BQU11QyxLQUFOLENBQVk7QUFDekI2UCxjQUFheEssT0FBYixFQUFzQjtBQUNwQjtBQUNBLFNBQUt5VixJQUFMLEdBQVk1SyxNQUFNNkssVUFBTixDQUFpQjFWLE9BQWpCLENBQVosQ0FGb0IsQ0FJcEI7O0FBQ0EsUUFBSTJWLGVBQWU7QUFBQ0MsMEJBQW9CO0FBQXJCLEtBQW5CO0FBQ0FsUSxXQUFPQyxNQUFQLENBQWNnUSxZQUFkLEVBQTRCM1YsT0FBNUI7QUFDQSxTQUFLNlYsU0FBTCxHQUFpQmhMLE1BQU02SyxVQUFOLENBQWlCQyxZQUFqQixDQUFqQjtBQUNEOztBQUVELFNBQU9HLFVBQVAsQ0FBbUJDLElBQW5CLEVBQXlCO0FBQ3ZCLFdBQU9QLE9BQU9PLElBQVAsRUFBYUMsTUFBYixHQUFzQm5YLFNBQXRCLENBQWdDLENBQWhDLEVBQW1DLEVBQW5DLEVBQXVDb1gsT0FBdkMsQ0FBK0MsR0FBL0MsRUFBb0QsR0FBcEQsQ0FBUDtBQUNEO0FBRUQ7Ozs7OztBQUlBdGEsUUFBT0ssR0FBUCxFQUFZO0FBQ1Y7QUFDQTtBQUNBLFdBQU8sS0FBS2thLE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUl0SyxPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ25CO0FBQ0FvSyxZQUFJemEsS0FBSixDQUFVSyxHQUFWLEVBQWUsQ0FBQ3FDLENBQUQsRUFBSXpDLEdBQUosS0FBWTtBQUN6QjtBQUNBd2EsY0FBSUMsT0FBSjs7QUFDQSxjQUFJaFksQ0FBSixFQUFPO0FBQ0wyTixtQkFBTzNOLENBQVA7QUFDRCxXQUZELE1BRU8wTixRQUFRblEsR0FBUjtBQUNSLFNBTkQ7QUFPRCxPQVZJLENBQVA7QUFZRCxLQWZFLEVBaUJKc1EsS0FqQkksQ0FpQkc3TixDQUFELElBQU87QUFDWixZQUFNQSxDQUFOO0FBQ0QsS0FuQkksQ0FBUDtBQW9CRDs7QUFFS2lZLGNBQU4sQ0FBb0J0YSxHQUFwQjtBQUFBLG9DQUF5QjtBQUN2QixVQUFJSixvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT0osSUFBSTJhLFFBQVg7QUFDRCxLQUhEO0FBQUE7QUFLQTs7Ozs7Ozs7QUFNTW5ZLGFBQU4sQ0FBbUI2TSxLQUFuQixFQUEwQnpSLE9BQU8sRUFBakMsRUFBcUNnZCxVQUFVLEVBQS9DO0FBQUEsb0NBQW1EO0FBQ2pEO0FBQ0E7QUFFQSxVQUFJeGEsTUFBTyxlQUFjaVAsS0FBTSxHQUEvQjtBQUVBLFVBQUkzQyxNQUFNLElBQUltTyxHQUFKLEVBQVY7O0FBQ0EsV0FBSyxJQUFJbkosQ0FBVCxJQUFjNUgsT0FBTzJILElBQVAsQ0FBWTdULElBQVosQ0FBZCxFQUFpQztBQUMvQixZQUFJQSxLQUFLOFQsQ0FBTCxNQUFZLElBQWhCLEVBQXNCO0FBQ3BCaEYsY0FBSXdFLEdBQUosQ0FBUVEsQ0FBUixFQUFXLE1BQVg7QUFDRCxTQUZELE1BRU8sSUFBSTlULEtBQUs4VCxDQUFMLEVBQVE5QyxXQUFSLENBQW9CeFEsSUFBcEIsS0FBNkIsTUFBakMsRUFBeUM7QUFDOUM7QUFDQXNPLGNBQUl3RSxHQUFKLENBQVFRLENBQVIsRUFBWSxJQUFHM1MsTUFBTW1iLFVBQU4sQ0FBaUJ0YyxLQUFLOFQsQ0FBTCxDQUFqQixDQUEwQixHQUF6QztBQUNELFNBSE0sTUFHQTtBQUNMaEYsY0FBSXdFLEdBQUosQ0FBUVEsQ0FBUixFQUFZLEdBQUV6QyxNQUFNNkwsTUFBTixDQUFhbGQsS0FBSzhULENBQUwsQ0FBYixDQUFzQixFQUFwQztBQUNEO0FBQ0Y7O0FBQ0QsV0FBSyxJQUFJQSxDQUFULElBQWM1SCxPQUFPMkgsSUFBUCxDQUFZbUosT0FBWixDQUFkLEVBQW9DO0FBQ2xDbE8sWUFBSXdFLEdBQUosQ0FBUVEsQ0FBUixFQUFXa0osUUFBUWxKLENBQVIsTUFBZSxJQUFmLEdBQXNCLE1BQXRCLEdBQStCa0osUUFBUWxKLENBQVIsQ0FBMUM7QUFDRDs7QUFFRHRSLGFBQVEsS0FBSSxDQUFDLEdBQUdzTSxJQUFJK0UsSUFBSixFQUFKLEVBQWdCOUUsSUFBaEIsQ0FBcUIsR0FBckIsQ0FBMEIsS0FBdEM7QUFFQXZNLGFBQVEsV0FBVSxDQUFDLEdBQUdzTSxJQUFJcU8sTUFBSixFQUFKLEVBQWtCcE8sSUFBbEIsQ0FBdUIsR0FBdkIsQ0FBNEIsS0FBOUM7QUFFQSxVQUFJM00sb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9KLElBQUkyYSxRQUFYO0FBQ0QsS0EzQkQ7QUFBQTtBQTZCQTs7Ozs7Ozs7O0FBT01qSyxhQUFOLENBQW1CckIsS0FBbkIsRUFBMEI3UCxNQUExQixFQUFrQzVCLElBQWxDLEVBQXdDZ2QsT0FBeEM7QUFBQSxvQ0FBaUQ7QUFDL0MsVUFBSXhhLE1BQU8sVUFBU2lQLEtBQU0sT0FBMUI7QUFFQSxVQUFJMkwsVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSXRKLENBQVQsSUFBYzVILE9BQU8ySCxJQUFQLENBQVk3VCxJQUFaLENBQWQsRUFBaUM7QUFDL0JvZCxnQkFBUXRMLElBQVIsQ0FBYyxHQUFFZ0MsQ0FBRSxJQUFHekMsTUFBTTZMLE1BQU4sQ0FBYWxkLEtBQUs4VCxDQUFMLENBQWIsQ0FBc0IsRUFBM0M7QUFDRDs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBYzVILE9BQU8ySCxJQUFQLENBQVltSixPQUFaLENBQWQsRUFBb0M7QUFDbENJLGdCQUFRdEwsSUFBUixDQUFjLEdBQUVnQyxDQUFFLElBQUdrSixRQUFRbEosQ0FBUixDQUFXLEVBQWhDO0FBQ0Q7O0FBQ0R0UixhQUFPNGEsUUFBUXJPLElBQVIsQ0FBYSxHQUFiLENBQVA7QUFFQXZNLGFBQVEsVUFBU1osTUFBTyxHQUF4QjtBQUVBLFVBQUlRLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPSixHQUFQO0FBQ0QsS0FoQkQ7QUFBQSxHQTNGeUIsQ0E2R3pCOzs7QUFDTWliLFlBQU4sQ0FBa0I3YSxHQUFsQjtBQUFBLG9DQUF1QjtBQUNyQixVQUFJOGEsV0FBVyxLQUFLckIsSUFBcEI7QUFDQSxXQUFLQSxJQUFMLEdBQVksS0FBS0ksU0FBakI7O0FBQ0EsVUFBSTtBQUNGLFlBQUlqYSxvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsZUFBT0osR0FBUDtBQUNELE9BSEQsU0FHVTtBQUNSLGFBQUs2WixJQUFMLEdBQVlxQixRQUFaO0FBQ0Q7QUFDRixLQVREO0FBQUE7O0FBV01DLGtCQUFOO0FBQUEsb0NBQTBCO0FBQ3hCLG9CQUFNLEtBQUtwYixLQUFMLENBQVksb0JBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJTXFiLFFBQU47QUFBQSxvQ0FBZ0I7QUFDZCxvQkFBTSxLQUFLcmIsS0FBTCxDQUFZLFNBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJTXNiLFVBQU47QUFBQSxvQ0FBa0I7QUFDaEIsb0JBQU0sS0FBS3RiLEtBQUwsQ0FBWSxXQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSUF1UCxpQkFBZ0JsUCxHQUFoQixFQUFxQitPLFdBQVloUCxNQUFELElBQVksQ0FBRSxDQUE5QyxFQUFnRGlQLFVBQVczTSxDQUFELElBQU8sQ0FBRSxDQUFuRSxFQUFxRTtBQUNuRSxXQUFPLEtBQUs2WCxNQUFMLEdBQ0pDLElBREksQ0FFRkMsR0FBRCxJQUFTO0FBQ1AsYUFBTyxJQUFJdEssT0FBSixDQUNMLENBQU9DLE9BQVAsRUFBZ0JDLE1BQWhCLDhCQUEyQjtBQUN6QjtBQUNBb0ssWUFBSXphLEtBQUosQ0FBVUssR0FBVixFQUNHa2IsRUFESCxDQUNNLFFBRE4sRUFFS25iLE1BQUQsSUFBWTtBQUNWcWEsY0FBSWUsS0FBSjtBQUNBcE0sbUJBQVNoUCxNQUFUO0FBQ0FxYSxjQUFJZ0IsTUFBSjtBQUNELFNBTkwsRUFPR0YsRUFQSCxDQU9NLE9BUE4sRUFPZ0I3WSxDQUFELElBQU87QUFDbEIyTSxrQkFBUTNNLENBQVI7QUFDRCxTQVRILEVBVUc2WSxFQVZILENBVU0sS0FWTixFQVVhLE1BQU07QUFDZmQsY0FBSUMsT0FBSjtBQUNBdEs7QUFDRCxTQWJIO0FBY0QsT0FoQkQsQ0FESyxDQUFQO0FBbUJELEtBdEJFLEVBd0JKRyxLQXhCSSxDQXdCRzdOLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQTFCSSxDQUFQO0FBMkJEOztBQUVENlgsV0FBVTtBQUNSLFdBQU8sSUFBSXBLLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQSxXQUFLeUosSUFBTCxDQUFVNEIsYUFBVixDQUF3QixDQUFDaFosQ0FBRCxFQUFJK1gsR0FBSixLQUFZO0FBQ2xDLFlBQUkvWCxDQUFKLEVBQU87QUFDTDJOLGlCQUFPM04sQ0FBUDtBQUNELFNBRkQsTUFFTztBQUNMME4sa0JBQVFxSyxHQUFSO0FBQ0Q7QUFDRixPQU5EO0FBT0QsS0FWSSxFQVlKbEssS0FaSSxDQWFGN04sQ0FBRCxJQUFPO0FBQ0wsWUFBTUEsQ0FBTjtBQUNELEtBZkUsQ0FBUDtBQWlCRDs7QUFyTHdCLEM7Ozs7Ozs7Ozs7O0FDSDNCckcsT0FBTytSLE1BQVAsQ0FBYztBQUFDNVIsV0FBUSxNQUFJK0s7QUFBYixDQUFkOztBQUFlLE1BQU1BLE1BQU4sQ0FBYTtBQUMxQnNILGNBQWF2QyxVQUFiLEVBQXlCO0FBQ3ZCLFNBQUtBLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EsU0FBS08sYUFBTCxHQUFxQixJQUFyQjtBQUNBLFNBQUtLLFFBQUwsR0FBZ0IsSUFBaEI7QUFDQSxTQUFLUyxXQUFMLEdBQW1CLElBQW5CO0FBQ0EsU0FBS2lDLEtBQUwsR0FBYSxDQUFiO0FBQ0EsU0FBSzlDLFdBQUwsR0FBbUIsQ0FBbkI7QUFDRDs7QUFFS3FCLFFBQU4sQ0FBY2hCLEdBQWQ7QUFBQSxvQ0FBbUI7QUFDakI7QUFDQSxVQUFJLEtBQUt5QyxLQUFMLEdBQWEsS0FBS3RELFVBQWxCLEtBQWlDLENBQXJDLEVBQXdDO0FBQ3RDLFlBQUksS0FBS08sYUFBVCxFQUF3QjtBQUN0Qix3QkFBTSxLQUFLQSxhQUFMLENBQW1CLEtBQUtDLFdBQXhCLENBQU47QUFDRDtBQUNGOztBQUNELFVBQUksS0FBS0ksUUFBVCxFQUFtQjtBQUNqQixzQkFBTSxLQUFLQSxRQUFMLENBQWNDLEdBQWQsQ0FBTjtBQUNEOztBQUNELFdBQUt5QyxLQUFMLEdBVmlCLENBV2pCOztBQUNBLFVBQUksS0FBS0EsS0FBTCxHQUFhLEtBQUt0RCxVQUFsQixLQUFpQyxDQUFyQyxFQUF3QztBQUN0QyxhQUFLdkIsS0FBTDtBQUNBLGFBQUsrQixXQUFMO0FBQ0Q7QUFDRixLQWhCRDtBQUFBOztBQWlCQS9CLFVBQVM7QUFDUCxRQUFJLEtBQUs0QyxXQUFULEVBQXNCO0FBQ3BCLFdBQUtBLFdBQUwsQ0FBaUIsS0FBS2IsV0FBdEI7QUFDRDtBQUNGOztBQS9CeUIsQzs7Ozs7Ozs7Ozs7QUNBNUJ6USxPQUFPK1IsTUFBUCxDQUFjO0FBQUM1UixXQUFRLE1BQUl5QztBQUFiLENBQWQ7QUFBb0MsSUFBSWtLLFNBQUo7QUFBYzlNLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMwTSxnQkFBVTFNLENBQVY7QUFBWTs7QUFBeEIsQ0FBaEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJK1QsSUFBSjtBQUFTblUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ2lVLE9BQUsvVCxDQUFMLEVBQU87QUFBQytULFdBQUsvVCxDQUFMO0FBQU87O0FBQWhCLENBQTNDLEVBQTZELENBQTdEO0FBQWdFLElBQUlDLE1BQUo7QUFBV0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDs7QUFLOVAsTUFBTXdDLE1BQU4sQ0FBYTtBQUMxQjRQLGdCQUFlO0FBQ2IsU0FBS3pPLE1BQUwsR0FBYyxFQUFkO0FBQ0EsU0FBSzJTLFNBQUwsR0FBaUIsRUFBakI7QUFDQSxTQUFLNEksUUFBTCxHQUFnQixJQUFoQjtBQUNELEdBTHlCLENBTzFCOzs7QUFDQUMsZ0JBQWVDLE9BQWYsRUFBd0I7QUFDdEIsU0FBS0YsUUFBTCxHQUFnQixJQUFJRyxRQUFKLENBQWFELE9BQWIsQ0FBaEI7QUFDQSxTQUFLOUksU0FBTCxDQUFlcEQsSUFBZixDQUFvQixLQUFLZ00sUUFBekI7QUFDRDs7QUFFSzViLE9BQU4sQ0FBYTFCLE9BQU8sRUFBcEIsRUFBd0J5VSxLQUFLLCtCQUFZLENBQUUsQ0FBZCxDQUE3QjtBQUFBLG9DQUE2QztBQUMzQyxVQUFJaUosTUFBTTtBQUNSRixpQkFBU25mO0FBREQsT0FBVjtBQUlBLFdBQUtrZixhQUFMLENBQW1CRyxJQUFJRixPQUF2Qjs7QUFFQSxVQUFJO0FBQ0YsWUFBSTViLG9CQUFZNlMsSUFBWixDQUFKO0FBRUEvSSxlQUFPQyxNQUFQLENBQWMrUixHQUFkLEVBQW1CO0FBQ2pCOU0sZ0JBQU0sU0FEVztBQUVqQmxQLGlCQUFPMUIsSUFGVTtBQUdqQjJkLGtCQUFRL2I7QUFIUyxTQUFuQjtBQUtELE9BUkQsQ0FRRSxPQUFPeUMsQ0FBUCxFQUFVO0FBQ1ZxSCxlQUFPQyxNQUFQLENBQWMrUixHQUFkLEVBQW1CO0FBQ2pCOU0sZ0JBQU0sT0FEVztBQUVqQmxQLGlCQUFPMUIsSUFGVTtBQUdqQjJkLGtCQUFRN1MsVUFBVU4sS0FBVixDQUFnQm5HLENBQWhCO0FBSFMsU0FBbkI7QUFLRCxPQWRELFNBY1U7QUFDUjtBQUNBLFlBQUksS0FBS2laLFFBQUwsQ0FBY00sTUFBZCxDQUFxQkMsS0FBekIsRUFBZ0M7QUFDOUJuUyxpQkFBT0MsTUFBUCxDQUFjK1IsR0FBZCxFQUFtQjtBQUNqQkosc0JBQVUsS0FBS0EsUUFBTCxDQUFjTTtBQURQLFdBQW5CO0FBR0QsU0FOTyxDQU9SOzs7QUFDQUYsWUFBSUksU0FBSixHQUFnQixJQUFJblIsSUFBSixFQUFoQixDQVJRLENBU1I7O0FBQ0F3RixhQUFLL1IsTUFBTCxDQUFZc2QsR0FBWixFQVZRLENBWVI7O0FBQ0EsYUFBSzNiLE1BQUwsQ0FBWXVQLElBQVosQ0FBaUJvTSxHQUFqQjtBQUNEO0FBQ0YsS0FwQ0Q7QUFBQSxHQWIwQixDQW1EMUI7QUFDQTs7O0FBQ01qUyxpQkFBTixDQUF1QlYsR0FBdkIsRUFBNEIwSixFQUE1QjtBQUFBLG9DQUFnQztBQUM5QiwyQkFBYTFKLElBQUl3QixPQUFKLEVBQWIsR0FBNEI7QUFDMUIsWUFBSXpNLG9CQUFZaUwsSUFBSXlCLElBQUosRUFBWixDQUFKOztBQUNBLFlBQUk7QUFDRjtBQUNBLGNBQUk1SyxvQkFBWTZTLEdBQUczVSxHQUFILENBQVosQ0FBSjtBQUNBLGVBQUtnSixRQUFMLENBQWNsSCxHQUFkO0FBQ0QsU0FKRCxDQUlFLE9BQU95QyxDQUFQLEVBQVU7QUFDVixlQUFLQyxNQUFMLENBQVlELENBQVo7QUFDRDtBQUNGOztBQUNEMEcsVUFBSTJCLEtBQUo7QUFDRCxLQVpEO0FBQUE7O0FBY0E1RCxXQUFVaVYsU0FBVixFQUFxQjtBQUNuQixTQUFLVCxRQUFMLENBQWNVLE9BQWQsQ0FBc0JELFNBQXRCO0FBQ0Q7O0FBRUR6WixTQUFReVosU0FBUixFQUFtQjtBQUNqQixTQUFLVCxRQUFMLENBQWNuZCxLQUFkLENBQW9CMkssVUFBVU4sS0FBVixDQUFnQnVULFNBQWhCLENBQXBCO0FBQ0Q7O0FBRURFLGlCQUFnQjtBQUNkLFFBQUlDLFdBQVcsS0FBS3hKLFNBQUwsQ0FBZWxPLElBQWYsQ0FBb0JuQyxLQUFLQSxFQUFFNFosWUFBRixFQUF6QixDQUFmO0FBQ0EsUUFBSUUsV0FBVyxLQUFmOztBQUNBLFNBQUssSUFBSVQsR0FBVCxJQUFnQixLQUFLM2IsTUFBckIsRUFBNkI7QUFDM0IsVUFBSTJiLElBQUk5TSxJQUFKLEtBQWEsT0FBakIsRUFBMEI7QUFDeEJ1TixtQkFBVyxJQUFYO0FBQ0E7QUFDRDtBQUNGOztBQUNELFdBQU9ELFlBQVlDLFFBQW5CO0FBQ0Q7O0FBRURwWSxZQUFXO0FBQ1Q7QUFDQSxRQUFJLEtBQUtrWSxZQUFMLEVBQUosRUFBeUI7QUFDdkIsWUFBTSxJQUFJamYsT0FBTzBMLEtBQVgsQ0FBaUIsS0FBSzNJLE1BQXRCLENBQU47QUFDRDs7QUFDRCxXQUFPLEtBQUtBLE1BQVo7QUFDRDs7QUE3RnlCOztBQWdHNUIsTUFBTTBiLFFBQU4sQ0FBZTtBQUNiak4sY0FBYWdOLE9BQWIsRUFBc0I7QUFDcEIsU0FBS0ksTUFBTCxHQUFjO0FBQ1pDLGFBQU8sQ0FESztBQUVaRyxlQUFTLENBRkc7QUFHWjdkLGFBQU8sQ0FISztBQUlacWQsZUFBU0E7QUFKRyxLQUFkO0FBTUEsU0FBS1ksU0FBTCxHQUFpQixJQUFqQjtBQUNEOztBQUVESixVQUFTRCxTQUFULEVBQW9CO0FBQ2xCLFFBQUlBLFNBQUosRUFBZTtBQUNiLFdBQUs5VCxHQUFMLENBQVM4VCxTQUFULEVBQW9CLElBQXBCO0FBQ0Q7O0FBQ0QsU0FBS0gsTUFBTCxDQUFZSSxPQUFaO0FBQ0EsU0FBS0osTUFBTCxDQUFZQyxLQUFaO0FBQ0Q7O0FBRUQxZCxRQUFPNGQsU0FBUCxFQUFrQjtBQUNoQjtBQUNBLFFBQUl4ZCxLQUFLQyxTQUFMLENBQWUsS0FBSzRkLFNBQXBCLE1BQW1DN2QsS0FBS0MsU0FBTCxDQUFldWQsU0FBZixDQUF2QyxFQUFrRTtBQUNoRSxVQUFJQSxhQUFhQSxjQUFjLEVBQTNCLElBQWlDQSxjQUFjLEVBQW5ELEVBQXVEO0FBQ3JELGFBQUs5VCxHQUFMLENBQVM4VCxTQUFULEVBQW9CLEtBQXBCO0FBQ0EsYUFBS0ssU0FBTCxHQUFpQkwsU0FBakI7QUFDRDtBQUNGOztBQUNELFNBQUtILE1BQUwsQ0FBWXpkLEtBQVo7QUFDQSxTQUFLeWQsTUFBTCxDQUFZQyxLQUFaO0FBQ0Q7O0FBRUQ1VCxNQUFLOFQsU0FBTCxFQUFnQk07QUFBVTtBQUExQixJQUFtRTtBQUNqRSxRQUFJWCxNQUFNO0FBQ1JNLGVBQVNLLFNBREQ7QUFFUmIsZUFBUyxLQUFLSSxNQUFMLENBQVlKLE9BRmI7QUFHUnJDLGVBQVM0QyxTQUhEO0FBSVJELGlCQUFXLElBQUluUixJQUFKO0FBSkgsS0FBVjtBQU1Bd0YsU0FBSy9SLE1BQUwsQ0FBWXNkLEdBQVo7QUFDRDs7QUFFRE8saUJBQWdCO0FBQ2QsV0FBTyxLQUFLTCxNQUFMLENBQVl6ZCxLQUFuQjtBQUNEOztBQTNDWSxDOzs7Ozs7Ozs7OztBQ3JHZm5DLE9BQU8rUixNQUFQLENBQWM7QUFBQzVSLFdBQVEsTUFBSTBYO0FBQWIsQ0FBZDs7QUFBZSxNQUFNQSxRQUFOLENBQWU7QUFDNUIsU0FBTytELE9BQVAsQ0FBZ0IwRSxJQUFoQixFQUFzQkMsR0FBdEIsRUFBMkJDLFVBQTNCLEVBQXVDO0FBQ3JDLFFBQUlBLGVBQWVDLFNBQW5CLEVBQThCO0FBQUVELG1CQUFhLEVBQWI7QUFBaUI7O0FBQ2pELFFBQUlFLFlBQVlKLEtBQUtLLEtBQUwsQ0FBVyxFQUFYLENBQWhCO0FBQ0EsUUFBSXBOLFFBQVEsQ0FBWjtBQUNBLFFBQUlxTixNQUFNLEVBQVY7O0FBQ0EsU0FBSyxJQUFJNUwsSUFBSSxDQUFiLEVBQWdCQSxJQUFJMEwsVUFBVXpMLE1BQTlCLEVBQXNDRCxHQUF0QyxFQUEyQztBQUN6QyxVQUFJNkwsSUFBSW5DLE9BQU9nQyxVQUFVMUwsQ0FBVixDQUFQLENBQVI7QUFDQSxVQUFJNkwsRUFBRTVMLE1BQUYsR0FBVyxDQUFmLEVBQWtCMUIsUUFBbEIsS0FDS0EsU0FBUyxDQUFUOztBQUNMLFVBQUlBLFFBQVFnTixHQUFaLEVBQWlCO0FBQ2YsZUFBT0ssTUFBTUosVUFBYjtBQUNEOztBQUNESSxhQUFPTixLQUFLUSxNQUFMLENBQVk5TCxDQUFaLENBQVA7QUFDRDs7QUFDRCxXQUFPc0wsSUFBUDtBQUNEOztBQWhCMkIsQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCAocmVxLCByZXMsIG5leHQpID0+IHtcclxuLy8gICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbi8vICAgcmVzLmVuZChgSGVsbG8gd29ybGQgZnJvbTogJHtNZXRlb3IucmVsZWFzZX1gKTtcclxuLy8gfSk7XHJcblxyXG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xyXG5pbXBvcnQgdW5pcWlkIGZyb20gJ3VuaXFpZCc7XHJcblxyXG4vLyBSZXF1aXJlcyBtdWx0aXBhcnR5IFxyXG5pbXBvcnQgbXVsdGlwYXJ0eSBmcm9tICdjb25uZWN0LW11bHRpcGFydHknO1xyXG5pbXBvcnQge1xyXG4gIFVwbG9hZHNcclxufSBmcm9tICcuLi8uLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcyc7XHJcbmxldCBtdWx0aXBhcnR5TWlkZGxld2FyZSA9IG11bHRpcGFydHkoKTtcclxuXHJcbmNvbnN0IHJvdXRlID0gJy91cGxvYWQvaW1hZ2UnO1xyXG5cclxuLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCBmdWMudXBsb2FkRmlsZSApO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgbXVsdGlwYXJ0eU1pZGRsZXdhcmUpO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgKHJlcSwgcmVzcCkgPT4ge1xyXG4gIC8vIGRvbid0IGZvcmdldCB0byBkZWxldGUgYWxsIHJlcS5maWxlcyB3aGVuIGRvbmVcclxuXHJcbiAgY29uc3QgcmVhZGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy5yZWFkRmlsZSk7XHJcbiAgY29uc3Qgd3JpdGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy53cml0ZUZpbGUpO1xyXG4gIGNvbnN0IHVwbG9hZElkID0gdW5pcWlkKCk7XHJcblxyXG4gIGZvciAobGV0IGZpbGUgb2YgcmVxLmZpbGVzLmZpbGUpIHtcclxuICAgIGNvbnN0IGRhdGEgPSByZWFkZXIoZmlsZS5wYXRoKTtcclxuICAgIC8vIOODleOCoeOCpOODq+WQjeOBrumHjeikh+OCkumBv+OBkeOCi+OBn+OCgeOAgeS4gOaEj+OBruODleOCoeOCpOODq+WQjeOCkuS9nOaIkOOBmeOCi1xyXG4gICAgLy8g5qW95aSp44Gu44OV44Kh44Kk44Or5ZCN5paH5a2X5pWw5Yi26ZmQMjDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBmaWxlbmFtZSA9IGAke3VuaXFpZCgpfS5qcGdgXHJcblxyXG4gICAgLy8gc2V0IHRoZSBjb3JyZWN0IHBhdGggZm9yIHRoZSBmaWxlIG5vdCB0aGUgdGVtcG9yYXJ5IG9uZSBmcm9tIHRoZSBBUEk6XHJcbiAgICBsZXQgc2F2ZVBhdGggPSByZXEuYm9keS5pbWFnZWRpciArICcvJyArIGZpbGVuYW1lO1xyXG5cclxuICAgIC8vIGNvcHkgdGhlIGRhdGEgZnJvbSB0aGUgcmVxLmZpbGVzLmZpbGUucGF0aCBhbmQgcGFzdGUgaXQgdG8gZmlsZS5wYXRoXHJcblxyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ57WQ5p6c44KS6KiY6Yyy44GZ44KLXHJcbiAgICBsZXQgZG9jID0ge1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICAgIGNsaWVudEZpbGVOYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgIHVwbG9hZGVkRmlsZU5hbWU6IGZpbGVuYW1lXHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICB0cnl7XHJcbiAgICAgIHdyaXRlcihzYXZlUGF0aCwgZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaChlcnIpe1xyXG4gICAgICBkb2MuZXJyb3IgPSBlcnI7XHJcbiAgICB9XHJcbiAgICBVcGxvYWRzLmluc2VydChkb2MpO1xyXG5cclxuICAgIGRlbGV0ZSBmaWxlO1xyXG5cclxuICB9O1xyXG4gIHJlc3Aud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgc2F2ZURpcjogcmVxLmJvZHkuaW1hZ2VkaXJcclxuICB9KSk7XHJcblxyXG59KTsiLCJpbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0bydcclxuXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBSZXBvcnQgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBHcm91cCxcclxuICBHcm91cEZhY3RvcnlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzJ1xyXG5pbXBvcnQge1xyXG4gIEZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlbWlnJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5taWdyYXRlYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIC8vIHNldHVwIGdyb3VwXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgRmlsdGVyKGNvbmZpZy5zcmNGaWx0ZXJJZClcclxuICAgIC8vIGxldCBwbHVnID0gZ3JvdXAuZ2V0UGx1ZygpO1xyXG5cclxuICAgIC8vIGNoZWNraW5nIGNvbm5lY3Rpb25cclxuICAgIC8vXHJcblxyXG4gICAgbGV0IHRlc3RRdWVyeSA9ICdTSE9XIERBVEFCQVNFUydcclxuXHJcbiAgICBsZXQgZHN0RGIgPSBuZXcgTXlTUUwoY29uZmlnLmRzdC5jcmVkKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnQ29ubmVjdCB0byBEZXN0aW5hdGlvbicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBhd2FpdCBkc3REYi5xdWVyeSh0ZXN0UXVlcnkpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcHJvY2VzcyBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICAvL1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnU2VsZWN0IGxvb3AgaW4gc291cmNlJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICBtb2JpbGVOdWxsOiBhc3luYyAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIC8vIOWApOOCkuaVtOeQhlxyXG4gICAgICAgICAgICAvLyBmb3IgKGxldCBrZXkgb2YgT2JqZWN0LmtleXMocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyAgIGlmIChyZWNvcmRba2V5XSA9PT0gbnVsbCk7XHJcbiAgICAgICAgICAgIC8vICAgZWxzZSBpZiAocmVjb3JkW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAvLyDml6Xku5jjgpLlpInmj5tcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gTXlTUUwuZm9ybWF0RGF0ZShyZWNvcmRba2V5XSk7XHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IGBcIiR7cmVjb3JkW2tleV19XCJgO1xyXG4gICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyIOOBq+S/neWtmFxyXG5cclxuICAgICAgICAgICAgbGV0IHNxbCA9IGBcclxuXHJcbiAgICAgICAgICAgICAgICBJTlNFUlQgZHRiX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAoIFxcYGN1c3RvbWVyX2lkXFxgLCBcXGBzdGF0dXNcXGAsIFxcYHNleFxcYCwgXFxgam9iXFxgLCBcXGBjb3VudHJ5X2lkXFxgLCBcXGBwcmVmXFxgLCBcXGBuYW1lMDFcXGAsIFxcYG5hbWUwMlxcYCwgXFxga2FuYTAxXFxgLCBcXGBrYW5hMDJcXGAsIFxcYGNvbXBhbnlfbmFtZVxcYCwgXFxgemlwMDFcXGAsIFxcYHppcDAyXFxgLCBcXGB6aXBjb2RlXFxgLCBcXGBhZGRyMDFcXGAsIFxcYGFkZHIwMlxcYCwgXFxgZW1haWxcXGAsIFxcYHRlbDAxXFxgLCBcXGB0ZWwwMlxcYCwgXFxgdGVsMDNcXGAsIFxcYGZheDAxXFxgLCBcXGBmYXgwMlxcYCwgXFxgZmF4MDNcXGAsIFxcYGJpcnRoXFxgLCBcXGBwYXNzd29yZFxcYCwgXFxgc2FsdFxcYCwgXFxgc2VjcmV0X2tleVxcYCwgXFxgZmlyc3RfYnV5X2RhdGVcXGAsIFxcYGxhc3RfYnV5X2RhdGVcXGAsIFxcYGJ1eV90aW1lc1xcYCwgXFxgYnV5X3RvdGFsXFxgLCBcXGBub3RlXFxgLCBcXGBjcmVhdGVfZGF0ZVxcYCwgXFxgdXBkYXRlX2RhdGVcXGAsIFxcYGRlbF9mbGdcXGAgKVxyXG5cclxuICAgICAgICAgICAgICAgIFZBTFVFUyggJHtyZWNvcmQuY3VzdG9tZXJfaWR9ICwgJHtyZWNvcmQuc3RhdHVzfSAsICR7cmVjb3JkLnNleH0gLCAke3JlY29yZC5qb2J9ICwgJHtyZWNvcmQuY291bnRyeV9pZH0gLCAke3JlY29yZC5wcmVmfSAsICR7cmVjb3JkLm5hbWUwMX0gLCAke3JlY29yZC5uYW1lMDJ9ICwgJHtyZWNvcmQua2FuYTAxfSAsICR7cmVjb3JkLmthbmEwMn0gLCAke3JlY29yZC5jb21wYW55X25hbWV9ICwgJHtyZWNvcmQuemlwMDF9ICwgJHtyZWNvcmQuemlwMDJ9ICwgJHtyZWNvcmQuemlwY29kZX0gLCAke3JlY29yZC5hZGRyMDF9ICwgJHtyZWNvcmQuYWRkcjAyfSAsICR7cmVjb3JkLmVtYWlsfSAsICR7cmVjb3JkLnRlbDAxfSAsICR7cmVjb3JkLnRlbDAyfSAsICR7cmVjb3JkLnRlbDAzfSAsICR7cmVjb3JkLmZheDAxfSAsICR7cmVjb3JkLmZheDAyfSAsICR7cmVjb3JkLmZheDAzfSAsICR7cmVjb3JkLmJpcnRofSAsICR7cmVjb3JkLnBhc3N3b3JkfSAsICR7cmVjb3JkLnNhbHR9ICwgJHtyZWNvcmQuc2VjcmV0X2tleX0gLCAke3JlY29yZC5maXJzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5sYXN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmJ1eV90aW1lc30gLCAke3JlY29yZC5idXlfdG90YWx9ICwgJHtyZWNvcmQubm90ZX0gLCAke3JlY29yZC5jcmVhdGVfZGF0ZX0gLCAke3JlY29yZC51cGRhdGVfZGF0ZX0gLCAke3JlY29yZC5kZWxfZmxnfSApXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBzdGF0dXM6IHJlY29yZC5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgIHNleDogcmVjb3JkLnNleCxcclxuICAgICAgICAgICAgICAgICAgam9iOiByZWNvcmQuam9iLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIGVtYWlsOiByZWNvcmQuZW1haWwsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGJpcnRoOiByZWNvcmQuYmlydGgsXHJcbiAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiByZWNvcmQucGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICAgIHNhbHQ6IHJlY29yZC5zYWx0LFxyXG4gICAgICAgICAgICAgICAgICBzZWNyZXRfa2V5OiByZWNvcmQuc2VjcmV0X2tleSxcclxuICAgICAgICAgICAgICAgICAgZmlyc3RfYnV5X2RhdGU6IHJlY29yZC5maXJzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgbGFzdF9idXlfZGF0ZTogcmVjb3JkLmxhc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90aW1lczogcmVjb3JkLmJ1eV90aW1lcyxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RvdGFsOiByZWNvcmQuYnV5X3RvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBub3RlOiByZWNvcmQubm90ZSxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lcl9hZGRyZXNzXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyX2FkZHJlc3MnLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2FkZHJlc3NfaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOODoeODq+ODnuOCrOODl+ODqeOCsOOCpOODsyBwbGdfbWFpbG1hZ2FfY3VzdG9tZXJcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfbWFpbG1hZ2FfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGlkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBtYWlsbWFnYV9mbGc6IHJlY29yZC5tYWlsbWFnYV9mbGcsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjgq/jg7zjg53jg7PnmbrooYzvvIhFQ0NVQkUy44Gu44Od44Kk44Oz44OI6YKE5YWD77yJXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uQ2QgPSBjcnlwdG8ucmFuZG9tQnl0ZXMoOCkudG9TdHJpbmcoJ2Jhc2U2NCcpLnN1YnN0cmluZygwLCAxMSlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25OYW1lID0gYCR7cmVjb3JkLm5hbWUwMX0gJHtyZWNvcmQubmFtZTAyfSDmp5gg44GU5YSq5b6F44Kv44O844Od44OzIOS8muWToeeVquWPtzoke3JlY29yZC5jdXN0b21lcl9pZH1gXHJcblxyXG4gICAgICAgICAgICBsZXQgZGlzY291bnRQcmljZSA9IHJlY29yZC5wb2ludCArIDUwMFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX2NvdXBvbicsIHtcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fY2Q6IGNvdXBvbkNkLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdHlwZTogMywgLy8g5YWo5ZWG5ZOBXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9uYW1lOiBjb3Vwb25OYW1lLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF90eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdXNlX3RpbWU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9yZWxlYXNlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9wcmljZTogZGlzY291bnRQcmljZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcmF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgZW5hYmxlX2ZsYWc6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9tZW1iZXI6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9sb3dlcl9saW1pdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX2Zyb21fZGF0ZTogJzIwMTgtMDQtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfdG9fZGF0ZTogJzIwMTktMDUtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiAwXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyAnY3ViZW1pZy5zZXJ2ZXJDaGVjaycgKHByb2ZpbGUpIHtcclxuICAgIGxldCBkYiA9IG5ldyBNeVNRTChwcm9maWxlKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGRiLnF1ZXJ5KCdTSE9XIERBVEFCQVNFUycpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IHsgTW9uZ29Db2xsZWN0aW9uIH0gZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL21vbmdvJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuY29sbGVjdGlvbidcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZmluZGBdIChwbHVnLCBxdWVyeSA9IHt9LCBwcm9qZWN0aW9uID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5maW5kKHF1ZXJ5LCB7cHJvamVjdGlvbjogcHJvamVjdGlvbn0pLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmFnZ3JlZ2F0ZWBdIChwbHVnLCBxdWVyeSA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuYWdncmVnYXRlKHF1ZXJ5KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuaXRlbXMnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z44Kz44Os44Kv44K344On44Oz5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44G+44GZ44CCXHJcbiAgICogQHBhcmFtXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uc2V0SW1hZ2VgXSAocGx1ZywgdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGxldCB1cGxvYWRlZCA9IGF3YWl0IGl0ZW1jb24uc2V0SW1hZ2UodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICAgIHJldHVybiB1cGxvYWRlZFxyXG4gIH0sXHJcblxyXG4gIC8qKlxyXG4gICAqIOOCouOCpOODhuODoOaDheWgseODh+ODvOOCv+ODmeODvOOCueOBrueUu+WDj+eZu+mMsuOCkuWJiumZpOOBmeOCi++8iOeUu+WDj+iHquS9k+OBr+WJiumZpOOBl+OBquOBhO+8iVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LmNsZWFuSW1hZ2VgXSAocGx1ZywgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5jbGVhbkltYWdlKG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IHtcclxuICBDdWJlM0FwaVxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9jdWJlM2FwaSdcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWcqOW6q+abtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVTdG9ja2BdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpXHJcbiAgICBsZXQgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+WcqOW6q+OBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdVUERBVEUnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseeZu+mMsuOBqOabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYkl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKVxyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQilcclxuXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdFQ0NVQkUz44G444Gu5ZWG5ZOB55m76YyyJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnSU5TRVJUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvblxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKVxyXG5cclxuICAgICAgICAgICAgICBsZXQgaW5zZXJ0UmVzID0gYXdhaXQgYXBpLnByb2R1Y3RDcmVhdGUoY3ViZUl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIC8vIGl0ZW0g44OH44O844K/44OZ44O844K544G444Gu55m76YyyXHJcbiAgICAgICAgICAgICAgYXdhaXQgY29sLnVwZGF0ZSh7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkXHJcbiAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X2lkLFxyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X2NsYXNzX2lkLFxyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X3N0b2NrX2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X3N0b2NrX2lkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+WVhuWTgeaDheWgseOBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RJbWFnZVVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IFBhY2tldCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcGFja2V0J1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgYXJjaGl2ZXIgZnJvbSAnYXJjaGl2ZXInXHJcbmltcG9ydCBjc3YgZnJvbSAnY3N2J1xyXG5cclxuY29uc3QgdGFnID0gJ3JvYm90aW5Qb3N0bGFiZWwnXHJcblxyXG5jb25zdCBPUkRFUl9OT19QUkVGSVggPSAn5Y+X5rOo55Wq5Y+377yaJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIFJvYm90LWluXHJcbiAgLy8g6YCB44KK54q244Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6LyJXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmFkZEl0ZW1Db2RlYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnUm9ib3QtaW4g6YCB44KK54q244Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6LyJJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vcG9zdGxhYmVsYFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyB3b3JrZGlyIOOBjOa6luWCmeOBleOCjOOBpuOBhOOBn+OCieWun+ihjOOBmeOCi1xyXG5cclxuICAgICAgICAgIC8vIGNvbnN0IHcgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyU2F2ZWZpbGV9YClcclxuXHJcbiAgICAgICAgICBsZXQgb3JkZXJDc3YgPSBhd2FpdCBmc0V4dHJhLnJlYWRGaWxlKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyQ3N2UHJlZml4fS5jc3ZgKVxyXG4gICAgICAgICAgb3JkZXJDc3YgPSBhd2FpdCBpY29udi5kZWNvZGUob3JkZXJDc3YsICdTSklTJylcclxuICAgICAgICAgIG9yZGVyQ3N2ID0gYXdhaXQgaWNvbnYuZW5jb2RlKG9yZGVyQ3N2LCAnVVRGLTgnKVxyXG5cclxuICAgICAgICAgIC8vIG9yZGVyQ3N2LnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAvLyAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC8vICAgLnBpcGUoY3N2LnBhcnNlKHtcclxuICAgICAgICAgIC8vICAgICBjb2x1bW5zOiB0cnVlXHJcbiAgICAgICAgICAvLyAgIH0pKVxyXG4gICAgICAgICAgLy8gICAucGlwZShjc3YudHJhbnNmb3JtKFxyXG4gICAgICAgICAgLy8gICAgIGFzeW5jIChyZWNPcmRlciwgY2FsbGJhY2spID0+IHtcclxuICAgICAgICAgIC8vICAgICAgIGxldCBlcnIgPSBudWxsXHJcbiAgICAgICAgICAvLyAgICAgICB0cnkge1xyXG4gICAgICAgICAgLy8g6YCB44KK54q244Gu56iu6aGe44GU44Go44Gr57mw44KK6L+U44GZXHJcbiAgICAgICAgICBhd2FpdCBjb25maWcucG9zdGFnZXMuZm9yRWFjaChcclxuICAgICAgICAgICAgYXN5bmMgZSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coYGNzdlByZWZpeDogJHtlLmNzdlByZWZpeH1gKVxyXG4gICAgICAgICAgICAgIC8vIGF3YWl0IGUuaWQuZm9yRWFjaChcclxuICAgICAgICAgICAgICAvLyAgIGFzeW5jIGlkID0+IHtcclxuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coYCR7aWQub3JkZXJ9OiAke3JlY09yZGVyW2lkLm9yZGVyXX1gKVxyXG4gICAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAgIC8vIClcclxuICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhgJHtjb25maWcuaXRlbUNvZGVDb2x1bW59OiAke3JlY09yZGVyW2NvbmZpZy5pdGVtQ29kZUNvbHVtbl19YClcclxuXHJcbiAgICAgICAgICAgICAgLy8g6YCB44KK54q2Q1NW44KS6ZaL44GN44CB6YWN6YCB44GU44Go44Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6LyJ44GZ44KLXHJcbiAgICAgICAgICAgICAgY29uc3QgcG9zdENTViA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyfS8ke2UuY3N2UHJlZml4fS5jc3ZgKVxyXG4gICAgICAgICAgICAgIHBvc3RDU1YucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGNzdi5wYXJzZSh7XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM6IHRydWVcclxuICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgICAvLyAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyAgICAgICAgIGVyciA9IGVcclxuICAgICAgICAgIC8vICAgICAgIH1cclxuICAgICAgICAgIC8vICAgICAgIGNhbGxiYWNrKGVyciwgcmVjT3JkZXIpXHJcbiAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgLy8gICApKVxyXG4gICAgICAgICAgLy8gLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAvLyAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAvLyAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC8vIC5waXBlKHcpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoYOato+OBl+OBhOS9nOalreODh+OCo+ODrOOCr+ODiOODquOBjOeUqOaEj+OBleOCjOOBpuOBhOOBvuOBm+OCk+OBp+OBl+OBn+OAguS4i+iomOOBruODleOCqeODq+ODgOOBuOWPl+azqENTVuOAgemAgeOCiueKtkNTVuOCkuOCs+ODlOODvOOBl+OBpuOBj+OBoOOBleOBhOOAglxcblske3dvcmtkaXJ9XWApXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAndG9vbCdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udGVzdGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcblxyXG4gICAgY29uc3QgbmV3TG9jYWwgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7fSwgYXN5bmMgKGUpID0+IHtcclxuICAgICAgdGhyb3cgZVxyXG4gICAgfSlcclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODleOCo+ODq+OCv+ODvOODhuOCueODiCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gbmV3TG9jYWxcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5pbXBvcnQgV293bWFBcGkgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL3dvd21hQXBpJ1xyXG5pbXBvcnQgdXRpbEVycm9yIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9lcnJvcidcclxuXHJcbmNvbnN0IHRhZyA9ICd3b3dtYSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDllYblk4Hjga7phY3pgIHmlrnms5XjgpLoqK3lrprjgZnjgotcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlSXRlbS5kZWxpdmVyeU1ldGhvZGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dvd21hISDllYblk4Hjga7phY3pgIHmlrnms5XjgpLoqK3lrprjgZnjgosnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyBqbGluZV9lbmdpbmUg5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aaXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5ZWG5ZOB5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgbGV0IGN1ciA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICAgICAgJGFuZDogW1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiB7ICRleGlzdHM6IDEgfVxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDk0MicgLy8gSkstMTIwXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihpdGVtLCBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVdvd21hQ3JlYXRlRGVsaXZlcnlNZXRob2QoaXRlbS5pdGVtQ29kZSkpXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS51cGRhdGVJdGVtKGl0ZW0pXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtyZXF1ZXN0Qm9keTogaXRlbSwgcmVzcG9uc2U6IHJlc31cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHRocm93IE9iamVjdC5hc3NpZ24oe3JlcXVlc3RCb2R5OiBpdGVtfSwgdXRpbEVycm9yLnBhcnNlKGUpKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueS4iuOBruWVhuWTgeOCkuWFrOmWi+OBmeOCi1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVJdGVtLm9wZW5gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB44OH44O844K/44OZ44O844K55LiK44Gu5ZWG5ZOB44KS5YWs6ZaL44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgaXRlbS5zYWxlU3RhdHVzID0gMVxyXG4gICAgICAgICAgICBpdGVtLmxpbWl0ZWRQYXNzd2QgPSAnTlVMTCdcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZUl0ZW0oaXRlbSlcclxuICAgICAgICAgICAgICByZXR1cm4ge3JlcXVlc3RCb2R5OiBpdGVtLCByZXNwb25zZTogcmVzfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih7cmVxdWVzdEJvZHk6IGl0ZW19LCB1dGlsRXJyb3IucGFyc2UoZSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5Zyo5bqr5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZVN0b2NrYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWcqOW6q+abtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWcqOW6q+aDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICBsZXQgY3VyID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgICAgICAkYW5kOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6IHsgJGV4aXN0czogMSB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8g44OG44K544OI5qSc57Si5p2h5Lu26Kit5a6aXHJcbiAgICAgICAgICAgICAgICAvLyAgICx7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnZ2stMTYzJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgXVxyXG4gICAgICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g6YWN6YCB5pa55rOV44Gu6YGV44GE44KS55yB44GPXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IHtcclxuICAgICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckbWFsbC53b3dtYS5pdGVtQ29kZScsXHJcbiAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlOiAnJG1hbGwud293bWEuSENob2ljZU5hbWUnLFxyXG4gICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6ICckbWFsbC53b3dtYS5WQ2hvaWNlTmFtZSdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBpdGVtOiB7XHJcbiAgICAgICAgICAgICAgICAgICRmaXJzdDogJyRfaWQnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Oa44O844K444GU44Go77yI5ZWG5ZOB44Kz44O844OJ77yJ44Gr44Kw44Or44O844OX5YyW44GZ44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckX2lkLml0ZW1Db2RlJyxcclxuICAgICAgICAgICAgICAgIHZhcmlhdGlvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgJHB1c2g6IHtcclxuICAgICAgICAgICAgICAgICAgICBfaWQ6ICckaXRlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGU6ICckX2lkLmNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlJyxcclxuICAgICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6ICckX2lkLmNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZSdcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnLFxyXG4gICAgICAgICAgICAgICAgdmFyaWF0aW9uczogJyR2YXJpYXRpb25zJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8gbGV0IHJlc01vbmdvID0gYXdhaXQgY3VyLnRvQXJyYXkoKVxyXG4gICAgICAgIC8vIHJldHVybiByZXNNb25nb1xyXG5cclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqNcclxuICAgICAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICAgICAgbGV0IGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpXHJcblxyXG4gICAgICAgICAgLy8g5Zyo5bqr44KS6Kit5a6a44GZ44KLXHJcbiAgICAgICAgICBmb3IgKGxldCBlIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgICAgICBlLnN0b2NrID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soZS5faWQpXHJcbiAgICAgICAgICAgIGRlbGV0ZSBlLl9pZFxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC8vXHJcbiAgICAgICAgICAvLyDlnKjluqvmm7TmlrDjg6rjgq/jgqjjgrnjg4hcclxuICAgICAgICAgIGxldCBhcGkgPSBuZXcgV293bWFBcGkoY29uZmlnLndvd21hQXBpUG9zdCwgY29uZmlnLnNob3BJZClcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlU3RvY2soW2l0ZW1dKVxyXG4gICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeaknOe0olxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5zZWFyY2hJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBvcHRpb25zID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShjb25maWcud293bWFBcGkpKVxyXG4gICAgICAgICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hJdGVtSW5mb2BcclxuICAgICAgICAgICAgb3B0aW9ucy5xcy5pdGVtQ29kZSA9IGl0ZW0ubWFsbC53b3dtYS5pdGVtQ29kZVxyXG5cclxuICAgICAgICAgICAgbGV0IHJlcG9zID0gYXdhaXQgcmVxdWVzdChvcHRpb25zKVxyXG4gICAgICAgICAgICBsZXQgZmlsZW5hbWUgPSBgJHt3b3JrZGlyfS8ke2l0ZW0ubW9kZWx9LnhtbGBcclxuXHJcbiAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEud3JpdGVGaWxlKGZpbGVuYW1lLCByZXBvcylcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBXb3dtYUFwaUl0ZW1GaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmNvbnN0IHRhZyA9ICd3b3dtYUFwaSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQeWVhuWTgeaDheWgseWPluW+l1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5nZXRJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgV293bWFBcGlJdGVtRmlsdGVyKGNvbmZpZy53b3dtYUFwaSwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIC8vIHRyeSB7XHJcbiAgICAgICAgLy8gICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIC8vIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIC8vIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICAvLyB0cnkge1xyXG4gICAgICAgIC8vICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIC8vIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhpdGVtKVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBQYWNrZXQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3BhY2tldCdcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcblxyXG5pbXBvcnQgaWNvbnYgZnJvbSAnaWNvbnYtbGl0ZSdcclxuaW1wb3J0IGFyY2hpdmVyIGZyb20gJ2FyY2hpdmVyJ1xyXG5pbXBvcnQgY3N2IGZyb20gJ2NzdidcclxuaW1wb3J0IHsgUGFzc1Rocm91Z2gsIFRyYW5zZm9ybSB9IGZyb20gJ3N0cmVhbSdcclxuXHJcbmNvbnN0IHByZWZpeCA9ICdwYWNrZXQnXHJcbmNvbnN0IHRhZyA9ICd5YXVjdCdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDjg6Tjg5Xjgqrjgq/lj5fms6jjg5XjgqHjgqTjg6tcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ub3JkZXJgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lj5fms6gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9vcmRlcmBcclxuICAgICAgICBjb25zdCByID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyTG9hZGZpbGV9YClcclxuICAgICAgICBjb25zdCB3ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbShgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlclNhdmVmaWxlfWApXHJcbiAgICAgICAgci5waXBlKGljb252LmRlY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAucGlwZShjc3YudHJhbnNmb3JtKFxyXG4gICAgICAgICAgICBhc3luYyAocmVjb3JkLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgIGxldCBlcnIgPSBudWxsXHJcbiAgICAgICAgICAgICAgLy8g566h55CG55Wq5Y+344KS572u44GN5o+b44GI44KLXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHJlY29yZFsn566h55CG55Wq5Y+3J10gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRNb2RlbENsYXNzKHJlY29yZFsn566h55CG55Wq5Y+3J10pXHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgZXJyID0gZVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBjYWxsYmFjayhlcnIsIHJlY29yZClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKSlcclxuICAgICAgICAgIC5waXBlKGNzdi5zdHJpbmdpZnkoe2hlYWRlcjogdHJ1ZX0pKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAucGlwZSh3KVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyDjg6Tjg5Xjgqrjgq/lh7rlk4Hjg5XjgqHjgqTjg6tcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJpdGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODpOODleOCquOCr+WHuuWTgScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOe5sOOCiui/lOOBl+WHpueQhuOCkuS7u+aEj+OBru+8iHBhY2tldFNpemXvvInjgafliIblibJcclxuICAgICAgICBjb25zdCBwYWNrZXQgPSBuZXcgUGFja2V0KGNvbmZpZy5wYWNrZXRTaXplKVxyXG5cclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgpLkvZzmiJDjgZfnlLvlg4/jg4fjg7zjgr/jgpLlj47pm4bjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L3dvcmtgXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUod29ya2RpcilcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcblxyXG4gICAgICAgIC8vIFpJUOODleOCoeOCpOODq+OCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHVwbG9hZGRpciA9IGAke2NvbmZpZy53b3JrZGlyfS91cGxvYWRgXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUodXBsb2FkZGlyKVxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIodXBsb2FkZGlyKVxyXG5cclxuICAgICAgICBsZXQgY2QgPSBudWxsIC8vIOODkeOCseODg+ODiOODleOCqeODq+ODgFxyXG4gICAgICAgIGxldCBmaWxlbmFtZSA9IG51bGwgLy8gY3N244OV44Kh44Kk44OrXHJcbiAgICAgICAgbGV0IG5hbWUgPSBudWxsIC8vIOODkeOCseODg+ODiOeVquWPt1xyXG5cclxuICAgICAgICAvLyBDU1bjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZfjgIHpoIbnlarjgpLnorrlrprjgZnjgotcclxuICAgICAgICBsZXQgZmllbGRzID0gWyfnrqHnkIbnlarlj7cnLCAn44Kr44OG44K044OqJywgJ+OCv+OCpOODiOODqycsICfoqqzmmI4nLCAn44K544OI44Ki5YaF5ZWG5ZOB5qSc57Si55So44Kt44O844Ov44O844OJJywgJ+mWi+Wni+S+oeagvCcsICfljbPmsbrkvqHmoLwnLCAn5YCk5LiL44GS5Lqk5riJJywgJ+WAi+aVsCcsICflhaXmnK3lgIvmlbDliLbpmZAnLCAn5pyf6ZaTJywgJ+e1guS6huaZgumWkycsICfllYblk4HnmbrpgIHlhYPjga7pg73pgZPlupznnIwnLCAn5ZWG5ZOB55m66YCB5YWD44Gu5biC5Yy655S65p2RJywgJ+mAgeaWmeiyoOaLhScsICfku6Pph5HlhYjmiZXjgYTjgIHlvozmiZXjgYQnLCAn6JC95pyt44OK44OT5rG65riI5pa55rOV6Kit5a6aJywgJ+WVhuWTgeOBrueKtuaFiycsICfllYblk4Hjga7nirbmhYvlgpnogIMnLCAn6L+U5ZOB44Gu5Y+v5ZCmJywgJ+i/lOWTgeOBruWPr+WQpuWCmeiAgycsICfnlLvlg48xJywgJ+eUu+WDjzHjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMicsICfnlLvlg48y44Kz44Oh44Oz44OIJywgJ+eUu+WDjzMnLCAn55S75YOPM+OCs+ODoeODs+ODiCcsICfnlLvlg480JywgJ+eUu+WDjzTjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNScsICfnlLvlg48144Kz44Oh44Oz44OIJywgJ+eUu+WDjzYnLCAn55S75YOPNuOCs+ODoeODs+ODiCcsICfnlLvlg483JywgJ+eUu+WDjzfjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOCcsICfnlLvlg48444Kz44Oh44Oz44OIJywgJ+eUu+WDjzknLCAn55S75YOPOeOCs+ODoeODs+ODiCcsICfnlLvlg48xMCcsICfnlLvlg48xMOOCs+ODoeODs+ODiCcsICfmnIDkvY7oqZXkvqEnLCAn5oKq6KmV5Ymy5ZCI5Yi26ZmQJywgJ+WFpeacreiAheiqjeiovOWItumZkCcsICfoh6rli5Xlu7bplbcnLCAn5pep5pyf57WC5LqGJywgJ+WVhuWTgeOBruiHquWLleWGjeWHuuWTgScsICfoh6rli5XlgKTkuIvjgZInLCAn5pyA5L2O6JC95pyt5L6h5qC8JywgJ+ODgeODo+ODquODhuOCo+ODvCcsICfms6jnm67jga7jgqrjg7zjgq/jgrfjg6fjg7MnLCAn5aSq5a2X44OG44Kt44K544OIJywgJ+iDjOaZr+iJsicsICfjgrnjg4jjgqLjg5vjg4Pjg4jjgqrjg7zjgq/jgrfjg6fjg7MnLCAn55uu56uL44Gh44Ki44Kk44Kz44OzJywgJ+i0iOetlOWTgeOCouOCpOOCs+ODsycsICdU44Od44Kk44Oz44OI44Kq44OX44K344On44OzJywgJ+OCouODleOCo+ODquOCqOOCpOODiOOCquODl+OCt+ODp+ODsycsICfojbfnianjga7lpKfjgY3jgZUnLCAn6I2354mp44Gu6YeN6YePJywgJ+OBr+OBk0JPT04nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMScsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTHlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMicsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTLlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTPlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTTlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNScsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTXlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNicsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTblhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTflhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTjlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOScsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTnlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTAnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTDmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTDlhajlm73kuIDlvovkvqHmoLwnLCAn5rW35aSW55m66YCBJywgJ+mFjemAgeaWueazleODu+mAgeaWmeioreWumicsICfku6PlvJXmiYvmlbDmlpnoqK3lrponLCAn5raI6LK756iO6Kit5a6aJywgJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXVxyXG4gICAgICAgIGxldCBoZWFkZXIgPSBmaWVsZHMubWFwKHYgPT4gYFwiJHt2fVwiYCkuam9pbignLCcpICsgJ1xcbidcclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW6ZaL5aeL5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0U3RhcnQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcclxuICAgICAgICAgIG5hbWUgPSBwcmVmaXggKyAoJzAwMDAwJyArIHBhY2tldENvdW50KS5zbGljZSgtNSlcclxuICAgICAgICAgIGNkID0gYCR7d29ya2Rpcn0vJHtuYW1lfWBcclxuICAgICAgICAgIGZpbGVuYW1lID0gYCR7Y2R9LyR7Y29uZmlnLmNzdkZpbGVOYW1lfWBcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY2QpXHJcbiAgICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgavjg5XjgqPjg7zjg6vjg4njgpLoqK3lrprjgZnjgotcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKGhlYWRlciwgJ1NoaWZ0X0pJUycpKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0ID0gYXN5bmMgKGFyZykgPT4ge1xyXG4gICAgICAgICAgbGV0IHlhdWN0ID0gYXJnLnlhdWN0XHJcbiAgICAgICAgICBsZXQgaXRlbSA9IGFyZy5pdGVtXHJcbiAgICAgICAgICAvLyBjc3bjg5XjgqHjgqTjg6vjgavjg6zjgrPjg7zjg4nvvIjllYblk4Hjg4bjg7Pjg5fjg6zjg7zjg4jvvInjgpLov73liqDjgZnjgotcclxuICAgICAgICAgIGxldCByZWNvcmQgPSBmaWVsZHMubWFwKHYgPT4geyByZXR1cm4geWF1Y3Rbdl0gPyBgXCIke3lhdWN0W3ZdfVwiYCA6ICdcIlwiJyB9KS5qb2luKCcsJykgKyAnXFxuJ1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUocmVjb3JkLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgICAvLyDnlLvlg4/jg5XjgqHjgqTjg6vjgpLjgrPjg5Tjg7xcclxuICAgICAgICAgIGZvciAobGV0IGltZyBvZiBpdGVtLmltYWdlcykge1xyXG4gICAgICAgICAgICBsZXQgaW1nU3JjID0gYCR7Y29uZmlnLmltYWdlZGlyfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIGxldCBpbWdUZ3QgPSBgJHtjZH0vJHtpbWd9YFxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIC8vIOWQjOOBmOODleOCoeOCpOODq+OBjOOBguOCi+WgtOWQiOOBr+OCs+ODlOODvOOBl+OBquOBhFxyXG4gICAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYWNjZXNzKGltZ1RndClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEuY29weUZpbGUoaW1nU3JjLCBpbWdUZ3QpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOe1guS6huaZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldEVuZCA9IGFzeW5jIChwYWNrZXRDb3VudCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgemlwID0gYXJjaGl2ZXIoJ3ppcCcpXHJcbiAgICAgICAgICBjb25zdCB6aXBuYW1lID0gYCR7dXBsb2FkZGlyfS8ke25hbWV9LnppcGBcclxuICAgICAgICAgIGNvbnN0IG91dHB1dCA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oemlwbmFtZSlcclxuICAgICAgICAgIHppcC5waXBlKG91dHB1dClcclxuICAgICAgICAgIHppcC5kaXJlY3RvcnkoY2QsIGZhbHNlKVxyXG4gICAgICAgICAgemlwLmZpbmFsaXplKClcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICAvLyBpdGVt44Gr5a6a576p44GV44KM44Gm44GE44KL5pyA5L2O5b+F6KaB5Zyo5bqr44KI44KK5aSa44GE5ZWG5ZOB44KS5Ye65ZOB44GZ44KLXHJcbiAgICAgICAgICAgIGlmIChxdWFudGl0eSA+PSBpdGVtLm1hbGwueWF1Y3QubWluUXVhbnRpdHkpIHtcclxuICAgICAgICAgICAgICBsZXQgeWF1Y3QgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVlhdWN0KGNvbmZpZy5kZWZhdWx0LCBpdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IHBhY2tldC5zdWJtaXQoe3lhdWN0OiB5YXVjdCwgaXRlbTogaXRlbX0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICBwYWNrZXQuY2xvc2UoKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgJy4uL2ltcG9ydHMvY29sbGVjdGlvbi9jb25maWdzJ1xyXG5cclxuaW1wb3J0ICcuL3JvdXRlL3VwbG9hZC9pbWFnZSdcclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcblxyXG5leHBvcnQgY29uc3QgQ29uZmlncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb25maWdzJywge2lkR2VuZXJhdGlvbjogJ01PTkdPJ30pXHJcblxyXG4vLyBNZXRlb3IubWV0aG9kcyh7XHJcbi8vICAgYXN5bmMgJ215c3FsU2VydmVycy5pbnNlcnQnICggbmV3U2VydmVyICl7XHJcbi8vICAgICByZXR1cm4gYXdhaXQgTXlzcWxTZXJ2ZXJzLmluc2VydChuZXdTZXJ2ZXIpO1xyXG4vLyAgIH1cclxuLy8gfSk7XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0JztcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnO1xyXG5pbXBvcnQgeyBHcm91cEJhc2UgfSBmcm9tICcuL2dyb3Vwcyc7XHJcblxyXG5jb25zdCBGaWx0ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZpbHRlcnMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZpbHRlciBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGZpbHRlcklkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBGaWx0ZXJzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGZpbHRlcklkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcblxyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKCBvblJlc3VsdCA9IChyZWNvcmQpPT57fSwgb25FcnJvciA9IChlKT0+e30gKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGxhdGZvcm0gdHlwZScpO1xyXG5cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7eyBmaWx0ZXJUeXBlOiBhc3luYyAocmVjb3JkICkgPT4ge30gfX0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoKGNhbGxiYWNrcyA9IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGUoKTtcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICB0eXBlOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnQgPSB7fTtcclxuICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgY291bnRbZmlsdGVyLnR5cGVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmaWx0ZXIucXVlcnksXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCk9PntcclxuICAgICAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgICAgICBsZXQgcXVlcnkgPSBtb2JqZWN0LnVuZXNjYXBlKGZpbHRlci5xdWVyeSk7XHJcbiAgICAgICAgICBsZXQgZXhhbSA9IHNpZnQoIHF1ZXJ5ICk7XHJcbiAgICAgICAgICBpZiggZXhhbShyZWNvcmQpICl7XHJcbiAgICAgICAgICAgIGNvdW50W2ZpbHRlci50eXBlXS5jb3VudCsrO1xyXG4gICAgICAgICAgICBpZiggdHlwZW9mIGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFja3NbZmlsdGVyLnR5cGVdKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBvbkVycm9yXHJcbiAgICApO1xyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnQ7XHJcblxyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbmNvbnN0IEdyb3VwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdncm91cHMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwQmFzZSB7XHJcblxyXG4gIHByb2ZpbGU7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb2ZpbGUpIHtcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBnZXRzICdQbHVnJyB3aXRjaCBpcyBhIHNldCBvZiBwcm9wZXJ0aWVzIG5lZWRlZFxyXG4gICAqIHdoZW4gY29ubmVjdCB0byBzb21lIHBsYXRmb3Jtc1xyXG4gICAqIHRvIGdldCBkYXRhcyhNZW1iZXJzIG9mIHRoZSBHcm91cClcclxuICAgKi9cclxuICBnZXRQbHVnKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZS5wbGF0Zm9ybVBsdWc7XHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZTtcclxuICB9XHJcblxyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge307XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXAgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihncm91cElkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBHcm91cHMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZ3JvdXBJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKGRvYykgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX0gV0hFUkUgXFxgJHtkb2Mua2V5fVxcYCA9IFwiJHtkb2MuaWR9XCJgO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBncm91cCB0eXBlJyk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7YXN5bmMgKHJlY29yZCk9PnZvaWR9IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IGN1ciA9IEdyb3Vwcy5maW5kKHtcclxuICAgICAgZ3JvdXBJZDogdGhpcy5wcm9maWxlLl9pZFxyXG4gICAgfSwge1xyXG4gICAgICBmaWVsZHM6IHtcclxuICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAga2V5OiAxXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGN1ci5mb3JFYWNoKFxyXG4gICAgICAgICAgYXN5bmMgKGRvYywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVjb3JkID0gYXdhaXQgdGhpcy5pbXBvcnQoZG9jKTtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFjayhyZWNvcmQpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgb25FcnJvcihlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaW5kZXggKyAxID09PSBjdXIuY291bnQoKSkge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICB9XHJcbiAgICApLmNhdGNoKFxyXG4gICAgICAoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2xvZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG4gXHJcbmV4cG9ydCBjb25zdCBVcGxvYWRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VwbG9hZHMnLHtpZEdlbmVyYXRpb246J01PTkdPJ30pO1xyXG5cclxuIiwiaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuXHJcbmV4cG9ydCBjbGFzcyBDdWJlM0FwaSB7XHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge015U1FMfSBteXNxbFxyXG4gICAqL1xyXG4gIGNvbnN0cnVjdG9yIChteXNxbCkge1xyXG4gICAgdGhpcy5teXNxbF8gPSBteXNxbFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHByb2R1Y3RDbGFzc0lkLCBxdWFudGl0eSA9IDApIHtcclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcclxuICAgICAge30sIHtcclxuICAgICAgICBzdG9jazogcXVhbnRpdHksXHJcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJyxcclxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXHJcbiAgICAgIHt9LCB7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RUYWdVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDliYrpmaTjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvZmYgPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDooajnpLrjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvbiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgLy8g44GZ44Gn44Gr6KGo56S644GV44KM44Gm44GE44KL44K/44Kw44GM44GC44KM44Gw5L2V44KC44GX44Gq44GEXHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIFNFTEVDVCBDT1VOVCgqKSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgbGV0IGNvdW50UmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKVxyXG4gICAgICBpZiAoY291bnRSZXNbMF1bJ0NPVU5UKCopJ10pIHJldHVyblxyXG5cclxuICAgICAgcmVzLnB1c2goXHJcbiAgICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAnZHRiX3Byb2R1Y3RfdGFnJyxcclxuICAgICAgICAgIHt9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBkYXRhLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgICAgIHRhZzogdGFnLFxyXG4gICAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKSlcclxuICAgIH1cclxuXHJcbiAgICBmb3IgKGxldCB0YWdTZXQgb2YgZGF0YS50YWdzKSB7XHJcbiAgICAgIHN3aXRjaCAodGFnU2V0LnNldCkge1xyXG4gICAgICAgIGNhc2UgJ29uJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29uKHRhZ1NldC50YWcpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICAgIGNhc2UgJ29mZic6XHJcbiAgICAgICAgICBhd2FpdCB0YWdvZmYodGFnU2V0LnRhZylcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdEltYWdlVXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgcHJvZHVjdElkID0gZGF0YS5wcm9kdWN0X2lkXHJcbiAgICBsZXQgaW1hZ2VzID0gZGF0YS5pbWFnZXNcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDllYblk4HjgavplqLpgKPjgZnjgovjgZnjgbnjgabjga7nlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgotcclxuICAgIGxldCBzcWwgPSBgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfaW1hZ2UgV0hFUkUgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdElkfWBcclxuICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbCkpXHJcbiAgICAvLyDmlLnjgoHjgabnlLvlg4/jgpLnmbvpjLLjgZfjgarjgYrjgZlcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICdkdGJfcHJvZHVjdF9pbWFnZScsIHtcclxuICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcclxuICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICAgIGZpbGVfbmFtZTogaW1hZ2VzW2ldLFxyXG4gICAgICAgICAgcmFuazogaSArIDFcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBsZXQga2V5cyA9IFtdXHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RcclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnc3RhdHVzJyxcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnbm90ZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9saXN0JyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXHJcbiAgICAgICdzZWFyY2hfd29yZCcsXHJcbiAgICAgICdmcmVlX2FyZWEnXHJcbiAgICBdXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBkdGJfcHJvZHVjdF9jbGFzc1xyXG5cclxuICAgIHVwZGF0ZURhdGEgPSB7fVxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ2RlbGl2ZXJ5X2RhdGVfaWQnLFxyXG4gICAgICAncHJvZHVjdF9jb2RlJyxcclxuICAgICAgJ3NhbGVfbGltaXQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJyxcclxuICAgICAgJ2RlbGl2ZXJ5X2ZlZSdcclxuICAgIF1cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdENyZWF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSB7fVxyXG5cclxuICAgIGxldCB1cGRhdGVEYXRhID0ge31cclxuICAgIGxldCBrZXlzID0gW11cclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnbmFtZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnXHJcbiAgICBdXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgIC8vICAgZGVzY3JpcHRpb25fZGV0YWlsOiBpdGVtLmRlc2NyaXB0aW9uLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBzdGF0dXM6IDEsXHJcbiAgICAgICAgbm90ZTogJ05VTEwnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uX2xpc3Q6ICdOVUxMJyxcclxuICAgICAgICBzZWFyY2hfd29yZDogJ05VTEwnLFxyXG4gICAgICAgIGZyZWVfYXJlYTogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICB1cGRhdGVEYXRhID0ge31cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAncHJvZHVjdF90eXBlX2lkJyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIHByb2R1Y3RfY29kZTogaXRlbS5tb2RlbCxcclxuICAgIC8vICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAvLyAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9jbGFzc19pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHByb2R1Y3RfaWQ6IHJlcy5wcm9kdWN0X2lkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDE6ICdOVUxMJyxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDI6ICdOVUxMJyxcclxuICAgICAgICBkZWxpdmVyeV9kYXRlX2lkOiAnTlVMTCcsXHJcbiAgICAgICAgc2FsZV9saW1pdDogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3Rfc3RvY2tfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJywge30sIHtcclxuICAgICAgICBwcm9kdWN0X2NsYXNzX2lkOiByZXMucHJvZHVjdF9jbGFzc19pZCxcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgc3RvY2s6IDAsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIGZvciB0ZXN0XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNb25nb0NsaWVudH0gZnJvbSAnbW9uZ29kYidcclxuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCdcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnXHJcbmltcG9ydCB7IHhtbDJqcyB9IGZyb20gJ3htbC1qcydcclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlckZhY3Rvcnkge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBsZXQgaW5zdGFuY2VcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICBpbnN0YW5jZSA9IG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGluc3RhbmNlXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnXHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlXHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZmFjdG9yeSAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHJldHVybiBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKVxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbHVnIHR5cGUnKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0UGx1Z18gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Z1xyXG4gIH1cclxuXHJcbiAgZ2V0Q3JlZF8gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Zy5jcmVkXHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlXHJcbiAgfVxyXG5cclxuICBzZXRJbXBvcnRGdW5jdGlvbl8gKFxyXG4gICAgZm4gPSBhc3luYyAob25SZXN1bHQgPSByZWNvcmQgPT4ge30sIG9uRXJyb3IgPSBlID0+IHt9KSA9PiB7fVxyXG4gICkge1xyXG4gICAgdGhpcy5pbXBvcnQgPSBmblxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogdXNlYWdlOlxyXG4gICAqXHJcbiAgICpcclxuICAgKiBAcGFyYW0geyBPYmplY3QgfSBpdGVyYXRvcnMgeyBmaWx0ZXJOYW1lOiBhc3luYyAoZG9jLGNvbnRleHQpPT57fSwgLi4uIH0gaXRlcmF0b3IgZm9yIGVhY2ggZmlsdGVyc1xyXG4gICAqIEBwYXJhbSB7IGFzeW5jIGZ1bmN0aW9uIH0gb25FcnJvciBlcnJvciBoYW5kbGVyIHdoaWxlIGl0ZXJhdGluZ1xyXG4gICAqIEByZXR1cm5zIHsgT2JqZWN0IH0geyBmaWx0ZXJOYW1lOiB7IHF1ZXJ5OiBhbnksIGNvdW50OiBudW1iZXIgfSwgLi4uIH1cclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoIChpdGVyYXRvcnMgPSB7fSkge1xyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGVfKClcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICBuYW1lOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnRlciA9IHt9XHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBmaWx0ZXJzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgICBjb3VudGVyW2YubmFtZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGYucXVlcnksXHJcbiAgICAgICAgbGltaXQ6IHR5cGVvZiBmLmxpbWl0ICE9PSAndW5kZWZpbmVkJyA/IGYubGltaXQgOiAwLFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH1cclxuICAgICAgZmlsdGVycy5wdXNoKFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6IGYubmFtZSxcclxuICAgICAgICAgIGV4YW06IHNpZnQobW9iamVjdC51bmVzY2FwZShmLnF1ZXJ5KSlcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgIGZvciAobGV0IGYgb2YgZmlsdGVycykge1xyXG4gICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXHJcbiAgICAgICAgICBsZXQgYyA9IGNvdW50ZXJbZi5uYW1lXVxyXG4gICAgICAgICAgaWYgKGMubGltaXQpIHtcclxuICAgICAgICAgICAgaWYgKGMuY291bnQgPj0gYy5saW1pdCkge1xyXG4gICAgICAgICAgICAgIGNvbnRpbnVlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZi5leGFtKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXHJcbiAgICAgICAgICAgIGMuY291bnQrK1xyXG5cclxuICAgICAgICAgICAgLy8gaXRlcmF0b3JcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVyYXRvcnNbZi5uYW1lXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICBhd2FpdCBpdGVyYXRvcnNbZi5uYW1lXShyZWNvcmQsIGNvbnRleHQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudGVyXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTXlzcWxEQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKVxyXG5cclxuICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwoY3JlZClcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWBcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgKGUpID0+IHsgdGhyb3cgZSB9KVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuLy8gaW1wb3J0IE1vbmdvTmF0aXZlIGZyb20gJ21vbmdvZGInO1xyXG4vLyBjb25zdCBNb25nb0NsaWVudCA9IE1vbmdvTmF0aXZlLk1vbmdvQ2xpZW50O1xyXG4vLyBjb25zdCBNb25nb0NsaWVudCA9IHJlcXVpcmUoJ21vbmdvZGInKS5Nb25nb0NsaWVudDtcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKVxyXG5cclxuICAgIC8vIG1vbmdvIOOBuOaOpee2mlxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBjbGllbnRcclxuICAgICAgY2xpZW50ID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSlcclxuXHJcbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xyXG4gICAgICBsZXQgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSlcclxuICAgICAgbGV0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbilcclxuXHJcbiAgICAgIGxldCBjb250ZXh0ID0ge1xyXG4gICAgICAgIGNsaWVudDogY2xpZW50LFxyXG4gICAgICAgIGNvbGxlY3Rpb246IGNvbGxlY3Rpb24sXHJcbiAgICAgICAgZGF0YWJhc2U6IGRiXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKVxyXG5cclxuICAgICAgLy8g44Kr44O844K944Or44Gu44K/44Kk44Og44Ki44Km44OI44KS6Kej6ZmkXHJcbiAgICAgIGN1ci5hZGRDdXJzb3JGbGFnKCdub0N1cnNvclRpbWVvdXQnLCB0cnVlKVxyXG5cclxuICAgICAgLy8g44GZ44G544Gm44Gu44OJ44Kt44Ol44Oh44Oz44OI44KS44Or44O844OXXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgICAgIGxldCBkb2MgPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgICAgICBhd2FpdCBvblJlc3VsdChkb2MsIGNvbnRleHQpXHJcbiAgICAgICAgfTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAvLyDjgqvjg7zjgr3jg6vjgpLplovmlL5cclxuICAgICAgICBhd2FpdCBjdXIuY2xvc2UoKVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIFdvd21hQXBpSXRlbUZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICAvLyDllYblk4Hmg4XloLHjga7lj5blvpfjg6vjg7zjg5fjgpLlrprnvqlcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcclxuICAgICAgbGV0IG9wdGlvbnMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHBsdWcpKVxyXG4gICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hTdG9ja3NgXHJcbiAgICAgIGxldCBjb250ZXh0ID0ge1xyXG4gICAgICAgIG9wdGlvbnM6IG9wdGlvbnNcclxuICAgICAgfVxyXG5cclxuICAgICAgd2hpbGUgKDEpIHtcclxuICAgICAgICAvLyBXb3dtYSBBcGkg44GL44KJ5ZWG5ZOB5oOF5aCx44KS5Y+W5b6XXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3Qob3B0aW9ucylcclxuICAgICAgICByZXMgPSB4bWwyanMocmVzLCB7Y29tcGFjdDogdHJ1ZX0pXHJcblxyXG4gICAgICAgIGxldCBtYXhDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0Lm1heENvdW50Ll90ZXh0KVxyXG4gICAgICAgIGxldCByZXN1bHRDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0LnJlc3VsdENvdW50Ll90ZXh0KVxyXG4gICAgICAgIGxldCBzdGFydENvdW50ID0gTnVtYmVyKHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQuc3RhcnRDb3VudC5fdGV4dClcclxuICAgICAgICBsZXQgcmVzdWx0U3RvY2tzID0gcmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5yZXN1bHRTdG9ja3NcclxuXHJcbiAgICAgICAgLy8g5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS44Kr44K544K/44Og44OX44Ot44K744K544Gr5rih44GZXHJcbiAgICAgICAgaWYgKHJlc3VsdFN0b2NrcyBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICAgICAgICAvLyDlj5blvpfjgZfjgZ/jg4fjg7zjgr/jgYzopIfmlbDllYblk4Hjga7loLTlkIhcclxuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0Q291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICBhd2FpdCBvblJlc3VsdChyZXN1bHRTdG9ja3NbaV0sIGNvbnRleHQpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIOWPluW+l+OBl+OBn+ODh+ODvOOCv+OBjOWNmOaVsOWVhuWTgeOBruWgtOWQiFxyXG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQocmVzdWx0U3RvY2tzLCBjb250ZXh0KVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG5leHQgPSBzdGFydENvdW50ICsgcmVzdWx0Q291bnRcclxuXHJcbiAgICAgICAgaWYgKG5leHQgPiBtYXhDb3VudCkgYnJlYWtcclxuICAgICAgICBvcHRpb25zLnFzLnN0YXJ0Q291bnQgPSBuZXh0XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbi8vICAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xyXG4vLyAgICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XHJcblxyXG4vLyAgICAgLy8gbW9uZ28g44G45o6l57aaXHJcbi8vICAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuLy8gICAgIGxldCBjb251cmkgPSBgbW9uZ29kYjovLyR7Y3JlZC5ob3N0fToke2NyZWQucG9ydH0vJHtjcmVkLmRhdGFiYXNlfWA7XHJcbi8vICAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KGNvbnVyaSk7XHJcblxyXG4vLyAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5L2c44KLXHJcbi8vICAgICBsZXQgY29sbGVjdGlvbiA9IG1vbmdvb3NlLmNvbm5lY3Rpb24uY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG5cclxuLy8gICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4vLyAgICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XHJcblxyXG4vLyAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH1cclxuLy8gfVxyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvQ29sbGVjdGlvblxyXG59IGZyb20gJy4uL3V0aWwvbW9uZ28nXHJcbmltcG9ydCB7XHJcbiAgVXBsb2Fkc1xyXG59IGZyb20gJy4uL2NvbGxlY3Rpb24vdXBsb2FkcydcclxuaW1wb3J0IHtcclxuICBPYmplY3RJRFxyXG59IGZyb20gJ2Jzb24nXHJcbmltcG9ydCBUZXh0VXRpbCBmcm9tICcuLi91dGlsL3RleHQnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtQ29udHJvbGxlciB7XHJcbiAgYXN5bmMgaW5pdCAocGx1Zykge1xyXG4gICAgdGhpcy5JdGVtcyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ2l0ZW1zJylcclxuICAgIHRoaXMuUHJvZHVjdHMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdwcm9kdWN0cycpXHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTdG9jayAoaXRlbUlkKSB7XHJcbiAgICBsZXQgaXRlbSA9IGF3YWl0IHRoaXMuSXRlbXMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogaXRlbUlkXHJcbiAgICB9LCB7XHJcbiAgICAgIHByb2plY3Rpb246IHtcclxuICAgICAgICAncHJvZHVjdCc6IDFcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIGxldCBwcm9kdWN0U2V0ID0gaXRlbS5wcm9kdWN0XHJcblxyXG4gICAgLy8gcHJvZHVjdCAqIDwtPiAqIGl0ZW1cclxuICAgIC8vIHByb2R1Y3RbXTog6KSH5pWw44Gu5ZWG5ZOB44KSMeODkeODg+OCseODvOOCuOOBqOOBl+OBpuiyqeWjslxyXG4gICAgLy8gcHJvZHVjdFt7aWRzOls8T2JqZWN0SWQ+XSxzZXQ6PE51bWJlcj59XTog55Ww44Gq44KL5rWB6YCa57WM6Lev44CB55Ww44Gq44KL5Y6f5L6h44O75LuV5YWl44KM5YCkXHJcbiAgICAvLyBpdGVtOiDnlbDjgarjgovjgrvjg7zjg6vjgIHosqnlo7LlvaLmhYtcclxuICAgIC8vIOKAuyBwcm9kdWN0IOOBi+OCieOBr+OAgeiyqeWjsuWPr+iDveOBquWcqOW6q+OAgeWIqeebiuioiOeul+OBruOBn+OCgeOBruaDheWgseOCkuW+l+OCi1xyXG5cclxuICAgIGxldCBxdWFudGl0aWVzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBwcm9kdWN0UmVmIG9mIHByb2R1Y3RTZXQpIHtcclxuICAgICAgbGV0IHByZFF1YW50aXR5ID0gMFxyXG5cclxuICAgICAgZm9yIChsZXQgaWQgb2YgcHJvZHVjdFJlZi5pZHMpIHtcclxuICAgICAgICBsZXQgcHJvZHVjdCA9IGF3YWl0IHRoaXMuUHJvZHVjdHMuZmluZE9uZSh7XHJcbiAgICAgICAgICBfaWQ6IGlkXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgICAnc3RvY2snOiAxXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBsZXQgc3RvY2tBcnJheSA9IHByb2R1Y3Quc3RvY2tcclxuXHJcbiAgICAgICAgLy8g5Y2Y57SU44Gr44GZ44G544Gm44Gu5Zyo5bqr5ZWG5ZOB44CB55+t5pyf6ZaT5Y+W44KK5a+E44Gb5Y+v6IO95ZWG5ZOB44KS5ZCI566XXHJcbiAgICAgICAgZm9yIChsZXQgc3RvY2sgb2Ygc3RvY2tBcnJheSkge1xyXG4gICAgICAgICAgcHJkUXVhbnRpdHkgKz0gc3RvY2sucXVhbnRpdHlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIOWVhuWTgShpdGVtKeOBruWcqOW6q+aVsCA9IOijveWTgeWcqOW6q+aVsChwcmRRdWFudGl0eSkgLyDlv4XopoHjgrvjg4Pjg4jmlbAocHJvZHVjdFJlZi5zZXQpXHJcbiAgICAgIHF1YW50aXRpZXMucHVzaChNYXRoLmZsb29yKHByZFF1YW50aXR5IC8gcHJvZHVjdFJlZi5zZXQpKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCu+ODg+ODiOWVhuWTgeOBruWgtOWQiOOAgeS4gOeVquWwkeOBquOBhOWVhuWTgeaVsOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IHF1YW50aXR5ID0gTWF0aC5taW4uYXBwbHkobnVsbCwgcXVhbnRpdGllcylcclxuXHJcbiAgICByZXR1cm4gcXVhbnRpdHlcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgovjgIJcclxuICAgKlxyXG4gICAqIOODoeODvOOCq+ODvOODouODh+ODq+OBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog54m55a6a44Gu5bGe5oCn77yI44Kr44Op44O844Gq44Gp77yJ44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXHJcbiAgICogY2xhc3Mx44Gr5YCk44KS5oyH5a6a44GX44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXHJcbiAgICog44KC44GXY2xhc3My44Gu44G/5oyH5a6a44GX44Gf44GE5aC05ZCI44GvY2xhc3Mx44GrbnVsbOOCkuaMh+WumuOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog5L6L77yaSkstMTAw44GuQkxBQ0vjga7llYblk4HnlLvlg4/jgpJcclxuICAgKiDjgZnjgbnjgabjga7jgrXjgqTjgrrvvIhTLE0sTCxYTCwyWEwsM1hMLDRYTOKApu+8ieOBq+mWoumAo+S7mOOBkeOCi+WgtOWQiFxyXG4gICAqIHNldEltYWdlKCB1cGxvYWRJZCwgJ0pLLTEwMCcsICdCTEFDSycgKTtcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB1cGxvYWRJZCDkuIDlm57jga7jgqLjg4Pjg5fjg63jg7zjg4nnlLvlg4/jgpLmnZ/jga3jgabjgYTjgotJROOAgm1ldGVvcuODh+ODvOOCv+ODmeODvOOCueOAgVVwbG9hZHPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjg4njgq3jg6Xjg6Hjg7Pjg4jjga51cGxvYWRJZOODl+ODreODkeODhuOCo1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgc2V0SW1hZ2UgKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44Gu5oOF5aCx5Y+W5b6XXHJcbiAgICBsZXQgaW1hZ2VzID0gVXBsb2Fkcy5maW5kKHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkXHJcbiAgICB9KS5mZXRjaCgpLm1hcCgodikgPT4gdi51cGxvYWRlZEZpbGVOYW1lKVxyXG5cclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlciwge1xyXG4gICAgICAgICRwdXNoOiB7XHJcbiAgICAgICAgICBpbWFnZXM6IHtcclxuICAgICAgICAgICAgJGVhY2g6IGltYWdlc1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIOeZu+mMsuOBl+OBn+eUu+WDj+ODleOCoeOCpOODq+WQjeS4gOimp1xyXG4gICAgcmV0dXJuIGltYWdlc1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+eZu+mMsuOBleOCjOOBpuOBhOOCi+eUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKi9cclxuICBhc3luYyBjbGVhbkltYWdlIChtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge31cclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsXHJcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxXHJcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLCB7XHJcbiAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44Gu5ZWG5ZOB44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gu5bGe5oCn5Yil44Gu5ZWG5ZOB5oOF5aCx44KS6L+U44GZ44CCXHJcbiAgICpcclxuICAgKiDlvJXmlbDjgajjgZfjgablj5fjgZHlj5bjgotpdGVt44Gv5Lu75oSP44Gu5ZWG5ZOB5oOF5aCx44CCXHJcbiAgICogaXRlbeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBq+OBpOOBhOOBpuW/heimgeOBquaDheWgseOCkuaVtOeQhuOBl+i/lOOBmeOAglxyXG4gICAqXHJcbiAgICogcHJvamVjdOOBq+WPgueFp+OBl+OBn+OBhOWVhuWTgeaDheWgseODleOCo+ODvOODq+ODieOCkuWumue+qeOBmeOCi+OAglxyXG4gICAqIOODoeOCveODg+ODieOBruWRvOOBs+WHuuOBl+aZguOBq+W/heimgeOBq+W/nOOBmOOBpnByb2plY3TjgpLoqK3lrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS9leOBq+azqOebruOBl+OBpuWVhuWTgeOBrumWoumAo+aAp+OCkuaknOWHuuOBmeOCi+OBi+OBr+OAgeOBk+OBruODoeOCveODg+ODieWGheOBp+Wumue+qeOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGl0ZW1cclxuICAgKiBAcGFyYW0ge09iamVjdH0gcHJvamVjdFxyXG4gICAqL1xyXG4gIGFzeW5jIGdldFZhcmlhdGlvbiAoaXRlbSwgcHJvamVjdCkge1xyXG4gICAgLyoqXHJcbiAgICAgKiBhZ2dyZWdhdGlvbuioreWumlxyXG4gICAgICpcclxuICAgICAqIGxhYmVsOiDlsZ7mgKflkI3vvIjphY3pgIHmlrnms5XjgIHjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganvvIlcclxuICAgICAqIGN1cnJlbnQ6IOaMh+WumuOBleOCjOOBn+OCouOCpOODhuODoO+8iGl0ZW3vvInjgYzoqbLlvZPjgZnjgovpoIXnm65cclxuICAgICAqIHBvcmplY3Q6IOODkOODquOCqOODvOOCt+ODp+ODs+aknOe0ouOBruOCreODvOOBqOOBquOCi2l0ZW3lhoXjga7jg5XjgqPjg7zjg6vjg4nlkI0gJFvjg5XjgqPjg7zjg6vjg4nlkI1d5b2i5byPXHJcbiAgICAgKiBxdWVyeTogYWdncmVnYXRpb27lr77osaHjgajjgZnjgovjg4njgq3jg6Xjg6Hjg7Pjg4jjga7mpJzntKLmnaHku7ZcclxuICAgICAqL1xyXG4gICAgbGV0IHNldCA9IFt7XHJcbiAgICAgIGxhYmVsOiAn6YWN6YCB5pa55rOVJyxcclxuICAgICAgY3VycmVudDogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgIHZhbHVlOiAnJGRlbGl2ZXJ5J1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogaXRlbS5jbGFzczFfbmFtZSxcclxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRjbGFzczFfdmFsdWUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogaXRlbS5jbGFzczJfbmFtZSxcclxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczJfdmFsdWUsXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRjbGFzczJfdmFsdWUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgICAgY2xhc3MxX3ZhbHVlOiBpdGVtLmNsYXNzMV92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBdXHJcblxyXG4gICAgbGV0IGF0dHJzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBzIG9mIHNldCkge1xyXG4gICAgICBhdHRycy5wdXNoKHtcclxuICAgICAgICB2YXJpYXRpb25zOiBhd2FpdCB0aGlzLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFt7XHJcbiAgICAgICAgICAgICRtYXRjaDogT2JqZWN0LmFzc2lnbihzLnF1ZXJ5LCB7XHJcbiAgICAgICAgICAgICAgbW9kZWw6IGl0ZW0ubW9kZWxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICRwcm9qZWN0OiBPYmplY3QuYXNzaWduKHMucHJvamVjdCwgcHJvamVjdClcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICRzb3J0OiB7XHJcbiAgICAgICAgICAgICAgX2lkOiAxXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIF1cclxuICAgICAgICApLnRvQXJyYXkoKSxcclxuICAgICAgICBwcm9wczogc1xyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIGZvciAobGV0IGF0dHIgb2YgYXR0cnMpIHtcclxuICAgICAgZm9yIChsZXQgdiBvZiBhdHRyLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICB2LnN0b2NrID0gYXdhaXQgdGhpcy5nZXRTdG9jayh2Ll9pZClcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBhdHRyc1xyXG4gIH1cclxuXHJcbiAgLy8g44Oi44OH44Or44Kv44Op44K55b2i5byP44KS5L2c44KLXHJcbiAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gIGFzeW5jIGdldE1vZGVsQ2xhc3MgKGFyZykge1xyXG4gICAgbGV0IGl0ZW1cclxuICAgIC8vIGl0ZW0g44GM5paH5a2X5YiX44Gq44KJ44CBaXRlbeOBr+S7u+aEj+OBruOCquODluOCuOOCp+OCr+ODiElE44Gu5pyr5bC+44GL44KJ5Lu75oSP44Gu5qGB5pWw44GuMTbpgLLmlbBcclxuICAgIGlmICh0eXBlb2YgYXJnID09PSAnc3RyaW5nJykge1xyXG4gICAgICBsZXQgZXhwID0gbmV3IFJlZ0V4cChgJHthcmd9JGApXHJcbiAgICAgIGxldCBjdXIgPSB0aGlzLkl0ZW1zLmZpbmQoe30sIHtcclxuICAgICAgICBwcm9qZWN0aW9uOiB7XHJcbiAgICAgICAgICBtb2RlbDogMSxcclxuICAgICAgICAgIGNsYXNzMV92YWx1ZTogMSxcclxuICAgICAgICAgIGNsYXNzMl92YWx1ZTogMVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICAgIHdoaWxlICgxKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgICAgICBsZXQgbWF0Y2ggPSBhd2FpdCBpdGVtLl9pZC50b0hleFN0cmluZygpLm1hdGNoKGV4cClcclxuICAgICAgICAgIGlmIChtYXRjaCkge1xyXG4gICAgICAgICAgICBicmVha1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIC8vIOipsuW9k+OBmeOCi2l0ZW3jg4fjg7zjgr/jgYzjgarjgYRcclxuICAgICAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICAgICAgICByZXR1cm4gYXJnXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpdGVtID0gYXJnXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuICAgIHJldHVybiBtb2RlbENsYXNzLmpvaW4oJy8nKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlMyAoY3JlYXRvcklkLCBpdGVtKSB7XHJcbiAgICAvLyDlgKTlpInmj5tcclxuICAgIGxldCBjb252RGVsaXYgPSAoZGVsaXZlcnkpID0+IGRlbGl2ZXJ5ID09PSAn44KG44GG44OR44Kx44OD44OIJyA/ICfjg53jgrnjg4jmipXlh70nIDogZGVsaXZlcnlcclxuXHJcbiAgICAvLyBwcm9kdWN0X2lkXHJcbiAgICBsZXQgcHJvZHVjdElkID0gbnVsbFxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG5cclxuICAgIC8vIOS4i+iomOOBruW9ouW8j+OCkuS9nOOCi1xyXG4gICAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuXHJcbiAgICAvLyDllYblk4HnqK7liKXjgpLlibLjgorlvZPjgabjgotcclxuICAgIGxldCBwcm9kdWN0VHlwZUlkXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDJcclxuICAgICAgICBicmVha1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCB0YWdzID0gW11cclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeWIpemAgeaWmeOCkuioreWumuOBmeOCi1xyXG4gICAgbGV0IGRlbGl2ZXJ5RmVlID0gbnVsbFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBudWxsXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICBkZWxpdmVyeUZlZSA9IDI0MFxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy9cclxuICAgIC8vIOmhp+WuouWQkeOBkeODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgemBuOaKnuapn+iDveOBruWun+ijhVxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6ICckbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJ1xyXG4gICAgfSlcclxuXHJcbiAgICAvLyBIVE1MIOODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgeOBlOOBqOOBruODquODs+OCr+S7mOOBjeODnOOCv+ODs+OCkuihqOekuuOBmeOCi1xyXG5cclxuICAgIC8vIOWApOOBruWkieaPm1xyXG4gICAgYXR0cnMgPSBhdHRycy5tYXAoXHJcbiAgICAgIChhdHRyKSA9PiB7XHJcbiAgICAgICAgYXR0ci5wcm9wcy5jdXJyZW50ID0gY29udkRlbGl2KGF0dHIucHJvcHMuY3VycmVudClcclxuICAgICAgICBhdHRyLnZhcmlhdGlvbnMgPSBhdHRyLnZhcmlhdGlvbnMubWFwKFxyXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xyXG4gICAgICAgICAgICB2YXJpYXRpb24udmFsdWUgPSBjb252RGVsaXYodmFyaWF0aW9uLnZhbHVlKVxyXG4gICAgICAgICAgICByZXR1cm4gdmFyaWF0aW9uXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIHJldHVybiBhdHRyXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBIVE1M55Sf5oiQXHJcbiAgICBsZXQgdmFyaWF0aW9uSHRtbCA9XHJcbiAgICAgIGF0dHJzLm1hcChcclxuICAgICAgICAoYXR0cikgPT5cclxuICAgICAgICAgICc8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWZsdWlkXCI+JyArXHJcbiAgICAgICAgYDxkaXYgY2xhc3M9XCJyb3dcIj5gICtcclxuICAgICAgICBgPGRpdiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLWJsb2NrIGJ0bi14c1wiPmAgK1xyXG4gICAgICAgIGA8c3Ryb25nPiR7YXR0ci5wcm9wcy5sYWJlbH08L3N0cm9uZz5gICtcclxuICAgICAgICBgPC9kaXY+YCArXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgaWYgKGF0dHIucHJvcHMuY3VycmVudCA9PT0gdmFyaWF0aW9uLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgLy8g6KGo56S65Lit44Gu5ZWG5ZOB44Oc44K/44OzXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zdWNjZXNzIGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj48c3Ryb25nPiR7dmFyaWF0aW9uLnZhbHVlfTwvc3Ryb25nPjwvYnV0dG9uPmBcclxuICAgICAgICAgICAgfSBlbHNlXHJcbiAgICAgICAgICAgIGlmICh2YXJpYXRpb24uc3RvY2sgPiAwKSB7XHJcbiAgICAgICAgICAgICAgLy8g6LKp5aOy5Y+v6IO95ZWG5ZOB44Gu44Oc44K/44OzXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YSBocmVmPVwiL3Byb2R1Y3RzL2RldGFpbC8ke3ZhcmlhdGlvbi5wcm9kdWN0X2lkfVwiPjxidXR0b24gY2xhc3M9XCJidG4gYnRuLWRlZmF1bHQgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPiR7dmFyaWF0aW9uLnZhbHVlfTwvYnV0dG9uPjwvYT5gXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgLy8g6LKp5aOy5LiN5Y+v6IO95ZWG5ZOB44Gu44Oc44K/44Oz77yI5Zyo5bqr44Gq44GX77yJXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgZGF0YS10b2dnbGU9XCJ0b29sdGlwXCIgdGl0bGU9XCLlnKjluqvjgYzjgZTjgZbjgYTjgb7jgZvjgpNcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj5gXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApLmpvaW4oJycpICtcclxuICAgICAgICAnPC9kaXY+JyArXHJcbiAgICAgICAgJzwvZGl2PidcclxuICAgICAgKS5qb2luKCcnKVxyXG5cclxuICAgIGxldCBkZXNjcmlwdGlvbkRldGFpbCA9IGBcclxuICAgIDxzbWFsbD7igLsg6YWN6YCB5pa55rOV44O744Kr44Op44O844O744K144Kk44K644Gv5LiL6KiY44GL44KJ44GK6YG444Gz44GP44Gg44GV44GE44CCPC9zbWFsbD5cclxuICAgICR7dmFyaWF0aW9uSHRtbH1cclxuICAgIGBcclxuXHJcbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcclxuICAgIGxldCBkYXRhID0ge1xyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7Y29udkRlbGl2KGl0ZW0uZGVsaXZlcnkpfSAke2l0ZW0ubmFtZX0ke2l0ZW0uamFuX2NvZGUgPyAnICcgKyBpdGVtLmphbl9jb2RlIDogJyd9YCxcclxuICAgICAgZGVzY3JpcHRpb25fZGV0YWlsOiBkZXNjcmlwdGlvbkRldGFpbCxcclxuICAgICAgLy8gZnJlZV9hcmVhOiBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVGcmVlQXJlYShpdGVtKSxcclxuICAgICAgcHJvZHVjdF9jb2RlOiBtb2RlbENsYXNzLmpvaW4oJy8nKSxcclxuICAgICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAgIC8vIHByaWNlMDI6IGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZVByaWNlMDIoaXRlbSksXHJcbiAgICAgIC8vIGltYWdlczogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlSW1hZ2VzKGl0ZW0pLFxyXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RUeXBlSWQsXHJcbiAgICAgIHRhZ3M6IHRhZ3MsXHJcbiAgICAgIGRlbGl2ZXJ5X2ZlZTogZGVsaXZlcnlGZWVcclxuICAgIH1cclxuXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZUZyZWVBcmVhKGl0ZW0pKVxyXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyKGl0ZW0pKVxyXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVJbWFnZXMoaXRlbSkpXHJcblxyXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBpdGVtLm1hbGwuc2hhcmFrdVNob3ApXHJcblxyXG4gICAgcmV0dXJuIGRhdGFcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVGcmVlQXJlYSAoaXRlbSkge1xyXG4gICAgbGV0IGZyZWVBcmVhID0gJydcclxuICAgIC8vIOWVhuWTgeaDheWgseODhuOCreOCueODiOOCkuiomOi8ieOBmeOCi1xyXG4gICAgZnJlZUFyZWEgKz0gaXRlbS5kZXNjcmlwdGlvblxyXG4gICAgLy8gMueVquebruS7pemZjeOBrueUu+WDj+OCkuODleODquODvOOCqOODquOCouOBq+iomOi8ieOBmeOCi1xyXG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBpdGVtLmltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBmcmVlQXJlYSArPSBgPGltZyBzcmM9XCIvdXBsb2FkL3NhdmVfaW1hZ2UvJHtpdGVtLmltYWdlc1tpXX1cIj48YnI+YFxyXG4gICAgfVxyXG4gICAgLy8g5oOF5aCx44Gu44Kv44Oq44KiXHJcbiAgICBmcmVlQXJlYSArPSAnICdcclxuICAgIHJldHVybiB7ZnJlZV9hcmVhOiBmcmVlQXJlYX1cclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyIChpdGVtKSB7XHJcbiAgICAvLyDkvqHmoLzjgpLov5TjgZlcclxuICAgIHJldHVybiB7cHJpY2UwMjogaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByaWNlfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlM2NyZWF0ZUltYWdlcyAoaXRlbSkge1xyXG4gICAgLy8g55S75YOP44Oq44K544OI44Gu44GG44GhMeOBpOOCgeOBoOOBkeOCkui/lOOBmVxyXG4gICAgbGV0IGFyciA9IHR5cGVvZiBpdGVtLmltYWdlc1swXSA9PT0gJ3VuZGVmaW5lZCcgPyBbXSA6IFsgaXRlbS5pbWFnZXNbMF0gXVxyXG4gICAgcmV0dXJuIHsgaW1hZ2VzOiBhcnIgfVxyXG4gIH1cclxuXHJcbiAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44G444Gu5aSJ5o+bXHJcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdCAoZGVmLCBpdGVtKSB7XHJcbiAgICBjb25zdCBpZExlbmd0aCA9IDIwXHJcbiAgICBjb25zdCB0aXRsZUxlbmd0aCA9IDEzMFxyXG5cclxuICAgIGxldCB5YXVjdCA9IHt9XHJcbiAgICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjga7liJ3mnJ/lgKTvvIjjgobjgYbjg5HjgrHjg4Pjg4jjg7vlroXphY3kvr/jgafnlbDjgarjgovvvIlcclxuICAgIHlhdWN0ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkZWZbaXRlbS5kZWxpdmVyeV0pKVxyXG5cclxuICAgIC8vIOeUu+WDj+OBruiomOi/sFxyXG4gICAgY29uc3QgaW1nUHJlZml4ID0gJ+eUu+WDjydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgeWF1Y3RbaW1nUHJlZml4ICsgKGkgKyAxKV0gPSBpdGVtLmltYWdlc1tpXVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCv+OCpOODiOODq1xyXG4gICAgeWF1Y3RbJ+OCq+ODhuOCtOODqiddID0gaXRlbS5tYWxsLnlhdWN0LmNhdGVnb3J5XHJcbiAgICB5YXVjdFsn44K/44Kk44OI44OrJ10gPSBUZXh0VXRpbC5zdWJzdHI4KGAke2F3YWl0IHRoaXMuZ2V0TW9kZWxDbGFzcyhpdGVtKX0gJHtpdGVtLmRlbGl2ZXJ5fSAke2l0ZW0ubmFtZX1gLCB0aXRsZUxlbmd0aClcclxuICAgIHlhdWN0Wyfplovlp4vkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfljbPmsbrkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfnrqHnkIbnlarlj7cnXSA9IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkuc2xpY2UoLWlkTGVuZ3RoKVxyXG4gICAgeWF1Y3RbJ+iqrOaYjiddID0gaXRlbS5kZXNjcmlwdGlvblxyXG4gICAgeWF1Y3RbJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXSA9IGl0ZW0uamFuX2NvZGVcclxuXHJcbiAgICByZXR1cm4geWF1Y3RcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtV293bWFDcmVhdGVEZWxpdmVyeU1ldGhvZCAoaXRlbUNvZGUpIHtcclxuICAgIGxldCBpZCA9ICdtYWxsLndvd21hLml0ZW1Db2RlJ1xyXG4gICAgbGV0IHNldCA9ICdkZWxpdmVyeSdcclxuICAgIGxldCBtZXRyaWNzID0ge1xyXG4gICAgICAn44KG44GG44OR44Kx44OD44OIJzogWydQb3N0J10sXHJcbiAgICAgICflroXphY3kvr8nOiBbJ1lVLVBhY2snLCAnS2FuZ2Fyb28nXVxyXG4gICAgfVxyXG4gICAgLy8gZGVsaXZlcnlNZXRob2RTZXFcclxuXHJcbiAgICBsZXQgYWdnciA9IGF3YWl0IHRoaXMuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgIFtpZF06IGl0ZW1Db2RlXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgX2lkOiBgJCR7aWR9YCxcclxuICAgICAgICAgICAgW3NldF06IHsgJGFkZFRvU2V0OiBgJCR7c2V0fWAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgJHByb2plY3Q6IHtcclxuICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnLFxyXG4gICAgICAgICAgICBbc2V0XTogYCQke3NldH1gXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICBdXHJcbiAgICApLnRvQXJyYXkoKVxyXG5cclxuICAgIGxldCBhY2NlcHREZWxpdiA9IFtdXHJcbiAgICBmb3IgKGxldCBkZWwgb2YgYWdnclswXS5kZWxpdmVyeSkge1xyXG4gICAgICBhY2NlcHREZWxpdiA9IGFjY2VwdERlbGl2LmNvbmNhdChtZXRyaWNzW2Ake2RlbH1gXSlcclxuICAgIH1cclxuICAgIGxldCBkZWxpdmVyeU1ldGhvZCA9IG5ldyBBcnJheSg1KVxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkZWxpdmVyeU1ldGhvZC5sZW5ndGg7IGkrKykge1xyXG4gICAgICBsZXQgaWQgPSB0eXBlb2YgYWNjZXB0RGVsaXZbaV0gPT09ICd1bmRlZmluZWQnID8gJ05VTEwnIDogYWNjZXB0RGVsaXZbaV1cclxuICAgICAgZGVsaXZlcnlNZXRob2RbaV0gPSB7ZGVsaXZlcnlNZXRob2RTZXE6IGkgKyAxLCBkZWxpdmVyeU1ldGhvZElkOiBpZH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge2RlbGl2ZXJ5TWV0aG9kOiBkZWxpdmVyeU1ldGhvZH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5pbXBvcnQgeyBqc29uMnhtbCB9IGZyb20gJ3htbC1qcydcclxuaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuLi91dGlsL2Vycm9yJ1xyXG5cclxuY29uc3QgQkFTRV9VUkkgPSAnaHR0cHM6Ly9hcGkubWFuYWdlci53b3dtYS5qcC93bXNob3BhcGknXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBXb3dtYUFwaSB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHNob3BJZCkge1xyXG4gICAgdGhpcy5wbHVnID0gcGx1Z1xyXG4gICAgdGhpcy5zaG9wSWQgPSBzaG9wSWRcclxuICB9XHJcblxyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG4gIGFzeW5jIHVwZGF0ZUl0ZW0gKHVwZGF0ZUl0ZW0pIHtcclxuICAgIGxldCByZXF1ZXN0ID0gYDxyZXF1ZXN0PjxzaG9wSWQ+JHt0aGlzLnNob3BJZH08L3Nob3BJZD48dXBkYXRlSXRlbT4ke2pzb24yeG1sKHVwZGF0ZUl0ZW0sIHtjb21wYWN0OiB0cnVlfSl9PC91cGRhdGVJdGVtPjwvcmVxdWVzdD5gXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5yZXF1ZXN0UG9zdChcclxuICAgICAgICAndXBkYXRlSXRlbUluZm8nLFxyXG4gICAgICAgIHJlcXVlc3RcclxuICAgICAgKVxyXG4gICAgICByZXR1cm4ge3Jlc3BvbnNlOiByZXMsIHJlcXVlc3RYTUw6IHJlcXVlc3R9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIHRocm93IE9iamVjdC5hc3NpZ24odXRpbEVycm9yLnBhcnNlKGUpLCB7cmVxdWVzdFhNTDogcmVxdWVzdH0pXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyByZXF1ZXN0UG9zdCAobWV0aG9kLCBib2R5KSB7XHJcbiAgICAvLyDmjqXntprjgqrjg5fjgrfjg6fjg7Pjga7kvZzmiJBcclxuICAgIGxldCBhcGlSZXF1ZXN0ID0ge1xyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgdXJpOiBgJHtCQVNFX1VSSX0vJHttZXRob2R9YCxcclxuICAgICAgYm9keTogYm9keVxyXG4gICAgfVxyXG4gICAgLy8g5YWx6YCa44Gu5o6l57aa6Kit5a6a44Go57WQ5ZCI44GZ44KLXHJcbiAgICBPYmplY3QuYXNzaWduKGFwaVJlcXVlc3QsIHRoaXMucGx1ZylcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgIGxldCByZXMgPSBhd2FpdCByZXF1ZXN0KGFwaVJlcXVlc3QpXHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHN0b2NrVXBkYXRlSXRlbSkge1xyXG4gICAgLy8g5o6l57aa44Kq44OX44K344On44Oz44Gu5L2c5oiQXHJcbiAgICBsZXQgYXBpUmVxdWVzdCA9IHtcclxuICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgIHVyaTogYCR7QkFTRV9VUkl9L3VwZGF0ZVN0b2NrYFxyXG4gICAgfVxyXG4gICAgLy8g5YWx6YCa44Gu5o6l57aa6Kit5a6a44Go57WQ5ZCI44GZ44KLXHJcbiAgICBPYmplY3QuYXNzaWduKGFwaVJlcXVlc3QsIHRoaXMucGx1ZylcclxuXHJcbiAgICBhcGlSZXF1ZXN0LmJvZHkgPSBhd2FpdCB0aGlzLnVwZGF0ZVN0b2NrQ3JlYXRlUmVxdWVzdEJvZHkoc3RvY2tVcGRhdGVJdGVtKVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3QoYXBpUmVxdWVzdClcclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9ja0NyZWF0ZVJlcXVlc3RCb2R5IChzdG9ja1VwZGF0ZUl0ZW0pIHtcclxuICAgIC8vXHJcbiAgICAvLyBzdG9ja1VwZGF0ZUl0ZW0gPVxyXG4gICAgLy8gW1xyXG4gICAgLy8gICB7XHJcbiAgICAvLyAgICAgaXRlbUNvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgIHZhcmlhdGlvbnM6IFtcclxuICAgIC8vICAgICAgICB7XHJcbiAgICAvLyAgICAgICAgICBjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgICAgICAgc3RvY2s6IDxOdW1iZXI+XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgIF1cclxuICAgIC8vICAgfVxyXG4gICAgLy8gXVxyXG5cclxuICAgIGxldCBzdG9ja1VwZGF0ZUl0ZW1YTUwgPSAnJ1xyXG5cclxuICAgIGZvciAobGV0IGl0ZW0gb2Ygc3RvY2tVcGRhdGVJdGVtKSB7XHJcbiAgICAgIC8vIOWApOOBruODgeOCp+ODg+OCr1xyXG4gICAgICBmb3IgKGxldCBlIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgIC8vIOWcqOW6q+aVsOOBruS4iumZkDEwMFxyXG4gICAgICAgIGlmIChlLnN0b2NrID4gMTAwKSBlLnN0b2NrID0gMTAwXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrVXBkYXRlSXRlbT4nXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPGl0ZW1Db2RlPiR7aXRlbS5pdGVtQ29kZX08L2l0ZW1Db2RlPmBcclxuXHJcbiAgICAgIC8vIOWVhuWTgeWcqOW6q+eoruWIpeOCkuaMr+OCiuWIhuOBkVxyXG4gICAgICAvLyAxIC0+IOmAmuW4uOWVhuWTgVxyXG4gICAgICAvLyAyIC0+IOmBuOaKnuiCouWIpeWcqOW6q1xyXG5cclxuICAgICAgbGV0IHZhcjAgPSBpdGVtLnZhcmlhdGlvbnNbMF1cclxuICAgICAgaWYgKHZhcjAuY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGUgPT09ICcnICYmIHZhcjAuY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlID09PSAnJykge1xyXG4gICAgICAgIC8vIOmAmuW4uOWVhuWTgVxyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrU2VnbWVudD4xPC9zdG9ja1NlZ21lbnQ+J1xyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPHN0b2NrQ291bnQ+JHt2YXIwLnN0b2NrfTwvc3RvY2tDb3VudD5gXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8g6YG45oqe6IKi5Yil5Zyo5bqrXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tTZWdtZW50PjI8L3N0b2NrU2VnbWVudD4nXHJcblxyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIGZvciAobGV0IHZhcmlhdGlvbiBvZiBpdGVtLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICAgIC8vIOWcqOW6q+ioreWumuOCv+OCsOOBruWQjeWJjeOCkuW3ruOBl+abv+OBiOOCi1xyXG4gICAgICAgICAgdmFyaWF0aW9uLmNob2ljZXNTdG9ja0NvdW50ID0gdmFyaWF0aW9uLnN0b2NrXHJcbiAgICAgICAgICBkZWxldGUgdmFyaWF0aW9uLnN0b2NrXHJcblxyXG4gICAgICAgICAgLy8geG1s44KS5qeL5oiQ44GZ44KLXHJcbiAgICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxjaG9pY2VzU3RvY2tzPidcclxuICAgICAgICAgIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyh2YXJpYXRpb24pKSB7XHJcbiAgICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPCR7a2V5fT4ke3ZhcmlhdGlvbltrZXldfTwvJHtrZXl9PmBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPC9jaG9pY2VzU3RvY2tzPidcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPC9zdG9ja1VwZGF0ZUl0ZW0+J1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OBruS9nOaIkFxyXG4gICAgbGV0IGFwaVJlcXVlc3RCb2R5ID0gYFxyXG4gICAgPHJlcXVlc3Q+XHJcbiAgICA8c2hvcElkPiR7dGhpcy5zaG9wSWR9PC9zaG9wSWQ+XHJcbiAgICAke3N0b2NrVXBkYXRlSXRlbVhNTH1cclxuICAgIDwvcmVxdWVzdD5cclxuICAgIGBcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqPjgpLov5TjgZlcclxuICAgIHJldHVybiBhcGlSZXF1ZXN0Qm9keVxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyB1dGlsRXJyb3Ige1xyXG4gIHN0YXRpYyBwYXJzZSAoZSkge1xyXG4gICAgbGV0IHJlcyA9IHt9XHJcblxyXG4gICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICByZXMubWVzc2FnZSA9IGUubWVzc2FnZVxyXG4gICAgICByZXMubmFtZSA9IGUubmFtZVxyXG4gICAgICByZXMuZmlsZU5hbWUgPSBlLmZpbGVOYW1lXHJcbiAgICAgIHJlcy5saW5lTnVtYmVyID0gZS5saW5lTnVtYmVyXHJcbiAgICAgIHJlcy5jb2x1bW5OdW1iZXIgPSBlLmNvbHVtbk51bWJlclxyXG4gICAgICByZXMuc3RhY2sgPSBlLnN0YWNrXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXMgPSBlXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInXHJcblxyXG5leHBvcnQgY2xhc3MgTW9uZ29Db2xsZWN0aW9uIHtcclxuICBzdGF0aWMgYXN5bmMgZ2V0IChwbHVnLCBjb2xsZWN0aW9uKSB7XHJcbiAgICBsZXQgY2xpZW50ID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSlcclxuICAgIGxldCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKVxyXG4gICAgcmV0dXJuIGRiLmNvbGxlY3Rpb24oY29sbGVjdGlvbilcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IG15c3FsIGZyb20gJ215c3FsJ1xyXG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE15U1FMIHtcclxuICBjb25zdHJ1Y3RvciAocHJvZmlsZSkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz44OX44O844Or5Yid5pyf5YyWXHJcbiAgICB0aGlzLnBvb2wgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGUpXHJcblxyXG4gICAgLy8g6KSH5pWw6KGM44K544OG44O844OI44Oh44Oz44OI5a++5b+cXHJcbiAgICBsZXQgcHJvZmlsZU11bHRpID0ge211bHRpcGxlU3RhdGVtZW50czogdHJ1ZX1cclxuICAgIE9iamVjdC5hc3NpZ24ocHJvZmlsZU11bHRpLCBwcm9maWxlKVxyXG4gICAgdGhpcy5wb29sTXVsdGkgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGVNdWx0aSlcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmb3JtYXREYXRlIChkYXRlKSB7XHJcbiAgICByZXR1cm4gbW9tZW50KGRhdGUpLmZvcm1hdCgpLnN1YnN0cmluZygwLCAxOSkucmVwbGFjZSgnVCcsICcgJylcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNxbFxyXG4gICAqL1xyXG4gIHF1ZXJ5IChzcWwpIHtcclxuICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+eiuueri1xyXG4gICAgLy8gbGV0IGNvbiA9IGF3YWl0IHRoaXMuZ2V0Q29uKCk7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxyXG4gICAgICAudGhlbihcclxuICAgICAgICAoY29uKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcclxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsLCAoZSwgcmVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7PplovmlL5cclxuICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgIGlmIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgIHJlamVjdChlKVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHJlc29sdmUocmVzKVxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZVxyXG4gICAgICB9KVxyXG4gIH07XHJcblxyXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0XyAoc3FsKSB7XHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzLmluc2VydElkXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB0YWJsZVxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvOOAgW51bGzjgIFqYXZhc2NyaXB0LT5teXNxbOaXpeS7mOWkieaPm+OBq+OCguWvvuW/nFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhU3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xyXG4gICAqL1xyXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0ICh0YWJsZSwgZGF0YSA9IHt9LCBkYXRhU3FsID0ge30pIHtcclxuICAgIC8vIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XHJcbiAgICAvLyByZXR1cm4gcmVzLmluc2VydElkO1xyXG5cclxuICAgIGxldCBzcWwgPSBgSU5TRVJUIElOVE8gJHt0YWJsZX0gYFxyXG5cclxuICAgIGxldCBtYXAgPSBuZXcgTWFwKClcclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YSkpIHtcclxuICAgICAgaWYgKGRhdGFba10gPT09IG51bGwpIHtcclxuICAgICAgICBtYXAuc2V0KGssICdOVUxMJylcclxuICAgICAgfSBlbHNlIGlmIChkYXRhW2tdLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgIG1hcC5zZXQoaywgYFwiJHtNeVNRTC5mb3JtYXREYXRlKGRhdGFba10pfVwiYClcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBtYXAuc2V0KGssIGAke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGFTcWwpKSB7XHJcbiAgICAgIG1hcC5zZXQoaywgZGF0YVNxbFtrXSA9PT0gbnVsbCA/ICdOVUxMJyA6IGRhdGFTcWxba10pXHJcbiAgICB9XHJcblxyXG4gICAgc3FsICs9IGAoICR7Wy4uLm1hcC5rZXlzKCldLmpvaW4oJywnKX0gKSBgXHJcblxyXG4gICAgc3FsICs9IGBWQUxVRVMoICR7Wy4uLm1hcC52YWx1ZXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzLmluc2VydElkXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB0YWJsZVxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBmaWx0ZXIgU1FMIFVQREFUReOCueODhuODvOODiOODoeODs+ODiOOBrldIRVJF5Y+lXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O8XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlVcGRhdGUgKHRhYmxlLCBmaWx0ZXIsIGRhdGEsIGRhdGFTcWwpIHtcclxuICAgIGxldCBzcWwgPSBgVVBEQVRFICR7dGFibGV9IFNFVCBgXHJcblxyXG4gICAgbGV0IHVwZGF0ZXMgPSBbXVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtteXNxbC5lc2NhcGUoZGF0YVtrXSl9YClcclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgdXBkYXRlcy5wdXNoKGAke2t9PSR7ZGF0YVNxbFtrXX1gKVxyXG4gICAgfVxyXG4gICAgc3FsICs9IHVwZGF0ZXMuam9pbignLCcpXHJcblxyXG4gICAgc3FsICs9IGAgV0hFUkUgJHtmaWx0ZXJ9IGBcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICAvLyBlbmFibGUgdG8gdXNlIG11bHRpcGxlIHN0YXRlbWVudHNcclxuICBhc3luYyBxdWVyeU11bHRpIChzcWwpIHtcclxuICAgIGxldCBwb29sU3dhcCA9IHRoaXMucG9vbFxyXG4gICAgdGhpcy5wb29sID0gdGhpcy5wb29sTXVsdGlcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgICAgcmV0dXJuIHJlc1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgdGhpcy5wb29sID0gcG9vbFN3YXBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHN0YXJ0VHJhbnNhY3Rpb24gKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgU1RBUlQgVFJBTlNBQ1RJT047YClcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbW1pdCAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBDT01NSVQ7YClcclxuICB9XHJcblxyXG4gIGFzeW5jIHJvbGxiYWNrICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYFJPTExCQUNLO2ApXHJcbiAgfVxyXG5cclxuICBzdHJlYW1pbmdRdWVyeSAoc3FsLCBvblJlc3VsdCA9IChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gKGUpID0+IHt9KSB7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxyXG4gICAgICAudGhlbihcclxuICAgICAgICAoY29uKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgICAgIGFzeW5jIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcclxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsKVxyXG4gICAgICAgICAgICAgICAgLm9uKCdyZXN1bHQnLFxyXG4gICAgICAgICAgICAgICAgICAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uLnBhdXNlKClcclxuICAgICAgICAgICAgICAgICAgICBvblJlc3VsdChyZWNvcmQpXHJcbiAgICAgICAgICAgICAgICAgICAgY29uLnJlc3VtZSgpXHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2Vycm9yJywgKGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgb25FcnJvcihlKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZW5kJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpXHJcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUoKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfVxyXG5cclxuICBnZXRDb24gKCkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgLy8g44OX44O844Or44GL44KJ44Gu44Kz44ON44Kv44K344On44Oz542y5b6XXHJcbiAgICAgICAgdGhpcy5wb29sLmdldENvbm5lY3Rpb24oKGUsIGNvbikgPT4ge1xyXG4gICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXNvbHZlKGNvbilcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC5jYXRjaChcclxuICAgICAgICAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gIH07XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGFja2V0IHtcclxuICBjb25zdHJ1Y3RvciAocGFja2V0U2l6ZSkge1xyXG4gICAgdGhpcy5wYWNrZXRTaXplID0gcGFja2V0U2l6ZVxyXG4gICAgdGhpcy5vblBhY2tldFN0YXJ0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldCA9IG51bGxcclxuICAgIHRoaXMub25QYWNrZXRFbmQgPSBudWxsXHJcbiAgICB0aGlzLmNvdW50ID0gMFxyXG4gICAgdGhpcy5wYWNrZXRDb3VudCA9IDBcclxuICB9XHJcblxyXG4gIGFzeW5jIHN1Ym1pdCAoYXJnKSB7XHJcbiAgICAvLyBwYWNrZXRTaXpl44Gu5Zue5pWw44GU44Go44Gr44CB5Yid5pyf5YyW44KS5ZG844Gz5Ye644GZXHJcbiAgICBpZiAodGhpcy5jb3VudCAlIHRoaXMucGFja2V0U2l6ZSA9PT0gMCkge1xyXG4gICAgICBpZiAodGhpcy5vblBhY2tldFN0YXJ0KSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5vblBhY2tldFN0YXJ0KHRoaXMucGFja2V0Q291bnQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLm9uUGFja2V0KSB7XHJcbiAgICAgIGF3YWl0IHRoaXMub25QYWNrZXQoYXJnKVxyXG4gICAgfVxyXG4gICAgdGhpcy5jb3VudCsrXHJcbiAgICAvLyBwYWNrZXRTaXpl44Gu5Zue5pWw44GU44Go44Gr44CB57WC5LqG5Yem55CG44KS5ZG844Gz5Ye644GZXHJcbiAgICBpZiAodGhpcy5jb3VudCAlIHRoaXMucGFja2V0U2l6ZSA9PT0gMCkge1xyXG4gICAgICB0aGlzLmNsb3NlKClcclxuICAgICAgdGhpcy5wYWNrZXRDb3VudCsrXHJcbiAgICB9XHJcbiAgfVxyXG4gIGNsb3NlICgpIHtcclxuICAgIGlmICh0aGlzLm9uUGFja2V0RW5kKSB7XHJcbiAgICAgIHRoaXMub25QYWNrZXRFbmQodGhpcy5wYWNrZXRDb3VudClcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuL2Vycm9yJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IHsgTG9ncyB9IGZyb20gJy4uL2NvbGxlY3Rpb24vbG9ncydcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZXBvcnQge1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMucmVjb3JkID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3JzID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3IgPSBudWxsXHJcbiAgfVxyXG5cclxuICAvLyBwcml2YXRlXHJcbiAgc2V0dXBJdGVyYXRvciAocGhhc2VJZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvciA9IG5ldyBJdGVyYXRvcihwaGFzZUlkKVxyXG4gICAgdGhpcy5pdGVyYXRvcnMucHVzaCh0aGlzLml0ZXJhdG9yKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGhhc2UgKG5hbWUgPSAnJywgZm4gPSBhc3luYyAoKSA9PiB7fSkge1xyXG4gICAgbGV0IHJlYyA9IHtcclxuICAgICAgcGhhc2VJZDogdW5pcWlkKClcclxuICAgIH1cclxuXHJcbiAgICB0aGlzLnNldHVwSXRlcmF0b3IocmVjLnBoYXNlSWQpXHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGZuKClcclxuXHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogcmVzXHJcbiAgICAgIH0pXHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHV0aWxFcnJvci5wYXJzZShlKVxyXG4gICAgICB9KVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgLy8g44Or44O844OX5Yem55CG44Gu44Os44Od44O844OI44KS5L2c5oiQXHJcbiAgICAgIGlmICh0aGlzLml0ZXJhdG9yLm1ldHJpYy50b3RhbCkge1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgICBpdGVyYXRvcjogdGhpcy5pdGVyYXRvci5tZXRyaWNcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICAgIC8vIOOCv+OCpOODoOOCueOCv+ODs+ODl1xyXG4gICAgICByZWMudGltZVN0YW1wID0gbmV3IERhdGUoKVxyXG4gICAgICAvLyDjg6zjg53jg7zjg4jjgpLjg4fjg7zjgr/jg5njg7zjgrnjgavoqJjpjLJcclxuICAgICAgTG9ncy5pbnNlcnQocmVjKVxyXG5cclxuICAgICAgLy8g5ZG844Gz5Ye644GX5YWD55So44Os44Od44O844OI44Gr6L+95YqgXHJcbiAgICAgIHRoaXMucmVjb3JkLnB1c2gocmVjKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLy8g44Kr44O844K944Or44KS44Or44O844OX44GX44CB5LiO44GI44KJ44KM44Gf6Zai5pWw44KS5a6f6KGMXHJcbiAgLy8g5ZG844Gz5Ye644GZ6Zai5pWw44Gu5byV5pWw44Gr44Gv44Kr44O844K944Or44GL44KJ5b6X44KJ44KM44Gf44OJ44Kt44Ol44Oh44Oz44OI44KS5rih44GZXHJcbiAgYXN5bmMgZm9yRWFjaE9uQ3Vyc29yIChjdXIsIGZuKSB7XHJcbiAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICBsZXQgZG9jID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICB0cnkge1xyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmbihkb2MpXHJcbiAgICAgICAgdGhpcy5pU3VjY2VzcyhyZXMpXHJcbiAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICB0aGlzLmlFcnJvcihlKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBjdXIuY2xvc2UoKVxyXG4gIH1cclxuXHJcbiAgaVN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5zdWNjZXNzKG5ld1JlY29yZClcclxuICB9XHJcblxyXG4gIGlFcnJvciAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLmVycm9yKHV0aWxFcnJvci5wYXJzZShuZXdSZWNvcmQpKVxyXG4gIH1cclxuXHJcbiAgZXJyb3JPY3VycmVkICgpIHtcclxuICAgIGxldCBpdGVFcnJvciA9IHRoaXMuaXRlcmF0b3JzLmZpbmQoZSA9PiBlLmVycm9yT2N1cnJlZCgpKVxyXG4gICAgbGV0IHBoYUVycm9yID0gZmFsc2VcclxuICAgIGZvciAobGV0IHJlYyBvZiB0aGlzLnJlY29yZCkge1xyXG4gICAgICBpZiAocmVjLnR5cGUgPT09ICdlcnJvcicpIHtcclxuICAgICAgICBwaGFFcnJvciA9IHRydWVcclxuICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXRlRXJyb3IgfHwgcGhhRXJyb3JcclxuICB9XHJcblxyXG4gIHB1Ymxpc2ggKCkge1xyXG4gICAgLy8g5ZG844Gz5Ye644GX5YWD44G444Os44Od44O844OIXHJcbiAgICBpZiAodGhpcy5lcnJvck9jdXJyZWQoKSkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKHRoaXMucmVjb3JkKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMucmVjb3JkXHJcbiAgfVxyXG59XHJcblxyXG5jbGFzcyBJdGVyYXRvciB7XHJcbiAgY29uc3RydWN0b3IgKHBoYXNlSWQpIHtcclxuICAgIHRoaXMubWV0cmljID0ge1xyXG4gICAgICB0b3RhbDogMCxcclxuICAgICAgc3VjY2VzczogMCxcclxuICAgICAgZXJyb3I6IDAsXHJcbiAgICAgIHBoYXNlSWQ6IHBoYXNlSWRcclxuICAgIH1cclxuICAgIHRoaXMubGFzdEVycm9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgc3VjY2VzcyAobmV3UmVjb3JkKSB7XHJcbiAgICBpZiAobmV3UmVjb3JkKSB7XHJcbiAgICAgIHRoaXMubG9nKG5ld1JlY29yZCwgdHJ1ZSlcclxuICAgIH1cclxuICAgIHRoaXMubWV0cmljLnN1Y2Nlc3MrK1xyXG4gICAgdGhpcy5tZXRyaWMudG90YWwrK1xyXG4gIH1cclxuXHJcbiAgZXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgLy8g55u05YmN44Go5ZCM44GY44Ko44Op44O844Gv55yB44GPXHJcbiAgICBpZiAoSlNPTi5zdHJpbmdpZnkodGhpcy5sYXN0RXJyb3IpICE9PSBKU09OLnN0cmluZ2lmeShuZXdSZWNvcmQpKSB7XHJcbiAgICAgIGlmIChuZXdSZWNvcmQgJiYgbmV3UmVjb3JkICE9PSB7fSAmJiBuZXdSZWNvcmQgIT09ICcnKSB7XHJcbiAgICAgICAgdGhpcy5sb2cobmV3UmVjb3JkLCBmYWxzZSlcclxuICAgICAgICB0aGlzLmxhc3RFcnJvciA9IG5ld1JlY29yZFxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICB0aGlzLm1ldHJpYy5lcnJvcisrXHJcbiAgICB0aGlzLm1ldHJpYy50b3RhbCsrXHJcbiAgfVxyXG5cclxuICBsb2cgKG5ld1JlY29yZCwgaXNTdWNjZXNzIC8qIHRydWUgPT4gc3VjY2VzcyBvciBmYWxzZSA9PiBlcnJvciAqLykge1xyXG4gICAgbGV0IHJlYyA9IHtcclxuICAgICAgc3VjY2VzczogaXNTdWNjZXNzLFxyXG4gICAgICBwaGFzZUlkOiB0aGlzLm1ldHJpYy5waGFzZUlkLFxyXG4gICAgICBtZXNzYWdlOiBuZXdSZWNvcmQsXHJcbiAgICAgIHRpbWVTdGFtcDogbmV3IERhdGUoKVxyXG4gICAgfVxyXG4gICAgTG9ncy5pbnNlcnQocmVjKVxyXG4gIH1cclxuXHJcbiAgZXJyb3JPY3VycmVkICgpIHtcclxuICAgIHJldHVybiB0aGlzLm1ldHJpYy5lcnJvclxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBUZXh0VXRpbCB7XHJcbiAgc3RhdGljIHN1YnN0cjggKHRleHQsIGxlbiwgdHJ1bmNhdGlvbikge1xyXG4gICAgaWYgKHRydW5jYXRpb24gPT09IHVuZGVmaW5lZCkgeyB0cnVuY2F0aW9uID0gJycgfVxyXG4gICAgdmFyIHRleHRBcnJheSA9IHRleHQuc3BsaXQoJycpXHJcbiAgICB2YXIgY291bnQgPSAwXHJcbiAgICB2YXIgc3RyID0gJydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGV4dEFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHZhciBuID0gZXNjYXBlKHRleHRBcnJheVtpXSlcclxuICAgICAgaWYgKG4ubGVuZ3RoIDwgNCkgY291bnQrK1xyXG4gICAgICBlbHNlIGNvdW50ICs9IDJcclxuICAgICAgaWYgKGNvdW50ID4gbGVuKSB7XHJcbiAgICAgICAgcmV0dXJuIHN0ciArIHRydW5jYXRpb25cclxuICAgICAgfVxyXG4gICAgICBzdHIgKz0gdGV4dC5jaGFyQXQoaSlcclxuICAgIH1cclxuICAgIHJldHVybiB0ZXh0XHJcbiAgfVxyXG59XHJcbiJdfQ==
