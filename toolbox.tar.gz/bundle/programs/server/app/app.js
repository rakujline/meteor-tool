var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/route/upload/image.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"_cubeup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cube/_cubeup.js                                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../../imports/core/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../../imports/core/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let tag = 'cubeup';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.item`](config) {
    return Promise.asyncApply(() => {
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('JLINE ENGINE からの取り込み', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'SAMPLE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              cubeItem = ItemController.itemCube3(item);
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(config.creator_id, cubeItem));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  },

  //
  // 画像更新
  [`${tag}.image`](config) {
    return Promise.asyncApply(() => {
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('JLINE ENGINE からの取り込み', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'SAMPLE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let res = Promise.await(api.productImageUpdate(config.creator_id, ItemController.itemCube3(item)));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"_cubex.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cube/_cubex.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../../imports/core/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 4);
let ItemController;
module.watch(require("../../imports/core/items"), {
  default(v) {
    ItemController = v;
  }

}, 5);
let tag = 'cubex';
Meteor.methods({
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // let mongoJline;
      // let Items;
      // await report.phase(
      //   'JLINE ENGINE への接続',
      //   async ()=>{
      //     let plug = config.sourceDB;
      //     mongoJline = await MongoClient.connect(plug.uri);
      //     Items = mongoJline.db(plug.database).collection(plug.collection);
      //   }
      // );

      let filter = new MongoDBFilter(config.sourceDB, config.profile);
      let targetDB = new MySQL(config.targetDB.cred);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('JLINE ENGINE からの取り込み', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'KOMINE_NOTEXISTS': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let insertRet = Promise.await(api.productCreate(config.creator_id, ItemController.itemCube3(item)));
              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRet.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cube/cubemig.js                                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 2);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 3);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 4);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let coupon_cd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let coupon_name = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discount_price = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: coupon_cd,
                coupon_type: 3,
                // 全商品
                coupon_name: coupon_name,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discount_price,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/jline/collection.js                                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug));
      return Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug));
      return Promise.await(coll.aggregate(query).toArray());
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/jline/items.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let ItemController;
module.watch(require("../../imports/core/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param  
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cube.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/core/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/core/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let tag = 'cube';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = ItemController.itemCube3(config.creator_id, item);
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = ItemController.itemCube3(config.creator_id, item);
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/tooltest.js                                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/main.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/collection/configs.js                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/collection/filters.js                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/collection/groups.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/collection/uploads.js                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"core":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/core/cube3api.js                                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 1);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creator_id = data.creator_id;
      let res = [];

      let tagon = tag => Promise.asyncApply(() => {
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creator_id
        })));
      });

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let product_id = data.product_id;
      let images = data.images;
      let creator_id = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${product_id}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        this.mysql_.queryInsert('dtb_product_image', {
          product_id: product_id,
          creator_id: creator_id,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        });
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let update_data = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, update_data, {
        update_date: 'NOW()'
      }); // dtb_product_class

      update_data = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      let res = this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, update_data, {
        update_date: 'NOW()'
      });
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creator_id = data.creator_id;
      let res = {};
      let update_data = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', update_data, {
        creator_id: creator_id,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      update_data = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', update_data, {
        creator_id: creator_id,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        delivery_fee: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creator_id,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/core/dbfilter.js                                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 2);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 3);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 4);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case "mysql":
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  // DB からデータを取得するプロセス
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    let instance;

    switch (plug.type) {
      case "mysql":
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error("invalid plug type");
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   * 
   * 
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters 
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== "undefined") {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      return Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find();

      while (Promise.await(cur.hasNext())) {
        let doc = Promise.await(cur.next());
        Promise.await(onResult(doc, context));
      }

      ;
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/core/items.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      plug.collection = 'items';
      this.Items = Promise.await(MongoCollection.get(Object.assign({
        collection: 'items'
      }, plug)));
      this.Products = Promise.await(MongoCollection.get(Object.assign({
        collection: 'products'
      }, plug)));
    });
  }

  getStock(item_id) {
    return Promise.asyncApply(() => {
      let project = Promise.await(this.Items.findOne({
        _id: item_id
      }, {
        projection: {
          'product': 1
        }
      }));
      let product_pack = project.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[[]]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let product_sku of product_pack) {
        let quantity_sku = 0;

        for (let product_id of product_sku) {
          let project = Promise.await(this.Products.findOne({
            _id: product_id
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stock_array = project.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stock_array) {
            quantity_sku += stock.quantity;
          }
        }

        quantities.push(quantity_sku);
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   * 
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   * 
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   * 
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   * 
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   * 
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   * 
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   * 
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }

  static itemCube3(creator_id, item) {
    return new itemCube3(creator_id, item);
  }

}

class itemCube3 {
  constructor(creator_id, item) {
    // product_id
    let product_id = 'NULL';

    if (item.sharakuShop) {
      product_id = item.sharakuShop.product_id;
    } // 下記の形式を作る
    // メーカーコード/属性1（カラーなど）/属性2（サイズなど）


    let modelClass = [];
    if (item.model) modelClass.push(item.model);
    if (item.class1_value) modelClass.push(item.class1_value);
    if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

    let product_type_id;

    switch (item.delivery) {
      case '宅配便':
        product_type_id = 1;
        break;

      case 'ゆうパケット':
        product_type_id = 2;
        break;

      default:
        product_type_id = 1;
        break;
    } // 商品タグを設定する


    let tags = [];

    switch (item.delivery) {
      case '宅配便':
        tags.push({
          tag: 4,
          set: 'on'
        }, {
          tag: 5,
          set: 'off'
        });
        break;

      case 'ゆうパケット':
        tags.push({
          tag: 5,
          set: 'on'
        }, {
          tag: 4,
          set: 'off'
        });
        break;
    } // 商品データを作る


    let data = {
      product_id: product_id,
      name: `${modelClass.join('/')} ${item.name} ${item.jan_code}`,
      description_detail: item.description,
      product_code: item.model,
      price01: item.retail_price,
      price02: item.sales_price,
      images: item.images,
      product_type_id: product_type_id,
      tags: tags
    };
    Object.assign(this, {
      creator_id: creator_id
    });
    Object.assign(this, data);
    Object.assign(this, item.mall.sharakuShop);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/util/mongo.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(plug.collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/util/mysql.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   * 
   * @param {String} sql 
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   * 
   * @param {String} table 
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} data_sql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, data_sql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `"${data[k]}"`);
        }
      }

      for (let k of Object.keys(data_sql)) {
        map.set(k, data_sql[k] === null ? 'NULL' : data_sql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   * 
   * @param {String} table 
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} data_sql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, data_sql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}="${data[k]}"`);
      }

      for (let k of Object.keys(data_sql)) {
        updates.push(`${k}=${data_sql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/util/report.js                                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  default: () => Report
});

class Report {
  constructor() {
    this.record = [];
    this.iterator = new Iterator();
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.iterator = new Iterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: e
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(newRecord);
  }

  errorOcurred() {
    let iteError = this.iterator.trace.error.total;
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    if (newRecord && newRecord !== {} && newRecord !== '') {
      this.trace.error.records.push(JSON.parse(newRecord));
    }

    this.trace.error.total++;
    this.total++;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/_cubeup.js");
require("/server/cube/_cubex.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvX2N1YmV1cC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvX2N1YmV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY3ViZS9jdWJlbWlnLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvamxpbmUvY29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2l0ZW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY3ViZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3Rvb2x0ZXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb3JlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvcmUvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29yZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL21vbmdvLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbXlzcWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9yZXBvcnQuanMiXSwibmFtZXMiOlsiZnMiLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJkZWZhdWx0IiwidiIsInVuaXFpZCIsIm11bHRpcGFydHkiLCJVcGxvYWRzIiwibXVsdGlwYXJ0eU1pZGRsZXdhcmUiLCJyb3V0ZSIsIldlYkFwcCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsInJlcSIsInJlc3AiLCJyZWFkZXIiLCJNZXRlb3IiLCJ3cmFwQXN5bmMiLCJyZWFkRmlsZSIsIndyaXRlciIsIndyaXRlRmlsZSIsInVwbG9hZElkIiwiZmlsZSIsImZpbGVzIiwiZGF0YSIsInBhdGgiLCJmaWxlbmFtZSIsInNhdmVQYXRoIiwiYm9keSIsImltYWdlZGlyIiwiZG9jIiwiY2xpZW50RmlsZU5hbWUiLCJuYW1lIiwidXBsb2FkZWRGaWxlTmFtZSIsImVyciIsImVycm9yIiwiaW5zZXJ0Iiwid3JpdGVIZWFkIiwiZW5kIiwiSlNPTiIsInN0cmluZ2lmeSIsInNhdmVEaXIiLCJSZXBvcnQiLCJNb25nb0RCRmlsdGVyIiwiQ3ViZTNBcGkiLCJNeVNRTCIsIkl0ZW1Db250cm9sbGVyIiwidGFnIiwibWV0aG9kcyIsImNvbmZpZyIsInJlcG9ydCIsImZpbHRlciIsIml0ZW1zREIiLCJwcm9maWxlIiwidGFyZ2V0REIiLCJjdWJlM0RCIiwiYXBpIiwicGhhc2UiLCJmb3JlYWNoIiwiaXRlbSIsImNvbnRleHQiLCJjb2wiLCJjb2xsZWN0aW9uIiwiY3ViZUl0ZW0iLCJpdGVtQ3ViZTMiLCJwcm9kdWN0VXBkYXRlIiwicHJvZHVjdFRhZ1VwZGF0ZSIsImNyZWF0b3JfaWQiLCJpU3VjY2VzcyIsImUiLCJpRXJyb3IiLCJwdWJsaXNoIiwicmVzIiwicHJvZHVjdEltYWdlVXBkYXRlIiwiTW9uZ29DbGllbnQiLCJzb3VyY2VEQiIsImNyZWQiLCJpbnNlcnRSZXQiLCJwcm9kdWN0Q3JlYXRlIiwidXBkYXRlIiwiX2lkIiwiJHNldCIsImNyeXB0byIsIkdyb3VwIiwiR3JvdXBGYWN0b3J5IiwiRmlsdGVyIiwic3JjRmlsdGVySWQiLCJ0ZXN0UXVlcnkiLCJkc3REYiIsImRzdCIsInF1ZXJ5IiwibW9iaWxlTnVsbCIsInJlY29yZCIsInNxbCIsImN1c3RvbWVyX2lkIiwic3RhdHVzIiwic2V4Iiwiam9iIiwiY291bnRyeV9pZCIsInByZWYiLCJuYW1lMDEiLCJuYW1lMDIiLCJrYW5hMDEiLCJrYW5hMDIiLCJjb21wYW55X25hbWUiLCJ6aXAwMSIsInppcDAyIiwiemlwY29kZSIsImFkZHIwMSIsImFkZHIwMiIsImVtYWlsIiwidGVsMDEiLCJ0ZWwwMiIsInRlbDAzIiwiZmF4MDEiLCJmYXgwMiIsImZheDAzIiwiYmlydGgiLCJwYXNzd29yZCIsInNhbHQiLCJzZWNyZXRfa2V5IiwiZmlyc3RfYnV5X2RhdGUiLCJsYXN0X2J1eV9kYXRlIiwiYnV5X3RpbWVzIiwiYnV5X3RvdGFsIiwibm90ZSIsImNyZWF0ZV9kYXRlIiwidXBkYXRlX2RhdGUiLCJkZWxfZmxnIiwicXVlcnlJbnNlcnQiLCJjdXN0b21lcl9hZGRyZXNzX2lkIiwiaWQiLCJtYWlsbWFnYV9mbGciLCJjb3Vwb25fY2QiLCJyYW5kb21CeXRlcyIsInRvU3RyaW5nIiwic3Vic3RyaW5nIiwiY291cG9uX25hbWUiLCJkaXNjb3VudF9wcmljZSIsInBvaW50IiwiY291cG9uX2lkIiwiY291cG9uX3R5cGUiLCJkaXNjb3VudF90eXBlIiwiY291cG9uX3VzZV90aW1lIiwiY291cG9uX3JlbGVhc2UiLCJkaXNjb3VudF9yYXRlIiwiZW5hYmxlX2ZsYWciLCJjb3Vwb25fbWVtYmVyIiwiY291cG9uX2xvd2VyX2xpbWl0IiwiYXZhaWxhYmxlX2Zyb21fZGF0ZSIsImF2YWlsYWJsZV90b19kYXRlIiwiZGIiLCJNb25nb0NvbGxlY3Rpb24iLCJwbHVnIiwicHJvamVjdGlvbiIsImNvbGwiLCJnZXQiLCJmaW5kIiwidG9BcnJheSIsImFnZ3JlZ2F0ZSIsIm1vZGVsIiwiY2xhc3MxIiwiY2xhc3MyIiwiaXRlbWNvbiIsImluaXQiLCJ1cGxvYWRlZCIsInNldEltYWdlIiwiY2xlYW5JbWFnZSIsImluc2VydFJlcyIsImV4cG9ydCIsIkNvbmZpZ3MiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJpZEdlbmVyYXRpb24iLCJzaWZ0IiwibW9iamVjdCIsIkdyb3VwQmFzZSIsIkZpbHRlcnMiLCJjb25zdHJ1Y3RvciIsImZpbHRlcklkIiwiZmluZE9uZSIsImdldFBsdWciLCJ0eXBlIiwibXlzcWwiLCJpbXBvcnQiLCJvblJlc3VsdCIsIm9uRXJyb3IiLCJ0YWJsZSIsInN0cmVhbWluZ1F1ZXJ5IiwiRXJyb3IiLCJjYWxsYmFja3MiLCJnZXRQcm9maWxlIiwiZmlsdGVycyIsInB1c2giLCJjb3VudCIsInVuZXNjYXBlIiwiZXhhbSIsIkdyb3VwcyIsInBsYXRmb3JtUGx1ZyIsImNhbGxiYWNrIiwiZ3JvdXBJZCIsImtleSIsImN1ciIsImZpZWxkcyIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiZm9yRWFjaCIsImluZGV4IiwiY2F0Y2giLCJteXNxbF8iLCJ0YWdvbiIsInByb2R1Y3RfaWQiLCJ0YWdvZmYiLCJ0YWdTZXQiLCJ0YWdzIiwic2V0IiwiaW1hZ2VzIiwiaSIsImxlbmd0aCIsImZpbGVfbmFtZSIsInJhbmsiLCJ1cGRhdGVfZGF0YSIsImtleXMiLCJrIiwicXVlcnlVcGRhdGUiLCJkZXNjcmlwdGlvbl9saXN0Iiwic2VhcmNoX3dvcmQiLCJmcmVlX2FyZWEiLCJwcm9kdWN0X2NsYXNzX2lkIiwic3RvY2siLCJzdG9ja191bmxpbWl0ZWQiLCJjbGFzc19jYXRlZ29yeV9pZDEiLCJjbGFzc19jYXRlZ29yeV9pZDIiLCJkZWxpdmVyeV9kYXRlX2lkIiwic2FsZV9saW1pdCIsImRlbGl2ZXJ5X2ZlZSIsInByb2R1Y3Rfc3RvY2tfaWQiLCJEQkZpbHRlckZhY3RvcnkiLCJEQkZpbHRlciIsIk15c3FsREJGaWx0ZXIiLCJpbnN0YW5jZSIsImZhY3RvcnkiLCJnZXRQbHVnXyIsImdldENyZWRfIiwiZ2V0UHJvZmlsZV8iLCJzZXRJbXBvcnRGdW5jdGlvbl8iLCJmbiIsIml0ZXJhdG9ycyIsImNvdW50ZXIiLCJmIiwibGltaXQiLCJjIiwiY2xpZW50IiwiY29ubmVjdCIsInVyaSIsImRhdGFiYXNlIiwiaGFzTmV4dCIsIm5leHQiLCJJdGVtcyIsIk9iamVjdCIsImFzc2lnbiIsIlByb2R1Y3RzIiwiZ2V0U3RvY2siLCJpdGVtX2lkIiwicHJvamVjdCIsInByb2R1Y3RfcGFjayIsInByb2R1Y3QiLCJxdWFudGl0aWVzIiwicHJvZHVjdF9za3UiLCJxdWFudGl0eV9za3UiLCJzdG9ja19hcnJheSIsInF1YW50aXR5IiwiTWF0aCIsIm1pbiIsImFwcGx5IiwiZmV0Y2giLCJtYXAiLCJjbGFzczFfdmFsdWUiLCJjbGFzczJfdmFsdWUiLCJ1cGRhdGVNYW55IiwiJHB1c2giLCIkZWFjaCIsInNoYXJha3VTaG9wIiwibW9kZWxDbGFzcyIsInByb2R1Y3RfdHlwZV9pZCIsImRlbGl2ZXJ5Iiwiam9pbiIsImphbl9jb2RlIiwiZGVzY3JpcHRpb25fZGV0YWlsIiwiZGVzY3JpcHRpb24iLCJwcm9kdWN0X2NvZGUiLCJwcmljZTAxIiwicmV0YWlsX3ByaWNlIiwicHJpY2UwMiIsInNhbGVzX3ByaWNlIiwibWFsbCIsIm1vbWVudCIsInBvb2wiLCJjcmVhdGVQb29sIiwicHJvZmlsZU11bHRpIiwibXVsdGlwbGVTdGF0ZW1lbnRzIiwicG9vbE11bHRpIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJmb3JtYXQiLCJyZXBsYWNlIiwiZ2V0Q29uIiwidGhlbiIsImNvbiIsInJlbGVhc2UiLCJxdWVyeUluc2VydF8iLCJpbnNlcnRJZCIsImRhdGFfc3FsIiwiTWFwIiwidmFsdWVzIiwidXBkYXRlcyIsInF1ZXJ5TXVsdGkiLCJwb29sU3dhcCIsInN0YXJ0VHJhbnNhY3Rpb24iLCJjb21taXQiLCJyb2xsYmFjayIsIm9uIiwicGF1c2UiLCJyZXN1bWUiLCJnZXRDb25uZWN0aW9uIiwiaXRlcmF0b3IiLCJJdGVyYXRvciIsInJlYyIsInJlc3VsdCIsInRvdGFsIiwibmV3UmVjb3JkIiwic3VjY2VzcyIsImVycm9yT2N1cnJlZCIsIml0ZUVycm9yIiwidHJhY2UiLCJwaGFFcnJvciIsInJlY29yZHMiLCJwYXJzZSJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxFQUFKO0FBQU9DLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxJQUFSLENBQWIsRUFBMkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNMLFNBQUdLLENBQUg7QUFBSzs7QUFBakIsQ0FBM0IsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUMsTUFBSjtBQUFXTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlELElBQUlFLFVBQUo7QUFBZU4sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNFLGlCQUFXRixDQUFYO0FBQWE7O0FBQXpCLENBQTNDLEVBQXNFLENBQXRFO0FBQXlFLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFDQUFSLENBQWIsRUFBNEQ7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBNUQsRUFBb0YsQ0FBcEY7QUFhaE8sSUFBSUksdUJBQXVCRixZQUEzQjtBQUVBLE1BQU1HLFFBQVEsZUFBZCxDLENBRUE7O0FBQ0FDLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCSCxLQUEzQixFQUFrQ0Qsb0JBQWxDO0FBQ0FFLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCSCxLQUEzQixFQUFrQyxDQUFDSSxHQUFELEVBQU1DLElBQU4sS0FBZTtBQUMvQztBQUVBLFFBQU1DLFNBQVNDLE9BQU9DLFNBQVAsQ0FBaUJsQixHQUFHbUIsUUFBcEIsQ0FBZjtBQUNBLFFBQU1DLFNBQVNILE9BQU9DLFNBQVAsQ0FBaUJsQixHQUFHcUIsU0FBcEIsQ0FBZjtBQUNBLFFBQU1DLFdBQVdoQixRQUFqQjs7QUFFQSxPQUFLLElBQUlpQixJQUFULElBQWlCVCxJQUFJVSxLQUFKLENBQVVELElBQTNCLEVBQWlDO0FBQy9CLFVBQU1FLE9BQU9ULE9BQU9PLEtBQUtHLElBQVosQ0FBYixDQUQrQixDQUUvQjtBQUNBOztBQUNBLFFBQUlDLFdBQVksR0FBRXJCLFFBQVMsTUFBM0IsQ0FKK0IsQ0FNL0I7O0FBQ0EsUUFBSXNCLFdBQVdkLElBQUllLElBQUosQ0FBU0MsUUFBVCxHQUFvQixHQUFwQixHQUEwQkgsUUFBekMsQ0FQK0IsQ0FTL0I7QUFFQTs7QUFDQSxRQUFJSSxNQUFNO0FBQ1JULGdCQUFVQSxRQURGO0FBRVJVLHNCQUFnQlQsS0FBS1UsSUFGYjtBQUdSQyx3QkFBa0JQO0FBSFYsS0FBVjs7QUFNQSxRQUFHO0FBQ0RQLGFBQU9RLFFBQVAsRUFBaUJILElBQWpCO0FBQ0QsS0FGRCxDQUdBLE9BQU1VLEdBQU4sRUFBVTtBQUNSSixVQUFJSyxLQUFKLEdBQVlELEdBQVo7QUFDRDs7QUFDRDNCLFlBQVE2QixNQUFSLENBQWVOLEdBQWY7QUFFQSxXQUFPUixJQUFQO0FBRUQ7O0FBQUE7QUFDRFIsT0FBS3VCLFNBQUwsQ0FBZSxHQUFmO0FBQ0F2QixPQUFLd0IsR0FBTCxDQUFTQyxLQUFLQyxTQUFMLENBQWU7QUFDdEJuQixjQUFVQSxRQURZO0FBRXRCb0IsYUFBUzVCLElBQUllLElBQUosQ0FBU0M7QUFGSSxHQUFmLENBQVQ7QUFLRCxDQTFDRCxFOzs7Ozs7Ozs7OztBQ25CQSxJQUFJYSxNQUFKO0FBQVcxQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3NDLGFBQU90QyxDQUFQO0FBQVM7O0FBQXJCLENBQWxELEVBQXlFLENBQXpFO0FBQTRFLElBQUl1QyxhQUFKO0FBQWtCM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ3lDLGdCQUFjdkMsQ0FBZCxFQUFnQjtBQUFDdUMsb0JBQWN2QyxDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJd0MsUUFBSjtBQUFhNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQzBDLFdBQVN4QyxDQUFULEVBQVc7QUFBQ3dDLGVBQVN4QyxDQUFUO0FBQVc7O0FBQXhCLENBQXBELEVBQThFLENBQTlFO0FBQWlGLElBQUl5QyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFO0FBQTBFLElBQUkwQyxjQUFKO0FBQW1COUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMwQyxxQkFBZTFDLENBQWY7QUFBaUI7O0FBQTdCLENBQWpELEVBQWdGLENBQWhGO0FBVXpZLElBQUkyQyxNQUFNLFFBQVY7QUFFQS9CLE9BQU9nQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLE9BQWQsRUFBc0JFLE1BQXRCO0FBQUEsb0NBQThCO0FBRTVCLFVBQUlDLFNBQVMsSUFBSVIsTUFBSixFQUFiO0FBRUEsVUFBSVMsU0FBUyxJQUFJUixhQUFKLENBQWtCTSxPQUFPRyxPQUF6QixFQUFrQ0gsT0FBT0ksT0FBekMsQ0FBYjtBQUNBLFVBQUlDLFdBQVcsSUFBSVQsS0FBSixDQUFVSSxPQUFPTSxPQUFqQixDQUFmO0FBQ0EsVUFBSUMsTUFBTSxJQUFJWixRQUFKLENBQWFVLFFBQWIsQ0FBVjtBQUVBLG9CQUFNSixPQUFPTyxLQUFQLENBQ0osc0JBREksRUFFSiwrQkFBWTtBQUNWLDZCQUFhTixPQUFPTyxPQUFQLENBQWU7QUFDeEIsb0JBQVUsQ0FBT0MsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUVqQyxnQkFBSUMsTUFBTUQsUUFBUUUsVUFBbEI7O0FBRUEsZ0JBQUk7QUFFRkMseUJBQVdqQixlQUFla0IsU0FBZixDQUF5QkwsSUFBekIsQ0FBWDtBQUVBLDRCQUFNSCxJQUFJUyxhQUFKLENBQWtCRixRQUFsQixDQUFOO0FBQ0EsNEJBQU1QLElBQUlVLGdCQUFKLENBQXFCakIsT0FBT2tCLFVBQTVCLEVBQXVDSixRQUF2QyxDQUFOO0FBRUFiLHFCQUFPa0IsUUFBUDtBQUVELGFBVEQsQ0FTRSxPQUFPQyxDQUFQLEVBQVU7QUFFVm5CLHFCQUFPb0IsTUFBUCxDQUFjRCxDQUFkO0FBRUQ7QUFDRixXQWxCUztBQURjLFNBQWYsRUFxQkpBLENBQVAsNkJBQWE7QUFDWCxnQkFBTUEsQ0FBTjtBQUNELFNBRkQsQ0FyQlcsQ0FBYjtBQXlCRCxPQTFCRCxDQUZJLENBQU47QUFnQ0EsYUFBT25CLE9BQU9xQixPQUFQLEVBQVA7QUFFRCxLQTFDRDtBQUFBLEdBTGE7O0FBa0RiO0FBQ0E7QUFFQSxHQUFRLEdBQUV4QixHQUFJLFFBQWQsRUFBdUJFLE1BQXZCO0FBQUEsb0NBQStCO0FBRTdCLFVBQUlDLFNBQVMsSUFBSVIsTUFBSixFQUFiO0FBRUEsVUFBSVMsU0FBUyxJQUFJUixhQUFKLENBQWtCTSxPQUFPRyxPQUF6QixFQUFrQ0gsT0FBT0ksT0FBekMsQ0FBYjtBQUNBLFVBQUlDLFdBQVcsSUFBSVQsS0FBSixDQUFVSSxPQUFPTSxPQUFqQixDQUFmO0FBQ0EsVUFBSUMsTUFBTSxJQUFJWixRQUFKLENBQWFVLFFBQWIsQ0FBVjtBQUVBLG9CQUFNSixPQUFPTyxLQUFQLENBQ0osc0JBREksRUFFSiwrQkFBWTtBQUNWLDZCQUFhTixPQUFPTyxPQUFQLENBQWU7QUFDeEIsb0JBQVUsQ0FBT0MsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUVqQyxnQkFBSUMsTUFBTUQsUUFBUUUsVUFBbEI7O0FBRUEsZ0JBQUk7QUFFRixrQkFBSVUsb0JBQVloQixJQUFJaUIsa0JBQUosQ0FDZHhCLE9BQU9rQixVQURPLEVBRWRyQixlQUFla0IsU0FBZixDQUF5QkwsSUFBekIsQ0FGYyxDQUFaLENBQUo7QUFLQVQscUJBQU9rQixRQUFQO0FBRUQsYUFURCxDQVNFLE9BQU9DLENBQVAsRUFBVTtBQUVWbkIscUJBQU9vQixNQUFQLENBQWNELENBQWQ7QUFFRDtBQUNGLFdBbEJTO0FBRGMsU0FBZixFQXFCSkEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQXJCVyxDQUFiO0FBeUJELE9BMUJELENBRkksQ0FBTjtBQWdDQSxhQUFPbkIsT0FBT3FCLE9BQVAsRUFBUDtBQUVELEtBMUNEO0FBQUE7O0FBckRhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNaQSxJQUFJN0IsTUFBSjtBQUFXMUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzQyxhQUFPdEMsQ0FBUDtBQUFTOztBQUFyQixDQUFsRCxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJdUMsYUFBSjtBQUFrQjNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUN5QyxnQkFBY3ZDLENBQWQsRUFBZ0I7QUFBQ3VDLG9CQUFjdkMsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXdDLFFBQUo7QUFBYTVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUMwQyxXQUFTeEMsQ0FBVCxFQUFXO0FBQUN3QyxlQUFTeEMsQ0FBVDtBQUFXOztBQUF4QixDQUFwRCxFQUE4RSxDQUE5RTtBQUFpRixJQUFJeUMsS0FBSjtBQUFVN0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN5QyxZQUFNekMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJc0UsV0FBSjtBQUFnQjFFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ3dFLGNBQVl0RSxDQUFaLEVBQWM7QUFBQ3NFLGtCQUFZdEUsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJMEMsY0FBSjtBQUFtQjlDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDMEMscUJBQWUxQyxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQWE1ZCxJQUFJMkMsTUFBTSxPQUFWO0FBRUEvQixPQUFPZ0MsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLFVBQWQsRUFBeUJFLE1BQXpCO0FBQUEsb0NBQWlDO0FBRS9CLFVBQUlDLFNBQVMsSUFBSVIsTUFBSixFQUFiLENBRitCLENBSS9CO0FBQ0E7QUFFQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQUlTLFNBQVMsSUFBSVIsYUFBSixDQUFrQk0sT0FBTzBCLFFBQXpCLEVBQW1DMUIsT0FBT0ksT0FBMUMsQ0FBYjtBQUNBLFVBQUlDLFdBQVcsSUFBSVQsS0FBSixDQUFVSSxPQUFPSyxRQUFQLENBQWdCc0IsSUFBMUIsQ0FBZjtBQUNBLFVBQUlwQixNQUFNLElBQUlaLFFBQUosQ0FBYVUsUUFBYixDQUFWO0FBRUEsb0JBQU1KLE9BQU9PLEtBQVAsQ0FDSixzQkFESSxFQUVKLCtCQUFZO0FBQ1YsNkJBQWFOLE9BQU9PLE9BQVAsQ0FBZTtBQUN4Qiw4QkFBb0IsQ0FBT0MsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUUzQyxnQkFBSUMsTUFBTUQsUUFBUUUsVUFBbEI7O0FBRUEsZ0JBQUk7QUFFRixrQkFBSWUsMEJBQWtCckIsSUFBSXNCLGFBQUosQ0FDcEI3QixPQUFPa0IsVUFEYSxFQUVwQnJCLGVBQWVrQixTQUFmLENBQXlCTCxJQUF6QixDQUZvQixDQUFsQixDQUFKO0FBS0EsNEJBQU1FLElBQUlrQixNQUFKLENBQVc7QUFDZkMscUJBQUtyQixLQUFLcUI7QUFESyxlQUFYLEVBRUg7QUFDREMsc0JBQU07QUFDSixzQ0FBb0JKLFVBQVVMO0FBRDFCO0FBREwsZUFGRyxDQUFOO0FBUUF0QixxQkFBT2tCLFFBQVA7QUFFRCxhQWpCRCxDQWlCRSxPQUFPQyxDQUFQLEVBQVU7QUFFVm5CLHFCQUFPb0IsTUFBUCxDQUFjRCxDQUFkO0FBRUQ7QUFDRixXQTFCbUI7QUFESSxTQUFmLEVBNkJKQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBN0JXLENBQWI7QUFpQ0QsT0FsQ0QsQ0FGSSxDQUFOO0FBd0NBLGFBQU9uQixPQUFPcUIsT0FBUCxFQUFQO0FBRUQsS0E5REQ7QUFBQTs7QUFGYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSVcsTUFBSjtBQUFXbEYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzhFLGFBQU85RSxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlELElBQUl5QyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFO0FBQTBFLElBQUlzQyxNQUFKO0FBQVcxQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3NDLGFBQU90QyxDQUFQO0FBQVM7O0FBQXJCLENBQWxELEVBQXlFLENBQXpFO0FBQTRFLElBQUkrRSxLQUFKLEVBQVVDLFlBQVY7QUFBdUJwRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUNBQVIsQ0FBYixFQUF3RDtBQUFDaUYsUUFBTS9FLENBQU4sRUFBUTtBQUFDK0UsWUFBTS9FLENBQU47QUFBUSxHQUFsQjs7QUFBbUJnRixlQUFhaEYsQ0FBYixFQUFlO0FBQUNnRixtQkFBYWhGLENBQWI7QUFBZTs7QUFBbEQsQ0FBeEQsRUFBNEcsQ0FBNUc7QUFBK0csSUFBSWlGLE1BQUo7QUFBV3JGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQ0FBUixDQUFiLEVBQXlEO0FBQUNtRixTQUFPakYsQ0FBUCxFQUFTO0FBQUNpRixhQUFPakYsQ0FBUDtBQUFTOztBQUFwQixDQUF6RCxFQUErRSxDQUEvRTtBQVloWSxJQUFJMkMsTUFBTSxTQUFWO0FBRUEvQixPQUFPZ0MsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLFVBQWQsRUFBeUJFLE1BQXpCO0FBQUEsb0NBQWlDO0FBRS9CLFVBQUlDLFNBQVMsSUFBSVIsTUFBSixFQUFiLENBRitCLENBSS9CO0FBQ0E7O0FBRUEsVUFBSVMsU0FBUyxJQUFJa0MsTUFBSixDQUFXcEMsT0FBT3FDLFdBQWxCLENBQWIsQ0FQK0IsQ0FRL0I7QUFFQTtBQUNBOztBQUVBLFVBQUlDLFlBQVksZ0JBQWhCO0FBRUEsVUFBSUMsUUFBUSxJQUFJM0MsS0FBSixDQUFVSSxPQUFPd0MsR0FBUCxDQUFXYixJQUFyQixDQUFaO0FBRUEsb0JBQU0xQixPQUFPTyxLQUFQLENBQWEsd0JBQWIsRUFDSiwrQkFBWTtBQUNWLHNCQUFNK0IsTUFBTUUsS0FBTixDQUFZSCxTQUFaLENBQU47QUFDRCxPQUZELENBREksQ0FBTixFQWpCK0IsQ0F1Qi9CO0FBQ0E7O0FBRUEsb0JBQU1yQyxPQUFPTyxLQUFQLENBQWEsdUJBQWIsRUFDSiwrQkFBWTtBQUNWLDZCQUFhTixPQUFPTyxPQUFQLENBQWU7QUFDeEJpQyxzQkFBbUJDLE1BQVAsNkJBQWtCO0FBRTVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsZ0JBQUlDLE1BQU87Ozs7OzBCQUtFRCxPQUFPRSxXQUFhLE1BQU1GLE9BQU9HLE1BQVEsTUFBTUgsT0FBT0ksR0FBSyxNQUFNSixPQUFPSyxHQUFLLE1BQU1MLE9BQU9NLFVBQVksTUFBTU4sT0FBT08sSUFBTSxNQUFNUCxPQUFPUSxNQUFRLE1BQU1SLE9BQU9TLE1BQVEsTUFBTVQsT0FBT1UsTUFBUSxNQUFNVixPQUFPVyxNQUFRLE1BQU1YLE9BQU9ZLFlBQWMsTUFBTVosT0FBT2EsS0FBTyxNQUFNYixPQUFPYyxLQUFPLE1BQU1kLE9BQU9lLE9BQVMsTUFBTWYsT0FBT2dCLE1BQVEsTUFBTWhCLE9BQU9pQixNQUFRLE1BQU1qQixPQUFPa0IsS0FBTyxNQUFNbEIsT0FBT21CLEtBQU8sTUFBTW5CLE9BQU9vQixLQUFPLE1BQU1wQixPQUFPcUIsS0FBTyxNQUFNckIsT0FBT3NCLEtBQU8sTUFBTXRCLE9BQU91QixLQUFPLE1BQU12QixPQUFPd0IsS0FBTyxNQUFNeEIsT0FBT3lCLEtBQU8sTUFBTXpCLE9BQU8wQixRQUFVLE1BQU0xQixPQUFPMkIsSUFBTSxNQUFNM0IsT0FBTzRCLFVBQVksTUFBTTVCLE9BQU82QixjQUFnQixNQUFNN0IsT0FBTzhCLGFBQWUsTUFBTTlCLE9BQU8rQixTQUFXLE1BQU0vQixPQUFPZ0MsU0FBVyxNQUFNaEMsT0FBT2lDLElBQU0sTUFBTWpDLE9BQU9rQyxXQUFhLE1BQU1sQyxPQUFPbUMsV0FBYSxNQUFNbkMsT0FBT29DLE9BQVM7O2lCQUx0d0I7O0FBU0EsZ0JBQUk7QUFDRiw0QkFBTXhDLE1BQU15QyxXQUFOLENBQ0osY0FESSxFQUVKO0FBQ0VuQyw2QkFBYUYsT0FBT0UsV0FEdEI7QUFFRUMsd0JBQVFILE9BQU9HLE1BRmpCO0FBR0VDLHFCQUFLSixPQUFPSSxHQUhkO0FBSUVDLHFCQUFLTCxPQUFPSyxHQUpkO0FBS0VDLDRCQUFZTixPQUFPTSxVQUxyQjtBQU1FQyxzQkFBTVAsT0FBT08sSUFOZjtBQU9FQyx3QkFBUVIsT0FBT1EsTUFQakI7QUFRRUMsd0JBQVFULE9BQU9TLE1BUmpCO0FBU0VDLHdCQUFRVixPQUFPVSxNQVRqQjtBQVVFQyx3QkFBUVgsT0FBT1csTUFWakI7QUFXRUMsOEJBQWNaLE9BQU9ZLFlBWHZCO0FBWUVDLHVCQUFPYixPQUFPYSxLQVpoQjtBQWFFQyx1QkFBT2QsT0FBT2MsS0FiaEI7QUFjRUMseUJBQVNmLE9BQU9lLE9BZGxCO0FBZUVDLHdCQUFRaEIsT0FBT2dCLE1BZmpCO0FBZ0JFQyx3QkFBUWpCLE9BQU9pQixNQWhCakI7QUFpQkVDLHVCQUFPbEIsT0FBT2tCLEtBakJoQjtBQWtCRUMsdUJBQU9uQixPQUFPbUIsS0FsQmhCO0FBbUJFQyx1QkFBT3BCLE9BQU9vQixLQW5CaEI7QUFvQkVDLHVCQUFPckIsT0FBT3FCLEtBcEJoQjtBQXFCRUMsdUJBQU90QixPQUFPc0IsS0FyQmhCO0FBc0JFQyx1QkFBT3ZCLE9BQU91QixLQXRCaEI7QUF1QkVDLHVCQUFPeEIsT0FBT3dCLEtBdkJoQjtBQXdCRUMsdUJBQU96QixPQUFPeUIsS0F4QmhCO0FBeUJFQywwQkFBVTFCLE9BQU8wQixRQXpCbkI7QUEwQkVDLHNCQUFNM0IsT0FBTzJCLElBMUJmO0FBMkJFQyw0QkFBWTVCLE9BQU80QixVQTNCckI7QUE0QkVDLGdDQUFnQjdCLE9BQU82QixjQTVCekI7QUE2QkVDLCtCQUFlOUIsT0FBTzhCLGFBN0J4QjtBQThCRUMsMkJBQVcvQixPQUFPK0IsU0E5QnBCO0FBK0JFQywyQkFBV2hDLE9BQU9nQyxTQS9CcEI7QUFnQ0VDLHNCQUFNakMsT0FBT2lDLElBaENmO0FBaUNFQyw2QkFBYWxDLE9BQU9rQyxXQWpDdEI7QUFrQ0VDLDZCQUFhbkMsT0FBT21DLFdBbEN0QjtBQW1DRUMseUJBQVNwQyxPQUFPb0M7QUFuQ2xCLGVBRkksQ0FBTjtBQXdDRCxhQXpDRCxDQXlDRSxPQUFPM0QsQ0FBUCxFQUFVO0FBQ1ZuQixxQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBbEUyQixDQW9FNUI7OztBQUNBLGdCQUFJO0FBQ0YsNEJBQU1tQixNQUFNeUMsV0FBTixDQUNKLHNCQURJLEVBQ29CO0FBQ3RCQyxxQ0FBcUIsSUFEQztBQUV0QnBDLDZCQUFhRixPQUFPRSxXQUZFO0FBR3RCSSw0QkFBWU4sT0FBT00sVUFIRztBQUl0QkMsc0JBQU1QLE9BQU9PLElBSlM7QUFLdEJDLHdCQUFRUixPQUFPUSxNQUxPO0FBTXRCQyx3QkFBUVQsT0FBT1MsTUFOTztBQU90QkMsd0JBQVFWLE9BQU9VLE1BUE87QUFRdEJDLHdCQUFRWCxPQUFPVyxNQVJPO0FBU3RCQyw4QkFBY1osT0FBT1ksWUFUQztBQVV0QkMsdUJBQU9iLE9BQU9hLEtBVlE7QUFXdEJDLHVCQUFPZCxPQUFPYyxLQVhRO0FBWXRCQyx5QkFBU2YsT0FBT2UsT0FaTTtBQWF0QkMsd0JBQVFoQixPQUFPZ0IsTUFiTztBQWN0QkMsd0JBQVFqQixPQUFPaUIsTUFkTztBQWV0QkUsdUJBQU9uQixPQUFPbUIsS0FmUTtBQWdCdEJDLHVCQUFPcEIsT0FBT29CLEtBaEJRO0FBaUJ0QkMsdUJBQU9yQixPQUFPcUIsS0FqQlE7QUFrQnRCQyx1QkFBT3RCLE9BQU9zQixLQWxCUTtBQW1CdEJDLHVCQUFPdkIsT0FBT3VCLEtBbkJRO0FBb0J0QkMsdUJBQU94QixPQUFPd0IsS0FwQlE7QUFxQnRCVSw2QkFBYWxDLE9BQU9rQyxXQXJCRTtBQXNCdEJDLDZCQUFhbkMsT0FBT21DLFdBdEJFO0FBdUJ0QkMseUJBQVNwQyxPQUFPb0M7QUF2Qk0sZUFEcEIsQ0FBTjtBQTJCRCxhQTVCRCxDQTRCRSxPQUFPM0QsQ0FBUCxFQUFVO0FBQ1ZuQixxQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBbkcyQixDQXFHNUI7OztBQUNBLGdCQUFJO0FBQ0YsNEJBQU1tQixNQUFNeUMsV0FBTixDQUNKLHVCQURJLEVBQ3FCO0FBQ3ZCRSxvQkFBSSxJQURtQjtBQUV2QnJDLDZCQUFhRixPQUFPRSxXQUZHO0FBR3ZCc0MsOEJBQWN4QyxPQUFPd0MsWUFIRTtBQUl2Qk4sNkJBQWFsQyxPQUFPa0MsV0FKRztBQUt2QkMsNkJBQWFuQyxPQUFPbUMsV0FMRztBQU12QkMseUJBQVNwQyxPQUFPb0M7QUFOTyxlQURyQixDQUFOO0FBVUQsYUFYRCxDQVdFLE9BQU8zRCxDQUFQLEVBQVU7QUFDVm5CLHFCQUFPb0IsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFuSDJCLENBcUg1Qjs7O0FBRUEsZ0JBQUlnRSxZQUFZbkQsT0FBT29ELFdBQVAsQ0FBbUIsQ0FBbkIsRUFBc0JDLFFBQXRCLENBQStCLFFBQS9CLEVBQXlDQyxTQUF6QyxDQUFtRCxDQUFuRCxFQUFxRCxFQUFyRCxDQUFoQjtBQUVBLGdCQUFJQyxjQUFlLEdBQUU3QyxPQUFPUSxNQUFPLElBQUdSLE9BQU9TLE1BQU8sbUJBQWtCVCxPQUFPRSxXQUFZLEVBQXpGO0FBRUEsZ0JBQUk0QyxpQkFBaUI5QyxPQUFPK0MsS0FBUCxHQUFlLEdBQXBDOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUluRSxvQkFBWWdCLE1BQU15QyxXQUFOLENBQ2QsWUFEYyxFQUNBO0FBQ1pXLDJCQUFXLElBREM7QUFFWlAsMkJBQVdBLFNBRkM7QUFHWlEsNkJBQWEsQ0FIRDtBQUdJO0FBQ2hCSiw2QkFBYUEsV0FKRDtBQUtaSywrQkFBZSxDQUxIO0FBTVpDLGlDQUFpQixDQU5MO0FBT1pDLGdDQUFnQixDQVBKO0FBUVpOLGdDQUFnQkEsY0FSSjtBQVNaTywrQkFBZSxJQVRIO0FBVVpDLDZCQUFhLENBVkQ7QUFXWkMsK0JBQWUsQ0FYSDtBQVlaQyxvQ0FBb0IsSUFaUjtBQWFaQyxxQ0FBcUIscUJBYlQ7QUFjWkMsbUNBQW1CLHFCQWRQO0FBZVp0Qix5QkFBUztBQWZHLGVBREEsRUFpQlo7QUFDQUYsNkJBQWEsT0FEYjtBQUVBQyw2QkFBYTtBQUZiLGVBakJZLENBQVosQ0FBSjtBQXNCRCxhQXZCRCxDQXVCRSxPQUFPMUQsQ0FBUCxFQUFVO0FBQ1ZuQixxQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0F2Slc7QUFEWSxTQUFmLEVBMEpKQSxDQUFQLDZCQUFhO0FBQ1huQixpQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUNELFNBRkQsQ0ExSlcsQ0FBYjtBQThKRCxPQS9KRCxDQURJLENBQU47QUFrS0EsYUFBT25CLE9BQU9xQixPQUFQLEVBQVA7QUFDRCxLQTdMRDtBQUFBLEdBRmE7O0FBaU1QLHVCQUFOLENBQTZCbEIsT0FBN0I7QUFBQSxvQ0FBc0M7QUFFcEMsVUFBSWtHLEtBQUssSUFBSTFHLEtBQUosQ0FBVVEsT0FBVixDQUFUO0FBQ0EsVUFBSW1CLG9CQUFZK0UsR0FBRzdELEtBQUgsQ0FBUyxnQkFBVCxDQUFaLENBQUo7QUFDQSxhQUFPbEIsR0FBUDtBQUNELEtBTEQ7QUFBQTs7QUFqTWEsQ0FBZixFOzs7Ozs7Ozs7OztBQ2RBLElBQUlnRixlQUFKO0FBQW9CeEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ3NKLGtCQUFnQnBKLENBQWhCLEVBQWtCO0FBQUNvSixzQkFBZ0JwSixDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBakQsRUFBeUYsQ0FBekY7QUFFcEIsSUFBSTJDLE1BQU0sa0JBQVY7QUFFQS9CLE9BQU9nQyxPQUFQLENBQWU7QUFFYixHQUFRLEdBQUVELEdBQUksT0FBZCxFQUF1QjBHLElBQXZCLEVBQTZCL0QsUUFBTSxFQUFuQyxFQUF1Q2dFLGFBQVcsRUFBbEQ7QUFBQSxvQ0FBdUQ7QUFFckQsVUFBSUMscUJBQWFILGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLENBQWIsQ0FBSjtBQUNBLDJCQUFhRSxLQUFLRSxJQUFMLENBQVVuRSxLQUFWLEVBQWdCO0FBQUNnRSxvQkFBV0E7QUFBWixPQUFoQixFQUF5Q0ksT0FBekMsRUFBYjtBQUVELEtBTEQ7QUFBQSxHQUZhOztBQVNiLEdBQVEsR0FBRS9HLEdBQUksWUFBZCxFQUE0QjBHLElBQTVCLEVBQWtDL0QsUUFBTSxFQUF4QztBQUFBLG9DQUE2QztBQUUzQyxVQUFJaUUscUJBQWFILGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLENBQWIsQ0FBSjtBQUNBLDJCQUFhRSxLQUFLSSxTQUFMLENBQWVyRSxLQUFmLEVBQXNCb0UsT0FBdEIsRUFBYjtBQUVELEtBTEQ7QUFBQTs7QUFUYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSWhILGNBQUo7QUFBbUI5QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzBDLHFCQUFlMUMsQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFFbkIsSUFBSTJDLE1BQU0sYUFBVjtBQUVBL0IsT0FBT2dDLE9BQVAsQ0FBZTtBQUViOzs7OztBQUtBLEdBQVEsR0FBRUQsR0FBSSxXQUFkLEVBQTJCMEcsSUFBM0IsRUFBaUNwSSxRQUFqQyxFQUEyQzJJLEtBQTNDLEVBQWtEQyxTQUFTLElBQTNELEVBQWlFQyxTQUFTLElBQTFFO0FBQUEsb0NBQWlGO0FBQy9FLFVBQUlDLFVBQVUsSUFBSXJILGNBQUosRUFBZDtBQUNBLG9CQUFNcUgsUUFBUUMsSUFBUixDQUFhWCxJQUFiLENBQU47QUFDQSxVQUFJWSx5QkFBaUJGLFFBQVFHLFFBQVIsQ0FBa0JqSixRQUFsQixFQUE0QjJJLEtBQTVCLEVBQW1DQyxNQUFuQyxFQUEyQ0MsTUFBM0MsQ0FBakIsQ0FBSjtBQUNBLGFBQU9HLFFBQVA7QUFDRCxLQUxEO0FBQUEsR0FQYTs7QUFjYjs7O0FBR0EsR0FBUSxHQUFFdEgsR0FBSSxhQUFkLEVBQTZCMEcsSUFBN0IsRUFBbUNPLEtBQW5DLEVBQTBDQyxTQUFTLElBQW5ELEVBQXlEQyxTQUFTLElBQWxFO0FBQUEsb0NBQXlFO0FBQ3ZFLFVBQUlDLFVBQVUsSUFBSXJILGNBQUosRUFBZDtBQUNBLG9CQUFNcUgsUUFBUUMsSUFBUixDQUFhWCxJQUFiLENBQU47QUFDQSxvQkFBTVUsUUFBUUksVUFBUixDQUFvQlAsS0FBcEIsRUFBMkJDLE1BQTNCLEVBQW1DQyxNQUFuQyxDQUFOO0FBQ0QsS0FKRDtBQUFBOztBQWpCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSXhILE1BQUo7QUFBVzFDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDc0MsYUFBT3RDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSXVDLGFBQUo7QUFBa0IzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDeUMsZ0JBQWN2QyxDQUFkLEVBQWdCO0FBQUN1QyxvQkFBY3ZDLENBQWQ7QUFBZ0I7O0FBQWxDLENBQWpELEVBQXFGLENBQXJGO0FBQXdGLElBQUl3QyxRQUFKO0FBQWE1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDMEMsV0FBU3hDLENBQVQsRUFBVztBQUFDd0MsZUFBU3hDLENBQVQ7QUFBVzs7QUFBeEIsQ0FBakQsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSXlDLEtBQUo7QUFBVTdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDeUMsWUFBTXpDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSTBDLGNBQUo7QUFBbUI5QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzBDLHFCQUFlMUMsQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBOUMsRUFBNkUsQ0FBN0U7QUFVN1gsSUFBSTJDLE1BQU0sTUFBVjtBQUVBL0IsT0FBT2dDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksWUFBZCxFQUEyQkUsTUFBM0I7QUFBQSxvQ0FBbUM7QUFFakM7QUFDQSxVQUFJQyxTQUFTLElBQUlSLE1BQUosRUFBYjtBQUVBLFVBQUlTLFNBQVMsSUFBSVIsYUFBSixDQUFrQk0sT0FBT0csT0FBekIsRUFBa0NILE9BQU9JLE9BQXpDLENBQWI7QUFDQSxVQUFJQyxXQUFXLElBQUlULEtBQUosQ0FBVUksT0FBT00sT0FBakIsQ0FBZjtBQUNBLFVBQUlDLE1BQU0sSUFBSVosUUFBSixDQUFhVSxRQUFiLENBQVY7QUFFQSxvQkFBTUosT0FBT08sS0FBUCxDQUNKLGVBREksRUFFSiwrQkFBWTtBQUNWLDZCQUFhTixPQUFPTyxPQUFQLENBQWU7QUFDeEIsb0JBQVUsQ0FBT0MsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUVqQyxnQkFBSUMsTUFBTUQsUUFBUUUsVUFBbEI7O0FBRUEsZ0JBQUk7QUFFRixrQkFBSUMsV0FBV2pCLGVBQWVrQixTQUFmLENBQXlCZixPQUFPa0IsVUFBaEMsRUFBNENSLElBQTVDLENBQWY7QUFFQSxrQkFBSTZHLDBCQUFrQmhILElBQUlzQixhQUFKLENBQWtCZixRQUFsQixDQUFsQixDQUFKLENBSkUsQ0FNRjs7QUFDQSw0QkFBTUYsSUFBSWtCLE1BQUosQ0FBVztBQUNmQyxxQkFBS3JCLEtBQUtxQjtBQURLLGVBQVgsRUFFSDtBQUNEQyxzQkFBTTtBQUNKLHNDQUFvQnVGLFVBQVVoRztBQUQxQjtBQURMLGVBRkcsQ0FBTjtBQVFBdEIscUJBQU9rQixRQUFQO0FBRUQsYUFqQkQsQ0FpQkUsT0FBT0MsQ0FBUCxFQUFVO0FBRVZuQixxQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUVEO0FBQ0YsV0ExQlM7QUFEYyxTQUFmLEVBNkJKQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBN0JXLENBQWI7QUFnQ0QsT0FqQ0QsQ0FGSSxDQUFOO0FBcUNBLG9CQUFNbkIsT0FBT08sS0FBUCxDQUNKLGdCQURJLEVBRUosK0JBQVk7QUFDViw2QkFBYU4sT0FBT08sT0FBUCxDQUFlO0FBQ3hCLG9CQUFVLENBQU9DLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFFakMsZ0JBQUlDLE1BQU1ELFFBQVFFLFVBQWxCOztBQUVBLGdCQUFJO0FBRUYsa0JBQUlDLFdBQVdqQixlQUFla0IsU0FBZixDQUF5QmYsT0FBT2tCLFVBQWhDLEVBQTRDUixJQUE1QyxDQUFmO0FBRUEsNEJBQU1ILElBQUlpQixrQkFBSixDQUF1QlYsUUFBdkIsQ0FBTjtBQUNBLDRCQUFNUCxJQUFJUyxhQUFKLENBQWtCRixRQUFsQixDQUFOO0FBQ0EsNEJBQU1QLElBQUlVLGdCQUFKLENBQXFCSCxRQUFyQixDQUFOO0FBRUFiLHFCQUFPa0IsUUFBUDtBQUVELGFBVkQsQ0FVRSxPQUFPQyxDQUFQLEVBQVU7QUFFVm5CLHFCQUFPb0IsTUFBUCxDQUFjRCxDQUFkO0FBRUQ7QUFDRixXQW5CUztBQURjLFNBQWYsRUFzQkpBLENBQVAsNkJBQWE7QUFDWCxnQkFBTUEsQ0FBTjtBQUNELFNBRkQsQ0F0QlcsQ0FBYjtBQXlCRCxPQTFCRCxDQUZJLENBQU47QUE4QkEsYUFBT25CLE9BQU9xQixPQUFQLEVBQVA7QUFFRCxLQTlFRDtBQUFBOztBQUxhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNaQSxJQUFJN0IsTUFBSjtBQUFXMUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzQyxhQUFPdEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJdUMsYUFBSjtBQUFrQjNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUN5QyxnQkFBY3ZDLENBQWQsRUFBZ0I7QUFBQ3VDLG9CQUFjdkMsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBakQsRUFBcUYsQ0FBckY7QUFBd0YsSUFBSXlDLEtBQUo7QUFBVTdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDeUMsWUFBTXpDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFNeE0sSUFBSTJDLE1BQU0sTUFBVjtBQUVBL0IsT0FBT2dDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksT0FBZCxFQUFzQkUsTUFBdEI7QUFBQSxvQ0FBOEI7QUFFNUI7QUFDQSxVQUFJQyxTQUFTLElBQUlSLE1BQUosRUFBYjtBQUVBLFVBQUlTLFNBQVMsSUFBSVIsYUFBSixDQUFrQk0sT0FBT0csT0FBekIsRUFBa0NILE9BQU9JLE9BQXpDLENBQWI7QUFFQSxvQkFBTUgsT0FBT08sS0FBUCxDQUNKLFVBREksRUFFSiwrQkFBWTtBQUNWLDZCQUFhTixPQUFPTyxPQUFQLENBQ1gsRUFEVyxFQUVKVyxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBRlcsQ0FBYjtBQUtELE9BTkQsQ0FGSSxDQUFOO0FBVUEsYUFBT25CLE9BQU9xQixPQUFQLEVBQVA7QUFFRCxLQW5CRDtBQUFBOztBQUxhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNSQXZFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwrQkFBUixDQUFiO0FBQXVERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0F2REYsT0FBT3lLLE1BQVAsQ0FBYztBQUFDQyxXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJQyxLQUFKO0FBQVUzSyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUN5SyxRQUFNdkssQ0FBTixFQUFRO0FBQUN1SyxZQUFNdkssQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUV4QyxNQUFNc0ssVUFBVSxJQUFJQyxNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQStCO0FBQUNDLGdCQUFhO0FBQWQsQ0FBL0IsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNGUDdLLE9BQU95SyxNQUFQLENBQWM7QUFBQ3BGLFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUlzRixLQUFKO0FBQVUzSyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUN5SyxRQUFNdkssQ0FBTixFQUFRO0FBQUN1SyxZQUFNdkssQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJeUMsS0FBSjtBQUFVN0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTBLLElBQUo7QUFBUzlLLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMwSyxXQUFLMUssQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJMkssT0FBSjtBQUFZL0ssT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzJLLGNBQVEzSyxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEO0FBQStELElBQUk0SyxTQUFKO0FBQWNoTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUM4SyxZQUFVNUssQ0FBVixFQUFZO0FBQUM0SyxnQkFBVTVLLENBQVY7QUFBWTs7QUFBMUIsQ0FBakMsRUFBNkQsQ0FBN0Q7QUFhblosTUFBTTZLLFVBQVUsSUFBSU4sTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUFnQztBQUM5Q0MsZ0JBQWM7QUFEZ0MsQ0FBaEMsQ0FBaEI7O0FBSU8sTUFBTXhGLE1BQU4sU0FBcUIyRixTQUFyQixDQUErQjtBQUVwQ0UsY0FBWUMsUUFBWixFQUFzQjtBQUVwQixRQUFJOUgsVUFBVTRILFFBQVFHLE9BQVIsQ0FBZ0I7QUFDNUJwRyxXQUFLbUc7QUFEdUIsS0FBaEIsQ0FBZDtBQUlBLFVBQU05SCxPQUFOO0FBRUEsUUFBSW9HLE9BQU8sS0FBSzRCLE9BQUwsRUFBWDs7QUFFQSxZQUFRNUIsS0FBSzZCLElBQWI7QUFFRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSTFJLEtBQUosQ0FBVTRHLEtBQUs3RSxJQUFmLENBQWI7O0FBQ0EsYUFBSzRHLE1BQUwsR0FBYyxDQUFRQyxXQUFZN0YsTUFBRCxJQUFVLENBQUUsQ0FBL0IsRUFBaUM4RixVQUFXckgsQ0FBRCxJQUFLLENBQUUsQ0FBbEQsOEJBQXdEO0FBQ3BFLGNBQUl3QixNQUFPLGlCQUFnQjRELEtBQUtrQyxLQUFNLEVBQXRDO0FBQ0EsK0JBQWEsS0FBS0osS0FBTCxDQUFXSyxjQUFYLENBQTBCL0YsR0FBMUIsRUFBK0I0RixRQUEvQixFQUF5Q0MsT0FBekMsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFFRjtBQUNFLGNBQU0sSUFBSUcsS0FBSixDQUFVLHVCQUFWLENBQU47QUFYSjtBQWNEO0FBRUQ7Ozs7OztBQUlNbkksU0FBTixDQUFjb0ksWUFBWSxFQUExQixFQUE4QkosVUFBaUJySCxDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUF4QztBQUFBLG9DQUF5RDtBQUV2RCxVQUFJaEIsVUFBVSxLQUFLMEksVUFBTCxFQUFkLENBRnVELENBSXZEOztBQUNBMUksY0FBUTJJLE9BQVIsQ0FBZ0JDLElBQWhCLENBQXFCO0FBQ25CWCxjQUFNLE1BRGE7QUFFbkI1RixlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJd0csUUFBUSxFQUFaOztBQUNBLFdBQUssSUFBSS9JLE1BQVQsSUFBbUJFLFFBQVEySSxPQUEzQixFQUFvQztBQUNsQ0UsY0FBTS9JLE9BQU9tSSxJQUFiLElBQXFCO0FBQ25CNUYsaUJBQU92QyxPQUFPdUMsS0FESztBQUVuQndHLGlCQUFPO0FBRlksU0FBckI7QUFJRDs7QUFFRCxvQkFBTSxLQUFLVixNQUFMLENBQ0c1RixNQUFQLDZCQUFnQjtBQUNkLGFBQUssSUFBSXpDLE1BQVQsSUFBbUJFLFFBQVEySSxPQUEzQixFQUFvQztBQUNsQyxjQUFJdEcsUUFBUXFGLFFBQVFvQixRQUFSLENBQWlCaEosT0FBT3VDLEtBQXhCLENBQVo7QUFDQSxjQUFJMEcsT0FBT3RCLEtBQU1wRixLQUFOLENBQVg7O0FBQ0EsY0FBSTBHLEtBQUt4RyxNQUFMLENBQUosRUFBa0I7QUFDaEJzRyxrQkFBTS9JLE9BQU9tSSxJQUFiLEVBQW1CWSxLQUFuQjs7QUFDQSxnQkFBSSxPQUFPSixVQUFVM0ksT0FBT21JLElBQWpCLENBQVAsS0FBa0MsV0FBdEMsRUFBa0Q7QUFDaEQsNEJBQU1RLFVBQVUzSSxPQUFPbUksSUFBakIsRUFBdUIxRixNQUF2QixDQUFOO0FBQ0Q7O0FBQ0Q7QUFDRDtBQUNGO0FBQ0YsT0FaRCxDQURJLEVBY0o4RixPQWRJLENBQU4sRUFsQnVELENBbUN2RDs7QUFDQSxhQUFPUSxLQUFQO0FBRUQsS0F0Q0Q7QUFBQTs7QUFoQ29DLEM7Ozs7Ozs7Ozs7O0FDakJ0Q2xNLE9BQU95SyxNQUFQLENBQWM7QUFBQ08sYUFBVSxNQUFJQSxTQUFmO0FBQXlCN0YsU0FBTSxNQUFJQTtBQUFuQyxDQUFkO0FBQXlELElBQUl3RixLQUFKO0FBQVUzSyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUN5SyxRQUFNdkssQ0FBTixFQUFRO0FBQUN1SyxZQUFNdkssQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJeUMsS0FBSjtBQUFVN0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFRbk4sTUFBTWlNLFNBQVMsSUFBSTFCLE1BQU1DLFVBQVYsQ0FBcUIsUUFBckIsRUFBK0I7QUFDNUNDLGdCQUFjO0FBRDhCLENBQS9CLENBQWY7O0FBSU8sTUFBTUcsU0FBTixDQUFnQjtBQUlyQkUsY0FBWTdILE9BQVosRUFBcUI7QUFDbkIsU0FBS0EsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBZ0ksWUFBVTtBQUNSLFdBQU8sS0FBS2hJLE9BQUwsQ0FBYWlKLFlBQXBCO0FBQ0Q7O0FBRURQLGVBQWE7QUFDWCxXQUFPLEtBQUsxSSxPQUFaO0FBQ0Q7O0FBRURLLFVBQVE2SSxXQUFrQjNHLE1BQVAsNkJBQWtCLENBQUUsQ0FBcEIsQ0FBbkIsRUFBeUM4RixVQUFpQnJILENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQW5ELEVBQW9FLENBQUU7O0FBckJqRDs7QUF5QmhCLE1BQU1jLEtBQU4sU0FBb0I2RixTQUFwQixDQUE4QjtBQUVuQ0UsY0FBWXNCLE9BQVosRUFBcUI7QUFFbkIsUUFBSW5KLFVBQVVnSixPQUFPakIsT0FBUCxDQUFlO0FBQzNCcEcsV0FBS3dIO0FBRHNCLEtBQWYsQ0FBZDtBQUlBLFVBQU1uSixPQUFOO0FBRUEsUUFBSW9HLE9BQU8sS0FBSzRCLE9BQUwsRUFBWDs7QUFFQSxZQUFRNUIsS0FBSzZCLElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSTFJLEtBQUosQ0FBVTRHLEtBQUs3RSxJQUFmLENBQWI7O0FBQ0EsYUFBSzRHLE1BQUwsR0FBcUIxSixHQUFQLDZCQUFlO0FBQzNCLGNBQUkrRCxNQUFPLGlCQUFnQjRELEtBQUtrQyxLQUFNLFlBQVc3SixJQUFJMkssR0FBSSxTQUFRM0ssSUFBSXFHLEVBQUcsR0FBeEU7QUFDQSwrQkFBYSxLQUFLb0QsS0FBTCxDQUFXN0YsS0FBWCxDQUFpQkcsR0FBakIsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFDRjtBQUNFLGNBQU0sSUFBSWdHLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBVEo7QUFZRDtBQUdEOzs7Ozs7QUFJQW5JLFVBQVE2SSxXQUFrQjNHLE1BQVAsNkJBQWtCLENBQUUsQ0FBcEIsQ0FBbkIsRUFBeUM4RixVQUFpQnJILENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQW5ELEVBQW9FO0FBRWxFLFFBQUlxSSxNQUFNTCxPQUFPeEMsSUFBUCxDQUFZO0FBQ3BCMkMsZUFBUyxLQUFLbkosT0FBTCxDQUFhMkI7QUFERixLQUFaLEVBRVA7QUFDRDJILGNBQVE7QUFDTjNILGFBQUssQ0FEQztBQUVObUQsWUFBSSxDQUZFO0FBR05zRSxhQUFLO0FBSEM7QUFEUCxLQUZPLENBQVY7QUFVQSxXQUFPLElBQUlHLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFFbkJKLFVBQUlLLE9BQUosQ0FDRSxDQUFPakwsR0FBUCxFQUFZa0wsS0FBWiw4QkFBc0I7QUFDcEIsWUFBSTtBQUNGLGNBQUlwSCx1QkFBZSxLQUFLNEYsTUFBTCxDQUFZMUosR0FBWixDQUFmLENBQUo7QUFDQSx3QkFBTXlLLFNBQVMzRyxNQUFULENBQU47QUFDRCxTQUhELENBR0UsT0FBT3ZCLENBQVAsRUFBVTtBQUNWcUgsa0JBQVFySCxDQUFSO0FBQ0Q7O0FBQ0QsWUFBSTJJLFFBQVEsQ0FBUixLQUFjTixJQUFJUixLQUFKLEVBQWxCLEVBQStCO0FBQzdCVztBQUNEO0FBQ0YsT0FWRCxDQURGO0FBYUQsS0FoQkksRUFpQkxJLEtBakJLLENBa0JKNUksQ0FBRCxJQUFPO0FBQ0wsWUFBTUEsQ0FBTjtBQUNELEtBcEJJLENBQVA7QUF1QkQ7O0FBbEVrQyxDOzs7Ozs7Ozs7OztBQ3JDckNyRSxPQUFPeUssTUFBUCxDQUFjO0FBQUNsSyxXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJb0ssS0FBSjtBQUFVM0ssT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDeUssUUFBTXZLLENBQU4sRUFBUTtBQUFDdUssWUFBTXZLLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFeEMsTUFBTUcsVUFBVSxJQUFJb0ssTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUErQjtBQUFDQyxnQkFBYTtBQUFkLENBQS9CLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDRlA3SyxPQUFPeUssTUFBUCxDQUFjO0FBQUM3SCxZQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJQyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFO0FBQTBFLElBQUlzRSxXQUFKO0FBQWdCMUUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDd0UsY0FBWXRFLENBQVosRUFBYztBQUFDc0Usa0JBQVl0RSxDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFOztBQUtwSSxNQUFNd0MsUUFBTixDQUFlO0FBRXBCc0ksY0FBWUssUUFBUSxJQUFJMUksS0FBSixFQUFwQixFQUFpQztBQUMvQixTQUFLcUssTUFBTCxHQUFjM0IsS0FBZDtBQUNEOztBQUdLckgsa0JBQU4sQ0FBdUIxQyxJQUF2QjtBQUFBLG9DQUE2QjtBQUUzQixVQUFJMkMsYUFBYTNDLEtBQUsyQyxVQUF0QjtBQUVBLFVBQUlLLE1BQU0sRUFBVjs7QUFFQSxVQUFJMkksUUFBZXBLLEdBQVAsNkJBQWU7QUFDekJ5QixZQUFJeUgsSUFBSixlQUNRLEtBQUtpQixNQUFMLENBQVlqRixXQUFaLENBQ0osaUJBREksRUFFSixFQUZJLEVBR0o7QUFDRW1GLHNCQUFZNUwsS0FBSzRMLFVBRG5CO0FBRUVySyxlQUFLQSxHQUZQO0FBR0VvQixzQkFBWUE7QUFIZCxTQUhJLENBRFI7QUFTTSxPQVZJLENBQVo7O0FBWUEsVUFBSWtKLFNBQWdCdEssR0FBUCw2QkFBZTtBQUMxQixZQUFJOEMsTUFBTzs7MkJBRVVyRSxLQUFLNEwsVUFBVyxjQUFhckssR0FBSTtPQUZ0RDtBQUlBeUIsWUFBSXlILElBQUosZUFBZ0IsS0FBS2lCLE1BQUwsQ0FBWXhILEtBQVosQ0FBa0JHLEdBQWxCLENBQWhCO0FBQ0QsT0FOWSxDQUFiOztBQVFBLFdBQUssSUFBSXlILE1BQVQsSUFBbUI5TCxLQUFLK0wsSUFBeEIsRUFBOEI7QUFDNUIsZ0JBQVFELE9BQU9FLEdBQWY7QUFDRSxlQUFLLElBQUw7QUFDRSwwQkFBTUwsTUFBTUcsT0FBT3ZLLEdBQWIsQ0FBTjtBQUNBOztBQUNGLGVBQUssS0FBTDtBQUNFLDBCQUFNc0ssT0FBT0MsT0FBT3ZLLEdBQWQsQ0FBTjtBQUNBO0FBTko7QUFRRDs7QUFFRCxhQUFPO0FBQ0x5QixhQUFLQTtBQURBLE9BQVA7QUFJRCxLQXpDRDtBQUFBOztBQTJDTUMsb0JBQU4sQ0FBeUJqRCxJQUF6QjtBQUFBLG9DQUErQjtBQUU3QixVQUFJNEwsYUFBYTVMLEtBQUs0TCxVQUF0QjtBQUNBLFVBQUlLLFNBQVNqTSxLQUFLaU0sTUFBbEI7QUFDQSxVQUFJdEosYUFBYTNDLEtBQUsyQyxVQUF0QjtBQUVBLFVBQUlLLE1BQU0sRUFBVixDQU42QixDQVE3Qjs7QUFDQSxVQUFJcUIsTUFBTyxvREFBbUR1SCxVQUFXLEVBQXpFO0FBQ0E1SSxVQUFJeUgsSUFBSixlQUFlLEtBQUtpQixNQUFMLENBQVl4SCxLQUFaLENBQWtCRyxHQUFsQixDQUFmLEdBVjZCLENBWTdCOztBQUNBLFdBQUssSUFBSTZILElBQUksQ0FBYixFQUFnQkEsSUFBSUQsT0FBT0UsTUFBM0IsRUFBbUNELEdBQW5DLEVBQXdDO0FBRXRDLGFBQUtSLE1BQUwsQ0FBWWpGLFdBQVosQ0FDRSxtQkFERixFQUN1QjtBQUNuQm1GLHNCQUFZQSxVQURPO0FBRW5Cakosc0JBQVlBLFVBRk87QUFHbkJ5SixxQkFBV0gsT0FBT0MsQ0FBUCxDQUhRO0FBSW5CRyxnQkFBTUgsSUFBSTtBQUpTLFNBRHZCLEVBTUs7QUFDRDVGLHVCQUFhO0FBRFosU0FOTDtBQVVEOztBQUVELGFBQU87QUFDTHRELGFBQUtBO0FBREEsT0FBUDtBQUlELEtBL0JEO0FBQUE7O0FBaUNNUCxlQUFOLENBQW9CekMsSUFBcEI7QUFBQSxvQ0FBMEI7QUFFeEIsVUFBSXNNLGNBQWMsRUFBbEI7QUFDQSxVQUFJQyxPQUFPLEVBQVgsQ0FId0IsQ0FLeEI7O0FBRUFBLGFBQU8sQ0FDTCxRQURLLEVBRUwsTUFGSyxFQUdMLE1BSEssRUFJTCxrQkFKSyxFQUtMLG9CQUxLLEVBTUwsYUFOSyxFQU9MLFdBUEssQ0FBUDs7QUFTQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJdk0sS0FBS3dNLENBQUwsQ0FBSixFQUFhRixZQUFZRSxDQUFaLElBQWlCeE0sS0FBS3dNLENBQUwsQ0FBakI7QUFDZDs7QUFFRCxXQUFLZCxNQUFMLENBQVllLFdBQVosQ0FDRSxhQURGLEVBRUcsZ0JBQWV6TSxLQUFLNEwsVUFBVyxFQUZsQyxFQUdFVSxXQUhGLEVBR2U7QUFDWC9GLHFCQUFhO0FBREYsT0FIZixFQXBCd0IsQ0E0QnhCOztBQUVBK0Ysb0JBQWMsRUFBZDtBQUNBQyxhQUFPLENBQ0wsa0JBREssRUFFTCxjQUZLLEVBR0wsWUFISyxFQUlMLFNBSkssRUFLTCxTQUxLLEVBTUwsY0FOSyxDQUFQOztBQVFBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUl2TSxLQUFLd00sQ0FBTCxDQUFKLEVBQWFGLFlBQVlFLENBQVosSUFBaUJ4TSxLQUFLd00sQ0FBTCxDQUFqQjtBQUNkOztBQUVELFVBQUl4SixNQUFNLEtBQUswSSxNQUFMLENBQVllLFdBQVosQ0FDUixtQkFEUSxFQUVQLGdCQUFlek0sS0FBSzRMLFVBQVcsRUFGeEIsRUFHUlUsV0FIUSxFQUdLO0FBQ1gvRixxQkFBYTtBQURGLE9BSEwsQ0FBVjtBQVFBLGFBQU87QUFDTHZELGFBQUtBO0FBREEsT0FBUDtBQUlELEtBdkREO0FBQUE7O0FBeURNTSxlQUFOLENBQW9CdEQsSUFBcEI7QUFBQSxvQ0FBMEI7QUFFeEIsVUFBSTJDLGFBQWEzQyxLQUFLMkMsVUFBdEI7QUFFQSxVQUFJSyxNQUFNLEVBQVY7QUFFQSxVQUFJc0osY0FBYyxFQUFsQjtBQUNBLFVBQUlDLE9BQU8sRUFBWDtBQUVBQSxhQUFPLENBQ0wsTUFESyxFQUVMLG9CQUZLLENBQVAsQ0FUd0IsQ0FheEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSXZNLEtBQUt3TSxDQUFMLENBQUosRUFBYUYsWUFBWUUsQ0FBWixJQUFpQnhNLEtBQUt3TSxDQUFMLENBQWpCO0FBQ2Q7O0FBRUR4SixVQUFJNEksVUFBSixpQkFBdUIsS0FBS0YsTUFBTCxDQUFZakYsV0FBWixDQUNyQixhQURxQixFQUVyQjZGLFdBRnFCLEVBRVI7QUFDWDNKLG9CQUFZQSxVQUREO0FBRVg0QixnQkFBUSxDQUZHO0FBR1g4QixjQUFNLE1BSEs7QUFJWHFHLDBCQUFrQixNQUpQO0FBS1hDLHFCQUFhLE1BTEY7QUFNWEMsbUJBQVcsTUFOQTtBQU9YdEcscUJBQWEsT0FQRjtBQVFYQyxxQkFBYTtBQVJGLE9BRlEsQ0FBdkI7QUFlQStGLG9CQUFjLEVBQWQ7QUFDQUMsYUFBTyxDQUNMLGNBREssRUFFTCxpQkFGSyxFQUdMLFNBSEssRUFJTCxTQUpLLENBQVAsQ0F0Q3dCLENBNEN4QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUl2TSxLQUFLd00sQ0FBTCxDQUFKLEVBQWFGLFlBQVlFLENBQVosSUFBaUJ4TSxLQUFLd00sQ0FBTCxDQUFqQjtBQUNkOztBQUVEeEosVUFBSTZKLGdCQUFKLGlCQUE2QixLQUFLbkIsTUFBTCxDQUFZakYsV0FBWixDQUMzQixtQkFEMkIsRUFFM0I2RixXQUYyQixFQUVkO0FBQ1gzSixvQkFBWUEsVUFERDtBQUVYaUosb0JBQVk1SSxJQUFJNEksVUFGTDtBQUdYa0IsZUFBTyxDQUhJO0FBSVhDLHlCQUFpQixDQUpOO0FBS1hDLDRCQUFvQixNQUxUO0FBTVhDLDRCQUFvQixNQU5UO0FBT1hDLDBCQUFrQixNQVBQO0FBUVhDLG9CQUFZLE1BUkQ7QUFTWEMsc0JBQWMsTUFUSDtBQVVYOUcscUJBQWEsT0FWRjtBQVdYQyxxQkFBYTtBQVhGLE9BRmMsQ0FBN0I7O0FBaUJBLFdBQUssSUFBSWlHLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJdk0sS0FBS3dNLENBQUwsQ0FBSixFQUFhRixZQUFZRSxDQUFaLElBQWlCeE0sS0FBS3dNLENBQUwsQ0FBakI7QUFDZDs7QUFFRHhKLFVBQUlxSyxnQkFBSixpQkFBNkIsS0FBSzNCLE1BQUwsQ0FBWWpGLFdBQVosQ0FDM0IsbUJBRDJCLEVBQ04sRUFETSxFQUNGO0FBQ3ZCb0csMEJBQWtCN0osSUFBSTZKLGdCQURDO0FBRXZCbEssb0JBQVlBLFVBRlc7QUFHdkJtSyxlQUFPLENBSGdCO0FBSXZCeEcscUJBQWEsT0FKVTtBQUt2QkMscUJBQWE7QUFMVSxPQURFLENBQTdCLEVBM0V3QixDQXFGeEI7O0FBQ0EsYUFBTztBQUNMdkQsYUFBS0E7QUFEQSxPQUFQO0FBSUQsS0ExRkQ7QUFBQTs7QUE1SW9CLEM7Ozs7Ozs7Ozs7O0FDTHRCeEUsT0FBT3lLLE1BQVAsQ0FBYztBQUFDcUUsbUJBQWdCLE1BQUlBLGVBQXJCO0FBQXFDQyxZQUFTLE1BQUlBLFFBQWxEO0FBQTJEQyxpQkFBYyxNQUFJQSxhQUE3RTtBQUEyRnJNLGlCQUFjLE1BQUlBO0FBQTdHLENBQWQ7QUFBMkksSUFBSWdJLEtBQUo7QUFBVTNLLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ3lLLFFBQU12SyxDQUFOLEVBQVE7QUFBQ3VLLFlBQU12SyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTBLLElBQUo7QUFBUzlLLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMwSyxXQUFLMUssQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJMkssT0FBSjtBQUFZL0ssT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzJLLGNBQVEzSyxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEO0FBQStELElBQUl5QyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDeUMsWUFBTXpDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXNFLFdBQUo7QUFBZ0IxRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUN3RSxjQUFZdEUsQ0FBWixFQUFjO0FBQUNzRSxrQkFBWXRFLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7O0FBT3RmLE1BQU0wTyxlQUFOLENBQXNCO0FBQzNCNUQsY0FBWXpCLElBQVosRUFBa0JwRyxPQUFsQixFQUEyQjtBQUN6QixRQUFJNEwsUUFBSjs7QUFDQSxZQUFReEYsS0FBSzZCLElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRTJELG1CQUFXLElBQUlELGFBQUosQ0FBa0J2RixJQUFsQixFQUF3QnBHLE9BQXhCLENBQVg7QUFGSjs7QUFLQSxXQUFPNEwsUUFBUDtBQUNEOztBQVQwQjs7QUFZdEIsTUFBTUYsUUFBTixDQUFlO0FBQ3BCO0FBR0E3RCxjQUFZekIsSUFBWixFQUFrQnBHLE9BQWxCLEVBQTJCO0FBQ3pCLFNBQUtvRyxJQUFMLEdBQVlBLElBQVo7QUFDQSxTQUFLcEcsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7O0FBRUQsU0FBTzZMLE9BQVAsQ0FBZXpGLElBQWYsRUFBcUJwRyxPQUFyQixFQUE4QjtBQUM1QixRQUFJNEwsUUFBSjs7QUFDQSxZQUFReEYsS0FBSzZCLElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxlQUFPLElBQUkwRCxhQUFKLENBQWtCdkYsSUFBbEIsRUFBd0JwRyxPQUF4QixDQUFQOztBQUNGO0FBQ0UsY0FBTSxJQUFJd0ksS0FBSixDQUFVLG1CQUFWLENBQU47QUFKSjtBQU1EOztBQUVEc0QsYUFBVztBQUNULFdBQU8sS0FBSzFGLElBQVo7QUFDRDs7QUFFRDJGLGFBQVc7QUFDVCxXQUFPLEtBQUszRixJQUFMLENBQVU3RSxJQUFqQjtBQUNEOztBQUVEeUssZ0JBQWM7QUFDWixXQUFPLEtBQUtoTSxPQUFaO0FBQ0Q7O0FBRURpTSxxQkFDRUMsS0FBSyxDQUFPOUQsV0FBVzdGLFVBQVUsQ0FBRSxDQUE5QixFQUFnQzhGLFVBQVVySCxLQUFLLENBQUUsQ0FBakQsOEJBQXNELENBQUUsQ0FBeEQsQ0FEUCxFQUVFO0FBQ0EsU0FBS21ILE1BQUwsR0FBYytELEVBQWQ7QUFDRDtBQUVEOzs7Ozs7Ozs7OztBQVNNN0wsU0FBTixDQUFjOEwsWUFBWSxFQUExQjtBQUFBLG9DQUE4QjtBQUM1QixVQUFJbk0sVUFBVSxLQUFLZ00sV0FBTCxFQUFkLENBRDRCLENBRzVCOztBQUNBaE0sY0FBUTJJLE9BQVIsQ0FBZ0JDLElBQWhCLENBQXFCO0FBQ25CakssY0FBTSxNQURhO0FBRW5CMEQsZUFBTztBQUZZLE9BQXJCO0FBS0EsVUFBSStKLFVBQVUsRUFBZDs7QUFDQSxXQUFLLElBQUlDLENBQVQsSUFBY3JNLFFBQVEySSxPQUF0QixFQUErQixDQUM5Qjs7QUFFRCxVQUFJQSxVQUFVLEVBQWQ7O0FBRUEsV0FBSyxJQUFJMEQsQ0FBVCxJQUFjck0sUUFBUTJJLE9BQXRCLEVBQStCO0FBQzdCeUQsZ0JBQVFDLEVBQUUxTixJQUFWLElBQWtCO0FBQ2hCMEQsaUJBQU9nSyxFQUFFaEssS0FETztBQUVoQmlLLGlCQUFPLE9BQU9ELEVBQUVDLEtBQVQsS0FBbUIsV0FBbkIsR0FBaUNELEVBQUVDLEtBQW5DLEdBQTJDLENBRmxDO0FBR2hCekQsaUJBQU87QUFIUyxTQUFsQjtBQUtBRixnQkFBUUMsSUFBUixDQUNFO0FBQ0VqSyxnQkFBTTBOLEVBQUUxTixJQURWO0FBRUVvSyxnQkFBTXRCLEtBQU1DLFFBQVFvQixRQUFSLENBQWlCdUQsRUFBRWhLLEtBQW5CLENBQU47QUFGUixTQURGO0FBTUQ7O0FBRUQsb0JBQU0sS0FBSzhGLE1BQUwsQ0FDSixDQUFPNUYsTUFBUCxFQUFlaEMsT0FBZiw4QkFBMkI7QUFFekIsYUFBSyxJQUFJOEwsQ0FBVCxJQUFjMUQsT0FBZCxFQUF1QjtBQUVyQjtBQUNBLGNBQUk0RCxJQUFJSCxRQUFRQyxFQUFFMU4sSUFBVixDQUFSOztBQUNBLGNBQUk0TixFQUFFRCxLQUFOLEVBQWE7QUFDWCxnQkFBSUMsRUFBRTFELEtBQUYsSUFBVzBELEVBQUVELEtBQWpCLEVBQXdCO0FBQ3RCO0FBQ0Q7QUFDRjs7QUFFRCxjQUFJRCxFQUFFdEQsSUFBRixDQUFPeEcsTUFBUCxDQUFKLEVBQW9CO0FBRWxCO0FBQ0FnSyxjQUFFMUQsS0FBRixHQUhrQixDQUtsQjs7QUFDQSxnQkFBSSxPQUFPc0QsVUFBVUUsRUFBRTFOLElBQVosQ0FBUCxLQUE2QixXQUFqQyxFQUE4QztBQUM1Qyw0QkFBTXdOLFVBQVVFLEVBQUUxTixJQUFaLEVBQWtCNEQsTUFBbEIsRUFBMEJoQyxPQUExQixDQUFOO0FBQ0Q7O0FBQ0Q7QUFFRDtBQUNGO0FBQ0YsT0F6QkQsQ0FESSxDQUFOLEVBN0I0QixDQXlENUI7O0FBQ0EsYUFBTzZMLE9BQVA7QUFDRCxLQTNERDtBQUFBOztBQTlDb0I7O0FBOEdmLE1BQU1ULGFBQU4sU0FBNEJELFFBQTVCLENBQXFDO0FBQzFDN0QsY0FBWXpCLElBQVosRUFBa0JwRyxPQUFsQixFQUEyQjtBQUN6QixVQUFNb0csSUFBTixFQUFZcEcsT0FBWjtBQUVBLFFBQUl1QixPQUFPLEtBQUt3SyxRQUFMLEVBQVg7QUFFQSxTQUFLN0QsS0FBTCxHQUFhLElBQUkxSSxLQUFKLENBQVUrQixJQUFWLENBQWI7QUFDQSxTQUFLMEssa0JBQUwsQ0FBd0IsQ0FBTzdELFFBQVAsRUFBaUJDLE9BQWpCLDhCQUE2QjtBQUNuRCxVQUFJN0YsTUFBTyxpQkFBZ0I0RCxLQUFLa0MsS0FBTSxFQUF0QztBQUNBLDJCQUFhLEtBQUtKLEtBQUwsQ0FBV0ssY0FBWCxDQUEwQi9GLEdBQTFCLEVBQStCNEYsUUFBL0IsRUFBMENwSCxDQUFELElBQUs7QUFBQyxjQUFNQSxDQUFOO0FBQVEsT0FBdkQsQ0FBYjtBQUNELEtBSHVCLENBQXhCO0FBSUQ7O0FBWHlDOztBQW1CckMsTUFBTTFCLGFBQU4sU0FBNEJvTSxRQUE1QixDQUFxQztBQUMxQzdELGNBQVl6QixJQUFaLEVBQWtCcEcsT0FBbEIsRUFBMkI7QUFDekIsVUFBTW9HLElBQU4sRUFBWXBHLE9BQVosRUFEeUIsQ0FHekI7O0FBQ0EsU0FBS2lNLGtCQUFMLENBQXdCLENBQU83RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFFbkQsVUFBSW1FLE1BQUo7QUFDQUEsNkJBQWVuTCxZQUFZb0wsT0FBWixDQUFvQnJHLEtBQUtzRyxHQUF6QixDQUFmLEVBSG1ELENBS25EOztBQUNBLFVBQUl4RyxLQUFLc0csT0FBT3RHLEVBQVAsQ0FBVUUsS0FBS3VHLFFBQWYsQ0FBVDtBQUNBLFVBQUlsTSxhQUFheUYsR0FBR3pGLFVBQUgsQ0FBYzJGLEtBQUszRixVQUFuQixDQUFqQjtBQUVBLFVBQUlGLFVBQVU7QUFDWmlNLGdCQUFRQSxNQURJO0FBRVovTCxvQkFBWUEsVUFGQTtBQUdaa00sa0JBQVV6RztBQUhFLE9BQWQ7QUFNQSxVQUFJbUQsTUFBTTVJLFdBQVcrRixJQUFYLEVBQVY7O0FBRUEsMkJBQWE2QyxJQUFJdUQsT0FBSixFQUFiLEdBQTRCO0FBQzFCLFlBQUluTyxvQkFBWTRLLElBQUl3RCxJQUFKLEVBQVosQ0FBSjtBQUNBLHNCQUFNekUsU0FBUzNKLEdBQVQsRUFBYzhCLE9BQWQsQ0FBTjtBQUNEOztBQUFBO0FBRUYsS0F0QnVCLENBQXhCO0FBd0JEOztBQTdCeUMsQzs7Ozs7Ozs7Ozs7QUNwSjVDNUQsT0FBT3lLLE1BQVAsQ0FBYztBQUFDdEssV0FBUSxNQUFJMkM7QUFBYixDQUFkO0FBQTRDLElBQUkwRyxlQUFKO0FBQW9CeEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDc0osa0JBQWdCcEosQ0FBaEIsRUFBa0I7QUFBQ29KLHNCQUFnQnBKLENBQWhCO0FBQWtCOztBQUF0QyxDQUF0QyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJRyxPQUFKO0FBQVlQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNLLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTlDLEVBQXNFLENBQXRFOztBQUc5SSxNQUFNMEMsY0FBTixDQUFvQjtBQUUzQnNILE1BQU4sQ0FBV1gsSUFBWDtBQUFBLG9DQUFnQjtBQUVkQSxXQUFLM0YsVUFBTCxHQUFrQixPQUFsQjtBQUNBLFdBQUtxTSxLQUFMLGlCQUFtQjNHLGdCQUFnQkksR0FBaEIsQ0FBcUJ3RyxPQUFPQyxNQUFQLENBQWM7QUFBQ3ZNLG9CQUFXO0FBQVosT0FBZCxFQUFtQzJGLElBQW5DLENBQXJCLENBQW5CO0FBQ0EsV0FBSzZHLFFBQUwsaUJBQXNCOUcsZ0JBQWdCSSxHQUFoQixDQUFxQndHLE9BQU9DLE1BQVAsQ0FBYztBQUFDdk0sb0JBQVc7QUFBWixPQUFkLEVBQXNDMkYsSUFBdEMsQ0FBckIsQ0FBdEI7QUFFRCxLQU5EO0FBQUE7O0FBUU04RyxVQUFOLENBQWdCQyxPQUFoQjtBQUFBLG9DQUF5QjtBQUV2QixVQUFJQyx3QkFBZ0IsS0FBS04sS0FBTCxDQUFXL0UsT0FBWCxDQUFtQjtBQUFFcEcsYUFBS3dMO0FBQVAsT0FBbkIsRUFBb0M7QUFBQzlHLG9CQUFZO0FBQUMscUJBQVU7QUFBWDtBQUFiLE9BQXBDLENBQWhCLENBQUo7QUFDQSxVQUFJZ0gsZUFBZUQsUUFBUUUsT0FBM0IsQ0FIdUIsQ0FLdkI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxVQUFJQyxhQUFhLEVBQWpCOztBQUVBLFdBQUssSUFBSUMsV0FBVCxJQUF3QkgsWUFBeEIsRUFBc0M7QUFFcEMsWUFBSUksZUFBZSxDQUFuQjs7QUFFQSxhQUFLLElBQUkxRCxVQUFULElBQXVCeUQsV0FBdkIsRUFBb0M7QUFFbEMsY0FBSUosd0JBQWdCLEtBQUtILFFBQUwsQ0FBY2xGLE9BQWQsQ0FBc0I7QUFBQ3BHLGlCQUFLb0k7QUFBTixXQUF0QixFQUF3QztBQUFDMUQsd0JBQVc7QUFBQyx1QkFBUTtBQUFUO0FBQVosV0FBeEMsQ0FBaEIsQ0FBSjtBQUNBLGNBQUlxSCxjQUFjTixRQUFRbkMsS0FBMUIsQ0FIa0MsQ0FLbEM7O0FBQ0EsZUFBSyxJQUFJQSxLQUFULElBQWtCeUMsV0FBbEIsRUFBK0I7QUFDN0JELDRCQUFnQnhDLE1BQU0wQyxRQUF0QjtBQUNEO0FBRUY7O0FBRURKLG1CQUFXM0UsSUFBWCxDQUFnQjZFLFlBQWhCO0FBRUQsT0EvQnNCLENBaUN2Qjs7O0FBQ0EsVUFBSUUsV0FBV0MsS0FBS0MsR0FBTCxDQUFTQyxLQUFULENBQWdCLElBQWhCLEVBQXNCUCxVQUF0QixDQUFmO0FBRUEsYUFBT0ksUUFBUDtBQUNELEtBckNEO0FBQUE7QUF1Q0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJNMUcsVUFBTixDQUFnQmpKLFFBQWhCLEVBQTBCMkksS0FBMUIsRUFBaUNDLFNBQVMsSUFBMUMsRUFBZ0RDLFNBQVMsSUFBekQ7QUFBQSxvQ0FBK0Q7QUFFN0Q7QUFDQSxVQUFJdUQsU0FBU2xOLFFBQVFzSixJQUFSLENBQWE7QUFBQ3hJLGtCQUFTQTtBQUFWLE9BQWIsRUFBa0MrUCxLQUFsQyxHQUEwQ0MsR0FBMUMsQ0FBK0NqUixLQUFLQSxFQUFFNkIsZ0JBQXRELENBQWIsQ0FINkQsQ0FLN0Q7O0FBQ0EsVUFBSWtCLFNBQVMsRUFBYjtBQUNBQSxhQUFPNkcsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFhOUcsT0FBT21PLFlBQVAsR0FBc0JySCxNQUF0QjtBQUNiLFVBQUlDLE1BQUosRUFBYS9HLE9BQU9vTyxZQUFQLEdBQXNCckgsTUFBdEI7QUFFYixVQUFJMUYsb0JBQVksS0FBSzJMLEtBQUwsQ0FBV3FCLFVBQVgsQ0FDZHJPLE1BRGMsRUFFZDtBQUNFc08sZUFBTTtBQUNKaEUsa0JBQVE7QUFDTmlFLG1CQUFPakU7QUFERDtBQURKO0FBRFIsT0FGYyxDQUFaLENBQUosQ0FYNkQsQ0FzQjdEOztBQUNBLGFBQU9BLE1BQVA7QUFDRCxLQXhCRDtBQUFBO0FBMEJBOzs7Ozs7Ozs7O0FBUU1sRCxZQUFOLENBQWtCUCxLQUFsQixFQUF5QkMsU0FBUyxJQUFsQyxFQUF3Q0MsU0FBUyxJQUFqRDtBQUFBLG9DQUF1RDtBQUVyRDtBQUNBLFVBQUkvRyxTQUFTLEVBQWI7QUFDQUEsYUFBTzZHLEtBQVAsR0FBZUEsS0FBZjtBQUNBLFVBQUlDLE1BQUosRUFBYTlHLE9BQU9tTyxZQUFQLEdBQXNCckgsTUFBdEI7QUFDYixVQUFJQyxNQUFKLEVBQWEvRyxPQUFPb08sWUFBUCxHQUFzQnJILE1BQXRCO0FBRWIsVUFBSTFGLG9CQUFZLEtBQUsyTCxLQUFMLENBQVdxQixVQUFYLENBQ2RyTyxNQURjLEVBRWQ7QUFDRThCLGNBQUs7QUFDSHdJLGtCQUFRO0FBREw7QUFEUCxPQUZjLENBQVosQ0FBSjtBQVNELEtBakJEO0FBQUE7O0FBbUJBLFNBQU96SixTQUFQLENBQWlCRyxVQUFqQixFQUE2QlIsSUFBN0IsRUFBa0M7QUFDaEMsV0FBTyxJQUFJSyxTQUFKLENBQWNHLFVBQWQsRUFBMEJSLElBQTFCLENBQVA7QUFDRDs7QUE3SGdDOztBQWlJbkMsTUFBTUssU0FBTixDQUFnQjtBQUVka0gsY0FBYS9HLFVBQWIsRUFBeUJSLElBQXpCLEVBQThCO0FBRTVCO0FBQ0EsUUFBSXlKLGFBQWEsTUFBakI7O0FBQ0EsUUFBSXpKLEtBQUtnTyxXQUFULEVBQXNCO0FBQ3BCdkUsbUJBQWF6SixLQUFLZ08sV0FBTCxDQUFpQnZFLFVBQTlCO0FBQ0QsS0FOMkIsQ0FRNUI7QUFDQTs7O0FBQ0EsUUFBSXdFLGFBQWEsRUFBakI7QUFDQSxRQUFHak8sS0FBS3FHLEtBQVIsRUFBZTRILFdBQVczRixJQUFYLENBQWdCdEksS0FBS3FHLEtBQXJCO0FBQ2YsUUFBR3JHLEtBQUsyTixZQUFSLEVBQXNCTSxXQUFXM0YsSUFBWCxDQUFnQnRJLEtBQUsyTixZQUFyQjtBQUN0QixRQUFHM04sS0FBSzROLFlBQVIsRUFBc0JLLFdBQVczRixJQUFYLENBQWdCdEksS0FBSzROLFlBQXJCLEVBYk0sQ0FlNUI7O0FBQ0EsUUFBSU0sZUFBSjs7QUFDQSxZQUFPbE8sS0FBS21PLFFBQVo7QUFDRSxXQUFLLEtBQUw7QUFBWUQsMEJBQWtCLENBQWxCO0FBQXFCOztBQUNqQyxXQUFLLFFBQUw7QUFBZUEsMEJBQWlCLENBQWpCO0FBQW9COztBQUNuQztBQUFVQSwwQkFBa0IsQ0FBbEI7QUFBcUI7QUFIakMsS0FqQjRCLENBdUI1Qjs7O0FBQ0EsUUFBSXRFLE9BQU8sRUFBWDs7QUFDQSxZQUFPNUosS0FBS21PLFFBQVo7QUFDRSxXQUFLLEtBQUw7QUFBWXZFLGFBQUt0QixJQUFMLENBQVU7QUFBQ2xKLGVBQUksQ0FBTDtBQUFPeUssZUFBSTtBQUFYLFNBQVYsRUFBMkI7QUFBQ3pLLGVBQUksQ0FBTDtBQUFPeUssZUFBSTtBQUFYLFNBQTNCO0FBQStDOztBQUMzRCxXQUFLLFFBQUw7QUFBZUQsYUFBS3RCLElBQUwsQ0FBVTtBQUFDbEosZUFBSSxDQUFMO0FBQU95SyxlQUFJO0FBQVgsU0FBVixFQUEyQjtBQUFDekssZUFBSSxDQUFMO0FBQU95SyxlQUFJO0FBQVgsU0FBM0I7QUFBK0M7QUFGaEUsS0F6QjRCLENBOEI1Qjs7O0FBQ0EsUUFBSWhNLE9BQU87QUFDVDRMLGtCQUFZQSxVQURIO0FBRVRwTCxZQUFPLEdBQUU0UCxXQUFXRyxJQUFYLENBQWdCLEdBQWhCLENBQXFCLElBQUdwTyxLQUFLM0IsSUFBSyxJQUFHMkIsS0FBS3FPLFFBQVMsRUFGbkQ7QUFHVEMsMEJBQW9CdE8sS0FBS3VPLFdBSGhCO0FBSVRDLG9CQUFjeE8sS0FBS3FHLEtBSlY7QUFLVG9JLGVBQVN6TyxLQUFLME8sWUFMTDtBQU1UQyxlQUFTM08sS0FBSzRPLFdBTkw7QUFPVDlFLGNBQVE5SixLQUFLOEosTUFQSjtBQVFUb0UsdUJBQWlCQSxlQVJSO0FBU1R0RSxZQUFNQTtBQVRHLEtBQVg7QUFZQTZDLFdBQU9DLE1BQVAsQ0FBZSxJQUFmLEVBQXFCO0FBQUNsTSxrQkFBWUE7QUFBYixLQUFyQjtBQUNBaU0sV0FBT0MsTUFBUCxDQUFlLElBQWYsRUFBcUI3TyxJQUFyQjtBQUNBNE8sV0FBT0MsTUFBUCxDQUFlLElBQWYsRUFBcUIxTSxLQUFLNk8sSUFBTCxDQUFVYixXQUEvQjtBQUVEOztBQWpEYSxDOzs7Ozs7Ozs7OztBQ3BJaEIzUixPQUFPeUssTUFBUCxDQUFjO0FBQUNqQixtQkFBZ0IsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJOUUsV0FBSjtBQUFnQjFFLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ3dFLGNBQVl0RSxDQUFaLEVBQWM7QUFBQ3NFLGtCQUFZdEUsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTs7QUFFOUQsTUFBTW9KLGVBQU4sQ0FBcUI7QUFDMUIsU0FBYUksR0FBYixDQUFpQkgsSUFBakI7QUFBQSxvQ0FBc0I7QUFDcEIsVUFBSW9HLHVCQUFlbkwsWUFBWW9MLE9BQVosQ0FBb0JyRyxLQUFLc0csR0FBekIsQ0FBZixDQUFKO0FBQ0EsVUFBSXhHLEtBQUtzRyxPQUFPdEcsRUFBUCxDQUFVRSxLQUFLdUcsUUFBZixDQUFUO0FBQ0EsYUFBT3pHLEdBQUd6RixVQUFILENBQWMyRixLQUFLM0YsVUFBbkIsQ0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFEMEIsQzs7Ozs7Ozs7Ozs7QUNGNUI5RCxPQUFPeUssTUFBUCxDQUFjO0FBQUN0SyxXQUFRLE1BQUkwQztBQUFiLENBQWQ7QUFBbUMsSUFBSTBJLEtBQUo7QUFBVXZMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxPQUFSLENBQWIsRUFBOEI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNtTCxZQUFNbkwsQ0FBTjtBQUFROztBQUFwQixDQUE5QixFQUFvRCxDQUFwRDtBQUF1RCxJQUFJcVMsTUFBSjtBQUFXelMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3FTLGFBQU9yUyxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREOztBQUloRyxNQUFNeUMsS0FBTixDQUFZO0FBRXpCcUksY0FBWTdILE9BQVosRUFBcUI7QUFDbkI7QUFDQSxTQUFLcVAsSUFBTCxHQUFZbkgsTUFBTW9ILFVBQU4sQ0FBaUJ0UCxPQUFqQixDQUFaLENBRm1CLENBSW5COztBQUNBLFFBQUl1UCxlQUFlO0FBQUNDLDBCQUFtQjtBQUFwQixLQUFuQjtBQUNBekMsV0FBT0MsTUFBUCxDQUFldUMsWUFBZixFQUE2QnZQLE9BQTdCO0FBQ0EsU0FBS3lQLFNBQUwsR0FBaUJ2SCxNQUFNb0gsVUFBTixDQUFpQkMsWUFBakIsQ0FBakI7QUFDRDs7QUFFRCxTQUFPRyxVQUFQLENBQW1CQyxJQUFuQixFQUF5QjtBQUN2QixXQUFPUCxPQUFPTyxJQUFQLEVBQWFDLE1BQWIsR0FBc0J6SyxTQUF0QixDQUFnQyxDQUFoQyxFQUFrQyxFQUFsQyxFQUFzQzBLLE9BQXRDLENBQThDLEdBQTlDLEVBQW1ELEdBQW5ELENBQVA7QUFDRDtBQUVEOzs7Ozs7QUFJQXhOLFFBQU1HLEdBQU4sRUFBVztBQUVUO0FBQ0E7QUFDQSxXQUFPLEtBQUtzTixNQUFMLEdBQ0pDLElBREksQ0FFRkMsR0FBRCxJQUFTO0FBQ1AsYUFBTyxJQUFJekcsT0FBSixDQUNMLENBQU9DLE9BQVAsRUFBZ0JDLE1BQWhCLDhCQUEyQjtBQUN6QjtBQUNBdUcsWUFBSTNOLEtBQUosQ0FBVUcsR0FBVixFQUFlLENBQUN4QixDQUFELEVBQUlHLEdBQUosS0FBWTtBQUN6QjtBQUNBNk8sY0FBSUMsT0FBSjs7QUFDQSxjQUFJalAsQ0FBSixFQUFPO0FBQ0x5SSxtQkFBT3pJLENBQVA7QUFDRCxXQUZELE1BRU93SSxRQUFRckksR0FBUjtBQUNSLFNBTkQ7QUFPRCxPQVRELENBREssQ0FBUDtBQWFELEtBaEJFLEVBa0JKeUksS0FsQkksQ0FrQkc1SSxDQUFELElBQU87QUFDWixZQUFNQSxDQUFOO0FBQ0QsS0FwQkksQ0FBUDtBQXFCRDs7QUFFS2tQLGNBQU4sQ0FBbUIxTixHQUFuQjtBQUFBLG9DQUF1QjtBQUNyQixVQUFJckIsb0JBQVksS0FBS2tCLEtBQUwsQ0FBV0csR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPckIsSUFBSWdQLFFBQVg7QUFDRCxLQUhEO0FBQUE7QUFLQTs7Ozs7Ozs7QUFNT3ZMLGFBQU4sQ0FBa0IwRCxLQUFsQixFQUF5Qm5LLE9BQU8sRUFBaEMsRUFBb0NpUyxXQUFXLEVBQS9DO0FBQUEsb0NBQWtEO0FBRWpEO0FBQ0E7QUFFQSxVQUFJNU4sTUFBTyxlQUFjOEYsS0FBTSxHQUEvQjtBQUVBLFVBQUkwRixNQUFNLElBQUlxQyxHQUFKLEVBQVY7O0FBQ0EsV0FBSyxJQUFJMUYsQ0FBVCxJQUFjb0MsT0FBT3JDLElBQVAsQ0FBWXZNLElBQVosQ0FBZCxFQUFpQztBQUUvQixZQUFJQSxLQUFLd00sQ0FBTCxNQUFZLElBQWhCLEVBQXFCO0FBQ25CcUQsY0FBSTdELEdBQUosQ0FBUVEsQ0FBUixFQUFXLE1BQVg7QUFDRCxTQUZELE1BR0ssSUFBSXhNLEtBQUt3TSxDQUFMLEVBQVE5QyxXQUFSLENBQW9CbEosSUFBcEIsS0FBNkIsTUFBakMsRUFBeUM7QUFDNUM7QUFDQXFQLGNBQUk3RCxHQUFKLENBQVFRLENBQVIsRUFBWSxJQUFHbkwsTUFBTWtRLFVBQU4sQ0FBaUJ2UixLQUFLd00sQ0FBTCxDQUFqQixDQUEwQixHQUF6QztBQUNELFNBSEksTUFJRDtBQUNGcUQsY0FBSTdELEdBQUosQ0FBUVEsQ0FBUixFQUFZLElBQUd4TSxLQUFLd00sQ0FBTCxDQUFRLEdBQXZCO0FBQ0Q7QUFFRjs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBY29DLE9BQU9yQyxJQUFQLENBQVkwRixRQUFaLENBQWQsRUFBcUM7QUFDbkNwQyxZQUFJN0QsR0FBSixDQUFRUSxDQUFSLEVBQVd5RixTQUFTekYsQ0FBVCxNQUFnQixJQUFoQixHQUF1QixNQUF2QixHQUFnQ3lGLFNBQVN6RixDQUFULENBQTNDO0FBQ0Q7O0FBRURuSSxhQUFRLEtBQUksQ0FBQyxHQUFHd0wsSUFBSXRELElBQUosRUFBSixFQUFnQmdFLElBQWhCLENBQXFCLEdBQXJCLENBQTBCLEtBQXRDO0FBRUFsTSxhQUFRLFdBQVUsQ0FBQyxHQUFHd0wsSUFBSXNDLE1BQUosRUFBSixFQUFrQjVCLElBQWxCLENBQXVCLEdBQXZCLENBQTRCLEtBQTlDO0FBRUEsVUFBSXZOLG9CQUFZLEtBQUtrQixLQUFMLENBQVdHLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT3JCLElBQUlnUCxRQUFYO0FBRUQsS0FqQ0E7QUFBQTtBQW1DRDs7Ozs7Ozs7O0FBT012RixhQUFOLENBQWtCdEMsS0FBbEIsRUFBeUJ4SSxNQUF6QixFQUFpQzNCLElBQWpDLEVBQXVDaVMsUUFBdkM7QUFBQSxvQ0FBZ0Q7QUFDOUMsVUFBSTVOLE1BQU8sVUFBUzhGLEtBQU0sT0FBMUI7QUFFQSxVQUFJaUksVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSTVGLENBQVQsSUFBY29DLE9BQU9yQyxJQUFQLENBQVl2TSxJQUFaLENBQWQsRUFBaUM7QUFDL0JvUyxnQkFBUTNILElBQVIsQ0FBYyxHQUFFK0IsQ0FBRSxLQUFJeE0sS0FBS3dNLENBQUwsQ0FBUSxHQUE5QjtBQUNEOztBQUNELFdBQUssSUFBSUEsQ0FBVCxJQUFjb0MsT0FBT3JDLElBQVAsQ0FBWTBGLFFBQVosQ0FBZCxFQUFxQztBQUNuQ0csZ0JBQVEzSCxJQUFSLENBQWMsR0FBRStCLENBQUUsSUFBR3lGLFNBQVN6RixDQUFULENBQVksRUFBakM7QUFDRDs7QUFDRG5JLGFBQU8rTixRQUFRN0IsSUFBUixDQUFhLEdBQWIsQ0FBUDtBQUVBbE0sYUFBUSxVQUFTMUMsTUFBTyxHQUF4QjtBQUVBLFVBQUlxQixvQkFBWSxLQUFLa0IsS0FBTCxDQUFXRyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9yQixHQUFQO0FBQ0QsS0FoQkQ7QUFBQSxHQXBHeUIsQ0FzSHpCOzs7QUFDTXFQLFlBQU4sQ0FBaUJoTyxHQUFqQjtBQUFBLG9DQUFzQjtBQUNwQixVQUFJaU8sV0FBVyxLQUFLcEIsSUFBcEI7QUFDQSxXQUFLQSxJQUFMLEdBQVksS0FBS0ksU0FBakI7O0FBQ0EsVUFBRztBQUNELFlBQUl0TyxvQkFBWSxLQUFLa0IsS0FBTCxDQUFXRyxHQUFYLENBQVosQ0FBSjtBQUNBLGVBQU9yQixHQUFQO0FBQ0QsT0FIRCxTQUlPO0FBQ0wsYUFBS2tPLElBQUwsR0FBWW9CLFFBQVo7QUFDRDtBQUNGLEtBVkQ7QUFBQTs7QUFZTUMsa0JBQU47QUFBQSxvQ0FBd0I7QUFDdEIsb0JBQU0sS0FBS3JPLEtBQUwsQ0FBWSxvQkFBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNc08sUUFBTjtBQUFBLG9DQUFjO0FBQ1osb0JBQU0sS0FBS3RPLEtBQUwsQ0FBWSxTQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSU11TyxVQUFOO0FBQUEsb0NBQWdCO0FBQ2Qsb0JBQU0sS0FBS3ZPLEtBQUwsQ0FBWSxXQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSUFrRyxpQkFBZS9GLEdBQWYsRUFBb0I0RixXQUFZN0YsTUFBRCxJQUFZLENBQUUsQ0FBN0MsRUFBK0M4RixVQUFXckgsQ0FBRCxJQUFPLENBQUUsQ0FBbEUsRUFBb0U7QUFDbEUsV0FBTyxLQUFLOE8sTUFBTCxHQUNKQyxJQURJLENBRUZDLEdBQUQsSUFBUztBQUNQLGFBQU8sSUFBSXpHLE9BQUosQ0FDTCxDQUFPQyxPQUFQLEVBQWdCQyxNQUFoQiw4QkFBMkI7QUFDekI7QUFDQXVHLFlBQUkzTixLQUFKLENBQVVHLEdBQVYsRUFDR3FPLEVBREgsQ0FDTSxRQUROLEVBRUt0TyxNQUFELElBQVk7QUFDVnlOLGNBQUljLEtBQUo7QUFDQTFJLG1CQUFTN0YsTUFBVDtBQUNBeU4sY0FBSWUsTUFBSjtBQUNELFNBTkwsRUFPR0YsRUFQSCxDQU9NLE9BUE4sRUFPZ0I3UCxDQUFELElBQU87QUFDbEJxSCxrQkFBUXJILENBQVI7QUFDRCxTQVRILEVBVUc2UCxFQVZILENBVU0sS0FWTixFQVVhLE1BQU07QUFDZmIsY0FBSUMsT0FBSjtBQUNBekc7QUFDRCxTQWJIO0FBY0QsT0FoQkQsQ0FESyxDQUFQO0FBb0JELEtBdkJFLEVBeUJKSSxLQXpCSSxDQXlCRzVJLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQTNCSSxDQUFQO0FBNkJEOztBQUdEOE8sV0FBUztBQUNQLFdBQU8sSUFBSXZHLE9BQUosQ0FDSCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQSxXQUFLNEYsSUFBTCxDQUFVMkIsYUFBVixDQUF3QixDQUFDaFEsQ0FBRCxFQUFJZ1AsR0FBSixLQUFZO0FBQ2xDLFlBQUloUCxDQUFKLEVBQU87QUFDTHlJLGlCQUFPekksQ0FBUDtBQUNELFNBRkQsTUFFTztBQUNMd0ksa0JBQVF3RyxHQUFSO0FBQ0Q7QUFDRixPQU5EO0FBT0QsS0FWRSxFQVlKcEcsS0FaSSxDQWFGNUksQ0FBRCxJQUFPO0FBQ0wsWUFBTUEsQ0FBTjtBQUNELEtBZkUsQ0FBUDtBQWlCRDs7QUFsTXdCLEM7Ozs7Ozs7Ozs7O0FDSjNCckUsT0FBT3lLLE1BQVAsQ0FBYztBQUFDdEssV0FBUSxNQUFJdUM7QUFBYixDQUFkOztBQUFlLE1BQU1BLE1BQU4sQ0FBYTtBQUUxQndJLGdCQUFjO0FBQ1osU0FBS3RGLE1BQUwsR0FBYyxFQUFkO0FBQ0EsU0FBSzBPLFFBQUwsR0FBZ0IsSUFBSUMsUUFBSixFQUFoQjtBQUNEOztBQUVLOVEsT0FBTixDQUFZekIsT0FBTyxFQUFuQixFQUF1QnVOLEtBQUssK0JBQVksQ0FBRSxDQUFkLENBQTVCO0FBQUEsb0NBQTRDO0FBRTFDLFdBQUsrRSxRQUFMLEdBQWdCLElBQUlDLFFBQUosRUFBaEI7QUFDQSxVQUFJQyxNQUFNLEVBQVY7O0FBRUEsVUFBSTtBQUVGLFlBQUloUSxvQkFBWStLLElBQVosQ0FBSjtBQUVBYSxlQUFPQyxNQUFQLENBQWNtRSxHQUFkLEVBQW1CO0FBQ2pCbEosZ0JBQU0sU0FEVztBQUVqQjdILGlCQUFPekIsSUFGVTtBQUdqQnlTLGtCQUFRalE7QUFIUyxTQUFuQjtBQU1ELE9BVkQsQ0FVRSxPQUFPSCxDQUFQLEVBQVU7QUFFVitMLGVBQU9DLE1BQVAsQ0FBY21FLEdBQWQsRUFBbUI7QUFDakJsSixnQkFBTSxPQURXO0FBRWpCN0gsaUJBQU96QixJQUZVO0FBR2pCeVMsa0JBQVFwUTtBQUhTLFNBQW5CO0FBTUQsT0FsQkQsU0FrQlU7QUFFUixZQUFJLEtBQUtpUSxRQUFMLENBQWNJLEtBQWxCLEVBQXlCO0FBQ3ZCdEUsaUJBQU9DLE1BQVAsQ0FBY21FLEdBQWQsRUFBbUI7QUFDakJGLHNCQUFVLEtBQUtBO0FBREUsV0FBbkI7QUFHRDs7QUFDRCxhQUFLMU8sTUFBTCxDQUFZcUcsSUFBWixDQUFpQnVJLEdBQWpCO0FBRUQ7QUFFRixLQWxDRDtBQUFBOztBQW9DQXBRLFdBQVN1USxTQUFULEVBQW9CO0FBQ2xCLFNBQUtMLFFBQUwsQ0FBY00sT0FBZCxDQUFzQkQsU0FBdEI7QUFDRDs7QUFFRHJRLFNBQU9xUSxTQUFQLEVBQWtCO0FBQ2hCLFNBQUtMLFFBQUwsQ0FBY25TLEtBQWQsQ0FBb0J3UyxTQUFwQjtBQUNEOztBQUVERSxpQkFBYztBQUNaLFFBQUlDLFdBQVcsS0FBS1IsUUFBTCxDQUFjUyxLQUFkLENBQW9CNVMsS0FBcEIsQ0FBMEJ1UyxLQUF6QztBQUNBLFFBQUlNLFdBQVcsS0FBZjs7QUFDQSxTQUFLLElBQUlSLEdBQVQsSUFBZ0IsS0FBSzVPLE1BQXJCLEVBQTZCO0FBQzNCLFVBQUk0TyxJQUFJbEosSUFBSixLQUFhLE9BQWpCLEVBQXlCO0FBQ3ZCMEosbUJBQVcsSUFBWDtBQUNBO0FBQ0Q7QUFDRjs7QUFDRCxXQUFPRixZQUFZRSxRQUFuQjtBQUNEOztBQUVEelEsWUFBVTtBQUNSLFFBQUcsS0FBS3NRLFlBQUwsRUFBSCxFQUF1QjtBQUNyQixZQUFNLElBQUk3VCxPQUFPNkssS0FBWCxDQUFpQixLQUFLakcsTUFBdEIsQ0FBTjtBQUNEOztBQUNELFdBQU8sS0FBS0EsTUFBWjtBQUNEOztBQXBFeUI7O0FBeUU1QixNQUFNMk8sUUFBTixDQUFlO0FBRWJySixnQkFBYztBQUNaLFNBQUt3SixLQUFMLEdBQVksQ0FBWjtBQUNBLFNBQUtLLEtBQUwsR0FBYTtBQUNYSCxlQUFTO0FBQ1BGLGVBQU8sQ0FEQTtBQUVQTyxpQkFBUztBQUZGLE9BREU7QUFLWDlTLGFBQU87QUFDTHVTLGVBQU8sQ0FERjtBQUVMTyxpQkFBUztBQUZKO0FBTEksS0FBYjtBQVVEOztBQUVETCxVQUFRRCxTQUFSLEVBQW1CO0FBQ2pCLFFBQUdBLFNBQUgsRUFBYTtBQUNYLFdBQUtJLEtBQUwsQ0FBV0gsT0FBWCxDQUFtQkssT0FBbkIsQ0FBMkJoSixJQUEzQixDQUFnQzBJLFNBQWhDO0FBQ0Q7O0FBQ0QsU0FBS0ksS0FBTCxDQUFXSCxPQUFYLENBQW1CRixLQUFuQjtBQUNBLFNBQUtBLEtBQUw7QUFDRDs7QUFDRHZTLFFBQU13UyxTQUFOLEVBQWlCO0FBQ2YsUUFBR0EsYUFBYUEsY0FBYyxFQUEzQixJQUFpQ0EsY0FBYSxFQUFqRCxFQUFxRDtBQUNuRCxXQUFLSSxLQUFMLENBQVc1UyxLQUFYLENBQWlCOFMsT0FBakIsQ0FBeUJoSixJQUF6QixDQUE4QjFKLEtBQUsyUyxLQUFMLENBQVdQLFNBQVgsQ0FBOUI7QUFDRDs7QUFDRCxTQUFLSSxLQUFMLENBQVc1UyxLQUFYLENBQWlCdVMsS0FBakI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBN0JZLEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcbi8vICAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4vLyAgIHJlcy5lbmQoYEhlbGxvIHdvcmxkIGZyb206ICR7TWV0ZW9yLnJlbGVhc2V9YCk7XHJcbi8vIH0pO1xyXG5cclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnO1xyXG5cclxuLy8gUmVxdWlyZXMgbXVsdGlwYXJ0eSBcclxuaW1wb3J0IG11bHRpcGFydHkgZnJvbSAnY29ubmVjdC1tdWx0aXBhcnR5JztcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL3VwbG9hZHMnO1xyXG5sZXQgbXVsdGlwYXJ0eU1pZGRsZXdhcmUgPSBtdWx0aXBhcnR5KCk7XHJcblxyXG5jb25zdCByb3V0ZSA9ICcvdXBsb2FkL2ltYWdlJztcclxuXHJcbi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgZnVjLnVwbG9hZEZpbGUgKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIG11bHRpcGFydHlNaWRkbGV3YXJlKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIChyZXEsIHJlc3ApID0+IHtcclxuICAvLyBkb24ndCBmb3JnZXQgdG8gZGVsZXRlIGFsbCByZXEuZmlsZXMgd2hlbiBkb25lXHJcblxyXG4gIGNvbnN0IHJlYWRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMucmVhZEZpbGUpO1xyXG4gIGNvbnN0IHdyaXRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMud3JpdGVGaWxlKTtcclxuICBjb25zdCB1cGxvYWRJZCA9IHVuaXFpZCgpO1xyXG5cclxuICBmb3IgKGxldCBmaWxlIG9mIHJlcS5maWxlcy5maWxlKSB7XHJcbiAgICBjb25zdCBkYXRhID0gcmVhZGVyKGZpbGUucGF0aCk7XHJcbiAgICAvLyDjg5XjgqHjgqTjg6vlkI3jga7ph43opIfjgpLpgb/jgZHjgovjgZ/jgoHjgIHkuIDmhI/jga7jg5XjgqHjgqTjg6vlkI3jgpLkvZzmiJDjgZnjgotcclxuICAgIC8vIOalveWkqeOBruODleOCoeOCpOODq+WQjeaWh+Wtl+aVsOWItumZkDIw44Gr5ZCI44KP44Gb44KLXHJcbiAgICBsZXQgZmlsZW5hbWUgPSBgJHt1bmlxaWQoKX0uanBnYFxyXG5cclxuICAgIC8vIHNldCB0aGUgY29ycmVjdCBwYXRoIGZvciB0aGUgZmlsZSBub3QgdGhlIHRlbXBvcmFyeSBvbmUgZnJvbSB0aGUgQVBJOlxyXG4gICAgbGV0IHNhdmVQYXRoID0gcmVxLmJvZHkuaW1hZ2VkaXIgKyAnLycgKyBmaWxlbmFtZTtcclxuXHJcbiAgICAvLyBjb3B5IHRoZSBkYXRhIGZyb20gdGhlIHJlcS5maWxlcy5maWxlLnBhdGggYW5kIHBhc3RlIGl0IHRvIGZpbGUucGF0aFxyXG5cclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiee1kOaenOOCkuiomOmMsuOBmeOCi1xyXG4gICAgbGV0IGRvYyA9IHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgICBjbGllbnRGaWxlTmFtZTogZmlsZS5uYW1lLFxyXG4gICAgICB1cGxvYWRlZEZpbGVOYW1lOiBmaWxlbmFtZVxyXG4gICAgfTtcclxuICAgIFxyXG4gICAgdHJ5e1xyXG4gICAgICB3cml0ZXIoc2F2ZVBhdGgsIGRhdGEpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2goZXJyKXtcclxuICAgICAgZG9jLmVycm9yID0gZXJyO1xyXG4gICAgfVxyXG4gICAgVXBsb2Fkcy5pbnNlcnQoZG9jKTtcclxuXHJcbiAgICBkZWxldGUgZmlsZTtcclxuXHJcbiAgfTtcclxuICByZXNwLndyaXRlSGVhZCgyMDApO1xyXG4gIHJlc3AuZW5kKEpTT04uc3RyaW5naWZ5KHtcclxuICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgIHNhdmVEaXI6IHJlcS5ib2R5LmltYWdlZGlyXHJcbiAgfSkpO1xyXG5cclxufSk7IiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvcmVwb3J0JztcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb3JlL2RiZmlsdGVyJztcclxuaW1wb3J0IHtcclxuICBDdWJlM0FwaVxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29yZS9jdWJlM2FwaSc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vLi4vaW1wb3J0cy9jb3JlL2l0ZW1zJztcclxuXHJcbmxldCB0YWcgPSAnY3ViZXVwJztcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uaXRlbWBdKGNvbmZpZykge1xyXG5cclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSk7XHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnSkxJTkUgRU5HSU5FIOOBi+OCieOBruWPluOCiui+vOOBvycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgICAnU0FNUExFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvbjtcclxuXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuXHJcbiAgICAgICAgICAgICAgICBjdWJlSXRlbSA9IEl0ZW1Db250cm9sbGVyLml0ZW1DdWJlMyhpdGVtKTtcclxuXHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSk7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjb25maWcuY3JlYXRvcl9pZCxjdWJlSXRlbSk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKCk7XHJcblxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XHJcblxyXG4gIH0sXHJcblxyXG5cclxuICAvL1xyXG4gIC8vIOeUu+WDj+abtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5pbWFnZWBdKGNvbmZpZykge1xyXG5cclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSk7XHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnSkxJTkUgRU5HSU5FIOOBi+OCieOBruWPluOCiui+vOOBvycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgICAnU0FNUExFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvbjtcclxuXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnByb2R1Y3RJbWFnZVVwZGF0ZShcclxuICAgICAgICAgICAgICAgICAgY29uZmlnLmNyZWF0b3JfaWQsXHJcbiAgICAgICAgICAgICAgICAgIEl0ZW1Db250cm9sbGVyLml0ZW1DdWJlMyhpdGVtKVxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKTtcclxuXHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG5cclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XHJcblxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICAgIHRocm93IGVcclxuICAgICAgICAgIH1cclxuICAgICAgICApO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKTtcclxuXHJcbiAgfVxyXG5cclxuXHJcbn0pOyIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL3JlcG9ydCc7XHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29yZS9kYmZpbHRlcic7XHJcbmltcG9ydCB7XHJcbiAgQ3ViZTNBcGlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvcmUvY3ViZTNhcGknO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNb25nb0NsaWVudFxyXG59IGZyb20gJ21vbmdvZGInO1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vLi4vaW1wb3J0cy9jb3JlL2l0ZW1zJztcclxuXHJcbmxldCB0YWcgPSAnY3ViZXgnO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYml0YF0oY29uZmlnKSB7XHJcblxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKTtcclxuXHJcbiAgICAvLyBsZXQgbW9uZ29KbGluZTtcclxuICAgIC8vIGxldCBJdGVtcztcclxuXHJcbiAgICAvLyBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAvLyAgICdKTElORSBFTkdJTkUg44G444Gu5o6l57aaJyxcclxuICAgIC8vICAgYXN5bmMgKCk9PntcclxuICAgIC8vICAgICBsZXQgcGx1ZyA9IGNvbmZpZy5zb3VyY2VEQjtcclxuICAgIC8vICAgICBtb25nb0psaW5lID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSk7XHJcbiAgICAvLyAgICAgSXRlbXMgPSBtb25nb0psaW5lLmRiKHBsdWcuZGF0YWJhc2UpLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKTtcclxuICAgIC8vICAgfVxyXG4gICAgLy8gKTtcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLnNvdXJjZURCLCBjb25maWcucHJvZmlsZSk7XHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLnRhcmdldERCLmNyZWQpO1xyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnSkxJTkUgRU5HSU5FIOOBi+OCieOBruWPluOCiui+vOOBvycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgICAnS09NSU5FX05PVEVYSVNUUyc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb247XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGluc2VydFJldCA9IGF3YWl0IGFwaS5wcm9kdWN0Q3JlYXRlKFxyXG4gICAgICAgICAgICAgICAgICBjb25maWcuY3JlYXRvcl9pZCxcclxuICAgICAgICAgICAgICAgICAgSXRlbUNvbnRyb2xsZXIuaXRlbUN1YmUzKGl0ZW0pXHJcbiAgICAgICAgICAgICAgICApO1xyXG5cclxuICAgICAgICAgICAgICAgIGF3YWl0IGNvbC51cGRhdGUoe1xyXG4gICAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcCc6IGluc2VydFJldC5yZXNcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKCk7XHJcblxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XHJcblxyXG4gIH1cclxuXHJcbn0pOyIsImltcG9ydCBjcnlwdG8gZnJvbSAnY3J5cHRvJztcclxuXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQgUmVwb3J0IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnO1xyXG5pbXBvcnQge1xyXG4gIEdyb3VwLFxyXG4gIEdyb3VwRmFjdG9yeVxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9ncm91cHMnO1xyXG5pbXBvcnQge1xyXG4gIEZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzJztcclxuXHJcbmxldCB0YWcgPSAnY3ViZW1pZyc7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm1pZ3JhdGVgXShjb25maWcpIHtcclxuXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xyXG5cclxuICAgIC8vIHNldHVwIGdyb3VwXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgRmlsdGVyKGNvbmZpZy5zcmNGaWx0ZXJJZCk7XHJcbiAgICAvLyBsZXQgcGx1ZyA9IGdyb3VwLmdldFBsdWcoKTtcclxuXHJcbiAgICAvLyBjaGVja2luZyBjb25uZWN0aW9uXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCB0ZXN0UXVlcnkgPSAnU0hPVyBEQVRBQkFTRVMnO1xyXG5cclxuICAgIGxldCBkc3REYiA9IG5ldyBNeVNRTChjb25maWcuZHN0LmNyZWQpO1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnQ29ubmVjdCB0byBEZXN0aW5hdGlvbicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBhd2FpdCBkc3REYi5xdWVyeSh0ZXN0UXVlcnkpO1xyXG4gICAgICB9KTtcclxuXHJcblxyXG4gICAgLy8gcHJvY2VzcyBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICAvL1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnU2VsZWN0IGxvb3AgaW4gc291cmNlJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAgIG1vYmlsZU51bGw6IGFzeW5jIChyZWNvcmQpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgLy8gLy8g5YCk44KS5pW055CGXHJcbiAgICAgICAgICAgICAgLy8gZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgICAvLyAgIGlmIChyZWNvcmRba2V5XSA9PT0gbnVsbCk7XHJcbiAgICAgICAgICAgICAgLy8gICBlbHNlIGlmIChyZWNvcmRba2V5XS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnRGF0ZScpIHtcclxuICAgICAgICAgICAgICAvLyAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gTXlTUUwuZm9ybWF0RGF0ZShyZWNvcmRba2V5XSk7XHJcbiAgICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gYFwiJHtyZWNvcmRba2V5XX1cImA7XHJcbiAgICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXIg44Gr5L+d5a2YXHJcblxyXG4gICAgICAgICAgICAgIGxldCBzcWwgPSBgXHJcblxyXG4gICAgICAgICAgICAgICAgSU5TRVJUIGR0Yl9jdXN0b21lclxyXG4gICAgICAgICAgICAgICAgKCBcXGBjdXN0b21lcl9pZFxcYCwgXFxgc3RhdHVzXFxgLCBcXGBzZXhcXGAsIFxcYGpvYlxcYCwgXFxgY291bnRyeV9pZFxcYCwgXFxgcHJlZlxcYCwgXFxgbmFtZTAxXFxgLCBcXGBuYW1lMDJcXGAsIFxcYGthbmEwMVxcYCwgXFxga2FuYTAyXFxgLCBcXGBjb21wYW55X25hbWVcXGAsIFxcYHppcDAxXFxgLCBcXGB6aXAwMlxcYCwgXFxgemlwY29kZVxcYCwgXFxgYWRkcjAxXFxgLCBcXGBhZGRyMDJcXGAsIFxcYGVtYWlsXFxgLCBcXGB0ZWwwMVxcYCwgXFxgdGVsMDJcXGAsIFxcYHRlbDAzXFxgLCBcXGBmYXgwMVxcYCwgXFxgZmF4MDJcXGAsIFxcYGZheDAzXFxgLCBcXGBiaXJ0aFxcYCwgXFxgcGFzc3dvcmRcXGAsIFxcYHNhbHRcXGAsIFxcYHNlY3JldF9rZXlcXGAsIFxcYGZpcnN0X2J1eV9kYXRlXFxgLCBcXGBsYXN0X2J1eV9kYXRlXFxgLCBcXGBidXlfdGltZXNcXGAsIFxcYGJ1eV90b3RhbFxcYCwgXFxgbm90ZVxcYCwgXFxgY3JlYXRlX2RhdGVcXGAsIFxcYHVwZGF0ZV9kYXRlXFxgLCBcXGBkZWxfZmxnXFxgIClcclxuXHJcbiAgICAgICAgICAgICAgICBWQUxVRVMoICR7IHJlY29yZC5jdXN0b21lcl9pZCB9ICwgJHsgcmVjb3JkLnN0YXR1cyB9ICwgJHsgcmVjb3JkLnNleCB9ICwgJHsgcmVjb3JkLmpvYiB9ICwgJHsgcmVjb3JkLmNvdW50cnlfaWQgfSAsICR7IHJlY29yZC5wcmVmIH0gLCAkeyByZWNvcmQubmFtZTAxIH0gLCAkeyByZWNvcmQubmFtZTAyIH0gLCAkeyByZWNvcmQua2FuYTAxIH0gLCAkeyByZWNvcmQua2FuYTAyIH0gLCAkeyByZWNvcmQuY29tcGFueV9uYW1lIH0gLCAkeyByZWNvcmQuemlwMDEgfSAsICR7IHJlY29yZC56aXAwMiB9ICwgJHsgcmVjb3JkLnppcGNvZGUgfSAsICR7IHJlY29yZC5hZGRyMDEgfSAsICR7IHJlY29yZC5hZGRyMDIgfSAsICR7IHJlY29yZC5lbWFpbCB9ICwgJHsgcmVjb3JkLnRlbDAxIH0gLCAkeyByZWNvcmQudGVsMDIgfSAsICR7IHJlY29yZC50ZWwwMyB9ICwgJHsgcmVjb3JkLmZheDAxIH0gLCAkeyByZWNvcmQuZmF4MDIgfSAsICR7IHJlY29yZC5mYXgwMyB9ICwgJHsgcmVjb3JkLmJpcnRoIH0gLCAkeyByZWNvcmQucGFzc3dvcmQgfSAsICR7IHJlY29yZC5zYWx0IH0gLCAkeyByZWNvcmQuc2VjcmV0X2tleSB9ICwgJHsgcmVjb3JkLmZpcnN0X2J1eV9kYXRlIH0gLCAkeyByZWNvcmQubGFzdF9idXlfZGF0ZSB9ICwgJHsgcmVjb3JkLmJ1eV90aW1lcyB9ICwgJHsgcmVjb3JkLmJ1eV90b3RhbCB9ICwgJHsgcmVjb3JkLm5vdGUgfSAsICR7IHJlY29yZC5jcmVhdGVfZGF0ZSB9ICwgJHsgcmVjb3JkLnVwZGF0ZV9kYXRlIH0gLCAkeyByZWNvcmQuZGVsX2ZsZyB9IClcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgYDtcclxuXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyJyxcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgc3RhdHVzOiByZWNvcmQuc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgICAgIHNleDogcmVjb3JkLnNleCxcclxuICAgICAgICAgICAgICAgICAgICBqb2I6IHJlY29yZC5qb2IsXHJcbiAgICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgICBlbWFpbDogcmVjb3JkLmVtYWlsLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICAgIGJpcnRoOiByZWNvcmQuYmlydGgsXHJcbiAgICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHJlY29yZC5wYXNzd29yZCxcclxuICAgICAgICAgICAgICAgICAgICBzYWx0OiByZWNvcmQuc2FsdCxcclxuICAgICAgICAgICAgICAgICAgICBzZWNyZXRfa2V5OiByZWNvcmQuc2VjcmV0X2tleSxcclxuICAgICAgICAgICAgICAgICAgICBmaXJzdF9idXlfZGF0ZTogcmVjb3JkLmZpcnN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIGxhc3RfYnV5X2RhdGU6IHJlY29yZC5sYXN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIGJ1eV90aW1lczogcmVjb3JkLmJ1eV90aW1lcyxcclxuICAgICAgICAgICAgICAgICAgICBidXlfdG90YWw6IHJlY29yZC5idXlfdG90YWwsXHJcbiAgICAgICAgICAgICAgICAgICAgbm90ZTogcmVjb3JkLm5vdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lcl9hZGRyZXNzXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyX2FkZHJlc3MnLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfYWRkcmVzc19pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgLy8g44Oh44Or44Oe44Ks44OX44Op44Kw44Kk44OzIHBsZ19tYWlsbWFnYV9jdXN0b21lclxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICAgJ3BsZ19tYWlsbWFnYV9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgICBpZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgIG1haWxtYWdhX2ZsZzogcmVjb3JkLm1haWxtYWdhX2ZsZyxcclxuICAgICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAvLyDjgq/jg7zjg53jg7PnmbrooYzvvIhFQ0NVQkUy44Gu44Od44Kk44Oz44OI6YKE5YWD77yJXHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb3Vwb25fY2QgPSBjcnlwdG8ucmFuZG9tQnl0ZXMoOCkudG9TdHJpbmcoJ2Jhc2U2NCcpLnN1YnN0cmluZygwLDExKTtcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGNvdXBvbl9uYW1lID0gYCR7cmVjb3JkLm5hbWUwMX0gJHtyZWNvcmQubmFtZTAyfSDmp5gg44GU5YSq5b6F44Kv44O844Od44OzIOS8muWToeeVquWPtzoke3JlY29yZC5jdXN0b21lcl9pZH1gO1xyXG5cclxuICAgICAgICAgICAgICBsZXQgZGlzY291bnRfcHJpY2UgPSByZWNvcmQucG9pbnQgKyA1MDA7XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAgICdwbGdfY291cG9uJywge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl9pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBjb3Vwb25fY2Q6IGNvdXBvbl9jZCxcclxuICAgICAgICAgICAgICAgICAgICBjb3Vwb25fdHlwZTogMywgLy8g5YWo5ZWG5ZOBXHJcbiAgICAgICAgICAgICAgICAgICAgY291cG9uX25hbWU6IGNvdXBvbl9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3R5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgY291cG9uX3VzZV90aW1lOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl9yZWxlYXNlOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3ByaWNlOiBkaXNjb3VudF9wcmljZSxcclxuICAgICAgICAgICAgICAgICAgICBkaXNjb3VudF9yYXRlOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgIGVuYWJsZV9mbGFnOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl9tZW1iZXI6IDEsXHJcbiAgICAgICAgICAgICAgICAgICAgY291cG9uX2xvd2VyX2xpbWl0OiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV9mcm9tX2RhdGU6ICcyMDE4LTA0LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgICBhdmFpbGFibGVfdG9fZGF0ZTogJzIwMTktMDUtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IDBcclxuICAgICAgICAgICAgICAgICAgfSx7XHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgKTtcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKTtcclxuICB9LFxyXG5cclxuICBhc3luYyAnY3ViZW1pZy5zZXJ2ZXJDaGVjaycgKHByb2ZpbGUpIHtcclxuXHJcbiAgICBsZXQgZGIgPSBuZXcgTXlTUUwocHJvZmlsZSk7XHJcbiAgICBsZXQgcmVzID0gYXdhaXQgZGIucXVlcnkoJ1NIT1cgREFUQUJBU0VTJyk7XHJcbiAgICByZXR1cm4gcmVzO1xyXG4gIH1cclxuXHJcbn0pOyIsImltcG9ydCB7IE1vbmdvQ29sbGVjdGlvbiB9IGZyb20gXCIuLi8uLi9pbXBvcnRzL3V0aWwvbW9uZ29cIjtcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuY29sbGVjdGlvbic7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmZpbmRgXSggcGx1ZywgcXVlcnk9e30sIHByb2plY3Rpb249e30gKSB7XHJcblxyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcpO1xyXG4gICAgcmV0dXJuIGF3YWl0IGNvbGwuZmluZChxdWVyeSx7cHJvamVjdGlvbjpwcm9qZWN0aW9ufSkudG9BcnJheSgpO1xyXG5cclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5hZ2dyZWdhdGVgXSggcGx1ZywgcXVlcnk9e30gKSB7XHJcblxyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcpO1xyXG4gICAgcmV0dXJuIGF3YWl0IGNvbGwuYWdncmVnYXRlKHF1ZXJ5KS50b0FycmF5KCk7XHJcblxyXG4gIH1cclxuXHJcbn0pOyIsImltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tIFwiLi4vLi4vaW1wb3J0cy9jb3JlL2l0ZW1zXCI7XHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLml0ZW1zJztcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgb7jgZnjgIJcclxuICAgKiBAcGFyYW0gIFxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LnNldEltYWdlYF0oIHBsdWcsIHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCApIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKCk7XHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1Zyk7XHJcbiAgICBsZXQgdXBsb2FkZWQgPSBhd2FpdCBpdGVtY29uLnNldEltYWdlKCB1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSwgY2xhc3MyICk7XHJcbiAgICByZXR1cm4gdXBsb2FkZWQ7XHJcbiAgfSxcclxuXHJcbiAgLyoqXHJcbiAgICog44Ki44Kk44OG44Og5oOF5aCx44OH44O844K/44OZ44O844K544Gu55S75YOP55m76Yyy44KS5YmK6Zmk44GZ44KL77yI55S75YOP6Ieq5L2T44Gv5YmK6Zmk44GX44Gq44GE77yJXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uY2xlYW5JbWFnZWBdKCBwbHVnLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCApIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKCk7XHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1Zyk7XHJcbiAgICBhd2FpdCBpdGVtY29uLmNsZWFuSW1hZ2UoIG1vZGVsLCBjbGFzczEsIGNsYXNzMiApO1xyXG4gIH1cclxuXHJcbn0pOyIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCc7XHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvY29yZS9kYmZpbHRlcic7XHJcbmltcG9ydCB7XHJcbiAgQ3ViZTNBcGlcclxufSBmcm9tICcuLi9pbXBvcnRzL2NvcmUvY3ViZTNhcGknO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJztcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvY29yZS9pdGVtcyc7XHJcblxyXG5sZXQgdGFnID0gJ2N1YmUnO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYkl0ZW1gXShjb25maWcpIHtcclxuXHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSk7XHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+OBuOOBruWVhuWTgeeZu+mMsicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgICAnSU5TRVJUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvbjtcclxuXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBJdGVtQ29udHJvbGxlci5pdGVtQ3ViZTMoY29uZmlnLmNyZWF0b3JfaWQsIGl0ZW0pO1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCBpbnNlcnRSZXMgPSBhd2FpdCBhcGkucHJvZHVjdENyZWF0ZShjdWJlSXRlbSk7XHJcblxyXG4gICAgICAgICAgICAgICAgLy8gaXRlbSDjg4fjg7zjgr/jg5njg7zjgrnjgbjjga7nmbvpjLJcclxuICAgICAgICAgICAgICAgIGF3YWl0IGNvbC51cGRhdGUoe1xyXG4gICAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcCc6IGluc2VydFJlcy5yZXNcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfSk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKCk7XHJcblxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+WVhuWTgeaDheWgseOBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgICAnVVBEQVRFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvbjtcclxuXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBJdGVtQ29udHJvbGxlci5pdGVtQ3ViZTMoY29uZmlnLmNyZWF0b3JfaWQsIGl0ZW0pO1xyXG5cclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0SW1hZ2VVcGRhdGUoY3ViZUl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RVcGRhdGUoY3ViZUl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RUYWdVcGRhdGUoY3ViZUl0ZW0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xyXG5cclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpO1xyXG5cclxuICB9XHJcblxyXG59KTsiLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnO1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL2NvcmUvZGJmaWx0ZXInO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJztcclxuXHJcbmxldCB0YWcgPSAndG9vbCc7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnRlc3RgXShjb25maWcpIHtcclxuXHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSk7XHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44OV44Kj44Or44K/44O844OG44K544OIJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBhd2FpdCBmaWx0ZXIuZm9yZWFjaChcclxuICAgICAgICAgIHt9LFxyXG4gICAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpO1xyXG5cclxuICB9XHJcblxyXG59KTsiLCJpbXBvcnQgJy4uL2ltcG9ydHMvY29sbGVjdGlvbi9jb25maWdzJztcclxuXHJcbmltcG9ydCAnLi9yb3V0ZS91cGxvYWQvaW1hZ2UnOyIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuIFxyXG5leHBvcnQgY29uc3QgQ29uZmlncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb25maWdzJyx7aWRHZW5lcmF0aW9uOidNT05HTyd9KTtcclxuXHJcbi8vIE1ldGVvci5tZXRob2RzKHsgXHJcbi8vICAgYXN5bmMgJ215c3FsU2VydmVycy5pbnNlcnQnICggbmV3U2VydmVyICl7XHJcbi8vICAgICByZXR1cm4gYXdhaXQgTXlzcWxTZXJ2ZXJzLmluc2VydChuZXdTZXJ2ZXIpO1xyXG4vLyAgIH1cclxuLy8gfSk7XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0JztcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnO1xyXG5pbXBvcnQgeyBHcm91cEJhc2UgfSBmcm9tICcuL2dyb3Vwcyc7XHJcblxyXG5jb25zdCBGaWx0ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZpbHRlcnMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZpbHRlciBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGZpbHRlcklkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBGaWx0ZXJzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGZpbHRlcklkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcblxyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKCBvblJlc3VsdCA9IChyZWNvcmQpPT57fSwgb25FcnJvciA9IChlKT0+e30gKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGxhdGZvcm0gdHlwZScpO1xyXG5cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7eyBmaWx0ZXJUeXBlOiBhc3luYyAocmVjb3JkICkgPT4ge30gfX0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoKGNhbGxiYWNrcyA9IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGUoKTtcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICB0eXBlOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnQgPSB7fTtcclxuICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgY291bnRbZmlsdGVyLnR5cGVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmaWx0ZXIucXVlcnksXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCk9PntcclxuICAgICAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgICAgICBsZXQgcXVlcnkgPSBtb2JqZWN0LnVuZXNjYXBlKGZpbHRlci5xdWVyeSk7XHJcbiAgICAgICAgICBsZXQgZXhhbSA9IHNpZnQoIHF1ZXJ5ICk7XHJcbiAgICAgICAgICBpZiggZXhhbShyZWNvcmQpICl7XHJcbiAgICAgICAgICAgIGNvdW50W2ZpbHRlci50eXBlXS5jb3VudCsrO1xyXG4gICAgICAgICAgICBpZiggdHlwZW9mIGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFja3NbZmlsdGVyLnR5cGVdKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBvbkVycm9yXHJcbiAgICApO1xyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnQ7XHJcblxyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbmNvbnN0IEdyb3VwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdncm91cHMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwQmFzZSB7XHJcblxyXG4gIHByb2ZpbGU7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb2ZpbGUpIHtcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBnZXRzICdQbHVnJyB3aXRjaCBpcyBhIHNldCBvZiBwcm9wZXJ0aWVzIG5lZWRlZFxyXG4gICAqIHdoZW4gY29ubmVjdCB0byBzb21lIHBsYXRmb3Jtc1xyXG4gICAqIHRvIGdldCBkYXRhcyhNZW1iZXJzIG9mIHRoZSBHcm91cClcclxuICAgKi9cclxuICBnZXRQbHVnKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZS5wbGF0Zm9ybVBsdWc7XHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZTtcclxuICB9XHJcblxyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge307XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXAgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihncm91cElkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBHcm91cHMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZ3JvdXBJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKGRvYykgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX0gV0hFUkUgXFxgJHtkb2Mua2V5fVxcYCA9IFwiJHtkb2MuaWR9XCJgO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBncm91cCB0eXBlJyk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7YXN5bmMgKHJlY29yZCk9PnZvaWR9IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IGN1ciA9IEdyb3Vwcy5maW5kKHtcclxuICAgICAgZ3JvdXBJZDogdGhpcy5wcm9maWxlLl9pZFxyXG4gICAgfSwge1xyXG4gICAgICBmaWVsZHM6IHtcclxuICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAga2V5OiAxXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGN1ci5mb3JFYWNoKFxyXG4gICAgICAgICAgYXN5bmMgKGRvYywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVjb3JkID0gYXdhaXQgdGhpcy5pbXBvcnQoZG9jKTtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFjayhyZWNvcmQpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgb25FcnJvcihlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaW5kZXggKyAxID09PSBjdXIuY291bnQoKSkge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICB9XHJcbiAgICApLmNhdGNoKFxyXG4gICAgICAoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbiBcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2Fkcycse2lkR2VuZXJhdGlvbjonTU9OR08nfSk7XHJcblxyXG4iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNb25nb0NsaWVudFxyXG59IGZyb20gJ21vbmdvZGInO1xyXG5cclxuZXhwb3J0IGNsYXNzIEN1YmUzQXBpIHtcclxuXHJcbiAgY29uc3RydWN0b3IobXlzcWwgPSBuZXcgTXlTUUwoKSkge1xyXG4gICAgdGhpcy5teXNxbF8gPSBteXNxbDtcclxuICB9XHJcblxyXG5cclxuICBhc3luYyBwcm9kdWN0VGFnVXBkYXRlKGRhdGEpIHtcclxuXHJcbiAgICBsZXQgY3JlYXRvcl9pZCA9IGRhdGEuY3JlYXRvcl9pZDtcclxuICAgIFxyXG4gICAgbGV0IHJlcyA9IFtdO1xyXG5cclxuICAgIGxldCB0YWdvbiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgcmVzLnB1c2goXHJcbiAgICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAnZHRiX3Byb2R1Y3RfdGFnJyxcclxuICAgICAgICAgIHt9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBkYXRhLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgICAgIHRhZzogdGFnLFxyXG4gICAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9yX2lkXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKSk7fTtcclxuXHJcbiAgICBsZXQgdGFnb2ZmID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICBsZXQgc3FsID0gYFxyXG4gICAgICBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF90YWcgXHJcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxyXG4gICAgICBgO1xyXG4gICAgICByZXMucHVzaCggYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSApO1xyXG4gICAgfTtcclxuXHJcbiAgICBmb3IgKGxldCB0YWdTZXQgb2YgZGF0YS50YWdzKSB7XHJcbiAgICAgIHN3aXRjaCAodGFnU2V0LnNldCkge1xyXG4gICAgICAgIGNhc2UgJ29uJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29uKHRhZ1NldC50YWcpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgY2FzZSAnb2ZmJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29mZih0YWdTZXQudGFnKTtcclxuICAgICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH07XHJcblxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdEltYWdlVXBkYXRlKGRhdGEpIHtcclxuXHJcbiAgICBsZXQgcHJvZHVjdF9pZCA9IGRhdGEucHJvZHVjdF9pZDtcclxuICAgIGxldCBpbWFnZXMgPSBkYXRhLmltYWdlcztcclxuICAgIGxldCBjcmVhdG9yX2lkID0gZGF0YS5jcmVhdG9yX2lkO1xyXG5cclxuICAgIGxldCByZXMgPSBbXTtcclxuXHJcbiAgICAvLyDllYblk4HjgavplqLpgKPjgZnjgovjgZnjgbnjgabjga7nlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgotcclxuICAgIGxldCBzcWwgPSBgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfaW1hZ2UgV0hFUkUgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdF9pZH1gO1xyXG4gICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSk7XHJcblxyXG4gICAgLy8g5pS544KB44Gm55S75YOP44KS55m76Yyy44GX44Gq44GK44GZXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGltYWdlcy5sZW5ndGg7IGkrKykge1xyXG5cclxuICAgICAgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgJ2R0Yl9wcm9kdWN0X2ltYWdlJywge1xyXG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdF9pZCxcclxuICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JfaWQsXHJcbiAgICAgICAgICBmaWxlX25hbWU6IGltYWdlc1tpXSxcclxuICAgICAgICAgIHJhbms6IGkgKyAxXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH07XHJcblxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdFVwZGF0ZShkYXRhKSB7XHJcblxyXG4gICAgbGV0IHVwZGF0ZV9kYXRhID0ge307XHJcbiAgICBsZXQga2V5cyA9IFtdO1xyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0XHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3N0YXR1cycsXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ25vdGUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fbGlzdCcsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnLFxyXG4gICAgICAnc2VhcmNoX3dvcmQnLFxyXG4gICAgICAnZnJlZV9hcmVhJ1xyXG4gICAgXTtcclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlX2RhdGFba10gPSBkYXRhW2tdO1xyXG4gICAgfVxyXG5cclxuICAgIHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZV9kYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgICAvLyBkdGJfcHJvZHVjdF9jbGFzc1xyXG5cclxuICAgIHVwZGF0ZV9kYXRhID0ge307XHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnZGVsaXZlcnlfZGF0ZV9pZCcsXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAnc2FsZV9saW1pdCcsXHJcbiAgICAgICdwcmljZTAxJyxcclxuICAgICAgJ3ByaWNlMDInLFxyXG4gICAgICAnZGVsaXZlcnlfZmVlJ1xyXG4gICAgXTtcclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlX2RhdGFba10gPSBkYXRhW2tdO1xyXG4gICAgfVxyXG5cclxuICAgIGxldCByZXMgPSB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxyXG4gICAgICB1cGRhdGVfZGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH07XHJcblxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdENyZWF0ZShkYXRhKSB7XHJcblxyXG4gICAgbGV0IGNyZWF0b3JfaWQgPSBkYXRhLmNyZWF0b3JfaWQ7XHJcblxyXG4gICAgbGV0IHJlcyA9IHt9O1xyXG5cclxuICAgIGxldCB1cGRhdGVfZGF0YSA9IHt9O1xyXG4gICAgbGV0IGtleXMgPSBbXTtcclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnbmFtZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnXHJcbiAgICBdO1xyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiBpdGVtLm5hbWUsXHJcbiAgICAvLyAgIGRlc2NyaXB0aW9uX2RldGFpbDogaXRlbS5kZXNjcmlwdGlvbixcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVfZGF0YVtrXSA9IGRhdGFba107XHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcclxuICAgICAgdXBkYXRlX2RhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9yX2lkLFxyXG4gICAgICAgIHN0YXR1czogMSxcclxuICAgICAgICBub3RlOiAnTlVMTCcsXHJcbiAgICAgICAgZGVzY3JpcHRpb25fbGlzdDogJ05VTEwnLFxyXG4gICAgICAgIHNlYXJjaF93b3JkOiAnTlVMTCcsXHJcbiAgICAgICAgZnJlZV9hcmVhOiAnTlVMTCcsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcblxyXG4gICAgdXBkYXRlX2RhdGEgPSB7fTtcclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAncHJvZHVjdF90eXBlX2lkJyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMidcclxuICAgIF07XHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIHByb2R1Y3RfY29kZTogaXRlbS5tb2RlbCxcclxuICAgIC8vICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAvLyAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlX2RhdGFba10gPSBkYXRhW2tdO1xyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2NsYXNzX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIHVwZGF0ZV9kYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcl9pZCxcclxuICAgICAgICBwcm9kdWN0X2lkOiByZXMucHJvZHVjdF9pZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQxOiAnTlVMTCcsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQyOiAnTlVMTCcsXHJcbiAgICAgICAgZGVsaXZlcnlfZGF0ZV9pZDogJ05VTEwnLFxyXG4gICAgICAgIHNhbGVfbGltaXQ6ICdOVUxMJyxcclxuICAgICAgICBkZWxpdmVyeV9mZWU6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlX2RhdGFba10gPSBkYXRhW2tdO1xyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X3N0b2NrX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsIHt9LCB7XHJcbiAgICAgICAgcHJvZHVjdF9jbGFzc19pZDogcmVzLnByb2R1Y3RfY2xhc3NfaWQsXHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcl9pZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIC8vIGZvciB0ZXN0XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfTtcclxuXHJcbiAgfVxyXG5cclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSBcIm1ldGVvci9tb25nb1wiO1xyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSBcInNpZnRcIjtcclxuaW1wb3J0IG1vYmplY3QgZnJvbSBcIm1vbmdvb2JqZWN0XCI7XHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXJGYWN0b3J5IHtcclxuICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBsZXQgaW5zdGFuY2U7XHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlIFwibXlzcWxcIjpcclxuICAgICAgICBpbnN0YW5jZSA9IG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBpbnN0YW5jZTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlciB7XHJcbiAgLy8gREIg44GL44KJ44OH44O844K/44KS5Y+W5b6X44GZ44KL44OX44Ot44K744K5XHJcbiAgaW1wb3J0O1xyXG5cclxuICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnO1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmYWN0b3J5KHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIGxldCBpbnN0YW5jZTtcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgXCJteXNxbFwiOlxyXG4gICAgICAgIHJldHVybiBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKTtcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJpbnZhbGlkIHBsdWcgdHlwZVwiKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldFBsdWdfKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1ZztcclxuICB9XHJcblxyXG4gIGdldENyZWRfKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Zy5jcmVkO1xyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZV8oKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgc2V0SW1wb3J0RnVuY3Rpb25fKFxyXG4gICAgZm4gPSBhc3luYyAob25SZXN1bHQgPSByZWNvcmQgPT4ge30sIG9uRXJyb3IgPSBlID0+IHt9KSA9PiB7fVxyXG4gICkge1xyXG4gICAgdGhpcy5pbXBvcnQgPSBmbjtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIHVzZWFnZTpcclxuICAgKiBcclxuICAgKiBcclxuICAgKiBAcGFyYW0geyBPYmplY3QgfSBpdGVyYXRvcnMgeyBmaWx0ZXJOYW1lOiBhc3luYyAoZG9jLGNvbnRleHQpPT57fSwgLi4uIH0gaXRlcmF0b3IgZm9yIGVhY2ggZmlsdGVycyBcclxuICAgKiBAcGFyYW0geyBhc3luYyBmdW5jdGlvbiB9IG9uRXJyb3IgZXJyb3IgaGFuZGxlciB3aGlsZSBpdGVyYXRpbmdcclxuICAgKiBAcmV0dXJucyB7IE9iamVjdCB9IHsgZmlsdGVyTmFtZTogeyBxdWVyeTogYW55LCBjb3VudDogbnVtYmVyIH0sIC4uLiB9XHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaChpdGVyYXRvcnMgPSB7fSkge1xyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGVfKCk7XHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgbmFtZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pO1xyXG5cclxuICAgIGxldCBjb3VudGVyID0ge307XHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBmaWx0ZXJzID0gW107XHJcblxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgICAgY291bnRlcltmLm5hbWVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmLnF1ZXJ5LFxyXG4gICAgICAgIGxpbWl0OiB0eXBlb2YgZi5saW1pdCAhPT0gJ3VuZGVmaW5lZCcgPyBmLmxpbWl0IDogMCAsXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgICAgZmlsdGVycy5wdXNoKFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6IGYubmFtZSxcclxuICAgICAgICAgIGV4YW06IHNpZnQoIG1vYmplY3QudW5lc2NhcGUoZi5xdWVyeSkgKVxyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCwgY29udGV4dCkgPT4ge1xyXG5cclxuICAgICAgICBmb3IgKGxldCBmIG9mIGZpbHRlcnMpIHtcclxuXHJcbiAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgIGxldCBjID0gY291bnRlcltmLm5hbWVdO1xyXG4gICAgICAgICAgaWYoIGMubGltaXQgKXtcclxuICAgICAgICAgICAgaWYoIGMuY291bnQgPj0gYy5saW1pdCApe1xyXG4gICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKGYuZXhhbShyZWNvcmQpKSB7XHJcblxyXG4gICAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgICAgYy5jb3VudCsrO1xyXG5cclxuICAgICAgICAgICAgLy8gaXRlcmF0b3JcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVyYXRvcnNbZi5uYW1lXSAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGl0ZXJhdG9yc1tmLm5hbWVdKHJlY29yZCwgY29udGV4dCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudGVyO1xyXG4gIH1cclxufVxyXG5cclxuaW1wb3J0IE15U1FMIGZyb20gXCIuLi91dGlsL215c3FsXCI7XHJcblxyXG5leHBvcnQgY2xhc3MgTXlzcWxEQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuXHJcbiAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKGNyZWQpO1xyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YDtcclxuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgKGUpPT57dGhyb3cgZX0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgTW9uZ29OYXRpdmUgZnJvbSAnbW9uZ29kYic7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gTW9uZ29OYXRpdmUuTW9uZ29DbGllbnQ7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gcmVxdWlyZSgnbW9uZ29kYicpLk1vbmdvQ2xpZW50O1xyXG5pbXBvcnQge01vbmdvQ2xpZW50fSBmcm9tICdtb25nb2RiJztcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xyXG5cclxuICAgIC8vIG1vbmdvIOOBuOaOpee2mlxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcblxyXG4gICAgICBsZXQgY2xpZW50O1xyXG4gICAgICBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKTtcclxuXHJcbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xyXG4gICAgICBsZXQgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSk7XHJcbiAgICAgIGxldCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG4gIFxyXG4gICAgICBsZXQgY29udGV4dCA9IHtcclxuICAgICAgICBjbGllbnQ6IGNsaWVudCxcclxuICAgICAgICBjb2xsZWN0aW9uOiBjb2xsZWN0aW9uLFxyXG4gICAgICAgIGRhdGFiYXNlOiBkYlxyXG4gICAgICB9O1xyXG5cclxuICAgICAgbGV0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpO1xyXG4gICAgICBcclxuICAgICAgd2hpbGUoIGF3YWl0IGN1ci5oYXNOZXh0KCkgKXtcclxuICAgICAgICBsZXQgZG9jID0gYXdhaXQgY3VyLm5leHQoKTtcclxuICAgICAgICBhd2FpdCBvblJlc3VsdChkb2MsIGNvbnRleHQpO1xyXG4gICAgICB9O1xyXG5cclxuICAgIH0pO1xyXG5cclxuICB9XHJcbn1cclxuXHJcblxyXG4vLyBpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbi8vICAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xyXG4vLyAgICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XHJcblxyXG4vLyAgICAgLy8gbW9uZ28g44G45o6l57aaXHJcbi8vICAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuLy8gICAgIGxldCBjb251cmkgPSBgbW9uZ29kYjovLyR7Y3JlZC5ob3N0fToke2NyZWQucG9ydH0vJHtjcmVkLmRhdGFiYXNlfWA7XHJcbi8vICAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KGNvbnVyaSk7XHJcblxyXG4vLyAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5L2c44KLXHJcbi8vICAgICBsZXQgY29sbGVjdGlvbiA9IG1vbmdvb3NlLmNvbm5lY3Rpb24uY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG5cclxuLy8gICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4vLyAgICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XHJcbiAgICAgIFxyXG4vLyAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH1cclxuLy8gfVxyXG5cclxuXHJcbiIsImltcG9ydCB7IE1vbmdvQ29sbGVjdGlvbiB9IGZyb20gXCIuLi91dGlsL21vbmdvXCI7XHJcbmltcG9ydCB7IFVwbG9hZHMgfSBmcm9tIFwiLi4vY29sbGVjdGlvbi91cGxvYWRzXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtQ29udHJvbGxlcntcclxuXHJcbiAgYXN5bmMgaW5pdChwbHVnKXtcclxuXHJcbiAgICBwbHVnLmNvbGxlY3Rpb24gPSAnaXRlbXMnO1xyXG4gICAgdGhpcy5JdGVtcyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQoIE9iamVjdC5hc3NpZ24oe2NvbGxlY3Rpb246J2l0ZW1zJ30scGx1ZykgKTtcclxuICAgIHRoaXMuUHJvZHVjdHMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KCBPYmplY3QuYXNzaWduKHtjb2xsZWN0aW9uOidwcm9kdWN0cyd9LHBsdWcpICk7XHJcblxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U3RvY2soIGl0ZW1faWQgKXtcclxuICAgIFxyXG4gICAgbGV0IHByb2plY3QgPSBhd2FpdCB0aGlzLkl0ZW1zLmZpbmRPbmUoeyBfaWQ6IGl0ZW1faWQgfSx7cHJvamVjdGlvbjogeydwcm9kdWN0JzoxfX0pO1xyXG4gICAgbGV0IHByb2R1Y3RfcGFjayA9IHByb2plY3QucHJvZHVjdDtcclxuXHJcbiAgICAvLyBwcm9kdWN0ICogPC0+ICogaXRlbVxyXG4gICAgLy8gcHJvZHVjdFtdOiDopIfmlbDjga7llYblk4HjgpIx44OR44OD44Kx44O844K444Go44GX44Gm6LKp5aOyXHJcbiAgICAvLyBwcm9kdWN0W1tdXTog55Ww44Gq44KL5rWB6YCa57WM6Lev44CB55Ww44Gq44KL5Y6f5L6h44O75LuV5YWl44KM5YCkXHJcbiAgICAvLyBpdGVtOiDnlbDjgarjgovjgrvjg7zjg6vjgIHosqnlo7LlvaLmhYtcclxuICAgIC8vIOKAuyBwcm9kdWN0IOOBi+OCieOBr+OAgeiyqeWjsuWPr+iDveOBquWcqOW6q+OAgeWIqeebiuioiOeul+OBruOBn+OCgeOBruaDheWgseOCkuW+l+OCi1xyXG5cclxuICAgIGxldCBxdWFudGl0aWVzID0gW107XHJcblxyXG4gICAgZm9yKCBsZXQgcHJvZHVjdF9za3Ugb2YgcHJvZHVjdF9wYWNrICl7XHJcblxyXG4gICAgICBsZXQgcXVhbnRpdHlfc2t1ID0gMDtcclxuXHJcbiAgICAgIGZvciggbGV0IHByb2R1Y3RfaWQgb2YgcHJvZHVjdF9za3UgKXtcclxuXHJcbiAgICAgICAgbGV0IHByb2plY3QgPSBhd2FpdCB0aGlzLlByb2R1Y3RzLmZpbmRPbmUoe19pZDogcHJvZHVjdF9pZH0se3Byb2plY3Rpb246eydzdG9jayc6MX19KTtcclxuICAgICAgICBsZXQgc3RvY2tfYXJyYXkgPSBwcm9qZWN0LnN0b2NrO1xyXG5cclxuICAgICAgICAvLyDljZjntJTjgavjgZnjgbnjgabjga7lnKjluqvllYblk4HjgIHnn63mnJ/plpPlj5bjgorlr4TjgZvlj6/og73llYblk4HjgpLlkIjnrpdcclxuICAgICAgICBmb3IoIGxldCBzdG9jayBvZiBzdG9ja19hcnJheSApe1xyXG4gICAgICAgICAgcXVhbnRpdHlfc2t1ICs9IHN0b2NrLnF1YW50aXR5O1xyXG4gICAgICAgIH1cclxuXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHF1YW50aXRpZXMucHVzaChxdWFudGl0eV9za3UpO1xyXG5cclxuICAgIH1cclxuXHJcbiAgICAvLyDjgrvjg4Pjg4jllYblk4Hjga7loLTlkIjjgIHkuIDnlarlsJHjgarjgYTllYblk4HmlbDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBxdWFudGl0eSA9IE1hdGgubWluLmFwcGx5KCBudWxsLCBxdWFudGl0aWVzICk7XHJcblxyXG4gICAgcmV0dXJuIHF1YW50aXR5O1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgovjgIJcclxuICAgKiBcclxuICAgKiDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6vjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcclxuICAgKiBjbGFzczHjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcclxuICAgKiBcclxuICAgKiDnibnlrprjga7lsZ7mgKfvvIjjgqvjg6njg7zjgarjganvvInjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcclxuICAgKiBjbGFzczHjgavlgKTjgpLmjIflrprjgZfjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcclxuICAgKiDjgoLjgZdjbGFzczLjga7jgb/mjIflrprjgZfjgZ/jgYTloLTlkIjjga9jbGFzczHjgatudWxs44KS5oyH5a6a44GZ44KL44CCXHJcbiAgICogXHJcbiAgICog5L6L77yaSkstMTAw44GuQkxBQ0vjga7llYblk4HnlLvlg4/jgpJcclxuICAgKiDjgZnjgbnjgabjga7jgrXjgqTjgrrvvIhTLE0sTCxYTCwyWEwsM1hMLDRYTOKApu+8ieOBq+mWoumAo+S7mOOBkeOCi+WgtOWQiFxyXG4gICAqIHNldEltYWdlKCB1cGxvYWRJZCwgJ0pLLTEwMCcsICdCTEFDSycgKTtcclxuICAgKiBcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdXBsb2FkSWQg5LiA5Zue44Gu44Ki44OD44OX44Ot44O844OJ55S75YOP44KS5p2f44Gt44Gm44GE44KLSUTjgIJtZXRlb3Ljg4fjg7zjgr/jg5njg7zjgrnjgIFVcGxvYWRz44Kz44Os44Kv44K344On44Oz5YaF44OJ44Kt44Ol44Oh44Oz44OI44GudXBsb2FkSWTjg5fjg63jg5Hjg4bjgqNcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIHNldEltYWdlKCB1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwgKXtcclxuXHJcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jga7mg4XloLHlj5blvpdcclxuICAgIGxldCBpbWFnZXMgPSBVcGxvYWRzLmZpbmQoe3VwbG9hZElkOnVwbG9hZElkfSkuZmV0Y2goKS5tYXAoIHYgPT4gdi51cGxvYWRlZEZpbGVOYW1lICk7XHJcblxyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge307XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbDtcclxuICAgIGlmKCBjbGFzczEgKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxO1xyXG4gICAgaWYoIGNsYXNzMiApIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczI7XHJcbiAgICBcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlcixcclxuICAgICAge1xyXG4gICAgICAgICRwdXNoOntcclxuICAgICAgICAgIGltYWdlczoge1xyXG4gICAgICAgICAgICAkZWFjaDogaW1hZ2VzXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIC8vIOeZu+mMsuOBl+OBn+eUu+WDj+ODleOCoeOCpOODq+WQjeS4gOimp1xyXG4gICAgcmV0dXJuIGltYWdlcztcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIFxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr55m76Yyy44GV44KM44Gm44GE44KL55S75YOP5oOF5aCx44KS5YmK6Zmk44GZ44KL44CCXHJcbiAgICogXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKi9cclxuICBhc3luYyBjbGVhbkltYWdlKCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCApe1xyXG5cclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9O1xyXG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWw7XHJcbiAgICBpZiggY2xhc3MxICkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMTtcclxuICAgIGlmKCBjbGFzczIgKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyO1xyXG4gICAgXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxyXG4gICAgICBmaWx0ZXIsXHJcbiAgICAgIHtcclxuICAgICAgICAkc2V0OntcclxuICAgICAgICAgIGltYWdlczogW11cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGl0ZW1DdWJlMyhjcmVhdG9yX2lkLCBpdGVtKXtcclxuICAgIHJldHVybiBuZXcgaXRlbUN1YmUzKGNyZWF0b3JfaWQsIGl0ZW0pO1xyXG4gIH1cclxuXHJcbn1cclxuXHJcbmNsYXNzIGl0ZW1DdWJlMyB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCBjcmVhdG9yX2lkLCBpdGVtKXtcclxuXHJcbiAgICAvLyBwcm9kdWN0X2lkXHJcbiAgICBsZXQgcHJvZHVjdF9pZCA9ICdOVUxMJztcclxuICAgIGlmKCBpdGVtLnNoYXJha3VTaG9wICl7XHJcbiAgICAgIHByb2R1Y3RfaWQgPSBpdGVtLnNoYXJha3VTaG9wLnByb2R1Y3RfaWQ7XHJcbiAgICB9XHJcblxyXG4gICAgLy8g5LiL6KiY44Gu5b2i5byP44KS5L2c44KLXHJcbiAgICAvLyDjg6Hjg7zjgqvjg7zjgrPjg7zjg4kv5bGe5oCnMe+8iOOCq+ODqeODvOOBquOBqe+8iS/lsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXHJcbiAgICBsZXQgbW9kZWxDbGFzcyA9IFtdO1xyXG4gICAgaWYoaXRlbS5tb2RlbCkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0ubW9kZWwpO1xyXG4gICAgaWYoaXRlbS5jbGFzczFfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMV92YWx1ZSk7XHJcbiAgICBpZihpdGVtLmNsYXNzMl92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MyX3ZhbHVlKTtcclxuXHJcbiAgICAvLyDllYblk4HnqK7liKXjgpLlibLjgorlvZPjgabjgotcclxuICAgIGxldCBwcm9kdWN0X3R5cGVfaWQ7XHJcbiAgICBzd2l0Y2goaXRlbS5kZWxpdmVyeSl7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6IHByb2R1Y3RfdHlwZV9pZCA9IDE7IGJyZWFrO1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOiBwcm9kdWN0X3R5cGVfaWQgPTI7IGJyZWFrO1xyXG4gICAgICBkZWZhdWx0IDogcHJvZHVjdF90eXBlX2lkID0gMTsgYnJlYWs7XHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB44K/44Kw44KS6Kit5a6a44GZ44KLXHJcbiAgICBsZXQgdGFncyA9IFtdO1xyXG4gICAgc3dpdGNoKGl0ZW0uZGVsaXZlcnkpe1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOiB0YWdzLnB1c2goe3RhZzo0LHNldDonb24nfSx7dGFnOjUsc2V0OidvZmYnfSk7IGJyZWFrO1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOiB0YWdzLnB1c2goe3RhZzo1LHNldDonb24nfSx7dGFnOjQsc2V0OidvZmYnfSk7IGJyZWFrO1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeODh+ODvOOCv+OCkuS9nOOCi1xyXG4gICAgbGV0IGRhdGEgPSB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RfaWQsXHJcbiAgICAgIG5hbWU6IGAke21vZGVsQ2xhc3Muam9pbignLycpfSAke2l0ZW0ubmFtZX0gJHtpdGVtLmphbl9jb2RlfWAsXHJcbiAgICAgIGRlc2NyaXB0aW9uX2RldGFpbDogaXRlbS5kZXNjcmlwdGlvbixcclxuICAgICAgcHJvZHVjdF9jb2RlOiBpdGVtLm1vZGVsLFxyXG4gICAgICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcclxuICAgICAgcHJpY2UwMjogaXRlbS5zYWxlc19wcmljZSxcclxuICAgICAgaW1hZ2VzOiBpdGVtLmltYWdlcyxcclxuICAgICAgcHJvZHVjdF90eXBlX2lkOiBwcm9kdWN0X3R5cGVfaWQsXHJcbiAgICAgIHRhZ3M6IHRhZ3NcclxuICAgIH07XHJcblxyXG4gICAgT2JqZWN0LmFzc2lnbiggdGhpcywge2NyZWF0b3JfaWQ6IGNyZWF0b3JfaWR9ICk7XHJcbiAgICBPYmplY3QuYXNzaWduKCB0aGlzLCBkYXRhICk7XHJcbiAgICBPYmplY3QuYXNzaWduKCB0aGlzLCBpdGVtLm1hbGwuc2hhcmFrdVNob3ApO1xyXG5cclxuICB9XHJcbn0iLCJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInO1xyXG5cclxuZXhwb3J0IGNsYXNzIE1vbmdvQ29sbGVjdGlvbntcclxuICBzdGF0aWMgYXN5bmMgZ2V0KHBsdWcpe1xyXG4gICAgbGV0IGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpO1xyXG4gICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpO1xyXG4gICAgcmV0dXJuIGRiLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKTtcclxuICB9XHJcbn0iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnO1xyXG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCc7XHJcblxyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlTUUwge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9maWxlKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pjg5fjg7zjg6vliJ3mnJ/ljJZcclxuICAgIHRoaXMucG9vbCA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZSk7XHJcblxyXG4gICAgLy8g6KSH5pWw6KGM44K544OG44O844OI44Oh44Oz44OI5a++5b+cXHJcbiAgICBsZXQgcHJvZmlsZU11bHRpID0ge211bHRpcGxlU3RhdGVtZW50czp0cnVlfTtcclxuICAgIE9iamVjdC5hc3NpZ24oIHByb2ZpbGVNdWx0aSwgcHJvZmlsZSApO1xyXG4gICAgdGhpcy5wb29sTXVsdGkgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGVNdWx0aSk7XHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZm9ybWF0RGF0ZSggZGF0ZSApe1xyXG4gICAgcmV0dXJuIG1vbWVudChkYXRlKS5mb3JtYXQoKS5zdWJzdHJpbmcoMCwxOSkucmVwbGFjZSgnVCcsICcgJyk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsIFxyXG4gICAqL1xyXG4gIHF1ZXJ5KHNxbCkge1xyXG5cclxuICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+eiuueri1xyXG4gICAgLy8gbGV0IGNvbiA9IGF3YWl0IHRoaXMuZ2V0Q29uKCk7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxyXG4gICAgICAudGhlbihcclxuICAgICAgICAoY29uKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgICAgIGFzeW5jIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcclxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsLCAoZSwgcmVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7PplovmlL5cclxuICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKCk7XHJcbiAgICAgICAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICAgICAgICByZWplY3QoZSk7XHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXMpO1xyXG4gICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnRfKHNxbCl7XHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xyXG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZDtcclxuICB9XHJcbiAgXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlIFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvOOAgW51bGzjgIFqYXZhc2NyaXB0LT5teXNxbOaXpeS7mOWkieaPm+OBq+OCguWvvuW/nFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhX3NxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICAgYXN5bmMgcXVlcnlJbnNlcnQodGFibGUsIGRhdGEgPSB7fSwgZGF0YV9zcWwgPSB7fSl7XHJcblxyXG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgO1xyXG5cclxuICAgIGxldCBtYXAgPSBuZXcgTWFwKCk7XHJcbiAgICBmb3IoIGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpICl7XHJcblxyXG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCl7XHJcbiAgICAgICAgbWFwLnNldChrLCAnTlVMTCcpO1xyXG4gICAgICB9XHJcbiAgICAgIGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKTtcclxuICAgICAgfVxyXG4gICAgICBlbHNle1xyXG4gICAgICAgIG1hcC5zZXQoaywgYFwiJHtkYXRhW2tdfVwiYCk7XHJcbiAgICAgIH1cclxuXHJcbiAgICB9XHJcbiAgICBmb3IoIGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGFfc3FsKSApe1xyXG4gICAgICBtYXAuc2V0KGssIGRhdGFfc3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YV9zcWxba10pO1xyXG4gICAgfVxyXG5cclxuICAgIHNxbCArPSBgKCAke1suLi5tYXAua2V5cygpXS5qb2luKCcsJyl9ICkgYDtcclxuXHJcbiAgICBzcWwgKz0gYFZBTFVFUyggJHtbLi4ubWFwLnZhbHVlcygpXS5qb2luKCcsJyl9ICkgYDtcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xyXG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZDtcclxuXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdGFibGUgXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YV9zcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlVcGRhdGUodGFibGUsIGZpbHRlciwgZGF0YSwgZGF0YV9zcWwpe1xyXG4gICAgbGV0IHNxbCA9IGBVUERBVEUgJHt0YWJsZX0gU0VUIGA7XHJcblxyXG4gICAgbGV0IHVwZGF0ZXMgPSBbXTtcclxuICAgIGZvciggbGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YSkgKXtcclxuICAgICAgdXBkYXRlcy5wdXNoKGAke2t9PVwiJHtkYXRhW2tdfVwiYCk7XHJcbiAgICB9XHJcbiAgICBmb3IoIGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGFfc3FsKSApe1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhX3NxbFtrXX1gKTtcclxuICAgIH1cclxuICAgIHNxbCArPSB1cGRhdGVzLmpvaW4oJywnKTtcclxuXHJcbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYDtcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xyXG4gICAgcmV0dXJuIHJlcztcclxuICB9XHJcblxyXG4gIC8vIGVuYWJsZSB0byB1c2UgbXVsdGlwbGUgc3RhdGVtZW50c1xyXG4gIGFzeW5jIHF1ZXJ5TXVsdGkoc3FsKSB7XHJcbiAgICBsZXQgcG9vbFN3YXAgPSB0aGlzLnBvb2w7XHJcbiAgICB0aGlzLnBvb2wgPSB0aGlzLnBvb2xNdWx0aTtcclxuICAgIHRyeXtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgICAgcmV0dXJuIHJlcztcclxuICAgIH1cclxuICAgIGZpbmFsbHl7XHJcbiAgICAgIHRoaXMucG9vbCA9IHBvb2xTd2FwO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3RhcnRUcmFuc2FjdGlvbigpe1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgU1RBUlQgVFJBTlNBQ1RJT047YCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBjb21taXQoKXtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYENPTU1JVDtgKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHJvbGxiYWNrKCl7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBST0xMQkFDSztgKTtcclxuICB9XHJcblxyXG4gIHN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQgPSAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IChlKSA9PiB7fSkge1xyXG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcclxuICAgICAgLnRoZW4oXHJcbiAgICAgICAgKGNvbikgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAgICAgICBhc3luYyAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXHJcbiAgICAgICAgICAgICAgY29uLnF1ZXJ5KHNxbClcclxuICAgICAgICAgICAgICAgIC5vbigncmVzdWx0JyxcclxuICAgICAgICAgICAgICAgICAgKHJlY29yZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbi5wYXVzZSgpO1xyXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0KHJlY29yZCk7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uLnJlc3VtZSgpO1xyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlcnJvcicsIChlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIG9uRXJyb3IoZSk7XHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKCk7XHJcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgICAgIH0pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApO1xyXG5cclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgICAgfSk7XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIGdldENvbigpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAvLyDjg5fjg7zjg6vjgYvjgonjga7jgrPjg43jgq/jgrfjg6fjg7PnjbLlvpdcclxuICAgICAgICAgIHRoaXMucG9vbC5nZXRDb25uZWN0aW9uKChlLCBjb24pID0+IHtcclxuICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICByZWplY3QoZSk7XHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgcmVzb2x2ZShjb24pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKFxyXG4gICAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlO1xyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICB9O1xyXG5cclxufSIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIFJlcG9ydCB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgdGhpcy5yZWNvcmQgPSBbXTtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IoKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIHBoYXNlKG5hbWUgPSAnJywgZm4gPSBhc3luYyAoKSA9PiB7fSkge1xyXG5cclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IoKTtcclxuICAgIGxldCByZWMgPSB7fTtcclxuXHJcbiAgICB0cnkge1xyXG5cclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGZuKCk7XHJcblxyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdzdWNjZXNzJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHJlc1xyXG4gICAgICB9KTtcclxuXHJcbiAgICB9IGNhdGNoIChlKSB7XHJcblxyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiBlXHJcbiAgICAgIH0pO1xyXG5cclxuICAgIH0gZmluYWxseSB7XHJcblxyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci50b3RhbCkge1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgICBpdGVyYXRvcjogdGhpcy5pdGVyYXRvclxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9XHJcbiAgICAgIHRoaXMucmVjb3JkLnB1c2gocmVjKTtcclxuXHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcbiAgaVN1Y2Nlc3MobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLnN1Y2Nlc3MobmV3UmVjb3JkKTtcclxuICB9XHJcblxyXG4gIGlFcnJvcihuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IuZXJyb3IobmV3UmVjb3JkKTtcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCgpe1xyXG4gICAgbGV0IGl0ZUVycm9yID0gdGhpcy5pdGVyYXRvci50cmFjZS5lcnJvci50b3RhbDtcclxuICAgIGxldCBwaGFFcnJvciA9IGZhbHNlO1xyXG4gICAgZm9yKCBsZXQgcmVjIG9mIHRoaXMucmVjb3JkICl7XHJcbiAgICAgIGlmKCByZWMudHlwZSA9PT0gJ2Vycm9yJyl7XHJcbiAgICAgICAgcGhhRXJyb3IgPSB0cnVlO1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXRlRXJyb3IgfHwgcGhhRXJyb3I7XHJcbiAgfVxyXG5cclxuICBwdWJsaXNoKCkge1xyXG4gICAgaWYodGhpcy5lcnJvck9jdXJyZWQoKSl7XHJcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IodGhpcy5yZWNvcmQpO1xyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMucmVjb3JkO1xyXG4gIH1cclxuXHJcbn1cclxuXHJcblxyXG5jbGFzcyBJdGVyYXRvciB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKCkge1xyXG4gICAgdGhpcy50b3RhbCA9MDtcclxuICAgIHRoaXMudHJhY2UgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IHtcclxuICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICByZWNvcmRzOiBbXVxyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjoge1xyXG4gICAgICAgIHRvdGFsOiAwLFxyXG4gICAgICAgIHJlY29yZHM6IFtdXHJcbiAgICAgIH0sXHJcbiAgICB9O1xyXG4gIH1cclxuXHJcbiAgc3VjY2VzcyhuZXdSZWNvcmQpIHtcclxuICAgIGlmKG5ld1JlY29yZCl7XHJcbiAgICAgIHRoaXMudHJhY2Uuc3VjY2Vzcy5yZWNvcmRzLnB1c2gobmV3UmVjb3JkKTtcclxuICAgIH1cclxuICAgIHRoaXMudHJhY2Uuc3VjY2Vzcy50b3RhbCsrO1xyXG4gICAgdGhpcy50b3RhbCsrO1xyXG4gIH1cclxuICBlcnJvcihuZXdSZWNvcmQpIHtcclxuICAgIGlmKG5ld1JlY29yZCAmJiBuZXdSZWNvcmQgIT09IHt9ICYmIG5ld1JlY29yZCAhPT0nJyApe1xyXG4gICAgICB0aGlzLnRyYWNlLmVycm9yLnJlY29yZHMucHVzaChKU09OLnBhcnNlKG5ld1JlY29yZCkpO1xyXG4gICAgfVxyXG4gICAgdGhpcy50cmFjZS5lcnJvci50b3RhbCsrO1xyXG4gICAgdGhpcy50b3RhbCsrO1xyXG4gIH1cclxuXHJcbn1cclxuIl19
