var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/route/upload/image.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

// WebApp.connectHandlers.use('/upload', (req, res, next) => {
//   res.writeHead(200);
//   res.end(`Hello world from: ${Meteor.release}`);
// });

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

// Requires multiparty

var _connectMultiparty = require('connect-multiparty');

var _connectMultiparty2 = _interopRequireDefault(_connectMultiparty);

var _importsCollections = require('../../../imports/collections');

var multipartyMiddleware = (0, _connectMultiparty2['default'])();

var route = '/upload/image';

// WebApp.connectHandlers.use('/upload', fuc.uploadFile );
WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, function (req, resp) {
  // don't forget to delete all req.files when done

  var reader = Meteor.wrapAsync(_fs2['default'].readFile);
  var writer = Meteor.wrapAsync(_fs2['default'].writeFile);
  var uploadId = (0, _uniqid2['default'])();

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = req.files.file[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var file = _step.value;

      var data = reader(file.path);
      // ファイル名の重複を避けるため、一意のファイル名を作成する
      // 楽天のファイル名文字数制限20に合わせる
      var filename = (0, _uniqid2['default'])() + '.jpg';

      // set the correct path for the file not the temporary one from the API:
      var savePath = req.body.imagedir + '/' + filename;

      // copy the data from the req.files.file.path and paste it to file.path

      // アップロード結果を記録する
      var doc = {
        uploadId: uploadId,
        clientFileName: file.name,
        uploadedFileName: filename
      };

      try {
        writer(savePath, data);
      } catch (err) {
        doc.error = err;
      }
      _importsCollections.Uploads.insert(doc);

      delete file;
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator['return']) {
        _iterator['return']();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube/cubemig.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _crypto = require('crypto');

var _crypto2 = _interopRequireDefault(_crypto);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsUtilReport = require('../../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsCollectionGroups = require('../../imports/collection/groups');

var _importsCollectionFilters = require('../../imports/collection/filters');

var tag = 'cubemig';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.migrate', function callee$0$0(config) {
  var report, filter, testQuery, dstDb;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsCollectionFilters.Filter(config.srcFilterId);
        testQuery = 'SHOW DATABASES';
        dstDb = new _importsUtilMysql2['default'](config.dst.cred);
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(report.phase('Connect to Destination', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(dstDb.query(testQuery));

              case 2:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 6:
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(report.phase('Select loop in source', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this2 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  mobileNull: function mobileNull(record) {
                    var sql, couponCd, couponName, discountPrice, _res;

                    return regeneratorRuntime.async(function mobileNull$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          sql = '\n\n                INSERT dtb_customer\n                ( `customer_id`, `status`, `sex`, `job`, `country_id`, `pref`, `name01`, `name02`, `kana01`, `kana02`, `company_name`, `zip01`, `zip02`, `zipcode`, `addr01`, `addr02`, `email`, `tel01`, `tel02`, `tel03`, `fax01`, `fax02`, `fax03`, `birth`, `password`, `salt`, `secret_key`, `first_buy_date`, `last_buy_date`, `buy_times`, `buy_total`, `note`, `create_date`, `update_date`, `del_flg` )\n\n                VALUES( ' + record.customer_id + ' , ' + record.status + ' , ' + record.sex + ' , ' + record.job + ' , ' + record.country_id + ' , ' + record.pref + ' , ' + record.name01 + ' , ' + record.name02 + ' , ' + record.kana01 + ' , ' + record.kana02 + ' , ' + record.company_name + ' , ' + record.zip01 + ' , ' + record.zip02 + ' , ' + record.zipcode + ' , ' + record.addr01 + ' , ' + record.addr02 + ' , ' + record.email + ' , ' + record.tel01 + ' , ' + record.tel02 + ' , ' + record.tel03 + ' , ' + record.fax01 + ' , ' + record.fax02 + ' , ' + record.fax03 + ' , ' + record.birth + ' , ' + record.password + ' , ' + record.salt + ' , ' + record.secret_key + ' , ' + record.first_buy_date + ' , ' + record.last_buy_date + ' , ' + record.buy_times + ' , ' + record.buy_total + ' , ' + record.note + ' , ' + record.create_date + ' , ' + record.update_date + ' , ' + record.del_flg + ' )\n                \n                ';
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer', {
                            customer_id: record.customer_id,
                            status: record.status,
                            sex: record.sex,
                            job: record.job,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            email: record.email,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            birth: record.birth,
                            password: record.password,
                            salt: record.salt,
                            secret_key: record.secret_key,
                            first_buy_date: record.first_buy_date,
                            last_buy_date: record.last_buy_date,
                            buy_times: record.buy_times,
                            buy_total: record.buy_total,
                            note: record.note,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 4:
                          context$3$0.next = 9;
                          break;

                        case 6:
                          context$3$0.prev = 6;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 9:
                          context$3$0.prev = 9;
                          context$3$0.next = 12;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer_address', {
                            customer_address_id: null,
                            customer_id: record.customer_id,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 12:
                          context$3$0.next = 17;
                          break;

                        case 14:
                          context$3$0.prev = 14;
                          context$3$0.t1 = context$3$0['catch'](9);

                          report.iError(context$3$0.t1);

                        case 17:
                          context$3$0.prev = 17;
                          context$3$0.next = 20;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_mailmaga_customer', {
                            id: null,
                            customer_id: record.customer_id,
                            mailmaga_flg: record.mailmaga_flg,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 20:
                          context$3$0.next = 25;
                          break;

                        case 22:
                          context$3$0.prev = 22;
                          context$3$0.t2 = context$3$0['catch'](17);

                          report.iError(context$3$0.t2);

                        case 25:
                          couponCd = _crypto2['default'].randomBytes(8).toString('base64').substring(0, 11);
                          couponName = record.name01 + ' ' + record.name02 + ' 様 ご優待クーポン 会員番号:' + record.customer_id;
                          discountPrice = record.point + 500;
                          context$3$0.prev = 28;
                          context$3$0.next = 31;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_coupon', {
                            coupon_id: null,
                            coupon_cd: couponCd,
                            coupon_type: 3, // 全商品
                            coupon_name: couponName,
                            discount_type: 1,
                            coupon_use_time: 1,
                            coupon_release: 1,
                            discount_price: discountPrice,
                            discount_rate: null,
                            enable_flag: 1,
                            coupon_member: 1,
                            coupon_lower_limit: null,
                            customer_id: record.customer_id,
                            available_from_date: '2018-04-02 00:00:00',
                            available_to_date: '2019-05-02 00:00:00',
                            del_flg: 0
                          }, {
                            create_date: 'NOW()',
                            update_date: 'NOW()'
                          }));

                        case 31:
                          _res = context$3$0.sent;
                          context$3$0.next = 37;
                          break;

                        case 34:
                          context$3$0.prev = 34;
                          context$3$0.t3 = context$3$0['catch'](28);

                          report.iError(context$3$0.t3);

                        case 37:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this2, [[1, 6], [9, 14], [17, 22], [28, 34]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        report.iError(e);

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this2);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 8:
        return context$1$0.abrupt('return', report.publish());

      case 9:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, 'cubemig.serverCheck', function cubemigServerCheck(profile) {
  var db, res;
  return regeneratorRuntime.async(function cubemigServerCheck$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        db = new _importsUtilMysql2['default'](profile);
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(db.query('SHOW DATABASES'));

      case 3:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// setup group
//

// let plug = group.getPlug();

// checking connection
//

// process for each members
//

// // 値を整理
// for (let key of Object.keys(record)) {
//   if (record[key] === null);
//   else if (record[key].constructor.name === 'Date') {
//     // 日付を変換
//     record[key] = MySQL.formatDate(record[key]);
//     record[key] = `"${record[key]}"`;
//   }
// }

// dtb_customer に保存

// dtb_customer_address

// メルマガプラグイン plg_mailmaga_customer

// クーポン発行（ECCUBE2のポイント還元）
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/collection.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilMongo = require('../../imports/util/mongo');

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.collection';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.find', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var projection = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.find(query, { projection: projection }).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.aggregate', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.aggregate(query).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/items.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsServiceItems = require('../../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.items';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.setImage', function callee$0$0(plug, uploadId, model) {
  var class1 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var class2 = arguments.length <= 4 || arguments[4] === undefined ? null : arguments[4];
  var itemcon, uploaded;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.setImage(uploadId, model, class1, class2));

      case 5:
        uploaded = context$1$0.sent;
        return context$1$0.abrupt('return', uploaded);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.cleanImage', function callee$0$0(plug, model) {
  var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
  var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var itemcon;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.cleanImage(model, class1, class2));

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

/**
 * 指定された条件に一致するitemsコレクション内のドキュメントに、
 * アップロード済み画像を関連付けます。
 * @param
 */

/**
 * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceCube3api = require('../imports/service/cube3api');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var tag = 'cube';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.category', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('商品カテゴリの更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  UPDATE: function UPDATE(item, context) {
                    var results;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          if (!_lodash2['default'].isArray(item.mall.sharakuShop.categories)) {
                            context$3$0.next = 11;
                            break;
                          }

                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(api.modifyCategory(item.mall.sharakuShop.product_id, item.mall.sharakuShop.categories));

                        case 4:
                          results = context$3$0.sent;

                          // SQLクエリ結果を記録
                          report.iSuccess(results);
                          context$3$0.next = 11;
                          break;

                        case 8:
                          context$3$0.prev = 8;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 11:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this, [[1, 8]]);
                  }
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('在庫の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({

                  UPDATE: function UPDATE(item, context) {
                    var quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;
                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 5:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  }
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibItem', function callee$0$0(config) {
  var filter, targetDB, api, itemController, report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this6 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 6:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3への商品登録', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  INSERT: function INSERT(item, context) {
                    var col, cubeItem, insertRes;
                    return regeneratorRuntime.async(function INSERT$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.updateItem, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productCreate(cubeItem));

                        case 7:
                          insertRes = context$3$0.sent;
                          context$3$0.next = 10;
                          return regeneratorRuntime.awrap(col.update({
                            _id: item._id
                          }, {
                            $set: {
                              'mall.sharakuShop.product_id': insertRes.res.product_id,
                              'mall.sharakuShop.product_class_id': insertRes.res.product_class_id,
                              'mall.sharakuShop.product_stock_id': insertRes.res.product_stock_id
                            }
                          }));

                        case 10:

                          report.iSuccess();
                          context$3$0.next = 16;
                          break;

                        case 13:
                          context$3$0.prev = 13;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 16:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this5, [[1, 13]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 9:
        context$1$0.next = 11;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3商品情報の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this7 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  UPDATE: function UPDATE(item, context) {
                    var col, cubeItem, quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.updateItem, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productImageUpdate(cubeItem));

                        case 7:
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(api.productUpdate(cubeItem));

                        case 9:
                          context$3$0.next = 11;
                          return regeneratorRuntime.awrap(api.productTagUpdate(cubeItem));

                        case 11:
                          context$3$0.next = 13;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 13:
                          quantity = context$3$0.sent;
                          context$3$0.next = 16;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 16:

                          report.iSuccess();
                          context$3$0.next = 22;
                          break;

                        case 19:
                          context$3$0.prev = 19;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 22:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this7, [[1, 19]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this7);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 11:
        return context$1$0.abrupt('return', report.publish());

      case 12:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// カテゴリ更新

// クライアントが参照するための処理結果作成オブジェクト

// 商品にカテゴリーデータが記録されていれば処理する

// 商品情報データベースに記録された商品カテゴリー情報を、モールに適用する

//
// 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 商品情報登録と更新

// クライアントが参照するための処理結果作成オブジェクト

// item データベースへの登録
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/robotin.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var _fibers = require('fibers');

var _fibers2 = _interopRequireDefault(_fibers);

var _importsServiceRobotin = require('../imports/service/robotin');

var _importsServiceRobotin2 = _interopRequireDefault(_importsServiceRobotin);

var tag = 'robotin';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order.export', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 受注CSV 出力', function callee$1$0() {
          var workdir, workdirExport, orderCsvExport, itemS;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.order.workdir;
                workdirExport = workdir + '/' + config.order.workdirExport;
                orderCsvExport = config.order.ordercsvExport + '.csv';
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirExport));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 27:

                // 受注CSVを出力する
                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _importsServiceRobotin2['default'].createReadableOrder().on('error', function (err) {
                    mcb(err);
                  });

                  var transform = new _stream.Transform({
                    writableObjectMode: true,
                    readableObjectMode: true,
                    transform: function transform(chunk, enc, cb) {
                      cb(null, chunk.robotin);
                    }
                  });

                  var write = _fsExtra2['default'].createWriteStream(workdirExport + '/' + orderCsvExport).on('error', function (err) {
                    mcb(err);
                  }).on('finish', function () {
                    mcb();
                  });

                  read.pipe(transform).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(write);
                })();

              case 28:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this, [[3, 8], [10, 15], [17, 22]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.order.import', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this3 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 受注CSV 取込み', function callee$1$0() {
          var workdir, workdirImport, orderCsv, itemS;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.order.workdir;
                workdirImport = workdir + '/' + config.order.workdirImport;
                orderCsv = config.order.ordercsv + '.csv';
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirImport));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 27:

                // 受注CSVを読み込む
                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _fsExtra2['default'].createReadStream(workdirImport + '/' + orderCsv).on('error', function (err) {
                    mcb(err);
                  });
                  var write = new _stream.Writable({
                    objectMode: true,
                    write: function write(chunk, encoding, callback) {
                      var _this2 = this;

                      (0, _fibers2['default'])(function callee$4$0() {
                        return regeneratorRuntime.async(function callee$4$0$(context$5$0) {
                          while (1) switch (context$5$0.prev = context$5$0.next) {
                            case 0:
                              context$5$0.prev = 0;
                              context$5$0.next = 3;
                              return regeneratorRuntime.awrap(_importsServiceRobotin2['default'].importOrder(chunk, itemS));

                            case 3:
                              report.iSuccess();
                              context$5$0.next = 9;
                              break;

                            case 6:
                              context$5$0.prev = 6;
                              context$5$0.t0 = context$5$0['catch'](0);

                              callback(context$5$0.t0);

                            case 9:
                              callback();

                            case 10:
                            case 'end':
                              return context$5$0.stop();
                          }
                        }, null, _this2, [[0, 6]]);
                      }).run();
                    },
                    final: function final(callback) {
                      callback();
                      mcb();
                    }
                  }).on('error', function (err) {
                    return report.iError(err);
                  });

                  read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(write);
                })();

              case 28:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this3, [[3, 8], [10, 15], [17, 22]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.postlabel', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 送り状発行', function callee$1$0() {
          var workdir, workdirRead, workdirWrite, itemS, robo;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.postlabel.workdir;
                workdirRead = workdir + '/' + config.postlabel.workdirRead;
                workdirWrite = workdir + '/' + config.postlabel.workdirWrite;
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirRead));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                context$2$0.prev = 24;
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirWrite));

              case 27:
                context$2$0.next = 31;
                break;

              case 29:
                context$2$0.prev = 29;
                context$2$0.t3 = context$2$0['catch'](24);

              case 31:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 34;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 34:
                robo = new _importsServiceRobotin2['default']();

                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _fsExtra2['default'].createReadStream(workdirRead + '/' + config.postlabel.ordercsv + '.csv').on('error', function (err) {
                    mcb(err);
                  });
                  var write = new _stream.Writable({
                    objectMode: true,
                    write: function write(chunk, encoding, callback) {
                      robo.importOrderTemp(chunk, itemS);
                      callback();
                    },
                    final: function final(callback) {
                      callback();
                      mcb();
                    }
                  });

                  read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(write);
                })();

                // 送り状種別ごとに繰り返す
                config.postlabel.labeltypes.forEach(function (labelOption) {
                  try {
                    _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                      var read = _fsExtra2['default'].createReadStream(workdirRead + '/' + labelOption.readcsv + '.csv').on('error', function () {
                        mcb();
                      }); // ファイルがない場合は無視
                      var transform = new _stream.Transform({
                        readableObjectMode: true,
                        writableObjectMode: true,
                        transform: function transform(chunk, encoding, callback) {
                          var record = undefined;
                          try {
                            (0, _fibers2['default'])(function () {
                              record = robo[labelOption.method](chunk, labelOption);
                              callback(null, record);
                            }).run();
                          } catch (error) {
                            mcb(error);
                          }
                        }
                      });
                      var write = _fsExtra2['default'].createWriteStream(workdirWrite + '/' + labelOption.writecsv + '.csv').on('finish', function () {
                        report.iSuccess();
                        mcb();
                      }).on('error', function (error) {
                        mcb(error);
                      });

                      read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: labelOption.columns === true ? true : null })).pipe(transform).pipe(_csv2['default'].stringify({ header: labelOption.columns })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(write);
                    })();
                  } catch (error) {
                    report.iError(error);
                  }
                });

              case 37:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[3, 8], [10, 15], [17, 22], [24, 29]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.itemcode', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this5 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 外部連携商品番号', function callee$1$0() {
          var workdir, itemController, read, writeCsv;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.itemcode.workdir;
                context$2$0.prev = 1;
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 4:
                context$2$0.next = 8;
                break;

              case 6:
                context$2$0.prev = 6;
                context$2$0.t0 = context$2$0['catch'](1);

              case 8:
                context$2$0.prev = 8;
                context$2$0.next = 11;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 11:
                context$2$0.next = 22;
                break;

              case 13:
                context$2$0.prev = 13;
                context$2$0.t1 = context$2$0['catch'](8);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 18;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 18:
                read = itemController.Items.find({ model: { $ne: '' } }).stream();

                writeCsv = function writeCsv(read, tf, filename) {
                  var robotin = new _stream.Transform({
                    readableObjectMode: true,
                    writableObjectMode: true,
                    transform: function transform(chunk, encoding, callback) {
                      (0, _fibers2['default'])(function () {
                        var data = tf(chunk);
                        callback(null, data);
                      }).run();
                    }
                  });
                  var count = 0;
                  var clearnum = new _stream.Transform({
                    encoding: 'utf8',
                    transform: function transform(chunk, encoding, callback) {
                      var str = chunk.toString();
                      if (count === 0) {
                        str = str.replace(/_\d+?/g, '');
                      }
                      count++;
                      callback(null, str);
                    }
                  });
                  var writecsv = _fsExtra2['default'].createWriteStream(filename + '.csv');
                  writecsv.on('error', function (e) {
                    throw _meteorMeteor.Meteor.Error('CSVファイル書き込みエラー');
                  });

                  read.pipe(robotin).pipe(_csv2['default'].stringify({ header: true })).pipe(clearnum).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(writecsv);
                };

                writeCsv(read, _importsServiceItems2['default'].convertItemRobotinItem, workdir + '/' + config.itemcode.csvNameItem);

                writeCsv(read, _importsServiceItems2['default'].convertItemRobotinSelect, workdir + '/' + config.itemcode.csvNameSelect);

              case 22:
                throw new _meteorMeteor.Meteor.Error('正しい作業ディレクトリが用意されていませんでした。\n[' + workdir + ']');

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this5, [[1, 6], [8, 13]]);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 商品データベースへの接続準備

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 商品データベースへの接続準備

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 書き込みフォルダ

// workdir が準備されていたら実行する

// 受注CSVを読み込む

//
// Robot-in
// 外部連携商品番号

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// workdir が準備されていたら実行する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/tooltest.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _meteorMeteor = require('meteor/meteor');

var tag = 'tool';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.test', function callee$0$0(config) {
  var report, filter, newLocal;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        context$1$0.next = 4;
        return regeneratorRuntime.awrap(filter.foreach({}, function callee$1$0(e) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                throw e;

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 4:
        newLocal = context$1$0.sent;
        context$1$0.next = 7;
        return regeneratorRuntime.awrap(report.phase('フィルターテスト', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                return context$2$0.abrupt('return', newLocal);

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 7:
        return context$1$0.abrupt('return', report.publish());

      case 8:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// 商品情報更新

// クライアントが参照するための処理結果作成オブジェクト
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowma.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _importsServiceWowmaApi = require('../imports/service/wowmaApi');

var _importsServiceWowmaApi2 = _interopRequireDefault(_importsServiceWowmaApi);

var _importsUtilError = require('../imports/util/error');

var _importsUtilError2 = _interopRequireDefault(_importsUtilError);

var tag = 'wowma';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateItem.info', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品情報を更新する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     },
                    //     {
                    //       'mall.wowma.itemCode': '10004942' // JK-120
                    //     }
                    // {
                    //   'mall.wowma.itemCode': '10005402'
                    // },
                    // {
                    //   'mall.wowma.itemCode': '10004743'
                    // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        Object.assign(item, config.itemInfo['default']);
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 4:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 8:
                        context$3$0.prev = 8;
                        context$3$0.t0 = context$3$0['catch'](1);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 8]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.deliveryMethod', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品の配送方法を設定する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     },
                    //     {
                    //       'mall.wowma.itemCode': '10004942' // JK-120
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        context$3$0.t0 = Object;
                        context$3$0.t1 = item;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.convertItemWowmaCreateDeliveryMethod(item.itemCode));

                      case 4:
                        context$3$0.t2 = context$3$0.sent;
                        context$3$0.t0.assign.call(context$3$0.t0, context$3$0.t1, context$3$0.t2);
                        context$3$0.prev = 6;
                        context$3$0.next = 9;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 9:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 13:
                        context$3$0.prev = 13;
                        context$3$0.t3 = context$3$0['catch'](6);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t3));

                      case 16:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[6, 13]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.open', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this6 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品データベース上の商品を公開する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        item.saleStatus = 1;
                        item.limitedPasswd = 'NULL';
                        context$3$0.prev = 2;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 5:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 9:
                        context$3$0.prev = 9;
                        context$3$0.t0 = context$3$0['catch'](2);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 12:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5, [[2, 9]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this7 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 在庫更新', function callee$1$0() {
          var itemController, cur, item, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, e, api, res;

          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    //   ,{
                    //     $or: [
                    //       {
                    //         'mall.wowma.itemCode': '10005402'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': 'gk-163'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': '10004743'
                    //       }
                    //     ]
                    //   }
                    ]
                  }
                }, {
                  // 配送方法の違いを省く
                  $group: {
                    _id: {
                      itemCode: '$mall.wowma.itemCode',
                      choicesStockHorizontalCode: '$mall.wowma.HChoiceName',
                      choicesStockVerticalCode: '$mall.wowma.VChoiceName'
                    },
                    item: {
                      $first: '$_id'
                    }
                  }
                }, {
                  // 商品ページごと（商品コード）にグループ化する
                  $group: {
                    _id: '$_id.itemCode',
                    variations: {
                      $push: {
                        _id: '$item',
                        choicesStockHorizontalCode: '$_id.choicesStockHorizontalCode',
                        choicesStockVerticalCode: '$_id.choicesStockVerticalCode'
                      }
                    }
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id',
                    variations: '$variations'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;

              case 6:
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(cur.hasNext());

              case 8:
                if (!context$2$0.sent) {
                  context$2$0.next = 53;
                  break;
                }

                context$2$0.next = 11;
                return regeneratorRuntime.awrap(cur.next());

              case 11:
                item = context$2$0.sent;
                _iteratorNormalCompletion = true;
                _didIteratorError = false;
                _iteratorError = undefined;
                context$2$0.prev = 15;
                _iterator = item.variations[Symbol.iterator]();

              case 17:
                if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                  context$2$0.next = 26;
                  break;
                }

                e = _step.value;
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(itemController.getStock(e._id));

              case 21:
                e.stock = context$2$0.sent;

                delete e._id;

              case 23:
                _iteratorNormalCompletion = true;
                context$2$0.next = 17;
                break;

              case 26:
                context$2$0.next = 32;
                break;

              case 28:
                context$2$0.prev = 28;
                context$2$0.t0 = context$2$0['catch'](15);
                _didIteratorError = true;
                _iteratorError = context$2$0.t0;

              case 32:
                context$2$0.prev = 32;
                context$2$0.prev = 33;

                if (!_iteratorNormalCompletion && _iterator['return']) {
                  _iterator['return']();
                }

              case 35:
                context$2$0.prev = 35;

                if (!_didIteratorError) {
                  context$2$0.next = 38;
                  break;
                }

                throw _iteratorError;

              case 38:
                return context$2$0.finish(35);

              case 39:
                return context$2$0.finish(32);

              case 40:
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.prev = 41;
                context$2$0.next = 44;
                return regeneratorRuntime.awrap(api.updateStock([item]));

              case 44:
                res = context$2$0.sent;

                report.iSuccess(res);
                context$2$0.next = 51;
                break;

              case 48:
                context$2$0.prev = 48;
                context$2$0.t1 = context$2$0['catch'](41);

                report.iError(context$2$0.t1);

              case 51:
                context$2$0.next = 6;
                break;

              case 53:
                cur.close();

              case 54:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this7, [[15, 28, 32, 40], [33,, 35, 39], [41, 48]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.searchItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this9 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, workdir, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this8 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.prev = 4;
                context$2$0.next = 7;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 7:
                context$2$0.next = 11;
                break;

              case 9:
                context$2$0.prev = 9;
                context$2$0.t0 = context$2$0['catch'](4);

              case 11:
                workdir = config.workdir + '/items_' + new Date().getTime();
                context$2$0.prev = 12;
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 15:
                context$2$0.next = 19;
                break;

              case 17:
                context$2$0.prev = 17;
                context$2$0.t1 = context$2$0['catch'](12);

              case 19:
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var options, repos, filename;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          options = JSON.parse(JSON.stringify(config.wowmaApi));

                          options.uri = options.uri + '/searchItemInfo';
                          options.qs.itemCode = item.mall.wowma.itemCode;

                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

                        case 5:
                          repos = context$3$0.sent;
                          filename = workdir + '/' + item.model + '.xml';
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(_fsExtra2['default'].writeFile(filename, repos));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this8);
                  } }));

              case 21:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this9, [[4, 9], [12, 17]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// WOWMA 商品情報の変更

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品の配送方法を設定する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品データベース上の商品を公開する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 在庫情報の作成

// let resMongo = await cur.toArray()
// return resMongo

// リクエストボディ

// 在庫を設定する

//
// 在庫更新リクエスト

//
// WOWMA 商品検索

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 作業フォルダを作成する

// APIから取得した商品情報を保存する場所

// 作業フォルダを作成する

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowmaApi.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'wowmaApi';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.getItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.WowmaApiItemFilter(config.wowmaApi, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          report.iSuccess(item);

                        case 1:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 6:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 8:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// WOWMA商品情報取得

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(config.workdir)
// } catch (e) {}

// // APIから取得した商品情報を保存する場所
// const workdir = `${config.workdir}/items_${(new Date()).getTime()}`
// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(workdir)
// } catch (e) {}

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/yauct.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilPacket = require('../imports/util/packet');

var _importsUtilPacket2 = _interopRequireDefault(_importsUtilPacket);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var prefix = 'packet';
var tag = 'yauct';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク受注', function callee$1$0() {
          var itemController, workdir, r, w;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                workdir = config.workdir + '/order';
                r = _fsExtra2['default'].createReadStream(workdir + '/' + config.orderLoadfile);
                w = _fsExtra2['default'].createWriteStream(workdir + '/' + config.orderSavefile);

                r.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(_csv2['default'].transform(function callee$2$0(record, callback) {
                  var err;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        err = null;
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.getModelClass(record['管理番号']));

                      case 4:
                        record['管理番号'] = context$3$0.sent;
                        context$3$0.next = 10;
                        break;

                      case 7:
                        context$3$0.prev = 7;
                        context$3$0.t0 = context$3$0['catch'](1);

                        err = context$3$0.t0;

                      case 10:
                        callback(err, record);

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 7]]);
                })).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(w);

              case 7:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibit', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク出品', function callee$1$0() {
          var filter, itemController, packet, workdir, uploaddir, cd, filename, name, fields, header, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                packet = new _importsUtilPacket2['default'](config.packetSize);
                context$2$0.prev = 5;
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 8:
                context$2$0.next = 12;
                break;

              case 10:
                context$2$0.prev = 10;
                context$2$0.t0 = context$2$0['catch'](5);

              case 12:
                workdir = config.workdir + '/work';
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(workdir));

              case 15:
                context$2$0.next = 17;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 17:
                uploaddir = config.workdir + '/upload';
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(uploaddir));

              case 20:
                context$2$0.next = 22;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(uploaddir));

              case 22:
                cd = null;
                filename = null;
                name = null;
                fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
                header = fields.map(function (v) {
                  return '"' + v + '"';
                }).join(',') + '\n';

                // パケット化開始時
                packet.onPacketStart = function callee$2$0(packetCount) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        name = prefix + ('00000' + packetCount).slice(-5);
                        cd = workdir + '/' + name;
                        filename = cd + '/' + config.csvFileName;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(cd));

                      case 5:
                        context$3$0.next = 7;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(header, 'Shift_JIS')));

                      case 7:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // パケット化時
                packet.onPacket = function callee$2$0(arg) {
                  var yauct, item, record, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, img, imgSrc, imgTgt;

                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        yauct = arg.yauct;
                        item = arg.item;
                        record = fields.map(function (v) {
                          return yauct[v] ? '"' + yauct[v] + '"' : '""';
                        }).join(',') + '\n';
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(record, 'Shift_JIS')));

                      case 5:
                        _iteratorNormalCompletion = true;
                        _didIteratorError = false;
                        _iteratorError = undefined;
                        context$3$0.prev = 8;
                        _iterator = item.images[Symbol.iterator]();

                      case 10:
                        if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                          context$3$0.next = 26;
                          break;
                        }

                        img = _step.value;
                        imgSrc = config.imagedir + '/' + img;
                        imgTgt = cd + '/' + img;
                        context$3$0.prev = 14;
                        context$3$0.next = 17;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].access(imgTgt));

                      case 17:
                        context$3$0.next = 23;
                        break;

                      case 19:
                        context$3$0.prev = 19;
                        context$3$0.t0 = context$3$0['catch'](14);
                        context$3$0.next = 23;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].copyFile(imgSrc, imgTgt));

                      case 23:
                        _iteratorNormalCompletion = true;
                        context$3$0.next = 10;
                        break;

                      case 26:
                        context$3$0.next = 32;
                        break;

                      case 28:
                        context$3$0.prev = 28;
                        context$3$0.t1 = context$3$0['catch'](8);
                        _didIteratorError = true;
                        _iteratorError = context$3$0.t1;

                      case 32:
                        context$3$0.prev = 32;
                        context$3$0.prev = 33;

                        if (!_iteratorNormalCompletion && _iterator['return']) {
                          _iterator['return']();
                        }

                      case 35:
                        context$3$0.prev = 35;

                        if (!_didIteratorError) {
                          context$3$0.next = 38;
                          break;
                        }

                        throw _iteratorError;

                      case 38:
                        return context$3$0.finish(35);

                      case 39:
                        return context$3$0.finish(32);

                      case 40:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[8, 28, 32, 40], [14, 19], [33,, 35, 39]]);
                };

                // パケット終了時
                packet.onPacketEnd = function callee$2$0(packetCount) {
                  var zip, zipname, output;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        zip = (0, _archiver2['default'])('zip');
                        zipname = uploaddir + '/' + name + '.zip';
                        output = _fsExtra2['default'].createWriteStream(zipname);

                        zip.pipe(output);
                        zip.directory(cd, false);
                        zip.finalize();

                      case 6:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // メインループ
                //

                context$2$0.next = 32;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var quantity, yauct;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;

                          if (!(quantity >= item.mall.yauct.minQuantity)) {
                            context$3$0.next = 9;
                            break;
                          }

                          context$3$0.next = 6;
                          return regeneratorRuntime.awrap(itemController.convertItemYauct(config['default'], item));

                        case 6:
                          yauct = context$3$0.sent;
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(packet.submit({ yauct: yauct, item: item }));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  } }));

              case 32:
                res = context$2$0.sent;

                packet.close();

                return context$2$0.abrupt('return', res);

              case 35:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[5, 10]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// ヤフオク受注ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 管理番号を置き換える

//
// ヤフオク出品ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 繰り返し処理を任意の（packetSize）で分割

// 作業フォルダを作成する

// CSVファイルを作成し画像データを収集する場所

// ZIPファイルを保存する場所
// パケットフォルダ
// csvファイル
// パケット番号

// CSVフィールドを定義し、順番を確定する

// CSVファイルにフィールドを設定する

// csvファイルにレコード（商品テンプレート）を追加する

// 画像ファイルをコピー

// 同じファイルがある場合はコピーしない

// itemに定義されている最低必要在庫より多い商品を出品する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
require('../imports/collections');

require('./route/upload/image');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"filters.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/filters.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _groups = require('./groups');

var Filters = new _meteorMongo.Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

var Filter = (function (_GroupBase) {
  _inherits(Filter, _GroupBase);

  function Filter(filterId) {
    var _this = this;

    _classCallCheck(this, Filter);

    var profile = Filters.findOne({
      _id: filterId
    });

    _get(Object.getPrototypeOf(Filter.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {

      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0() {
          var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
          var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table;
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, onError));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this);
        };
        break;

      default:
        throw new Error('invalid platform type');

    }
  }

  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */

  _createClass(Filter, [{
    key: 'foreach',
    value: function foreach() {
      var _this2 = this;

      var callbacks = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this2);
      } : arguments[1];

      var profile, count, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, filter;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this3 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              type: 'misc',
              query: {}
            });

            count = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              filter = _step.value;

              count[filter.type] = {
                query: filter.query,
                count: 0
              };
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record) {
              var _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, filter, query, exam;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion2 = true;
                    _didIteratorError2 = false;
                    _iteratorError2 = undefined;
                    context$3$0.prev = 3;
                    _iterator2 = profile.filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
                      context$3$0.next = 18;
                      break;
                    }

                    filter = _step2.value;
                    query = _mongoobject2['default'].unescape(filter.query);
                    exam = (0, _sift2['default'])(query);

                    if (!exam(record)) {
                      context$3$0.next = 15;
                      break;
                    }

                    count[filter.type].count++;

                    if (!(typeof callbacks[filter.type] !== 'undefined')) {
                      context$3$0.next = 14;
                      break;
                    }

                    context$3$0.next = 14;
                    return regeneratorRuntime.awrap(callbacks[filter.type](record));

                  case 14:
                    return context$3$0.abrupt('break', 18);

                  case 15:
                    _iteratorNormalCompletion2 = true;
                    context$3$0.next = 5;
                    break;

                  case 18:
                    context$3$0.next = 24;
                    break;

                  case 20:
                    context$3$0.prev = 20;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError2 = true;
                    _iteratorError2 = context$3$0.t0;

                  case 24:
                    context$3$0.prev = 24;
                    context$3$0.prev = 25;

                    if (!_iteratorNormalCompletion2 && _iterator2['return']) {
                      _iterator2['return']();
                    }

                  case 27:
                    context$3$0.prev = 27;

                    if (!_didIteratorError2) {
                      context$3$0.next = 30;
                      break;
                    }

                    throw _iteratorError2;

                  case 30:
                    return context$3$0.finish(27);

                  case 31:
                    return context$3$0.finish(24);

                  case 32:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this3, [[3, 20, 24, 32], [25,, 27, 31]]);
            }, onError));

          case 24:
            return context$2$0.abrupt('return', count);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21]]);
    }
  }]);

  return Filter;
})(_groups.GroupBase);

exports.Filter = Filter;

// return result of filtering
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/groups.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

var Groups = new _meteorMongo.Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

var GroupBase = (function () {
  function GroupBase(profile) {
    _classCallCheck(this, GroupBase);

    this.profile = profile;
  }

  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */

  _createClass(GroupBase, [{
    key: 'getPlug',
    value: function getPlug() {
      return this.profile.platformPlug;
    }
  }, {
    key: 'getProfile',
    value: function getProfile() {
      return this.profile;
    }
  }, {
    key: 'foreach',
    value: function foreach() {
      var _this = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
    }
  }]);

  return GroupBase;
})();

exports.GroupBase = GroupBase;

var Group = (function (_GroupBase) {
  _inherits(Group, _GroupBase);

  function Group(groupId) {
    var _this2 = this;

    _classCallCheck(this, Group);

    var profile = Groups.findOne({
      _id: groupId
    });

    _get(Object.getPrototypeOf(Group.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0(doc) {
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table + ' WHERE `' + doc.key + '` = "' + doc.id + '"';
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.query(sql));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this2);
        };
        break;
      default:
        throw new Error('invalid group type');
    }
  }

  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */

  _createClass(Group, [{
    key: 'foreach',
    value: function foreach() {
      var _this3 = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[1];

      var cur = Groups.find({
        groupId: this.profile._id
      }, {
        fields: {
          _id: 0,
          id: 1,
          key: 1
        }
      });

      return new Promise(function (resolve, reject) {

        cur.forEach(function callee$3$0(doc, index) {
          var record;
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                context$4$0.prev = 0;
                context$4$0.next = 3;
                return regeneratorRuntime.awrap(this['import'](doc));

              case 3:
                record = context$4$0.sent;
                context$4$0.next = 6;
                return regeneratorRuntime.awrap(callback(record));

              case 6:
                context$4$0.next = 11;
                break;

              case 8:
                context$4$0.prev = 8;
                context$4$0.t0 = context$4$0['catch'](0);

                onError(context$4$0.t0);

              case 11:
                if (index + 1 === cur.count()) {
                  resolve();
                }

              case 12:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this3, [[0, 8]]);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }]);

  return Group;
})(GroupBase);

exports.Group = Group;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/cube3api.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _utilSyncObject = require('../util/syncObject');

var _utilSyncObject2 = _interopRequireDefault(_utilSyncObject);

var Cube3Api = (function () {
  /**
   *
   * @param {MySQL} mysql
   */

  function Cube3Api(mysql) {
    _classCallCheck(this, Cube3Api);

    this.mysql = mysql;
  }

  _createClass(Cube3Api, [{
    key: 'modifyCategory',
    value: function modifyCategory(productId, categoryIdArray) {
      var tableCategory, colSrc, sql, colDst, results;
      return regeneratorRuntime.async(function modifyCategory$(context$2$0) {
        var _this = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            tableCategory = 'dtb_product_category';
            colSrc = [];

            categoryIdArray.forEach(function (elem) {
              colSrc.push({
                product_id: productId,
                category_id: elem
              });
            });

            // モールデータベースから現在の商品カテゴリー情報を取得
            sql = '\n    SELECT product_id, category_id\n    FROM ' + tableCategory + '\n    WHERE product_id = ' + productId + '\n    ';
            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.mysql.querySelect(tableCategory, 'product_id = ' + productId, 'product_id, category_id'));

          case 6:
            colDst = context$2$0.sent;
            results = [];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap((0, _utilSyncObject2['default'])(colSrc, colDst, null, function callee$2$0(id, object) {
              var res;
              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    context$3$0.next = 2;
                    return regeneratorRuntime.awrap(this.mysql.queryInsert(tableCategory, {}, Object.assign({ rank: 1 }, object)));

                  case 2:
                    res = context$3$0.sent;

                    results.push(res);

                  case 4:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            }, function callee$2$0(id, object) {
              var res;
              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    context$3$0.next = 2;
                    return regeneratorRuntime.awrap(this.mysql.query('\n          DELETE FROM ' + tableCategory + '\n          WHERE product_id = ' + object.product_id + '\n            AND category_id = ' + object.category_id + '\n          '));

                  case 2:
                    res = context$3$0.sent;

                    results.push(res);

                  case 4:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            }));

          case 10:
            return context$2$0.abrupt('return', results);

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(productClassId) {
      var quantity = arguments.length <= 1 || arguments[1] === undefined ? 0 : arguments[1];
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_class', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              stock_unlimited: 0,
              update_date: 'NOW()'
            }));

          case 2:
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_stock', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              update_date: 'NOW()'
            }));

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productTagUpdate',
    value: function productTagUpdate(data) {
      var creatorId, res, tagoff, tagon, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, tagSet;

      return regeneratorRuntime.async(function productTagUpdate$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = [];

            tagoff = function tagoff(tag) {
              var sql;
              return regeneratorRuntime.async(function tagoff$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      DELETE FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.t0 = res;
                    context$3$0.next = 4;
                    return regeneratorRuntime.awrap(this.mysql.query(sql));

                  case 4:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 6:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2);
            };

            tagon = function tagon(tag) {
              var sql, countRes;
              return regeneratorRuntime.async(function tagon$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      SELECT COUNT(*) FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.next = 3;
                    return regeneratorRuntime.awrap(this.mysql.query(sql));

                  case 3:
                    countRes = context$3$0.sent;

                    if (!countRes[0]['COUNT(*)']) {
                      context$3$0.next = 6;
                      break;
                    }

                    return context$3$0.abrupt('return');

                  case 6:
                    context$3$0.t0 = res;
                    context$3$0.next = 9;
                    return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_tag', {}, {
                      product_id: data.product_id,
                      tag: tag,
                      creator_id: creatorId,
                      create_date: 'NOW()'
                    }));

                  case 9:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 11:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2);
            };

            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 7;
            _iterator = data.tags[Symbol.iterator]();

          case 9:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 23;
              break;
            }

            tagSet = _step.value;
            context$2$0.t0 = tagSet.set;
            context$2$0.next = context$2$0.t0 === 'on' ? 14 : context$2$0.t0 === 'off' ? 17 : 20;
            break;

          case 14:
            context$2$0.next = 16;
            return regeneratorRuntime.awrap(tagon(tagSet.tag));

          case 16:
            return context$2$0.abrupt('break', 20);

          case 17:
            context$2$0.next = 19;
            return regeneratorRuntime.awrap(tagoff(tagSet.tag));

          case 19:
            return context$2$0.abrupt('break', 20);

          case 20:
            _iteratorNormalCompletion = true;
            context$2$0.next = 9;
            break;

          case 23:
            context$2$0.next = 29;
            break;

          case 25:
            context$2$0.prev = 25;
            context$2$0.t1 = context$2$0['catch'](7);
            _didIteratorError = true;
            _iteratorError = context$2$0.t1;

          case 29:
            context$2$0.prev = 29;
            context$2$0.prev = 30;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 32:
            context$2$0.prev = 32;

            if (!_didIteratorError) {
              context$2$0.next = 35;
              break;
            }

            throw _iteratorError;

          case 35:
            return context$2$0.finish(32);

          case 36:
            return context$2$0.finish(29);

          case 37:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 38:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[7, 25, 29, 37], [30,, 32, 36]]);
    }
  }, {
    key: 'productImageUpdate',
    value: function productImageUpdate(data) {
      var productId, images, creatorId, res, sql, i;
      return regeneratorRuntime.async(function productImageUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productId = data.product_id;
            images = data.images;
            creatorId = data.creator_id;
            res = [];
            sql = 'DELETE FROM dtb_product_image WHERE product_id = ' + productId;
            context$2$0.t0 = res;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(this.mysql.query(sql));

          case 8:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t1);
            i = 0;

          case 11:
            if (!(i < images.length)) {
              context$2$0.next = 17;
              break;
            }

            context$2$0.next = 14;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_image', {
              product_id: productId,
              creator_id: creatorId,
              file_name: images[i],
              rank: i + 1
            }, {
              create_date: 'NOW()'
            }));

          case 14:
            i++;
            context$2$0.next = 11;
            break;

          case 17:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productUpdate',
    value: function productUpdate(data) {
      var updateData, keys, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, k, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, res;

      return regeneratorRuntime.async(function productUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            updateData = {};
            keys = [];

            // dtb_product

            keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 6;
            for (_iterator2 = keys[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              if (data[k]) {
                updateData[k] = data[k];
              }
            }

            // [
            //   'status',
            //   'name',
            //   'note',
            //   'description_list',
            //   'description_detail',
            //   'search_word',
            //   'free_area',
            // ].forEach(
            //   (v) => {
            //     if (data[v]) {
            //       updateData[v] = data[v];
            //     }
            //   },
            // );

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError2) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError2;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 24:

            // dtb_product_class

            updateData = {};
            keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 29;
            for (_iterator3 = keys[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 37;
            break;

          case 33:
            context$2$0.prev = 33;
            context$2$0.t1 = context$2$0['catch'](29);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t1;

          case 37:
            context$2$0.prev = 37;
            context$2$0.prev = 38;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 40:
            context$2$0.prev = 40;

            if (!_didIteratorError3) {
              context$2$0.next = 43;
              break;
            }

            throw _iteratorError3;

          case 43:
            return context$2$0.finish(40);

          case 44:
            return context$2$0.finish(37);

          case 45:
            context$2$0.next = 47;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_class', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 47:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 49:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [29, 33, 37, 45], [38,, 40, 44]]);
    }
  }, {
    key: 'productCreate',
    value: function productCreate(data) {
      var creatorId, res, updateData, keys, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, k, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6;

      return regeneratorRuntime.async(function productCreate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = {};
            updateData = {};
            keys = [];

            keys = ['name', 'description_detail'];
            // {
            //   name: item.name,
            //   description_detail: item.description,
            // },

            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 8;
            for (_iterator4 = keys[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 16;
            break;

          case 12:
            context$2$0.prev = 12;
            context$2$0.t0 = context$2$0['catch'](8);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t0;

          case 16:
            context$2$0.prev = 16;
            context$2$0.prev = 17;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 19:
            context$2$0.prev = 19;

            if (!_didIteratorError4) {
              context$2$0.next = 22;
              break;
            }

            throw _iteratorError4;

          case 22:
            return context$2$0.finish(19);

          case 23:
            return context$2$0.finish(16);

          case 24:
            context$2$0.next = 26;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product', updateData, {
              creator_id: creatorId,
              status: 1,
              note: 'NULL',
              description_list: 'NULL',
              search_word: 'NULL',
              free_area: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 26:
            res.product_id = context$2$0.sent;

            updateData = {};
            keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee'];
            // {
            //   product_code: item.model,
            //   price01: item.retail_price,
            //   price02: item.sales_price,
            // },

            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 32;
            for (_iterator5 = keys[Symbol.iterator](); !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
              k = _step5.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 40;
            break;

          case 36:
            context$2$0.prev = 36;
            context$2$0.t1 = context$2$0['catch'](32);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t1;

          case 40:
            context$2$0.prev = 40;
            context$2$0.prev = 41;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 43:
            context$2$0.prev = 43;

            if (!_didIteratorError5) {
              context$2$0.next = 46;
              break;
            }

            throw _iteratorError5;

          case 46:
            return context$2$0.finish(43);

          case 47:
            return context$2$0.finish(40);

          case 48:
            context$2$0.next = 50;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_class', updateData, {
              creator_id: creatorId,
              product_id: res.product_id,
              stock: 0,
              stock_unlimited: 0,
              class_category_id1: 'NULL',
              class_category_id2: 'NULL',
              delivery_date_id: 'NULL',
              sale_limit: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 50:
            res.product_class_id = context$2$0.sent;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 54;

            for (_iterator6 = keys[Symbol.iterator](); !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
              k = _step6.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 62;
            break;

          case 58:
            context$2$0.prev = 58;
            context$2$0.t2 = context$2$0['catch'](54);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t2;

          case 62:
            context$2$0.prev = 62;
            context$2$0.prev = 63;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 65:
            context$2$0.prev = 65;

            if (!_didIteratorError6) {
              context$2$0.next = 68;
              break;
            }

            throw _iteratorError6;

          case 68:
            return context$2$0.finish(65);

          case 69:
            return context$2$0.finish(62);

          case 70:
            context$2$0.next = 72;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_stock', {}, {
              product_class_id: res.product_class_id,
              creator_id: creatorId,
              stock: 0,
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 72:
            res.product_stock_id = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res:

              // for test
              res
            });

          case 74:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 12, 16, 24], [17,, 19, 23], [32, 36, 40, 48], [41,, 43, 47], [54, 58, 62, 70], [63,, 65, 69]]);
    }
  }]);

  return Cube3Api;
})();

exports.Cube3Api = Cube3Api;

// 商品情報データベースに記録された商品カテゴリー情報

// const colDst = JSON.parse(JSON.stringify(await this.mysql.query(sql)));

// 各SQLクエリの結果すべてを記録する

// 削除するタグ

// 表示するタグ

// すでに表示されているタグがあれば何もしない

// 商品に関連するすべての画像情報を削除する

// 改めて画像を登録しなおす
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/dbfilter.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _xmlJs = require('xml-js');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var DBFilterFactory = function DBFilterFactory(plug, profile) {
  _classCallCheck(this, DBFilterFactory);

  var instance = undefined;
  switch (plug.type) {
    case 'mysql':
      instance = new MysqlDBFilter(plug, profile);
  }

  return instance;
};

exports.DBFilterFactory = DBFilterFactory;

var DBFilter = (function () {
  function DBFilter(plug, profile) {
    _classCallCheck(this, DBFilter);

    this.plug = plug;
    this.profile = profile;
  }

  _createClass(DBFilter, [{
    key: 'getPlug_',
    value: function getPlug_() {
      return this.plug;
    }
  }, {
    key: 'getCred_',
    value: function getCred_() {
      return this.plug.cred;
    }
  }, {
    key: 'getProfile_',
    value: function getProfile_() {
      return this.profile;
    }
  }, {
    key: 'setImportFunction_',
    value: function setImportFunction_() {
      var _this = this;

      var fn = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0() {
        var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
        var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];

      this['import'] = fn;
    }

    /**
     * traces members of the group
     * useage:
     *
     *
     * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
     * @param { async function } onError error handler while iterating
     * @returns { Object } { filterName: { query: any, count: number }, ... }
     */
  }, {
    key: 'foreach',
    value: function foreach() {
      var iterators = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      var profile, counter, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, f, filters, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile_();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              name: 'misc',
              query: {}
            });

            counter = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              f = _step.value;
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            filters = [];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 26;

            for (_iterator2 = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              f = _step2.value;

              counter[f.name] = {
                query: f.query,
                limit: typeof f.limit !== 'undefined' ? f.limit : 0,
                count: 0
              };
              filters.push({
                name: f.name,
                exam: (0, _sift2['default'])(_mongoobject2['default'].unescape(f.query))
              });
            }

            context$2$0.next = 34;
            break;

          case 30:
            context$2$0.prev = 30;
            context$2$0.t1 = context$2$0['catch'](26);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 34:
            context$2$0.prev = 34;
            context$2$0.prev = 35;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 37:
            context$2$0.prev = 37;

            if (!_didIteratorError2) {
              context$2$0.next = 40;
              break;
            }

            throw _iteratorError2;

          case 40:
            return context$2$0.finish(37);

          case 41:
            return context$2$0.finish(34);

          case 42:
            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record, context) {
              var _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, f, c;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion3 = true;
                    _didIteratorError3 = false;
                    _iteratorError3 = undefined;
                    context$3$0.prev = 3;
                    _iterator3 = filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
                      context$3$0.next = 20;
                      break;
                    }

                    f = _step3.value;
                    c = counter[f.name];

                    if (!c.limit) {
                      context$3$0.next = 11;
                      break;
                    }

                    if (!(c.count >= c.limit)) {
                      context$3$0.next = 11;
                      break;
                    }

                    return context$3$0.abrupt('continue', 17);

                  case 11:
                    if (!f.exam(record)) {
                      context$3$0.next = 17;
                      break;
                    }

                    // counter limiter
                    c.count++;

                    // iterator

                    if (!(typeof iterators[f.name] !== 'undefined')) {
                      context$3$0.next = 16;
                      break;
                    }

                    context$3$0.next = 16;
                    return regeneratorRuntime.awrap(iterators[f.name](record, context));

                  case 16:
                    return context$3$0.abrupt('break', 20);

                  case 17:
                    _iteratorNormalCompletion3 = true;
                    context$3$0.next = 5;
                    break;

                  case 20:
                    context$3$0.next = 26;
                    break;

                  case 22:
                    context$3$0.prev = 22;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError3 = true;
                    _iteratorError3 = context$3$0.t0;

                  case 26:
                    context$3$0.prev = 26;
                    context$3$0.prev = 27;

                    if (!_iteratorNormalCompletion3 && _iterator3['return']) {
                      _iterator3['return']();
                    }

                  case 29:
                    context$3$0.prev = 29;

                    if (!_didIteratorError3) {
                      context$3$0.next = 32;
                      break;
                    }

                    throw _iteratorError3;

                  case 32:
                    return context$3$0.finish(29);

                  case 33:
                    return context$3$0.finish(26);

                  case 34:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2, [[3, 22, 26, 34], [27,, 29, 33]]);
            }));

          case 44:
            return context$2$0.abrupt('return', counter);

          case 45:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [26, 30, 34, 42], [35,, 37, 41]]);
    }
  }], [{
    key: 'factory',
    value: function factory(plug, profile) {
      switch (plug.type) {
        case 'mysql':
          return new MysqlDBFilter(plug, profile);
        default:
          throw new Error('invalid plug type');
      }
    }
  }]);

  return DBFilter;
})();

exports.DBFilter = DBFilter;

var MysqlDBFilter = (function (_DBFilter) {
  _inherits(MysqlDBFilter, _DBFilter);

  function MysqlDBFilter(plug, profile) {
    var _this3 = this;

    _classCallCheck(this, MysqlDBFilter);

    _get(Object.getPrototypeOf(MysqlDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    var cred = this.getCred_();

    this.mysql = new _utilMysql2['default'](cred);
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var sql, res;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            sql = 'SELECT * FROM ' + plug.table;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, function (e) {
              throw e;
            }));

          case 3:
            res = context$3$0.sent;
            return context$3$0.abrupt('return', res);

          case 5:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this3);
    });
  }

  // import MongoNative from 'mongodb';
  // const MongoClient = MongoNative.MongoClient;
  // const MongoClient = require('mongodb').MongoClient;

  return MysqlDBFilter;
})(DBFilter);

exports.MysqlDBFilter = MysqlDBFilter;

var MongoDBFilter = (function (_DBFilter2) {
  _inherits(MongoDBFilter, _DBFilter2);

  function MongoDBFilter(plug, profile) {
    var _this4 = this;

    _classCallCheck(this, MongoDBFilter);

    _get(Object.getPrototypeOf(MongoDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    // mongo へ接続
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var client, db, collection, context, cur, doc;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            client = undefined;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri, { useNewUrlParser: true }));

          case 3:
            client = context$3$0.sent;
            db = client.db(plug.database);
            collection = db.collection(plug.collection);
            context = {
              client: client,
              collection: collection,
              database: db
            };
            cur = collection.find();

            // カーソルのタイムアウトを解除
            cur.addCursorFlag('noCursorTimeout', true);

            // すべてのドキュメントをループ
            context$3$0.prev = 9;

          case 10:
            context$3$0.next = 12;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 12:
            if (!context$3$0.sent) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 15;
            return regeneratorRuntime.awrap(cur.next());

          case 15:
            doc = context$3$0.sent;
            context$3$0.next = 18;
            return regeneratorRuntime.awrap(onResult(doc, context));

          case 18:
            context$3$0.next = 10;
            break;

          case 20:
            context$3$0.prev = 20;
            context$3$0.next = 23;
            return regeneratorRuntime.awrap(cur.close());

          case 23:
            return context$3$0.finish(20);

          case 24:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this4, [[9,, 20, 24]]);
    });
  }

  return MongoDBFilter;
})(DBFilter);

exports.MongoDBFilter = MongoDBFilter;

var WowmaApiItemFilter = (function (_DBFilter3) {
  _inherits(WowmaApiItemFilter, _DBFilter3);

  function WowmaApiItemFilter(plug, profile) {
    var _this5 = this;

    _classCallCheck(this, WowmaApiItemFilter);

    _get(Object.getPrototypeOf(WowmaApiItemFilter.prototype), 'constructor', this).call(this, plug, profile);

    // 商品情報の取得ループを定義
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var options, context, res, maxCount, resultCount, startCount, resultStocks, i, next;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            options = JSON.parse(JSON.stringify(plug));

            options.uri = options.uri + '/searchStocks';
            context = {
              options: options
            };

          case 3:
            if (!1) {
              context$3$0.next = 30;
              break;
            }

            context$3$0.next = 6;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

          case 6:
            res = context$3$0.sent;

            res = (0, _xmlJs.xml2js)(res, { compact: true });

            maxCount = Number(res.response.searchResult.maxCount._text);
            resultCount = Number(res.response.searchResult.resultCount._text);
            startCount = Number(res.response.searchResult.startCount._text);
            resultStocks = res.response.searchResult.resultStocks;

            if (!(resultStocks instanceof Array)) {
              context$3$0.next = 22;
              break;
            }

            i = 0;

          case 14:
            if (!(i < resultCount)) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 17;
            return regeneratorRuntime.awrap(onResult(resultStocks[i], context));

          case 17:
            i++;
            context$3$0.next = 14;
            break;

          case 20:
            context$3$0.next = 24;
            break;

          case 22:
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(onResult(resultStocks, context));

          case 24:
            next = startCount + resultCount;

            if (!(next > maxCount)) {
              context$3$0.next = 27;
              break;
            }

            return context$3$0.abrupt('break', 30);

          case 27:
            options.qs.startCount = next;
            context$3$0.next = 3;
            break;

          case 30:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this5);
    });
  }

  // import mongoose from 'mongoose';

  // export class MongoDBFilter extends DBFilter {
  //   constructor(plug, profile) {
  //     super(plug, profile);

  //     // mongo へ接続
  //     let cred = this.getCred_();
  //     let conuri = `mongodb://${cred.host}:${cred.port}/${cred.database}`;
  //     await mongoose.connect(conuri);

  //     // コレクションを作る
  //     let collection = mongoose.connection.collection(plug.collection);

  //     this.setImportFunction_(async (onResult, onError) => {
  //       let cur = collection.find();

  //       return await this.mysql.streamingQuery(sql, onResult, onError);
  //     });
  //   }
  // }
  return WowmaApiItemFilter;
})(DBFilter);

exports.WowmaApiItemFilter = WowmaApiItemFilter;

// counter limiter

// return result of filtering

// コレクションを取得

// カーソルを開放

// コレクションを取得

// Wowma Api から商品情報を取得

// 取得した商品情報をカスタムプロセスに渡す

// 取得したデータが複数商品の場合

// 取得したデータが単数商品の場合
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/items.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMongo = require('../util/mongo');

var _collections = require('../collections');

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var ItemController = (function () {
  function ItemController() {
    _classCallCheck(this, ItemController);
  }

  _createClass(ItemController, [{
    key: 'init',

    /**
     *
     * @param {{uri:string, database:string, collection:string}} plug
     */
    value: function init(plug) {
      return regeneratorRuntime.async(function init$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'items'));

          case 2:
            this.Items = context$2$0.sent;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'products'));

          case 5:
            this.Products = context$2$0.sent;

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'getStock',
    value: function getStock(itemId) {
      var item, productSet, quantities, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, productRef, prdQuantity, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, id, product, stockArray, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, stock, quantity;

      return regeneratorRuntime.async(function getStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.Items.findOne({
              _id: itemId
            }, {
              projection: {
                product: 1
              }
            }));

          case 2:
            item = context$2$0.sent;
            productSet = item.product;
            quantities = [];
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 8;
            _iterator = productSet[Symbol.iterator]();

          case 10:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 64;
              break;
            }

            productRef = _step.value;
            prdQuantity = 0;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 16;
            _iterator2 = productRef.ids[Symbol.iterator]();

          case 18:
            if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
              context$2$0.next = 46;
              break;
            }

            id = _step2.value;
            context$2$0.next = 22;
            return regeneratorRuntime.awrap(this.Products.findOne({
              _id: id
            }, {
              projection: {
                stock: 1
              }
            }));

          case 22:
            product = context$2$0.sent;
            stockArray = product.stock;
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 27;

            // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算
            for (_iterator3 = stockArray[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              stock = _step3.value;
              prdQuantity += stock.quantity;
            }context$2$0.next = 35;
            break;

          case 31:
            context$2$0.prev = 31;
            context$2$0.t0 = context$2$0['catch'](27);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 35:
            context$2$0.prev = 35;
            context$2$0.prev = 36;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 38:
            context$2$0.prev = 38;

            if (!_didIteratorError3) {
              context$2$0.next = 41;
              break;
            }

            throw _iteratorError3;

          case 41:
            return context$2$0.finish(38);

          case 42:
            return context$2$0.finish(35);

          case 43:
            _iteratorNormalCompletion2 = true;
            context$2$0.next = 18;
            break;

          case 46:
            context$2$0.next = 52;
            break;

          case 48:
            context$2$0.prev = 48;
            context$2$0.t1 = context$2$0['catch'](16);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 52:
            context$2$0.prev = 52;
            context$2$0.prev = 53;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 55:
            context$2$0.prev = 55;

            if (!_didIteratorError2) {
              context$2$0.next = 58;
              break;
            }

            throw _iteratorError2;

          case 58:
            return context$2$0.finish(55);

          case 59:
            return context$2$0.finish(52);

          case 60:

            // 商品(item)の在庫数 = 製品在庫数(prdQuantity) / 必要セット数(productRef.set)
            quantities.push(Math.floor(prdQuantity / productRef.set));

          case 61:
            _iteratorNormalCompletion = true;
            context$2$0.next = 10;
            break;

          case 64:
            context$2$0.next = 70;
            break;

          case 66:
            context$2$0.prev = 66;
            context$2$0.t2 = context$2$0['catch'](8);
            _didIteratorError = true;
            _iteratorError = context$2$0.t2;

          case 70:
            context$2$0.prev = 70;
            context$2$0.prev = 71;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 73:
            context$2$0.prev = 73;

            if (!_didIteratorError) {
              context$2$0.next = 76;
              break;
            }

            throw _iteratorError;

          case 76:
            return context$2$0.finish(73);

          case 77:
            return context$2$0.finish(70);

          case 78:
            quantity = Math.min.apply(null, quantities);
            return context$2$0.abrupt('return', quantity);

          case 80:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 66, 70, 78], [16, 48, 52, 60], [27, 31, 35, 43], [36,, 38, 42], [53,, 55, 59], [71,, 73, 77]]);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに、
     * アップロード済み画像を関連付ける。
     *
     * メーカーモデルに共通の画像を一括で関連付けたい場合、
     * class1、class2引数を指定せずに実行する。
     *
     * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
     * class1に値を指定し、class2引数を指定せずに実行する。
     * もしclass2のみ指定したい場合はclass1にnullを指定する。
     *
     * 例：JK-100のBLACKの商品画像を
     * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
     * setImage( uploadId, 'JK-100', 'BLACK' );
     *
     * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'setImage',
    value: function setImage(uploadId, model) {
      var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
      var images, filter, res;
      return regeneratorRuntime.async(function setImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            images = _collections.Uploads.find({
              uploadId: uploadId
            }).fetch().map(function (v) {
              return v.uploadedFileName;
            });
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $push: {
                images: {
                  $each: images
                }
              }
            }));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', images);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
     *
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'cleanImage',
    value: function cleanImage(model) {
      var class1 = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
      var class2 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var filter, res;
      return regeneratorRuntime.async(function cleanImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $set: {
                images: []
              }
            }));

          case 6:
            res = context$2$0.sent;

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * 指定の商品に関連する商品群の属性別の商品情報を返す。
     *
     * 引数として受け取るitemは任意の商品情報。
     * itemに関連する商品群について必要な情報を整理し返す。
     *
     * projectに参照したい商品情報フィールドを定義する。
     * メソッドの呼び出し時に必要に応じてprojectを設定する。
     *
     * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
     *
     * @param {Object} item
     * @param {Object} project
     */
  }, {
    key: 'getVariation',
    value: function getVariation(item, project) {
      var set, attrs, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, s, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, attr, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6, v;

      return regeneratorRuntime.async(function getVariation$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            set = [{
              label: '配送方法',
              current: item.delivery,
              project: {
                value: '$delivery'
              },
              query: {
                class1_value: item.class1_value,
                class2_value: item.class2_value
              }
            }, {
              label: item.class1_name,
              current: item.class1_value,
              project: {
                value: '$class1_value'
              },
              query: {
                delivery: item.delivery,
                class2_value: item.class2_value
              }
            }, {
              label: item.class2_name,
              current: item.class2_value,
              project: {
                value: '$class2_value'
              },
              query: {
                delivery: item.delivery,
                class1_value: item.class1_value
              }
            }];
            attrs = [];
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 5;
            _iterator4 = set[Symbol.iterator]();

          case 7:
            if (_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done) {
              context$2$0.next = 19;
              break;
            }

            s = _step4.value;
            context$2$0.t0 = attrs;
            context$2$0.next = 12;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: Object.assign(s.query, {
                model: item.model
              })
            }, {
              $project: Object.assign(s.project, project)
            }, {
              $sort: {
                _id: 1
              }
            }]).toArray());

          case 12:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = s;
            context$2$0.t3 = {
              variations: context$2$0.t1,
              props: context$2$0.t2
            };
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t3);

          case 16:
            _iteratorNormalCompletion4 = true;
            context$2$0.next = 7;
            break;

          case 19:
            context$2$0.next = 25;
            break;

          case 21:
            context$2$0.prev = 21;
            context$2$0.t4 = context$2$0['catch'](5);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t4;

          case 25:
            context$2$0.prev = 25;
            context$2$0.prev = 26;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 28:
            context$2$0.prev = 28;

            if (!_didIteratorError4) {
              context$2$0.next = 31;
              break;
            }

            throw _iteratorError4;

          case 31:
            return context$2$0.finish(28);

          case 32:
            return context$2$0.finish(25);

          case 33:
            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 36;
            _iterator5 = attrs[Symbol.iterator]();

          case 38:
            if (_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done) {
              context$2$0.next = 70;
              break;
            }

            attr = _step5.value;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 43;
            _iterator6 = attr.variations[Symbol.iterator]();

          case 45:
            if (_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done) {
              context$2$0.next = 53;
              break;
            }

            v = _step6.value;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.getStock(v._id));

          case 49:
            v.stock = context$2$0.sent;

          case 50:
            _iteratorNormalCompletion6 = true;
            context$2$0.next = 45;
            break;

          case 53:
            context$2$0.next = 59;
            break;

          case 55:
            context$2$0.prev = 55;
            context$2$0.t5 = context$2$0['catch'](43);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t5;

          case 59:
            context$2$0.prev = 59;
            context$2$0.prev = 60;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 62:
            context$2$0.prev = 62;

            if (!_didIteratorError6) {
              context$2$0.next = 65;
              break;
            }

            throw _iteratorError6;

          case 65:
            return context$2$0.finish(62);

          case 66:
            return context$2$0.finish(59);

          case 67:
            _iteratorNormalCompletion5 = true;
            context$2$0.next = 38;
            break;

          case 70:
            context$2$0.next = 76;
            break;

          case 72:
            context$2$0.prev = 72;
            context$2$0.t6 = context$2$0['catch'](36);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t6;

          case 76:
            context$2$0.prev = 76;
            context$2$0.prev = 77;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 79:
            context$2$0.prev = 79;

            if (!_didIteratorError5) {
              context$2$0.next = 82;
              break;
            }

            throw _iteratorError5;

          case 82:
            return context$2$0.finish(79);

          case 83:
            return context$2$0.finish(76);

          case 84:
            return context$2$0.abrupt('return', attrs);

          case 85:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 21, 25, 33], [26,, 28, 32], [36, 72, 76, 84], [43, 55, 59, 67], [60,, 62, 66], [77,, 79, 83]]);
    }

    // モデルクラス形式を作る
    // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
  }, {
    key: 'getModelClass',
    value: function getModelClass(arg) {
      var item, exp, cur, match, modelClass;
      return regeneratorRuntime.async(function getModelClass$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            item = undefined;

            if (!(typeof arg === 'string')) {
              context$2$0.next = 25;
              break;
            }

            exp = new RegExp(arg + '$');
            cur = this.Items.find({}, {
              projection: {
                model: 1,
                class1_value: 1,
                class2_value: 1
              }
            });

          case 4:
            if (!1) {
              context$2$0.next = 22;
              break;
            }

            context$2$0.prev = 5;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(cur.next());

          case 8:
            item = context$2$0.sent;
            context$2$0.next = 11;
            return regeneratorRuntime.awrap(item._id.toHexString().match(exp));

          case 11:
            match = context$2$0.sent;

            if (!match) {
              context$2$0.next = 14;
              break;
            }

            return context$2$0.abrupt('break', 22);

          case 14:
            context$2$0.next = 20;
            break;

          case 16:
            context$2$0.prev = 16;
            context$2$0.t0 = context$2$0['catch'](5);

            // 該当するitemデータがない
            cur.close();
            return context$2$0.abrupt('return', arg);

          case 20:
            context$2$0.next = 4;
            break;

          case 22:
            cur.close();
            context$2$0.next = 26;
            break;

          case 25:
            item = arg;

          case 26:
            modelClass = [];

            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);
            return context$2$0.abrupt('return', modelClass.join('/'));

          case 31:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 16]]);
    }
  }, {
    key: 'convertItemCube3',
    value: function convertItemCube3(configUploadItem, item) {
      var convDeliv, productId, modelClass, productTypeId, tags, deliveryFee, attrs, variationHtml, descriptionDetail, data;
      return regeneratorRuntime.async(function convertItemCube3$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            convDeliv = function convDeliv(delivery) {
              return delivery === 'ゆうパケット' ? 'ポスト投函' : delivery;
            };

            productId = null;
            modelClass = [];

            // 下記の形式を作る
            // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);

            // 商品種別を割り当てる
            productTypeId = undefined;
            context$2$0.t0 = item.delivery;
            context$2$0.next = context$2$0.t0 === '宅配便' ? 10 : context$2$0.t0 === 'ゆうパケット' ? 12 : 14;
            break;

          case 10:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 12:
            productTypeId = 2;
            return context$2$0.abrupt('break', 16);

          case 14:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 16:
            tags = [];
            context$2$0.t1 = item.delivery;
            context$2$0.next = context$2$0.t1 === '宅配便' ? 20 : context$2$0.t1 === 'ゆうパケット' ? 22 : 24;
            break;

          case 20:
            tags.push({
              tag: 4,
              set: 'on'
            }, {
              tag: 5,
              set: 'off'
            });
            return context$2$0.abrupt('break', 25);

          case 22:
            tags.push({
              tag: 5,
              set: 'on'
            }, {
              tag: 4,
              set: 'off'
            });
            return context$2$0.abrupt('break', 25);

          case 24:
            return context$2$0.abrupt('break', 25);

          case 25:
            deliveryFee = null;
            context$2$0.t2 = item.delivery;
            context$2$0.next = context$2$0.t2 === '宅配便' ? 29 : context$2$0.t2 === 'ゆうパケット' ? 31 : 33;
            break;

          case 29:
            deliveryFee = null;
            return context$2$0.abrupt('break', 34);

          case 31:
            deliveryFee = 240;
            return context$2$0.abrupt('break', 34);

          case 33:
            return context$2$0.abrupt('break', 34);

          case 34:
            context$2$0.next = 36;
            return regeneratorRuntime.awrap(this.getVariation(item, {
              product_id: '$mall.sharakuShop.product_id'
            }));

          case 36:
            attrs = context$2$0.sent;

            // HTML バリエーション商品ごとのリンク付きボタンを表示する

            // 値の変換
            attrs = attrs.map(function (attr) {
              attr.props.current = convDeliv(attr.props.current);
              attr.variations = attr.variations.map(function (variation) {
                variation.value = convDeliv(variation.value);
                return variation;
              });
              return attr;
            });

            // HTML生成
            variationHtml = attrs.map(function (attr) {
              return '' + ('<div class="container-fluid">' + '<div class="row">' + '<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">' + ('<strong>' + attr.props.label + '</strong>') + '</div>') + attr.variations.map(function (variation) {
                if (attr.props.current === variation.value) {
                  // 表示中の商品ボタン
                  return '<button class="btn btn-success btn-sm btn-item-class-select"><strong>' + variation.value + '</strong></button>';
                }if (variation.stock > 0) {
                  // 販売可能商品のボタン
                  return '<a href="/products/detail/' + variation.product_id + '"><button class="btn btn-default btn-sm btn-item-class-select">' + variation.value + '</button></a>';
                }
                // 販売不可能商品のボタン（在庫なし）
                return '<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">' + variation.value + '</button>';
              }).join('') + '</div>' + '</div>';
            }).join('');
            descriptionDetail = '\n    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>\n    ' + variationHtml + '\n    ';
            data = {
              product_id: productId,
              creator_id: configUploadItem.creator_id,
              name: modelClass.join('/') + ' ' + convDeliv(item.delivery) + ' ' + item.name + (item.jan_code ? ' ' + item.jan_code : ''),
              description_detail: descriptionDetail,
              // free_area: await this.convertItemCube3createFreeArea(item),
              product_code: modelClass.join('/'),
              price01: item.retail_price,
              // price02: await this.convertItemCube3createPrice02(item),
              // images: await this.convertItemCube3createImages(item),
              product_type_id: productTypeId,
              tags: tags,
              delivery_fee: deliveryFee
            };
            context$2$0.t3 = Object;
            context$2$0.t4 = data;
            context$2$0.next = 45;
            return regeneratorRuntime.awrap(this.convertItemCube3createFreeArea(configUploadItem, item));

          case 45:
            context$2$0.t5 = context$2$0.sent;
            context$2$0.t3.assign.call(context$2$0.t3, context$2$0.t4, context$2$0.t5);
            context$2$0.t6 = Object;
            context$2$0.t7 = data;
            context$2$0.next = 51;
            return regeneratorRuntime.awrap(this.convertItemCube3createPrice02(configUploadItem, item));

          case 51:
            context$2$0.t8 = context$2$0.sent;
            context$2$0.t6.assign.call(context$2$0.t6, context$2$0.t7, context$2$0.t8);
            context$2$0.t9 = Object;
            context$2$0.t10 = data;
            context$2$0.next = 57;
            return regeneratorRuntime.awrap(this.convertItemCube3createImages(configUploadItem, item));

          case 57:
            context$2$0.t11 = context$2$0.sent;
            context$2$0.t9.assign.call(context$2$0.t9, context$2$0.t10, context$2$0.t11);

            Object.assign(data, item.mall.sharakuShop);

            return context$2$0.abrupt('return', data);

          case 61:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createFreeArea',
    value: function convertItemCube3createFreeArea(configUploadItem, item) {
      var freeArea, i;
      return regeneratorRuntime.async(function convertItemCube3createFreeArea$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            freeArea = '';

            // 商品情報テキストを記載する
            freeArea += item.description;
            // 2番目以降の画像をフリーエリアに記載する
            for (i = 1; i < item.images.length; i++) {
              freeArea += '<img src="/upload/save_image/' + item.images[i] + '"><br>';
            } // 情報のクリア
            freeArea += ' ';
            return context$2$0.abrupt('return', { free_area: freeArea });

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createPrice02',
    value: function convertItemCube3createPrice02(configUploadItem, item) {
      return regeneratorRuntime.async(function convertItemCube3createPrice02$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            return context$2$0.abrupt('return', { price02: item.mall.sharakuShop.price });

          case 1:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createImages',
    value: function convertItemCube3createImages(configUploadItem, item) {
      var arr;
      return regeneratorRuntime.async(function convertItemCube3createImages$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            arr = typeof item.images[0] === 'undefined' ? [] : [item.images[0]];
            return context$2$0.abrupt('return', { images: arr });

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct1',
    value: function convertItemYauct1(config, item) {
      var res;
      return regeneratorRuntime.async(function convertItemYauct1$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.convertItemYauct(config['default'], item));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct',
    value: function convertItemYauct(def, item) {
      var idLength, titleLength, yauct, imgPrefix, i;
      return regeneratorRuntime.async(function convertItemYauct$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            idLength = 20;
            titleLength = 130;
            yauct = {};

            // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）
            yauct = JSON.parse(JSON.stringify(def[item.delivery]));

            // 画像の記述
            imgPrefix = '画像';

            for (i = 0; i < item.images.length; i++) {
              yauct[imgPrefix + (i + 1)] = item.images[i];
            } // タイトル
            yauct['カテゴリ'] = item.mall.yauct.category;
            context$2$0.t0 = _utilText2['default'];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap(this.getModelClass(item));

          case 10:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = context$2$0.t1 + ' ';
            context$2$0.t3 = item.delivery;
            context$2$0.t4 = context$2$0.t2 + context$2$0.t3;
            context$2$0.t5 = context$2$0.t4 + ' ';
            context$2$0.t6 = item.name;
            context$2$0.t7 = context$2$0.t5 + context$2$0.t6;
            context$2$0.t8 = titleLength;
            yauct['タイトル'] = context$2$0.t0.substr8.call(context$2$0.t0, context$2$0.t7, context$2$0.t8);

            yauct['開始価格'] = item.sales_price;
            yauct['即決価格'] = item.sales_price;
            yauct['管理番号'] = item._id.toHexString().slice(-idLength);
            if (typeof yauct['説明'] === 'string') yauct['説明'] = item.description + '<br><br>' + yauct['説明'];else yauct['説明'] = item.description;

            yauct['JANコード・ISBNコード'] = item.jan_code;

            return context$2$0.abrupt('return', yauct);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemWowmaCreateDeliveryMethod',
    value: function convertItemWowmaCreateDeliveryMethod(itemCode) {
      var id, set, metrics, aggr, acceptDeliv, _iteratorNormalCompletion7, _didIteratorError7, _iteratorError7, _iterator7, _step7, del, deliveryMethod, i, _id;

      return regeneratorRuntime.async(function convertItemWowmaCreateDeliveryMethod$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            id = 'mall.wowma.itemCode';
            set = 'delivery';
            metrics = {
              ゆうパケット: ['Post'],
              宅配便: ['YU-Pack', 'Kangaroo']
            };
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: _defineProperty({}, id, itemCode)
            }, {
              $group: _defineProperty({
                _id: '$' + id
              }, set, { $addToSet: '$' + set })
            }, {
              $project: _defineProperty({
                _id: 0,
                itemCode: '$_id'
              }, set, '$' + set)
            }]).toArray());

          case 5:
            aggr = context$2$0.sent;
            acceptDeliv = [];
            _iteratorNormalCompletion7 = true;
            _didIteratorError7 = false;
            _iteratorError7 = undefined;
            context$2$0.prev = 10;

            for (_iterator7 = aggr[0].delivery[Symbol.iterator](); !(_iteratorNormalCompletion7 = (_step7 = _iterator7.next()).done); _iteratorNormalCompletion7 = true) {
              del = _step7.value;
              acceptDeliv = acceptDeliv.concat(metrics['' + del]);
            }context$2$0.next = 18;
            break;

          case 14:
            context$2$0.prev = 14;
            context$2$0.t0 = context$2$0['catch'](10);
            _didIteratorError7 = true;
            _iteratorError7 = context$2$0.t0;

          case 18:
            context$2$0.prev = 18;
            context$2$0.prev = 19;

            if (!_iteratorNormalCompletion7 && _iterator7['return']) {
              _iterator7['return']();
            }

          case 21:
            context$2$0.prev = 21;

            if (!_didIteratorError7) {
              context$2$0.next = 24;
              break;
            }

            throw _iteratorError7;

          case 24:
            return context$2$0.finish(21);

          case 25:
            return context$2$0.finish(18);

          case 26:
            deliveryMethod = new Array(5);

            for (i = 0; i < deliveryMethod.length; i++) {
              _id = typeof acceptDeliv[i] === 'undefined' ? 'NULL' : acceptDeliv[i];

              deliveryMethod[i] = { deliveryMethodSeq: i + 1, deliveryMethodId: _id };
            }

            return context$2$0.abrupt('return', { deliveryMethod: deliveryMethod });

          case 29:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[10, 14, 18, 26], [19,, 21, 25]]);
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その1 item.csv

  }], [{
    key: 'convertItemRobotinItem',
    value: function convertItemRobotinItem(item) {
      return {
        コントロールカラム: 'n',
        新規登録ID: item._id.toHexString(),
        商品ID: null,
        商品名: '' + item.model + (item.class1_value === '' ? '' : '/' + item.class1_value) + (item.class2_value === '' ? '' : '/' + item.class2_value),
        規格: 'なし'
      };
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その2 select.csv

  }, {
    key: 'convertItemRobotinSelect',
    value: function convertItemRobotinSelect(item) {
      var select = {
        コントロールカラム: 'n',
        新規登録ID: item._id.toHexString(),
        商品ID: null,
        外部連携ID: null,
        外部連携商品番号: item._id.toHexString()
      };

      var shops = _collections.RobotinShop.find();

      shops.forEach(function (doc, index) {
        var model = undefined;
        var class1 = undefined;
        var class2 = undefined;
        try {
          // モールの商品番号を特定する
          model = item.mall['' + doc.name]['' + doc.modelPath];
          model = typeof model === 'undefined' ? '' : model;
          class1 = item.mall['' + doc.name]['' + doc.class1Path];
          class1 = typeof class1 === 'undefined' ? '' : class1;
          class2 = item.mall['' + doc.name]['' + doc.class2Path];
          class2 = typeof class2 === 'undefined' ? '' : class2;
        } catch (e) {
          // 商品のモール情報の取得に失敗した（データが設定されていないなど）
          // model = item.model
          // class1 = item.class1_value
          // class2 = item.class2_value
          return;
        }

        select['受注商品ID_' + index] = null;
        select['店舗ID_' + index] = doc['店舗ID'];
        select['店舗名_' + index] = doc.name;
        select['受注商品番号_' + index] = '' + model + class1 + class2;
        select['有効フラグ_' + index] = '有効';
      });

      return select;
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その3 selectShop.csv

  }, {
    key: 'convertItemRobotinSelectShop',
    value: function convertItemRobotinSelectShop(shop, item) {
      var model = item.mall['' + shop.name]['' + shop.modelPath];
      var class1 = item.mall['' + shop.name]['' + shop.class1Path];
      var class2 = item.mall['' + shop.name]['' + shop.class2Path];

      return {
        コントロールカラム: 'u',
        新規登録ID: item._id.toHexString(),
        受注商品ID: null,
        店舗ID: shop['店舗ID'],
        店舗名: null,
        受注商品番号: '' + model + class1 + class2,
        有効フラグ: '有効'
      };
    }
  }]);

  return ItemController;
})();

exports['default'] = ItemController;
module.exports = exports['default'];

// product * <-> * item
// product[]: 複数の商品を1パッケージとして販売
// product[{ids:[<ObjectId>],set:<Number>}]: 異なる流通経路、異なる原価・仕入れ値
// item: 異なるセール、販売形態
// ※ product からは、販売可能な在庫、利益計算のための情報を得る

// セット商品の場合、一番少ない商品数に合わせる

// アップロード済み画像の情報取得

// 検索条件の組み立て

// 登録した画像ファイル名一覧

// 検索条件の組み立て

/**
 * aggregation設定
 *
 * label: 属性名（配送方法、カラー、サイズなど）
 * current: 指定されたアイテム（item）が該当する項目
 * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
 * query: aggregation対象とするドキュメントの検索条件
 */

// item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

// 値変換

// product_id

// 商品タグを設定する

// 商品別送料を設定する

//
// 顧客向けバリエーション商品選択機能の実装
//

// 商品データを作る

// 価格を返す

// 画像リストのうち1つめだけを返す

// deliveryMethodSeq
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/robotin.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _bson = require('bson');

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var _items = require('./items');

var _items2 = _interopRequireDefault(_items);

var _collections = require('../collections');

var Robotin = (function () {
  function Robotin() {
    _classCallCheck(this, Robotin);

    // importOrderTemp に関連
    // 受発注システムでは処理できない例外的受注処理に対して
    // 個別の送り状発行などを行う
    this.Order = new _meteorMongo.Mongo.Collection(null);
  }

  _createClass(Robotin, [{
    key: 'importOrderTemp',

    /**
     *
     * @param {*} docOrder
     * @param {ItemController} itemS
     */
    value: function importOrderTemp(docOrder, itemS) {
      // 受注データをデータベースに保存
      this.Order.insert({ robotin: docOrder });
    }

    /**
     *
     * @param {*} docOrder
     * @param {ItemController} itemCon
     */
  }, {
    key: 'transformLabelSeino',

    /**
     *
     * @param {*} docLabel
     * @param {Array} writeItemCodeTo
     */
    value: function transformLabelSeino(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      //

      // 受注番号を抽出
      var orderNumber = docLabel[32]; // 33番目の項目「記事１」

      // // 受注CSVから店舗名と受注番号をキーに商品コード一覧を取得する
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel[11], // 12番目の項目「荷送人名称」
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });

      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel[11], // 12番目の項目「荷送人名称」
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      // // 送り状レコードに該当する受注レコードが見つからない場合
      // if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');

      // // 送り状の発送商品コード一覧を配列にする
      // const items = cur.fetch();

      // docLabel : 入力送り状データ
      // conLabel : 出力用送り状データ
      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // writeItemCodeTo （一つの送り状に記載できる商品コードの最大数）の総数より、受注データの商品数が多い場合はエラー
      var writeItemCodeTo = labelOptions.writeItemCodeTo;
      if (writeItemCodeTo.length < items.length) throw new Error('送り状データに記載できる商品数は' + writeItemCodeTo.length + '個までです');

      // 定数の埋め込み
      labelOptions['const'].forEach(function (e) {
        conLabel[e.column] = e.value;
      });

      // 送り状データに商品コードを記録する
      writeItemCodeTo.forEach(function (e, i) {
        if (items[i]) {
          conLabel[e] = items[i];
        } else {
          // 送り状の商品コード欄はすべて埋める
          // これにより列の欠落を防ぐ
          conLabel[e] = '';
        }
      });

      // 住所文字列の分割を修正する
      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      _utilText2['default'].splitlenb(conLabel, [12, 13], 40); // 項目13「荷送人住所１」、項目14「荷送人住所２」
      _utilText2['default'].splitlenb(conLabel, [21, 22], 60); // 項目22「お届け先住所１」、項目23「お届け先住所２」

      return conLabel;
    }

    /**
     *
     * @param {*} docLabel
     * @param {Array} writeItemCodeTo
     */
  }, {
    key: 'transformLabelYupack',
    value: function transformLabelYupack(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      //

      // 受注番号を抽出
      var orderNumber = docLabel['記事名１'].replace('受注番号：', '');

      // // 受注CSVから店舗名と受注番号をキーに商品コード一覧を取得する
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel['ご依頼主 名称1'],
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });

      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel['ご依頼主 名称1'],
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      // docLabel : 入力送り状データ
      // conLabel : 出力用送り状データ
      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // writeItemCodeTo （一つの送り状に記載できる商品コードの最大数）の総数より、受注データの商品数が多い場合はエラー
      var writeItemCodeTo = labelOptions.writeItemCodeTo;
      if (writeItemCodeTo.length < items.length) throw new Error('送り状データに記載できる商品数は' + writeItemCodeTo.length + '個までです');

      // 送り状データに商品コードを記録する
      writeItemCodeTo.forEach(function (e, i) {
        if (items[i]) {
          conLabel[e] = items[i];
        } else {
          // 送り状の商品コード欄はすべて埋める
          // これにより列の欠落を防ぐ
          conLabel[e] = '';
        }
      });

      // 送り状種別を設定
      conLabel['送り状種別'] = labelOptions.labelId;

      // 住所文字列の分割を修正する
      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      _utilText2['default'].splitlenb(conLabel, ['ご依頼主 住所1', 'ご依頼主 住所2', 'ご依頼主 住所3'], 50);
      _utilText2['default'].splitlenb(conLabel, ['お届け先 住所1', 'お届け先 住所2', 'お届け先 住所3'], 50);
      return conLabel;
    }
  }, {
    key: 'transformLabelYupacket',
    value: function transformLabelYupacket(docLabel, writeItemCodeTo) {
      // 商品コードを送り状CSVに埋め込む
      var orderNumber = docLabel['記事名１'].replace('受注番号：', '');
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel['ご依頼主 名称1'],
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });
      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel['ご依頼主 名称1'],
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      var conLabel = JSON.parse(JSON.stringify(docLabel));
      conLabel['記事名１'] = items.join('　');

      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      _utilText2['default'].splitlenb(conLabel, ['ご依頼主 住所1', 'ご依頼主 住所2', 'ご依頼主 住所3'], 50);
      _utilText2['default'].splitlenb(conLabel, ['お届け先 住所1', 'お届け先 住所2', 'お届け先 住所3'], 50);
      return conLabel;
    }
  }], [{
    key: 'createReadableOrder',
    value: function createReadableOrder() {
      var query = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      return _collections.RobotinOrders.rawCollection().find(query, { _id: 0, robotin: 1 }).stream();
    }
  }, {
    key: 'importOrder',
    value: function importOrder(docOrder, itemCon) {
      var insertDoc;
      return regeneratorRuntime.async(function importOrder$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            insertDoc = {
              robotin: docOrder
            };

            // すでに受注が取り込まれていた場合は、docOrderの内容に更新する
            // 取り込まれていない受注の場合は新規登録する
            _collections.RobotinOrders.update({
              'robotin.受注ID': docOrder['受注ID'],
              'robotin.明細ID': docOrder['明細ID']
            }, {
              $set: {
                robotin: docOrder
              }
            }, {
              upsert: true
            });

            // 発注ステータスが設定されていないドキュメント（新規登録受注）
            // 発注ステータスの初期値を設定する
            _collections.RobotinOrders.update({
              vendor: { $exists: 0 }
            }, {
              $set: {
                vendor: { // 発注ステータスの初期値
                  orderto: "", // 発注先
                  orderDate: null, // 発注日
                  promise: null }
              }
            });

          case 3:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'listItemCodeForLabel',
    // 発送予定日
    value: function listItemCodeForLabel(query) {
      var collection = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      collection = collection === null ? _collections.RobotinOrders : collection;

      // 検索条件に該当する受注を調べる
      var cur = collection.find(query, {
        fields: {
          _id: 0,
          'robotin.商品コード': 1,
          'robotin.数量': 1
        }
      });
      // 送り状レコードに該当する受注レコードが見つからない場合
      if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');
      // 商品リストを作成する
      var list = [];
      cur.forEach(function (doc) {
        var q = doc.robotin.数量 == 1 ? '' : '[' + doc.robotin.数量 + 'EA]';
        list.push(doc.robotin.商品コード + ' ' + q);
      });
      // 商品リストを返す
      return list;
    }
  }]);

  return Robotin;
})();

exports['default'] = Robotin;
module.exports = exports['default'];

// 商品番号をmongoIdとして検索し、該当するitemがあれば書き換える
// if (ObjectID.isValid(docOrder['商品コード'])) {
//   const item = await itemCon.Items.findOne({ _id: new ObjectID(docOrder['商品コード']) });
//   if (item) docOrder['商品コード'] = await itemCon.getModelClass(item);
// }

// 受注データをデータベースに保存
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/wowmaApi.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _xmlJs = require('xml-js');

var _utilError = require('../util/error');

var _utilError2 = _interopRequireDefault(_utilError);

var BASE_URI = 'https://api.manager.wowma.jp/wmshopapi';

var WowmaApi = (function () {
  function WowmaApi(plug, shopId) {
    _classCallCheck(this, WowmaApi);

    this.plug = plug;
    this.shopId = shopId;
  }

  // 商品情報更新

  _createClass(WowmaApi, [{
    key: 'updateItem',
    value: function updateItem(_updateItem) {
      var request, res;
      return regeneratorRuntime.async(function updateItem$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            request = '<request><shopId>' + this.shopId + '</shopId><updateItem>' + (0, _xmlJs.json2xml)(_updateItem, { compact: true }) + '</updateItem></request>';
            context$2$0.prev = 1;
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.requestPost('updateItemInfo', request));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', { response: res, requestXML: request });

          case 8:
            context$2$0.prev = 8;
            context$2$0.t0 = context$2$0['catch'](1);
            throw Object.assign(_utilError2['default'].parse(context$2$0.t0), { requestXML: request });

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[1, 8]]);
    }
  }, {
    key: 'requestPost',
    value: function requestPost(method, body) {
      var apiRequest, res;
      return regeneratorRuntime.async(function requestPost$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/' + method,
              body: body
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            // リクエスト発行
            context$2$0.next = 4;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(stockUpdateItem) {
      var apiRequest, res;
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/updateStock'
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.updateStockCreateRequestBody(stockUpdateItem));

          case 4:
            apiRequest.body = context$2$0.sent;
            context$2$0.next = 7;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStockCreateRequestBody',
    value: function updateStockCreateRequestBody(stockUpdateItem) {
      var stockUpdateItemXML, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, item, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, e, var0, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, variation, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, key, apiRequestBody;

      return regeneratorRuntime.async(function updateStockCreateRequestBody$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            stockUpdateItemXML = '';
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 4;
            _iterator = stockUpdateItem[Symbol.iterator]();

          case 6:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 87;
              break;
            }

            item = _step.value;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 11;

            // 値のチェック
            for (_iterator2 = item.variations[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              e = _step2.value;

              // 在庫数の上限100
              if (e.stock > 100) e.stock = 100;
            }

            context$2$0.next = 19;
            break;

          case 15:
            context$2$0.prev = 15;
            context$2$0.t0 = context$2$0['catch'](11);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 19:
            context$2$0.prev = 19;
            context$2$0.prev = 20;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 22:
            context$2$0.prev = 22;

            if (!_didIteratorError2) {
              context$2$0.next = 25;
              break;
            }

            throw _iteratorError2;

          case 25:
            return context$2$0.finish(22);

          case 26:
            return context$2$0.finish(19);

          case 27:
            stockUpdateItemXML += '<stockUpdateItem>';
            stockUpdateItemXML += '<itemCode>' + item.itemCode + '</itemCode>';

            // 商品在庫種別を振り分け
            // 1 -> 通常商品
            // 2 -> 選択肢別在庫

            var0 = item.variations[0];

            if (!(var0.choicesStockHorizontalCode === '' && var0.choicesStockVerticalCode === '')) {
              context$2$0.next = 35;
              break;
            }

            // 通常商品
            stockUpdateItemXML += '<stockSegment>1</stockSegment>';
            stockUpdateItemXML += '<stockCount>' + var0.stock + '</stockCount>';
            context$2$0.next = 83;
            break;

          case 35:
            // 選択肢別在庫
            stockUpdateItemXML += '<stockSegment>2</stockSegment>';

            // リクエストボディを作成する
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 39;
            _iterator3 = item.variations[Symbol.iterator]();

          case 41:
            if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
              context$2$0.next = 69;
              break;
            }

            variation = _step3.value;

            // 在庫設定タグの名前を差し替える
            variation.choicesStockCount = variation.stock;
            delete variation.stock;

            // xmlを構成する
            stockUpdateItemXML += '<choicesStocks>';
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 49;
            for (_iterator4 = Object.keys(variation)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              key = _step4.value;

              stockUpdateItemXML += '<' + key + '>' + variation[key] + '</' + key + '>';
            }
            context$2$0.next = 57;
            break;

          case 53:
            context$2$0.prev = 53;
            context$2$0.t1 = context$2$0['catch'](49);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 57:
            context$2$0.prev = 57;
            context$2$0.prev = 58;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 60:
            context$2$0.prev = 60;

            if (!_didIteratorError4) {
              context$2$0.next = 63;
              break;
            }

            throw _iteratorError4;

          case 63:
            return context$2$0.finish(60);

          case 64:
            return context$2$0.finish(57);

          case 65:
            stockUpdateItemXML += '</choicesStocks>';

          case 66:
            _iteratorNormalCompletion3 = true;
            context$2$0.next = 41;
            break;

          case 69:
            context$2$0.next = 75;
            break;

          case 71:
            context$2$0.prev = 71;
            context$2$0.t2 = context$2$0['catch'](39);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t2;

          case 75:
            context$2$0.prev = 75;
            context$2$0.prev = 76;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 78:
            context$2$0.prev = 78;

            if (!_didIteratorError3) {
              context$2$0.next = 81;
              break;
            }

            throw _iteratorError3;

          case 81:
            return context$2$0.finish(78);

          case 82:
            return context$2$0.finish(75);

          case 83:

            stockUpdateItemXML += '</stockUpdateItem>';

          case 84:
            _iteratorNormalCompletion = true;
            context$2$0.next = 6;
            break;

          case 87:
            context$2$0.next = 93;
            break;

          case 89:
            context$2$0.prev = 89;
            context$2$0.t3 = context$2$0['catch'](4);
            _didIteratorError = true;
            _iteratorError = context$2$0.t3;

          case 93:
            context$2$0.prev = 93;
            context$2$0.prev = 94;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 96:
            context$2$0.prev = 96;

            if (!_didIteratorError) {
              context$2$0.next = 99;
              break;
            }

            throw _iteratorError;

          case 99:
            return context$2$0.finish(96);

          case 100:
            return context$2$0.finish(93);

          case 101:
            apiRequestBody = '\n    <request>\n    <shopId>' + this.shopId + '</shopId>\n    ' + stockUpdateItemXML + '\n    </request>\n    ';
            return context$2$0.abrupt('return', apiRequestBody);

          case 103:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[4, 89, 93, 101], [11, 15, 19, 27], [20,, 22, 26], [39, 71, 75, 83], [49, 53, 57, 65], [58,, 60, 64], [76,, 78, 82], [94,, 96, 100]]);
    }
  }]);

  return WowmaApi;
})();

exports['default'] = WowmaApi;
module.exports = exports['default'];

// 接続オプションの作成

// 接続オプションの作成

// リクエスト発行

//
// stockUpdateItem =
// [
//   {
//     itemCode: <String>,
//     variations: [
//        {
//          choicesStockHorizontalCode: <String>,
//          choicesStockVerticalCode: <String>,
//          stock: <Number>
//        }
//     ]
//   }
// ]

// リクエストボディの作成

// リクエストボディを返す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/error.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var utilError = (function () {
  function utilError() {
    _classCallCheck(this, utilError);
  }

  _createClass(utilError, null, [{
    key: "parse",
    value: function parse(e) {
      var res = {};

      if (e instanceof Error) {
        res.message = e.message;
        res.name = e.name;
        res.fileName = e.fileName;
        res.lineNumber = e.lineNumber;
        res.columnNumber = e.columnNumber;
        res.stack = e.stack;
      } else {
        res = e;
      }

      return res;
    }
  }]);

  return utilError;
})();

exports["default"] = utilError;
module.exports = exports["default"];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mongo.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var MongoCollection = (function () {
  function MongoCollection() {
    _classCallCheck(this, MongoCollection);
  }

  _createClass(MongoCollection, null, [{
    key: 'get',
    value: function get(plug, collection) {
      var client, db;
      return regeneratorRuntime.async(function get$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri, { useNewUrlParser: true }));

          case 2:
            client = context$2$0.sent;
            db = client.db(plug.database);
            return context$2$0.abrupt('return', db.collection(collection));

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }]);

  return MongoCollection;
})();

exports.MongoCollection = MongoCollection;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mysql.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mysql = require('mysql');

var _mysql2 = _interopRequireDefault(_mysql);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var MySQL = (function () {
  function MySQL(profile) {
    _classCallCheck(this, MySQL);

    // コネクションプール初期化
    this.pool = _mysql2['default'].createPool(profile);

    // 複数行ステートメント対応
    var profileMulti = { multipleStatements: true };
    Object.assign(profileMulti, profile);
    this.poolMulti = _mysql2['default'].createPool(profileMulti);
  }

  _createClass(MySQL, [{
    key: 'querySelect',
    value: function querySelect(table, condition) {
      var product = arguments.length <= 2 || arguments[2] === undefined ? '*' : arguments[2];
      var productPart, tablePart, conditionPart, res;
      return regeneratorRuntime.async(function querySelect$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productPart = product;
            tablePart = 'FROM ' + table;
            conditionPart = condition ? 'WHERE ' + condition : '';
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query('SELECT ' + productPart + ' ' + tablePart + ' ' + conditionPart));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', JSON.parse(JSON.stringify(res)));

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'query',

    /**
     *
     * @param {String} sql
     */
    value: function query(sql) {
      // コネクション確立
      // let con = await this.getCon();
      return this.getCon().then(function (con) {
        return new Promise(function (resolve, reject) {
          // クエリ送信
          con.query(sql, function (e, res) {
            // コネクション開放
            con.release();
            if (e) {
              reject(e);
            } else resolve(res);
          });
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'queryInsert_',
    value: function queryInsert_(sql) {
      var res;
      return regeneratorRuntime.async(function queryInsert_$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query(sql));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * @param {String} table
     * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryInsert',
    value: function queryInsert(table) {
      var data = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
      var dataSql = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

      var sql, map, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, k, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, res;

      return regeneratorRuntime.async(function queryInsert$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'INSERT INTO ' + table + ' ';
            map = new Map();
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 5;

            for (_iterator = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              k = _step.value;

              if (data[k] === null) {
                map.set(k, 'NULL');
              } else if (data[k].constructor.name === 'Date') {
                // 日付を変換
                map.set(k, '"' + MySQL.formatDate(data[k]) + '"');
              } else {
                map.set(k, '' + _mysql2['default'].escape(data[k]));
              }
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 24;
            for (_iterator2 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
            }

            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError2) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError2;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += '( ' + [].concat(_toConsumableArray(map.keys())).join(',') + ' ) ';

            sql += 'VALUES( ' + [].concat(_toConsumableArray(map.values())).join(',') + ' ) ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    /**
     *
     * @param {String} table
     * @param {String} filter SQL UPDATEステートメントのWHERE句
     * @param {Object} data 文字列のパラメーター
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryUpdate',
    value: function queryUpdate(table, filter, data, dataSql) {
      var sql, updates, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, k, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, res;

      return regeneratorRuntime.async(function queryUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'UPDATE ' + table + ' SET ';
            updates = [];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 5;

            for (_iterator3 = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              updates.push(k + '=' + _mysql2['default'].escape(data[k]));
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError3) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError3;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 24;
            for (_iterator4 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              updates.push(k + '=' + dataSql[k]);
            }
            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError4) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError4;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += updates.join(',');

            sql += ' WHERE ' + filter + ' ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    // enable to use multiple statements
  }, {
    key: 'queryMulti',
    value: function queryMulti(sql) {
      var poolSwap, res;
      return regeneratorRuntime.async(function queryMulti$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            poolSwap = this.pool;

            this.pool = this.poolMulti;
            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query(sql));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 7:
            context$2$0.prev = 7;

            this.pool = poolSwap;
            return context$2$0.finish(7);

          case 10:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2,, 7, 10]]);
    }
  }, {
    key: 'startTransaction',
    value: function startTransaction() {
      return regeneratorRuntime.async(function startTransaction$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('START TRANSACTION;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'commit',
    value: function commit() {
      return regeneratorRuntime.async(function commit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('COMMIT;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'rollback',
    value: function rollback() {
      return regeneratorRuntime.async(function rollback$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('ROLLBACK;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'streamingQuery',
    value: function streamingQuery(sql) {
      var _this = this;

      var onResult = arguments.length <= 1 || arguments[1] === undefined ? function (record) {} : arguments[1];
      var onError = arguments.length <= 2 || arguments[2] === undefined ? function (e) {} : arguments[2];

      return this.getCon().then(function (con) {
        return new Promise(function callee$3$0(resolve, reject) {
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                // クエリ送信
                con.query(sql).on('result', function (record) {
                  con.pause();
                  onResult(record);
                  con.resume();
                }).on('error', function (e) {
                  onError(e);
                }).on('end', function () {
                  con.release();
                  resolve();
                });

              case 1:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'getCon',
    value: function getCon() {
      var _this2 = this;

      return new Promise(function (resolve, reject) {
        // プールからのコネクション獲得
        _this2.pool.getConnection(function (e, con) {
          if (e) {
            reject(e);
          } else {
            resolve(con);
          }
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }], [{
    key: 'formatDate',
    value: function formatDate(date) {
      return (0, _moment2['default'])(date).format().substring(0, 19).replace('T', ' ');
    }
  }]);

  return MySQL;
})();

exports['default'] = MySQL;
module.exports = exports['default'];

// SELECTの結果はディープコピーすることで rowdatapacket を外す

// let res = await this.query(sql);
// return res.insertId;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/packet.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Packet = (function () {
  function Packet(packetSize) {
    _classCallCheck(this, Packet);

    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  _createClass(Packet, [{
    key: "submit",
    value: function submit(arg) {
      return regeneratorRuntime.async(function submit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            if (!(this.count % this.packetSize === 0)) {
              context$2$0.next = 4;
              break;
            }

            if (!this.onPacketStart) {
              context$2$0.next = 4;
              break;
            }

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.onPacketStart(this.packetCount));

          case 4:
            if (!this.onPacket) {
              context$2$0.next = 7;
              break;
            }

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.onPacket(arg));

          case 7:
            this.count++;
            // packetSizeの回数ごとに、終了処理を呼び出す
            if (this.count % this.packetSize === 0) {
              this.close();
              this.packetCount++;
            }

          case 9:
          case "end":
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: "close",
    value: function close() {
      if (this.onPacketEnd) {
        this.onPacketEnd(this.packetCount);
      }
    }
  }]);

  return Packet;
})();

exports["default"] = Packet;
module.exports = exports["default"];

// packetSizeの回数ごとに、初期化を呼び出す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/report.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _error = require('./error');

var _error2 = _interopRequireDefault(_error);

var _meteorMeteor = require('meteor/meteor');

var _collections = require('../collections');

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

var Report = (function () {
  function Report() {
    _classCallCheck(this, Report);

    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  // private

  _createClass(Report, [{
    key: 'setupIterator',
    value: function setupIterator(phaseId) {
      this.iterator = new Iterator(phaseId);
      this.iterators.push(this.iterator);
    }
  }, {
    key: 'phase',
    value: function phase() {
      var _this = this;

      var name = arguments.length <= 0 || arguments[0] === undefined ? '' : arguments[0];
      var fn = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0() {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
      var rec, res;
      return regeneratorRuntime.async(function phase$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            rec = {
              phaseId: (0, _uniqid2['default'])()
            };

            this.setupIterator(rec.phaseId);

            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(fn());

          case 5:
            res = context$2$0.sent;

            Object.assign(rec, {
              type: 'success',
              phase: name,
              result: res
            });
            context$2$0.next = 12;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](2);

            Object.assign(rec, {
              type: 'error',
              phase: name,
              result: _error2['default'].parse(context$2$0.t0)
            });

          case 12:
            context$2$0.prev = 12;

            // ループ処理のレポートを作成
            if (this.iterator.metric.total) {
              Object.assign(rec, {
                iterator: this.iterator.metric
              });
            }
            // タイムスタンプ
            rec.timeStamp = new Date();
            // レポートをデータベースに記録
            _collections.Logs.insert(rec);

            // 呼び出し元用レポートに追加
            this.record.push(rec);
            return context$2$0.finish(12);

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2, 9, 12, 18]]);
    }

    // カーソルをループし、与えられた関数を実行
    // 呼び出す関数の引数にはカーソルから得られたドキュメントを渡す
  }, {
    key: 'forEachOnCursor',
    value: function forEachOnCursor(cur, fn) {
      var doc, res;
      return regeneratorRuntime.async(function forEachOnCursor$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 2:
            if (!context$2$0.sent) {
              context$2$0.next = 18;
              break;
            }

            context$2$0.next = 5;
            return regeneratorRuntime.awrap(cur.next());

          case 5:
            doc = context$2$0.sent;
            context$2$0.prev = 6;
            context$2$0.next = 9;
            return regeneratorRuntime.awrap(fn(doc));

          case 9:
            res = context$2$0.sent;

            this.iSuccess(res);
            context$2$0.next = 16;
            break;

          case 13:
            context$2$0.prev = 13;
            context$2$0.t0 = context$2$0['catch'](6);

            this.iError(context$2$0.t0);

          case 16:
            context$2$0.next = 0;
            break;

          case 18:
            cur.close();

          case 19:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 13]]);
    }
  }, {
    key: 'iSuccess',
    value: function iSuccess(newRecord) {
      this.iterator.success(newRecord);
    }
  }, {
    key: 'iError',
    value: function iError(newRecord) {
      this.iterator.error(_error2['default'].parse(newRecord));
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      var iteError = this.iterators.find(function (e) {
        return e.errorOcurred();
      });
      var phaError = false;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.record[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var rec = _step.value;

          if (rec.type === 'error') {
            phaError = true;
            break;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return iteError || phaError;
    }
  }, {
    key: 'publish',
    value: function publish() {
      // 呼び出し元へレポート
      if (this.errorOcurred()) {
        throw new _meteorMeteor.Meteor.Error(this.record);
      }
      return this.record;
    }
  }]);

  return Report;
})();

exports['default'] = Report;

var Iterator = (function () {
  function Iterator(phaseId) {
    _classCallCheck(this, Iterator);

    this.metric = {
      total: 0,
      success: 0,
      error: 0,
      phaseId: phaseId
    };
    this.lastError = null;
  }

  _createClass(Iterator, [{
    key: 'success',
    value: function success(newRecord) {
      if (newRecord) {
        this.log(newRecord, true);
      }
      this.metric.success++;
      this.metric.total++;
    }
  }, {
    key: 'error',
    value: function error(newRecord) {
      // 直前と同じエラーは省く
      if (JSON.stringify(this.lastError) !== JSON.stringify(newRecord)) {
        if (newRecord && newRecord !== {} && newRecord !== '') {
          this.log(newRecord, false);
          this.lastError = newRecord;
        }
      }
      this.metric.error++;
      this.metric.total++;
    }
  }, {
    key: 'log',
    value: function log(newRecord, isSuccess /* true => success or false => error */) {
      var rec = {
        success: isSuccess,
        phaseId: this.metric.phaseId,
        message: newRecord,
        timeStamp: new Date()
      };
      _collections.Logs.insert(rec);
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      return this.metric.error;
    }
  }]);

  return Iterator;
})();

module.exports = exports['default'];

// リクエスト発行
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"syncObject.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/syncObject.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

/**
 *
 * @param {[Object]} src
 * @param {[Object]} dst
 * @param {string} idkey
 * @param {function(any, Object)} create
 * @param {function(any, Object)} remove
 */

exports['default'] = function syncObject(src, dst, idkey, addFunc, remFunc) {
  if (idkey === undefined) idkey = null;
  var srcContainer, dstContainer, idDeletedClone;
  return regeneratorRuntime.async(function syncObject$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        srcContainer = [];
        dstContainer = [];

        idDeletedClone = function idDeletedClone(elem, idkeyAP) {
          var elemSave = _lodash2['default'].cloneDeep(elem);
          // id を比較対象から外す
          if (_lodash2['default'].isUndefined(elemSave[idkeyAP]) === false) {
            delete elemSave[idkeyAP];
          }
          // ディープクローンしたオブジェクトを返す
          return elemSave;
        };

        // オブジェクト比較の前準備
        src.forEach(function (elem) {
          srcContainer.push({
            object: idDeletedClone(elem, idkey),
            id: elem[idkey],
            state: {
              /**
               * true 何もしない
               * false 新規に作成
               */
              find: false
            }
          });
        });

        dst.forEach(function (elem) {
          dstContainer.push({
            object: idDeletedClone(elem, idkey),
            id: elem[idkey],
            state: {
              /**
               * true 何もしない
               * false 削除する
               */
              find: false
            }
          });
        });

        // オブジェクトを比較
        srcContainer.forEach(function (srcElem) {
          dstContainer.forEach(function (dstElem) {
            if (_lodash2['default'].isEqual(srcElem.object, dstElem.object)) {
              // 同じオブジェクトが見つかった場合
              srcElem.state.find = true;
              dstElem.state.find = true;
            }
          });
        });

        // データの挿入
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(Promise.all(srcContainer.map(function callee$1$0(elem) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                if (!(elem.state.find === false)) {
                  context$2$0.next = 3;
                  break;
                }

                context$2$0.next = 3;
                return regeneratorRuntime.awrap(addFunc(elem.id, elem.object));

              case 3:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        })));

      case 8:
        context$1$0.next = 10;
        return regeneratorRuntime.awrap(Promise.all(dstContainer.map(function callee$1$0(elem) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                if (!(elem.state.find === false)) {
                  context$2$0.next = 3;
                  break;
                }

                context$2$0.next = 3;
                return regeneratorRuntime.awrap(remFunc(elem.id, elem.object));

              case 3:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        })));

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
};

module.exports = exports['default'];

// データの削除
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/text.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var TextUtil = (function () {
  function TextUtil() {
    _classCallCheck(this, TextUtil);
  }

  _createClass(TextUtil, null, [{
    key: 'substr8',

    // 8ビットで文字列切り取る
    value: function substr8(text, len, truncation) {
      if (truncation === undefined) {
        truncation = '';
      }
      var textArray = text.split('');
      var count = 0;
      var str = '';
      for (var i = 0; i < textArray.length; i++) {
        var n = escape(textArray[i]);
        if (n.length < 4) count++;else count += 2;
        if (count > len) {
          return str + truncation;
        }
        str += text.charAt(i);
      }
      return text;
    }

    // 文字列のバイト数を数える
  }, {
    key: 'lenb',
    value: function lenb(text) {
      return encodeURIComponent(text).replace(/%..%..%../g, 'xx').length;
    }
  }, {
    key: 'splitlenb',
    value: function splitlenb(target, keyS, length) {
      var sep = ' ';
      // keyS で指定された target 内の要素の値をすべて結合した文字列を作る
      var strEntire = keyS.reduce(function (prev, current) {
        return prev + target[current];
      }, '');
      // 結合した文字列を半角スペースで分割する
      var arrEntire = strEntire.split(sep);
      var arrRes = [];
      var last = '';
      // バイト長がlengthを超えない限り前後の分割文字列を結合していく
      // バイト長がlengthを超えたら、ひとつまえの結合文字列を配列登録する
      try {
        arrEntire.reduce(function (prev, current) {
          // length を超えるバイト長の分割文字列がある場合は何もしない
          if (TextUtil.lenb(current) > length) throw new Error('文字列超過');
          var exam = (prev !== '' ? prev + sep : '') + current;
          if (TextUtil.lenb(exam) > length) {
            arrRes.push(prev);
            last = current; // 最後の文字列
            return '';
          } else {
            last = exam; // 最後の文字列
            return exam;
          }
        }, '');
      } catch (e) {
        // length を超えるバイト長の分割文字列がある場合は何もしない
        if (e.message === '文字列超過') return;
      }

      arrRes.push(last); // 最後の文字列を配列登録する
      // keyS で指定された target 内の要素の値を修正する
      for (var i = 0; i < keyS.length; i++) {
        target[keyS[i]] = arrRes[i] ? arrRes[i] : '';
      }
    }
  }]);

  return TextUtil;
})();

exports['default'] = TextUtil;
module.exports = exports['default'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _this = this;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _meteorMeteor = require('meteor/meteor');

var _meteorMongo = require('meteor/mongo');

var Logs = new _meteorMongo.Mongo.Collection('logs', { idGeneration: 'MONGO' });
exports.Logs = Logs;
var Uploads = new _meteorMongo.Mongo.Collection('uploads', { idGeneration: 'MONGO' });

exports.Uploads = Uploads;
var RobotinShop = new _meteorMongo.Mongo.Collection('robotinShop', { idGeneration: 'MONGO' });
exports.RobotinShop = RobotinShop;
var RobotinOrders = new _meteorMongo.Mongo.Collection('robotinOrders', { idGeneration: 'MONGO' });

exports.RobotinOrders = RobotinOrders;
var Configs = new _meteorMongo.Mongo.Collection('configs', { idGeneration: 'MONGO' });

exports.Configs = Configs;
if (_meteorMeteor.Meteor.isServer) {
  _meteorMeteor.Meteor.publish('configs', function () {
    return Configs.find();
  });
  _meteorMeteor.Meteor.methods(_defineProperty({}, 'robotinOrderGroups', function robotinOrderGroups() {
    var res;
    return regeneratorRuntime.async(function robotinOrderGroups$(context$1$0) {
      while (1) switch (context$1$0.prev = context$1$0.next) {
        case 0:
          context$1$0.next = 2;
          return regeneratorRuntime.awrap(RobotinOrders.rawCollection().aggregate([{
            // 受注IDごとにグループ化
            $group: {
              _id: {
                受注ID: '$robotin.受注ID',
                受注日時: '$robotin.受注日時',
                店舗名: '$robotin.店舗名',
                受注番号: '$robotin.受注番号'
              },
              items: { $push: { 商品コード: '$robotin.商品コード', 数量: '$robotin.数量' } }
            }
          }, {
            $project: {
              _id: 0,
              受注ID: '$_id.受注ID',
              受注日時: '$_id.受注日時',
              店舗名: '$_id.店舗名',
              受注番号: '$_id.受注番号',
              items: '$items'
            }
          }]).toArray());

        case 2:
          res = context$1$0.sent;
          return context$1$0.abrupt('return', res);

        case 4:
        case 'end':
          return context$1$0.stop();
      }
    }, null, this);
  }));

  _meteorMeteor.Meteor.publish('robotinOrderItems', function callee$0$0() {
    return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
      while (1) switch (context$1$0.prev = context$1$0.next) {
        case 0:
          return context$1$0.abrupt('return', RobotinOrders.find());

        case 1:
        case 'end':
          return context$1$0.stop();
      }
    }, null, _this);
  });
}

if (_meteorMeteor.Meteor.isClient) {
  _meteorMeteor.Meteor.subscribe('configs');
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/robotin.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/wowmaApi.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yb2JvdGluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdG9vbHRlc3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci93b3dtYS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIveWF1Y3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3Vwcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL3JvYm90aW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS93b3dtYUFwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3N5bmNPYmplY3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC90ZXh0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb25zLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztrQkFLZSxJQUFJOzs7O3NCQUNBLFFBQVE7Ozs7OztpQ0FHSixvQkFBb0I7Ozs7a0NBR3BDLDhCQUE4Qjs7QUFDckMsSUFBSSxvQkFBb0IsR0FBRyxxQ0FBWSxDQUFDOztBQUV4QyxJQUFNLEtBQUssR0FBRyxlQUFlLENBQUM7OztBQUc5QixNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztBQUN4RCxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBQyxHQUFHLEVBQUUsSUFBSSxFQUFLOzs7QUFHL0MsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxnQkFBRyxRQUFRLENBQUMsQ0FBQztBQUM3QyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLGdCQUFHLFNBQVMsQ0FBQyxDQUFDO0FBQzlDLE1BQU0sUUFBUSxHQUFHLDBCQUFRLENBQUM7Ozs7Ozs7QUFFMUIseUJBQWlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSw4SEFBRTtVQUF4QixJQUFJOztBQUNYLFVBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7OztBQUcvQixVQUFJLFFBQVEsR0FBTSwwQkFBUSxTQUFNOzs7QUFHaEMsVUFBSSxRQUFRLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQzs7Ozs7QUFLbEQsVUFBSSxHQUFHLEdBQUc7QUFDUixnQkFBUSxFQUFFLFFBQVE7QUFDbEIsc0JBQWMsRUFBRSxJQUFJLENBQUMsSUFBSTtBQUN6Qix3QkFBZ0IsRUFBRSxRQUFRO09BQzNCLENBQUM7O0FBRUYsVUFBRztBQUNELGNBQU0sQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7T0FDeEIsQ0FDRCxPQUFNLEdBQUcsRUFBQztBQUNSLFdBQUcsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO09BQ2pCO0FBQ0Qsa0NBQVEsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDOztBQUVwQixhQUFPLElBQUksQ0FBQztLQUViOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsR0FBQztBQUNGLE1BQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDcEIsTUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO0FBQ3RCLFlBQVEsRUFBRSxRQUFRO0FBQ2xCLFdBQU8sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVE7R0FDM0IsQ0FBQyxDQUFDLENBQUM7Q0FFTCxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7O3NCQzdEaUIsUUFBUTs7Ozs0QkFFSixlQUFlOztnQ0FDcEIsMEJBQTBCOzs7O2lDQUN6QiwyQkFBMkI7Ozs7dUNBSXZDLGlDQUFpQzs7d0NBR2pDLGtDQUFrQzs7QUFFekMsSUFBSSxHQUFHLEdBQUcsU0FBUzs7QUFFbkIscUJBQU8sT0FBTyx5REFFRixHQUFHLGVBQVksb0JBQUMsTUFBTTtNQUMxQixNQUFNLEVBS04sTUFBTSxFQU1OLFNBQVMsRUFFVCxLQUFLOzs7Ozs7QUFiTCxjQUFNLEdBQUcsb0NBQVk7QUFLckIsY0FBTSxHQUFHLHFDQUFXLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFNdkMsaUJBQVMsR0FBRyxnQkFBZ0I7QUFFNUIsYUFBSyxHQUFHLGtDQUFVLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDOzt3Q0FFaEMsTUFBTSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsRUFDekM7Ozs7O2dEQUNRLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDOzs7Ozs7O1NBQzdCLENBQUM7Ozs7d0NBS0UsTUFBTSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsRUFDeEM7Y0FDTSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDN0IsNEJBQVUsRUFBRSxvQkFBTyxNQUFNO3dCQWFuQixHQUFHLEVBd0dILFFBQVEsRUFFUixVQUFVLEVBRVYsYUFBYSxFQUdYLElBQUc7Ozs7O0FBL0dMLDZCQUFHLDZkQUtPLE1BQU0sQ0FBQyxXQUFXLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsR0FBRyxXQUFNLE1BQU0sQ0FBQyxHQUFHLFdBQU0sTUFBTSxDQUFDLFVBQVUsV0FBTSxNQUFNLENBQUMsSUFBSSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLFlBQVksV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLE9BQU8sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxRQUFRLFdBQU0sTUFBTSxDQUFDLElBQUksV0FBTSxNQUFNLENBQUMsVUFBVSxXQUFNLE1BQU0sQ0FBQyxjQUFjLFdBQU0sTUFBTSxDQUFDLGFBQWEsV0FBTSxNQUFNLENBQUMsU0FBUyxXQUFNLE1BQU0sQ0FBQyxTQUFTLFdBQU0sTUFBTSxDQUFDLElBQUksV0FBTSxNQUFNLENBQUMsV0FBVyxXQUFNLE1BQU0sQ0FBQyxXQUFXLFdBQU0sTUFBTSxDQUFDLE9BQU87OzswREFLenJCLEtBQUssQ0FBQyxXQUFXLENBQ3JCLGNBQWMsRUFBRTtBQUNkLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0Isa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQiwrQkFBRyxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQ2YsK0JBQUcsRUFBRSxNQUFNLENBQUMsR0FBRztBQUNmLHNDQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDN0IsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLHdDQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7QUFDakMsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87QUFDdkIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixvQ0FBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ3pCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsc0NBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtBQUM3QiwwQ0FBYyxFQUFFLE1BQU0sQ0FBQyxjQUFjO0FBQ3JDLHlDQUFhLEVBQUUsTUFBTSxDQUFDLGFBQWE7QUFDbkMscUNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztBQUMzQixxQ0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO0FBQzNCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87MkJBQ3hCLENBQ0Y7Ozs7Ozs7Ozs7QUFFRCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7OzBEQUtWLEtBQUssQ0FBQyxXQUFXLENBQ3JCLHNCQUFzQixFQUFFO0FBQ3RCLCtDQUFtQixFQUFFLElBQUk7QUFDekIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixzQ0FBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO0FBQzdCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQix3Q0FBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO0FBQ2pDLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO0FBQ3ZCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTzsyQkFDeEIsQ0FDRjs7Ozs7Ozs7OztBQUVELGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7MERBS1YsS0FBSyxDQUFDLFdBQVcsQ0FDckIsdUJBQXVCLEVBQUU7QUFDdkIsOEJBQUUsRUFBRSxJQUFJO0FBQ1IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix3Q0FBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO0FBQ2pDLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPOzJCQUN4QixDQUNGOzs7Ozs7Ozs7O0FBRUQsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7QUFLZCxrQ0FBUSxHQUFHLG9CQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7QUFFcEUsb0NBQVUsR0FBTSxNQUFNLENBQUMsTUFBTSxTQUFJLE1BQU0sQ0FBQyxNQUFNLHdCQUFtQixNQUFNLENBQUMsV0FBVztBQUVuRix1Q0FBYSxHQUFHLE1BQU0sQ0FBQyxLQUFLLEdBQUcsR0FBRzs7OzBEQUdwQixLQUFLLENBQUMsV0FBVyxDQUMvQixZQUFZLEVBQUU7QUFDWixxQ0FBUyxFQUFFLElBQUk7QUFDZixxQ0FBUyxFQUFFLFFBQVE7QUFDbkIsdUNBQVcsRUFBRSxDQUFDO0FBQ2QsdUNBQVcsRUFBRSxVQUFVO0FBQ3ZCLHlDQUFhLEVBQUUsQ0FBQztBQUNoQiwyQ0FBZSxFQUFFLENBQUM7QUFDbEIsMENBQWMsRUFBRSxDQUFDO0FBQ2pCLDBDQUFjLEVBQUUsYUFBYTtBQUM3Qix5Q0FBYSxFQUFFLElBQUk7QUFDbkIsdUNBQVcsRUFBRSxDQUFDO0FBQ2QseUNBQWEsRUFBRSxDQUFDO0FBQ2hCLDhDQUFrQixFQUFFLElBQUk7QUFDeEIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQiwrQ0FBbUIsRUFBRSxxQkFBcUI7QUFDMUMsNkNBQWlCLEVBQUUscUJBQXFCO0FBQ3hDLG1DQUFPLEVBQUUsQ0FBQzsyQkFDWCxFQUFFO0FBQ0QsdUNBQVcsRUFBRSxPQUFPO0FBQ3BCLHVDQUFXLEVBQUUsT0FBTzsyQkFDckIsQ0FDRjs7O0FBdEJHLDhCQUFHOzs7Ozs7OztBQXdCUCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7Ozs7bUJBRW5CO2lCQUNGLEVBQ0Qsb0JBQU8sQ0FBQzs7OztBQUNOLDhCQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzs7Ozs7OztpQkFDakIsQ0FDQTs7O0FBNUpHLG1CQUFHO29EQThKQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBRUsscUJBQXFCLEVBQUMsNEJBQUMsT0FBTztNQUM5QixFQUFFLEVBQ0YsR0FBRzs7OztBQURILFVBQUUsR0FBRyxrQ0FBVSxPQUFPLENBQUM7O3dDQUNYLEVBQUUsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7OztBQUF0QyxXQUFHOzRDQUNBLEdBQUc7Ozs7Ozs7Q0FDWCxvQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0NDck44QiwwQkFBMEI7OzRCQUNyQyxlQUFlOztBQUVwQyxJQUFJLEdBQUcsR0FBRyxrQkFBa0I7O0FBRTVCLHFCQUFPLE9BQU8seURBRUYsR0FBRyxZQUFTLG9CQUFDLElBQUk7TUFBRSxLQUFLLHlEQUFHLEVBQUU7TUFBRSxVQUFVLHlEQUFHLEVBQUU7TUFDbEQsSUFBSSxFQUNKLEdBQUc7Ozs7O3dDQURVLGtDQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUM7OztBQUF2RCxZQUFJOzt3Q0FDUSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRTs7O0FBQWhFLFdBQUc7NENBQ0EsR0FBRzs7Ozs7OztDQUNYLG9DQUVTLEdBQUcsaUJBQWMsb0JBQUMsSUFBSTtNQUFFLEtBQUsseURBQUcsRUFBRTtNQUN0QyxJQUFJLEVBQ0osR0FBRzs7Ozs7d0NBRFUsa0NBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQzs7O0FBQXZELFlBQUk7O3dDQUNRLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxFQUFFOzs7QUFBM0MsV0FBRzs0Q0FDQSxHQUFHOzs7Ozs7O0NBQ1gsb0JBRUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7bUNDbkJ5Qiw2QkFBNkI7Ozs7NEJBQ25DLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLGFBQWE7O0FBRXZCLHFCQUFPLE9BQU8seURBT0YsR0FBRyxnQkFBYSxvQkFBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLEtBQUs7TUFBRSxNQUFNLHlEQUFHLElBQUk7TUFBRSxNQUFNLHlEQUFHLElBQUk7TUFDeEUsT0FBTyxFQUVQLFFBQVE7Ozs7QUFGUixlQUFPLEdBQUcsc0NBQW9COzt3Q0FDNUIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7Ozs7d0NBQ0gsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7OztBQUFsRSxnQkFBUTs0Q0FDTCxRQUFROzs7Ozs7O0NBQ2hCLG9DQUtTLEdBQUcsa0JBQWUsb0JBQUMsSUFBSSxFQUFFLEtBQUs7TUFBRSxNQUFNLHlEQUFHLElBQUk7TUFBRSxNQUFNLHlEQUFHLElBQUk7TUFDaEUsT0FBTzs7OztBQUFQLGVBQU8sR0FBRyxzQ0FBb0I7O3dDQUM1QixPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs7Ozt3Q0FDbEIsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQzs7Ozs7OztDQUNoRCxvQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3NCQzVCWSxRQUFROzs7OzRCQUNDLGVBQWU7O2lDQUNuQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7c0NBRzdCLDZCQUE2Qjs7Z0NBQ2xCLHVCQUF1Qjs7OzttQ0FDZCwwQkFBMEI7Ozs7QUFHckQsSUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDOztBQUVuQixxQkFBTyxPQUFPLHlEQUtGLEdBQUcsZ0JBQWEsb0JBQUMsTUFBTTtNQUV6QixNQUFNLEVBRU4sTUFBTSxFQUNOLGNBQWMsRUFHZCxRQUFRLEVBQ1IsR0FBRzs7Ozs7O0FBUEgsY0FBTSxHQUFHLG9DQUFZO0FBRXJCLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFFbkMsZ0JBQVEsR0FBRyxrQ0FBVSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ3BDLFdBQUcsR0FBRyxxQ0FBYSxRQUFRLENBQUM7O3dDQUU1QixNQUFNLENBQUMsS0FBSyxDQUNoQixXQUFXLEVBQ1g7Y0FDUSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDL0Isd0JBQU0sRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFPaEIsT0FBTzs7OzsrQkFKYixvQkFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDOzs7Ozs7OzBEQUlyQixHQUFHLENBQUMsY0FBYyxDQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FDakM7OztBQUhLLGlDQUFPOzs7QUFNYixnQ0FBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQzs7Ozs7Ozs7QUFHekIsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHLENBQUM7Ozs7Ozs7bUJBS3RCO2lCQUNGLENBQUM7OztBQXZCSSxtQkFBRztvREF5QkYsR0FBRzs7Ozs7OztTQUNYLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBRXhCLG9DQUtTLEdBQUcsbUJBQWdCLG9CQUFDLE1BQU07TUFFNUIsTUFBTSxFQUVOLE1BQU0sRUFDTixjQUFjLEVBR2QsUUFBUSxFQUNSLEdBQUc7Ozs7OztBQVBILGNBQU0sR0FBRyxvQ0FBWTtBQUVyQixjQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCxzQkFBYyxHQUFHLHNDQUFvQjs7d0NBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBRW5DLGdCQUFRLEdBQUcsa0NBQVUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNwQyxXQUFHLEdBQUcscUNBQWEsUUFBUSxDQUFDOzt3Q0FFNUIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsT0FBTyxFQUNQO2NBQ1EsR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDOztBQUUvQix3QkFBTSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPO3dCQUNwQixRQUFROzs7OzswREFBUyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUFsRCxrQ0FBUTs7MERBQ1IsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLENBQUM7Ozs7Ozs7bUJBQ3hFO2lCQUNGLENBQUM7OztBQU5JLG1CQUFHO29EQVFGLEdBQUc7Ozs7Ozs7U0FDWCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGlCQUFjLG9CQUFDLE1BQU07TUFDMUIsTUFBTSxFQUNOLFFBQVEsRUFDUixHQUFHLEVBRUgsY0FBYyxFQUlkLE1BQU07Ozs7OztBQVJOLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELGdCQUFRLEdBQUcsa0NBQVUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNwQyxXQUFHLEdBQUcscUNBQWEsUUFBUSxDQUFDO0FBRTVCLHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFHbkMsY0FBTSxHQUFHLG9DQUFZOzt3Q0FFckIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBQ1EsR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQy9CLHdCQUFNLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3BCLEdBQUcsRUFHRCxRQUFRLEVBRVIsU0FBUzs7OztBQUxYLDZCQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVU7OzswREFHTCxjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7OztBQUF6RSxrQ0FBUTs7MERBRVUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7OztBQUE3QyxtQ0FBUzs7MERBR1QsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUNmLCtCQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUc7MkJBQ2QsRUFBRTtBQUNELGdDQUFJLEVBQUU7QUFDSiwyREFBNkIsRUFBRSxTQUFTLENBQUMsR0FBRyxDQUFDLFVBQVU7QUFDdkQsaUVBQW1DLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0I7QUFDbkUsaUVBQW1DLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0I7NkJBQ3BFOzJCQUNGLENBQUM7Ozs7QUFFRixnQ0FBTSxDQUFDLFFBQVEsRUFBRSxDQUFDOzs7Ozs7OztBQUVsQixnQ0FBTSxDQUFDLE1BQU0sZ0JBQUcsQ0FBQzs7Ozs7OzttQkFFcEI7aUJBQ0YsRUFDRCxvQkFBTyxDQUFDOzs7OzhCQUNBLENBQUM7Ozs7Ozs7aUJBQ1IsQ0FBQzs7O0FBNUJJLG1CQUFHO29EQThCRixHQUFHOzs7Ozs7O1NBQ1gsQ0FDRjs7Ozt3Q0FFSyxNQUFNLENBQUMsS0FBSyxDQUNoQixnQkFBZ0IsRUFDaEI7Y0FDUSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDL0Isd0JBQU0sRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDcEIsR0FBRyxFQUdELFFBQVEsRUFNUixRQUFROzs7O0FBVFYsNkJBQUcsR0FBRyxPQUFPLENBQUMsVUFBVTs7OzBEQUdMLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQzs7O0FBQXpFLGtDQUFROzswREFFUixHQUFHLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDOzs7OzBEQUNoQyxHQUFHLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQzs7OzswREFDM0IsR0FBRyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQzs7OzswREFFYixjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUFsRCxrQ0FBUTs7MERBQ1IsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLENBQUM7Ozs7QUFFdkUsZ0NBQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQzs7Ozs7Ozs7QUFFbEIsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHLENBQUM7Ozs7Ozs7bUJBRXBCO2lCQUNGLEVBQ0Qsb0JBQU8sQ0FBQzs7Ozs4QkFDQSxDQUFDOzs7Ozs7O2lCQUNSLENBQUM7OztBQXRCSSxtQkFBRztvREF3QkYsR0FBRzs7Ozs7OztTQUNYLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9CQUVELENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQ3hMZ0Isd0JBQXdCOzs7O21DQUNoQiwwQkFBMEI7Ozs7NEJBQzlCLGVBQWU7O3VCQUNsQixVQUFVOzs7O3lCQUNaLFlBQVk7Ozs7bUJBQ2QsS0FBSzs7OztzQkFDZSxRQUFROztzQkFFMUIsUUFBUTs7OztxQ0FDTiw0QkFBNEI7Ozs7QUFFaEQsSUFBTSxHQUFHLEdBQUcsU0FBUzs7QUFFckIscUJBQU8sT0FBTyx5REFFRixHQUFHLG9CQUFpQixvQkFBQyxNQUFNO01BRS9CLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLG1CQUFtQixFQUNuQjtjQUNRLE9BQU8sRUFDUCxhQUFhLEVBQ2IsY0FBYyxFQWVkLEtBQUs7Ozs7QUFqQkwsdUJBQU8sR0FBTSxNQUFNLENBQUMsT0FBTyxTQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsT0FBTztBQUNuRCw2QkFBYSxHQUFNLE9BQU8sU0FBSSxNQUFNLENBQUMsS0FBSyxDQUFDLGFBQWE7QUFDeEQsOEJBQWMsR0FBTSxNQUFNLENBQUMsS0FBSyxDQUFDLGNBQWM7OztnREFJN0MscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7Z0RBRzdCLHFCQUFRLEtBQUssQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7Z0RBSXRCLHFCQUFRLEtBQUssQ0FBQyxhQUFhLENBQUM7Ozs7Ozs7Ozs7O0FBSTlCLHFCQUFLLEdBQUcsc0NBQW9COztnREFDNUIsS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7OztBQUdoQyxxQ0FBTyxTQUFTLENBQUMsYUFBRyxFQUFJO0FBQ3RCLHNCQUFNLElBQUksR0FBRyxtQ0FBUSxtQkFBbUIsRUFBRSxDQUN2QyxFQUFFLENBQUMsT0FBTyxFQUFFLGFBQUcsRUFBSTtBQUFFLHVCQUFHLENBQUMsR0FBRyxDQUFDO21CQUFFLENBQUM7O0FBRW5DLHNCQUFNLFNBQVMsR0FBRyxzQkFBYztBQUM5QixzQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLHNDQUFrQixFQUFFLElBQUk7QUFDeEIsNkJBQVMsRUFBRSxtQkFBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUUsRUFBRztBQUMzQix3QkFBRSxDQUFDLElBQUksRUFBRSxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7cUJBQ3pCO21CQUNGLENBQUMsQ0FBQzs7QUFFSCxzQkFBTSxLQUFLLEdBQUcscUJBQVEsaUJBQWlCLENBQUksYUFBYSxTQUFJLGNBQWMsQ0FBRyxDQUMxRSxFQUFFLENBQUMsT0FBTyxFQUFFLGFBQUcsRUFBSTtBQUFFLHVCQUFHLENBQUMsR0FBRyxDQUFDO21CQUFFLENBQUMsQ0FDaEMsRUFBRSxDQUFDLFFBQVEsRUFBRSxZQUFJO0FBQ2hCLHVCQUFHLEVBQUU7bUJBQ04sQ0FBQzs7QUFFSixzQkFBSSxDQUNELElBQUksQ0FBQyxTQUFTLENBQUMsQ0FDZixJQUFJLENBQUMsaUJBQUksU0FBUyxDQUFDLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDbkMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUM7aUJBQ2YsQ0FBQyxFQUFFOzs7Ozs7O1NBRUwsQ0FDRjs7OzRDQUVNLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBRVMsR0FBRyxvQkFBaUIsb0JBQUMsTUFBTTtNQUUvQixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixvQkFBb0IsRUFDcEI7Y0FDUSxPQUFPLEVBQ1AsYUFBYSxFQUNiLFFBQVEsRUFlUixLQUFLOzs7O0FBakJMLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU87QUFDbkQsNkJBQWEsR0FBTSxPQUFPLFNBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhO0FBQ3hELHdCQUFRLEdBQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxRQUFROzs7Z0RBSWpDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUc3QixxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUl0QixxQkFBUSxLQUFLLENBQUMsYUFBYSxDQUFDOzs7Ozs7Ozs7OztBQUk5QixxQkFBSyxHQUFHLHNDQUFvQjs7Z0RBQzVCLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7QUFHaEMscUNBQU8sU0FBUyxDQUFDLGFBQUcsRUFBSTtBQUN0QixzQkFBTSxJQUFJLEdBQUcscUJBQVEsZ0JBQWdCLENBQUksYUFBYSxTQUFJLFFBQVEsQ0FBRyxDQUNsRSxFQUFFLENBQUMsT0FBTyxFQUFFLGFBQUcsRUFBSTtBQUFFLHVCQUFHLENBQUMsR0FBRyxDQUFDO21CQUFFLENBQUM7QUFDbkMsc0JBQU0sS0FBSyxHQUFHLHFCQUFhO0FBQ3pCLDhCQUFVLEVBQUUsSUFBSTtBQUNoQix5QkFBSyxFQUFDLGVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUU7OztBQUNoQywrQ0FBTTs7Ozs7OzhEQUVJLG1DQUFRLFdBQVcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDOzs7QUFDdkMsb0NBQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQzs7Ozs7Ozs7QUFHbEIsc0NBQVEsZ0JBQUs7OztBQUVmLHNDQUFRLEVBQUU7Ozs7Ozs7dUJBQ1gsQ0FBQyxDQUFDLEdBQUcsRUFBRTtxQkFDVDtBQUNELHlCQUFLLEVBQUMsZUFBQyxRQUFRLEVBQUU7QUFDZiw4QkFBUSxFQUFFO0FBQ1YseUJBQUcsRUFBRTtxQkFDTjttQkFDRixDQUFDLENBQ0MsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHOzJCQUFJLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO21CQUFBLENBQUM7O0FBRXpDLHNCQUFJLENBQUMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNsQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyxpQkFBSSxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUNmLENBQUMsRUFBRTs7Ozs7OztTQUVMLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUVTLEdBQUcsaUJBQWMsb0JBQUMsTUFBTTtNQUU1QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixnQkFBZ0IsRUFDaEI7Y0FDUSxPQUFPLEVBQ1AsV0FBVyxFQUNYLFlBQVksRUFrQlosS0FBSyxFQUlMLElBQUk7Ozs7QUF4QkosdUJBQU8sR0FBTSxNQUFNLENBQUMsT0FBTyxTQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsT0FBTztBQUN2RCwyQkFBVyxHQUFNLE9BQU8sU0FBSSxNQUFNLENBQUMsU0FBUyxDQUFDLFdBQVc7QUFDeEQsNEJBQVksR0FBTSxPQUFPLFNBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxZQUFZOzs7Z0RBR3hELHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUc3QixxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUl0QixxQkFBUSxLQUFLLENBQUMsV0FBVyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUkxQixxQkFBUSxLQUFLLENBQUMsWUFBWSxDQUFDOzs7Ozs7Ozs7OztBQUk3QixxQkFBSyxHQUFHLHNDQUFvQjs7Z0RBQzVCLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBRzFCLG9CQUFJLEdBQUcsd0NBQWE7O0FBQzFCLHFDQUFPLFNBQVMsQ0FBQyxhQUFHLEVBQUk7QUFDdEIsc0JBQU0sSUFBSSxHQUFHLHFCQUFRLGdCQUFnQixDQUFJLFdBQVcsU0FBSSxNQUFNLENBQUMsU0FBUyxDQUFDLFFBQVEsVUFBTyxDQUNyRixFQUFFLENBQUMsT0FBTyxFQUFFLGFBQUcsRUFBSTtBQUFFLHVCQUFHLENBQUMsR0FBRyxDQUFDO21CQUFFLENBQUM7QUFDbkMsc0JBQU0sS0FBSyxHQUFHLHFCQUFhO0FBQ3pCLDhCQUFVLEVBQUUsSUFBSTtBQUNoQix5QkFBSyxFQUFDLGVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUU7QUFDaEMsMEJBQUksQ0FBQyxlQUFlLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQztBQUNsQyw4QkFBUSxFQUFFO3FCQUNYO0FBQ0QseUJBQUssRUFBQyxlQUFDLFFBQVEsRUFBRTtBQUNmLDhCQUFRLEVBQUU7QUFDVix5QkFBRyxFQUFFO3FCQUNOO21CQUNGLENBQUM7O0FBRUYsc0JBQUksQ0FBQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ2xDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLGlCQUFJLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUM7aUJBQ2YsQ0FBQyxFQUFFOzs7QUFHSixzQkFBTSxDQUFDLFNBQVMsQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLHFCQUFXLEVBQUk7QUFDakQsc0JBQUk7QUFDRix5Q0FBTyxTQUFTLENBQUMsYUFBRyxFQUFJO0FBQ3RCLDBCQUFNLElBQUksR0FBRyxxQkFBUSxnQkFBZ0IsQ0FBSSxXQUFXLFNBQUksV0FBVyxDQUFDLE9BQU8sVUFBTyxDQUMvRSxFQUFFLENBQUMsT0FBTyxFQUFFLFlBQU07QUFBRSwyQkFBRyxFQUFFO3VCQUFFLENBQUM7QUFDL0IsMEJBQU0sU0FBUyxHQUFHLHNCQUFjO0FBQzlCLDBDQUFrQixFQUFFLElBQUk7QUFDeEIsMENBQWtCLEVBQUUsSUFBSTtBQUN4QixpQ0FBUyxFQUFFLG1CQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFLO0FBQ3hDLDhCQUFJLE1BQU07QUFDViw4QkFBSTtBQUNGLHFEQUFNLFlBQU07QUFDVixvQ0FBTSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQztBQUNyRCxzQ0FBUSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7NkJBQ3ZCLENBQUMsQ0FBQyxHQUFHLEVBQUU7MkJBQ1QsQ0FBQyxPQUFPLEtBQUssRUFBRTtBQUNkLCtCQUFHLENBQUMsS0FBSyxDQUFDOzJCQUNYO3lCQUNGO3VCQUNGLENBQUM7QUFDRiwwQkFBTSxLQUFLLEdBQUcscUJBQVEsaUJBQWlCLENBQUksWUFBWSxTQUFJLFdBQVcsQ0FBQyxRQUFRLFVBQU8sQ0FDbkYsRUFBRSxDQUFDLFFBQVEsRUFBRSxZQUFNO0FBQ2xCLDhCQUFNLENBQUMsUUFBUSxFQUFFO0FBQ2pCLDJCQUFHLEVBQUU7dUJBQ04sQ0FBQyxDQUNELEVBQUUsQ0FBQyxPQUFPLEVBQUUsZUFBSyxFQUFJO0FBQUUsMkJBQUcsQ0FBQyxLQUFLLENBQUM7dUJBQUUsQ0FBQzs7QUFFdkMsMEJBQUksQ0FDRCxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLGlCQUFJLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxXQUFXLENBQUMsT0FBTyxLQUFLLElBQUksR0FBRyxJQUFJLEdBQUcsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUN0RSxJQUFJLENBQUMsU0FBUyxDQUFDLENBQ2YsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FBQyxFQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsT0FBTyxFQUFDLENBQUMsQ0FBQyxDQUNsRCxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLEtBQUssQ0FBQztxQkFDZixDQUFDLEVBQUU7bUJBQ0wsQ0FBQyxPQUFPLEtBQUssRUFBRTtBQUNkLDBCQUFNLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQzttQkFDckI7aUJBQ0YsQ0FBQzs7Ozs7OztTQUNILENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQU1TLEdBQUcsZ0JBQWEsb0JBQUMsTUFBTTtNQUUzQixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixtQkFBbUIsRUFDbkI7Y0FDUSxPQUFPLEVBU0wsY0FBYyxFQUdkLElBQUksRUFFSixRQUFROzs7O0FBZFYsdUJBQU8sR0FBTSxNQUFNLENBQUMsT0FBTyxTQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsT0FBTzs7O2dEQUdwRCxxQkFBUSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFHN0IscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7O0FBR3RCLDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFFbkMsb0JBQUksR0FBRyxjQUFjLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFDLEtBQUssRUFBRSxFQUFDLEdBQUcsRUFBRSxFQUFFLEVBQUMsRUFBQyxDQUFDLENBQUMsTUFBTSxFQUFFOztBQUU3RCx3QkFBUSxHQUFHLFNBQVgsUUFBUSxDQUFJLElBQUksRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFLO0FBQ3ZDLHNCQUFNLE9BQU8sR0FBRyxzQkFBYztBQUM1QixzQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLHNDQUFrQixFQUFFLElBQUk7QUFDeEIsNkJBQVMsRUFBQyxtQkFBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRTtBQUNwQywrQ0FBTSxZQUFNO0FBQ1YsNEJBQU0sSUFBSSxHQUFHLEVBQUUsQ0FBQyxLQUFLLENBQUM7QUFDdEIsZ0NBQVEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDO3VCQUNyQixDQUFDLENBQUMsR0FBRyxFQUFFO3FCQUNUO21CQUNGLENBQUM7QUFDRixzQkFBSSxLQUFLLEdBQUcsQ0FBQztBQUNiLHNCQUFNLFFBQVEsR0FBRyxzQkFBYztBQUM3Qiw0QkFBUSxFQUFFLE1BQU07QUFDaEIsNkJBQVMsRUFBRSxtQkFBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBSztBQUN4QywwQkFBSSxHQUFHLEdBQUcsS0FBSyxDQUFDLFFBQVEsRUFBRTtBQUMxQiwwQkFBSSxLQUFLLEtBQUssQ0FBQyxFQUFFO0FBQ2YsMkJBQUcsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLFFBQVEsRUFBRSxFQUFFLENBQUM7dUJBQ2hDO0FBQ0QsMkJBQUssRUFBRTtBQUNQLDhCQUFRLENBQUMsSUFBSSxFQUFFLEdBQUcsQ0FBQztxQkFDcEI7bUJBQ0YsQ0FBQztBQUNGLHNCQUFNLFFBQVEsR0FBRyxxQkFBUSxpQkFBaUIsQ0FBSSxRQUFRLFVBQU87QUFDN0QsMEJBQVEsQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFLFdBQUMsRUFBSTtBQUFFLDBCQUFNLHFCQUFPLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQzttQkFBRSxDQUFDOztBQUVuRSxzQkFBSSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsQ0FDZixJQUFJLENBQUMsaUJBQUksU0FBUyxDQUFDLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDbkMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUNkLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsUUFBUSxDQUFDO2lCQUNsQjs7QUFFRCx3QkFBUSxDQUNOLElBQUksRUFDSixpQ0FBZSxzQkFBc0IsRUFDbEMsT0FBTyxTQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsV0FBVyxDQUMxQzs7QUFFRCx3QkFBUSxDQUNOLElBQUksRUFDSixpQ0FBZSx3QkFBd0IsRUFDcEMsT0FBTyxTQUFJLE1BQU0sQ0FBQyxRQUFRLENBQUMsYUFBYSxDQUM1Qzs7O3NCQUdHLElBQUkscUJBQU8sS0FBSyxrQ0FBZ0MsT0FBTyxPQUFJOzs7Ozs7O1NBQ2xFLENBQ0Y7Ozs7Ozs7Q0FDRixvQkFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDNVRpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7Z0NBQ2xCLHVCQUF1Qjs7Ozs0QkFDcEIsZUFBZTs7QUFFcEMsSUFBSSxHQUFHLEdBQUcsTUFBTTs7QUFFaEIscUJBQU8sT0FBTyxxQkFLRixHQUFHLFlBQVMsb0JBQUMsTUFBTTtNQUV2QixNQUFNLEVBRU4sTUFBTSxFQUVKLFFBQVE7Ozs7OztBQUpWLGNBQU0sR0FBRyxvQ0FBWTtBQUVyQixjQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7d0NBRXZDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLG9CQUFPLENBQUM7Ozs7c0JBQzFDLENBQUM7Ozs7Ozs7U0FDUixDQUFDOzs7QUFGSSxnQkFBUTs7d0NBR1IsTUFBTSxDQUFDLEtBQUssQ0FDaEIsVUFBVSxFQUNWOzs7O29EQUNTLFFBQVE7Ozs7Ozs7U0FDaEIsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsRUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0NoQ2lCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOzttQ0FDVCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O3VCQUNoQixVQUFVOzs7OzhCQUVWLGlCQUFpQjs7OztzQ0FDaEIsNkJBQTZCOzs7O2dDQUM1Qix1QkFBdUI7Ozs7QUFFN0MsSUFBTSxHQUFHLEdBQUcsT0FBTzs7QUFFbkIscUJBQU8sT0FBTyx5REFLRixHQUFHLHVCQUFvQixvQkFBQyxNQUFNO01BRWxDLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGtCQUFrQixFQUNsQjtjQUdRLGNBQWMsRUFLaEIsR0FBRyxFQTRDSCxHQUFHOzs7Ozs7QUFqREQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBSXpCLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUM1QyxDQUNFO0FBQ0Usd0JBQU0sRUFBRTtBQUNOLHdCQUFJLEVBQUUsQ0FDSjtBQUNFLDJDQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtxQkFDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFrQkY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRSxzQkFBc0I7bUJBQzVCO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO21CQUNqQjtpQkFDRixDQUNGLENBQ0Y7OztBQXpDRyxtQkFBRztBQTRDSCxtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Z0RBQ3BELE1BQU0sQ0FBQyxlQUFlLENBQzFCLEdBQUcsRUFDSCxvQkFBTSxJQUFJO3NCQUdGLEdBQUc7Ozs7QUFGVCw4QkFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLFFBQVEsV0FBUSxDQUFDOzs7d0RBRTFCLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDOzs7QUFBaEMsMkJBQUc7NERBQ0EsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUM7Ozs7OzhCQUVuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBQyxFQUFFLDhCQUFVLEtBQUssZ0JBQUcsQ0FBQzs7Ozs7OztpQkFFL0QsQ0FDRjs7Ozs7OztTQUNGLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUtTLEdBQUcsaUNBQThCLG9CQUFDLE1BQU07TUFFNUMsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIscUJBQXFCLEVBQ3JCO2NBR1EsY0FBYyxFQUtoQixHQUFHLEVBNENILEdBQUc7Ozs7OztBQWpERCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFJekIsY0FBYyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQzVDLENBQ0U7QUFDRSx3QkFBTSxFQUFFO0FBQ04sd0JBQUksRUFBRSxDQUNKO0FBQ0UsMkNBQXFCLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFO3FCQUN0Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQWtCRjttQkFDRjtpQkFDRixFQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFLHNCQUFzQjttQkFDNUI7aUJBQ0YsRUFDRDtBQUNFLDBCQUFRLEVBQUU7QUFDUix1QkFBRyxFQUFFLENBQUM7QUFDTiw0QkFBUSxFQUFFLE1BQU07bUJBQ2pCO2lCQUNGLENBQ0YsQ0FDRjs7O0FBekNHLG1CQUFHO0FBNENILG1CQUFHLEdBQUcsd0NBQWEsTUFBTSxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDOztnREFDcEQsTUFBTSxDQUFDLGVBQWUsQ0FDMUIsR0FBRyxFQUNILG9CQUFNLElBQUk7c0JBR0YsR0FBRzs7Ozt5Q0FGVCxNQUFNO3lDQUFRLElBQUk7O3dEQUFRLGNBQWMsQ0FBQyxvQ0FBb0MsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDOzs7O3VDQUFyRixNQUFNOzs7d0RBRUssR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7OztBQUFoQywyQkFBRzs0REFDQSxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBQzs7Ozs7OEJBRW5DLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFDLEVBQUUsOEJBQVUsS0FBSyxnQkFBRyxDQUFDOzs7Ozs7O2lCQUUvRCxDQUNGOzs7Ozs7O1NBQ0YsQ0FDRjs7OzRDQUVNLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBS1MsR0FBRyx1QkFBb0Isb0JBQUMsTUFBTTtNQUVsQyxNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQiwwQkFBMEIsRUFDMUI7Y0FHUSxjQUFjLEVBS2hCLEdBQUcsRUF5Q0gsR0FBRzs7Ozs7O0FBOUNELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUl6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7cUJBZUY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRSxzQkFBc0I7bUJBQzVCO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO21CQUNqQjtpQkFDRixDQUNGLENBQ0Y7OztBQXRDRyxtQkFBRztBQXlDSCxtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Z0RBQ3BELE1BQU0sQ0FBQyxlQUFlLENBQzFCLEdBQUcsRUFDSCxvQkFBTSxJQUFJO3NCQUlGLEdBQUc7Ozs7QUFIVCw0QkFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDO0FBQ25CLDRCQUFJLENBQUMsYUFBYSxHQUFHLE1BQU07Ozt3REFFVCxHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQzs7O0FBQWhDLDJCQUFHOzREQUNBLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFDOzs7Ozs4QkFFbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUMsRUFBRSw4QkFBVSxLQUFLLGdCQUFHLENBQUM7Ozs7Ozs7aUJBRS9ELENBQ0Y7Ozs7Ozs7U0FDRixDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLG1CQUFnQixvQkFBQyxNQUFNO01BRTlCLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGFBQWEsRUFDYjtjQUdRLGNBQWMsRUFHaEIsR0FBRyxFQWtFRCxJQUFJLGtGQUdDLENBQUMsRUFPTixHQUFHLEVBRUQsR0FBRzs7Ozs7QUFqRkwsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBRXpCLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUM1QyxDQUNFO0FBQ0Usd0JBQU0sRUFBRTtBQUNOLHdCQUFJLEVBQUUsQ0FDSjtBQUNFLDJDQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtxQkFDdEM7Ozs7Ozs7Ozs7Ozs7OztxQkFlRjttQkFDRjtpQkFDRixFQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFO0FBQ0gsOEJBQVEsRUFBRSxzQkFBc0I7QUFDaEMsZ0RBQTBCLEVBQUUseUJBQXlCO0FBQ3JELDhDQUF3QixFQUFFLHlCQUF5QjtxQkFDcEQ7QUFDRCx3QkFBSSxFQUFFO0FBQ0osNEJBQU0sRUFBRSxNQUFNO3FCQUNmO21CQUNGO2lCQUNGLEVBQ0Q7O0FBRUUsd0JBQU0sRUFBRTtBQUNOLHVCQUFHLEVBQUUsZUFBZTtBQUNwQiw4QkFBVSxFQUFFO0FBQ1YsMkJBQUssRUFBRTtBQUNMLDJCQUFHLEVBQUUsT0FBTztBQUNaLGtEQUEwQixFQUFFLGlDQUFpQztBQUM3RCxnREFBd0IsRUFBRSwrQkFBK0I7dUJBQzFEO3FCQUNGO21CQUNGO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO0FBQ2hCLDhCQUFVLEVBQUUsYUFBYTttQkFDMUI7aUJBQ0YsQ0FDRixDQUNGOzs7QUEzREcsbUJBQUc7Ozs7Z0RBaUVNLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7OztnREFDUCxHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdkIsb0JBQUk7Ozs7OzRCQUdNLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUFwQixpQkFBQzs7Z0RBQ1EsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDOzs7QUFBOUMsaUJBQUMsQ0FBQyxLQUFLOztBQUNQLHVCQUFPLENBQUMsQ0FBQyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLVixtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7O2dEQUV4QyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7OztBQUFuQyxtQkFBRzs7QUFDUCxzQkFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7O0FBRXBCLHNCQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OztBQUdwQixtQkFBRyxDQUFDLEtBQUssRUFBRTs7Ozs7OztTQUNaLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUtTLEdBQUcsa0JBQWUsb0JBQUMsTUFBTTtNQUU3QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixlQUFlLEVBQ2Y7Y0FJUSxNQUFNLEVBQ04sY0FBYyxFQVNkLE9BQU8sRUFTVCxHQUFHOzs7Ozs7QUFuQkQsc0JBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7OztnREFJakMscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7O0FBSS9CLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sZUFBVyxJQUFJLElBQUksRUFBRSxDQUFFLE9BQU8sRUFBRTs7O2dEQUd6RCxxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7Z0RBTWQsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7QUFFN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDeEIsT0FBTyxFQUlQLEtBQUssRUFDTCxRQUFROzs7O0FBTFIsaUNBQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDOztBQUN6RCxpQ0FBTyxDQUFDLEdBQUcsR0FBTSxPQUFPLENBQUMsR0FBRyxvQkFBaUI7QUFDN0MsaUNBQU8sQ0FBQyxFQUFFLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVE7OzswREFFNUIsaUNBQVEsT0FBTyxDQUFDOzs7QUFBOUIsK0JBQUs7QUFDTCxrQ0FBUSxHQUFNLE9BQU8sU0FBSSxJQUFJLENBQUMsS0FBSzs7MERBRWpDLHFCQUFRLFNBQVMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDOzs7Ozs7O21CQUN6QyxFQUFDLENBQUM7OztBQVhELG1CQUFHO29EQWFBLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQkFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDMVppQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7bUNBQ1QsMEJBQTBCOzs7OzRCQUVoQyxlQUFlOztBQUVwQyxJQUFNLEdBQUcsR0FBRyxVQUFVOztBQUV0QixxQkFBTyxPQUFPLHFCQUtGLEdBQUcsZUFBWSxvQkFBQyxNQUFNO01BRTFCLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGVBQWUsRUFDZjtjQUlRLE1BQU0sRUFDTixjQUFjLEVBa0JoQixHQUFHOzs7Ozs7QUFuQkQsc0JBQU0sR0FBRywrQ0FBdUIsTUFBTSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ2hFLDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQWlCekIsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7QUFFN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzs7OztBQUM1QixnQ0FBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7Ozs7Ozs7bUJBQ3RCLEVBQUMsQ0FBQzs7O0FBSkQsbUJBQUc7b0RBTUEsR0FBRzs7Ozs7OztTQUNYLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLEVBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDeERpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7bUNBQ1QsMEJBQTBCOzs7OzRCQUVoQyxlQUFlOztpQ0FDakIsd0JBQXdCOzs7O3VCQUN2QixVQUFVOzs7O3lCQUVaLFlBQVk7Ozs7d0JBQ1QsVUFBVTs7OzttQkFDZixLQUFLOzs7O3NCQUNrQixRQUFROztBQUUvQyxJQUFNLE1BQU0sR0FBRyxRQUFRO0FBQ3ZCLElBQU0sR0FBRyxHQUFHLE9BQU87O0FBRW5CLHFCQUFPLE9BQU8seURBS0YsR0FBRyxhQUFVLG9CQUFDLE1BQU07TUFFeEIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsUUFBUSxFQUNSO2NBQ1EsY0FBYyxFQUVkLE9BQU8sRUFDUCxDQUFDLEVBQ0QsQ0FBQzs7Ozs7O0FBSkQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUNuQyx1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPO0FBQzNCLGlCQUFDLEdBQUcscUJBQVEsZ0JBQWdCLENBQUksT0FBTyxTQUFJLE1BQU0sQ0FBQyxhQUFhLENBQUc7QUFDbEUsaUJBQUMsR0FBRyxxQkFBUSxpQkFBaUIsQ0FBSSxPQUFPLFNBQUksTUFBTSxDQUFDLGFBQWEsQ0FBRzs7QUFDekUsaUJBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQy9CLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLGlCQUFJLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxpQkFBSSxTQUFTLENBQ2pCLG9CQUFPLE1BQU0sRUFBRSxRQUFRO3NCQUNqQixHQUFHOzs7O0FBQUgsMkJBQUcsR0FBRyxJQUFJOzs7d0RBR1csY0FBYyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7OztBQUFuRSw4QkFBTSxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7QUFFZCwyQkFBRyxpQkFBSTs7O0FBRVQsZ0NBQVEsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDOzs7Ozs7O2lCQUN0QixDQUNGLENBQUMsQ0FDRCxJQUFJLENBQUMsaUJBQUksU0FBUyxDQUFDLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDbkMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7U0FDWCxDQUNGOzs7Ozs7O0NBQ0Ysb0NBS1MsR0FBRyxlQUFZLG9CQUFDLE1BQU07TUFFMUIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsUUFBUSxFQUNSO2NBSVEsTUFBTSxFQUNOLGNBQWMsRUFJZCxNQUFNLEVBUU4sT0FBTyxFQUtQLFNBQVMsRUFJWCxFQUFFLEVBQ0YsUUFBUSxFQUNSLElBQUksRUFHSixNQUFNLEVBQ04sTUFBTSxFQTZDTixHQUFHOzs7Ozs7QUF6RUQsc0JBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFHbkMsc0JBQU0sR0FBRyxtQ0FBVyxNQUFNLENBQUMsVUFBVSxDQUFDOzs7Z0RBSXBDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7OztBQUkvQix1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPOztnREFDM0IscUJBQVEsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFDdkIscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7O0FBR3RCLHlCQUFTLEdBQU0sTUFBTSxDQUFDLE9BQU87O2dEQUM3QixxQkFBUSxNQUFNLENBQUMsU0FBUyxDQUFDOzs7O2dEQUN6QixxQkFBUSxLQUFLLENBQUMsU0FBUyxDQUFDOzs7QUFFMUIsa0JBQUUsR0FBRyxJQUFJO0FBQ1Qsd0JBQVEsR0FBRyxJQUFJO0FBQ2Ysb0JBQUksR0FBRyxJQUFJO0FBR1gsc0JBQU0sR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFdBQVcsRUFBRSxvQkFBb0IsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsZ0JBQWdCLENBQUM7QUFDOXBDLHNCQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFDOytCQUFRLENBQUM7aUJBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJOzs7QUFHdkQsc0JBQU0sQ0FBQyxhQUFhLEdBQUcsb0JBQU8sV0FBVzs7OztBQUN2Qyw0QkFBSSxHQUFHLE1BQU0sR0FBRyxDQUFDLE9BQU8sR0FBRyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELDBCQUFFLEdBQU0sT0FBTyxTQUFJLElBQU07QUFDekIsZ0NBQVEsR0FBTSxFQUFFLFNBQUksTUFBTSxDQUFDLFdBQWE7O3dEQUNsQyxxQkFBUSxLQUFLLENBQUMsRUFBRSxDQUFDOzs7O3dEQUVqQixxQkFBUSxVQUFVLENBQUMsUUFBUSxFQUFFLHVCQUFNLE1BQU0sQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7Ozs7Ozs7aUJBQ3RFOzs7QUFHRCxzQkFBTSxDQUFDLFFBQVEsR0FBRyxvQkFBTyxHQUFHO3NCQUN0QixLQUFLLEVBQ0wsSUFBSSxFQUVKLE1BQU0sa0ZBR0QsR0FBRyxFQUNOLE1BQU0sRUFDTixNQUFNOzs7OztBQVJSLDZCQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUs7QUFDakIsNEJBQUksR0FBRyxHQUFHLENBQUMsSUFBSTtBQUVmLDhCQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFDLEVBQUk7QUFBRSxpQ0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFNLElBQUk7eUJBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJOzt3REFDckYscUJBQVEsVUFBVSxDQUFDLFFBQVEsRUFBRSx1QkFBTSxNQUFNLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDOzs7Ozs7O29DQUVyRCxJQUFJLENBQUMsTUFBTTs7Ozs7Ozs7QUFBbEIsMkJBQUc7QUFDTiw4QkFBTSxHQUFNLE1BQU0sQ0FBQyxRQUFRLFNBQUksR0FBRztBQUNsQyw4QkFBTSxHQUFNLEVBQUUsU0FBSSxHQUFHOzs7d0RBR2pCLHFCQUFRLE1BQU0sQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7Ozs7d0RBRXRCLHFCQUFRLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lCQUczQzs7O0FBR0Qsc0JBQU0sQ0FBQyxXQUFXLEdBQUcsb0JBQU8sV0FBVztzQkFDL0IsR0FBRyxFQUNILE9BQU8sRUFDUCxNQUFNOzs7O0FBRk4sMkJBQUcsR0FBRywyQkFBUyxLQUFLLENBQUM7QUFDckIsK0JBQU8sR0FBTSxTQUFTLFNBQUksSUFBSTtBQUM5Qiw4QkFBTSxHQUFHLHFCQUFRLGlCQUFpQixDQUFDLE9BQU8sQ0FBQzs7QUFDakQsMkJBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ2hCLDJCQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUM7QUFDeEIsMkJBQUcsQ0FBQyxRQUFRLEVBQUU7Ozs7Ozs7aUJBQ2Y7Ozs7OztnREFLZSxNQUFNLENBQUMsT0FBTyxDQUFDOztBQUU3QiwwQkFBUSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPO3dCQUN4QixRQUFRLEVBR04sS0FBSzs7Ozs7MERBSFUsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOzs7QUFBbEQsa0NBQVE7O2dDQUVSLFFBQVEsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXOzs7Ozs7MERBQ3ZCLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLFdBQVEsRUFBRSxJQUFJLENBQUM7OztBQUFuRSwrQkFBSzs7MERBQ0gsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBQyxDQUFDOzs7Ozs7O21CQUVsRCxFQUFDLENBQUM7OztBQVRELG1CQUFHOztBQVdQLHNCQUFNLENBQUMsS0FBSyxFQUFFOztvREFFUCxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0JBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7UUNuS0ssd0JBQXdCOztRQUN4QixzQkFBc0IsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkNDdEIsY0FBYzs7eUJBQ0gsZUFBZTs7Ozs0QkFHMUIsZUFBZTs7OztvQkFHTCxNQUFNOzs7OzJCQUNILGFBQWE7Ozs7c0JBQ1AsVUFBVTs7QUFFcEMsSUFBTSxPQUFPLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsU0FBUyxFQUFFO0FBQzlDLGNBQVksRUFBRSxPQUFPO0NBQ3RCLENBQUMsQ0FBQzs7SUFFVSxNQUFNO1lBQU4sTUFBTTs7QUFFTixXQUZBLE1BQU0sQ0FFTCxRQUFRLEVBQUU7OzswQkFGWCxNQUFNOztBQUlmLFFBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDNUIsU0FBRyxFQUFFLFFBQVE7S0FDZCxDQUFDLENBQUM7O0FBRUgsK0JBUlMsTUFBTSw2Q0FRVCxPQUFPLEVBQUU7O0FBRWYsUUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDOztBQUUxQixZQUFRLElBQUksQ0FBQyxJQUFJOztBQUVmLFdBQUssT0FBTztBQUNWLFlBQUksQ0FBQyxLQUFLLEdBQUcsMkJBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xDLFlBQUksVUFBTyxHQUFHO2NBQVEsUUFBUSx5REFBRyxVQUFDLE1BQU0sRUFBRyxFQUFFO2NBQUUsT0FBTyx5REFBRyxVQUFDLENBQUMsRUFBRyxFQUFFO2NBQzFELEdBQUc7Ozs7QUFBSCxtQkFBRyxzQkFBb0IsSUFBSSxDQUFDLEtBQUs7O2dEQUN4QixJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQzs7Ozs7Ozs7OztTQUMvRCxDQUFDO0FBQ0YsY0FBTTs7QUFFUjtBQUNFLGNBQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQzs7QUFBQSxLQUU1QztHQUNGOzs7Ozs7O2VBMUJVLE1BQU07O1dBZ0NKOzs7VUFBQyxTQUFTLHlEQUFHLEVBQUU7VUFBRSxPQUFPLHlEQUFHLG9CQUFPLENBQUM7Ozs7Ozs7O09BQU87O1VBRWpELE9BQU8sRUFRUCxLQUFLLGtGQUNBLE1BQU07Ozs7Ozs7QUFUWCxtQkFBTyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUU7OztBQUcvQixtQkFBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDbkIsa0JBQUksRUFBRSxNQUFNO0FBQ1osbUJBQUssRUFBRSxFQUFFO2FBQ1YsQ0FBQzs7QUFFRSxpQkFBSyxHQUFHLEVBQUU7Ozs7OztBQUNkLDZCQUFtQixPQUFPLENBQUMsT0FBTyx1SEFBRTtBQUEzQixvQkFBTTs7QUFDYixtQkFBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRztBQUNuQixxQkFBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLHFCQUFLLEVBQUUsQ0FBQztlQUNULENBQUM7YUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFSyxJQUFJLFVBQU8sQ0FDZixvQkFBTyxNQUFNO3VHQUNGLE1BQU0sRUFDVCxLQUFLLEVBQ0wsSUFBSTs7Ozs7Ozs7O2lDQUZTLE9BQU8sQ0FBQyxPQUFPOzs7Ozs7OztBQUF6QiwwQkFBTTtBQUNULHlCQUFLLEdBQUcseUJBQVEsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDdEMsd0JBQUksR0FBRyx1QkFBTSxLQUFLLENBQUU7O3lCQUNwQixJQUFJLENBQUMsTUFBTSxDQUFDOzs7OztBQUNkLHlCQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDOzswQkFDdkIsT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLFdBQVc7Ozs7OztvREFDekMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7YUFLM0MsRUFDRCxPQUFPLENBQ1I7OztnREFHTSxLQUFLOzs7Ozs7O0tBRWI7OztTQXRFVSxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MkJDZlosY0FBYzs7eUJBQ0gsZUFBZTs7Ozs0QkFHMUIsZUFBZTs7QUFFdEIsSUFBTSxNQUFNLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsUUFBUSxFQUFFO0FBQzVDLGNBQVksRUFBRSxPQUFPO0NBQ3RCLENBQUMsQ0FBQzs7SUFFVSxTQUFTO0FBSVQsV0FKQSxTQUFTLENBSVIsT0FBTyxFQUFFOzBCQUpWLFNBQVM7O0FBS2xCLFFBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0dBQ3hCOzs7Ozs7OztlQU5VLFNBQVM7O1dBYWIsbUJBQUc7QUFDUixhQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO0tBQ2xDOzs7V0FFUyxzQkFBRztBQUNYLGFBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztLQUNyQjs7O1dBRU0sbUJBQTZEOzs7VUFBNUQsUUFBUSx5REFBRyxvQkFBTyxNQUFNOzs7Ozs7OztPQUFPO1VBQUUsT0FBTyx5REFBRyxvQkFBTyxDQUFDOzs7Ozs7OztPQUFPO0tBQUk7OztTQXJCM0QsU0FBUzs7Ozs7SUF5QlQsS0FBSztZQUFMLEtBQUs7O0FBRUwsV0FGQSxLQUFLLENBRUosT0FBTyxFQUFFOzs7MEJBRlYsS0FBSzs7QUFJZCxRQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzNCLFNBQUcsRUFBRSxPQUFPO0tBQ2IsQ0FBQyxDQUFDOztBQUVILCtCQVJTLEtBQUssNkNBUVIsT0FBTyxFQUFFOztBQUVmLFFBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs7QUFFMUIsWUFBUSxJQUFJLENBQUMsSUFBSTtBQUNmLFdBQUssT0FBTztBQUNWLFlBQUksQ0FBQyxLQUFLLEdBQUcsMkJBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xDLFlBQUksVUFBTyxHQUFHLG9CQUFPLEdBQUc7Y0FDbEIsR0FBRzs7OztBQUFILG1CQUFHLHNCQUFvQixJQUFJLENBQUMsS0FBSyxnQkFBWSxHQUFHLENBQUMsR0FBRyxhQUFTLEdBQUcsQ0FBQyxFQUFFOztnREFDMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7Ozs7Ozs7O1NBQ25DLENBQUM7QUFDRixjQUFNO0FBQ1I7QUFDRSxjQUFNLElBQUksS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFBQSxLQUN6QztHQUVGOzs7Ozs7O2VBeEJVLEtBQUs7O1dBK0JULG1CQUE2RDs7O1VBQTVELFFBQVEseURBQUcsb0JBQU8sTUFBTTs7Ozs7Ozs7T0FBTztVQUFFLE9BQU8seURBQUcsb0JBQU8sQ0FBQzs7Ozs7Ozs7T0FBTzs7QUFFaEUsVUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztBQUNwQixlQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHO09BQzFCLEVBQUU7QUFDRCxjQUFNLEVBQUU7QUFDTixhQUFHLEVBQUUsQ0FBQztBQUNOLFlBQUUsRUFBRSxDQUFDO0FBQ0wsYUFBRyxFQUFFLENBQUM7U0FDUDtPQUNGLENBQUMsQ0FBQzs7QUFFSCxhQUFPLElBQUksT0FBTyxDQUNoQixVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUs7O0FBRW5CLFdBQUcsQ0FBQyxPQUFPLENBQ1Qsb0JBQU8sR0FBRyxFQUFFLEtBQUs7Y0FFVCxNQUFNOzs7Ozs7Z0RBQVMsSUFBSSxVQUFPLENBQUMsR0FBRyxDQUFDOzs7QUFBL0Isc0JBQU07O2dEQUNKLFFBQVEsQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7Ozs7QUFFdEIsdUJBQU8sZ0JBQUcsQ0FBQzs7O0FBRWIsb0JBQUksS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDN0IseUJBQU8sRUFBRSxDQUFDO2lCQUNYOzs7Ozs7O1NBQ0YsQ0FBQyxDQUFDO09BRU4sQ0FDRixTQUFNLENBQ0wsVUFBQyxDQUFDLEVBQUs7QUFDTCxjQUFNLENBQUMsQ0FBQztPQUNULENBQ0YsQ0FBQztLQUVIOzs7U0FsRVUsS0FBSztHQUFTLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQ3JDbEIsZUFBZTs7Ozs4QkFDVixvQkFBb0I7Ozs7SUFFOUIsUUFBUTs7Ozs7O0FBS1IsV0FMQSxRQUFRLENBS1AsS0FBSyxFQUFFOzBCQUxSLFFBQVE7O0FBTWpCLFFBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO0dBQ3BCOztlQVBVLFFBQVE7O1dBU0Msd0JBQUMsU0FBUyxFQUFFLGVBQWU7VUFDdkMsYUFBYSxFQUdiLE1BQU0sRUFTTixHQUFHLEVBT0gsTUFBTSxFQU9OLE9BQU87Ozs7OztBQTFCUCx5QkFBYSxHQUFHLHNCQUFzQjtBQUd0QyxrQkFBTSxHQUFHLEVBQUU7O0FBQ2pCLDJCQUFlLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFLO0FBQ2hDLG9CQUFNLENBQUMsSUFBSSxDQUFDO0FBQ1YsMEJBQVUsRUFBRSxTQUFTO0FBQ3JCLDJCQUFXLEVBQUUsSUFBSTtlQUNsQixDQUFDLENBQUM7YUFDSixDQUFDLENBQUM7OztBQUdHLGVBQUcsdURBRUYsYUFBYSxpQ0FDQyxTQUFTOzs0Q0FJVCxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDekMsYUFBYSxvQkFDRyxTQUFTLEVBQ3pCLHlCQUF5QixDQUMxQjs7O0FBSkssa0JBQU07QUFPTixtQkFBTyxHQUFHLEVBQUU7OzRDQUVaLGlDQUNKLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUNwQixvQkFBTyxFQUFFLEVBQUUsTUFBTTtrQkFDVCxHQUFHOzs7OztvREFBUyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDdEMsYUFBYSxFQUNiLEVBQUUsRUFDRixNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUNuQzs7O0FBSkssdUJBQUc7O0FBS1QsMkJBQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Ozs7Ozs7YUFDbkIsRUFDRCxvQkFBTyxFQUFFLEVBQUUsTUFBTTtrQkFDVCxHQUFHOzs7OztvREFBUyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssOEJBRWxCLGFBQWEsdUNBQ04sTUFBTSxDQUFDLFVBQVUsd0NBQ2hCLE1BQU0sQ0FBQyxXQUFXLGtCQUV6Qzs7O0FBTkssdUJBQUc7O0FBT1QsMkJBQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Ozs7Ozs7YUFDbkIsQ0FDRjs7O2dEQUVNLE9BQU87Ozs7Ozs7S0FDZjs7O1dBRWdCLHFCQUFDLGNBQWM7VUFBRSxRQUFRLHlEQUFHLENBQUM7Ozs7OzRDQUN0QyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDMUIsbUJBQW1CLDBCQUNHLGNBQWMsRUFDcEMsRUFBRSxFQUFFO0FBQ0YsbUJBQUssRUFBRSxRQUFRO0FBQ2YsNkJBQWUsRUFBRSxDQUFDO0FBQ2xCLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7OzRDQUVLLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUMxQixtQkFBbUIsMEJBQ0csY0FBYyxFQUNwQyxFQUFFLEVBQUU7QUFDRixtQkFBSyxFQUFFLFFBQVE7QUFDZix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs7OztLQUNGOzs7V0FFcUIsMEJBQUMsSUFBSTtVQUNuQixTQUFTLEVBRVQsR0FBRyxFQUdILE1BQU0sRUFTTixLQUFLLGtGQXVCQSxNQUFNOzs7Ozs7O0FBckNYLHFCQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVU7QUFFM0IsZUFBRyxHQUFHLEVBQUU7O0FBR1Isa0JBQU0sR0FBRyxTQUFULE1BQU0sQ0FBVSxHQUFHO2tCQUNqQixHQUFHOzs7O0FBQUgsdUJBQUcsdUVBRVksSUFBSSxDQUFDLFVBQVUsbUJBQWMsR0FBRztxQ0FFckQsR0FBRzs7b0RBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7O21DQUFoQyxJQUFJOzs7Ozs7O2FBQ1Q7O0FBR0ssaUJBQUssR0FBRyxTQUFSLEtBQUssQ0FBVSxHQUFHO2tCQUVoQixHQUFHLEVBSUgsUUFBUTs7OztBQUpSLHVCQUFHLGdGQUVZLElBQUksQ0FBQyxVQUFVLG1CQUFjLEdBQUc7O29EQUU5QixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUF0Qyw0QkFBUTs7eUJBQ1YsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQzs7Ozs7Ozs7cUNBRTNCLEdBQUc7O29EQUNLLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUMxQixpQkFBaUIsRUFDakIsRUFBRSxFQUNGO0FBQ0UsZ0NBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtBQUMzQix5QkFBRyxFQUFILEdBQUc7QUFDSCxnQ0FBVSxFQUFFLFNBQVM7QUFDckIsaUNBQVcsRUFBRSxPQUFPO3FCQUNyQixDQUNGOzs7O21DQVZDLElBQUk7Ozs7Ozs7YUFZVDs7Ozs7O3dCQUVvQixJQUFJLENBQUMsSUFBSTs7Ozs7Ozs7QUFBbkIsa0JBQU07NkJBQ1AsTUFBTSxDQUFDLEdBQUc7a0RBQ1gsSUFBSSwyQkFHSixLQUFLOzs7Ozs0Q0FGRixLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs0Q0FHakIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnREFLdkI7QUFDTCxpQkFBRyxFQUFILEdBQUc7YUFDSjs7Ozs7OztLQUNGOzs7V0FFdUIsNEJBQUMsSUFBSTtVQUNyQixTQUFTLEVBQ1QsTUFBTSxFQUNOLFNBQVMsRUFFVCxHQUFHLEVBR0gsR0FBRyxFQUdBLENBQUM7Ozs7QUFWSixxQkFBUyxHQUFHLElBQUksQ0FBQyxVQUFVO0FBQzNCLGtCQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU07QUFDcEIscUJBQVMsR0FBRyxJQUFJLENBQUMsVUFBVTtBQUUzQixlQUFHLEdBQUcsRUFBRTtBQUdSLGVBQUcseURBQXVELFNBQVM7NkJBQ3pFLEdBQUc7OzRDQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7OzsyQkFBaEMsSUFBSTtBQUVDLGFBQUMsR0FBRyxDQUFDOzs7a0JBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNOzs7Ozs7NENBQ3pCLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUMxQixtQkFBbUIsRUFBRTtBQUNuQix3QkFBVSxFQUFFLFNBQVM7QUFDckIsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHVCQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQixrQkFBSSxFQUFFLENBQUMsR0FBRyxDQUFDO2FBQ1osRUFBRTtBQUNELHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFWZ0MsYUFBQyxFQUFFOzs7OztnREFhL0I7QUFDTCxpQkFBRyxFQUFILEdBQUc7YUFDSjs7Ozs7OztLQUNGOzs7V0FFa0IsdUJBQUMsSUFBSTtVQUNsQixVQUFVLEVBQ1YsSUFBSSx1RkFzREcsQ0FBQyx1RkFHTixHQUFHOzs7OztBQTFETCxzQkFBVSxHQUFHLEVBQUU7QUFDZixnQkFBSSxHQUFHLEVBQUU7Ozs7QUFJYixnQkFBSSxHQUFHLENBQ0wsUUFBUSxFQUNSLE1BQU0sRUFDTixNQUFNLEVBQ04sa0JBQWtCLEVBQ2xCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2IsV0FBVyxDQUNaLENBQUM7Ozs7O0FBQ0YsOEJBQWdCLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNWLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNYLDBCQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2VBQ3pCO2FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQWtCSyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDMUIsYUFBYSxvQkFDRyxJQUFJLENBQUMsVUFBVSxFQUMvQixVQUFVLEVBQUU7QUFDVix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs7O0FBSUQsc0JBQVUsR0FBRyxFQUFFLENBQUM7QUFDaEIsZ0JBQUksR0FBRyxDQUNMLGtCQUFrQixFQUNsQixjQUFjLEVBQ2QsWUFBWSxFQUNaLFNBQVMsRUFDVCxTQUFTLEVBQ1QsY0FBYyxDQUNmLENBQUM7Ozs7O0FBQ0YsOEJBQWdCLElBQUksMkhBQUU7QUFBWCxlQUFDO0FBQVksa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FHN0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ3RDLG1CQUFtQixvQkFDSCxJQUFJLENBQUMsVUFBVSxFQUMvQixVQUFVLEVBQUU7QUFDVix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBTkssZUFBRztnREFRRjtBQUNMLGlCQUFHLEVBQUgsR0FBRzthQUNKOzs7Ozs7O0tBQ0Y7OztXQUVrQix1QkFBQyxJQUFJO1VBQ2hCLFNBQVMsRUFFVCxHQUFHLEVBRUwsVUFBVSxFQUNWLElBQUksdUZBNkRHLENBQUM7Ozs7O0FBbEVOLHFCQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVU7QUFFM0IsZUFBRyxHQUFHLEVBQUU7QUFFVixzQkFBVSxHQUFHLEVBQUU7QUFDZixnQkFBSSxHQUFHLEVBQUU7O0FBRWIsZ0JBQUksR0FBRyxDQUNMLE1BQU0sRUFDTixvQkFBb0IsQ0FDckIsQ0FBQzs7Ozs7Ozs7OztBQU1GLDhCQUFnQixJQUFJLDJIQUFFO0FBQVgsZUFBQztBQUFZLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBR3hDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUMzQyxhQUFhLEVBQ2IsVUFBVSxFQUFFO0FBQ1Ysd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLG9CQUFNLEVBQUUsQ0FBQztBQUNULGtCQUFJLEVBQUUsTUFBTTtBQUNaLDhCQUFnQixFQUFFLE1BQU07QUFDeEIseUJBQVcsRUFBRSxNQUFNO0FBQ25CLHVCQUFTLEVBQUUsTUFBTTtBQUNqQix5QkFBVyxFQUFFLE9BQU87QUFDcEIseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQVpELGVBQUcsQ0FBQyxVQUFVOztBQWNkLHNCQUFVLEdBQUcsRUFBRSxDQUFDO0FBQ2hCLGdCQUFJLEdBQUcsQ0FDTCxjQUFjLEVBQ2QsaUJBQWlCLEVBQ2pCLFNBQVMsRUFDVCxTQUFTLEVBQ1QsY0FBYyxDQUNmLENBQUM7Ozs7Ozs7Ozs7O0FBT0YsOEJBQWdCLElBQUksMkhBQUU7QUFBWCxlQUFDO0FBQVksa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FHbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ2pELG1CQUFtQixFQUNuQixVQUFVLEVBQUU7QUFDVix3QkFBVSxFQUFFLFNBQVM7QUFDckIsd0JBQVUsRUFBRSxHQUFHLENBQUMsVUFBVTtBQUMxQixtQkFBSyxFQUFFLENBQUM7QUFDUiw2QkFBZSxFQUFFLENBQUM7QUFDbEIsZ0NBQWtCLEVBQUUsTUFBTTtBQUMxQixnQ0FBa0IsRUFBRSxNQUFNO0FBQzFCLDhCQUFnQixFQUFFLE1BQU07QUFDeEIsd0JBQVUsRUFBRSxNQUFNO0FBQ2xCLHlCQUFXLEVBQUUsT0FBTztBQUNwQix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBZEQsZUFBRyxDQUFDLGdCQUFnQjs7Ozs7O0FBZ0JwQiw4QkFBZ0IsSUFBSSwySEFBRTtBQUFYLGVBQUM7QUFBWSxrQkFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUdsQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDakQsbUJBQW1CLEVBQUUsRUFBRSxFQUFFO0FBQ3ZCLDhCQUFnQixFQUFFLEdBQUcsQ0FBQyxnQkFBZ0I7QUFDdEMsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLG1CQUFLLEVBQUUsQ0FBQztBQUNSLHlCQUFXLEVBQUUsT0FBTztBQUNwQix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBUkQsZUFBRyxDQUFDLGdCQUFnQjtnREFXYjtBQUNMLGlCQUFHOzs7QUFBSCxpQkFBRzthQUNKOzs7Ozs7O0tBQ0Y7OztTQW5VVSxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkNISyxTQUFTOzs4QkFDZixpQkFBaUI7Ozs7OztvQkFHcEIsTUFBTTs7OzsyQkFDSCxhQUFhOzs7O3FCQUNWLFFBQVE7O3lCQUNiLGVBQWU7Ozs7SUFFcEIsZUFBZSxHQUNkLFNBREQsZUFBZSxDQUNiLElBQUksRUFBRSxPQUFPLEVBQUU7d0JBRGpCLGVBQWU7O0FBRXhCLE1BQUksUUFBUSxhQUFDO0FBQ2IsVUFBUSxJQUFJLENBQUMsSUFBSTtBQUNmLFNBQUssT0FBTztBQUNWLGNBQVEsR0FBRyxJQUFJLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFBQSxHQUMvQzs7QUFFRCxTQUFPLFFBQVEsQ0FBQztDQUNqQjs7OztJQUdVLFFBQVE7QUFDUCxXQURELFFBQVEsQ0FDTixJQUFJLEVBQUUsT0FBTyxFQUFFOzBCQURqQixRQUFROztBQUVqQixRQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztBQUNqQixRQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztHQUN4Qjs7ZUFKVSxRQUFROztXQWVWLG9CQUFHO0FBQ1YsYUFBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0tBQ2xCOzs7V0FFUSxvQkFBRztBQUNWLGFBQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7S0FDdkI7OztXQUVXLHVCQUFHO0FBQ2IsYUFBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0tBQ3JCOzs7V0FFa0IsOEJBRWpCOzs7VUFEQSxFQUFFLHlEQUFHO1lBQU8sUUFBUSx5REFBRyxVQUFDLE1BQU0sRUFBSyxFQUFFO1lBQUUsT0FBTyx5REFBRyxVQUFDLENBQUMsRUFBSyxFQUFFOzs7Ozs7OztPQUFPOztBQUVqRSxVQUFJLFVBQU8sR0FBRyxFQUFFLENBQUM7S0FDbEI7Ozs7Ozs7Ozs7Ozs7V0FXYTtVQUFDLFNBQVMseURBQUcsRUFBRTs7VUFDckIsT0FBTyxFQVFQLE9BQU8sa0ZBTUYsQ0FBQyxFQUZOLE9BQU87Ozs7Ozs7QUFaUCxtQkFBTyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUU7OztBQUdsQyxtQkFBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDbkIsa0JBQUksRUFBRSxNQUFNO0FBQ1osbUJBQUssRUFBRSxFQUFFO2FBQ1YsQ0FBQyxDQUFDOztBQUVHLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBQ2xCLDZCQUFnQixPQUFPLENBQUMsT0FBTyx1SEFBRTtBQUF0QixlQUFDO2FBQ1g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVLLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBRWxCLDhCQUFnQixPQUFPLENBQUMsT0FBTywySEFBRTtBQUF0QixlQUFDOztBQUNWLHFCQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHO0FBQ2hCLHFCQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUs7QUFDZCxxQkFBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDO0FBQ25ELHFCQUFLLEVBQUUsQ0FBQztlQUNULENBQUM7QUFDRixxQkFBTyxDQUFDLElBQUksQ0FDVjtBQUNFLG9CQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7QUFDWixvQkFBSSxFQUFFLHVCQUFLLHlCQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7ZUFDdEMsQ0FDRixDQUFDO2FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBRUssSUFBSSxVQUFPLENBQ2Ysb0JBQU8sTUFBTSxFQUFFLE9BQU87dUdBQ1QsQ0FBQyxFQUVKLENBQUM7Ozs7Ozs7OztpQ0FGTyxPQUFPOzs7Ozs7OztBQUFaLHFCQUFDO0FBRUoscUJBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzs7eUJBQ3JCLENBQUMsQ0FBQyxLQUFLOzs7OzswQkFDTCxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFLOzs7Ozs7Ozt5QkFLcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Ozs7OztBQUVoQixxQkFBQyxDQUFDLEtBQUssRUFBRSxDQUFDOzs7OzBCQUdOLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXOzs7Ozs7b0RBQ3BDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzthQUsvQyxDQUNOOzs7Z0RBR1UsT0FBTzs7Ozs7OztLQUNmOzs7V0E1RmMsaUJBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRTtBQUM3QixjQUFRLElBQUksQ0FBQyxJQUFJO0FBQ2YsYUFBSyxPQUFPO0FBQ1YsaUJBQU8sSUFBSSxhQUFhLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQzFDO0FBQ0UsZ0JBQU0sSUFBSSxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUFBLE9BQ3hDO0tBQ0Y7OztTQWJVLFFBQVE7Ozs7O0lBcUdSLGFBQWE7WUFBYixhQUFhOztBQUNaLFdBREQsYUFBYSxDQUNYLElBQUksRUFBRSxPQUFPLEVBQUU7OzswQkFEakIsYUFBYTs7QUFFdEIsK0JBRlMsYUFBYSw2Q0FFaEIsSUFBSSxFQUFFLE9BQU8sRUFBRTs7QUFFckIsUUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDOztBQUU3QixRQUFJLENBQUMsS0FBSyxHQUFHLDJCQUFVLElBQUksQ0FBQyxDQUFDO0FBQzdCLFFBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBTyxRQUFRLEVBQUUsT0FBTztVQUN4QyxHQUFHLEVBQ0gsR0FBRzs7OztBQURILGVBQUcsc0JBQW9CLElBQUksQ0FBQyxLQUFLOzs0Q0FDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxVQUFDLENBQUMsRUFBSztBQUFFLG9CQUFNLENBQUMsQ0FBQzthQUFFLENBQUM7OztBQUF6RSxlQUFHO2dEQUNGLEdBQUc7Ozs7Ozs7S0FDWCxDQUFDLENBQUM7R0FDSjs7Ozs7O1NBWlUsYUFBYTtHQUFTLFFBQVE7Ozs7SUFtQjlCLGFBQWE7WUFBYixhQUFhOztBQUNaLFdBREQsYUFBYSxDQUNYLElBQUksRUFBRSxPQUFPLEVBQUU7OzswQkFEakIsYUFBYTs7QUFFdEIsK0JBRlMsYUFBYSw2Q0FFaEIsSUFBSSxFQUFFLE9BQU8sRUFBRTs7O0FBR3JCLFFBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBTyxRQUFRLEVBQUUsT0FBTztVQUMxQyxNQUFNLEVBSUosRUFBRSxFQUNGLFVBQVUsRUFFVixPQUFPLEVBTVAsR0FBRyxFQVFDLEdBQUc7Ozs7QUFyQlQsa0JBQU07OzRDQUNLLHFCQUFZLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxDQUFDOzs7QUFBdkUsa0JBQU07QUFHQSxjQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0FBQzdCLHNCQUFVLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO0FBRTNDLG1CQUFPLEdBQUc7QUFDZCxvQkFBTSxFQUFOLE1BQU07QUFDTix3QkFBVSxFQUFWLFVBQVU7QUFDVixzQkFBUSxFQUFFLEVBQUU7YUFDYjtBQUVLLGVBQUcsR0FBRyxVQUFVLENBQUMsSUFBSSxFQUFFOzs7QUFHN0IsZUFBRyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQzs7Ozs7Ozs0Q0FJNUIsR0FBRyxDQUFDLE9BQU8sRUFBRTs7Ozs7Ozs7OzRDQUNOLEdBQUcsQ0FBQyxJQUFJLEVBQUU7OztBQUF0QixlQUFHOzs0Q0FDSCxRQUFRLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQzs7Ozs7Ozs7OzRDQUl4QixHQUFHLENBQUMsS0FBSyxFQUFFOzs7Ozs7Ozs7O0tBRXBCLENBQUMsQ0FBQztHQUNKOztTQW5DVSxhQUFhO0dBQVMsUUFBUTs7OztJQXNDOUIsa0JBQWtCO1lBQWxCLGtCQUFrQjs7QUFDakIsV0FERCxrQkFBa0IsQ0FDaEIsSUFBSSxFQUFFLE9BQU8sRUFBRTs7OzBCQURqQixrQkFBa0I7O0FBRTNCLCtCQUZTLGtCQUFrQiw2Q0FFckIsSUFBSSxFQUFFLE9BQU8sRUFBRTs7O0FBR3JCLFFBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBTyxRQUFRLEVBQUUsT0FBTztVQUV4QyxPQUFPLEVBRVAsT0FBTyxFQU1QLEdBQUcsRUFHRCxRQUFRLEVBQ1IsV0FBVyxFQUNYLFVBQVUsRUFDVixZQUFZLEVBS1AsQ0FBQyxFQVFOLElBQUk7Ozs7QUEzQk4sbUJBQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7O0FBQ2hELG1CQUFPLENBQUMsR0FBRyxHQUFNLE9BQU8sQ0FBQyxHQUFHLGtCQUFlLENBQUM7QUFDdEMsbUJBQU8sR0FBRztBQUNkLHFCQUFPLEVBQVAsT0FBTzthQUNSOzs7aUJBRU0sQ0FBQzs7Ozs7OzRDQUVVLGlDQUFRLE9BQU8sQ0FBQzs7O0FBQTVCLGVBQUc7O0FBQ1AsZUFBRyxHQUFHLG1CQUFPLEdBQUcsRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDOztBQUUvQixvQkFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO0FBQzNELHVCQUFXLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7QUFDakUsc0JBQVUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztBQUMvRCx3QkFBWSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFlBQVk7O2tCQUd2RCxZQUFZLFlBQVksS0FBSzs7Ozs7QUFFdEIsYUFBQyxHQUFHLENBQUM7OztrQkFBRSxDQUFDLEdBQUcsV0FBVzs7Ozs7OzRDQUN2QixRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQzs7O0FBRFQsYUFBQyxFQUFFOzs7Ozs7Ozs7OzRDQUs5QixRQUFRLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQzs7O0FBR2pDLGdCQUFJLEdBQUcsVUFBVSxHQUFHLFdBQVc7O2tCQUVqQyxJQUFJLEdBQUcsUUFBUTs7Ozs7Ozs7QUFDbkIsbUJBQU8sQ0FBQyxFQUFFLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzs7Ozs7Ozs7O0tBRWhDLENBQUMsQ0FBQztHQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztTQXhDVSxrQkFBa0I7R0FBUyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQ25MaEIsZUFBZTs7MkJBQ1YsZ0JBQWdCOzt3QkFDaEMsY0FBYzs7OztJQUVkLGNBQWM7V0FBZCxjQUFjOzBCQUFkLGNBQWM7OztlQUFkLGNBQWM7Ozs7Ozs7V0FLdkIsY0FBQyxJQUFJOzs7Ozs0Q0FDTSwyQkFBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7OztBQUFyRCxnQkFBSSxDQUFDLEtBQUs7OzRDQUNZLDJCQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQzs7O0FBQTNELGdCQUFJLENBQUMsUUFBUTs7Ozs7OztLQUNkOzs7V0FFYSxrQkFBQyxNQUFNO1VBQ2IsSUFBSSxFQU9KLFVBQVUsRUFRVixVQUFVLGtGQUVMLFVBQVUsRUFDZixXQUFXLHVGQUVKLEVBQUUsRUFDTCxPQUFPLEVBT1AsVUFBVSx1RkFHTCxLQUFLLEVBUWQsUUFBUTs7Ozs7OzRDQXZDSyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNwQyxpQkFBRyxFQUFFLE1BQU07YUFDWixFQUFFO0FBQ0Qsd0JBQVUsRUFBRTtBQUNWLHVCQUFPLEVBQUUsQ0FBQztlQUNYO2FBQ0YsQ0FBQzs7O0FBTkksZ0JBQUk7QUFPSixzQkFBVSxHQUFHLElBQUksQ0FBQyxPQUFPO0FBUXpCLHNCQUFVLEdBQUcsRUFBRTs7Ozs7d0JBRUksVUFBVTs7Ozs7Ozs7QUFBeEIsc0JBQVU7QUFDZix1QkFBVyxHQUFHLENBQUM7Ozs7O3lCQUVGLFVBQVUsQ0FBQyxHQUFHOzs7Ozs7OztBQUFwQixjQUFFOzs0Q0FDVyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztBQUMxQyxpQkFBRyxFQUFFLEVBQUU7YUFDUixFQUFFO0FBQ0Qsd0JBQVUsRUFBRTtBQUNWLHFCQUFLLEVBQUUsQ0FBQztlQUNUO2FBQ0YsQ0FBQzs7O0FBTkksbUJBQU87QUFPUCxzQkFBVSxHQUFHLE9BQU8sQ0FBQyxLQUFLOzs7Ozs7O0FBR2hDLDhCQUFvQixVQUFVO0FBQW5CLG1CQUFLO0FBQWdCLHlCQUFXLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQzthQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJaEUsc0JBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUl0RCxvQkFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUM7Z0RBRTFDLFFBQVE7Ozs7Ozs7S0FDaEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7V0F1QmEsa0JBQUMsUUFBUSxFQUFFLEtBQUs7VUFBRSxNQUFNLHlEQUFHLElBQUk7VUFBRSxNQUFNLHlEQUFHLElBQUk7VUFFcEQsTUFBTSxFQUtOLE1BQU0sRUFLTixHQUFHOzs7O0FBVkgsa0JBQU0sR0FBRyxxQkFBUSxJQUFJLENBQUM7QUFDMUIsc0JBQVEsRUFBUixRQUFRO2FBQ1QsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFDO3FCQUFJLENBQUMsQ0FBQyxnQkFBZ0I7YUFBQSxDQUFDO0FBR2pDLGtCQUFNLEdBQUcsRUFBRTs7QUFDakIsa0JBQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQ3JCLGdCQUFJLE1BQU0sRUFBRSxNQUFNLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQztBQUN6QyxnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7Ozs0Q0FFdkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQ3JDLE1BQU0sRUFBRTtBQUNOLG1CQUFLLEVBQUU7QUFDTCxzQkFBTSxFQUFFO0FBQ04sdUJBQUssRUFBRSxNQUFNO2lCQUNkO2VBQ0Y7YUFDRixDQUNGOzs7QUFSSyxlQUFHO2dEQVdGLE1BQU07Ozs7Ozs7S0FDZDs7Ozs7Ozs7Ozs7O1dBVWUsb0JBQUMsS0FBSztVQUFFLE1BQU0seURBQUcsSUFBSTtVQUFFLE1BQU0seURBQUcsSUFBSTtVQUU1QyxNQUFNLEVBS04sR0FBRzs7OztBQUxILGtCQUFNLEdBQUcsRUFBRTs7QUFDakIsa0JBQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQ3JCLGdCQUFJLE1BQU0sRUFBRSxNQUFNLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQztBQUN6QyxnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7Ozs0Q0FFdkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQ3JDLE1BQU0sRUFBRTtBQUNOLGtCQUFJLEVBQUU7QUFDSixzQkFBTSxFQUFFLEVBQUU7ZUFDWDthQUNGLENBQ0Y7OztBQU5LLGVBQUc7Ozs7Ozs7S0FPVjs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBZ0JpQixzQkFBQyxJQUFJLEVBQUUsT0FBTztVQVN4QixHQUFHLEVBbUNILEtBQUssdUZBRUEsQ0FBQyx1RkFzQkQsSUFBSSx1RkFBc0IsQ0FBQzs7Ozs7QUEzRGhDLGVBQUcsR0FBRyxDQUFDO0FBQ1gsbUJBQUssRUFBRSxNQUFNO0FBQ2IscUJBQU8sRUFBRSxJQUFJLENBQUMsUUFBUTtBQUN0QixxQkFBTyxFQUFFO0FBQ1AscUJBQUssRUFBRSxXQUFXO2VBQ25CO0FBQ0QsbUJBQUssRUFBRTtBQUNMLDRCQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7QUFDL0IsNEJBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtlQUNoQzthQUNGLEVBQ0Q7QUFDRSxtQkFBSyxFQUFFLElBQUksQ0FBQyxXQUFXO0FBQ3ZCLHFCQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVk7QUFDMUIscUJBQU8sRUFBRTtBQUNQLHFCQUFLLEVBQUUsZUFBZTtlQUN2QjtBQUNELG1CQUFLLEVBQUU7QUFDTCx3QkFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO0FBQ3ZCLDRCQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7ZUFDaEM7YUFDRixFQUNEO0FBQ0UsbUJBQUssRUFBRSxJQUFJLENBQUMsV0FBVztBQUN2QixxQkFBTyxFQUFFLElBQUksQ0FBQyxZQUFZO0FBQzFCLHFCQUFPLEVBQUU7QUFDUCxxQkFBSyxFQUFFLGVBQWU7ZUFDdkI7QUFDRCxtQkFBSyxFQUFFO0FBQ0wsd0JBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtBQUN2Qiw0QkFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO2VBQ2hDO2FBQ0YsQ0FDQTtBQUVLLGlCQUFLLEdBQUcsRUFBRTs7Ozs7eUJBRUEsR0FBRzs7Ozs7Ozs7QUFBUixhQUFDOzZCQUNWLEtBQUs7OzRDQUNlLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUNwQyxDQUFDO0FBQ0Msb0JBQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7QUFDN0IscUJBQUssRUFBRSxJQUFJLENBQUMsS0FBSztlQUNsQixDQUFDO2FBQ0gsRUFDRDtBQUNFLHNCQUFRLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQzthQUM1QyxFQUNEO0FBQ0UsbUJBQUssRUFBRTtBQUNMLG1CQUFHLEVBQUUsQ0FBQztlQUNQO2FBQ0YsQ0FDQSxDQUNGLENBQUMsT0FBTyxFQUFFOzs7OzZCQUNKLENBQUM7O0FBaEJSLHdCQUFVO0FBZ0JWLG1CQUFLOzsyQkFqQkQsSUFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkFxQk8sS0FBSzs7Ozs7Ozs7QUFBYixnQkFBSTs7Ozs7eUJBQTJCLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUFwQixhQUFDOzs0Q0FBcUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDOzs7QUFBcEMsYUFBQyxDQUFDLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnREFHM0QsS0FBSzs7Ozs7OztLQUNiOzs7Ozs7V0FJa0IsdUJBQUMsR0FBRztVQUNqQixJQUFJLEVBR0EsR0FBRyxFQUNILEdBQUcsRUFXQyxLQUFLLEVBYVgsVUFBVTs7OztBQTVCWixnQkFBSTs7a0JBRUosT0FBTyxHQUFHLEtBQUssUUFBUTs7Ozs7QUFDbkIsZUFBRyxHQUFHLElBQUksTUFBTSxDQUFJLEdBQUcsT0FBSTtBQUMzQixlQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFO0FBQzlCLHdCQUFVLEVBQUU7QUFDVixxQkFBSyxFQUFFLENBQUM7QUFDUiw0QkFBWSxFQUFFLENBQUM7QUFDZiw0QkFBWSxFQUFFLENBQUM7ZUFDaEI7YUFDRixDQUFDOzs7aUJBRUssQ0FBQzs7Ozs7Ozs0Q0FFUyxHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdkIsZ0JBQUk7OzRDQUNnQixJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEvQyxpQkFBSzs7aUJBQ1AsS0FBSzs7Ozs7Ozs7Ozs7Ozs7OztBQUdULGVBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztnREFDTCxHQUFHOzs7Ozs7O0FBR2QsZUFBRyxDQUFDLEtBQUssRUFBRSxDQUFDOzs7OztBQUVaLGdCQUFJLEdBQUcsR0FBRyxDQUFDOzs7QUFHUCxzQkFBVSxHQUFHLEVBQUU7O0FBQ3JCLGdCQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDNUMsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUMxRCxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dEQUNuRCxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7Ozs7OztLQUM1Qjs7O1dBRXFCLDBCQUFDLGdCQUFnQixFQUFFLElBQUk7VUFFckMsU0FBUyxFQUdULFNBQVMsRUFDVCxVQUFVLEVBU1osYUFBYSxFQWNYLElBQUksRUF5Qk4sV0FBVyxFQWdCWCxLQUFLLEVBcUJILGFBQWEsRUF1QmIsaUJBQWlCLEVBTWpCLElBQUk7Ozs7QUF0SEoscUJBQVMsR0FBRyxTQUFaLFNBQVMsQ0FBRyxRQUFRO3FCQUFLLFFBQVEsS0FBSyxRQUFRLEdBQUcsT0FBTyxHQUFHLFFBQVE7YUFBQzs7QUFHcEUscUJBQVMsR0FBRyxJQUFJO0FBQ2hCLHNCQUFVLEdBQUcsRUFBRTs7OztBQUlyQixnQkFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzVDLGdCQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDMUQsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQzs7O0FBR3RELHlCQUFhOzZCQUNULElBQUksQ0FBQyxRQUFRO2tEQUNkLEtBQUssMkJBR0wsUUFBUTs7OztBQUZYLHlCQUFhLEdBQUcsQ0FBQyxDQUFDOzs7O0FBR2xCLHlCQUFhLEdBQUcsQ0FBQyxDQUFDOzs7O0FBR2xCLHlCQUFhLEdBQUcsQ0FBQyxDQUFDOzs7O0FBS2hCLGdCQUFJLEdBQUcsRUFBRTs2QkFDUCxJQUFJLENBQUMsUUFBUTtrREFDZCxLQUFLLDJCQVNMLFFBQVE7Ozs7QUFSWCxnQkFBSSxDQUFDLElBQUksQ0FBQztBQUNSLGlCQUFHLEVBQUUsQ0FBQztBQUNOLGlCQUFHLEVBQUUsSUFBSTthQUNWLEVBQUU7QUFDRCxpQkFBRyxFQUFFLENBQUM7QUFDTixpQkFBRyxFQUFFLEtBQUs7YUFDWCxDQUFDLENBQUM7Ozs7QUFHSCxnQkFBSSxDQUFDLElBQUksQ0FBQztBQUNSLGlCQUFHLEVBQUUsQ0FBQztBQUNOLGlCQUFHLEVBQUUsSUFBSTthQUNWLEVBQUU7QUFDRCxpQkFBRyxFQUFFLENBQUM7QUFDTixpQkFBRyxFQUFFLEtBQUs7YUFDWCxDQUFDLENBQUM7Ozs7Ozs7QUFPSCx1QkFBVyxHQUFHLElBQUk7NkJBQ2QsSUFBSSxDQUFDLFFBQVE7a0RBQ2QsS0FBSywyQkFHTCxRQUFROzs7O0FBRlgsdUJBQVcsR0FBRyxJQUFJLENBQUM7Ozs7QUFHbkIsdUJBQVcsR0FBRyxHQUFHLENBQUM7Ozs7Ozs7OzRDQVVKLElBQUksQ0FBQyxZQUFZLENBQUMsSUFBSSxFQUFFO0FBQ3hDLHdCQUFVLEVBQUUsOEJBQThCO2FBQzNDLENBQUM7OztBQUZFLGlCQUFLOzs7OztBQU9ULGlCQUFLLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FDZixVQUFDLElBQUksRUFBSztBQUNSLGtCQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sR0FBRyxTQUFTLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUMsQ0FBQztBQUNuRCxrQkFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FDbkMsVUFBQyxTQUFTLEVBQUs7QUFDYix5QkFBUyxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzdDLHVCQUFPLFNBQVMsQ0FBQztlQUNsQixDQUNGLENBQUM7QUFDRixxQkFBTyxJQUFJLENBQUM7YUFDYixDQUNGLENBQUM7OztBQUdJLHlCQUFhLEdBQUcsS0FBSyxDQUFDLEdBQUcsQ0FDN0IsY0FBSTtxQkFBSSxNQUFHLCtCQUErQixHQUN0QyxtQkFBbUIsR0FDbkIsaUVBQWlFLGlCQUN0RCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssZUFBVyxHQUN0QyxRQUFRLElBQ1YsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQ2pCLFVBQUMsU0FBUyxFQUFLO0FBQ2Isb0JBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEtBQUssU0FBUyxDQUFDLEtBQUssRUFBRTs7QUFFMUMsbUdBQStFLFNBQVMsQ0FBQyxLQUFLLHdCQUFxQjtpQkFDbkgsSUFBSSxTQUFTLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTs7QUFFekIsd0RBQW9DLFNBQVMsQ0FBQyxVQUFVLHVFQUFrRSxTQUFTLENBQUMsS0FBSyxtQkFBZ0I7aUJBQzFKOztBQUVELHFKQUFtSSxTQUFTLENBQUMsS0FBSyxlQUFZO2VBQy9KLENBQ0YsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLGNBRVIsUUFBUTthQUFBLENBQ2IsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDO0FBRUosNkJBQWlCLDhEQUVyQixhQUFhO0FBSVQsZ0JBQUksR0FBRztBQUNYLHdCQUFVLEVBQUUsU0FBUztBQUNyQix3QkFBVSxFQUFFLGdCQUFnQixDQUFDLFVBQVU7QUFDdkMsa0JBQUksRUFBSyxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFJLFNBQVMsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLFNBQUksSUFBSSxDQUFDLElBQUksSUFBRyxJQUFJLENBQUMsUUFBUSxTQUFPLElBQUksQ0FBQyxRQUFRLEdBQUssRUFBRSxDQUFFO0FBQ25ILGdDQUFrQixFQUFFLGlCQUFpQjs7QUFFckMsMEJBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNsQyxxQkFBTyxFQUFFLElBQUksQ0FBQyxZQUFZOzs7QUFHMUIsNkJBQWUsRUFBRSxhQUFhO0FBQzlCLGtCQUFJLEVBQUosSUFBSTtBQUNKLDBCQUFZLEVBQUUsV0FBVzthQUMxQjs2QkFFRCxNQUFNOzZCQUFRLElBQUk7OzRDQUFRLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUM7Ozs7MkJBQTlFLE1BQU07NkJBQ2IsTUFBTTs2QkFBUSxJQUFJOzs0Q0FBUSxJQUFJLENBQUMsNkJBQTZCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDOzs7OzJCQUE3RSxNQUFNOzZCQUNiLE1BQU07OEJBQVEsSUFBSTs7NENBQVEsSUFBSSxDQUFDLDRCQUE0QixDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQzs7OzsyQkFBNUUsTUFBTTs7QUFFYixrQkFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQzs7Z0RBRXBDLElBQUk7Ozs7Ozs7S0FDWjs7O1dBRW1DLHdDQUFDLGdCQUFnQixFQUFFLElBQUk7VUFDckQsUUFBUSxFQUlILENBQUM7Ozs7QUFKTixvQkFBUSxHQUFHLEVBQUU7OztBQUVqQixvQkFBUSxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUM7O0FBRTdCLGlCQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRTtBQUFFLHNCQUFRLHNDQUFvQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxXQUFRLENBQUM7YUFBQTtBQUdoSCxvQkFBUSxJQUFJLEdBQUcsQ0FBQztnREFDVCxFQUFFLFNBQVMsRUFBRSxRQUFRLEVBQUU7Ozs7Ozs7S0FDL0I7OztXQUVrQyx1Q0FBQyxnQkFBZ0IsRUFBRSxJQUFJOzs7O2dEQUVqRCxFQUFFLE9BQU8sRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUU7Ozs7Ozs7S0FDaEQ7OztXQUVpQyxzQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJO1VBRWpELEdBQUc7Ozs7QUFBSCxlQUFHLEdBQUcsT0FBTyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsR0FBRyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2dEQUNsRSxFQUFFLE1BQU0sRUFBRSxHQUFHLEVBQUU7Ozs7Ozs7S0FDdkI7Ozs7O1dBR3NCLDJCQUFDLE1BQU0sRUFBRSxJQUFJO1VBQzVCLEdBQUc7Ozs7OzRDQUFTLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLFdBQVEsRUFBRSxJQUFJLENBQUM7OztBQUF2RCxlQUFHO2dEQUNGLEdBQUc7Ozs7Ozs7S0FDWDs7Ozs7V0FHcUIsMEJBQUMsR0FBRyxFQUFFLElBQUk7VUFDeEIsUUFBUSxFQUNSLFdBQVcsRUFFYixLQUFLLEVBS0gsU0FBUyxFQUNOLENBQUM7Ozs7QUFUSixvQkFBUSxHQUFHLEVBQUU7QUFDYix1QkFBVyxHQUFHLEdBQUc7QUFFbkIsaUJBQUssR0FBRyxFQUFFOzs7QUFFZCxpQkFBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7O0FBR2pELHFCQUFTLEdBQUcsSUFBSTs7QUFDdEIsaUJBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFO0FBQUUsbUJBQUssQ0FBQyxTQUFTLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUFBO0FBSXpGLGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUSxDQUFDOzs7NENBQ0MsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7Ozs7OzZCQUFJLElBQUksQ0FBQyxRQUFROzs7NkJBQUksSUFBSSxDQUFDLElBQUk7OzZCQUFJLFdBQVc7QUFBL0csaUJBQUssQ0FBQyxNQUFNLENBQUMsa0JBQVksT0FBTzs7QUFDaEMsaUJBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO0FBQ2pDLGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUNqQyxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDeEQsZ0JBQUksT0FBTyxLQUFLLENBQUMsSUFBSSxDQUFDLEtBQUssUUFBUSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBTSxJQUFJLENBQUMsV0FBVyxnQkFBVyxLQUFLLENBQUMsSUFBSSxDQUFHLENBQUMsS0FDMUYsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7O0FBRXBDLGlCQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDOztnREFFakMsS0FBSzs7Ozs7OztLQUNiOzs7V0FFeUMsOENBQUMsUUFBUTtVQUMzQyxFQUFFLEVBQ0YsR0FBRyxFQUNILE9BQU8sRUFNUCxJQUFJLEVBdUJOLFdBQVcsdUZBQ0osR0FBRyxFQUdSLGNBQWMsRUFDWCxDQUFDLEVBQ0YsR0FBRTs7Ozs7QUFyQ0osY0FBRSxHQUFHLHFCQUFxQjtBQUMxQixlQUFHLEdBQUcsVUFBVTtBQUNoQixtQkFBTyxHQUFHO0FBQ2Qsb0JBQU0sRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUNoQixpQkFBRyxFQUFFLENBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQzthQUM3Qjs7NENBR2tCLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUNyQyxDQUNFO0FBQ0Usb0JBQU0sc0JBQ0gsRUFBRSxFQUFHLFFBQVEsQ0FDZjthQUNGLEVBQ0Q7QUFDRSxvQkFBTTtBQUNKLG1CQUFHLFFBQU0sRUFBSTtpQkFDWixHQUFHLEVBQUcsRUFBRSxTQUFTLFFBQU0sR0FBSyxFQUFFLENBQ2hDO2FBQ0YsRUFDRDtBQUNFLHNCQUFRO0FBQ04sbUJBQUcsRUFBRSxDQUFDO0FBQ04sd0JBQVEsRUFBRSxNQUFNO2lCQUNmLEdBQUcsUUFBTyxHQUFHLENBQ2Y7YUFDRixDQUNGLENBQ0YsQ0FBQyxPQUFPLEVBQUU7OztBQXJCTCxnQkFBSTtBQXVCTix1QkFBVyxHQUFHLEVBQUU7Ozs7OztBQUNwQiw4QkFBa0IsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVE7QUFBdkIsaUJBQUc7QUFBc0IseUJBQVcsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sTUFBSSxHQUFHLENBQUcsQ0FBQyxDQUFDO2FBQUE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFHbEYsMEJBQWMsR0FBRyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7O0FBQ25DLGlCQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDeEMsaUJBQUUsR0FBRyxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEdBQUcsTUFBTSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUM7O0FBQzFFLDRCQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxpQkFBaUIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLGdCQUFnQixFQUFFLEdBQUUsRUFBRSxDQUFDO2FBQ3hFOztnREFFTSxFQUFFLGNBQWMsRUFBZCxjQUFjLEVBQUU7Ozs7Ozs7S0FDMUI7Ozs7Ozs7O1dBTTRCLGdDQUFDLElBQUksRUFBRTtBQUNsQyxhQUFPO0FBQ0wsaUJBQVMsRUFBRSxHQUFHO0FBQ2QsY0FBTSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFO0FBQzlCLFlBQUksRUFBRSxJQUFJO0FBQ1YsV0FBRyxPQUFLLElBQUksQ0FBQyxLQUFLLElBQUcsSUFBSSxDQUFDLFlBQVksS0FBSyxFQUFFLEdBQUcsRUFBRSxTQUFPLElBQUksQ0FBQyxZQUFZLENBQUUsSUFBRyxJQUFJLENBQUMsWUFBWSxLQUFLLEVBQUUsR0FBRyxFQUFFLFNBQU8sSUFBSSxDQUFDLFlBQVksQ0FBSTtBQUN4SSxVQUFFLEVBQUUsSUFBSTtPQUNULENBQUM7S0FDSDs7Ozs7Ozs7V0FNOEIsa0NBQUMsSUFBSSxFQUFFO0FBQ3BDLFVBQU0sTUFBTSxHQUFHO0FBQ2IsaUJBQVMsRUFBRSxHQUFHO0FBQ2QsY0FBTSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFO0FBQzlCLFlBQUksRUFBRSxJQUFJO0FBQ1YsY0FBTSxFQUFFLElBQUk7QUFDWixnQkFBUSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFO09BQ2pDLENBQUM7O0FBRUYsVUFBTSxLQUFLLEdBQUcseUJBQVksSUFBSSxFQUFFLENBQUM7O0FBRWpDLFdBQUssQ0FBQyxPQUFPLENBQ1gsVUFBQyxHQUFHLEVBQUUsS0FBSyxFQUFLO0FBQ2QsWUFBSSxLQUFLLGFBQUM7QUFDVixZQUFJLE1BQU0sYUFBQztBQUNYLFlBQUksTUFBTSxhQUFDO0FBQ1gsWUFBSTs7QUFFRixlQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBSSxHQUFHLENBQUMsSUFBSSxDQUFHLE1BQUksR0FBRyxDQUFDLFNBQVMsQ0FBRyxDQUFDO0FBQ3JELGVBQUssR0FBRyxPQUFPLEtBQUssS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHLEtBQUssQ0FBQztBQUNsRCxnQkFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksR0FBRyxDQUFDLElBQUksQ0FBRyxNQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUcsQ0FBQztBQUN2RCxnQkFBTSxHQUFHLE9BQU8sTUFBTSxLQUFLLFdBQVcsR0FBRyxFQUFFLEdBQUcsTUFBTSxDQUFDO0FBQ3JELGdCQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBSSxHQUFHLENBQUMsSUFBSSxDQUFHLE1BQUksR0FBRyxDQUFDLFVBQVUsQ0FBRyxDQUFDO0FBQ3ZELGdCQUFNLEdBQUcsT0FBTyxNQUFNLEtBQUssV0FBVyxHQUFHLEVBQUUsR0FBRyxNQUFNLENBQUM7U0FDdEQsQ0FBQyxPQUFPLENBQUMsRUFBRTs7Ozs7QUFLVixpQkFBTztTQUNSOztBQUVELGNBQU0sYUFBVyxLQUFLLENBQUcsR0FBRyxJQUFJLENBQUM7QUFDakMsY0FBTSxXQUFTLEtBQUssQ0FBRyxHQUFHLEdBQUcsQ0FBQyxNQUFNLENBQUMsQ0FBQztBQUN0QyxjQUFNLFVBQVEsS0FBSyxDQUFHLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQztBQUNsQyxjQUFNLGFBQVcsS0FBSyxDQUFHLFFBQU0sS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFRLENBQUM7QUFDekQsY0FBTSxZQUFVLEtBQUssQ0FBRyxHQUFHLElBQUksQ0FBQztPQUNqQyxDQUNGLENBQUM7O0FBRUYsYUFBTyxNQUFNLENBQUM7S0FDZjs7Ozs7Ozs7V0FNa0Msc0NBQUMsSUFBSSxFQUFFLElBQUksRUFBRTtBQUM5QyxVQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsU0FBUyxDQUFHLENBQUM7QUFDN0QsVUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBSSxJQUFJLENBQUMsSUFBSSxDQUFHLE1BQUksSUFBSSxDQUFDLFVBQVUsQ0FBRyxDQUFDO0FBQy9ELFVBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksSUFBSSxDQUFDLElBQUksQ0FBRyxNQUFJLElBQUksQ0FBQyxVQUFVLENBQUcsQ0FBQzs7QUFFL0QsYUFBTztBQUNMLGlCQUFTLEVBQUUsR0FBRztBQUNkLGNBQU0sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtBQUM5QixjQUFNLEVBQUUsSUFBSTtBQUNaLFlBQUksRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ2xCLFdBQUcsRUFBRSxJQUFJO0FBQ1QsY0FBTSxPQUFLLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBUTtBQUNwQyxhQUFLLEVBQUUsSUFBSTtPQUNaLENBQUM7S0FDSDs7O1NBamtCa0IsY0FBYzs7O3FCQUFkLGNBQWM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkNGNUIsY0FBYzs7b0JBR2QsTUFBTTs7d0JBQ1EsY0FBYzs7OztxQkFDUixTQUFTOzs7OzJCQUc3QixnQkFBZ0I7O0lBRUYsT0FBTztBQUVkLFdBRk8sT0FBTyxHQUVYOzBCQUZJLE9BQU87Ozs7O0FBTXhCLFFBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsSUFBSSxDQUFDO0dBQ3hDOztlQVBrQixPQUFPOzs7Ozs7OztXQWtCVix5QkFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFOztBQUVoQyxVQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFDLE9BQU8sRUFBQyxRQUFRLEVBQUMsQ0FBQztLQUN0Qzs7Ozs7Ozs7Ozs7Ozs7O1dBOEVrQiw2QkFBQyxRQUFRLEVBQUUsWUFBWSxFQUFFOzs7OztBQUsxQyxVQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7O0FBY2pDLFVBQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FDeEM7QUFDRSxxQkFBYSxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUM7O0FBRTNCLHNCQUFjLEVBQUU7QUFDZCxhQUFHLEVBQUUsQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ3hDO09BQ0Y7O0FBRUQsYUFBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVcsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FDdEQ7Ozs7Ozs7Ozs7QUFVRCxVQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzs7O0FBR3RELFVBQU0sZUFBZSxHQUFHLFlBQVksQ0FBQyxlQUFlLENBQUM7QUFDckQsVUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxJQUFJLEtBQUssc0JBQW9CLGVBQWUsQ0FBQyxNQUFNLFdBQVEsQ0FBQzs7O0FBRzdHLGtCQUFZLFNBQU0sQ0FBQyxPQUFPLENBQUMsVUFBQyxDQUFDLEVBQUs7QUFDaEMsZ0JBQVEsQ0FBQyxDQUFDLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDLEtBQUssQ0FBQztPQUM5QixDQUFDLENBQUM7OztBQUdILHFCQUFlLENBQUMsT0FBTyxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUMsRUFBSztBQUNoQyxZQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNaLGtCQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3hCLE1BQU07OztBQUdMLGtCQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQ2xCO09BQ0YsQ0FBQyxDQUFDOzs7OztBQUtILDRCQUFTLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7QUFDM0MsNEJBQVMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDLEVBQUUsRUFBRSxFQUFFLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQzs7QUFFM0MsYUFBTyxRQUFRLENBQUM7S0FDakI7Ozs7Ozs7OztXQU9tQiw4QkFBQyxRQUFRLEVBQUUsWUFBWSxFQUFFOzs7OztBQUszQyxVQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7QUFjMUQsVUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUN4QztBQUNFLHFCQUFhLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQzs7QUFFbkMsc0JBQWMsRUFBRTtBQUNkLGFBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDeEM7T0FDRjs7QUFFRCxhQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUN0RCxDQUFDOzs7O0FBSUYsVUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7OztBQUd0RCxVQUFNLGVBQWUsR0FBRyxZQUFZLENBQUMsZUFBZSxDQUFDO0FBQ3JELFVBQUksZUFBZSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sSUFBSSxLQUFLLHNCQUFvQixlQUFlLENBQUMsTUFBTSxXQUFRLENBQUM7OztBQUk3RyxxQkFBZSxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDLEVBQUs7QUFDaEMsWUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDWixrQkFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4QixNQUFNOzs7QUFHTCxrQkFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztTQUNsQjtPQUNGLENBQUMsQ0FBQzs7O0FBR0gsY0FBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUM7Ozs7O0FBS3pDLDRCQUFTLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQ3ZFLDRCQUFTLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDO0FBQ3ZFLGFBQU8sUUFBUSxDQUFDO0tBQ2pCOzs7V0FFcUIsZ0NBQUMsUUFBUSxFQUFFLGVBQWUsRUFBRTs7QUFFaEQsVUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLE1BQU0sQ0FBQyxDQUFDLE9BQU8sQ0FBQyxPQUFPLEVBQUUsRUFBRSxDQUFDLENBQUM7Ozs7Ozs7Ozs7O0FBVzFELFVBQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FDeEM7QUFDRSxxQkFBYSxFQUFFLFFBQVEsQ0FBQyxVQUFVLENBQUM7O0FBRW5DLHNCQUFjLEVBQUU7QUFDZCxhQUFHLEVBQUUsQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ3hDO09BQ0Y7O0FBRUQsYUFBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVcsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FDdEQsQ0FBQzs7QUFFRixVQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQztBQUN0RCxjQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzs7OztBQUluQyw0QkFBUyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUN2RSw0QkFBUyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztBQUN2RSxhQUFPLFFBQVEsQ0FBQztLQUNqQjs7O1dBcFF5QiwrQkFBYTtVQUFaLEtBQUsseURBQUcsRUFBRTs7QUFDbkMsYUFBTywyQkFBYyxhQUFhLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUMsR0FBRyxFQUFDLENBQUMsRUFBRSxPQUFPLEVBQUMsQ0FBQyxFQUFDLENBQUMsQ0FBQyxNQUFNLEVBQUU7S0FDOUU7OztXQWlCdUIscUJBQUMsUUFBUSxFQUFFLE9BQU87VUFRbEMsU0FBUzs7OztBQUFULHFCQUFTLEdBQUc7QUFDaEIscUJBQU8sRUFBRSxRQUFRO2FBQ2xCOzs7O0FBSUQsdUNBQWMsTUFBTSxDQUFDO0FBQ25CLDRCQUFjLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQztBQUNoQyw0QkFBYyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUM7YUFDakMsRUFBRTtBQUNELGtCQUFJLEVBQUU7QUFDSix1QkFBTyxFQUFFLFFBQVE7ZUFDbEI7YUFDRixFQUFFO0FBQ0Qsb0JBQU0sRUFBRSxJQUFJO2FBQ2IsQ0FBQzs7OztBQUlGLHVDQUFjLE1BQU0sQ0FBQztBQUNuQixvQkFBTSxFQUFFLEVBQUMsT0FBTyxFQUFDLENBQUMsRUFBQzthQUNwQixFQUFDO0FBQ0Esa0JBQUksRUFBRTtBQUNKLHNCQUFNLEVBQUU7QUFDTix5QkFBTyxFQUFFLEVBQUU7QUFDWCwyQkFBUyxFQUFFLElBQUk7QUFDZix5QkFBTyxFQUFFLElBQUksRUFDZDtlQUNGO2FBQ0YsQ0FBQzs7Ozs7OztLQUNIOzs7O1dBRTBCLDhCQUFDLEtBQUssRUFBcUI7VUFBbkIsVUFBVSx5REFBRyxJQUFJOzs7QUFFbEQsZ0JBQVUsR0FBRyxVQUFVLEtBQUssSUFBSSxnQ0FBbUIsVUFBVSxDQUFDOzs7QUFHOUQsVUFBTSxHQUFHLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FDekIsS0FBSyxFQUFFO0FBQ0wsY0FBTSxFQUFFO0FBQ04sYUFBRyxFQUFFLENBQUM7QUFDTix5QkFBZSxFQUFFLENBQUM7QUFDbEIsc0JBQVksRUFBRSxDQUFDO1NBQ2hCO09BQ0YsQ0FDRixDQUFDOztBQUVGLFVBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDOztBQUUxRSxVQUFJLElBQUksR0FBRyxFQUFFLENBQUM7QUFDZCxTQUFHLENBQUMsT0FBTyxDQUFDLGFBQUcsRUFBSTtBQUNqQixZQUFJLENBQUMsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxTQUFPLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRSxRQUFLLENBQUM7QUFDM0QsWUFBSSxDQUFDLElBQUksQ0FBSSxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssU0FBSSxDQUFDLENBQUc7T0FDdkMsQ0FBQzs7QUFFRixhQUFPLElBQUksQ0FBQztLQUNiOzs7U0E1RmtCLE9BQU87OztxQkFBUCxPQUFPOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OEJDWlIsaUJBQWlCOzs7O3FCQUNaLFFBQVE7O3lCQUNYLGVBQWU7Ozs7QUFFckMsSUFBTSxRQUFRLEdBQUcsd0NBQXdDOztJQUVwQyxRQUFRO0FBQ2YsV0FETyxRQUFRLENBQ2QsSUFBSSxFQUFFLE1BQU0sRUFBRTswQkFEUixRQUFROztBQUV6QixRQUFJLENBQUMsSUFBSSxHQUFHLElBQUk7QUFDaEIsUUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNO0dBQ3JCOzs7O2VBSmtCLFFBQVE7O1dBT1Ysb0JBQUMsV0FBVTtVQUN0QixPQUFPLEVBRUwsR0FBRzs7OztBQUZMLG1CQUFPLHlCQUF1QixJQUFJLENBQUMsTUFBTSw2QkFBd0IscUJBQVMsV0FBVSxFQUFFLEVBQUMsT0FBTyxFQUFFLElBQUksRUFBQyxDQUFDOzs7NENBRXhGLElBQUksQ0FBQyxXQUFXLENBQzlCLGdCQUFnQixFQUNoQixPQUFPLENBQ1I7OztBQUhHLGVBQUc7Z0RBSUEsRUFBQyxRQUFRLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUM7Ozs7O2tCQUVyQyxNQUFNLENBQUMsTUFBTSxDQUFDLHVCQUFVLEtBQUssZ0JBQUcsRUFBRSxFQUFDLFVBQVUsRUFBRSxPQUFPLEVBQUMsQ0FBQzs7Ozs7OztLQUVqRTs7O1dBRWlCLHFCQUFDLE1BQU0sRUFBRSxJQUFJO1VBRXpCLFVBQVUsRUFTVixHQUFHOzs7O0FBVEgsc0JBQVUsR0FBRztBQUNmLG9CQUFNLEVBQUUsTUFBTTtBQUNkLGlCQUFHLEVBQUssUUFBUSxTQUFJLE1BQVE7QUFDNUIsa0JBQUksRUFBRSxJQUFJO2FBQ1g7OztBQUVELGtCQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDOzs7OzRDQUdwQixpQ0FBUSxVQUFVLENBQUM7OztBQUEvQixlQUFHO2dEQUVBLEdBQUc7Ozs7Ozs7S0FDWDs7O1dBRWlCLHFCQUFDLGVBQWU7VUFFNUIsVUFBVSxFQVVWLEdBQUc7Ozs7QUFWSCxzQkFBVSxHQUFHO0FBQ2Ysb0JBQU0sRUFBRSxNQUFNO0FBQ2QsaUJBQUcsRUFBSyxRQUFRLGlCQUFjO2FBQy9COzs7QUFFRCxrQkFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQzs7OzRDQUVaLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxlQUFlLENBQUM7OztBQUExRSxzQkFBVSxDQUFDLElBQUk7OzRDQUdDLGlDQUFRLFVBQVUsQ0FBQzs7O0FBQS9CLGVBQUc7Z0RBRUEsR0FBRzs7Ozs7OztLQUNYOzs7V0FFa0Msc0NBQUMsZUFBZTtVQWdCN0Msa0JBQWtCLGtGQUViLElBQUksdUZBRUYsQ0FBQyxFQVlOLElBQUksdUZBVUcsU0FBUyx1RkFPUCxHQUFHLEVBV2QsY0FBYzs7Ozs7QUE1Q2QsOEJBQWtCLEdBQUcsRUFBRTs7Ozs7d0JBRVYsZUFBZTs7Ozs7Ozs7QUFBdkIsZ0JBQUk7Ozs7Ozs7QUFFWCw4QkFBYyxJQUFJLENBQUMsVUFBVSwySEFBRTtBQUF0QixlQUFDOzs7QUFFUixrQkFBSSxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUc7YUFDakM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVELDhCQUFrQixJQUFJLG1CQUFtQjtBQUN6Qyw4QkFBa0IsbUJBQWlCLElBQUksQ0FBQyxRQUFRLGdCQUFhOzs7Ozs7QUFNekQsZ0JBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQzs7a0JBQ3pCLElBQUksQ0FBQywwQkFBMEIsS0FBSyxFQUFFLElBQUksSUFBSSxDQUFDLHdCQUF3QixLQUFLLEVBQUU7Ozs7OztBQUVoRiw4QkFBa0IsSUFBSSxnQ0FBZ0M7QUFDdEQsOEJBQWtCLHFCQUFtQixJQUFJLENBQUMsS0FBSyxrQkFBZTs7Ozs7O0FBRzlELDhCQUFrQixJQUFJLGdDQUFnQzs7Ozs7Ozt5QkFHaEMsSUFBSSxDQUFDLFVBQVU7Ozs7Ozs7O0FBQTVCLHFCQUFTOzs7QUFFaEIscUJBQVMsQ0FBQyxpQkFBaUIsR0FBRyxTQUFTLENBQUMsS0FBSztBQUM3QyxtQkFBTyxTQUFTLENBQUMsS0FBSzs7O0FBR3RCLDhCQUFrQixJQUFJLGlCQUFpQjs7Ozs7QUFDdkMsOEJBQWdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLDJIQUFFO0FBQS9CLGlCQUFHOztBQUNWLGdDQUFrQixVQUFRLEdBQUcsU0FBSSxTQUFTLENBQUMsR0FBRyxDQUFDLFVBQUssR0FBRyxNQUFHO2FBQzNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELDhCQUFrQixJQUFJLGtCQUFrQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUk1Qyw4QkFBa0IsSUFBSSxvQkFBb0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUl4QywwQkFBYyxxQ0FFUixJQUFJLENBQUMsTUFBTSx1QkFDbkIsa0JBQWtCO2dEQUtiLGNBQWM7Ozs7Ozs7S0FDdEI7OztTQTFIa0IsUUFBUTs7O3FCQUFSLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQ05SLFNBQVM7V0FBVCxTQUFTOzBCQUFULFNBQVM7OztlQUFULFNBQVM7O1dBQ2YsZUFBQyxDQUFDLEVBQUU7QUFDZixVQUFJLEdBQUcsR0FBRyxFQUFFOztBQUVaLFVBQUksQ0FBQyxZQUFZLEtBQUssRUFBRTtBQUN0QixXQUFHLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxPQUFPO0FBQ3ZCLFdBQUcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUk7QUFDakIsV0FBRyxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsUUFBUTtBQUN6QixXQUFHLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxVQUFVO0FBQzdCLFdBQUcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLFlBQVk7QUFDakMsV0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSztPQUNwQixNQUFNO0FBQ0wsV0FBRyxHQUFHLENBQUM7T0FDUjs7QUFFRCxhQUFPLEdBQUc7S0FDWDs7O1NBaEJrQixTQUFTOzs7cUJBQVQsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUJDQUYsU0FBUzs7SUFFeEIsZUFBZTtXQUFmLGVBQWU7MEJBQWYsZUFBZTs7O2VBQWYsZUFBZTs7V0FDVCxhQUFDLElBQUksRUFBRSxVQUFVO1VBQzFCLE1BQU0sRUFDTixFQUFFOzs7Ozs0Q0FEYSxxQkFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsQ0FBQzs7O0FBQXZFLGtCQUFNO0FBQ04sY0FBRSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztnREFDNUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7Ozs7Ozs7S0FDakM7OztTQUxVLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQ0ZWLE9BQU87Ozs7c0JBQ04sUUFBUTs7OztJQUVOLEtBQUs7QUFDWixXQURPLEtBQUssQ0FDWCxPQUFPLEVBQUU7MEJBREgsS0FBSzs7O0FBR3RCLFFBQUksQ0FBQyxJQUFJLEdBQUcsbUJBQU0sVUFBVSxDQUFDLE9BQU8sQ0FBQyxDQUFDOzs7QUFHdEMsUUFBTSxZQUFZLEdBQUcsRUFBRSxrQkFBa0IsRUFBRSxJQUFJLEVBQUUsQ0FBQztBQUNsRCxVQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUMsQ0FBQztBQUNyQyxRQUFJLENBQUMsU0FBUyxHQUFHLG1CQUFNLFVBQVUsQ0FBQyxZQUFZLENBQUMsQ0FBQztHQUNqRDs7ZUFUa0IsS0FBSzs7V0FXUCxxQkFBQyxLQUFLLEVBQUUsU0FBUztVQUFFLE9BQU8seURBQUcsR0FBRztVQUV6QyxXQUFXLEVBQ1gsU0FBUyxFQUNULGFBQWEsRUFFYixHQUFHOzs7O0FBSkgsdUJBQVcsR0FBRyxPQUFPO0FBQ3JCLHFCQUFTLGFBQVcsS0FBSztBQUN6Qix5QkFBYSxHQUFHLFNBQVMsY0FBWSxTQUFTLEdBQUssRUFBRTs7NENBRXpDLElBQUksQ0FBQyxLQUFLLGFBQVcsV0FBVyxTQUFJLFNBQVMsU0FBSSxhQUFhLENBQUc7OztBQUE3RSxlQUFHO2dEQUdGLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7Ozs7OztLQUN2Qzs7Ozs7Ozs7V0FVSyxlQUFDLEdBQUcsRUFBRTs7O0FBR1YsYUFBTyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQ2pCLElBQUksQ0FDSCxVQUFDLEdBQUc7ZUFBSyxJQUFJLE9BQU8sQ0FDaEIsVUFBQyxPQUFPLEVBQUUsTUFBTSxFQUFLOztBQUVuQixhQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQUMsRUFBRSxHQUFHLEVBQUs7O0FBRXpCLGVBQUcsQ0FBQyxPQUFPLEVBQUU7QUFDYixnQkFBSSxDQUFDLEVBQUU7QUFDTCxvQkFBTSxDQUFDLENBQUMsQ0FBQzthQUNWLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztXQUNwQixDQUFDO1NBQ0gsQ0FDRjtPQUFBLENBQ0osU0FDSyxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQ1osY0FBTSxDQUFDLENBQUM7T0FDVCxDQUFDLENBQUM7S0FDTjs7O1dBRWtCLHNCQUFDLEdBQUc7VUFDZixHQUFHOzs7Ozs0Q0FBUyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0YsR0FBRyxDQUFDLFFBQVE7Ozs7Ozs7S0FDcEI7Ozs7Ozs7Ozs7V0FRaUIscUJBQUMsS0FBSztVQUFFLElBQUkseURBQUcsRUFBRTtVQUFFLE9BQU8seURBQUcsRUFBRTs7VUFJM0MsR0FBRyxFQUVELEdBQUcsa0ZBV0UsQ0FBQyx1RkFRTixHQUFHOzs7OztBQXJCTCxlQUFHLG9CQUFrQixLQUFLO0FBRXhCLGVBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRTs7Ozs7O0FBQ3JCLDZCQUFnQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx1SEFBRTtBQUF4QixlQUFDOztBQUNWLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUU7QUFDcEIsbUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQyxDQUFDO2VBQ3BCLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7O0FBRTlDLG1CQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBTSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFJLENBQUM7ZUFDOUMsTUFBTTtBQUNMLG1CQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBSyxtQkFBTSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUcsQ0FBQztlQUN4QzthQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCw4QkFBZ0IsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsMkhBQUU7QUFBM0IsZUFBQzs7QUFDVixpQkFBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksR0FBRyxNQUFNLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDdkQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVELGVBQUcsV0FBUyw2QkFBSSxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFLLENBQUM7O0FBRTNDLGVBQUcsaUJBQWUsNkJBQUksR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBSyxDQUFDOzs7NENBRWpDLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBM0IsZUFBRztnREFDRixHQUFHLENBQUMsUUFBUTs7Ozs7OztLQUNwQjs7Ozs7Ozs7Ozs7V0FTaUIscUJBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsT0FBTztVQUN6QyxHQUFHLEVBRUQsT0FBTyx1RkFJRixDQUFDLHVGQU9OLEdBQUc7Ozs7O0FBYkwsZUFBRyxlQUFhLEtBQUs7QUFFbkIsbUJBQU8sR0FBRyxFQUFFOzs7Ozs7QUFDbEIsOEJBQWdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLDJIQUFFO0FBQXhCLGVBQUM7O0FBQ1YscUJBQU8sQ0FBQyxJQUFJLENBQUksQ0FBQyxTQUFJLG1CQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRyxDQUFDO2FBQy9DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCw4QkFBZ0IsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsMkhBQUU7QUFBM0IsZUFBQzs7QUFDVixxQkFBTyxDQUFDLElBQUksQ0FBSSxDQUFDLFNBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFHLENBQUM7YUFDcEM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0QsZUFBRyxJQUFJLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7O0FBRXpCLGVBQUcsZ0JBQWMsTUFBTSxNQUFHLENBQUM7Ozs0Q0FFVCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0YsR0FBRzs7Ozs7OztLQUNYOzs7OztXQUdnQixvQkFBQyxHQUFHO1VBQ2IsUUFBUSxFQUdOLEdBQUc7Ozs7QUFITCxvQkFBUSxHQUFHLElBQUksQ0FBQyxJQUFJOztBQUMxQixnQkFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDOzs7NENBRVAsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNGLEdBQUc7Ozs7O0FBRVYsZ0JBQUksQ0FBQyxJQUFJLEdBQUcsUUFBUSxDQUFDOzs7Ozs7OztLQUV4Qjs7O1dBRXNCOzs7Ozs0Q0FDZixJQUFJLENBQUMsS0FBSyxDQUFDLG9CQUFvQixDQUFDOzs7Ozs7O0tBQ3ZDOzs7V0FFWTs7Ozs7NENBQ0wsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7Ozs7Ozs7S0FDNUI7OztXQUVjOzs7Ozs0Q0FDUCxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FBQzs7Ozs7OztLQUM5Qjs7O1dBRWMsd0JBQUMsR0FBRyxFQUFrRDs7O1VBQWhELFFBQVEseURBQUcsVUFBQyxNQUFNLEVBQUssRUFBRTtVQUFFLE9BQU8seURBQUcsVUFBQyxDQUFDLEVBQUssRUFBRTs7QUFDakUsYUFBTyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQ2pCLElBQUksQ0FDSCxVQUFDLEdBQUc7ZUFBSyxJQUFJLE9BQU8sQ0FDaEIsb0JBQU8sT0FBTyxFQUFFLE1BQU07Ozs7O0FBRXBCLG1CQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUNYLEVBQUUsQ0FBQyxRQUFRLEVBQ1YsVUFBQyxNQUFNLEVBQUs7QUFDVixxQkFBRyxDQUFDLEtBQUssRUFBRTtBQUNYLDBCQUFRLENBQUMsTUFBTSxDQUFDO0FBQ2hCLHFCQUFHLENBQUMsTUFBTSxFQUFFO2lCQUNiLENBQUMsQ0FDSCxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUMsQ0FBQyxFQUFLO0FBQ2xCLHlCQUFPLENBQUMsQ0FBQyxDQUFDO2lCQUNYLENBQUMsQ0FDRCxFQUFFLENBQUMsS0FBSyxFQUFFLFlBQU07QUFDZixxQkFBRyxDQUFDLE9BQU8sRUFBRTtBQUNiLHlCQUFPLEVBQUU7aUJBQ1YsQ0FBQzs7Ozs7OztTQUNMLENBQ0Y7T0FBQSxDQUNKLFNBQ0ssQ0FBQyxVQUFDLENBQUMsRUFBSztBQUNaLGNBQU0sQ0FBQyxDQUFDO09BQ1QsQ0FBQyxDQUFDO0tBQ047OztXQUVNLGtCQUFHOzs7QUFDUixhQUFPLElBQUksT0FBTyxDQUNoQixVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUs7O0FBRW5CLGVBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFDLENBQUMsRUFBRSxHQUFHLEVBQUs7QUFDbEMsY0FBSSxDQUFDLEVBQUU7QUFDTCxrQkFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO1dBQ1gsTUFBTTtBQUNMLG1CQUFPLENBQUMsR0FBRyxDQUFDLENBQUM7V0FDZDtTQUNGLENBQUMsQ0FBQztPQUNKLENBQ0YsU0FDTyxDQUNKLFVBQUMsQ0FBQyxFQUFLO0FBQ0wsY0FBTSxDQUFDLENBQUM7T0FDVCxDQUNGLENBQUM7S0FDTDs7O1dBdEtpQixvQkFBQyxJQUFJLEVBQUU7QUFDdkIsYUFBTyx5QkFBTyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxHQUFHLEVBQUUsR0FBRyxDQUFDLENBQUM7S0FDakU7OztTQXpCa0IsS0FBSzs7O3FCQUFMLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNITCxNQUFNO0FBQ2IsV0FETyxNQUFNLENBQ1osVUFBVSxFQUFFOzBCQUROLE1BQU07O0FBRXZCLFFBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVTtBQUM1QixRQUFJLENBQUMsYUFBYSxHQUFHLElBQUk7QUFDekIsUUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQ3BCLFFBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSTtBQUN2QixRQUFJLENBQUMsS0FBSyxHQUFHLENBQUM7QUFDZCxRQUFJLENBQUMsV0FBVyxHQUFHLENBQUM7R0FDckI7O2VBUmtCLE1BQU07O1dBVVosZ0JBQUMsR0FBRzs7OztrQkFFWCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQzs7Ozs7aUJBQ2hDLElBQUksQ0FBQyxhQUFhOzs7Ozs7NENBQ2QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDOzs7aUJBRzFDLElBQUksQ0FBQyxRQUFROzs7Ozs7NENBQ1QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7OztBQUUxQixnQkFBSSxDQUFDLEtBQUssRUFBRTs7QUFFWixnQkFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQyxFQUFFO0FBQ3RDLGtCQUFJLENBQUMsS0FBSyxFQUFFO0FBQ1osa0JBQUksQ0FBQyxXQUFXLEVBQUU7YUFDbkI7Ozs7Ozs7S0FDRjs7O1dBQ0ssaUJBQUc7QUFDUCxVQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7QUFDcEIsWUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO09BQ25DO0tBQ0Y7OztTQS9Ca0IsTUFBTTs7O3FCQUFOLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkNBTCxTQUFTOzs7OzRCQUNWLGVBQWU7OzJCQUNmLGdCQUFnQjs7c0JBQ2xCLFFBQVE7Ozs7SUFFTixNQUFNO0FBQ2IsV0FETyxNQUFNLEdBQ1Y7MEJBREksTUFBTTs7QUFFdkIsUUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFO0FBQ2hCLFFBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRTtBQUNuQixRQUFJLENBQUMsUUFBUSxHQUFHLElBQUk7R0FDckI7Ozs7ZUFMa0IsTUFBTTs7V0FRWCx1QkFBQyxPQUFPLEVBQUU7QUFDdEIsVUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDckMsVUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztLQUNuQzs7O1dBRVc7OztVQUFDLElBQUkseURBQUcsRUFBRTtVQUFFLEVBQUUseURBQUc7Ozs7Ozs7O09BQWM7VUFDckMsR0FBRyxFQU9ELEdBQUc7Ozs7QUFQTCxlQUFHLEdBQUc7QUFDUixxQkFBTyxFQUFFLDBCQUFRO2FBQ2xCOztBQUVELGdCQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7Ozs7NENBR2IsRUFBRSxFQUFFOzs7QUFBaEIsZUFBRzs7QUFFUCxrQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsa0JBQUksRUFBRSxTQUFTO0FBQ2YsbUJBQUssRUFBRSxJQUFJO0FBQ1gsb0JBQU0sRUFBRSxHQUFHO2FBQ1osQ0FBQzs7Ozs7Ozs7QUFFRixrQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsa0JBQUksRUFBRSxPQUFPO0FBQ2IsbUJBQUssRUFBRSxJQUFJO0FBQ1gsb0JBQU0sRUFBRSxtQkFBVSxLQUFLLGdCQUFHO2FBQzNCLENBQUM7Ozs7OztBQUdGLGdCQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtBQUM5QixvQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsd0JBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU07ZUFDL0IsQ0FBQzthQUNIOztBQUVELGVBQUcsQ0FBQyxTQUFTLEdBQUcsSUFBSSxJQUFJLEVBQUU7O0FBRTFCLDhCQUFLLE1BQU0sQ0FBQyxHQUFHLENBQUM7OztBQUdoQixnQkFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOzs7Ozs7OztLQUV4Qjs7Ozs7O1dBSXFCLHlCQUFDLEdBQUcsRUFBRSxFQUFFO1VBRXRCLEdBQUcsRUFHRCxHQUFHOzs7Ozs0Q0FKRSxHQUFHLENBQUMsT0FBTyxFQUFFOzs7Ozs7Ozs7NENBQ1IsR0FBRyxDQUFDLElBQUksRUFBRTs7O0FBQXRCLGVBQUc7Ozs0Q0FHVyxFQUFFLENBQUMsR0FBRyxDQUFDOzs7QUFBbkIsZUFBRzs7QUFDUCxnQkFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7O0FBRWxCLGdCQUFJLENBQUMsTUFBTSxnQkFBRzs7Ozs7OztBQUdsQixlQUFHLENBQUMsS0FBSyxFQUFFOzs7Ozs7O0tBQ1o7OztXQUVRLGtCQUFDLFNBQVMsRUFBRTtBQUNuQixVQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7S0FDakM7OztXQUVNLGdCQUFDLFNBQVMsRUFBRTtBQUNqQixVQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxtQkFBVSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7S0FDaEQ7OztXQUVZLHdCQUFHO0FBQ2QsVUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBQztlQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUU7T0FBQSxDQUFDO0FBQ3pELFVBQUksUUFBUSxHQUFHLEtBQUs7Ozs7OztBQUNwQiw2QkFBZ0IsSUFBSSxDQUFDLE1BQU0sOEhBQUU7Y0FBcEIsR0FBRzs7QUFDVixjQUFJLEdBQUcsQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO0FBQ3hCLG9CQUFRLEdBQUcsSUFBSTtBQUNmLGtCQUFLO1dBQ047U0FDRjs7Ozs7Ozs7Ozs7Ozs7OztBQUNELGFBQU8sUUFBUSxJQUFJLFFBQVE7S0FDNUI7OztXQUVPLG1CQUFHOztBQUVULFVBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO0FBQ3ZCLGNBQU0sSUFBSSxxQkFBTyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztPQUNwQztBQUNELGFBQU8sSUFBSSxDQUFDLE1BQU07S0FDbkI7OztTQTdGa0IsTUFBTTs7O3FCQUFOLE1BQU07O0lBZ0dyQixRQUFRO0FBQ0EsV0FEUixRQUFRLENBQ0MsT0FBTyxFQUFFOzBCQURsQixRQUFROztBQUVWLFFBQUksQ0FBQyxNQUFNLEdBQUc7QUFDWixXQUFLLEVBQUUsQ0FBQztBQUNSLGFBQU8sRUFBRSxDQUFDO0FBQ1YsV0FBSyxFQUFFLENBQUM7QUFDUixhQUFPLEVBQUUsT0FBTztLQUNqQjtBQUNELFFBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSTtHQUN0Qjs7ZUFURyxRQUFROztXQVdKLGlCQUFDLFNBQVMsRUFBRTtBQUNsQixVQUFJLFNBQVMsRUFBRTtBQUNiLFlBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQztPQUMxQjtBQUNELFVBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO0FBQ3JCLFVBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0tBQ3BCOzs7V0FFSyxlQUFDLFNBQVMsRUFBRTs7QUFFaEIsVUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxFQUFFO0FBQ2hFLFlBQUksU0FBUyxJQUFJLFNBQVMsS0FBSyxFQUFFLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtBQUNyRCxjQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUM7QUFDMUIsY0FBSSxDQUFDLFNBQVMsR0FBRyxTQUFTO1NBQzNCO09BQ0Y7QUFDRCxVQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtBQUNuQixVQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtLQUNwQjs7O1dBRUcsYUFBQyxTQUFTLEVBQUUsU0FBUywwQ0FBMEM7QUFDakUsVUFBSSxHQUFHLEdBQUc7QUFDUixlQUFPLEVBQUUsU0FBUztBQUNsQixlQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQzVCLGVBQU8sRUFBRSxTQUFTO0FBQ2xCLGlCQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7T0FDdEI7QUFDRCx3QkFBSyxNQUFNLENBQUMsR0FBRyxDQUFDO0tBQ2pCOzs7V0FFWSx3QkFBRztBQUNkLGFBQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLO0tBQ3pCOzs7U0EzQ0csUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztzQkNyR0EsUUFBUTs7Ozs7Ozs7Ozs7OztxQkFVUCxTQUFlLFVBQVUsQ0FDdEMsR0FBRyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQVMsT0FBTyxFQUFFLE9BQU87TUFBOUIsS0FBSyxnQkFBTCxLQUFLLEdBQUcsSUFBSTtNQUVoQixZQUFZLEVBQ1osWUFBWSxFQUVaLGNBQWM7Ozs7OztBQUhkLG9CQUFZLEdBQUcsRUFBRTtBQUNqQixvQkFBWSxHQUFHLEVBQUU7O0FBRWpCLHNCQUFjLEdBQUcsU0FBakIsY0FBYyxDQUFJLElBQUksRUFBRSxPQUFPLEVBQUs7QUFDeEMsY0FBTSxRQUFRLEdBQUcsb0JBQUUsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDOztBQUVuQyxjQUFJLG9CQUFFLFdBQVcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLEVBQUU7QUFDOUMsbUJBQU8sUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDO1dBQzFCOztBQUVELGlCQUFPLFFBQVEsQ0FBQztTQUNqQjs7O0FBR0QsV0FBRyxDQUFDLE9BQU8sQ0FBQyxVQUFDLElBQUksRUFBSztBQUNwQixzQkFBWSxDQUFDLElBQUksQ0FBQztBQUNoQixrQkFBTSxFQUFFLGNBQWMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDO0FBQ25DLGNBQUUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ2YsaUJBQUssRUFBRTs7Ozs7QUFLTCxrQkFBSSxFQUFFLEtBQUs7YUFDWjtXQUNGLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQzs7QUFFSCxXQUFHLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFLO0FBQ3BCLHNCQUFZLENBQUMsSUFBSSxDQUFDO0FBQ2hCLGtCQUFNLEVBQUUsY0FBYyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUM7QUFDbkMsY0FBRSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDZixpQkFBSyxFQUFFOzs7OztBQUtMLGtCQUFJLEVBQUUsS0FBSzthQUNaO1dBQ0YsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDOzs7QUFHSCxvQkFBWSxDQUFDLE9BQU8sQ0FBQyxVQUFDLE9BQU8sRUFBSztBQUNoQyxzQkFBWSxDQUFDLE9BQU8sQ0FBQyxVQUFDLE9BQU8sRUFBSztBQUNoQyxnQkFBSSxvQkFBRSxPQUFPLENBQUMsT0FBTyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUMsTUFBTSxDQUFDLEVBQUU7O0FBRTdDLHFCQUFPLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7QUFDMUIscUJBQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQzthQUMzQjtXQUNGLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQzs7Ozt3Q0FHRyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsb0JBQU8sSUFBSTs7OztzQkFDeEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSzs7Ozs7O2dEQUNyQixPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDOzs7Ozs7O1NBRXRDLENBQUMsQ0FBQzs7Ozt3Q0FHRyxPQUFPLENBQUMsR0FBRyxDQUFDLFlBQVksQ0FBQyxHQUFHLENBQUMsb0JBQU8sSUFBSTs7OztzQkFDeEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLEtBQUssS0FBSzs7Ozs7O2dEQUNyQixPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDOzs7Ozs7O1NBRXRDLENBQUMsQ0FBQzs7Ozs7OztDQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQy9Fb0IsUUFBUTtXQUFSLFFBQVE7MEJBQVIsUUFBUTs7O2VBQVIsUUFBUTs7OztXQUVaLGlCQUFDLElBQUksRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFO0FBQ3JDLFVBQUksVUFBVSxLQUFLLFNBQVMsRUFBRTtBQUFFLGtCQUFVLEdBQUcsRUFBRTtPQUFFO0FBQ2pELFVBQUksU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsRUFBRSxDQUFDO0FBQzlCLFVBQUksS0FBSyxHQUFHLENBQUM7QUFDYixVQUFJLEdBQUcsR0FBRyxFQUFFO0FBQ1osV0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLFNBQVMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDekMsWUFBSSxDQUFDLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixZQUFJLENBQUMsQ0FBQyxNQUFNLEdBQUcsQ0FBQyxFQUFFLEtBQUssRUFBRSxNQUNwQixLQUFLLElBQUksQ0FBQztBQUNmLFlBQUksS0FBSyxHQUFHLEdBQUcsRUFBRTtBQUNmLGlCQUFPLEdBQUcsR0FBRyxVQUFVO1NBQ3hCO0FBQ0QsV0FBRyxJQUFJLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO09BQ3RCO0FBQ0QsYUFBTyxJQUFJO0tBQ1o7Ozs7O1dBR1csY0FBQyxJQUFJLEVBQUU7QUFDakIsYUFBTyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQyxPQUFPLENBQUMsWUFBWSxFQUFFLElBQUksQ0FBQyxDQUFDLE1BQU07S0FDbkU7OztXQUVnQixtQkFBQyxNQUFNLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRTtBQUN0QyxVQUFNLEdBQUcsR0FBRyxHQUFHOztBQUVmLFVBQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsVUFBQyxJQUFJLEVBQUUsT0FBTztlQUFLLElBQUksR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO09BQUEsRUFBRSxFQUFFLENBQUM7O0FBRTVFLFVBQU0sU0FBUyxHQUFHLFNBQVMsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDO0FBQ3RDLFVBQUksTUFBTSxHQUFHLEVBQUU7QUFDZixVQUFJLElBQUksR0FBRyxFQUFFOzs7QUFHYixVQUFJO0FBQ0YsaUJBQVMsQ0FBQyxNQUFNLENBQUMsVUFBQyxJQUFJLEVBQUUsT0FBTyxFQUFLOztBQUVsQyxjQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUcsTUFBTSxFQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQzdELGNBQU0sSUFBSSxHQUFHLENBQUMsSUFBSSxLQUFLLEVBQUUsR0FBRyxJQUFJLEdBQUcsR0FBRyxHQUFHLEVBQUUsSUFBSSxPQUFPO0FBQ3RELGNBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsR0FBRyxNQUFNLEVBQUU7QUFDaEMsa0JBQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0FBQ2pCLGdCQUFJLEdBQUcsT0FBTztBQUNkLG1CQUFPLEVBQUU7V0FDVixNQUFNO0FBQ0wsZ0JBQUksR0FBRyxJQUFJO0FBQ1gsbUJBQU8sSUFBSTtXQUNaO1NBQ0YsRUFBRSxFQUFFLENBQUM7T0FDUCxDQUFDLE9BQU8sQ0FBQyxFQUFFOztBQUVWLFlBQUksQ0FBQyxDQUFDLE9BQU8sS0FBSyxPQUFPLEVBQUUsT0FBTTtPQUNsQzs7QUFFRCxZQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs7QUFFakIsV0FBSyxJQUFJLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDcEMsY0FBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRTtPQUM3QztLQUNGOzs7U0ExRGtCLFFBQVE7OztxQkFBUixRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0QkNBTixlQUFlOzsyQkFDaEIsY0FBYzs7QUFFN0IsSUFBTSxJQUFJLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOztBQUNsRSxJQUFNLE9BQU8sR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxTQUFTLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUM7OztBQUV4RSxJQUFNLFdBQVcsR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxhQUFhLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUM7O0FBQ2hGLElBQU0sYUFBYSxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLGVBQWUsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7O0FBRXBGLElBQU0sT0FBTyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFNBQVMsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7O0FBRS9FLElBQUkscUJBQU8sUUFBUSxFQUFFO0FBQ25CLHVCQUFPLE9BQU8sQ0FBQyxTQUFTLEVBQUUsWUFBTTtBQUM5QixXQUFPLE9BQU8sQ0FBQyxJQUFJLEVBQUU7R0FDdEIsQ0FBQyxDQUFDO0FBQ0gsdUJBQU8sT0FBTyxxQkFDTCxvQkFBb0IsRUFBQztRQUNwQixHQUFHOzs7OzswQ0FBUyxhQUFhLENBQUMsYUFBYSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQ3hEOztBQUVFLGtCQUFNLEVBQUU7QUFDTixpQkFBRyxFQUFFO0FBQ0gsb0JBQUksRUFBQyxlQUFlO0FBQ3BCLG9CQUFJLEVBQUMsZUFBZTtBQUNwQixtQkFBRyxFQUFFLGNBQWM7QUFDbkIsb0JBQUksRUFBRSxlQUFlO2VBQ3RCO0FBQ0QsbUJBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxFQUFDLEtBQUssRUFBRSxnQkFBZ0IsRUFBRSxFQUFFLEVBQUUsYUFBYSxFQUFDLEVBQUM7YUFDN0Q7V0FDRixFQUNEO0FBQ0Usb0JBQVEsRUFBRTtBQUNSLGlCQUFHLEVBQUMsQ0FBQztBQUNMLGtCQUFJLEVBQUMsV0FBVztBQUNoQixrQkFBSSxFQUFDLFdBQVc7QUFDaEIsaUJBQUcsRUFBRSxVQUFVO0FBQ2Ysa0JBQUksRUFBRSxXQUFXO0FBQ2pCLG1CQUFLLEVBQUUsUUFBUTthQUNoQjtXQUNGLENBQ0YsQ0FBQyxDQUFDLE9BQU8sRUFBRTs7O0FBdkJOLGFBQUc7OENBd0JGLEdBQUc7Ozs7Ozs7R0FDWCxFQUNELENBQUM7O0FBRUgsdUJBQU8sT0FBTyxDQUFDLG1CQUFtQixFQUFFOzs7OzhDQUMzQixhQUFhLENBQUMsSUFBSSxFQUFFOzs7Ozs7O0dBQzVCLENBQUMsQ0FBQztDQUNKOztBQUVELElBQUkscUJBQU8sUUFBUSxFQUFFO0FBQ25CLHVCQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcbi8vICAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4vLyAgIHJlcy5lbmQoYEhlbGxvIHdvcmxkIGZyb206ICR7TWV0ZW9yLnJlbGVhc2V9YCk7XHJcbi8vIH0pO1xyXG5cclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnO1xyXG5cclxuLy8gUmVxdWlyZXMgbXVsdGlwYXJ0eSBcclxuaW1wb3J0IG11bHRpcGFydHkgZnJvbSAnY29ubmVjdC1tdWx0aXBhcnR5JztcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9ucyc7XHJcbmxldCBtdWx0aXBhcnR5TWlkZGxld2FyZSA9IG11bHRpcGFydHkoKTtcclxuXHJcbmNvbnN0IHJvdXRlID0gJy91cGxvYWQvaW1hZ2UnO1xyXG5cclxuLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCBmdWMudXBsb2FkRmlsZSApO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgbXVsdGlwYXJ0eU1pZGRsZXdhcmUpO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgKHJlcSwgcmVzcCkgPT4ge1xyXG4gIC8vIGRvbid0IGZvcmdldCB0byBkZWxldGUgYWxsIHJlcS5maWxlcyB3aGVuIGRvbmVcclxuXHJcbiAgY29uc3QgcmVhZGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy5yZWFkRmlsZSk7XHJcbiAgY29uc3Qgd3JpdGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy53cml0ZUZpbGUpO1xyXG4gIGNvbnN0IHVwbG9hZElkID0gdW5pcWlkKCk7XHJcblxyXG4gIGZvciAobGV0IGZpbGUgb2YgcmVxLmZpbGVzLmZpbGUpIHtcclxuICAgIGNvbnN0IGRhdGEgPSByZWFkZXIoZmlsZS5wYXRoKTtcclxuICAgIC8vIOODleOCoeOCpOODq+WQjeOBrumHjeikh+OCkumBv+OBkeOCi+OBn+OCgeOAgeS4gOaEj+OBruODleOCoeOCpOODq+WQjeOCkuS9nOaIkOOBmeOCi1xyXG4gICAgLy8g5qW95aSp44Gu44OV44Kh44Kk44Or5ZCN5paH5a2X5pWw5Yi26ZmQMjDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBmaWxlbmFtZSA9IGAke3VuaXFpZCgpfS5qcGdgXHJcblxyXG4gICAgLy8gc2V0IHRoZSBjb3JyZWN0IHBhdGggZm9yIHRoZSBmaWxlIG5vdCB0aGUgdGVtcG9yYXJ5IG9uZSBmcm9tIHRoZSBBUEk6XHJcbiAgICBsZXQgc2F2ZVBhdGggPSByZXEuYm9keS5pbWFnZWRpciArICcvJyArIGZpbGVuYW1lO1xyXG5cclxuICAgIC8vIGNvcHkgdGhlIGRhdGEgZnJvbSB0aGUgcmVxLmZpbGVzLmZpbGUucGF0aCBhbmQgcGFzdGUgaXQgdG8gZmlsZS5wYXRoXHJcblxyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ57WQ5p6c44KS6KiY6Yyy44GZ44KLXHJcbiAgICBsZXQgZG9jID0ge1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICAgIGNsaWVudEZpbGVOYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgIHVwbG9hZGVkRmlsZU5hbWU6IGZpbGVuYW1lXHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICB0cnl7XHJcbiAgICAgIHdyaXRlcihzYXZlUGF0aCwgZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaChlcnIpe1xyXG4gICAgICBkb2MuZXJyb3IgPSBlcnI7XHJcbiAgICB9XHJcbiAgICBVcGxvYWRzLmluc2VydChkb2MpO1xyXG5cclxuICAgIGRlbGV0ZSBmaWxlO1xyXG5cclxuICB9O1xyXG4gIHJlc3Aud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgc2F2ZURpcjogcmVxLmJvZHkuaW1hZ2VkaXJcclxuICB9KSk7XHJcblxyXG59KTsiLCJpbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0bydcclxuXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBSZXBvcnQgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBHcm91cCxcclxuICBHcm91cEZhY3RvcnlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzJ1xyXG5pbXBvcnQge1xyXG4gIEZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlbWlnJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5taWdyYXRlYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIC8vIHNldHVwIGdyb3VwXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgRmlsdGVyKGNvbmZpZy5zcmNGaWx0ZXJJZClcclxuICAgIC8vIGxldCBwbHVnID0gZ3JvdXAuZ2V0UGx1ZygpO1xyXG5cclxuICAgIC8vIGNoZWNraW5nIGNvbm5lY3Rpb25cclxuICAgIC8vXHJcblxyXG4gICAgbGV0IHRlc3RRdWVyeSA9ICdTSE9XIERBVEFCQVNFUydcclxuXHJcbiAgICBsZXQgZHN0RGIgPSBuZXcgTXlTUUwoY29uZmlnLmRzdC5jcmVkKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnQ29ubmVjdCB0byBEZXN0aW5hdGlvbicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBhd2FpdCBkc3REYi5xdWVyeSh0ZXN0UXVlcnkpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcHJvY2VzcyBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICAvL1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnU2VsZWN0IGxvb3AgaW4gc291cmNlJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICBtb2JpbGVOdWxsOiBhc3luYyAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIC8vIOWApOOCkuaVtOeQhlxyXG4gICAgICAgICAgICAvLyBmb3IgKGxldCBrZXkgb2YgT2JqZWN0LmtleXMocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyAgIGlmIChyZWNvcmRba2V5XSA9PT0gbnVsbCk7XHJcbiAgICAgICAgICAgIC8vICAgZWxzZSBpZiAocmVjb3JkW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAvLyDml6Xku5jjgpLlpInmj5tcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gTXlTUUwuZm9ybWF0RGF0ZShyZWNvcmRba2V5XSk7XHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IGBcIiR7cmVjb3JkW2tleV19XCJgO1xyXG4gICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyIOOBq+S/neWtmFxyXG5cclxuICAgICAgICAgICAgbGV0IHNxbCA9IGBcclxuXHJcbiAgICAgICAgICAgICAgICBJTlNFUlQgZHRiX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAoIFxcYGN1c3RvbWVyX2lkXFxgLCBcXGBzdGF0dXNcXGAsIFxcYHNleFxcYCwgXFxgam9iXFxgLCBcXGBjb3VudHJ5X2lkXFxgLCBcXGBwcmVmXFxgLCBcXGBuYW1lMDFcXGAsIFxcYG5hbWUwMlxcYCwgXFxga2FuYTAxXFxgLCBcXGBrYW5hMDJcXGAsIFxcYGNvbXBhbnlfbmFtZVxcYCwgXFxgemlwMDFcXGAsIFxcYHppcDAyXFxgLCBcXGB6aXBjb2RlXFxgLCBcXGBhZGRyMDFcXGAsIFxcYGFkZHIwMlxcYCwgXFxgZW1haWxcXGAsIFxcYHRlbDAxXFxgLCBcXGB0ZWwwMlxcYCwgXFxgdGVsMDNcXGAsIFxcYGZheDAxXFxgLCBcXGBmYXgwMlxcYCwgXFxgZmF4MDNcXGAsIFxcYGJpcnRoXFxgLCBcXGBwYXNzd29yZFxcYCwgXFxgc2FsdFxcYCwgXFxgc2VjcmV0X2tleVxcYCwgXFxgZmlyc3RfYnV5X2RhdGVcXGAsIFxcYGxhc3RfYnV5X2RhdGVcXGAsIFxcYGJ1eV90aW1lc1xcYCwgXFxgYnV5X3RvdGFsXFxgLCBcXGBub3RlXFxgLCBcXGBjcmVhdGVfZGF0ZVxcYCwgXFxgdXBkYXRlX2RhdGVcXGAsIFxcYGRlbF9mbGdcXGAgKVxyXG5cclxuICAgICAgICAgICAgICAgIFZBTFVFUyggJHtyZWNvcmQuY3VzdG9tZXJfaWR9ICwgJHtyZWNvcmQuc3RhdHVzfSAsICR7cmVjb3JkLnNleH0gLCAke3JlY29yZC5qb2J9ICwgJHtyZWNvcmQuY291bnRyeV9pZH0gLCAke3JlY29yZC5wcmVmfSAsICR7cmVjb3JkLm5hbWUwMX0gLCAke3JlY29yZC5uYW1lMDJ9ICwgJHtyZWNvcmQua2FuYTAxfSAsICR7cmVjb3JkLmthbmEwMn0gLCAke3JlY29yZC5jb21wYW55X25hbWV9ICwgJHtyZWNvcmQuemlwMDF9ICwgJHtyZWNvcmQuemlwMDJ9ICwgJHtyZWNvcmQuemlwY29kZX0gLCAke3JlY29yZC5hZGRyMDF9ICwgJHtyZWNvcmQuYWRkcjAyfSAsICR7cmVjb3JkLmVtYWlsfSAsICR7cmVjb3JkLnRlbDAxfSAsICR7cmVjb3JkLnRlbDAyfSAsICR7cmVjb3JkLnRlbDAzfSAsICR7cmVjb3JkLmZheDAxfSAsICR7cmVjb3JkLmZheDAyfSAsICR7cmVjb3JkLmZheDAzfSAsICR7cmVjb3JkLmJpcnRofSAsICR7cmVjb3JkLnBhc3N3b3JkfSAsICR7cmVjb3JkLnNhbHR9ICwgJHtyZWNvcmQuc2VjcmV0X2tleX0gLCAke3JlY29yZC5maXJzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5sYXN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmJ1eV90aW1lc30gLCAke3JlY29yZC5idXlfdG90YWx9ICwgJHtyZWNvcmQubm90ZX0gLCAke3JlY29yZC5jcmVhdGVfZGF0ZX0gLCAke3JlY29yZC51cGRhdGVfZGF0ZX0gLCAke3JlY29yZC5kZWxfZmxnfSApXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBzdGF0dXM6IHJlY29yZC5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgIHNleDogcmVjb3JkLnNleCxcclxuICAgICAgICAgICAgICAgICAgam9iOiByZWNvcmQuam9iLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIGVtYWlsOiByZWNvcmQuZW1haWwsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGJpcnRoOiByZWNvcmQuYmlydGgsXHJcbiAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiByZWNvcmQucGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICAgIHNhbHQ6IHJlY29yZC5zYWx0LFxyXG4gICAgICAgICAgICAgICAgICBzZWNyZXRfa2V5OiByZWNvcmQuc2VjcmV0X2tleSxcclxuICAgICAgICAgICAgICAgICAgZmlyc3RfYnV5X2RhdGU6IHJlY29yZC5maXJzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgbGFzdF9idXlfZGF0ZTogcmVjb3JkLmxhc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90aW1lczogcmVjb3JkLmJ1eV90aW1lcyxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RvdGFsOiByZWNvcmQuYnV5X3RvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBub3RlOiByZWNvcmQubm90ZSxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lcl9hZGRyZXNzXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyX2FkZHJlc3MnLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2FkZHJlc3NfaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOODoeODq+ODnuOCrOODl+ODqeOCsOOCpOODsyBwbGdfbWFpbG1hZ2FfY3VzdG9tZXJcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfbWFpbG1hZ2FfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGlkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBtYWlsbWFnYV9mbGc6IHJlY29yZC5tYWlsbWFnYV9mbGcsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjgq/jg7zjg53jg7PnmbrooYzvvIhFQ0NVQkUy44Gu44Od44Kk44Oz44OI6YKE5YWD77yJXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uQ2QgPSBjcnlwdG8ucmFuZG9tQnl0ZXMoOCkudG9TdHJpbmcoJ2Jhc2U2NCcpLnN1YnN0cmluZygwLCAxMSlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25OYW1lID0gYCR7cmVjb3JkLm5hbWUwMX0gJHtyZWNvcmQubmFtZTAyfSDmp5gg44GU5YSq5b6F44Kv44O844Od44OzIOS8muWToeeVquWPtzoke3JlY29yZC5jdXN0b21lcl9pZH1gXHJcblxyXG4gICAgICAgICAgICBsZXQgZGlzY291bnRQcmljZSA9IHJlY29yZC5wb2ludCArIDUwMFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX2NvdXBvbicsIHtcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fY2Q6IGNvdXBvbkNkLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdHlwZTogMywgLy8g5YWo5ZWG5ZOBXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9uYW1lOiBjb3Vwb25OYW1lLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF90eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdXNlX3RpbWU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9yZWxlYXNlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9wcmljZTogZGlzY291bnRQcmljZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcmF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgZW5hYmxlX2ZsYWc6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9tZW1iZXI6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9sb3dlcl9saW1pdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX2Zyb21fZGF0ZTogJzIwMTgtMDQtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfdG9fZGF0ZTogJzIwMTktMDUtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiAwXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyAnY3ViZW1pZy5zZXJ2ZXJDaGVjaycgKHByb2ZpbGUpIHtcclxuICAgIGxldCBkYiA9IG5ldyBNeVNRTChwcm9maWxlKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGRiLnF1ZXJ5KCdTSE9XIERBVEFCQVNFUycpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IHsgTW9uZ29Db2xsZWN0aW9uIH0gZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL21vbmdvJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuY29sbGVjdGlvbidcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZmluZGBdIChwbHVnLCBxdWVyeSA9IHt9LCBwcm9qZWN0aW9uID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5maW5kKHF1ZXJ5LCB7cHJvamVjdGlvbjogcHJvamVjdGlvbn0pLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmFnZ3JlZ2F0ZWBdIChwbHVnLCBxdWVyeSA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuYWdncmVnYXRlKHF1ZXJ5KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuaXRlbXMnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z44Kz44Os44Kv44K344On44Oz5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44G+44GZ44CCXHJcbiAgICogQHBhcmFtXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uc2V0SW1hZ2VgXSAocGx1ZywgdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGxldCB1cGxvYWRlZCA9IGF3YWl0IGl0ZW1jb24uc2V0SW1hZ2UodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICAgIHJldHVybiB1cGxvYWRlZFxyXG4gIH0sXHJcblxyXG4gIC8qKlxyXG4gICAqIOOCouOCpOODhuODoOaDheWgseODh+ODvOOCv+ODmeODvOOCueOBrueUu+WDj+eZu+mMsuOCkuWJiumZpOOBmeOCi++8iOeUu+WDj+iHquS9k+OBr+WJiumZpOOBl+OBquOBhO+8iVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LmNsZWFuSW1hZ2VgXSAocGx1ZywgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5jbGVhbkltYWdlKG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgXyBmcm9tICdsb2Rhc2gnO1xuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnO1xuaW1wb3J0IHtcbiAgTW9uZ29EQkZpbHRlcixcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJztcbmltcG9ydCB7XG4gIEN1YmUzQXBpLFxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvY3ViZTNhcGknO1xuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCc7XG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJztcblxuXG5jb25zdCB0YWcgPSAnY3ViZSc7XG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAvL1xuICAvLyDjgqvjg4bjgrTjg6rmm7TmlrBcblxuICBhc3luYyBbYCR7dGFnfS5jYXRlZ29yeWBdIChjb25maWcpIHtcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcbiAgICBjb25zdCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XG5cbiAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpO1xuICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKCk7XG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQik7XG5cbiAgICBjb25zdCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQik7XG4gICAgY29uc3QgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKTtcblxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcbiAgICAgICfllYblk4Hjgqvjg4bjgrTjg6rjga7mm7TmlrAnLFxuICAgICAgYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XG4gICAgICAgICAgVVBEQVRFOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xuXG4gICAgICAgICAgICAvLyDllYblk4Hjgavjgqvjg4bjgrTjg6rjg7zjg4fjg7zjgr/jgYzoqJjpjLLjgZXjgozjgabjgYTjgozjgbDlh6bnkIbjgZnjgotcbiAgICAgICAgICAgIGlmIChfLmlzQXJyYXkoaXRlbS5tYWxsLnNoYXJha3VTaG9wLmNhdGVnb3JpZXMpKSB7XG5cbiAgICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgICAvLyDllYblk4Hmg4XloLHjg4fjg7zjgr/jg5njg7zjgrnjgavoqJjpjLLjgZXjgozjgZ/llYblk4Hjgqvjg4bjgrTjg6rjg7zmg4XloLHjgpLjgIHjg6Ljg7zjg6vjgavpgannlKjjgZnjgotcbiAgICAgICAgICAgICAgICBjb25zdCByZXN1bHRzID0gYXdhaXQgYXBpLm1vZGlmeUNhdGVnb3J5KFxuICAgICAgICAgICAgICAgICAgaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfaWQsXG4gICAgICAgICAgICAgICAgICBpdGVtLm1hbGwuc2hhcmFrdVNob3AuY2F0ZWdvcmllcyxcbiAgICAgICAgICAgICAgICApO1xuXG4gICAgICAgICAgICAgICAgLy8gU1FM44Kv44Ko44Oq57WQ5p6c44KS6KiY6YyyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKHJlc3VsdHMpO1xuICAgICAgICAgICAgICB9XG4gICAgICAgICAgICAgIGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcbiAgICAgICAgICAgICAgfVxuXG4gICAgICAgICAgICB9XG5cbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XG5cbiAgfSxcblxuICAvL1xuICAvLyDlnKjluqvmm7TmlrBcblxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVTdG9ja2BdIChjb25maWcpIHtcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcbiAgICBjb25zdCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XG5cbiAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpO1xuICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKCk7XG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQik7XG5cbiAgICBjb25zdCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQik7XG4gICAgY29uc3QgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKTtcblxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcbiAgICAgICflnKjluqvjga7mm7TmlrAnLFxuICAgICAgYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XG5cbiAgICAgICAgICBVUERBVEU6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKTtcbiAgICAgICAgICAgIGF3YWl0IGFwaS51cGRhdGVTdG9jayhpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCwgcXVhbnRpdHkpO1xuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuXG4gICAgICAgIHJldHVybiByZXM7XG4gICAgICB9LFxuICAgICk7XG5cbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKTtcbiAgfSxcblxuICAvL1xuICAvLyDllYblk4Hmg4XloLHnmbvpjLLjgajmm7TmlrBcblxuICBhc3luYyBbYCR7dGFnfS5leGhpYkl0ZW1gXSAoY29uZmlnKSB7XG4gICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKTtcbiAgICBjb25zdCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQik7XG4gICAgY29uc3QgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKTtcblxuICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKCk7XG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQik7XG5cbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcbiAgICBjb25zdCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XG5cbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXG4gICAgICAnRUNDVUJFM+OBuOOBruWVhuWTgeeZu+mMsicsXG4gICAgICBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcbiAgICAgICAgICBJTlNFUlQ6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICBjb25zdCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb247XG5cbiAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgIGNvbnN0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcudXBkYXRlSXRlbSwgaXRlbSk7XG5cbiAgICAgICAgICAgICAgY29uc3QgaW5zZXJ0UmVzID0gYXdhaXQgYXBpLnByb2R1Y3RDcmVhdGUoY3ViZUl0ZW0pO1xuXG4gICAgICAgICAgICAgIC8vIGl0ZW0g44OH44O844K/44OZ44O844K544G444Gu55m76YyyXG4gICAgICAgICAgICAgIGF3YWl0IGNvbC51cGRhdGUoe1xuICAgICAgICAgICAgICAgIF9pZDogaXRlbS5faWQsXG4gICAgICAgICAgICAgIH0sIHtcbiAgICAgICAgICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X2lkLFxuICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCc6IGluc2VydFJlcy5yZXMucHJvZHVjdF9jbGFzc19pZCxcbiAgICAgICAgICAgICAgICAgICdtYWxsLnNoYXJha3VTaG9wLnByb2R1Y3Rfc3RvY2tfaWQnOiBpbnNlcnRSZXMucmVzLnByb2R1Y3Rfc3RvY2tfaWQsXG4gICAgICAgICAgICAgICAgfSxcbiAgICAgICAgICAgICAgfSk7XG5cbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKCk7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcbiAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxuICAgICAgJ0VDQ1VCRTPllYblk4Hmg4XloLHjga7mm7TmlrAnLFxuICAgICAgYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XG4gICAgICAgICAgVVBEQVRFOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgY29sID0gY29udGV4dC5jb2xsZWN0aW9uO1xuXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBjb25zdCBjdWJlSXRlbSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnLnVwZGF0ZUl0ZW0sIGl0ZW0pO1xuXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0SW1hZ2VVcGRhdGUoY3ViZUl0ZW0pO1xuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSk7XG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VGFnVXBkYXRlKGN1YmVJdGVtKTtcblxuICAgICAgICAgICAgICBjb25zdCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKTtcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSk7XG5cbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKCk7XG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcbiAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XG4gIH0sXG5cbn0pO1xuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuaW1wb3J0IGljb252IGZyb20gJ2ljb252LWxpdGUnXHJcbmltcG9ydCBjc3YgZnJvbSAnY3N2J1xyXG5pbXBvcnQgeyBUcmFuc2Zvcm0sIFdyaXRhYmxlIH0gZnJvbSAnc3RyZWFtJ1xyXG5cclxuaW1wb3J0IEZpYmVyIGZyb20gJ2ZpYmVycydcclxuaW1wb3J0IFJvYm90aW4gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL3JvYm90aW4nXHJcblxyXG5jb25zdCB0YWcgPSAncm9ib3RpbidcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ub3JkZXIuZXhwb3J0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnUm9ib3QtaW4g5Y+X5rOoQ1NWIOWHuuWKmycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyLndvcmtkaXJ9YDtcclxuICAgICAgICBjb25zdCB3b3JrZGlyRXhwb3J0ID0gYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXIud29ya2RpckV4cG9ydH1gO1xyXG4gICAgICAgIGNvbnN0IG9yZGVyQ3N2RXhwb3J0ID0gYCR7Y29uZmlnLm9yZGVyLm9yZGVyY3N2RXhwb3J0fS5jc3ZgO1xyXG4gICAgICAgIFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAvLyDoqq3jgb/lj5bjgorjg5Xjgqnjg6vjg4BcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpckV4cG9ydClcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyDllYblk4Hjg4fjg7zjgr/jg5njg7zjgrnjgbjjga7mjqXntprmupblgplcclxuICAgICAgICBjb25zdCBpdGVtUyA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbVMuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g5Y+X5rOoQ1NW44KS5Ye65Yqb44GZ44KLXHJcbiAgICAgICAgTWV0ZW9yLndyYXBBc3luYyhtY2IgPT4ge1xyXG4gICAgICAgICAgY29uc3QgcmVhZCA9IFJvYm90aW4uY3JlYXRlUmVhZGFibGVPcmRlcigpXHJcbiAgICAgICAgICAgIC5vbignZXJyb3InLCBlcnIgPT4geyBtY2IoZXJyKSB9KVxyXG5cclxuICAgICAgICAgIGNvbnN0IHRyYW5zZm9ybSA9IG5ldyBUcmFuc2Zvcm0oe1xyXG4gICAgICAgICAgICB3cml0YWJsZU9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHJlYWRhYmxlT2JqZWN0TW9kZTogdHJ1ZSxcclxuICAgICAgICAgICAgdHJhbnNmb3JtOiAoY2h1bmssIGVuYywgY2IpPT57XHJcbiAgICAgICAgICAgICAgY2IobnVsbCwgY2h1bmsucm9ib3Rpbik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgIGNvbnN0IHdyaXRlID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbShgJHt3b3JrZGlyRXhwb3J0fS8ke29yZGVyQ3N2RXhwb3J0fWApXHJcbiAgICAgICAgICAgIC5vbignZXJyb3InLCBlcnIgPT4geyBtY2IoZXJyKSB9KVxyXG4gICAgICAgICAgICAub24oJ2ZpbmlzaCcsICgpPT57XHJcbiAgICAgICAgICAgICAgbWNiKClcclxuICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICByZWFkXHJcbiAgICAgICAgICAgIC5waXBlKHRyYW5zZm9ybSlcclxuICAgICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAgIC5waXBlKHdyaXRlKVxyXG4gICAgICAgIH0pKClcclxuXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm9yZGVyLmltcG9ydGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1JvYm90LWluIOWPl+azqENTViDlj5bovrzjgb8nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS8ke2NvbmZpZy5vcmRlci53b3JrZGlyfWA7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpckltcG9ydCA9IGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyLndvcmtkaXJJbXBvcnR9YDtcclxuICAgICAgICBjb25zdCBvcmRlckNzdiA9IGAke2NvbmZpZy5vcmRlci5vcmRlcmNzdn0uY3N2YDtcclxuICAgICAgICBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgLy8g6Kqt44G/5Y+W44KK44OV44Kp44Or44OAXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXJJbXBvcnQpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aa5rqW5YKZXHJcbiAgICAgICAgY29uc3QgaXRlbVMgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1TLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOWPl+azqENTVuOCkuiqreOBv+i+vOOCgFxyXG4gICAgICAgIE1ldGVvci53cmFwQXN5bmMobWNiID0+IHtcclxuICAgICAgICAgIGNvbnN0IHJlYWQgPSBmc0V4dHJhLmNyZWF0ZVJlYWRTdHJlYW0oYCR7d29ya2RpckltcG9ydH0vJHtvcmRlckNzdn1gKVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHsgbWNiKGVycikgfSlcclxuICAgICAgICAgIGNvbnN0IHdyaXRlID0gbmV3IFdyaXRhYmxlKHtcclxuICAgICAgICAgICAgb2JqZWN0TW9kZTogdHJ1ZSxcclxuICAgICAgICAgICAgd3JpdGUgKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgICBGaWJlcihhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgICBhd2FpdCBSb2JvdGluLmltcG9ydE9yZGVyKGNodW5rLCBpdGVtUylcclxuICAgICAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKCk7XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjYXRjaChlcnIpe1xyXG4gICAgICAgICAgICAgICAgICBjYWxsYmFjayhlcnIpXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICBjYWxsYmFjaygpXHJcbiAgICAgICAgICAgICAgfSkucnVuKClcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgZmluYWwgKGNhbGxiYWNrKSB7XHJcbiAgICAgICAgICAgICAgY2FsbGJhY2soKVxyXG4gICAgICAgICAgICAgIG1jYigpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIC5vbignZXJyb3InLCBlcnIgPT4gcmVwb3J0LmlFcnJvcihlcnIpKVxyXG5cclxuICAgICAgICAgIHJlYWQucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgICAucGlwZShjc3YucGFyc2Uoe2NvbHVtbnM6IHRydWV9KSlcclxuICAgICAgICAgICAgLnBpcGUod3JpdGUpXHJcbiAgICAgICAgfSkoKVxyXG5cclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ucG9zdGxhYmVsYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnUm9ib3QtaW4g6YCB44KK54q255m66KGMJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vJHtjb25maWcucG9zdGxhYmVsLndvcmtkaXJ9YFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXJSZWFkID0gYCR7d29ya2Rpcn0vJHtjb25maWcucG9zdGxhYmVsLndvcmtkaXJSZWFkfWBcclxuICAgICAgICBjb25zdCB3b3JrZGlyV3JpdGUgPSBgJHt3b3JrZGlyfS8ke2NvbmZpZy5wb3N0bGFiZWwud29ya2RpcldyaXRlfWBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgLy8g6Kqt44G/5Y+W44KK44OV44Kp44Or44OAXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXJSZWFkKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIC8vIOabuOOBjei+vOOBv+ODleOCqeODq+ODgFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyV3JpdGUpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gd29ya2RpciDjgYzmupblgpnjgZXjgozjgabjgYTjgZ/jgonlrp/ooYzjgZnjgotcclxuICAgICAgICBjb25zdCBpdGVtUyA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbVMuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g5Y+X5rOoQ1NW44KS6Kqt44G/6L6844KAXHJcbiAgICAgICAgY29uc3Qgcm9ibyA9IG5ldyBSb2JvdGluKClcclxuICAgICAgICBNZXRlb3Iud3JhcEFzeW5jKG1jYiA9PiB7XHJcbiAgICAgICAgICBjb25zdCByZWFkID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJSZWFkfS8ke2NvbmZpZy5wb3N0bGFiZWwub3JkZXJjc3Z9LmNzdmApXHJcbiAgICAgICAgICAgIC5vbignZXJyb3InLCBlcnIgPT4geyBtY2IoZXJyKSB9KVxyXG4gICAgICAgICAgY29uc3Qgd3JpdGUgPSBuZXcgV3JpdGFibGUoe1xyXG4gICAgICAgICAgICBvYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICB3cml0ZSAoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykge1xyXG4gICAgICAgICAgICAgIHJvYm8uaW1wb3J0T3JkZXJUZW1wKGNodW5rLCBpdGVtUylcclxuICAgICAgICAgICAgICBjYWxsYmFjaygpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGZpbmFsIChjYWxsYmFjaykge1xyXG4gICAgICAgICAgICAgIGNhbGxiYWNrKClcclxuICAgICAgICAgICAgICBtY2IoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KVxyXG5cclxuICAgICAgICAgIHJlYWQucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgICAucGlwZShjc3YucGFyc2Uoe2NvbHVtbnM6IHRydWV9KSlcclxuICAgICAgICAgICAgLnBpcGUod3JpdGUpXHJcbiAgICAgICAgfSkoKVxyXG5cclxuICAgICAgICAvLyDpgIHjgornirbnqK7liKXjgZTjgajjgavnubDjgorov5TjgZlcclxuICAgICAgICBjb25maWcucG9zdGxhYmVsLmxhYmVsdHlwZXMuZm9yRWFjaChsYWJlbE9wdGlvbiA9PiB7XHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBNZXRlb3Iud3JhcEFzeW5jKG1jYiA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc3QgcmVhZCA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyUmVhZH0vJHtsYWJlbE9wdGlvbi5yZWFkY3N2fS5jc3ZgKVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlcnJvcicsICgpID0+IHsgbWNiKCkgfSkgLy8g44OV44Kh44Kk44Or44GM44Gq44GE5aC05ZCI44Gv54Sh6KaWXHJcbiAgICAgICAgICAgICAgY29uc3QgdHJhbnNmb3JtID0gbmV3IFRyYW5zZm9ybSh7XHJcbiAgICAgICAgICAgICAgICByZWFkYWJsZU9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICB3cml0YWJsZU9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgICB0cmFuc2Zvcm06IChjaHVuaywgZW5jb2RpbmcsIGNhbGxiYWNrKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGxldCByZWNvcmRcclxuICAgICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgICBGaWJlcigoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgICByZWNvcmQgPSByb2JvW2xhYmVsT3B0aW9uLm1ldGhvZF0oY2h1bmssIGxhYmVsT3B0aW9uKVxyXG4gICAgICAgICAgICAgICAgICAgICAgY2FsbGJhY2sobnVsbCwgcmVjb3JkKVxyXG4gICAgICAgICAgICAgICAgICAgIH0pLnJ1bigpXHJcbiAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWNiKGVycm9yKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICBjb25zdCB3cml0ZSA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2RpcldyaXRlfS8ke2xhYmVsT3B0aW9uLndyaXRlY3N2fS5jc3ZgKVxyXG4gICAgICAgICAgICAgICAgLm9uKCdmaW5pc2gnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpXHJcbiAgICAgICAgICAgICAgICAgIG1jYigpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlcnJvcicsIGVycm9yID0+IHsgbWNiKGVycm9yKSB9KVxyXG5cclxuICAgICAgICAgICAgICByZWFkXHJcbiAgICAgICAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGNzdi5wYXJzZSh7Y29sdW1uczogbGFiZWxPcHRpb24uY29sdW1ucyA9PT0gdHJ1ZSA/IHRydWUgOiBudWxsfSkpXHJcbiAgICAgICAgICAgICAgICAucGlwZSh0cmFuc2Zvcm0pXHJcbiAgICAgICAgICAgICAgICAucGlwZShjc3Yuc3RyaW5naWZ5KHtoZWFkZXI6IGxhYmVsT3B0aW9uLmNvbHVtbnN9KSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgICAgICAgLnBpcGUod3JpdGUpXHJcbiAgICAgICAgICAgIH0pKClcclxuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZXJyb3IpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyBSb2JvdC1pblxyXG4gIC8vIOWklumDqOmAo+aQuuWVhuWTgeeVquWPt1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5pdGVtY29kZWBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1JvYm90LWluIOWklumDqOmAo+aQuuWVhuWTgeeVquWPtycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9LyR7Y29uZmlnLml0ZW1jb2RlLndvcmtkaXJ9YFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyB3b3JrZGlyIOOBjOa6luWCmeOBleOCjOOBpuOBhOOBn+OCieWun+ihjOOBmeOCi1xyXG4gICAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgICBjb25zdCByZWFkID0gaXRlbUNvbnRyb2xsZXIuSXRlbXMuZmluZCh7bW9kZWw6IHskbmU6ICcnfX0pLnN0cmVhbSgpXHJcblxyXG4gICAgICAgICAgY29uc3Qgd3JpdGVDc3YgPSAocmVhZCwgdGYsIGZpbGVuYW1lKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJvYm90aW4gPSBuZXcgVHJhbnNmb3JtKHtcclxuICAgICAgICAgICAgICByZWFkYWJsZU9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgd3JpdGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybSAoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykge1xyXG4gICAgICAgICAgICAgICAgRmliZXIoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gdGYoY2h1bmspXHJcbiAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIGRhdGEpXHJcbiAgICAgICAgICAgICAgICB9KS5ydW4oKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgbGV0IGNvdW50ID0gMFxyXG4gICAgICAgICAgICBjb25zdCBjbGVhcm51bSA9IG5ldyBUcmFuc2Zvcm0oe1xyXG4gICAgICAgICAgICAgIGVuY29kaW5nOiAndXRmOCcsXHJcbiAgICAgICAgICAgICAgdHJhbnNmb3JtOiAoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0ciA9IGNodW5rLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgIGlmIChjb3VudCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICBzdHIgPSBzdHIucmVwbGFjZSgvX1xcZCs/L2csICcnKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY291bnQrK1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sobnVsbCwgc3RyKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgY29uc3Qgd3JpdGVjc3YgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke2ZpbGVuYW1lfS5jc3ZgKVxyXG4gICAgICAgICAgICB3cml0ZWNzdi5vbignZXJyb3InLCBlID0+IHsgdGhyb3cgTWV0ZW9yLkVycm9yKCdDU1bjg5XjgqHjgqTjg6vmm7jjgY3ovrzjgb/jgqjjg6njg7wnKSB9KVxyXG5cclxuICAgICAgICAgICAgcmVhZC5waXBlKHJvYm90aW4pXHJcbiAgICAgICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAgICAgLnBpcGUoY2xlYXJudW0pXHJcbiAgICAgICAgICAgICAgLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgICAgIC5waXBlKHdyaXRlY3N2KVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHdyaXRlQ3N2KFxyXG4gICAgICAgICAgICByZWFkLFxyXG4gICAgICAgICAgICBJdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVJvYm90aW5JdGVtLFxyXG4gICAgICAgICAgICBgJHt3b3JrZGlyfS8ke2NvbmZpZy5pdGVtY29kZS5jc3ZOYW1lSXRlbX1gXHJcbiAgICAgICAgICApXHJcblxyXG4gICAgICAgICAgd3JpdGVDc3YoXHJcbiAgICAgICAgICAgIHJlYWQsXHJcbiAgICAgICAgICAgIEl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtUm9ib3RpblNlbGVjdCxcclxuICAgICAgICAgICAgYCR7d29ya2Rpcn0vJHtjb25maWcuaXRlbWNvZGUuY3N2TmFtZVNlbGVjdH1gXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGDmraPjgZfjgYTkvZzmpa3jg4fjgqPjg6zjgq/jg4jjg6rjgYznlKjmhI/jgZXjgozjgabjgYTjgb7jgZvjgpPjgafjgZfjgZ/jgIJcXG5bJHt3b3JrZGlyfV1gKVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ3Rvb2wnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnRlc3RgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG5cclxuICAgIGNvbnN0IG5ld0xvY2FsID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe30sIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgIHRocm93IGVcclxuICAgIH0pXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg5XjgqPjg6vjgr/jg7zjg4bjgrnjg4gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIG5ld0xvY2FsXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QtcHJvbWlzZSdcclxuaW1wb3J0IFdvd21hQXBpIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS93b3dtYUFwaSdcclxuaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuLi9pbXBvcnRzL3V0aWwvZXJyb3InXHJcblxyXG5jb25zdCB0YWcgPSAnd293bWEnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB5oOF5aCx44Gu5aSJ5pu0XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZUl0ZW0uaW5mb2BdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dvd21hISDllYblk4Hmg4XloLHjgpLmm7TmlrDjgZnjgosnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyBqbGluZV9lbmdpbmUg5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aaXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5ZWG5ZOB5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgbGV0IGN1ciA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICAgICAgJGFuZDogW1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiB7ICRleGlzdHM6IDEgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vIOODhuOCueODiOaknOe0ouadoeS7tuioreWumlxyXG4gICAgICAgICAgICAgICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJ2drLTE2MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA0OTQyJyAvLyBKSy0xMjBcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICBdXHJcbiAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4HjgrPjg7zjg4njga7kuIDopqfjgpLkvZzjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRtYWxsLndvd21hLml0ZW1Db2RlJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyDlvpfjgonjgozjgZ/llYblk4HjgZTjgajjgatBUEnjg6rjgq/jgqjjgrnjg4jjgpLnmbrooYxcclxuICAgICAgICBsZXQgYXBpID0gbmV3IFdvd21hQXBpKGNvbmZpZy53b3dtYUFwaVBvc3QsIGNvbmZpZy5zaG9wSWQpXHJcbiAgICAgICAgYXdhaXQgcmVwb3J0LmZvckVhY2hPbkN1cnNvcihcclxuICAgICAgICAgIGN1cixcclxuICAgICAgICAgIGFzeW5jIGl0ZW0gPT4ge1xyXG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKGl0ZW0sIGNvbmZpZy5pdGVtSW5mby5kZWZhdWx0KVxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlSXRlbShpdGVtKVxyXG4gICAgICAgICAgICAgIHJldHVybiB7cmVxdWVzdEJvZHk6IGl0ZW0sIHJlc3BvbnNlOiByZXN9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICB0aHJvdyBPYmplY3QuYXNzaWduKHtyZXF1ZXN0Qm9keTogaXRlbX0sIHV0aWxFcnJvci5wYXJzZShlKSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDllYblk4Hjga7phY3pgIHmlrnms5XjgpLoqK3lrprjgZnjgotcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlSXRlbS5kZWxpdmVyeU1ldGhvZGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dvd21hISDllYblk4Hjga7phY3pgIHmlrnms5XjgpLoqK3lrprjgZnjgosnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyBqbGluZV9lbmdpbmUg5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aaXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5ZWG5ZOB5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgbGV0IGN1ciA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICAgICAgJGFuZDogW1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiB7ICRleGlzdHM6IDEgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vIOODhuOCueODiOaknOe0ouadoeS7tuioreWumlxyXG4gICAgICAgICAgICAgICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJ2drLTE2MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA0OTQyJyAvLyBKSy0xMjBcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDU0MDInXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDc0MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICBdXHJcbiAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4HjgrPjg7zjg4njga7kuIDopqfjgpLkvZzjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRtYWxsLndvd21hLml0ZW1Db2RlJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyDlvpfjgonjgozjgZ/llYblk4HjgZTjgajjgatBUEnjg6rjgq/jgqjjgrnjg4jjgpLnmbrooYxcclxuICAgICAgICBsZXQgYXBpID0gbmV3IFdvd21hQXBpKGNvbmZpZy53b3dtYUFwaVBvc3QsIGNvbmZpZy5zaG9wSWQpXHJcbiAgICAgICAgYXdhaXQgcmVwb3J0LmZvckVhY2hPbkN1cnNvcihcclxuICAgICAgICAgIGN1cixcclxuICAgICAgICAgIGFzeW5jIGl0ZW0gPT4ge1xyXG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKGl0ZW0sIGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtV293bWFDcmVhdGVEZWxpdmVyeU1ldGhvZChpdGVtLml0ZW1Db2RlKSlcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZUl0ZW0oaXRlbSlcclxuICAgICAgICAgICAgICByZXR1cm4ge3JlcXVlc3RCb2R5OiBpdGVtLCByZXNwb25zZTogcmVzfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih7cmVxdWVzdEJvZHk6IGl0ZW19LCB1dGlsRXJyb3IucGFyc2UoZSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB44OH44O844K/44OZ44O844K55LiK44Gu5ZWG5ZOB44KS5YWs6ZaL44GZ44KLXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZUl0ZW0ub3BlbmBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dvd21hISDllYblk4Hjg4fjg7zjgr/jg5njg7zjgrnkuIrjga7llYblk4HjgpLlhazplovjgZnjgosnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyBqbGluZV9lbmdpbmUg5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aaXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5ZWG5ZOB5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgbGV0IGN1ciA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICAgICAgJGFuZDogW1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiB7ICRleGlzdHM6IDEgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vIOODhuOCueODiOaknOe0ouadoeS7tuioreWumlxyXG4gICAgICAgICAgICAgICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJ2drLTE2MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDU0MDInXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDc0MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICBdXHJcbiAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4HjgrPjg7zjg4njga7kuIDopqfjgpLkvZzjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRtYWxsLndvd21hLml0ZW1Db2RlJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyDlvpfjgonjgozjgZ/llYblk4HjgZTjgajjgatBUEnjg6rjgq/jgqjjgrnjg4jjgpLnmbrooYxcclxuICAgICAgICBsZXQgYXBpID0gbmV3IFdvd21hQXBpKGNvbmZpZy53b3dtYUFwaVBvc3QsIGNvbmZpZy5zaG9wSWQpXHJcbiAgICAgICAgYXdhaXQgcmVwb3J0LmZvckVhY2hPbkN1cnNvcihcclxuICAgICAgICAgIGN1cixcclxuICAgICAgICAgIGFzeW5jIGl0ZW0gPT4ge1xyXG4gICAgICAgICAgICBpdGVtLnNhbGVTdGF0dXMgPSAxXHJcbiAgICAgICAgICAgIGl0ZW0ubGltaXRlZFBhc3N3ZCA9ICdOVUxMJ1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlSXRlbShpdGVtKVxyXG4gICAgICAgICAgICAgIHJldHVybiB7cmVxdWVzdEJvZHk6IGl0ZW0sIHJlc3BvbnNlOiByZXN9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICB0aHJvdyBPYmplY3QuYXNzaWduKHtyZXF1ZXN0Qm9keTogaXRlbX0sIHV0aWxFcnJvci5wYXJzZShlKSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDlnKjluqvmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlU3RvY2tgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5Zyo5bqr5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5Zyo5bqr5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgIC8vICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAkb3I6IFtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDU0MDInXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAse1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAse1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDc0MydcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICBdXHJcbiAgICAgICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDphY3pgIHmlrnms5Xjga7pgZXjgYTjgpLnnIHjgY9cclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDoge1xyXG4gICAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRtYWxsLndvd21hLml0ZW1Db2RlJyxcclxuICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGU6ICckbWFsbC53b3dtYS5IQ2hvaWNlTmFtZScsXHJcbiAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogJyRtYWxsLndvd21hLlZDaG9pY2VOYW1lJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGl0ZW06IHtcclxuICAgICAgICAgICAgICAgICAgJGZpcnN0OiAnJF9pZCdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4Hjg5rjg7zjgrjjgZTjgajvvIjllYblk4HjgrPjg7zjg4nvvInjgavjgrDjg6vjg7zjg5fljJbjgZnjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRfaWQuaXRlbUNvZGUnLFxyXG4gICAgICAgICAgICAgICAgdmFyaWF0aW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAkcHVzaDoge1xyXG4gICAgICAgICAgICAgICAgICAgIF9pZDogJyRpdGVtJyxcclxuICAgICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZTogJyRfaWQuY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogJyRfaWQuY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlJ1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJHByb2plY3Q6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogMCxcclxuICAgICAgICAgICAgICAgIGl0ZW1Db2RlOiAnJF9pZCcsXHJcbiAgICAgICAgICAgICAgICB2YXJpYXRpb25zOiAnJHZhcmlhdGlvbnMnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyBsZXQgcmVzTW9uZ28gPSBhd2FpdCBjdXIudG9BcnJheSgpXHJcbiAgICAgICAgLy8gcmV0dXJuIHJlc01vbmdvXHJcblxyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo1xyXG4gICAgICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XHJcbiAgICAgICAgICBsZXQgaXRlbSA9IGF3YWl0IGN1ci5uZXh0KClcclxuXHJcbiAgICAgICAgICAvLyDlnKjluqvjgpLoqK3lrprjgZnjgotcclxuICAgICAgICAgIGZvciAobGV0IGUgb2YgaXRlbS52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgICAgIGUuc3RvY2sgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhlLl9pZClcclxuICAgICAgICAgICAgZGVsZXRlIGUuX2lkXHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgLy9cclxuICAgICAgICAgIC8vIOWcqOW6q+abtOaWsOODquOCr+OCqOOCueODiFxyXG4gICAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS51cGRhdGVTdG9jayhbaXRlbV0pXHJcbiAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhyZXMpXHJcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY3VyLmNsb3NlKClcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB5qSc57SiXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnNlYXJjaEl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5ZWG5ZOB5oOF5aCx5Y+W5b6XJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gQVBJ44GL44KJ5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9pdGVtc18keyhuZXcgRGF0ZSgpKS5nZXRUaW1lKCl9YFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IG9wdGlvbnMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGNvbmZpZy53b3dtYUFwaSkpXHJcbiAgICAgICAgICAgIG9wdGlvbnMudXJpID0gYCR7b3B0aW9ucy51cml9L3NlYXJjaEl0ZW1JbmZvYFxyXG4gICAgICAgICAgICBvcHRpb25zLnFzLml0ZW1Db2RlID0gaXRlbS5tYWxsLndvd21hLml0ZW1Db2RlXHJcblxyXG4gICAgICAgICAgICBsZXQgcmVwb3MgPSBhd2FpdCByZXF1ZXN0KG9wdGlvbnMpXHJcbiAgICAgICAgICAgIGxldCBmaWxlbmFtZSA9IGAke3dvcmtkaXJ9LyR7aXRlbS5tb2RlbH0ueG1sYFxyXG5cclxuICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS53cml0ZUZpbGUoZmlsZW5hbWUsIHJlcG9zKVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIFdvd21hQXBpSXRlbUZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxuY29uc3QgdGFnID0gJ3dvd21hQXBpJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIFdPV01B5ZWG5ZOB5oOF5aCx5Y+W5b6XXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmdldEl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5ZWG5ZOB5oOF5aCx5Y+W5b6XJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBXb3dtYUFwaUl0ZW1GaWx0ZXIoY29uZmlnLndvd21hQXBpLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8gLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgLy8gdHJ5IHtcclxuICAgICAgICAvLyAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgLy8gfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gLy8gQVBJ44GL44KJ5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgLy8gY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9pdGVtc18keyhuZXcgRGF0ZSgpKS5nZXRUaW1lKCl9YFxyXG4gICAgICAgIC8vIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIC8vIHRyeSB7XHJcbiAgICAgICAgLy8gICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgLy8gfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKGl0ZW0pXHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IFBhY2tldCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcGFja2V0J1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgYXJjaGl2ZXIgZnJvbSAnYXJjaGl2ZXInXHJcbmltcG9ydCBjc3YgZnJvbSAnY3N2J1xyXG5pbXBvcnQgeyBQYXNzVGhyb3VnaCwgVHJhbnNmb3JtIH0gZnJvbSAnc3RyZWFtJ1xyXG5cclxuY29uc3QgcHJlZml4ID0gJ3BhY2tldCdcclxuY29uc3QgdGFnID0gJ3lhdWN0J1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOODpOODleOCquOCr+WPl+azqOODleOCoeOCpOODq1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5vcmRlcmBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODpOODleOCquOCr+WPl+azqCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L29yZGVyYFxyXG4gICAgICAgIGNvbnN0IHIgPSBmc0V4dHJhLmNyZWF0ZVJlYWRTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJMb2FkZmlsZX1gKVxyXG4gICAgICAgIGNvbnN0IHcgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyU2F2ZWZpbGV9YClcclxuICAgICAgICByLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAucGlwZShjc3YucGFyc2Uoe2NvbHVtbnM6IHRydWV9KSlcclxuICAgICAgICAgIC5waXBlKGNzdi50cmFuc2Zvcm0oXHJcbiAgICAgICAgICAgIGFzeW5jIChyZWNvcmQsIGNhbGxiYWNrKSA9PiB7XHJcbiAgICAgICAgICAgICAgbGV0IGVyciA9IG51bGxcclxuICAgICAgICAgICAgICAvLyDnrqHnkIbnlarlj7fjgpLnva7jgY3mj5vjgYjjgotcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgcmVjb3JkWyfnrqHnkIbnlarlj7cnXSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldE1vZGVsQ2xhc3MocmVjb3JkWyfnrqHnkIbnlarlj7cnXSlcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBlcnIgPSBlXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNhbGxiYWNrKGVyciwgcmVjb3JkKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC5waXBlKHcpXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOODpOODleOCquOCr+WHuuWTgeODleOCoeOCpOODq1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYml0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44Ok44OV44Kq44Kv5Ye65ZOBJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g57mw44KK6L+U44GX5Yem55CG44KS5Lu75oSP44Gu77yIcGFja2V0U2l6Ze+8ieOBp+WIhuWJslxyXG4gICAgICAgIGNvbnN0IHBhY2tldCA9IG5ldyBQYWNrZXQoY29uZmlnLnBhY2tldFNpemUpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIENTVuODleOCoeOCpOODq+OCkuS9nOaIkOOBl+eUu+WDj+ODh+ODvOOCv+OCkuWPjumbhuOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vd29ya2BcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh3b3JrZGlyKVxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuXHJcbiAgICAgICAgLy8gWklQ44OV44Kh44Kk44Or44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3QgdXBsb2FkZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L3VwbG9hZGBcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh1cGxvYWRkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih1cGxvYWRkaXIpXHJcblxyXG4gICAgICAgIGxldCBjZCA9IG51bGwgLy8g44OR44Kx44OD44OI44OV44Kp44Or44OAXHJcbiAgICAgICAgbGV0IGZpbGVuYW1lID0gbnVsbCAvLyBjc3bjg5XjgqHjgqTjg6tcclxuICAgICAgICBsZXQgbmFtZSA9IG51bGwgLy8g44OR44Kx44OD44OI55Wq5Y+3XHJcblxyXG4gICAgICAgIC8vIENTVuODleOCo+ODvOODq+ODieOCkuWumue+qeOBl+OAgemghueVquOCkueiuuWumuOBmeOCi1xyXG4gICAgICAgIGxldCBmaWVsZHMgPSBbJ+euoeeQhueVquWPtycsICfjgqvjg4bjgrTjg6onLCAn44K/44Kk44OI44OrJywgJ+iqrOaYjicsICfjgrnjg4jjgqLlhoXllYblk4HmpJzntKLnlKjjgq3jg7zjg6/jg7zjg4knLCAn6ZaL5aeL5L6h5qC8JywgJ+WNs+axuuS+oeagvCcsICflgKTkuIvjgZLkuqTmuIknLCAn5YCL5pWwJywgJ+WFpeacreWAi+aVsOWItumZkCcsICfmnJ/plpMnLCAn57WC5LqG5pmC6ZaTJywgJ+WVhuWTgeeZuumAgeWFg+OBrumDvemBk+W6nOecjCcsICfllYblk4HnmbrpgIHlhYPjga7luILljLrnlLrmnZEnLCAn6YCB5paZ6LKg5ouFJywgJ+S7o+mHkeWFiOaJleOBhOOAgeW+jOaJleOBhCcsICfokL3mnK3jg4rjg5PmsbrmuIjmlrnms5XoqK3lrponLCAn5ZWG5ZOB44Gu54q25oWLJywgJ+WVhuWTgeOBrueKtuaFi+WCmeiAgycsICfov5Tlk4Hjga7lj6/lkKYnLCAn6L+U5ZOB44Gu5Y+v5ZCm5YKZ6ICDJywgJ+eUu+WDjzEnLCAn55S75YOPMeOCs+ODoeODs+ODiCcsICfnlLvlg48yJywgJ+eUu+WDjzLjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMycsICfnlLvlg48z44Kz44Oh44Oz44OIJywgJ+eUu+WDjzQnLCAn55S75YOPNOOCs+ODoeODs+ODiCcsICfnlLvlg481JywgJ+eUu+WDjzXjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNicsICfnlLvlg48244Kz44Oh44Oz44OIJywgJ+eUu+WDjzcnLCAn55S75YOPN+OCs+ODoeODs+ODiCcsICfnlLvlg484JywgJ+eUu+WDjzjjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOScsICfnlLvlg48544Kz44Oh44Oz44OIJywgJ+eUu+WDjzEwJywgJ+eUu+WDjzEw44Kz44Oh44Oz44OIJywgJ+acgOS9juipleS+oScsICfmgqroqZXlibLlkIjliLbpmZAnLCAn5YWl5pyt6ICF6KqN6Ki85Yi26ZmQJywgJ+iHquWLleW7tumVtycsICfml6nmnJ/ntYLkuoYnLCAn5ZWG5ZOB44Gu6Ieq5YuV5YaN5Ye65ZOBJywgJ+iHquWLleWApOS4i+OBkicsICfmnIDkvY7okL3mnK3kvqHmoLwnLCAn44OB44Oj44Oq44OG44Kj44O8JywgJ+azqOebruOBruOCquODvOOCr+OCt+ODp+ODsycsICflpKrlrZfjg4bjgq3jgrnjg4gnLCAn6IOM5pmv6ImyJywgJ+OCueODiOOCouODm+ODg+ODiOOCquODvOOCr+OCt+ODp+ODsycsICfnm67nq4vjgaHjgqLjgqTjgrPjg7MnLCAn6LSI562U5ZOB44Ki44Kk44Kz44OzJywgJ1Tjg53jgqTjg7Pjg4jjgqrjg5fjgrfjg6fjg7MnLCAn44Ki44OV44Kj44Oq44Ko44Kk44OI44Kq44OX44K344On44OzJywgJ+iNt+eJqeOBruWkp+OBjeOBlScsICfojbfnianjga7ph43ph48nLCAn44Gv44GTQk9PTicsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxJywgJ+OBneOBruS7lumFjemAgeaWueazlTHmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UyJywgJ+OBneOBruS7lumFjemAgeaWueazlTLmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UzJywgJ+OBneOBruS7lumFjemAgeaWueazlTPmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U0JywgJ+OBneOBruS7lumFjemAgeaWueazlTTmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U1JywgJ+OBneOBruS7lumFjemAgeaWueazlTXmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U2JywgJ+OBneOBruS7lumFjemAgeaWueazlTbmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U3JywgJ+OBneOBruS7lumFjemAgeaWueazlTfmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U4JywgJ+OBneOBruS7lumFjemAgeaWueazlTjmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U5JywgJ+OBneOBruS7lumFjemAgeaWueazlTnmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOWFqOWbveS4gOW+i+S+oeagvCcsICfmtbflpJbnmbrpgIEnLCAn6YWN6YCB5pa55rOV44O76YCB5paZ6Kit5a6aJywgJ+S7o+W8leaJi+aVsOaWmeioreWumicsICfmtojosrvnqI7oqK3lrponLCAnSkFO44Kz44O844OJ44O7SVNCTuOCs+ODvOODiSddXHJcbiAgICAgICAgbGV0IGhlYWRlciA9IGZpZWxkcy5tYXAodiA9PiBgXCIke3Z9XCJgKS5qb2luKCcsJykgKyAnXFxuJ1xyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbplovlp4vmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXRTdGFydCA9IGFzeW5jIChwYWNrZXRDb3VudCkgPT4ge1xyXG4gICAgICAgICAgbmFtZSA9IHByZWZpeCArICgnMDAwMDAnICsgcGFja2V0Q291bnQpLnNsaWNlKC01KVxyXG4gICAgICAgICAgY2QgPSBgJHt3b3JrZGlyfS8ke25hbWV9YFxyXG4gICAgICAgICAgZmlsZW5hbWUgPSBgJHtjZH0vJHtjb25maWcuY3N2RmlsZU5hbWV9YFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2RpcihjZClcclxuICAgICAgICAgIC8vIENTVuODleOCoeOCpOODq+OBq+ODleOCo+ODvOODq+ODieOCkuioreWumuOBmeOCi1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUoaGVhZGVyLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXQgPSBhc3luYyAoYXJnKSA9PiB7XHJcbiAgICAgICAgICBsZXQgeWF1Y3QgPSBhcmcueWF1Y3RcclxuICAgICAgICAgIGxldCBpdGVtID0gYXJnLml0ZW1cclxuICAgICAgICAgIC8vIGNzduODleOCoeOCpOODq+OBq+ODrOOCs+ODvOODie+8iOWVhuWTgeODhuODs+ODl+ODrOODvOODiO+8ieOCkui/veWKoOOBmeOCi1xyXG4gICAgICAgICAgbGV0IHJlY29yZCA9IGZpZWxkcy5tYXAodiA9PiB7IHJldHVybiB5YXVjdFt2XSA/IGBcIiR7eWF1Y3Rbdl19XCJgIDogJ1wiXCInIH0pLmpvaW4oJywnKSArICdcXG4nXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShyZWNvcmQsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICAgIC8vIOeUu+WDj+ODleOCoeOCpOODq+OCkuOCs+ODlOODvFxyXG4gICAgICAgICAgZm9yIChsZXQgaW1nIG9mIGl0ZW0uaW1hZ2VzKSB7XHJcbiAgICAgICAgICAgIGxldCBpbWdTcmMgPSBgJHtjb25maWcuaW1hZ2VkaXJ9LyR7aW1nfWBcclxuICAgICAgICAgICAgbGV0IGltZ1RndCA9IGAke2NkfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgLy8g5ZCM44GY44OV44Kh44Kk44Or44GM44GC44KL5aC05ZCI44Gv44Kz44OU44O844GX44Gq44GEXHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5hY2Nlc3MoaW1nVGd0KVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5jb3B5RmlsZShpbWdTcmMsIGltZ1RndClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI57WC5LqG5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0RW5kID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB6aXAgPSBhcmNoaXZlcignemlwJylcclxuICAgICAgICAgIGNvbnN0IHppcG5hbWUgPSBgJHt1cGxvYWRkaXJ9LyR7bmFtZX0uemlwYFxyXG4gICAgICAgICAgY29uc3Qgb3V0cHV0ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbSh6aXBuYW1lKVxyXG4gICAgICAgICAgemlwLnBpcGUob3V0cHV0KVxyXG4gICAgICAgICAgemlwLmRpcmVjdG9yeShjZCwgZmFsc2UpXHJcbiAgICAgICAgICB6aXAuZmluYWxpemUoKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgIC8vIGl0ZW3jgavlrprnvqnjgZXjgozjgabjgYTjgovmnIDkvY7lv4XopoHlnKjluqvjgojjgorlpJrjgYTllYblk4HjgpLlh7rlk4HjgZnjgotcclxuICAgICAgICAgICAgaWYgKHF1YW50aXR5ID49IGl0ZW0ubWFsbC55YXVjdC5taW5RdWFudGl0eSkge1xyXG4gICAgICAgICAgICAgIGxldCB5YXVjdCA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtWWF1Y3QoY29uZmlnLmRlZmF1bHQsIGl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgcGFja2V0LnN1Ym1pdCh7eWF1Y3Q6IHlhdWN0LCBpdGVtOiBpdGVtfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHBhY2tldC5jbG9zZSgpXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCAnLi4vaW1wb3J0cy9jb2xsZWN0aW9ucydcclxuaW1wb3J0ICcuL3JvdXRlL3VwbG9hZC9pbWFnZSdcclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXHJcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnO1xyXG5pbXBvcnQgbW9iamVjdCBmcm9tICdtb25nb29iamVjdCc7XHJcbmltcG9ydCB7IEdyb3VwQmFzZSB9IGZyb20gJy4vZ3JvdXBzJztcclxuXHJcbmNvbnN0IEZpbHRlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZmlsdGVycycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgRmlsdGVyIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZmlsdGVySWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEZpbHRlcnMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZmlsdGVySWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuXHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoIG9uUmVzdWx0ID0gKHJlY29yZCk9Pnt9LCBvbkVycm9yID0gKGUpPT57fSApID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbGF0Zm9ybSB0eXBlJyk7XHJcblxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHt7IGZpbHRlclR5cGU6IGFzeW5jIChyZWNvcmQgKSA9PiB7fSB9fSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGFzeW5jIGZvcmVhY2goY2FsbGJhY2tzID0ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZSgpO1xyXG5cclxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXHJcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XHJcbiAgICAgIHR5cGU6ICdtaXNjJyxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBjb3VudCA9IHt9O1xyXG4gICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICBjb3VudFtmaWx0ZXIudHlwZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGZpbHRlci5xdWVyeSxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkKT0+e1xyXG4gICAgICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgICAgIGxldCBxdWVyeSA9IG1vYmplY3QudW5lc2NhcGUoZmlsdGVyLnF1ZXJ5KTtcclxuICAgICAgICAgIGxldCBleGFtID0gc2lmdCggcXVlcnkgKTtcclxuICAgICAgICAgIGlmKCBleGFtKHJlY29yZCkgKXtcclxuICAgICAgICAgICAgY291bnRbZmlsdGVyLnR5cGVdLmNvdW50Kys7XHJcbiAgICAgICAgICAgIGlmKCB0eXBlb2YgY2FsbGJhY2tzW2ZpbHRlci50eXBlXSAhPT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0ocmVjb3JkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIG9uRXJyb3JcclxuICAgICk7XHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudDtcclxuXHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuY29uc3QgR3JvdXBzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2dyb3VwcycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXBCYXNlIHtcclxuXHJcbiAgcHJvZmlsZTtcclxuXHJcbiAgY29uc3RydWN0b3IocHJvZmlsZSkge1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGdldHMgJ1BsdWcnIHdpdGNoIGlzIGEgc2V0IG9mIHByb3BlcnRpZXMgbmVlZGVkXHJcbiAgICogd2hlbiBjb25uZWN0IHRvIHNvbWUgcGxhdGZvcm1zXHJcbiAgICogdG8gZ2V0IGRhdGFzKE1lbWJlcnMgb2YgdGhlIEdyb3VwKVxyXG4gICAqL1xyXG4gIGdldFBsdWcoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlLnBsYXRmb3JtUGx1ZztcclxuICB9XHJcblxyXG4gIGdldFByb2ZpbGUoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7fTtcclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cCBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGdyb3VwSWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEdyb3Vwcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBncm91cElkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoZG9jKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfSBXSEVSRSBcXGAke2RvYy5rZXl9XFxgID0gXCIke2RvYy5pZH1cImA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIGdyb3VwIHR5cGUnKTtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHthc3luYyAocmVjb3JkKT0+dm9pZH0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgY3VyID0gR3JvdXBzLmZpbmQoe1xyXG4gICAgICBncm91cElkOiB0aGlzLnByb2ZpbGUuX2lkXHJcbiAgICB9LCB7XHJcbiAgICAgIGZpZWxkczoge1xyXG4gICAgICAgIF9pZDogMCxcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICBrZXk6IDFcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY3VyLmZvckVhY2goXHJcbiAgICAgICAgICBhc3luYyAoZG9jLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZWNvcmQgPSBhd2FpdCB0aGlzLmltcG9ydChkb2MpO1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBvbkVycm9yKGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpbmRleCArIDEgPT09IGN1ci5jb3VudCgpKSB7XHJcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgIH1cclxuICAgICkuY2F0Y2goXHJcbiAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgfVxyXG5cclxufSIsImltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcbmltcG9ydCBzeW5jT2JqZWN0IGZyb20gJy4uL3V0aWwvc3luY09iamVjdCc7XG5cbmV4cG9ydCBjbGFzcyBDdWJlM0FwaSB7XG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0ge015U1FMfSBteXNxbFxuICAgKi9cbiAgY29uc3RydWN0b3IobXlzcWwpIHtcbiAgICB0aGlzLm15c3FsID0gbXlzcWw7XG4gIH1cblxuICBhc3luYyBtb2RpZnlDYXRlZ29yeShwcm9kdWN0SWQsIGNhdGVnb3J5SWRBcnJheSkge1xuICAgIGNvbnN0IHRhYmxlQ2F0ZWdvcnkgPSAnZHRiX3Byb2R1Y3RfY2F0ZWdvcnknO1xuXG4gICAgLy8g5ZWG5ZOB5oOF5aCx44OH44O844K/44OZ44O844K544Gr6KiY6Yyy44GV44KM44Gf5ZWG5ZOB44Kr44OG44K044Oq44O85oOF5aCxXG4gICAgY29uc3QgY29sU3JjID0gW107XG4gICAgY2F0ZWdvcnlJZEFycmF5LmZvckVhY2goKGVsZW0pID0+IHtcbiAgICAgIGNvbFNyYy5wdXNoKHtcbiAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxuICAgICAgICBjYXRlZ29yeV9pZDogZWxlbSxcbiAgICAgIH0pO1xuICAgIH0pO1xuXG4gICAgLy8g44Oi44O844Or44OH44O844K/44OZ44O844K544GL44KJ54++5Zyo44Gu5ZWG5ZOB44Kr44OG44K044Oq44O85oOF5aCx44KS5Y+W5b6XXG4gICAgY29uc3Qgc3FsID0gYFxuICAgIFNFTEVDVCBwcm9kdWN0X2lkLCBjYXRlZ29yeV9pZFxuICAgIEZST00gJHt0YWJsZUNhdGVnb3J5fVxuICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke3Byb2R1Y3RJZH1cbiAgICBgO1xuXG4gICAgLy8gY29uc3QgY29sRHN0ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCkpKTtcbiAgICBjb25zdCBjb2xEc3QgPSBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5U2VsZWN0KFxuICAgICAgdGFibGVDYXRlZ29yeSxcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtwcm9kdWN0SWR9YCxcbiAgICAgICdwcm9kdWN0X2lkLCBjYXRlZ29yeV9pZCcsXG4gICAgKTtcblxuICAgIC8vIOWQhFNRTOOCr+OCqOODquOBrue1kOaenOOBmeOBueOBpuOCkuiomOmMsuOBmeOCi1xuICAgIGNvbnN0IHJlc3VsdHMgPSBbXTtcblxuICAgIGF3YWl0IHN5bmNPYmplY3QoXG4gICAgICBjb2xTcmMsIGNvbERzdCwgbnVsbCxcbiAgICAgIGFzeW5jIChpZCwgb2JqZWN0KSA9PiB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWwucXVlcnlJbnNlcnQoXG4gICAgICAgICAgdGFibGVDYXRlZ29yeSxcbiAgICAgICAgICB7fSxcbiAgICAgICAgICBPYmplY3QuYXNzaWduKHsgcmFuazogMSB9LCBvYmplY3QpLFxuICAgICAgICApO1xuICAgICAgICByZXN1bHRzLnB1c2gocmVzKTtcbiAgICAgIH0sXG4gICAgICBhc3luYyAoaWQsIG9iamVjdCkgPT4ge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KFxuICAgICAgICAgIGBcbiAgICAgICAgICBERUxFVEUgRlJPTSAke3RhYmxlQ2F0ZWdvcnl9XG4gICAgICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7b2JqZWN0LnByb2R1Y3RfaWR9XG4gICAgICAgICAgICBBTkQgY2F0ZWdvcnlfaWQgPSAke29iamVjdC5jYXRlZ29yeV9pZH1cbiAgICAgICAgICBgLFxuICAgICAgICApO1xuICAgICAgICByZXN1bHRzLnB1c2gocmVzKTtcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIHJldHVybiByZXN1bHRzO1xuICB9XG5cbiAgYXN5bmMgdXBkYXRlU3RvY2socHJvZHVjdENsYXNzSWQsIHF1YW50aXR5ID0gMCkge1xuICAgIGF3YWl0IHRoaXMubXlzcWwucXVlcnlVcGRhdGUoXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXG4gICAgICB7fSwge1xuICAgICAgICBzdG9jazogcXVhbnRpdHksXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICB9LFxuICAgICk7XG5cbiAgICBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5VXBkYXRlKFxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJyxcbiAgICAgIGBwcm9kdWN0X2NsYXNzX2lkID0gJHtwcm9kdWN0Q2xhc3NJZH1gLFxuICAgICAge30sIHtcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgIH0sXG4gICAgKTtcbiAgfVxuXG4gIGFzeW5jIHByb2R1Y3RUYWdVcGRhdGUoZGF0YSkge1xuICAgIGNvbnN0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZDtcblxuICAgIGNvbnN0IHJlcyA9IFtdO1xuXG4gICAgLy8g5YmK6Zmk44GZ44KL44K/44KwXG4gICAgY29uc3QgdGFnb2ZmID0gYXN5bmMgKHRhZykgPT4ge1xuICAgICAgY29uc3Qgc3FsID0gYFxuICAgICAgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfdGFnIFxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XG4gICAgICBgO1xuICAgICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpKTtcbiAgICB9O1xuXG4gICAgLy8g6KGo56S644GZ44KL44K/44KwXG4gICAgY29uc3QgdGFnb24gPSBhc3luYyAodGFnKSA9PiB7XG4gICAgICAvLyDjgZnjgafjgavooajnpLrjgZXjgozjgabjgYTjgovjgr/jgrDjgYzjgYLjgozjgbDkvZXjgoLjgZfjgarjgYRcbiAgICAgIGNvbnN0IHNxbCA9IGBcbiAgICAgIFNFTEVDVCBDT1VOVCgqKSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxuICAgICAgYDtcbiAgICAgIGNvbnN0IGNvdW50UmVzID0gYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpO1xuICAgICAgaWYgKGNvdW50UmVzWzBdWydDT1VOVCgqKSddKSByZXR1cm47XG5cbiAgICAgIHJlcy5wdXNoKFxuICAgICAgICBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5SW5zZXJ0KFxuICAgICAgICAgICdkdGJfcHJvZHVjdF90YWcnLFxuICAgICAgICAgIHt9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGRhdGEucHJvZHVjdF9pZCxcbiAgICAgICAgICAgIHRhZyxcbiAgICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcbiAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgICAgIH0sXG4gICAgICAgICksXG4gICAgICApO1xuICAgIH07XG5cbiAgICBmb3IgKGNvbnN0IHRhZ1NldCBvZiBkYXRhLnRhZ3MpIHtcbiAgICAgIHN3aXRjaCAodGFnU2V0LnNldCkge1xuICAgICAgICBjYXNlICdvbic6XG4gICAgICAgICAgYXdhaXQgdGFnb24odGFnU2V0LnRhZyk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICAgIGNhc2UgJ29mZic6XG4gICAgICAgICAgYXdhaXQgdGFnb2ZmKHRhZ1NldC50YWcpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgfVxuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICByZXMsXG4gICAgfTtcbiAgfVxuXG4gIGFzeW5jIHByb2R1Y3RJbWFnZVVwZGF0ZShkYXRhKSB7XG4gICAgY29uc3QgcHJvZHVjdElkID0gZGF0YS5wcm9kdWN0X2lkO1xuICAgIGNvbnN0IGltYWdlcyA9IGRhdGEuaW1hZ2VzO1xuICAgIGNvbnN0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZDtcblxuICAgIGNvbnN0IHJlcyA9IFtdO1xuXG4gICAgLy8g5ZWG5ZOB44Gr6Zai6YCj44GZ44KL44GZ44G544Gm44Gu55S75YOP5oOF5aCx44KS5YmK6Zmk44GZ44KLXG4gICAgY29uc3Qgc3FsID0gYERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X2ltYWdlIFdIRVJFIHByb2R1Y3RfaWQgPSAke3Byb2R1Y3RJZH1gO1xuICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKSk7XG4gICAgLy8g5pS544KB44Gm55S75YOP44KS55m76Yyy44GX44Gq44GK44GZXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbWFnZXMubGVuZ3RoOyBpKyspIHtcbiAgICAgIGF3YWl0IHRoaXMubXlzcWwucXVlcnlJbnNlcnQoXG4gICAgICAgICdkdGJfcHJvZHVjdF9pbWFnZScsIHtcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXG4gICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxuICAgICAgICAgIGZpbGVfbmFtZTogaW1hZ2VzW2ldLFxuICAgICAgICAgIHJhbms6IGkgKyAxLFxuICAgICAgICB9LCB7XG4gICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH1cblxuICAgIHJldHVybiB7XG4gICAgICByZXMsXG4gICAgfTtcbiAgfVxuXG4gIGFzeW5jIHByb2R1Y3RVcGRhdGUoZGF0YSkge1xuICAgIGxldCB1cGRhdGVEYXRhID0ge307XG4gICAgbGV0IGtleXMgPSBbXTtcblxuICAgIC8vIGR0Yl9wcm9kdWN0XG5cbiAgICBrZXlzID0gW1xuICAgICAgJ3N0YXR1cycsXG4gICAgICAnbmFtZScsXG4gICAgICAnbm90ZScsXG4gICAgICAnZGVzY3JpcHRpb25fbGlzdCcsXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJyxcbiAgICAgICdzZWFyY2hfd29yZCcsXG4gICAgICAnZnJlZV9hcmVhJyxcbiAgICBdO1xuICAgIGZvciAoY29uc3QgayBvZiBrZXlzKSB7XG4gICAgICBpZiAoZGF0YVtrXSkge1xuICAgICAgICB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXTtcbiAgICAgIH1cbiAgICB9XG5cbiAgICAvLyBbXG4gICAgLy8gICAnc3RhdHVzJyxcbiAgICAvLyAgICduYW1lJyxcbiAgICAvLyAgICdub3RlJyxcbiAgICAvLyAgICdkZXNjcmlwdGlvbl9saXN0JyxcbiAgICAvLyAgICdkZXNjcmlwdGlvbl9kZXRhaWwnLFxuICAgIC8vICAgJ3NlYXJjaF93b3JkJyxcbiAgICAvLyAgICdmcmVlX2FyZWEnLFxuICAgIC8vIF0uZm9yRWFjaChcbiAgICAvLyAgICh2KSA9PiB7XG4gICAgLy8gICAgIGlmIChkYXRhW3ZdKSB7XG4gICAgLy8gICAgICAgdXBkYXRlRGF0YVt2XSA9IGRhdGFbdl07XG4gICAgLy8gICAgIH1cbiAgICAvLyAgIH0sXG4gICAgLy8gKTtcblxuICAgIGF3YWl0IHRoaXMubXlzcWwucXVlcnlVcGRhdGUoXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxuICAgICAgdXBkYXRlRGF0YSwge1xuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIC8vIGR0Yl9wcm9kdWN0X2NsYXNzXG5cbiAgICB1cGRhdGVEYXRhID0ge307XG4gICAga2V5cyA9IFtcbiAgICAgICdkZWxpdmVyeV9kYXRlX2lkJyxcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxuICAgICAgJ3NhbGVfbGltaXQnLFxuICAgICAgJ3ByaWNlMDEnLFxuICAgICAgJ3ByaWNlMDInLFxuICAgICAgJ2RlbGl2ZXJ5X2ZlZScsXG4gICAgXTtcbiAgICBmb3IgKGNvbnN0IGsgb2Yga2V5cykgeyBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba107IH1cblxuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5teXNxbC5xdWVyeVVwZGF0ZShcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXG4gICAgICB1cGRhdGVEYXRhLCB7XG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIHJlcyxcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgcHJvZHVjdENyZWF0ZShkYXRhKSB7XG4gICAgY29uc3QgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkO1xuXG4gICAgY29uc3QgcmVzID0ge307XG5cbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9O1xuICAgIGxldCBrZXlzID0gW107XG5cbiAgICBrZXlzID0gW1xuICAgICAgJ25hbWUnLFxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXG4gICAgXTtcbiAgICAvLyB7XG4gICAgLy8gICBuYW1lOiBpdGVtLm5hbWUsXG4gICAgLy8gICBkZXNjcmlwdGlvbl9kZXRhaWw6IGl0ZW0uZGVzY3JpcHRpb24sXG4gICAgLy8gfSxcblxuICAgIGZvciAoY29uc3QgayBvZiBrZXlzKSB7IGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXTsgfVxuXG5cbiAgICByZXMucHJvZHVjdF9pZCA9IGF3YWl0IHRoaXMubXlzcWwucXVlcnlJbnNlcnQoXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxuICAgICAgdXBkYXRlRGF0YSwge1xuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXG4gICAgICAgIHN0YXR1czogMSxcbiAgICAgICAgbm90ZTogJ05VTEwnLFxuICAgICAgICBkZXNjcmlwdGlvbl9saXN0OiAnTlVMTCcsXG4gICAgICAgIHNlYXJjaF93b3JkOiAnTlVMTCcsXG4gICAgICAgIGZyZWVfYXJlYTogJ05VTEwnLFxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICB9LFxuICAgICk7XG5cbiAgICB1cGRhdGVEYXRhID0ge307XG4gICAga2V5cyA9IFtcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxuICAgICAgJ3Byb2R1Y3RfdHlwZV9pZCcsXG4gICAgICAncHJpY2UwMScsXG4gICAgICAncHJpY2UwMicsXG4gICAgICAnZGVsaXZlcnlfZmVlJyxcbiAgICBdO1xuICAgIC8vIHtcbiAgICAvLyAgIHByb2R1Y3RfY29kZTogaXRlbS5tb2RlbCxcbiAgICAvLyAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxuICAgIC8vICAgcHJpY2UwMjogaXRlbS5zYWxlc19wcmljZSxcbiAgICAvLyB9LFxuXG4gICAgZm9yIChjb25zdCBrIG9mIGtleXMpIHsgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdOyB9XG5cblxuICAgIHJlcy5wcm9kdWN0X2NsYXNzX2lkID0gYXdhaXQgdGhpcy5teXNxbC5xdWVyeUluc2VydChcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXG4gICAgICB1cGRhdGVEYXRhLCB7XG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcbiAgICAgICAgcHJvZHVjdF9pZDogcmVzLnByb2R1Y3RfaWQsXG4gICAgICAgIHN0b2NrOiAwLFxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXG4gICAgICAgIGNsYXNzX2NhdGVnb3J5X2lkMTogJ05VTEwnLFxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDI6ICdOVUxMJyxcbiAgICAgICAgZGVsaXZlcnlfZGF0ZV9pZDogJ05VTEwnLFxuICAgICAgICBzYWxlX2xpbWl0OiAnTlVMTCcsXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIGZvciAoY29uc3QgayBvZiBrZXlzKSB7IGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXTsgfVxuXG5cbiAgICByZXMucHJvZHVjdF9zdG9ja19pZCA9IGF3YWl0IHRoaXMubXlzcWwucXVlcnlJbnNlcnQoXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLCB7fSwge1xuICAgICAgICBwcm9kdWN0X2NsYXNzX2lkOiByZXMucHJvZHVjdF9jbGFzc19pZCxcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxuICAgICAgICBzdG9jazogMCxcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgfSxcbiAgICApO1xuXG4gICAgLy8gZm9yIHRlc3RcbiAgICByZXR1cm4ge1xuICAgICAgcmVzLFxuICAgIH07XG4gIH1cbn1cbiIsImltcG9ydCB7TW9uZ29DbGllbnR9IGZyb20gJ21vbmdvZGInXG5pbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0LXByb21pc2UnXG5cbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0J1xuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnXG5pbXBvcnQgeyB4bWwyanMgfSBmcm9tICd4bWwtanMnXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCdcblxuZXhwb3J0IGNsYXNzIERCRmlsdGVyRmFjdG9yeSB7XG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XG4gICAgbGV0IGluc3RhbmNlO1xuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XG4gICAgICBjYXNlICdteXNxbCc6XG4gICAgICAgIGluc3RhbmNlID0gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSk7XG4gICAgfVxuXG4gICAgcmV0dXJuIGluc3RhbmNlO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBEQkZpbHRlciB7XG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XG4gICAgdGhpcy5wbHVnID0gcGx1ZztcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlO1xuICB9XG5cbiAgc3RhdGljIGZhY3RvcnkgKHBsdWcsIHByb2ZpbGUpIHtcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xuICAgICAgY2FzZSAnbXlzcWwnOlxuICAgICAgICByZXR1cm4gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSk7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGx1ZyB0eXBlJyk7XG4gICAgfVxuICB9XG5cbiAgZ2V0UGx1Z18gKCkge1xuICAgIHJldHVybiB0aGlzLnBsdWc7XG4gIH1cblxuICBnZXRDcmVkXyAoKSB7XG4gICAgcmV0dXJuIHRoaXMucGx1Zy5jcmVkO1xuICB9XG5cbiAgZ2V0UHJvZmlsZV8gKCkge1xuICAgIHJldHVybiB0aGlzLnByb2ZpbGU7XG4gIH1cblxuICBzZXRJbXBvcnRGdW5jdGlvbl8gKFxuICAgIGZuID0gYXN5bmMgKG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pID0+IHt9LFxuICApIHtcbiAgICB0aGlzLmltcG9ydCA9IGZuO1xuICB9XG5cbiAgLyoqXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxuICAgKiB1c2VhZ2U6XG4gICAqXG4gICAqXG4gICAqIEBwYXJhbSB7IE9iamVjdCB9IGl0ZXJhdG9ycyB7IGZpbHRlck5hbWU6IGFzeW5jIChkb2MsY29udGV4dCk9Pnt9LCAuLi4gfSBpdGVyYXRvciBmb3IgZWFjaCBmaWx0ZXJzXG4gICAqIEBwYXJhbSB7IGFzeW5jIGZ1bmN0aW9uIH0gb25FcnJvciBlcnJvciBoYW5kbGVyIHdoaWxlIGl0ZXJhdGluZ1xuICAgKiBAcmV0dXJucyB7IE9iamVjdCB9IHsgZmlsdGVyTmFtZTogeyBxdWVyeTogYW55LCBjb3VudDogbnVtYmVyIH0sIC4uLiB9XG4gICAqL1xuICBhc3luYyBmb3JlYWNoIChpdGVyYXRvcnMgPSB7fSkge1xuICAgIGNvbnN0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGVfKCk7XG5cbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcbiAgICAgIG5hbWU6ICdtaXNjJyxcbiAgICAgIHF1ZXJ5OiB7fSxcbiAgICB9KTtcblxuICAgIGNvbnN0IGNvdW50ZXIgPSB7fTtcbiAgICBmb3IgKGNvbnN0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XG4gICAgfVxuXG4gICAgY29uc3QgZmlsdGVycyA9IFtdO1xuXG4gICAgZm9yIChjb25zdCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xuICAgICAgY291bnRlcltmLm5hbWVdID0ge1xuICAgICAgICBxdWVyeTogZi5xdWVyeSxcbiAgICAgICAgbGltaXQ6IHR5cGVvZiBmLmxpbWl0ICE9PSAndW5kZWZpbmVkJyA/IGYubGltaXQgOiAwLFxuICAgICAgICBjb3VudDogMCxcbiAgICAgIH07XG4gICAgICBmaWx0ZXJzLnB1c2goXG4gICAgICAgIHtcbiAgICAgICAgICBuYW1lOiBmLm5hbWUsXG4gICAgICAgICAgZXhhbTogc2lmdChtb2JqZWN0LnVuZXNjYXBlKGYucXVlcnkpKSxcbiAgICAgICAgfSxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXG4gICAgICBhc3luYyAocmVjb3JkLCBjb250ZXh0KSA9PiB7XG4gICAgICAgIGZvciAoY29uc3QgZiBvZiBmaWx0ZXJzKSB7XG4gICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXG4gICAgICAgICAgY29uc3QgYyA9IGNvdW50ZXJbZi5uYW1lXTtcbiAgICAgICAgICBpZiAoYy5saW1pdCkge1xuICAgICAgICAgICAgaWYgKGMuY291bnQgPj0gYy5saW1pdCkge1xuICAgICAgICAgICAgICBjb250aW51ZTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9XG5cbiAgICAgICAgICBpZiAoZi5leGFtKHJlY29yZCkpIHtcbiAgICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxuICAgICAgICAgICAgYy5jb3VudCsrO1xuXG4gICAgICAgICAgICAvLyBpdGVyYXRvclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVyYXRvcnNbZi5uYW1lXSAhPT0gJ3VuZGVmaW5lZCcpIHtcbiAgICAgICAgICAgICAgYXdhaXQgaXRlcmF0b3JzW2YubmFtZV0ocmVjb3JkLCBjb250ZXh0KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIGJyZWFrO1xuICAgICAgICAgIH1cbiAgICAgICAgfVxuICAgICAgfVxuKTtcblxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXG4gICAgcmV0dXJuIGNvdW50ZXI7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIE15c3FsREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XG5cbiAgICBjb25zdCBjcmVkID0gdGhpcy5nZXRDcmVkXygpO1xuXG4gICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChjcmVkKTtcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcbiAgICAgIGNvbnN0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gO1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCAoZSkgPT4geyB0aHJvdyBlOyB9KTtcbiAgICAgIHJldHVybiByZXM7XG4gICAgfSk7XG4gIH1cbn1cblxuLy8gaW1wb3J0IE1vbmdvTmF0aXZlIGZyb20gJ21vbmdvZGInO1xuLy8gY29uc3QgTW9uZ29DbGllbnQgPSBNb25nb05hdGl2ZS5Nb25nb0NsaWVudDtcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gcmVxdWlyZSgnbW9uZ29kYicpLk1vbmdvQ2xpZW50O1xuXG5leHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcblxuICAgIC8vIG1vbmdvIOOBuOaOpee2mlxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xuICAgICAgbGV0IGNsaWVudDtcbiAgICAgIGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmksIHsgdXNlTmV3VXJsUGFyc2VyOiB0cnVlIH0pO1xuXG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcbiAgICAgIGNvbnN0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpO1xuICAgICAgY29uc3QgY29sbGVjdGlvbiA9IGRiLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKTtcblxuICAgICAgY29uc3QgY29udGV4dCA9IHtcbiAgICAgICAgY2xpZW50LFxuICAgICAgICBjb2xsZWN0aW9uLFxuICAgICAgICBkYXRhYmFzZTogZGIsXG4gICAgICB9O1xuXG4gICAgICBjb25zdCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKTtcblxuICAgICAgLy8g44Kr44O844K944Or44Gu44K/44Kk44Og44Ki44Km44OI44KS6Kej6ZmkXG4gICAgICBjdXIuYWRkQ3Vyc29yRmxhZygnbm9DdXJzb3JUaW1lb3V0JywgdHJ1ZSk7XG5cbiAgICAgIC8vIOOBmeOBueOBpuOBruODieOCreODpeODoeODs+ODiOOCkuODq+ODvOODl1xuICAgICAgdHJ5IHtcbiAgICAgICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcbiAgICAgICAgICBjb25zdCBkb2MgPSBhd2FpdCBjdXIubmV4dCgpO1xuICAgICAgICAgIGF3YWl0IG9uUmVzdWx0KGRvYywgY29udGV4dCk7XG4gICAgICAgIH1cbiAgICAgIH0gZmluYWxseSB7XG4gICAgICAgIC8vIOOCq+ODvOOCveODq+OCkumWi+aUvlxuICAgICAgICBhd2FpdCBjdXIuY2xvc2UoKTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgV293bWFBcGlJdGVtRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xuXG4gICAgLy8g5ZWG5ZOB5oOF5aCx44Gu5Y+W5b6X44Or44O844OX44KS5a6a576pXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcbiAgICAgIGNvbnN0IG9wdGlvbnMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHBsdWcpKTtcbiAgICAgIG9wdGlvbnMudXJpID0gYCR7b3B0aW9ucy51cml9L3NlYXJjaFN0b2Nrc2A7XG4gICAgICBjb25zdCBjb250ZXh0ID0ge1xuICAgICAgICBvcHRpb25zLFxuICAgICAgfTtcblxuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgLy8gV293bWEgQXBpIOOBi+OCieWVhuWTgeaDheWgseOCkuWPluW+l1xuICAgICAgICBsZXQgcmVzID0gYXdhaXQgcmVxdWVzdChvcHRpb25zKTtcbiAgICAgICAgcmVzID0geG1sMmpzKHJlcywgeyBjb21wYWN0OiB0cnVlIH0pO1xuXG4gICAgICAgIGNvbnN0IG1heENvdW50ID0gTnVtYmVyKHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQubWF4Q291bnQuX3RleHQpO1xuICAgICAgICBjb25zdCByZXN1bHRDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0LnJlc3VsdENvdW50Ll90ZXh0KTtcbiAgICAgICAgY29uc3Qgc3RhcnRDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0LnN0YXJ0Q291bnQuX3RleHQpO1xuICAgICAgICBjb25zdCByZXN1bHRTdG9ja3MgPSByZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0LnJlc3VsdFN0b2NrcztcblxuICAgICAgICAvLyDlj5blvpfjgZfjgZ/llYblk4Hmg4XloLHjgpLjgqvjgrnjgr/jg6Djg5fjg63jgrvjgrnjgavmuKHjgZlcbiAgICAgICAgaWYgKHJlc3VsdFN0b2NrcyBpbnN0YW5jZW9mIEFycmF5KSB7XG4gICAgICAgICAgLy8g5Y+W5b6X44GX44Gf44OH44O844K/44GM6KSH5pWw5ZWG5ZOB44Gu5aC05ZCIXG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHRDb3VudDsgaSsrKSB7XG4gICAgICAgICAgICBhd2FpdCBvblJlc3VsdChyZXN1bHRTdG9ja3NbaV0sIGNvbnRleHQpO1xuICAgICAgICAgIH1cbiAgICAgICAgfSBlbHNlIHtcbiAgICAgICAgICAvLyDlj5blvpfjgZfjgZ/jg4fjg7zjgr/jgYzljZjmlbDllYblk4Hjga7loLTlkIhcbiAgICAgICAgICBhd2FpdCBvblJlc3VsdChyZXN1bHRTdG9ja3MsIGNvbnRleHQpO1xuICAgICAgICB9XG5cbiAgICAgICAgY29uc3QgbmV4dCA9IHN0YXJ0Q291bnQgKyByZXN1bHRDb3VudDtcblxuICAgICAgICBpZiAobmV4dCA+IG1heENvdW50KSBicmVhaztcbiAgICAgICAgb3B0aW9ucy5xcy5zdGFydENvdW50ID0gbmV4dDtcbiAgICAgIH1cbiAgICB9KTtcbiAgfVxufVxuXG4vLyBpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xuXG4vLyBleHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcbi8vICAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xuLy8gICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xuXG4vLyAgICAgLy8gbW9uZ28g44G45o6l57aaXG4vLyAgICAgbGV0IGNyZWQgPSB0aGlzLmdldENyZWRfKCk7XG4vLyAgICAgbGV0IGNvbnVyaSA9IGBtb25nb2RiOi8vJHtjcmVkLmhvc3R9OiR7Y3JlZC5wb3J0fS8ke2NyZWQuZGF0YWJhc2V9YDtcbi8vICAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KGNvbnVyaSk7XG5cbi8vICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLkvZzjgotcbi8vICAgICBsZXQgY29sbGVjdGlvbiA9IG1vbmdvb3NlLmNvbm5lY3Rpb24uY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xuXG4vLyAgICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XG4vLyAgICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XG5cbi8vICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xuLy8gICAgIH0pO1xuLy8gICB9XG4vLyB9XG4iLCJpbXBvcnQgeyBNb25nb0NvbGxlY3Rpb24gfSBmcm9tICcuLi91dGlsL21vbmdvJztcbmltcG9ydCB7IFVwbG9hZHMsIFJvYm90aW5TaG9wIH0gZnJvbSAnLi4vY29sbGVjdGlvbnMnO1xuaW1wb3J0IFRleHRVdGlsIGZyb20gJy4uL3V0aWwvdGV4dCc7XG5cbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEl0ZW1Db250cm9sbGVyIHtcbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7e3VyaTpzdHJpbmcsIGRhdGFiYXNlOnN0cmluZywgY29sbGVjdGlvbjpzdHJpbmd9fSBwbHVnXG4gICAqL1xuICBhc3luYyBpbml0KHBsdWcpIHtcbiAgICB0aGlzLkl0ZW1zID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCAnaXRlbXMnKTtcbiAgICB0aGlzLlByb2R1Y3RzID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCAncHJvZHVjdHMnKTtcbiAgfVxuXG4gIGFzeW5jIGdldFN0b2NrKGl0ZW1JZCkge1xuICAgIGNvbnN0IGl0ZW0gPSBhd2FpdCB0aGlzLkl0ZW1zLmZpbmRPbmUoe1xuICAgICAgX2lkOiBpdGVtSWQsXG4gICAgfSwge1xuICAgICAgcHJvamVjdGlvbjoge1xuICAgICAgICBwcm9kdWN0OiAxLFxuICAgICAgfSxcbiAgICB9KTtcbiAgICBjb25zdCBwcm9kdWN0U2V0ID0gaXRlbS5wcm9kdWN0O1xuXG4gICAgLy8gcHJvZHVjdCAqIDwtPiAqIGl0ZW1cbiAgICAvLyBwcm9kdWN0W106IOikh+aVsOOBruWVhuWTgeOCkjHjg5Hjg4PjgrHjg7zjgrjjgajjgZfjgabosqnlo7JcbiAgICAvLyBwcm9kdWN0W3tpZHM6WzxPYmplY3RJZD5dLHNldDo8TnVtYmVyPn1dOiDnlbDjgarjgovmtYHpgJrntYzot6/jgIHnlbDjgarjgovljp/kvqHjg7vku5XlhaXjgozlgKRcbiAgICAvLyBpdGVtOiDnlbDjgarjgovjgrvjg7zjg6vjgIHosqnlo7LlvaLmhYtcbiAgICAvLyDigLsgcHJvZHVjdCDjgYvjgonjga/jgIHosqnlo7Llj6/og73jgarlnKjluqvjgIHliKnnm4roqIjnrpfjga7jgZ/jgoHjga7mg4XloLHjgpLlvpfjgotcblxuICAgIGNvbnN0IHF1YW50aXRpZXMgPSBbXTtcblxuICAgIGZvciAoY29uc3QgcHJvZHVjdFJlZiBvZiBwcm9kdWN0U2V0KSB7XG4gICAgICBsZXQgcHJkUXVhbnRpdHkgPSAwO1xuXG4gICAgICBmb3IgKGNvbnN0IGlkIG9mIHByb2R1Y3RSZWYuaWRzKSB7XG4gICAgICAgIGNvbnN0IHByb2R1Y3QgPSBhd2FpdCB0aGlzLlByb2R1Y3RzLmZpbmRPbmUoe1xuICAgICAgICAgIF9pZDogaWQsXG4gICAgICAgIH0sIHtcbiAgICAgICAgICBwcm9qZWN0aW9uOiB7XG4gICAgICAgICAgICBzdG9jazogMSxcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcbiAgICAgICAgY29uc3Qgc3RvY2tBcnJheSA9IHByb2R1Y3Quc3RvY2s7XG5cbiAgICAgICAgLy8g5Y2Y57SU44Gr44GZ44G544Gm44Gu5Zyo5bqr5ZWG5ZOB44CB55+t5pyf6ZaT5Y+W44KK5a+E44Gb5Y+v6IO95ZWG5ZOB44KS5ZCI566XXG4gICAgICAgIGZvciAoY29uc3Qgc3RvY2sgb2Ygc3RvY2tBcnJheSkgcHJkUXVhbnRpdHkgKz0gc3RvY2sucXVhbnRpdHk7XG4gICAgICB9XG5cbiAgICAgIC8vIOWVhuWTgShpdGVtKeOBruWcqOW6q+aVsCA9IOijveWTgeWcqOW6q+aVsChwcmRRdWFudGl0eSkgLyDlv4XopoHjgrvjg4Pjg4jmlbAocHJvZHVjdFJlZi5zZXQpXG4gICAgICBxdWFudGl0aWVzLnB1c2goTWF0aC5mbG9vcihwcmRRdWFudGl0eSAvIHByb2R1Y3RSZWYuc2V0KSk7XG4gICAgfVxuXG4gICAgLy8g44K744OD44OI5ZWG5ZOB44Gu5aC05ZCI44CB5LiA55Wq5bCR44Gq44GE5ZWG5ZOB5pWw44Gr5ZCI44KP44Gb44KLXG4gICAgY29uc3QgcXVhbnRpdHkgPSBNYXRoLm1pbi5hcHBseShudWxsLCBxdWFudGl0aWVzKTtcblxuICAgIHJldHVybiBxdWFudGl0eTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgovjgIJcbiAgICpcbiAgICog44Oh44O844Kr44O844Oi44OH44Or44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXG4gICAqIGNsYXNzMeOAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxuICAgKlxuICAgKiDnibnlrprjga7lsZ7mgKfvvIjjgqvjg6njg7zjgarjganvvInjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcbiAgICogY2xhc3Mx44Gr5YCk44KS5oyH5a6a44GX44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXG4gICAqIOOCguOBl2NsYXNzMuOBruOBv+aMh+WumuOBl+OBn+OBhOWgtOWQiOOBr2NsYXNzMeOBq251bGzjgpLmjIflrprjgZnjgovjgIJcbiAgICpcbiAgICog5L6L77yaSkstMTAw44GuQkxBQ0vjga7llYblk4HnlLvlg4/jgpJcbiAgICog44GZ44G544Gm44Gu44K144Kk44K677yIUyxNLEwsWEwsMlhMLDNYTCw0WEzigKbvvInjgavplqLpgKPku5jjgZHjgovloLTlkIhcbiAgICogc2V0SW1hZ2UoIHVwbG9hZElkLCAnSkstMTAwJywgJ0JMQUNLJyApO1xuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gdXBsb2FkSWQg5LiA5Zue44Gu44Ki44OD44OX44Ot44O844OJ55S75YOP44KS5p2f44Gt44Gm44GE44KLSUTjgIJtZXRlb3Ljg4fjg7zjgr/jg5njg7zjgrnjgIFVcGxvYWRz44Kz44Os44Kv44K344On44Oz5YaF44OJ44Kt44Ol44Oh44Oz44OI44GudXBsb2FkSWTjg5fjg63jg5Hjg4bjgqNcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xuICAgKi9cbiAgYXN5bmMgc2V0SW1hZ2UodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44Gu5oOF5aCx5Y+W5b6XXG4gICAgY29uc3QgaW1hZ2VzID0gVXBsb2Fkcy5maW5kKHtcbiAgICAgIHVwbG9hZElkLFxuICAgIH0pLmZldGNoKCkubWFwKHYgPT4gdi51cGxvYWRlZEZpbGVOYW1lKTtcblxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxuICAgIGNvbnN0IGZpbHRlciA9IHt9O1xuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsO1xuICAgIGlmIChjbGFzczEpIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczE7XG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMjtcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcbiAgICAgIGZpbHRlciwge1xuICAgICAgICAkcHVzaDoge1xuICAgICAgICAgIGltYWdlczoge1xuICAgICAgICAgICAgJGVhY2g6IGltYWdlcyxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICApO1xuXG4gICAgLy8g55m76Yyy44GX44Gf55S75YOP44OV44Kh44Kk44Or5ZCN5LiA6KanXG4gICAgcmV0dXJuIGltYWdlcztcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+eZu+mMsuOBleOCjOOBpuOBhOOCi+eUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi+OAglxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXG4gICAqL1xuICBhc3luYyBjbGVhbkltYWdlKG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXG4gICAgY29uc3QgZmlsdGVyID0ge307XG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWw7XG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMTtcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyO1xuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxuICAgICAgZmlsdGVyLCB7XG4gICAgICAgICRzZXQ6IHtcbiAgICAgICAgICBpbWFnZXM6IFtdLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgLyoqXG4gICAqIOaMh+WumuOBruWVhuWTgeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBruWxnuaAp+WIpeOBruWVhuWTgeaDheWgseOCkui/lOOBmeOAglxuICAgKlxuICAgKiDlvJXmlbDjgajjgZfjgablj5fjgZHlj5bjgotpdGVt44Gv5Lu75oSP44Gu5ZWG5ZOB5oOF5aCx44CCXG4gICAqIGl0ZW3jgavplqLpgKPjgZnjgovllYblk4HnvqTjgavjgaTjgYTjgablv4XopoHjgarmg4XloLHjgpLmlbTnkIbjgZfov5TjgZnjgIJcbiAgICpcbiAgICogcHJvamVjdOOBq+WPgueFp+OBl+OBn+OBhOWVhuWTgeaDheWgseODleOCo+ODvOODq+ODieOCkuWumue+qeOBmeOCi+OAglxuICAgKiDjg6Hjgr3jg4Pjg4njga7lkbzjgbPlh7rjgZfmmYLjgavlv4XopoHjgavlv5zjgZjjgaZwcm9qZWN044KS6Kit5a6a44GZ44KL44CCXG4gICAqXG4gICAqIOS9leOBq+azqOebruOBl+OBpuWVhuWTgeOBrumWoumAo+aAp+OCkuaknOWHuuOBmeOCi+OBi+OBr+OAgeOBk+OBruODoeOCveODg+ODieWGheOBp+Wumue+qeOBmeOCi+OAglxuICAgKlxuICAgKiBAcGFyYW0ge09iamVjdH0gaXRlbVxuICAgKiBAcGFyYW0ge09iamVjdH0gcHJvamVjdFxuICAgKi9cbiAgYXN5bmMgZ2V0VmFyaWF0aW9uKGl0ZW0sIHByb2plY3QpIHtcbiAgICAvKipcbiAgICAgKiBhZ2dyZWdhdGlvbuioreWumlxuICAgICAqXG4gICAgICogbGFiZWw6IOWxnuaAp+WQje+8iOmFjemAgeaWueazleOAgeOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqe+8iVxuICAgICAqIGN1cnJlbnQ6IOaMh+WumuOBleOCjOOBn+OCouOCpOODhuODoO+8iGl0ZW3vvInjgYzoqbLlvZPjgZnjgovpoIXnm65cbiAgICAgKiBwb3JqZWN0OiDjg5Djg6rjgqjjg7zjgrfjg6fjg7PmpJzntKLjga7jgq3jg7zjgajjgarjgotpdGVt5YaF44Gu44OV44Kj44O844Or44OJ5ZCNICRb44OV44Kj44O844Or44OJ5ZCNXeW9ouW8j1xuICAgICAqIHF1ZXJ5OiBhZ2dyZWdhdGlvbuWvvuixoeOBqOOBmeOCi+ODieOCreODpeODoeODs+ODiOOBruaknOe0ouadoeS7tlxuICAgICAqL1xuICAgIGNvbnN0IHNldCA9IFt7XG4gICAgICBsYWJlbDogJ+mFjemAgeaWueazlScsXG4gICAgICBjdXJyZW50OiBpdGVtLmRlbGl2ZXJ5LFxuICAgICAgcHJvamVjdDoge1xuICAgICAgICB2YWx1ZTogJyRkZWxpdmVyeScsXG4gICAgICB9LFxuICAgICAgcXVlcnk6IHtcbiAgICAgICAgY2xhc3MxX3ZhbHVlOiBpdGVtLmNsYXNzMV92YWx1ZSxcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB7XG4gICAgICBsYWJlbDogaXRlbS5jbGFzczFfbmFtZSxcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxuICAgICAgcHJvamVjdDoge1xuICAgICAgICB2YWx1ZTogJyRjbGFzczFfdmFsdWUnLFxuICAgICAgfSxcbiAgICAgIHF1ZXJ5OiB7XG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxuICAgICAgICBjbGFzczJfdmFsdWU6IGl0ZW0uY2xhc3MyX3ZhbHVlLFxuICAgICAgfSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGxhYmVsOiBpdGVtLmNsYXNzMl9uYW1lLFxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczJfdmFsdWUsXG4gICAgICBwcm9qZWN0OiB7XG4gICAgICAgIHZhbHVlOiAnJGNsYXNzMl92YWx1ZScsXG4gICAgICB9LFxuICAgICAgcXVlcnk6IHtcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWUsXG4gICAgICB9LFxuICAgIH0sXG4gICAgXTtcblxuICAgIGNvbnN0IGF0dHJzID0gW107XG5cbiAgICBmb3IgKGNvbnN0IHMgb2Ygc2V0KSB7XG4gICAgICBhdHRycy5wdXNoKHtcbiAgICAgICAgdmFyaWF0aW9uczogYXdhaXQgdGhpcy5JdGVtcy5hZ2dyZWdhdGUoXG4gICAgICAgICAgW3tcbiAgICAgICAgICAgICRtYXRjaDogT2JqZWN0LmFzc2lnbihzLnF1ZXJ5LCB7XG4gICAgICAgICAgICAgIG1vZGVsOiBpdGVtLm1vZGVsLFxuICAgICAgICAgICAgfSksXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICAkcHJvamVjdDogT2JqZWN0LmFzc2lnbihzLnByb2plY3QsIHByb2plY3QpLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgJHNvcnQ6IHtcbiAgICAgICAgICAgICAgX2lkOiAxLFxuICAgICAgICAgICAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIF0sXG4gICAgICAgICkudG9BcnJheSgpLFxuICAgICAgICBwcm9wczogcyxcbiAgICAgIH0pO1xuICAgIH1cblxuICAgIGZvciAoY29uc3QgYXR0ciBvZiBhdHRycykgZm9yIChjb25zdCB2IG9mIGF0dHIudmFyaWF0aW9ucykgdi5zdG9jayA9IGF3YWl0IHRoaXMuZ2V0U3RvY2sodi5faWQpO1xuXG5cbiAgICByZXR1cm4gYXR0cnM7XG4gIH1cblxuICAvLyDjg6Ljg4fjg6vjgq/jg6njgrnlvaLlvI/jgpLkvZzjgotcbiAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxuICBhc3luYyBnZXRNb2RlbENsYXNzKGFyZykge1xuICAgIGxldCBpdGVtO1xuICAgIC8vIGl0ZW0g44GM5paH5a2X5YiX44Gq44KJ44CBaXRlbeOBr+S7u+aEj+OBruOCquODluOCuOOCp+OCr+ODiElE44Gu5pyr5bC+44GL44KJ5Lu75oSP44Gu5qGB5pWw44GuMTbpgLLmlbBcbiAgICBpZiAodHlwZW9mIGFyZyA9PT0gJ3N0cmluZycpIHtcbiAgICAgIGNvbnN0IGV4cCA9IG5ldyBSZWdFeHAoYCR7YXJnfSRgKTtcbiAgICAgIGNvbnN0IGN1ciA9IHRoaXMuSXRlbXMuZmluZCh7fSwge1xuICAgICAgICBwcm9qZWN0aW9uOiB7XG4gICAgICAgICAgbW9kZWw6IDEsXG4gICAgICAgICAgY2xhc3MxX3ZhbHVlOiAxLFxuICAgICAgICAgIGNsYXNzMl92YWx1ZTogMSxcbiAgICAgICAgfSxcbiAgICAgIH0pO1xuXG4gICAgICB3aGlsZSAoMSkge1xuICAgICAgICB0cnkge1xuICAgICAgICAgIGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpO1xuICAgICAgICAgIGNvbnN0IG1hdGNoID0gYXdhaXQgaXRlbS5faWQudG9IZXhTdHJpbmcoKS5tYXRjaChleHApO1xuICAgICAgICAgIGlmIChtYXRjaCkgYnJlYWs7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyDoqbLlvZPjgZnjgotpdGVt44OH44O844K/44GM44Gq44GEXG4gICAgICAgICAgY3VyLmNsb3NlKCk7XG4gICAgICAgICAgcmV0dXJuIGFyZztcbiAgICAgICAgfVxuICAgICAgfVxuICAgICAgY3VyLmNsb3NlKCk7XG4gICAgfSBlbHNlIHtcbiAgICAgIGl0ZW0gPSBhcmc7XG4gICAgfVxuXG4gICAgY29uc3QgbW9kZWxDbGFzcyA9IFtdO1xuICAgIGlmIChpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbCk7XG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpO1xuICAgIGlmIChpdGVtLmNsYXNzMl92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MyX3ZhbHVlKTtcbiAgICByZXR1cm4gbW9kZWxDbGFzcy5qb2luKCcvJyk7XG4gIH1cblxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzKGNvbmZpZ1VwbG9hZEl0ZW0sIGl0ZW0pIHtcbiAgICAvLyDlgKTlpInmj5tcbiAgICBjb25zdCBjb252RGVsaXYgPSBkZWxpdmVyeSA9PiAoZGVsaXZlcnkgPT09ICfjgobjgYbjg5HjgrHjg4Pjg4gnID8gJ+ODneOCueODiOaKleWHvScgOiBkZWxpdmVyeSk7XG5cbiAgICAvLyBwcm9kdWN0X2lkXG4gICAgY29uc3QgcHJvZHVjdElkID0gbnVsbDtcbiAgICBjb25zdCBtb2RlbENsYXNzID0gW107XG5cbiAgICAvLyDkuIvoqJjjga7lvaLlvI/jgpLkvZzjgotcbiAgICAvLyBb44Oh44O844Kr44O844Kz44O844OJXS9b5bGe5oCnMe+8iOOCq+ODqeODvOOBquOBqe+8iV0vW+WxnuaApzLvvIjjgrXjgqTjgrrjgarjganvvIldXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKTtcbiAgICBpZiAoaXRlbS5jbGFzczFfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMV92YWx1ZSk7XG4gICAgaWYgKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpO1xuXG4gICAgLy8g5ZWG5ZOB56iu5Yil44KS5Ymy44KK5b2T44Gm44KLXG4gICAgbGV0IHByb2R1Y3RUeXBlSWQ7XG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XG4gICAgICBjYXNlICflroXphY3kvr8nOlxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMjtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMTtcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgLy8g5ZWG5ZOB44K/44Kw44KS6Kit5a6a44GZ44KLXG4gICAgY29uc3QgdGFncyA9IFtdO1xuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcbiAgICAgICAgdGFncy5wdXNoKHtcbiAgICAgICAgICB0YWc6IDQsXG4gICAgICAgICAgc2V0OiAnb24nLFxuICAgICAgICB9LCB7XG4gICAgICAgICAgdGFnOiA1LFxuICAgICAgICAgIHNldDogJ29mZicsXG4gICAgICAgIH0pO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XG4gICAgICAgIHRhZ3MucHVzaCh7XG4gICAgICAgICAgdGFnOiA1LFxuICAgICAgICAgIHNldDogJ29uJyxcbiAgICAgICAgfSwge1xuICAgICAgICAgIHRhZzogNCxcbiAgICAgICAgICBzZXQ6ICdvZmYnLFxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICAvLyDllYblk4HliKXpgIHmlpnjgpLoqK3lrprjgZnjgotcbiAgICBsZXQgZGVsaXZlcnlGZWUgPSBudWxsO1xuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBudWxsO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XG4gICAgICAgIGRlbGl2ZXJ5RmVlID0gMjQwO1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIC8vXG4gICAgLy8g6aGn5a6i5ZCR44GR44OQ44Oq44Ko44O844K344On44Oz5ZWG5ZOB6YG45oqe5qmf6IO944Gu5a6f6KOFXG4gICAgLy9cblxuICAgIGxldCBhdHRycyA9IGF3YWl0IHRoaXMuZ2V0VmFyaWF0aW9uKGl0ZW0sIHtcbiAgICAgIHByb2R1Y3RfaWQ6ICckbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJyxcbiAgICB9KTtcblxuICAgIC8vIEhUTUwg44OQ44Oq44Ko44O844K344On44Oz5ZWG5ZOB44GU44Go44Gu44Oq44Oz44Kv5LuY44GN44Oc44K/44Oz44KS6KGo56S644GZ44KLXG5cbiAgICAvLyDlgKTjga7lpInmj5tcbiAgICBhdHRycyA9IGF0dHJzLm1hcChcbiAgICAgIChhdHRyKSA9PiB7XG4gICAgICAgIGF0dHIucHJvcHMuY3VycmVudCA9IGNvbnZEZWxpdihhdHRyLnByb3BzLmN1cnJlbnQpO1xuICAgICAgICBhdHRyLnZhcmlhdGlvbnMgPSBhdHRyLnZhcmlhdGlvbnMubWFwKFxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcbiAgICAgICAgICAgIHZhcmlhdGlvbi52YWx1ZSA9IGNvbnZEZWxpdih2YXJpYXRpb24udmFsdWUpO1xuICAgICAgICAgICAgcmV0dXJuIHZhcmlhdGlvbjtcbiAgICAgICAgICB9LFxuICAgICAgICApO1xuICAgICAgICByZXR1cm4gYXR0cjtcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIC8vIEhUTUznlJ/miJBcbiAgICBjb25zdCB2YXJpYXRpb25IdG1sID0gYXR0cnMubWFwKFxuICAgICAgYXR0ciA9PiBgJHsnPGRpdiBjbGFzcz1cImNvbnRhaW5lci1mbHVpZFwiPidcbiAgICAgICAgKyAnPGRpdiBjbGFzcz1cInJvd1wiPidcbiAgICAgICAgKyAnPGRpdiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLWJsb2NrIGJ0bi14c1wiPidcbiAgICAgICAgKyBgPHN0cm9uZz4ke2F0dHIucHJvcHMubGFiZWx9PC9zdHJvbmc+YFxuICAgICAgICArICc8L2Rpdj4nfSR7XG4gICAgICAgIGF0dHIudmFyaWF0aW9ucy5tYXAoXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xuICAgICAgICAgICAgaWYgKGF0dHIucHJvcHMuY3VycmVudCA9PT0gdmFyaWF0aW9uLnZhbHVlKSB7XG4gICAgICAgICAgICAgIC8vIOihqOekuuS4reOBruWVhuWTgeODnOOCv+ODs1xuICAgICAgICAgICAgICByZXR1cm4gYDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXN1Y2Nlc3MgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPjxzdHJvbmc+JHt2YXJpYXRpb24udmFsdWV9PC9zdHJvbmc+PC9idXR0b24+YDtcbiAgICAgICAgICAgIH0gaWYgKHZhcmlhdGlvbi5zdG9jayA+IDApIHtcbiAgICAgICAgICAgICAgLy8g6LKp5aOy5Y+v6IO95ZWG5ZOB44Gu44Oc44K/44OzXG4gICAgICAgICAgICAgIHJldHVybiBgPGEgaHJlZj1cIi9wcm9kdWN0cy9kZXRhaWwvJHt2YXJpYXRpb24ucHJvZHVjdF9pZH1cIj48YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj48L2E+YDtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICAgIC8vIOiyqeWjsuS4jeWPr+iDveWVhuWTgeOBruODnOOCv+ODs++8iOWcqOW6q+OBquOBl++8iVxuICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgZGF0YS10b2dnbGU9XCJ0b29sdGlwXCIgdGl0bGU9XCLlnKjluqvjgYzjgZTjgZbjgYTjgb7jgZvjgpNcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj5gO1xuICAgICAgICAgIH0sXG4gICAgICAgICkuam9pbignJylcbiAgICAgIH08L2Rpdj5gXG4gICAgICAgICsgJzwvZGl2PicsXG4gICAgKS5qb2luKCcnKTtcblxuICAgIGNvbnN0IGRlc2NyaXB0aW9uRGV0YWlsID0gYFxuICAgIDxzbWFsbD7igLsg6YWN6YCB5pa55rOV44O744Kr44Op44O844O744K144Kk44K644Gv5LiL6KiY44GL44KJ44GK6YG444Gz44GP44Gg44GV44GE44CCPC9zbWFsbD5cbiAgICAke3ZhcmlhdGlvbkh0bWx9XG4gICAgYDtcblxuICAgIC8vIOWVhuWTgeODh+ODvOOCv+OCkuS9nOOCi1xuICAgIGNvbnN0IGRhdGEgPSB7XG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXG4gICAgICBjcmVhdG9yX2lkOiBjb25maWdVcGxvYWRJdGVtLmNyZWF0b3JfaWQsXG4gICAgICBuYW1lOiBgJHttb2RlbENsYXNzLmpvaW4oJy8nKX0gJHtjb252RGVsaXYoaXRlbS5kZWxpdmVyeSl9ICR7aXRlbS5uYW1lfSR7aXRlbS5qYW5fY29kZSA/IGAgJHtpdGVtLmphbl9jb2RlfWAgOiAnJ31gLFxuICAgICAgZGVzY3JpcHRpb25fZGV0YWlsOiBkZXNjcmlwdGlvbkRldGFpbCxcbiAgICAgIC8vIGZyZWVfYXJlYTogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlRnJlZUFyZWEoaXRlbSksXG4gICAgICBwcm9kdWN0X2NvZGU6IG1vZGVsQ2xhc3Muam9pbignLycpLFxuICAgICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXG4gICAgICAvLyBwcmljZTAyOiBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyKGl0ZW0pLFxuICAgICAgLy8gaW1hZ2VzOiBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVJbWFnZXMoaXRlbSksXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RUeXBlSWQsXG4gICAgICB0YWdzLFxuICAgICAgZGVsaXZlcnlfZmVlOiBkZWxpdmVyeUZlZSxcbiAgICB9O1xuXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVGcmVlQXJlYShjb25maWdVcGxvYWRJdGVtLCBpdGVtKSk7XG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyKGNvbmZpZ1VwbG9hZEl0ZW0sIGl0ZW0pKTtcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZUltYWdlcyhjb25maWdVcGxvYWRJdGVtLCBpdGVtKSk7XG5cbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcCk7XG5cbiAgICByZXR1cm4gZGF0YTtcbiAgfVxuXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVGcmVlQXJlYShjb25maWdVcGxvYWRJdGVtLCBpdGVtKSB7XG4gICAgbGV0IGZyZWVBcmVhID0gJyc7XG4gICAgLy8g5ZWG5ZOB5oOF5aCx44OG44Kt44K544OI44KS6KiY6LyJ44GZ44KLXG4gICAgZnJlZUFyZWEgKz0gaXRlbS5kZXNjcmlwdGlvbjtcbiAgICAvLyAy55Wq55uu5Lul6ZmN44Gu55S75YOP44KS44OV44Oq44O844Ko44Oq44Ki44Gr6KiY6LyJ44GZ44KLXG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBpdGVtLmltYWdlcy5sZW5ndGg7IGkrKykgZnJlZUFyZWEgKz0gYDxpbWcgc3JjPVwiL3VwbG9hZC9zYXZlX2ltYWdlLyR7aXRlbS5pbWFnZXNbaV19XCI+PGJyPmA7XG5cbiAgICAvLyDmg4XloLHjga7jgq/jg6rjgqJcbiAgICBmcmVlQXJlYSArPSAnICc7XG4gICAgcmV0dXJuIHsgZnJlZV9hcmVhOiBmcmVlQXJlYSB9O1xuICB9XG5cbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlM2NyZWF0ZVByaWNlMDIoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkge1xuICAgIC8vIOS+oeagvOOCkui/lOOBmVxuICAgIHJldHVybiB7IHByaWNlMDI6IGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcmljZSB9O1xuICB9XG5cbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlM2NyZWF0ZUltYWdlcyhjb25maWdVcGxvYWRJdGVtLCBpdGVtKSB7XG4gICAgLy8g55S75YOP44Oq44K544OI44Gu44GG44GhMeOBpOOCgeOBoOOBkeOCkui/lOOBmVxuICAgIGNvbnN0IGFyciA9IHR5cGVvZiBpdGVtLmltYWdlc1swXSA9PT0gJ3VuZGVmaW5lZCcgPyBbXSA6IFtpdGVtLmltYWdlc1swXV07XG4gICAgcmV0dXJuIHsgaW1hZ2VzOiBhcnIgfTtcbiAgfVxuXG4gIC8vIOODpOODleOCquOCr+ODhuODs+ODl+ODrOODvOODiOOBuOOBruWkieaPm1xuICBhc3luYyBjb252ZXJ0SXRlbVlhdWN0MShjb25maWcsIGl0ZW0pIHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtWWF1Y3QoY29uZmlnLmRlZmF1bHQsIGl0ZW0pO1xuICAgIHJldHVybiByZXM7XG4gIH1cblxuICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjgbjjga7lpInmj5tcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdChkZWYsIGl0ZW0pIHtcbiAgICBjb25zdCBpZExlbmd0aCA9IDIwO1xuICAgIGNvbnN0IHRpdGxlTGVuZ3RoID0gMTMwO1xuXG4gICAgbGV0IHlhdWN0ID0ge307XG4gICAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44Gu5Yid5pyf5YCk77yI44KG44GG44OR44Kx44OD44OI44O75a6F6YWN5L6/44Gn55Ww44Gq44KL77yJXG4gICAgeWF1Y3QgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGRlZltpdGVtLmRlbGl2ZXJ5XSkpO1xuXG4gICAgLy8g55S75YOP44Gu6KiY6L+wXG4gICAgY29uc3QgaW1nUHJlZml4ID0gJ+eUu+WDjyc7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtLmltYWdlcy5sZW5ndGg7IGkrKykgeWF1Y3RbaW1nUHJlZml4ICsgKGkgKyAxKV0gPSBpdGVtLmltYWdlc1tpXTtcblxuXG4gICAgLy8g44K/44Kk44OI44OrXG4gICAgeWF1Y3RbJ+OCq+ODhuOCtOODqiddID0gaXRlbS5tYWxsLnlhdWN0LmNhdGVnb3J5O1xuICAgIHlhdWN0Wyfjgr/jgqTjg4jjg6snXSA9IFRleHRVdGlsLnN1YnN0cjgoYCR7YXdhaXQgdGhpcy5nZXRNb2RlbENsYXNzKGl0ZW0pfSAke2l0ZW0uZGVsaXZlcnl9ICR7aXRlbS5uYW1lfWAsIHRpdGxlTGVuZ3RoKTtcbiAgICB5YXVjdFsn6ZaL5aeL5L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlO1xuICAgIHlhdWN0WyfljbPmsbrkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2U7XG4gICAgeWF1Y3RbJ+euoeeQhueVquWPtyddID0gaXRlbS5faWQudG9IZXhTdHJpbmcoKS5zbGljZSgtaWRMZW5ndGgpO1xuICAgIGlmICh0eXBlb2YgeWF1Y3RbJ+iqrOaYjiddID09PSAnc3RyaW5nJykgeWF1Y3RbJ+iqrOaYjiddID0gYCR7aXRlbS5kZXNjcmlwdGlvbn08YnI+PGJyPiR7eWF1Y3RbJ+iqrOaYjiddfWA7XG4gICAgZWxzZSB5YXVjdFsn6Kqs5piOJ10gPSBpdGVtLmRlc2NyaXB0aW9uO1xuXG4gICAgeWF1Y3RbJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXSA9IGl0ZW0uamFuX2NvZGU7XG5cbiAgICByZXR1cm4geWF1Y3Q7XG4gIH1cblxuICBhc3luYyBjb252ZXJ0SXRlbVdvd21hQ3JlYXRlRGVsaXZlcnlNZXRob2QoaXRlbUNvZGUpIHtcbiAgICBjb25zdCBpZCA9ICdtYWxsLndvd21hLml0ZW1Db2RlJztcbiAgICBjb25zdCBzZXQgPSAnZGVsaXZlcnknO1xuICAgIGNvbnN0IG1ldHJpY3MgPSB7XG4gICAgICDjgobjgYbjg5HjgrHjg4Pjg4g6IFsnUG9zdCddLFxuICAgICAg5a6F6YWN5L6/OiBbJ1lVLVBhY2snLCAnS2FuZ2Fyb28nXSxcbiAgICB9O1xuICAgIC8vIGRlbGl2ZXJ5TWV0aG9kU2VxXG5cbiAgICBjb25zdCBhZ2dyID0gYXdhaXQgdGhpcy5JdGVtcy5hZ2dyZWdhdGUoXG4gICAgICBbXG4gICAgICAgIHtcbiAgICAgICAgICAkbWF0Y2g6IHtcbiAgICAgICAgICAgIFtpZF06IGl0ZW1Db2RlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAkZ3JvdXA6IHtcbiAgICAgICAgICAgIF9pZDogYCQke2lkfWAsXG4gICAgICAgICAgICBbc2V0XTogeyAkYWRkVG9TZXQ6IGAkJHtzZXR9YCB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAkcHJvamVjdDoge1xuICAgICAgICAgICAgX2lkOiAwLFxuICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJyxcbiAgICAgICAgICAgIFtzZXRdOiBgJCR7c2V0fWAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgKS50b0FycmF5KCk7XG5cbiAgICBsZXQgYWNjZXB0RGVsaXYgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGRlbCBvZiBhZ2dyWzBdLmRlbGl2ZXJ5KSBhY2NlcHREZWxpdiA9IGFjY2VwdERlbGl2LmNvbmNhdChtZXRyaWNzW2Ake2RlbH1gXSk7XG5cblxuICAgIGNvbnN0IGRlbGl2ZXJ5TWV0aG9kID0gbmV3IEFycmF5KDUpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGVsaXZlcnlNZXRob2QubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGlkID0gdHlwZW9mIGFjY2VwdERlbGl2W2ldID09PSAndW5kZWZpbmVkJyA/ICdOVUxMJyA6IGFjY2VwdERlbGl2W2ldO1xuICAgICAgZGVsaXZlcnlNZXRob2RbaV0gPSB7IGRlbGl2ZXJ5TWV0aG9kU2VxOiBpICsgMSwgZGVsaXZlcnlNZXRob2RJZDogaWQgfTtcbiAgICB9XG5cbiAgICByZXR1cm4geyBkZWxpdmVyeU1ldGhvZCB9O1xuICB9XG5cbiAgLy9cbiAgLy8gUm9ib3QtaW4g5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+344Gu55m76Yyy44Gu44Gf44KB44Gu44OH44O844K/44KS5L2c44KLXG4gIC8vIOOBneOBrjEgaXRlbS5jc3ZcblxuICBzdGF0aWMgY29udmVydEl0ZW1Sb2JvdGluSXRlbShpdGVtKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIOOCs+ODs+ODiOODreODvOODq+OCq+ODqeODoDogJ24nLFxuICAgICAg5paw6KaP55m76YyySUQ6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXG4gICAgICDllYblk4FJRDogbnVsbCxcbiAgICAgIOWVhuWTgeWQjTogYCR7aXRlbS5tb2RlbH0ke2l0ZW0uY2xhc3MxX3ZhbHVlID09PSAnJyA/ICcnIDogYC8ke2l0ZW0uY2xhc3MxX3ZhbHVlfWB9JHtpdGVtLmNsYXNzMl92YWx1ZSA9PT0gJycgPyAnJyA6IGAvJHtpdGVtLmNsYXNzMl92YWx1ZX1gfWAsXG4gICAgICDopo/moLw6ICfjgarjgZcnLFxuICAgIH07XG4gIH1cblxuICAvL1xuICAvLyBSb2JvdC1pbiDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7fjga7nmbvpjLLjga7jgZ/jgoHjga7jg4fjg7zjgr/jgpLkvZzjgotcbiAgLy8g44Gd44GuMiBzZWxlY3QuY3N2XG5cbiAgc3RhdGljIGNvbnZlcnRJdGVtUm9ib3RpblNlbGVjdChpdGVtKSB7XG4gICAgY29uc3Qgc2VsZWN0ID0ge1xuICAgICAg44Kz44Oz44OI44Ot44O844Or44Kr44Op44OgOiAnbicsXG4gICAgICDmlrDopo/nmbvpjLJJRDogaXRlbS5faWQudG9IZXhTdHJpbmcoKSxcbiAgICAgIOWVhuWTgUlEOiBudWxsLFxuICAgICAg5aSW6YOo6YCj5pC6SUQ6IG51bGwsXG4gICAgICDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7c6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXG4gICAgfTtcblxuICAgIGNvbnN0IHNob3BzID0gUm9ib3RpblNob3AuZmluZCgpO1xuXG4gICAgc2hvcHMuZm9yRWFjaChcbiAgICAgIChkb2MsIGluZGV4KSA9PiB7XG4gICAgICAgIGxldCBtb2RlbDtcbiAgICAgICAgbGV0IGNsYXNzMTtcbiAgICAgICAgbGV0IGNsYXNzMjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyDjg6Ljg7zjg6vjga7llYblk4Hnlarlj7fjgpLnibnlrprjgZnjgotcbiAgICAgICAgICBtb2RlbCA9IGl0ZW0ubWFsbFtgJHtkb2MubmFtZX1gXVtgJHtkb2MubW9kZWxQYXRofWBdO1xuICAgICAgICAgIG1vZGVsID0gdHlwZW9mIG1vZGVsID09PSAndW5kZWZpbmVkJyA/ICcnIDogbW9kZWw7XG4gICAgICAgICAgY2xhc3MxID0gaXRlbS5tYWxsW2Ake2RvYy5uYW1lfWBdW2Ake2RvYy5jbGFzczFQYXRofWBdO1xuICAgICAgICAgIGNsYXNzMSA9IHR5cGVvZiBjbGFzczEgPT09ICd1bmRlZmluZWQnID8gJycgOiBjbGFzczE7XG4gICAgICAgICAgY2xhc3MyID0gaXRlbS5tYWxsW2Ake2RvYy5uYW1lfWBdW2Ake2RvYy5jbGFzczJQYXRofWBdO1xuICAgICAgICAgIGNsYXNzMiA9IHR5cGVvZiBjbGFzczIgPT09ICd1bmRlZmluZWQnID8gJycgOiBjbGFzczI7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyDllYblk4Hjga7jg6Ljg7zjg6vmg4XloLHjga7lj5blvpfjgavlpLHmlZfjgZfjgZ/vvIjjg4fjg7zjgr/jgYzoqK3lrprjgZXjgozjgabjgYTjgarjgYTjgarjganvvIlcbiAgICAgICAgICAvLyBtb2RlbCA9IGl0ZW0ubW9kZWxcbiAgICAgICAgICAvLyBjbGFzczEgPSBpdGVtLmNsYXNzMV92YWx1ZVxuICAgICAgICAgIC8vIGNsYXNzMiA9IGl0ZW0uY2xhc3MyX3ZhbHVlXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2VsZWN0W2Dlj5fms6jllYblk4FJRF8ke2luZGV4fWBdID0gbnVsbDtcbiAgICAgICAgc2VsZWN0W2DlupfoiJdJRF8ke2luZGV4fWBdID0gZG9jWyflupfoiJdJRCddO1xuICAgICAgICBzZWxlY3RbYOW6l+iIl+WQjV8ke2luZGV4fWBdID0gZG9jLm5hbWU7XG4gICAgICAgIHNlbGVjdFtg5Y+X5rOo5ZWG5ZOB55Wq5Y+3XyR7aW5kZXh9YF0gPSBgJHttb2RlbH0ke2NsYXNzMX0ke2NsYXNzMn1gO1xuICAgICAgICBzZWxlY3RbYOacieWKueODleODqeOCsF8ke2luZGV4fWBdID0gJ+acieWKuSc7XG4gICAgICB9LFxuICAgICk7XG5cbiAgICByZXR1cm4gc2VsZWN0O1xuICB9XG5cbiAgLy9cbiAgLy8gUm9ib3QtaW4g5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+344Gu55m76Yyy44Gu44Gf44KB44Gu44OH44O844K/44KS5L2c44KLXG4gIC8vIOOBneOBrjMgc2VsZWN0U2hvcC5jc3ZcblxuICBzdGF0aWMgY29udmVydEl0ZW1Sb2JvdGluU2VsZWN0U2hvcChzaG9wLCBpdGVtKSB7XG4gICAgY29uc3QgbW9kZWwgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AubW9kZWxQYXRofWBdO1xuICAgIGNvbnN0IGNsYXNzMSA9IGl0ZW0ubWFsbFtgJHtzaG9wLm5hbWV9YF1bYCR7c2hvcC5jbGFzczFQYXRofWBdO1xuICAgIGNvbnN0IGNsYXNzMiA9IGl0ZW0ubWFsbFtgJHtzaG9wLm5hbWV9YF1bYCR7c2hvcC5jbGFzczJQYXRofWBdO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIOOCs+ODs+ODiOODreODvOODq+OCq+ODqeODoDogJ3UnLFxuICAgICAg5paw6KaP55m76YyySUQ6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXG4gICAgICDlj5fms6jllYblk4FJRDogbnVsbCxcbiAgICAgIOW6l+iIl0lEOiBzaG9wWyflupfoiJdJRCddLFxuICAgICAg5bqX6IiX5ZCNOiBudWxsLFxuICAgICAg5Y+X5rOo5ZWG5ZOB55Wq5Y+3OiBgJHttb2RlbH0ke2NsYXNzMX0ke2NsYXNzMn1gLFxuICAgICAg5pyJ5Yq544OV44Op44KwOiAn5pyJ5Yq5JyxcbiAgICB9O1xuICB9XG59XG4iLCJpbXBvcnQge1xuICBNb25nb1xufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xuaW1wb3J0IHtcbiAgT2JqZWN0SURcbn0gZnJvbSAnYnNvbic7XG5pbXBvcnQgVGV4dFV0aWwgZnJvbSAnLi4vdXRpbC90ZXh0JztcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuL2l0ZW1zJztcbmltcG9ydCB7XG4gIFJvYm90aW5PcmRlcnNcbn0gZnJvbSAnLi4vY29sbGVjdGlvbnMnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSb2JvdGluIHtcblxuICBjb25zdHJ1Y3RvciAoKSB7XG4gICAgLy8gaW1wb3J0T3JkZXJUZW1wIOOBq+mWoumAo1xuICAgIC8vIOWPl+eZuuazqOOCt+OCueODhuODoOOBp+OBr+WHpueQhuOBp+OBjeOBquOBhOS+i+WklueahOWPl+azqOWHpueQhuOBq+WvvuOBl+OBplxuICAgIC8vIOWAi+WIpeOBrumAgeOCiueKtueZuuihjOOBquOBqeOCkuihjOOBhlxuICAgIHRoaXMuT3JkZXIgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihudWxsKVxuICB9XG5cbiAgc3RhdGljIGNyZWF0ZVJlYWRhYmxlT3JkZXIocXVlcnkgPSB7fSkge1xuICAgIHJldHVybiBSb2JvdGluT3JkZXJzLnJhd0NvbGxlY3Rpb24oKS5maW5kKHF1ZXJ5LCB7X2lkOjAsIHJvYm90aW46MX0pLnN0cmVhbSgpXG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHsqfSBkb2NPcmRlclxuICAgKiBAcGFyYW0ge0l0ZW1Db250cm9sbGVyfSBpdGVtU1xuICAgKi9cbiAgaW1wb3J0T3JkZXJUZW1wIChkb2NPcmRlciwgaXRlbVMpIHtcbiAgICAvLyDlj5fms6jjg4fjg7zjgr/jgpLjg4fjg7zjgr/jg5njg7zjgrnjgavkv53lrZhcbiAgICB0aGlzLk9yZGVyLmluc2VydCh7cm9ib3Rpbjpkb2NPcmRlcn0pXG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHsqfSBkb2NPcmRlclxuICAgKiBAcGFyYW0ge0l0ZW1Db250cm9sbGVyfSBpdGVtQ29uXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgaW1wb3J0T3JkZXIoZG9jT3JkZXIsIGl0ZW1Db24pIHtcbiAgICAvLyDllYblk4Hnlarlj7fjgpJtb25nb0lk44Go44GX44Gm5qSc57Si44GX44CB6Kmy5b2T44GZ44KLaXRlbeOBjOOBguOCjOOBsOabuOOBjeaPm+OBiOOCi1xuICAgIC8vIGlmIChPYmplY3RJRC5pc1ZhbGlkKGRvY09yZGVyWyfllYblk4HjgrPjg7zjg4knXSkpIHtcbiAgICAvLyAgIGNvbnN0IGl0ZW0gPSBhd2FpdCBpdGVtQ29uLkl0ZW1zLmZpbmRPbmUoeyBfaWQ6IG5ldyBPYmplY3RJRChkb2NPcmRlclsn5ZWG5ZOB44Kz44O844OJJ10pIH0pO1xuICAgIC8vICAgaWYgKGl0ZW0pIGRvY09yZGVyWyfllYblk4HjgrPjg7zjg4knXSA9IGF3YWl0IGl0ZW1Db24uZ2V0TW9kZWxDbGFzcyhpdGVtKTtcbiAgICAvLyB9XG5cbiAgICAvLyDlj5fms6jjg4fjg7zjgr/jgpLjg4fjg7zjgr/jg5njg7zjgrnjgavkv53lrZhcbiAgICBjb25zdCBpbnNlcnREb2MgPSB7XG4gICAgICByb2JvdGluOiBkb2NPcmRlclxuICAgIH1cblxuICAgIC8vIOOBmeOBp+OBq+WPl+azqOOBjOWPluOCiui+vOOBvuOCjOOBpuOBhOOBn+WgtOWQiOOBr+OAgWRvY09yZGVy44Gu5YaF5a6544Gr5pu05paw44GZ44KLXG4gICAgLy8g5Y+W44KK6L6844G+44KM44Gm44GE44Gq44GE5Y+X5rOo44Gu5aC05ZCI44Gv5paw6KaP55m76Yyy44GZ44KLXG4gICAgUm9ib3Rpbk9yZGVycy51cGRhdGUoe1xuICAgICAgJ3JvYm90aW4u5Y+X5rOoSUQnOiBkb2NPcmRlclsn5Y+X5rOoSUQnXSxcbiAgICAgICdyb2JvdGluLuaYjue0sElEJzogZG9jT3JkZXJbJ+aYjue0sElEJ11cbiAgICB9LCB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIHJvYm90aW46IGRvY09yZGVyXG4gICAgICB9XG4gICAgfSwge1xuICAgICAgdXBzZXJ0OiB0cnVlXG4gICAgfSlcblxuICAgIC8vIOeZuuazqOOCueODhuODvOOCv+OCueOBjOioreWumuOBleOCjOOBpuOBhOOBquOBhOODieOCreODpeODoeODs+ODiO+8iOaWsOimj+eZu+mMsuWPl+azqO+8iVxuICAgIC8vIOeZuuazqOOCueODhuODvOOCv+OCueOBruWIneacn+WApOOCkuioreWumuOBmeOCi1xuICAgIFJvYm90aW5PcmRlcnMudXBkYXRlKHtcbiAgICAgIHZlbmRvcjogeyRleGlzdHM6MH1cbiAgICB9LHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgdmVuZG9yOiB7IC8vIOeZuuazqOOCueODhuODvOOCv+OCueOBruWIneacn+WApFxuICAgICAgICAgIG9yZGVydG86IFwiXCIsIC8vIOeZuuazqOWFiFxuICAgICAgICAgIG9yZGVyRGF0ZTogbnVsbCwgLy8g55m65rOo5pelXG4gICAgICAgICAgcHJvbWlzZTogbnVsbCwgLy8g55m66YCB5LqI5a6a5pelXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICB9KVxuICB9XG5cbiAgc3RhdGljIGxpc3RJdGVtQ29kZUZvckxhYmVsKHF1ZXJ5LCBjb2xsZWN0aW9uID0gbnVsbCkge1xuICAgIC8vIOWPl+azqOOCt+OCueODhuODoOS+i+WkluOBruWgtOWQiOOAgeS7u+aEj+OBruOCs+ODrOOCr+OCt+ODp+ODs++8iG1pbmltb25nb+OBruS4gOaZguODh+ODvOOCv+ODmeODvOOCue+8ieOBjOmBuOaKnuOBp+OBjeOCi1xuICAgIGNvbGxlY3Rpb24gPSBjb2xsZWN0aW9uID09PSBudWxsID8gUm9ib3Rpbk9yZGVycyA6IGNvbGxlY3Rpb247XG5cbiAgICAvLyDmpJzntKLmnaHku7bjgavoqbLlvZPjgZnjgovlj5fms6jjgpLoqr/jgbnjgotcbiAgICBjb25zdCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoXG4gICAgICBxdWVyeSwge1xuICAgICAgICBmaWVsZHM6IHtcbiAgICAgICAgICBfaWQ6IDAsXG4gICAgICAgICAgJ3JvYm90aW4u5ZWG5ZOB44Kz44O844OJJzogMSxcbiAgICAgICAgICAncm9ib3Rpbi7mlbDph48nOiAxXG4gICAgICAgIH1cbiAgICAgIH1cbiAgICApO1xuICAgIC8vIOmAgeOCiueKtuODrOOCs+ODvOODieOBq+ipsuW9k+OBmeOCi+WPl+azqOODrOOCs+ODvOODieOBjOimi+OBpOOBi+OCieOBquOBhOWgtOWQiFxuICAgIGlmICghY3VyLmNvdW50KCkpIHRocm93IG5ldyBFcnJvcign6YCB44KK54q244Gr5a++5b+c44GZ44KL5Y+X5rOo44GM6KaL44Gk44GL44KK44G+44Gb44KT44CCQ1NW44OV44Kh44Kk44Or44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgLy8g5ZWG5ZOB44Oq44K544OI44KS5L2c5oiQ44GZ44KLXG4gICAgbGV0IGxpc3QgPSBbXTtcbiAgICBjdXIuZm9yRWFjaChkb2MgPT4ge1xuICAgICAgbGV0IHEgPSBkb2Mucm9ib3Rpbi7mlbDph48gPT0gMSA/ICcnIDogYFske2RvYy5yb2JvdGluLuaVsOmHj31FQV1gO1xuICAgICAgbGlzdC5wdXNoKGAke2RvYy5yb2JvdGluLuWVhuWTgeOCs+ODvOODiX0gJHtxfWApXG4gICAgfSlcbiAgICAvLyDllYblk4Hjg6rjgrnjg4jjgpLov5TjgZlcbiAgICByZXR1cm4gbGlzdDtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0geyp9IGRvY0xhYmVsXG4gICAqIEBwYXJhbSB7QXJyYXl9IHdyaXRlSXRlbUNvZGVUb1xuICAgKi9cbiAgdHJhbnNmb3JtTGFiZWxTZWlubyhkb2NMYWJlbCwgbGFiZWxPcHRpb25zKSB7XG4gICAgLy8g5ZWG5ZOB44Kz44O844OJ44KS6YCB44KK54q2Q1NW44Gr5Z+L44KB6L6844KAXG4gICAgLy9cblxuICAgIC8vIOWPl+azqOeVquWPt+OCkuaKveWHulxuICAgIGNvbnN0IG9yZGVyTnVtYmVyID0gZG9jTGFiZWxbMzJdOyAvLyAzM+eVquebruOBrumgheebruOAjOiomOS6i++8keOAjVxuXG4gICAgLy8gLy8g5Y+X5rOoQ1NW44GL44KJ5bqX6IiX5ZCN44Go5Y+X5rOo55Wq5Y+344KS44Kt44O844Gr5ZWG5ZOB44Kz44O844OJ5LiA6Kan44KS5Y+W5b6X44GZ44KLXG4gICAgLy8gY29uc3QgY3VyID0gUm9ib3Rpbk9yZGVycy5maW5kKHtcbiAgICAvLyAgIOW6l+iIl+WQjTogZG9jTGFiZWxbMTFdLCAvLyAxMueVquebruOBrumgheebruOAjOiNt+mAgeS6uuWQjeensOOAjVxuICAgIC8vICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXG4gICAgLy8gICDlj5fms6jnlarlj7c6IHsgJGluOiBbb3JkZXJOdW1iZXIsIE51bWJlcihvcmRlck51bWJlcildIH1cbiAgICAvLyB9LCB7XG4gICAgLy8gICBmaWVsZHM6IHtcbiAgICAvLyAgICAgX2lkOiAwLFxuICAgIC8vICAgICDllYblk4HjgrPjg7zjg4k6IDFcbiAgICAvLyAgIH1cbiAgICAvLyB9KTtcblxuICAgIGNvbnN0IGl0ZW1zID0gUm9ib3Rpbi5saXN0SXRlbUNvZGVGb3JMYWJlbChcbiAgICAgIHtcbiAgICAgICAgJ3JvYm90aW4u5bqX6IiX5ZCNJzogZG9jTGFiZWxbMTFdLCAvLyAxMueVquebruOBrumgheebruOAjOiNt+mAgeS6uuWQjeensOOAjVxuICAgICAgICAvLyDlj5fms6hDU1blh7rlipvjgZXjgozjgabjgYTjgovlj5fms6jnlarlj7fjgYzmloflrZfliJflvaLlvI/jgafjgoLmlbDlgKTlvaLlvI/jgafjgoLlvJXjgaPjgYvjgYvjgovjgojjgYbjgavjgZnjgovvvIgkaW7vvIlcbiAgICAgICAgJ3JvYm90aW4u5Y+X5rOo55Wq5Y+3Jzoge1xuICAgICAgICAgICRpbjogW29yZGVyTnVtYmVyLCBOdW1iZXIob3JkZXJOdW1iZXIpXVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgLy8g5Y+X5rOo44K344K544OG44Og5L6L5aSW44Gu5aC05ZCI44CB5Lu75oSP44Gu44Kz44Os44Kv44K344On44Oz77yIbWluaW1vbmdv44Gu5LiA5pmC44OH44O844K/44OZ44O844K577yJ44GM6YG45oqe44Gn44GN44KLXG4gICAgICB0eXBlb2YgdGhpcy5PcmRlciA9PT0gJ3VuZGVmaW5lZCcgPyBudWxsIDogdGhpcy5PcmRlclxuICAgIClcblxuICAgIC8vIC8vIOmAgeOCiueKtuODrOOCs+ODvOODieOBq+ipsuW9k+OBmeOCi+WPl+azqOODrOOCs+ODvOODieOBjOimi+OBpOOBi+OCieOBquOBhOWgtOWQiFxuICAgIC8vIGlmICghY3VyLmNvdW50KCkpIHRocm93IG5ldyBFcnJvcign6YCB44KK54q244Gr5a++5b+c44GZ44KL5Y+X5rOo44GM6KaL44Gk44GL44KK44G+44Gb44KT44CCQ1NW44OV44Kh44Kk44Or44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJyk7XG5cbiAgICAvLyAvLyDpgIHjgornirbjga7nmbrpgIHllYblk4HjgrPjg7zjg4nkuIDopqfjgpLphY3liJfjgavjgZnjgotcbiAgICAvLyBjb25zdCBpdGVtcyA9IGN1ci5mZXRjaCgpO1xuXG4gICAgLy8gZG9jTGFiZWwgOiDlhaXlipvpgIHjgornirbjg4fjg7zjgr9cbiAgICAvLyBjb25MYWJlbCA6IOWHuuWKm+eUqOmAgeOCiueKtuODh+ODvOOCv1xuICAgIGNvbnN0IGNvbkxhYmVsID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkb2NMYWJlbCkpO1xuXG4gICAgLy8gd3JpdGVJdGVtQ29kZVRvIO+8iOS4gOOBpOOBrumAgeOCiueKtuOBq+iomOi8ieOBp+OBjeOCi+WVhuWTgeOCs+ODvOODieOBruacgOWkp+aVsO+8ieOBrue3j+aVsOOCiOOCiuOAgeWPl+azqOODh+ODvOOCv+OBruWVhuWTgeaVsOOBjOWkmuOBhOWgtOWQiOOBr+OCqOODqeODvFxuICAgIGNvbnN0IHdyaXRlSXRlbUNvZGVUbyA9IGxhYmVsT3B0aW9ucy53cml0ZUl0ZW1Db2RlVG87XG4gICAgaWYgKHdyaXRlSXRlbUNvZGVUby5sZW5ndGggPCBpdGVtcy5sZW5ndGgpIHRocm93IG5ldyBFcnJvcihg6YCB44KK54q244OH44O844K/44Gr6KiY6LyJ44Gn44GN44KL5ZWG5ZOB5pWw44GvJHt3cml0ZUl0ZW1Db2RlVG8ubGVuZ3RofeWAi+OBvuOBp+OBp+OBmWApO1xuXG4gICAgLy8g5a6a5pWw44Gu5Z+L44KB6L6844G/XG4gICAgbGFiZWxPcHRpb25zLmNvbnN0LmZvckVhY2goKGUpID0+IHtcbiAgICAgIGNvbkxhYmVsW2UuY29sdW1uXSA9IGUudmFsdWU7XG4gICAgfSk7XG5cbiAgICAvLyDpgIHjgornirbjg4fjg7zjgr/jgavllYblk4HjgrPjg7zjg4njgpLoqJjpjLLjgZnjgotcbiAgICB3cml0ZUl0ZW1Db2RlVG8uZm9yRWFjaCgoZSwgaSkgPT4ge1xuICAgICAgaWYgKGl0ZW1zW2ldKSB7XG4gICAgICAgIGNvbkxhYmVsW2VdID0gaXRlbXNbaV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyDpgIHjgornirbjga7llYblk4HjgrPjg7zjg4nmrITjga/jgZnjgbnjgabln4vjgoHjgotcbiAgICAgICAgLy8g44GT44KM44Gr44KI44KK5YiX44Gu5qyg6JC944KS6Ziy44GQXG4gICAgICAgIGNvbkxhYmVsW2VdID0gJyc7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyDkvY/miYDmloflrZfliJfjga7liIblibLjgpLkv67mraPjgZnjgotcbiAgICAvLyBrZXlTIOOBp+aMh+WumuOBleOCjOOBnyB0YXJnZXQg5YaF44Gu6KaB57Sg44Gu5YCk44KS44CBbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44Gn5YiG5Ymy44GX5YaN5qeL56+J44GZ44KLXG4gICAgLy8gbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44KS6LaF44GI44KL5paH5a2X5YiX44Gv44CB5Y2K6KeS44K544Oa44O844K544Gn5YiG5Ymy44GZ44KLXG4gICAgVGV4dFV0aWwuc3BsaXRsZW5iKGNvbkxhYmVsLCBbMTIsIDEzXSwgNDApOyAvLyDpoIXnm64xM+OAjOiNt+mAgeS6uuS9j+aJgO+8keOAjeOAgemgheebrjE044CM6I236YCB5Lq65L2P5omA77yS44CNXG4gICAgVGV4dFV0aWwuc3BsaXRsZW5iKGNvbkxhYmVsLCBbMjEsIDIyXSwgNjApOyAvLyDpoIXnm64yMuOAjOOBiuWxiuOBkeWFiOS9j+aJgO+8keOAjeOAgemgheebrjIz44CM44GK5bGK44GR5YWI5L2P5omA77yS44CNXG5cbiAgICByZXR1cm4gY29uTGFiZWw7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHsqfSBkb2NMYWJlbFxuICAgKiBAcGFyYW0ge0FycmF5fSB3cml0ZUl0ZW1Db2RlVG9cbiAgICovXG4gIHRyYW5zZm9ybUxhYmVsWXVwYWNrKGRvY0xhYmVsLCBsYWJlbE9wdGlvbnMpIHtcbiAgICAvLyDllYblk4HjgrPjg7zjg4njgpLpgIHjgornirZDU1bjgavln4vjgoHovrzjgoBcbiAgICAvL1xuXG4gICAgLy8g5Y+X5rOo55Wq5Y+344KS5oq95Ye6XG4gICAgY29uc3Qgb3JkZXJOdW1iZXIgPSBkb2NMYWJlbFsn6KiY5LqL5ZCN77yRJ10ucmVwbGFjZSgn5Y+X5rOo55Wq5Y+377yaJywgJycpO1xuXG4gICAgLy8gLy8g5Y+X5rOoQ1NW44GL44KJ5bqX6IiX5ZCN44Go5Y+X5rOo55Wq5Y+344KS44Kt44O844Gr5ZWG5ZOB44Kz44O844OJ5LiA6Kan44KS5Y+W5b6X44GZ44KLXG4gICAgLy8gY29uc3QgY3VyID0gUm9ib3Rpbk9yZGVycy5maW5kKHtcbiAgICAvLyAgIOW6l+iIl+WQjTogZG9jTGFiZWxbJ+OBlOS+nemgvOS4uyDlkI3np7AxJ10sXG4gICAgLy8gICAvLyDlj5fms6hDU1blh7rlipvjgZXjgozjgabjgYTjgovlj5fms6jnlarlj7fjgYzmloflrZfliJflvaLlvI/jgafjgoLmlbDlgKTlvaLlvI/jgafjgoLlvJXjgaPjgYvjgYvjgovjgojjgYbjgavjgZnjgovvvIgkaW7vvIlcbiAgICAvLyAgIOWPl+azqOeVquWPtzogeyAkaW46IFtvcmRlck51bWJlciwgTnVtYmVyKG9yZGVyTnVtYmVyKV0gfVxuICAgIC8vIH0sIHtcbiAgICAvLyAgIGZpZWxkczoge1xuICAgIC8vICAgICBfaWQ6IDAsXG4gICAgLy8gICAgIOWVhuWTgeOCs+ODvOODiTogMVxuICAgIC8vICAgfVxuICAgIC8vIH0pO1xuXG4gICAgY29uc3QgaXRlbXMgPSBSb2JvdGluLmxpc3RJdGVtQ29kZUZvckxhYmVsKFxuICAgICAge1xuICAgICAgICAncm9ib3Rpbi7lupfoiJflkI0nOiBkb2NMYWJlbFsn44GU5L6d6aC85Li7IOWQjeensDEnXSxcbiAgICAgICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXG4gICAgICAgICdyb2JvdGluLuWPl+azqOeVquWPtyc6IHtcbiAgICAgICAgICAkaW46IFtvcmRlck51bWJlciwgTnVtYmVyKG9yZGVyTnVtYmVyKV1cbiAgICAgICAgfVxuICAgICAgfSxcbiAgICAgIC8vIOWPl+azqOOCt+OCueODhuODoOS+i+WkluOBruWgtOWQiOOAgeS7u+aEj+OBruOCs+ODrOOCr+OCt+ODp+ODs++8iG1pbmltb25nb+OBruS4gOaZguODh+ODvOOCv+ODmeODvOOCue+8ieOBjOmBuOaKnuOBp+OBjeOCi1xuICAgICAgdHlwZW9mIHRoaXMuT3JkZXIgPT09ICd1bmRlZmluZWQnID8gbnVsbCA6IHRoaXMuT3JkZXJcbiAgICApO1xuXG4gICAgLy8gZG9jTGFiZWwgOiDlhaXlipvpgIHjgornirbjg4fjg7zjgr9cbiAgICAvLyBjb25MYWJlbCA6IOWHuuWKm+eUqOmAgeOCiueKtuODh+ODvOOCv1xuICAgIGNvbnN0IGNvbkxhYmVsID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkb2NMYWJlbCkpO1xuXG4gICAgLy8gd3JpdGVJdGVtQ29kZVRvIO+8iOS4gOOBpOOBrumAgeOCiueKtuOBq+iomOi8ieOBp+OBjeOCi+WVhuWTgeOCs+ODvOODieOBruacgOWkp+aVsO+8ieOBrue3j+aVsOOCiOOCiuOAgeWPl+azqOODh+ODvOOCv+OBruWVhuWTgeaVsOOBjOWkmuOBhOWgtOWQiOOBr+OCqOODqeODvFxuICAgIGNvbnN0IHdyaXRlSXRlbUNvZGVUbyA9IGxhYmVsT3B0aW9ucy53cml0ZUl0ZW1Db2RlVG87XG4gICAgaWYgKHdyaXRlSXRlbUNvZGVUby5sZW5ndGggPCBpdGVtcy5sZW5ndGgpIHRocm93IG5ldyBFcnJvcihg6YCB44KK54q244OH44O844K/44Gr6KiY6LyJ44Gn44GN44KL5ZWG5ZOB5pWw44GvJHt3cml0ZUl0ZW1Db2RlVG8ubGVuZ3RofeWAi+OBvuOBp+OBp+OBmWApO1xuXG5cbiAgICAvLyDpgIHjgornirbjg4fjg7zjgr/jgavllYblk4HjgrPjg7zjg4njgpLoqJjpjLLjgZnjgotcbiAgICB3cml0ZUl0ZW1Db2RlVG8uZm9yRWFjaCgoZSwgaSkgPT4ge1xuICAgICAgaWYgKGl0ZW1zW2ldKSB7XG4gICAgICAgIGNvbkxhYmVsW2VdID0gaXRlbXNbaV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyDpgIHjgornirbjga7llYblk4HjgrPjg7zjg4nmrITjga/jgZnjgbnjgabln4vjgoHjgotcbiAgICAgICAgLy8g44GT44KM44Gr44KI44KK5YiX44Gu5qyg6JC944KS6Ziy44GQXG4gICAgICAgIGNvbkxhYmVsW2VdID0gJyc7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyDpgIHjgornirbnqK7liKXjgpLoqK3lrppcbiAgICBjb25MYWJlbFsn6YCB44KK54q256iu5YilJ10gPSBsYWJlbE9wdGlvbnMubGFiZWxJZDtcblxuICAgIC8vIOS9j+aJgOaWh+Wtl+WIl+OBruWIhuWJsuOCkuS/ruato+OBmeOCi1xuICAgIC8vIGtleVMg44Gn5oyH5a6a44GV44KM44GfIHRhcmdldCDlhoXjga7opoHntKDjga7lgKTjgpLjgIFsZW5ndGjvvIjjg5DjgqTjg4jplbfvvInjgafliIblibLjgZflho3mp4vnr4njgZnjgotcbiAgICAvLyBsZW5ndGjvvIjjg5DjgqTjg4jplbfvvInjgpLotoXjgYjjgovmloflrZfliJfjga/jgIHljYrop5Ljgrnjg5rjg7zjgrnjgafliIblibLjgZnjgotcbiAgICBUZXh0VXRpbC5zcGxpdGxlbmIoY29uTGFiZWwsIFsn44GU5L6d6aC85Li7IOS9j+aJgDEnLCAn44GU5L6d6aC85Li7IOS9j+aJgDInLCAn44GU5L6d6aC85Li7IOS9j+aJgDMnXSwgNTApO1xuICAgIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWyfjgYrlsYrjgZHlhYgg5L2P5omAMScsICfjgYrlsYrjgZHlhYgg5L2P5omAMicsICfjgYrlsYrjgZHlhYgg5L2P5omAMyddLCA1MCk7XG4gICAgcmV0dXJuIGNvbkxhYmVsO1xuICB9XG5cbiAgdHJhbnNmb3JtTGFiZWxZdXBhY2tldChkb2NMYWJlbCwgd3JpdGVJdGVtQ29kZVRvKSB7XG4gICAgLy8g5ZWG5ZOB44Kz44O844OJ44KS6YCB44KK54q2Q1NW44Gr5Z+L44KB6L6844KAXG4gICAgY29uc3Qgb3JkZXJOdW1iZXIgPSBkb2NMYWJlbFsn6KiY5LqL5ZCN77yRJ10ucmVwbGFjZSgn5Y+X5rOo55Wq5Y+377yaJywgJycpO1xuICAgIC8vIGNvbnN0IGN1ciA9IFJvYm90aW5PcmRlcnMuZmluZCh7XG4gICAgLy8gICDlupfoiJflkI06IGRvY0xhYmVsWyfjgZTkvp3poLzkuLsg5ZCN56ewMSddLFxuICAgIC8vICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXG4gICAgLy8gICDlj5fms6jnlarlj7c6IHsgJGluOiBbb3JkZXJOdW1iZXIsIE51bWJlcihvcmRlck51bWJlcildIH1cbiAgICAvLyB9LCB7XG4gICAgLy8gICBmaWVsZHM6IHtcbiAgICAvLyAgICAgX2lkOiAwLFxuICAgIC8vICAgICDllYblk4HjgrPjg7zjg4k6IDFcbiAgICAvLyAgIH1cbiAgICAvLyB9KTtcbiAgICBjb25zdCBpdGVtcyA9IFJvYm90aW4ubGlzdEl0ZW1Db2RlRm9yTGFiZWwoXG4gICAgICB7XG4gICAgICAgICdyb2JvdGluLuW6l+iIl+WQjSc6IGRvY0xhYmVsWyfjgZTkvp3poLzkuLsg5ZCN56ewMSddLFxuICAgICAgICAvLyDlj5fms6hDU1blh7rlipvjgZXjgozjgabjgYTjgovlj5fms6jnlarlj7fjgYzmloflrZfliJflvaLlvI/jgafjgoLmlbDlgKTlvaLlvI/jgafjgoLlvJXjgaPjgYvjgYvjgovjgojjgYbjgavjgZnjgovvvIgkaW7vvIlcbiAgICAgICAgJ3JvYm90aW4u5Y+X5rOo55Wq5Y+3Jzoge1xuICAgICAgICAgICRpbjogW29yZGVyTnVtYmVyLCBOdW1iZXIob3JkZXJOdW1iZXIpXVxuICAgICAgICB9XG4gICAgICB9LFxuICAgICAgLy8g5Y+X5rOo44K344K544OG44Og5L6L5aSW44Gu5aC05ZCI44CB5Lu75oSP44Gu44Kz44Os44Kv44K344On44Oz77yIbWluaW1vbmdv44Gu5LiA5pmC44OH44O844K/44OZ44O844K577yJ44GM6YG45oqe44Gn44GN44KLXG4gICAgICB0eXBlb2YgdGhpcy5PcmRlciA9PT0gJ3VuZGVmaW5lZCcgPyBudWxsIDogdGhpcy5PcmRlclxuICAgICk7XG5cbiAgICBjb25zdCBjb25MYWJlbCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZG9jTGFiZWwpKTtcbiAgICBjb25MYWJlbFsn6KiY5LqL5ZCN77yRJ10gPSBpdGVtcy5qb2luKCfjgIAnKTtcblxuICAgIC8vIGtleVMg44Gn5oyH5a6a44GV44KM44GfIHRhcmdldCDlhoXjga7opoHntKDjga7lgKTjgpLjgIFsZW5ndGjvvIjjg5DjgqTjg4jplbfvvInjgafliIblibLjgZflho3mp4vnr4njgZnjgotcbiAgICAvLyBsZW5ndGjvvIjjg5DjgqTjg4jplbfvvInjgpLotoXjgYjjgovmloflrZfliJfjga/jgIHljYrop5Ljgrnjg5rjg7zjgrnjgafliIblibLjgZnjgotcbiAgICBUZXh0VXRpbC5zcGxpdGxlbmIoY29uTGFiZWwsIFsn44GU5L6d6aC85Li7IOS9j+aJgDEnLCAn44GU5L6d6aC85Li7IOS9j+aJgDInLCAn44GU5L6d6aC85Li7IOS9j+aJgDMnXSwgNTApO1xuICAgIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWyfjgYrlsYrjgZHlhYgg5L2P5omAMScsICfjgYrlsYrjgZHlhYgg5L2P5omAMicsICfjgYrlsYrjgZHlhYgg5L2P5omAMyddLCA1MCk7XG4gICAgcmV0dXJuIGNvbkxhYmVsO1xuICB9XG59IiwiaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5pbXBvcnQgeyBqc29uMnhtbCB9IGZyb20gJ3htbC1qcydcclxuaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuLi91dGlsL2Vycm9yJ1xyXG5cclxuY29uc3QgQkFTRV9VUkkgPSAnaHR0cHM6Ly9hcGkubWFuYWdlci53b3dtYS5qcC93bXNob3BhcGknXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBXb3dtYUFwaSB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHNob3BJZCkge1xyXG4gICAgdGhpcy5wbHVnID0gcGx1Z1xyXG4gICAgdGhpcy5zaG9wSWQgPSBzaG9wSWRcclxuICB9XHJcblxyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG4gIGFzeW5jIHVwZGF0ZUl0ZW0gKHVwZGF0ZUl0ZW0pIHtcclxuICAgIGxldCByZXF1ZXN0ID0gYDxyZXF1ZXN0PjxzaG9wSWQ+JHt0aGlzLnNob3BJZH08L3Nob3BJZD48dXBkYXRlSXRlbT4ke2pzb24yeG1sKHVwZGF0ZUl0ZW0sIHtjb21wYWN0OiB0cnVlfSl9PC91cGRhdGVJdGVtPjwvcmVxdWVzdD5gXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5yZXF1ZXN0UG9zdChcclxuICAgICAgICAndXBkYXRlSXRlbUluZm8nLFxyXG4gICAgICAgIHJlcXVlc3RcclxuICAgICAgKVxyXG4gICAgICByZXR1cm4ge3Jlc3BvbnNlOiByZXMsIHJlcXVlc3RYTUw6IHJlcXVlc3R9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIHRocm93IE9iamVjdC5hc3NpZ24odXRpbEVycm9yLnBhcnNlKGUpLCB7cmVxdWVzdFhNTDogcmVxdWVzdH0pXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyByZXF1ZXN0UG9zdCAobWV0aG9kLCBib2R5KSB7XHJcbiAgICAvLyDmjqXntprjgqrjg5fjgrfjg6fjg7Pjga7kvZzmiJBcclxuICAgIGxldCBhcGlSZXF1ZXN0ID0ge1xyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgdXJpOiBgJHtCQVNFX1VSSX0vJHttZXRob2R9YCxcclxuICAgICAgYm9keTogYm9keVxyXG4gICAgfVxyXG4gICAgLy8g5YWx6YCa44Gu5o6l57aa6Kit5a6a44Go57WQ5ZCI44GZ44KLXHJcbiAgICBPYmplY3QuYXNzaWduKGFwaVJlcXVlc3QsIHRoaXMucGx1ZylcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgIGxldCByZXMgPSBhd2FpdCByZXF1ZXN0KGFwaVJlcXVlc3QpXHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHN0b2NrVXBkYXRlSXRlbSkge1xyXG4gICAgLy8g5o6l57aa44Kq44OX44K344On44Oz44Gu5L2c5oiQXHJcbiAgICBsZXQgYXBpUmVxdWVzdCA9IHtcclxuICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgIHVyaTogYCR7QkFTRV9VUkl9L3VwZGF0ZVN0b2NrYFxyXG4gICAgfVxyXG4gICAgLy8g5YWx6YCa44Gu5o6l57aa6Kit5a6a44Go57WQ5ZCI44GZ44KLXHJcbiAgICBPYmplY3QuYXNzaWduKGFwaVJlcXVlc3QsIHRoaXMucGx1ZylcclxuXHJcbiAgICBhcGlSZXF1ZXN0LmJvZHkgPSBhd2FpdCB0aGlzLnVwZGF0ZVN0b2NrQ3JlYXRlUmVxdWVzdEJvZHkoc3RvY2tVcGRhdGVJdGVtKVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3QoYXBpUmVxdWVzdClcclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9ja0NyZWF0ZVJlcXVlc3RCb2R5IChzdG9ja1VwZGF0ZUl0ZW0pIHtcclxuICAgIC8vXHJcbiAgICAvLyBzdG9ja1VwZGF0ZUl0ZW0gPVxyXG4gICAgLy8gW1xyXG4gICAgLy8gICB7XHJcbiAgICAvLyAgICAgaXRlbUNvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgIHZhcmlhdGlvbnM6IFtcclxuICAgIC8vICAgICAgICB7XHJcbiAgICAvLyAgICAgICAgICBjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgICAgICAgc3RvY2s6IDxOdW1iZXI+XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgIF1cclxuICAgIC8vICAgfVxyXG4gICAgLy8gXVxyXG5cclxuICAgIGxldCBzdG9ja1VwZGF0ZUl0ZW1YTUwgPSAnJ1xyXG5cclxuICAgIGZvciAobGV0IGl0ZW0gb2Ygc3RvY2tVcGRhdGVJdGVtKSB7XHJcbiAgICAgIC8vIOWApOOBruODgeOCp+ODg+OCr1xyXG4gICAgICBmb3IgKGxldCBlIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgIC8vIOWcqOW6q+aVsOOBruS4iumZkDEwMFxyXG4gICAgICAgIGlmIChlLnN0b2NrID4gMTAwKSBlLnN0b2NrID0gMTAwXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrVXBkYXRlSXRlbT4nXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPGl0ZW1Db2RlPiR7aXRlbS5pdGVtQ29kZX08L2l0ZW1Db2RlPmBcclxuXHJcbiAgICAgIC8vIOWVhuWTgeWcqOW6q+eoruWIpeOCkuaMr+OCiuWIhuOBkVxyXG4gICAgICAvLyAxIC0+IOmAmuW4uOWVhuWTgVxyXG4gICAgICAvLyAyIC0+IOmBuOaKnuiCouWIpeWcqOW6q1xyXG5cclxuICAgICAgbGV0IHZhcjAgPSBpdGVtLnZhcmlhdGlvbnNbMF1cclxuICAgICAgaWYgKHZhcjAuY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGUgPT09ICcnICYmIHZhcjAuY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlID09PSAnJykge1xyXG4gICAgICAgIC8vIOmAmuW4uOWVhuWTgVxyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrU2VnbWVudD4xPC9zdG9ja1NlZ21lbnQ+J1xyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPHN0b2NrQ291bnQ+JHt2YXIwLnN0b2NrfTwvc3RvY2tDb3VudD5gXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8g6YG45oqe6IKi5Yil5Zyo5bqrXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tTZWdtZW50PjI8L3N0b2NrU2VnbWVudD4nXHJcblxyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIGZvciAobGV0IHZhcmlhdGlvbiBvZiBpdGVtLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICAgIC8vIOWcqOW6q+ioreWumuOCv+OCsOOBruWQjeWJjeOCkuW3ruOBl+abv+OBiOOCi1xyXG4gICAgICAgICAgdmFyaWF0aW9uLmNob2ljZXNTdG9ja0NvdW50ID0gdmFyaWF0aW9uLnN0b2NrXHJcbiAgICAgICAgICBkZWxldGUgdmFyaWF0aW9uLnN0b2NrXHJcblxyXG4gICAgICAgICAgLy8geG1s44KS5qeL5oiQ44GZ44KLXHJcbiAgICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxjaG9pY2VzU3RvY2tzPidcclxuICAgICAgICAgIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyh2YXJpYXRpb24pKSB7XHJcbiAgICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPCR7a2V5fT4ke3ZhcmlhdGlvbltrZXldfTwvJHtrZXl9PmBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPC9jaG9pY2VzU3RvY2tzPidcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPC9zdG9ja1VwZGF0ZUl0ZW0+J1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OBruS9nOaIkFxyXG4gICAgbGV0IGFwaVJlcXVlc3RCb2R5ID0gYFxyXG4gICAgPHJlcXVlc3Q+XHJcbiAgICA8c2hvcElkPiR7dGhpcy5zaG9wSWR9PC9zaG9wSWQ+XHJcbiAgICAke3N0b2NrVXBkYXRlSXRlbVhNTH1cclxuICAgIDwvcmVxdWVzdD5cclxuICAgIGBcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqPjgpLov5TjgZlcclxuICAgIHJldHVybiBhcGlSZXF1ZXN0Qm9keVxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyB1dGlsRXJyb3Ige1xyXG4gIHN0YXRpYyBwYXJzZSAoZSkge1xyXG4gICAgbGV0IHJlcyA9IHt9XHJcblxyXG4gICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICByZXMubWVzc2FnZSA9IGUubWVzc2FnZVxyXG4gICAgICByZXMubmFtZSA9IGUubmFtZVxyXG4gICAgICByZXMuZmlsZU5hbWUgPSBlLmZpbGVOYW1lXHJcbiAgICAgIHJlcy5saW5lTnVtYmVyID0gZS5saW5lTnVtYmVyXHJcbiAgICAgIHJlcy5jb2x1bW5OdW1iZXIgPSBlLmNvbHVtbk51bWJlclxyXG4gICAgICByZXMuc3RhY2sgPSBlLnN0YWNrXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXMgPSBlXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInO1xuXG5leHBvcnQgY2xhc3MgTW9uZ29Db2xsZWN0aW9uIHtcbiAgc3RhdGljIGFzeW5jIGdldCAocGx1ZywgY29sbGVjdGlvbikge1xuICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmksIHsgdXNlTmV3VXJsUGFyc2VyOiB0cnVlIH0pO1xuICAgIGNvbnN0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpO1xuICAgIHJldHVybiBkYi5jb2xsZWN0aW9uKGNvbGxlY3Rpb24pO1xuICB9XG59XG4iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnO1xuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNeVNRTCB7XG4gIGNvbnN0cnVjdG9yIChwcm9maWxlKSB7XG4gICAgLy8g44Kz44ON44Kv44K344On44Oz44OX44O844Or5Yid5pyf5YyWXG4gICAgdGhpcy5wb29sID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlKTtcblxuICAgIC8vIOikh+aVsOihjOOCueODhuODvOODiOODoeODs+ODiOWvvuW/nFxuICAgIGNvbnN0IHByb2ZpbGVNdWx0aSA9IHsgbXVsdGlwbGVTdGF0ZW1lbnRzOiB0cnVlIH07XG4gICAgT2JqZWN0LmFzc2lnbihwcm9maWxlTXVsdGksIHByb2ZpbGUpO1xuICAgIHRoaXMucG9vbE11bHRpID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlTXVsdGkpO1xuICB9XG5cbiAgYXN5bmMgcXVlcnlTZWxlY3QodGFibGUsIGNvbmRpdGlvbiwgcHJvZHVjdCA9ICcqJykge1xuXG4gICAgY29uc3QgcHJvZHVjdFBhcnQgPSBwcm9kdWN0O1xuICAgIGNvbnN0IHRhYmxlUGFydCA9IGBGUk9NICR7dGFibGV9YDtcbiAgICBjb25zdCBjb25kaXRpb25QYXJ0ID0gY29uZGl0aW9uID8gYFdIRVJFICR7Y29uZGl0aW9ufWAgOiAnJztcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoYFNFTEVDVCAke3Byb2R1Y3RQYXJ0fSAke3RhYmxlUGFydH0gJHtjb25kaXRpb25QYXJ0fWApO1xuXG4gICAgLy8gU0VMRUNU44Gu57WQ5p6c44Gv44OH44Kj44O844OX44Kz44OU44O844GZ44KL44GT44Go44GnIHJvd2RhdGFwYWNrZXQg44KS5aSW44GZXG4gICAgcmV0dXJuIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocmVzKSk7XG4gIH1cblxuICBzdGF0aWMgZm9ybWF0RGF0ZSAoZGF0ZSkge1xuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsIDE5KS5yZXBsYWNlKCdUJywgJyAnKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsXG4gICAqL1xuICBxdWVyeSAoc3FsKSB7XG4gICAgLy8g44Kz44ON44Kv44K344On44Oz56K656uLXG4gICAgLy8gbGV0IGNvbiA9IGF3YWl0IHRoaXMuZ2V0Q29uKCk7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcbiAgICAgIC50aGVuKFxuICAgICAgICAoY29uKSA9PiBuZXcgUHJvbWlzZShcbiAgICAgICAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwsIChlLCByZXMpID0+IHtcbiAgICAgICAgICAgICAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7PplovmlL5cbiAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcbiAgICAgICAgICAgICAgICAgIHJlamVjdChlKVxuICAgICAgICAgICAgICAgIH0gZWxzZSByZXNvbHZlKHJlcylcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApLFxuICAgICAgKVxuICAgICAgLmNhdGNoKChlKSA9PiB7XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0XyAoc3FsKSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xuICAgIHJldHVybiByZXMuaW5zZXJ0SWQ7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvOOAgW51bGzjgIFqYXZhc2NyaXB0LT5teXNxbOaXpeS7mOWkieaPm+OBq+OCguWvvuW/nFxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cbiAgICovXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0ICh0YWJsZSwgZGF0YSA9IHt9LCBkYXRhU3FsID0ge30pIHtcbiAgICAvLyBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XG5cbiAgICBsZXQgc3FsID0gYElOU0VSVCBJTlRPICR7dGFibGV9IGA7XG5cbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XG4gICAgZm9yIChjb25zdCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCkge1xuICAgICAgICBtYXAuc2V0KGssICdOVUxMJyk7XG4gICAgICB9IGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XG4gICAgICAgIC8vIOaXpeS7mOOCkuWkieaPm1xuICAgICAgICBtYXAuc2V0KGssIGBcIiR7TXlTUUwuZm9ybWF0RGF0ZShkYXRhW2tdKX1cImApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWFwLnNldChrLCBgJHtteXNxbC5lc2NhcGUoZGF0YVtrXSl9YCk7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3QgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xuICAgICAgbWFwLnNldChrLCBkYXRhU3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YVNxbFtrXSk7XG4gICAgfVxuXG4gICAgc3FsICs9IGAoICR7Wy4uLm1hcC5rZXlzKCldLmpvaW4oJywnKX0gKSBgO1xuXG4gICAgc3FsICs9IGBWQUxVRVMoICR7Wy4uLm1hcC52YWx1ZXMoKV0uam9pbignLCcpfSApIGA7XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZDtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gdGFibGVcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O8XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhU3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xuICAgKi9cbiAgYXN5bmMgcXVlcnlVcGRhdGUgKHRhYmxlLCBmaWx0ZXIsIGRhdGEsIGRhdGFTcWwpIHtcbiAgICBsZXQgc3FsID0gYFVQREFURSAke3RhYmxlfSBTRVQgYDtcblxuICAgIGNvbnN0IHVwZGF0ZXMgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGsgb2YgT2JqZWN0LmtleXMoZGF0YSkpIHtcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrIG9mIE9iamVjdC5rZXlzKGRhdGFTcWwpKSB7XG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhU3FsW2tdfWApO1xuICAgIH1cbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJyk7XG5cbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYDtcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcbiAgICByZXR1cm4gcmVzO1xuICB9XG5cbiAgLy8gZW5hYmxlIHRvIHVzZSBtdWx0aXBsZSBzdGF0ZW1lbnRzXG4gIGFzeW5jIHF1ZXJ5TXVsdGkgKHNxbCkge1xuICAgIGNvbnN0IHBvb2xTd2FwID0gdGhpcy5wb29sO1xuICAgIHRoaXMucG9vbCA9IHRoaXMucG9vbE11bHRpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XG4gICAgICByZXR1cm4gcmVzO1xuICAgIH0gZmluYWxseSB7XG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcDtcbiAgICB9XG4gIH1cblxuICBhc3luYyBzdGFydFRyYW5zYWN0aW9uICgpIHtcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KCdTVEFSVCBUUkFOU0FDVElPTjsnKTtcbiAgfVxuXG4gIGFzeW5jIGNvbW1pdCAoKSB7XG4gICAgYXdhaXQgdGhpcy5xdWVyeSgnQ09NTUlUOycpO1xuICB9XG5cbiAgYXN5bmMgcm9sbGJhY2sgKCkge1xuICAgIGF3YWl0IHRoaXMucXVlcnkoJ1JPTExCQUNLOycpO1xuICB9XG5cbiAgc3RyZWFtaW5nUXVlcnkgKHNxbCwgb25SZXN1bHQgPSAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IChlKSA9PiB7fSkge1xuICAgIHJldHVybiB0aGlzLmdldENvbigpXG4gICAgICAudGhlbihcbiAgICAgICAgKGNvbikgPT4gbmV3IFByb21pc2UoXG4gICAgICAgICAgICBhc3luYyAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsKVxuICAgICAgICAgICAgICAgIC5vbigncmVzdWx0JyxcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uLnBhdXNlKClcbiAgICAgICAgICAgICAgICAgICAgb25SZXN1bHQocmVjb3JkKVxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKClcbiAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLm9uKCdlcnJvcicsIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAub24oJ2VuZCcsICgpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUoKVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKSxcbiAgICAgIClcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfSk7XG4gIH1cblxuICBnZXRDb24gKCkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZShcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgLy8g44OX44O844Or44GL44KJ44Gu44Kz44ON44Kv44K344On44Oz542y5b6XXG4gICAgICAgIHRoaXMucG9vbC5nZXRDb25uZWN0aW9uKChlLCBjb24pID0+IHtcbiAgICAgICAgICBpZiAoZSkge1xuICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlKGNvbik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgKVxuICAgICAgLmNhdGNoKFxuICAgICAgICAoZSkgPT4ge1xuICAgICAgICAgIHRocm93IGU7XG4gICAgICAgIH0sXG4gICAgICApO1xuICB9XG59XG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBQYWNrZXQge1xyXG4gIGNvbnN0cnVjdG9yIChwYWNrZXRTaXplKSB7XHJcbiAgICB0aGlzLnBhY2tldFNpemUgPSBwYWNrZXRTaXplXHJcbiAgICB0aGlzLm9uUGFja2V0U3RhcnQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldEVuZCA9IG51bGxcclxuICAgIHRoaXMuY291bnQgPSAwXHJcbiAgICB0aGlzLnBhY2tldENvdW50ID0gMFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0IChhcmcpIHtcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHliJ3mnJ/ljJbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0U3RhcnQpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLm9uUGFja2V0U3RhcnQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMub25QYWNrZXQpIHtcclxuICAgICAgYXdhaXQgdGhpcy5vblBhY2tldChhcmcpXHJcbiAgICB9XHJcbiAgICB0aGlzLmNvdW50KytcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHntYLkuoblh6bnkIbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIHRoaXMuY2xvc2UoKVxyXG4gICAgICB0aGlzLnBhY2tldENvdW50KytcclxuICAgIH1cclxuICB9XHJcbiAgY2xvc2UgKCkge1xyXG4gICAgaWYgKHRoaXMub25QYWNrZXRFbmQpIHtcclxuICAgICAgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdXRpbEVycm9yIGZyb20gJy4vZXJyb3InXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgeyBMb2dzIH0gZnJvbSAnLi4vY29sbGVjdGlvbnMnXHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVwb3J0IHtcclxuICBjb25zdHJ1Y3RvciAoKSB7XHJcbiAgICB0aGlzLnJlY29yZCA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9ycyA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgLy8gcHJpdmF0ZVxyXG4gIHNldHVwSXRlcmF0b3IgKHBoYXNlSWQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IocGhhc2VJZClcclxuICAgIHRoaXMuaXRlcmF0b3JzLnB1c2godGhpcy5pdGVyYXRvcilcclxuICB9XHJcblxyXG4gIGFzeW5jIHBoYXNlIChuYW1lID0gJycsIGZuID0gYXN5bmMgKCkgPT4ge30pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHBoYXNlSWQ6IHVuaXFpZCgpXHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKHJlYy5waGFzZUlkKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCBmbigpXHJcblxyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdzdWNjZXNzJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHJlc1xyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiB1dGlsRXJyb3IucGFyc2UoZSlcclxuICAgICAgfSlcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIC8vIOODq+ODvOODl+WHpueQhuOBruODrOODneODvOODiOOCkuS9nOaIkFxyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci5tZXRyaWMudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3IubWV0cmljXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICAvLyDjgr/jgqTjg6Djgrnjgr/jg7Pjg5dcclxuICAgICAgcmVjLnRpbWVTdGFtcCA9IG5ldyBEYXRlKClcclxuICAgICAgLy8g44Os44Od44O844OI44KS44OH44O844K/44OZ44O844K544Gr6KiY6YyyXHJcbiAgICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuXHJcbiAgICAgIC8vIOWRvOOBs+WHuuOBl+WFg+eUqOODrOODneODvOODiOOBq+i/veWKoFxyXG4gICAgICB0aGlzLnJlY29yZC5wdXNoKHJlYylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIOOCq+ODvOOCveODq+OCkuODq+ODvOODl+OBl+OAgeS4juOBiOOCieOCjOOBn+mWouaVsOOCkuWun+ihjFxyXG4gIC8vIOWRvOOBs+WHuuOBmemWouaVsOOBruW8leaVsOOBq+OBr+OCq+ODvOOCveODq+OBi+OCieW+l+OCieOCjOOBn+ODieOCreODpeODoeODs+ODiOOCkua4oeOBmVxyXG4gIGFzeW5jIGZvckVhY2hPbkN1cnNvciAoY3VyLCBmbikge1xyXG4gICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgbGV0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZm4oZG9jKVxyXG4gICAgICAgIHRoaXMuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgdGhpcy5pRXJyb3IoZSlcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgY3VyLmNsb3NlKClcclxuICB9XHJcblxyXG4gIGlTdWNjZXNzIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3Iuc3VjY2VzcyhuZXdSZWNvcmQpXHJcbiAgfVxyXG5cclxuICBpRXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5lcnJvcih1dGlsRXJyb3IucGFyc2UobmV3UmVjb3JkKSlcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICBsZXQgaXRlRXJyb3IgPSB0aGlzLml0ZXJhdG9ycy5maW5kKGUgPT4gZS5lcnJvck9jdXJyZWQoKSlcclxuICAgIGxldCBwaGFFcnJvciA9IGZhbHNlXHJcbiAgICBmb3IgKGxldCByZWMgb2YgdGhpcy5yZWNvcmQpIHtcclxuICAgICAgaWYgKHJlYy50eXBlID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgcGhhRXJyb3IgPSB0cnVlXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGl0ZUVycm9yIHx8IHBoYUVycm9yXHJcbiAgfVxyXG5cclxuICBwdWJsaXNoICgpIHtcclxuICAgIC8vIOWRvOOBs+WHuuOBl+WFg+OBuOODrOODneODvOODiFxyXG4gICAgaWYgKHRoaXMuZXJyb3JPY3VycmVkKCkpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcih0aGlzLnJlY29yZClcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnJlY29yZFxyXG4gIH1cclxufVxyXG5cclxuY2xhc3MgSXRlcmF0b3Ige1xyXG4gIGNvbnN0cnVjdG9yIChwaGFzZUlkKSB7XHJcbiAgICB0aGlzLm1ldHJpYyA9IHtcclxuICAgICAgdG90YWw6IDAsXHJcbiAgICAgIHN1Y2Nlc3M6IDAsXHJcbiAgICAgIGVycm9yOiAwLFxyXG4gICAgICBwaGFzZUlkOiBwaGFzZUlkXHJcbiAgICB9XHJcbiAgICB0aGlzLmxhc3RFcnJvciA9IG51bGxcclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLmxvZyhuZXdSZWNvcmQsIHRydWUpXHJcbiAgICB9XHJcbiAgICB0aGlzLm1ldHJpYy5zdWNjZXNzKytcclxuICAgIHRoaXMubWV0cmljLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIC8vIOebtOWJjeOBqOWQjOOBmOOCqOODqeODvOOBr+ecgeOBj1xyXG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KHRoaXMubGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMubG9nKG5ld1JlY29yZCwgZmFsc2UpXHJcbiAgICAgICAgdGhpcy5sYXN0RXJyb3IgPSBuZXdSZWNvcmRcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy5tZXRyaWMuZXJyb3IrK1xyXG4gICAgdGhpcy5tZXRyaWMudG90YWwrK1xyXG4gIH1cclxuXHJcbiAgbG9nIChuZXdSZWNvcmQsIGlzU3VjY2VzcyAvKiB0cnVlID0+IHN1Y2Nlc3Mgb3IgZmFsc2UgPT4gZXJyb3IgKi8pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IGlzU3VjY2VzcyxcclxuICAgICAgcGhhc2VJZDogdGhpcy5tZXRyaWMucGhhc2VJZCxcclxuICAgICAgbWVzc2FnZTogbmV3UmVjb3JkLFxyXG4gICAgICB0aW1lU3RhbXA6IG5ldyBEYXRlKClcclxuICAgIH1cclxuICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMuZXJyb3JcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcblxuLyoqXG4gKlxuICogQHBhcmFtIHtbT2JqZWN0XX0gc3JjXG4gKiBAcGFyYW0ge1tPYmplY3RdfSBkc3RcbiAqIEBwYXJhbSB7c3RyaW5nfSBpZGtleVxuICogQHBhcmFtIHtmdW5jdGlvbihhbnksIE9iamVjdCl9IGNyZWF0ZVxuICogQHBhcmFtIHtmdW5jdGlvbihhbnksIE9iamVjdCl9IHJlbW92ZVxuICovXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBzeW5jT2JqZWN0KFxuICBzcmMsIGRzdCwgaWRrZXkgPSBudWxsLCBhZGRGdW5jLCByZW1GdW5jLFxuKSB7XG4gIGNvbnN0IHNyY0NvbnRhaW5lciA9IFtdO1xuICBjb25zdCBkc3RDb250YWluZXIgPSBbXTtcblxuICBjb25zdCBpZERlbGV0ZWRDbG9uZSA9IChlbGVtLCBpZGtleUFQKSA9PiB7XG4gICAgY29uc3QgZWxlbVNhdmUgPSBfLmNsb25lRGVlcChlbGVtKTtcbiAgICAvLyBpZCDjgpLmr5TovIPlr77osaHjgYvjgonlpJbjgZlcbiAgICBpZiAoXy5pc1VuZGVmaW5lZChlbGVtU2F2ZVtpZGtleUFQXSkgPT09IGZhbHNlKSB7XG4gICAgICBkZWxldGUgZWxlbVNhdmVbaWRrZXlBUF07XG4gICAgfVxuICAgIC8vIOODh+OCo+ODvOODl+OCr+ODreODvOODs+OBl+OBn+OCquODluOCuOOCp+OCr+ODiOOCkui/lOOBmVxuICAgIHJldHVybiBlbGVtU2F2ZTtcbiAgfTtcblxuICAvLyDjgqrjg5bjgrjjgqfjgq/jg4jmr5TovIPjga7liY3mupblgplcbiAgc3JjLmZvckVhY2goKGVsZW0pID0+IHtcbiAgICBzcmNDb250YWluZXIucHVzaCh7XG4gICAgICBvYmplY3Q6IGlkRGVsZXRlZENsb25lKGVsZW0sIGlka2V5KSxcbiAgICAgIGlkOiBlbGVtW2lka2V5XSxcbiAgICAgIHN0YXRlOiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB0cnVlIOS9leOCguOBl+OBquOBhFxuICAgICAgICAgKiBmYWxzZSDmlrDopo/jgavkvZzmiJBcbiAgICAgICAgICovXG4gICAgICAgIGZpbmQ6IGZhbHNlLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfSk7XG5cbiAgZHN0LmZvckVhY2goKGVsZW0pID0+IHtcbiAgICBkc3RDb250YWluZXIucHVzaCh7XG4gICAgICBvYmplY3Q6IGlkRGVsZXRlZENsb25lKGVsZW0sIGlka2V5KSxcbiAgICAgIGlkOiBlbGVtW2lka2V5XSxcbiAgICAgIHN0YXRlOiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB0cnVlIOS9leOCguOBl+OBquOBhFxuICAgICAgICAgKiBmYWxzZSDliYrpmaTjgZnjgotcbiAgICAgICAgICovXG4gICAgICAgIGZpbmQ6IGZhbHNlLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8g44Kq44OW44K444Kn44Kv44OI44KS5q+U6LyDXG4gIHNyY0NvbnRhaW5lci5mb3JFYWNoKChzcmNFbGVtKSA9PiB7XG4gICAgZHN0Q29udGFpbmVyLmZvckVhY2goKGRzdEVsZW0pID0+IHtcbiAgICAgIGlmIChfLmlzRXF1YWwoc3JjRWxlbS5vYmplY3QsIGRzdEVsZW0ub2JqZWN0KSkge1xuICAgICAgICAvLyDlkIzjgZjjgqrjg5bjgrjjgqfjgq/jg4jjgYzopovjgaTjgYvjgaPjgZ/loLTlkIhcbiAgICAgICAgc3JjRWxlbS5zdGF0ZS5maW5kID0gdHJ1ZTtcbiAgICAgICAgZHN0RWxlbS5zdGF0ZS5maW5kID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8g44OH44O844K/44Gu5oy/5YWlXG4gIGF3YWl0IFByb21pc2UuYWxsKHNyY0NvbnRhaW5lci5tYXAoYXN5bmMgKGVsZW0pID0+IHtcbiAgICBpZiAoZWxlbS5zdGF0ZS5maW5kID09PSBmYWxzZSkge1xuICAgICAgYXdhaXQgYWRkRnVuYyhlbGVtLmlkLCBlbGVtLm9iamVjdCk7XG4gICAgfVxuICB9KSk7XG5cbiAgLy8g44OH44O844K/44Gu5YmK6ZmkXG4gIGF3YWl0IFByb21pc2UuYWxsKGRzdENvbnRhaW5lci5tYXAoYXN5bmMgKGVsZW0pID0+IHtcbiAgICBpZiAoZWxlbS5zdGF0ZS5maW5kID09PSBmYWxzZSkge1xuICAgICAgYXdhaXQgcmVtRnVuYyhlbGVtLmlkLCBlbGVtLm9iamVjdCk7XG4gICAgfVxuICB9KSk7XG59XG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBUZXh0VXRpbCB7XHJcbiAgLy8gOOODk+ODg+ODiOOBp+aWh+Wtl+WIl+WIh+OCiuWPluOCi1xyXG4gIHN0YXRpYyBzdWJzdHI4ICh0ZXh0LCBsZW4sIHRydW5jYXRpb24pIHtcclxuICAgIGlmICh0cnVuY2F0aW9uID09PSB1bmRlZmluZWQpIHsgdHJ1bmNhdGlvbiA9ICcnIH1cclxuICAgIHZhciB0ZXh0QXJyYXkgPSB0ZXh0LnNwbGl0KCcnKVxyXG4gICAgdmFyIGNvdW50ID0gMFxyXG4gICAgdmFyIHN0ciA9ICcnXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRleHRBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICB2YXIgbiA9IGVzY2FwZSh0ZXh0QXJyYXlbaV0pXHJcbiAgICAgIGlmIChuLmxlbmd0aCA8IDQpIGNvdW50KytcclxuICAgICAgZWxzZSBjb3VudCArPSAyXHJcbiAgICAgIGlmIChjb3VudCA+IGxlbikge1xyXG4gICAgICAgIHJldHVybiBzdHIgKyB0cnVuY2F0aW9uXHJcbiAgICAgIH1cclxuICAgICAgc3RyICs9IHRleHQuY2hhckF0KGkpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGV4dFxyXG4gIH1cclxuXHJcbiAgLy8g5paH5a2X5YiX44Gu44OQ44Kk44OI5pWw44KS5pWw44GI44KLXHJcbiAgc3RhdGljIGxlbmIgKHRleHQpIHtcclxuICAgIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQodGV4dCkucmVwbGFjZSgvJS4uJS4uJS4uL2csICd4eCcpLmxlbmd0aFxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHNwbGl0bGVuYiAodGFyZ2V0LCBrZXlTLCBsZW5ndGgpIHtcclxuICAgIGNvbnN0IHNlcCA9ICcgJ1xyXG4gICAgLy8ga2V5UyDjgafmjIflrprjgZXjgozjgZ8gdGFyZ2V0IOWGheOBruimgee0oOOBruWApOOCkuOBmeOBueOBpue1kOWQiOOBl+OBn+aWh+Wtl+WIl+OCkuS9nOOCi1xyXG4gICAgY29uc3Qgc3RyRW50aXJlID0ga2V5Uy5yZWR1Y2UoKHByZXYsIGN1cnJlbnQpID0+IHByZXYgKyB0YXJnZXRbY3VycmVudF0sICcnKVxyXG4gICAgLy8g57WQ5ZCI44GX44Gf5paH5a2X5YiX44KS5Y2K6KeS44K544Oa44O844K544Gn5YiG5Ymy44GZ44KLXHJcbiAgICBjb25zdCBhcnJFbnRpcmUgPSBzdHJFbnRpcmUuc3BsaXQoc2VwKVxyXG4gICAgbGV0IGFyclJlcyA9IFtdXHJcbiAgICBsZXQgbGFzdCA9ICcnXHJcbiAgICAvLyDjg5DjgqTjg4jplbfjgYxsZW5ndGjjgpLotoXjgYjjgarjgYTpmZDjgorliY3lvozjga7liIblibLmloflrZfliJfjgpLntZDlkIjjgZfjgabjgYTjgY9cclxuICAgIC8vIOODkOOCpOODiOmVt+OBjGxlbmd0aOOCkui2heOBiOOBn+OCieOAgeOBsuOBqOOBpOOBvuOBiOOBrue1kOWQiOaWh+Wtl+WIl+OCkumFjeWIl+eZu+mMsuOBmeOCi1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXJyRW50aXJlLnJlZHVjZSgocHJldiwgY3VycmVudCkgPT4ge1xyXG4gICAgICAgIC8vIGxlbmd0aCDjgpLotoXjgYjjgovjg5DjgqTjg4jplbfjga7liIblibLmloflrZfliJfjgYzjgYLjgovloLTlkIjjga/kvZXjgoLjgZfjgarjgYRcclxuICAgICAgICBpZiAoVGV4dFV0aWwubGVuYihjdXJyZW50KSA+IGxlbmd0aCkgdGhyb3cgbmV3IEVycm9yKCfmloflrZfliJfotoXpgY4nKVxyXG4gICAgICAgIGNvbnN0IGV4YW0gPSAocHJldiAhPT0gJycgPyBwcmV2ICsgc2VwIDogJycpICsgY3VycmVudFxyXG4gICAgICAgIGlmIChUZXh0VXRpbC5sZW5iKGV4YW0pID4gbGVuZ3RoKSB7XHJcbiAgICAgICAgICBhcnJSZXMucHVzaChwcmV2KVxyXG4gICAgICAgICAgbGFzdCA9IGN1cnJlbnQgLy8g5pyA5b6M44Gu5paH5a2X5YiXXHJcbiAgICAgICAgICByZXR1cm4gJydcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgbGFzdCA9IGV4YW0gLy8g5pyA5b6M44Gu5paH5a2X5YiXXHJcbiAgICAgICAgICByZXR1cm4gZXhhbVxyXG4gICAgICAgIH1cclxuICAgICAgfSwgJycpXHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIC8vIGxlbmd0aCDjgpLotoXjgYjjgovjg5DjgqTjg4jplbfjga7liIblibLmloflrZfliJfjgYzjgYLjgovloLTlkIjjga/kvZXjgoLjgZfjgarjgYRcclxuICAgICAgaWYgKGUubWVzc2FnZSA9PT0gJ+aWh+Wtl+WIl+i2hemBjicpIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIGFyclJlcy5wdXNoKGxhc3QpIC8vIOacgOW+jOOBruaWh+Wtl+WIl+OCkumFjeWIl+eZu+mMsuOBmeOCi1xyXG4gICAgLy8ga2V5UyDjgafmjIflrprjgZXjgozjgZ8gdGFyZ2V0IOWGheOBruimgee0oOOBruWApOOCkuS/ruato+OBmeOCi1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBrZXlTLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHRhcmdldFtrZXlTW2ldXSA9IGFyclJlc1tpXSA/IGFyclJlc1tpXSA6ICcnXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbG9ncycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5leHBvcnQgY29uc3QgVXBsb2FkcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1cGxvYWRzJywge2lkR2VuZXJhdGlvbjogJ01PTkdPJ30pXHJcblxyXG5leHBvcnQgY29uc3QgUm9ib3RpblNob3AgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncm9ib3RpblNob3AnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuZXhwb3J0IGNvbnN0IFJvYm90aW5PcmRlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncm9ib3Rpbk9yZGVycycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5cclxuZXhwb3J0IGNvbnN0IENvbmZpZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29uZmlncycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG4gIE1ldGVvci5wdWJsaXNoKCdjb25maWdzJywgKCkgPT4ge1xyXG4gICAgcmV0dXJuIENvbmZpZ3MuZmluZCgpXHJcbiAgfSk7XHJcbiAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgYXN5bmMgWydyb2JvdGluT3JkZXJHcm91cHMnXSgpIHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgUm9ib3Rpbk9yZGVycy5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAvLyDlj5fms6hJROOBlOOBqOOBq+OCsOODq+ODvOODl+WMllxyXG4gICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgIF9pZDoge1xyXG4gICAgICAgICAgICAgIOWPl+azqElEOickcm9ib3Rpbi7lj5fms6hJRCcsXHJcbiAgICAgICAgICAgICAg5Y+X5rOo5pel5pmCOickcm9ib3Rpbi7lj5fms6jml6XmmYInLFxyXG4gICAgICAgICAgICAgIOW6l+iIl+WQjTogJyRyb2JvdGluLuW6l+iIl+WQjScsXHJcbiAgICAgICAgICAgICAg5Y+X5rOo55Wq5Y+3OiAnJHJvYm90aW4u5Y+X5rOo55Wq5Y+3J1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBpdGVtczogeyRwdXNoOiB75ZWG5ZOB44Kz44O844OJOiAnJHJvYm90aW4u5ZWG5ZOB44Kz44O844OJJywg5pWw6YePOiAnJHJvYm90aW4u5pWw6YePJ319XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICBfaWQ6MCxcclxuICAgICAgICAgICAg5Y+X5rOoSUQ6JyRfaWQu5Y+X5rOoSUQnLFxyXG4gICAgICAgICAgICDlj5fms6jml6XmmYI6JyRfaWQu5Y+X5rOo5pel5pmCJyxcclxuICAgICAgICAgICAg5bqX6IiX5ZCNOiAnJF9pZC7lupfoiJflkI0nLFxyXG4gICAgICAgICAgICDlj5fms6jnlarlj7c6ICckX2lkLuWPl+azqOeVquWPtycsXHJcbiAgICAgICAgICAgIGl0ZW1zOiAnJGl0ZW1zJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgXSkudG9BcnJheSgpO1xyXG4gICAgICByZXR1cm4gcmVzO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICBNZXRlb3IucHVibGlzaCgncm9ib3Rpbk9yZGVySXRlbXMnLCBhc3luYyAoKT0+e1xyXG4gICAgcmV0dXJuIFJvYm90aW5PcmRlcnMuZmluZCgpO1xyXG4gIH0pO1xyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XHJcbiAgTWV0ZW9yLnN1YnNjcmliZSgnY29uZmlncycpXHJcbn1cclxuIl19
