var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/route/upload/image.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube/cubemig.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 3);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 4);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 5);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let couponCd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let couponName = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discountPrice = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: couponCd,
                coupon_type: 3,
                // 全商品
                coupon_name: couponName,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discountPrice,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                customer_id: record.customer_id,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
        return res;
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/collection.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
      return res;
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.aggregate(query).toArray());
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let ItemController;
module.watch(require("../../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/service/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 5);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  //
  // 商品情報登録と更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              let quantity = Promise.await(itemController.getStock(item._id));
              Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/tooltest.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      const newLocal = Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
        throw e;
      })));
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return newLocal;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/yauct.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
let PassThrough, Transform;
module.watch(require("stream"), {
  PassThrough(v) {
    PassThrough = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 9);
const prefix = 'packet';
const tag = 'yauct';
Meteor.methods({
  //
  // ヤフオク受注ファイル
  [`${tag}.order`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク受注', () => Promise.asyncApply(() => {
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        const workdir = `${config.workdir}/order`;
        const r = fsExtra.createReadStream(`${workdir}/${config.orderLoadfile}`);
        const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`);
        let i = 0;
        r.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
          columns: true
        })).pipe(csv.transform((record, callback) => Promise.asyncApply(() => {
          let err = null; // 管理番号を置き換える

          try {
            record['管理番号'] = Promise.await(itemController.getModelClass(record['管理番号']));
          } catch (e) {
            err = e;
          }

          callback(err, record);
        }))).pipe(csv.stringify({
          header: true
        })).pipe(iconv.decodeStream('UTF-8')).pipe(iconv.encodeStream('SJIS')).pipe(w);
      })));
    });
  },

  //
  // ヤフオク出品ファイル
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク出品', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 繰り返し処理を任意の（packetSize）で分割

        const packet = new Packet(config.packetSize); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // CSVファイルを作成し画像データを収集する場所


        const workdir = `${config.workdir}/work`;
        Promise.await(fsExtra.remove(workdir));
        Promise.await(fsExtra.mkdir(workdir)); // ZIPファイルを保存する場所

        const uploaddir = `${config.workdir}/upload`;
        Promise.await(fsExtra.remove(uploaddir));
        Promise.await(fsExtra.mkdir(uploaddir));
        let cd = null; // パケットフォルダ

        let filename = null; // csvファイル

        let name = null; // パケット番号
        // CSVフィールドを定義し、順番を確定する

        let fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
        let header = fields.map(v => `"${v}"`).join(',') + '\n'; // パケット化開始時

        packet.onPacketStart = packetCount => Promise.asyncApply(() => {
          name = prefix + ('00000' + packetCount).slice(-5);
          cd = `${workdir}/${name}`;
          filename = `${cd}/${config.csvFileName}`;
          Promise.await(fsExtra.mkdir(cd)); // CSVファイルにフィールドを設定する

          Promise.await(fsExtra.appendFile(filename, iconv.encode(header, 'Shift_JIS')));
        }); // パケット化時


        packet.onPacket = arg => Promise.asyncApply(() => {
          let yauct = arg.yauct;
          let item = arg.item; // csvファイルにレコード（商品テンプレート）を追加する

          let record = fields.map(v => {
            return yauct[v] ? `"${yauct[v]}"` : '""';
          }).join(',') + '\n';
          Promise.await(fsExtra.appendFile(filename, iconv.encode(record, 'Shift_JIS'))); // 画像ファイルをコピー

          for (let img of item.images) {
            let imgSrc = `${config.imagedir}/${img}`;
            let imgTgt = `${cd}/${img}`;

            try {
              // 同じファイルがある場合はコピーしない
              Promise.await(fsExtra.access(imgTgt));
            } catch (e) {
              Promise.await(fsExtra.copyFile(imgSrc, imgTgt));
            }
          }
        }); // パケット終了時


        packet.onPacketEnd = packetCount => Promise.asyncApply(() => {
          const zip = archiver('zip');
          const zipname = `${uploaddir}/${name}.zip`;
          const output = fsExtra.createWriteStream(zipname);
          zip.pipe(output);
          zip.directory(cd, false);
          zip.finalize();
        }); // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id)); // itemに定義されている最低必要在庫より多い商品を出品する

            if (quantity >= item.mall.yauct.minQuantity) {
              let yauct = Promise.await(itemController.convertItemYauct(config.default, item));
              Promise.await(packet.submit({
                yauct: yauct,
                item: item
              }));
            }
          })
        }));
        packet.close();
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/configs.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/filters.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/groups.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/uploads.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/cube3api.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  updateStock(productClassId, quantity = 0) {
    return Promise.asyncApply(() => {
      Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      }));
      Promise.await(this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      }));
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = []; // 削除するタグ

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      }); // 表示するタグ


      let tagon = tag => Promise.asyncApply(() => {
        // すでに表示されているタグがあれば何もしない
        let sql = `
      SELECT COUNT(*) FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        let countRes = Promise.await(this.mysql_.query(sql));
        if (countRes[0]['COUNT(*)']) return;
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creatorId,
          create_date: 'NOW()'
        })));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let productId = data.product_id;
      let images = data.images;
      let creatorId = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${productId}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        Promise.await(this.mysql_.queryInsert('dtb_product_image', {
          product_id: productId,
          creator_id: creatorId,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        }));
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let updateData = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      Promise.await(this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      })); // dtb_product_class

      updateData = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      let res = Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      }));
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = {};
      let updateData = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', updateData, {
        creator_id: creatorId,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      updateData = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', updateData, {
        creator_id: creatorId,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creatorId,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/dbfilter.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 3);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 4);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case 'mysql':
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    switch (plug.type) {
      case 'mysql':
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error('invalid plug type');
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   *
   *
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== 'undefined') {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      let res = Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
      return res;
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find(); // カーソルのタイムアウトを解除

      cur.addCursorFlag('noCursorTimeout', true); // すべてのドキュメントをループ

      try {
        while (Promise.await(cur.hasNext())) {
          let doc = Promise.await(cur.next());
          Promise.await(onResult(doc, context));
        }

        ;
      } finally {
        // カーソルを開放
        Promise.await(cur.close());
      }
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/items.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);
let ObjectID;
module.watch(require("bson"), {
  ObjectID(v) {
    ObjectID = v;
  }

}, 2);
let TextUtil;
module.watch(require("../util/text"), {
  default(v) {
    TextUtil = v;
  }

}, 3);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(itemId) {
    return Promise.asyncApply(() => {
      let project = Promise.await(this.Items.findOne({
        _id: itemId
      }, {
        projection: {
          'product': 1
        }
      }));
      let productPack = project.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[[]]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let productSku of productPack) {
        let quantitySku = 0;

        for (let productId of productSku) {
          let project = Promise.await(this.Products.findOne({
            _id: productId
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stockArray = project.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stockArray) {
            quantitySku += stock.quantity;
          }
        }

        quantities.push(quantitySku);
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   *
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   *
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   *
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   *
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   *
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }
  /**
   * 指定の商品に関連する商品群の属性別の商品情報を返す。
   *
   * 引数として受け取るitemは任意の商品情報。
   * itemに関連する商品群について必要な情報を整理し返す。
   *
   * projectに参照したい商品情報フィールドを定義する。
   * メソッドの呼び出し時に必要に応じてprojectを設定する。
   *
   * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
   *
   * @param {Object} item
   * @param {Object} project
   */


  getVariation(item, project) {
    return Promise.asyncApply(() => {
      /**
       * aggregation設定
       *
       * label: 属性名（配送方法、カラー、サイズなど）
       * current: 指定されたアイテム（item）が該当する項目
       * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
       * query: aggregation対象とするドキュメントの検索条件
       */
      let set = [{
        label: '配送方法',
        current: item.delivery,
        project: {
          value: '$delivery'
        },
        query: {
          class1_value: item.class1_value,
          class2_value: item.class2_value
        }
      }, {
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          delivery: item.delivery,
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          delivery: item.delivery,
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }, {
            $sort: {
              _id: 1
            }
          }]).toArray()),
          props: s
        });
      }

      return attrs;
    });
  } // モデルクラス形式を作る
  // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]


  getModelClass(arg) {
    return Promise.asyncApply(() => {
      let item; // item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

      if (typeof arg === 'string') {
        let exp = new RegExp(`${arg}$`);
        let cur = this.Items.find({}, {
          projection: {
            model: 1,
            class1_value: 1,
            class2_value: 1
          }
        });

        while (1) {
          try {
            item = Promise.await(cur.next());
            let match = Promise.await(item._id.toHexString().match(exp));

            if (match) {
              break;
            }
          } catch (e) {
            // 該当するitemデータがない
            return arg;
          }
        }
      } else {
        item = arg;
      }

      let modelClass = [];
      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value);
      return modelClass.join('/');
    });
  }

  convertItemCube3(creatorId, item) {
    return Promise.asyncApply(() => {
      // 値変換
      let convDeliv = delivery => delivery === 'ゆうパケット' ? 'ポスト投函' : delivery; // product_id


      let productId = null;
      let modelClass = []; // 下記の形式を作る
      // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]

      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let productTypeId;

      switch (item.delivery) {
        case '宅配便':
          productTypeId = 1;
          break;

        case 'ゆうパケット':
          productTypeId = 2;
          break;

        default:
          productTypeId = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let deliveryFee = null;

      switch (item.delivery) {
        case '宅配便':
          deliveryFee = null;
          break;

        case 'ゆうパケット':
          deliveryFee = 240;
          break;
      } //
      // 顧客向けバリエーション商品選択機能の実装
      //


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      })); // HTML バリエーション商品ごとのリンク付きボタンを表示する
      // 値の変換

      attrs = attrs.map(attr => {
        attr.props.current = convDeliv(attr.props.current);
        attr.variations = attr.variations.map(variation => {
          variation.value = convDeliv(variation.value);
          return variation;
        });
        return attr;
      }); // HTML生成

      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row">` + `<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">` + `<strong>${attr.props.label}</strong>` + `</div>` + attr.variations.map(variation => {
        if (attr.props.current === variation.value) {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-success btn-sm btn-item-class-select"><strong>${variation.value}</strong></button></a>`;
        } else {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-sm btn-item-class-select">${variation.value}</button></a>`;
        }
      }).join('') + '</div>' + '</div>').join('');
      let descriptionDetail = `
    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>
    <small class="text-danger">※ 在庫がない商品の場合「ページが見つかりません」と表示されます。</small>
    ${variationHtml}
    `; // 商品データを作る

      let data = {
        product_id: productId,
        creator_id: creatorId,
        name: `${modelClass.join('/')} ${convDeliv(item.delivery)} ${item.name} ${item.jan_code}`,
        description_detail: descriptionDetail,
        free_area: item.description + ' ',
        product_code: modelClass.join('/'),
        price01: item.retail_price,
        price02: item.sales_price * 0.95,
        // 楽天価格から5%値引き
        images: item.images,
        product_type_id: productTypeId,
        tags: tags,
        delivery_fee: deliveryFee
      };
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  } // ヤフオクテンプレートへの変換


  convertItemYauct(def, item) {
    return Promise.asyncApply(() => {
      const idLength = 20;
      const titleLength = 130;
      let yauct = {}; // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）

      yauct = JSON.parse(JSON.stringify(def[item.delivery])); // 画像の記述

      const imgPrefix = '画像';

      for (let i = 0; i < item.images.length; i++) {
        yauct[imgPrefix + (i + 1)] = item.images[i];
      } // タイトル


      yauct['カテゴリ'] = item.mall.yauct.category;
      yauct['タイトル'] = TextUtil.substr8(`${Promise.await(this.getModelClass(item))} ${item.delivery} ${item.name}`, titleLength);
      yauct['開始価格'] = item.sales_price;
      yauct['即決価格'] = item.sales_price;
      yauct['管理番号'] = item._id.toHexString().slice(-idLength);
      yauct['説明'] = item.description;
      yauct['JANコード・ISBNコード'] = item.jan_code;
      return yauct;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/error.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mongo.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mysql.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   *
   * @param {String} sql
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, dataSql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(dataSql)) {
        map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, dataSql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(dataSql)) {
        updates.push(`${k}=${dataSql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/packet.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Packet
});

class Packet {
  constructor(packetSize) {
    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  submit(arg) {
    return Promise.asyncApply(() => {
      // packetSizeの回数ごとに、初期化を呼び出す
      if (this.count % this.packetSize === 0) {
        if (this.onPacketStart) {
          Promise.await(this.onPacketStart(this.packetCount));
        }
      }

      if (this.onPacket) {
        Promise.await(this.onPacket(arg));
      }

      this.count++; // packetSizeの回数ごとに、終了処理を呼び出す

      if (this.count % this.packetSize === 0) {
        this.close();
        this.packetCount++;
      }
    });
  }

  close() {
    if (this.onPacketEnd) {
      this.onPacketEnd(this.packetCount);
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/report.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  setupIterator() {
    this.iterator = new Iterator();
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.setupIterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    // 直前のエラーを取得
    let lastError = null;
    let index = this.trace.error.records.length;

    if (index) {
      lastError = this.trace.error.records[index - 1];
    } // 直前と同じエラーは省く


    if (JSON.stringify(lastError) !== JSON.stringify(newRecord)) {
      if (newRecord && newRecord !== {} && newRecord !== '') {
        this.trace.error.records.push(newRecord);
      }
    }

    this.trace.error.total++;
    this.total++;
  }

  errorOcurred() {
    return this.trace.error.total;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/text.js                                                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => TextUtil
});

class TextUtil {
  static substr8(text, len, truncation) {
    if (truncation === undefined) {
      truncation = '';
    }

    var textArray = text.split('');
    var count = 0;
    var str = '';

    for (let i = 0; i < textArray.length; i++) {
      var n = escape(textArray[i]);
      if (n.length < 4) count++;else count += 2;

      if (count > len) {
        return str + truncation;
      }

      str += text.charAt(i);
    }

    return text;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90b29sdGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3lhdWN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3RleHQuanMiXSwibmFtZXMiOlsiZnMiLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJkZWZhdWx0IiwidiIsInVuaXFpZCIsIm11bHRpcGFydHkiLCJVcGxvYWRzIiwibXVsdGlwYXJ0eU1pZGRsZXdhcmUiLCJyb3V0ZSIsIldlYkFwcCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsInJlcSIsInJlc3AiLCJyZWFkZXIiLCJNZXRlb3IiLCJ3cmFwQXN5bmMiLCJyZWFkRmlsZSIsIndyaXRlciIsIndyaXRlRmlsZSIsInVwbG9hZElkIiwiZmlsZSIsImZpbGVzIiwiZGF0YSIsInBhdGgiLCJmaWxlbmFtZSIsInNhdmVQYXRoIiwiYm9keSIsImltYWdlZGlyIiwiZG9jIiwiY2xpZW50RmlsZU5hbWUiLCJuYW1lIiwidXBsb2FkZWRGaWxlTmFtZSIsImVyciIsImVycm9yIiwiaW5zZXJ0Iiwid3JpdGVIZWFkIiwiZW5kIiwiSlNPTiIsInN0cmluZ2lmeSIsInNhdmVEaXIiLCJjcnlwdG8iLCJNeVNRTCIsIlJlcG9ydCIsIkdyb3VwIiwiR3JvdXBGYWN0b3J5IiwiRmlsdGVyIiwidGFnIiwibWV0aG9kcyIsImNvbmZpZyIsInJlcG9ydCIsImZpbHRlciIsInNyY0ZpbHRlcklkIiwidGVzdFF1ZXJ5IiwiZHN0RGIiLCJkc3QiLCJjcmVkIiwicGhhc2UiLCJxdWVyeSIsInJlcyIsImZvcmVhY2giLCJtb2JpbGVOdWxsIiwicmVjb3JkIiwic3FsIiwiY3VzdG9tZXJfaWQiLCJzdGF0dXMiLCJzZXgiLCJqb2IiLCJjb3VudHJ5X2lkIiwicHJlZiIsIm5hbWUwMSIsIm5hbWUwMiIsImthbmEwMSIsImthbmEwMiIsImNvbXBhbnlfbmFtZSIsInppcDAxIiwiemlwMDIiLCJ6aXBjb2RlIiwiYWRkcjAxIiwiYWRkcjAyIiwiZW1haWwiLCJ0ZWwwMSIsInRlbDAyIiwidGVsMDMiLCJmYXgwMSIsImZheDAyIiwiZmF4MDMiLCJiaXJ0aCIsInBhc3N3b3JkIiwic2FsdCIsInNlY3JldF9rZXkiLCJmaXJzdF9idXlfZGF0ZSIsImxhc3RfYnV5X2RhdGUiLCJidXlfdGltZXMiLCJidXlfdG90YWwiLCJub3RlIiwiY3JlYXRlX2RhdGUiLCJ1cGRhdGVfZGF0ZSIsImRlbF9mbGciLCJxdWVyeUluc2VydCIsImUiLCJpRXJyb3IiLCJjdXN0b21lcl9hZGRyZXNzX2lkIiwiaWQiLCJtYWlsbWFnYV9mbGciLCJjb3Vwb25DZCIsInJhbmRvbUJ5dGVzIiwidG9TdHJpbmciLCJzdWJzdHJpbmciLCJjb3Vwb25OYW1lIiwiZGlzY291bnRQcmljZSIsInBvaW50IiwiY291cG9uX2lkIiwiY291cG9uX2NkIiwiY291cG9uX3R5cGUiLCJjb3Vwb25fbmFtZSIsImRpc2NvdW50X3R5cGUiLCJjb3Vwb25fdXNlX3RpbWUiLCJjb3Vwb25fcmVsZWFzZSIsImRpc2NvdW50X3ByaWNlIiwiZGlzY291bnRfcmF0ZSIsImVuYWJsZV9mbGFnIiwiY291cG9uX21lbWJlciIsImNvdXBvbl9sb3dlcl9saW1pdCIsImF2YWlsYWJsZV9mcm9tX2RhdGUiLCJhdmFpbGFibGVfdG9fZGF0ZSIsInB1Ymxpc2giLCJwcm9maWxlIiwiZGIiLCJNb25nb0NvbGxlY3Rpb24iLCJwbHVnIiwicHJvamVjdGlvbiIsImNvbGwiLCJnZXQiLCJjb2xsZWN0aW9uIiwiZmluZCIsInRvQXJyYXkiLCJhZ2dyZWdhdGUiLCJJdGVtQ29udHJvbGxlciIsIm1vZGVsIiwiY2xhc3MxIiwiY2xhc3MyIiwiaXRlbWNvbiIsImluaXQiLCJ1cGxvYWRlZCIsInNldEltYWdlIiwiY2xlYW5JbWFnZSIsIk1vbmdvREJGaWx0ZXIiLCJDdWJlM0FwaSIsIml0ZW1zREIiLCJpdGVtQ29udHJvbGxlciIsInRhcmdldERCIiwiY3ViZTNEQiIsImFwaSIsIml0ZW0iLCJjb250ZXh0IiwicXVhbnRpdHkiLCJnZXRTdG9jayIsIl9pZCIsInVwZGF0ZVN0b2NrIiwibWFsbCIsInNoYXJha3VTaG9wIiwicHJvZHVjdF9jbGFzc19pZCIsImNvbCIsImN1YmVJdGVtIiwiY29udmVydEl0ZW1DdWJlMyIsImNyZWF0b3JfaWQiLCJpbnNlcnRSZXMiLCJwcm9kdWN0Q3JlYXRlIiwidXBkYXRlIiwiJHNldCIsImlTdWNjZXNzIiwicHJvZHVjdEltYWdlVXBkYXRlIiwicHJvZHVjdFVwZGF0ZSIsInByb2R1Y3RUYWdVcGRhdGUiLCJuZXdMb2NhbCIsIlBhY2tldCIsImZzRXh0cmEiLCJpY29udiIsImFyY2hpdmVyIiwiY3N2IiwiUGFzc1Rocm91Z2giLCJUcmFuc2Zvcm0iLCJwcmVmaXgiLCJ3b3JrZGlyIiwiciIsImNyZWF0ZVJlYWRTdHJlYW0iLCJvcmRlckxvYWRmaWxlIiwidyIsImNyZWF0ZVdyaXRlU3RyZWFtIiwib3JkZXJTYXZlZmlsZSIsImkiLCJwaXBlIiwiZGVjb2RlU3RyZWFtIiwiZW5jb2RlU3RyZWFtIiwicGFyc2UiLCJjb2x1bW5zIiwidHJhbnNmb3JtIiwiY2FsbGJhY2siLCJnZXRNb2RlbENsYXNzIiwiaGVhZGVyIiwicGFja2V0IiwicGFja2V0U2l6ZSIsIm1rZGlyIiwicmVtb3ZlIiwidXBsb2FkZGlyIiwiY2QiLCJmaWVsZHMiLCJtYXAiLCJqb2luIiwib25QYWNrZXRTdGFydCIsInBhY2tldENvdW50Iiwic2xpY2UiLCJjc3ZGaWxlTmFtZSIsImFwcGVuZEZpbGUiLCJlbmNvZGUiLCJvblBhY2tldCIsImFyZyIsInlhdWN0IiwiaW1nIiwiaW1hZ2VzIiwiaW1nU3JjIiwiaW1nVGd0IiwiYWNjZXNzIiwiY29weUZpbGUiLCJvblBhY2tldEVuZCIsInppcCIsInppcG5hbWUiLCJvdXRwdXQiLCJkaXJlY3RvcnkiLCJmaW5hbGl6ZSIsIm1pblF1YW50aXR5IiwiY29udmVydEl0ZW1ZYXVjdCIsInN1Ym1pdCIsImNsb3NlIiwiZXhwb3J0IiwiQ29uZmlncyIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsImlkR2VuZXJhdGlvbiIsInNpZnQiLCJtb2JqZWN0IiwiR3JvdXBCYXNlIiwiRmlsdGVycyIsImNvbnN0cnVjdG9yIiwiZmlsdGVySWQiLCJmaW5kT25lIiwiZ2V0UGx1ZyIsInR5cGUiLCJteXNxbCIsImltcG9ydCIsIm9uUmVzdWx0Iiwib25FcnJvciIsInRhYmxlIiwic3RyZWFtaW5nUXVlcnkiLCJFcnJvciIsImNhbGxiYWNrcyIsImdldFByb2ZpbGUiLCJmaWx0ZXJzIiwicHVzaCIsImNvdW50IiwidW5lc2NhcGUiLCJleGFtIiwiR3JvdXBzIiwicGxhdGZvcm1QbHVnIiwiZ3JvdXBJZCIsImtleSIsImN1ciIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiZm9yRWFjaCIsImluZGV4IiwiY2F0Y2giLCJteXNxbF8iLCJwcm9kdWN0Q2xhc3NJZCIsInF1ZXJ5VXBkYXRlIiwic3RvY2siLCJzdG9ja191bmxpbWl0ZWQiLCJjcmVhdG9ySWQiLCJ0YWdvZmYiLCJwcm9kdWN0X2lkIiwidGFnb24iLCJjb3VudFJlcyIsInRhZ1NldCIsInRhZ3MiLCJzZXQiLCJwcm9kdWN0SWQiLCJsZW5ndGgiLCJmaWxlX25hbWUiLCJyYW5rIiwidXBkYXRlRGF0YSIsImtleXMiLCJrIiwiZGVzY3JpcHRpb25fbGlzdCIsInNlYXJjaF93b3JkIiwiZnJlZV9hcmVhIiwiY2xhc3NfY2F0ZWdvcnlfaWQxIiwiY2xhc3NfY2F0ZWdvcnlfaWQyIiwiZGVsaXZlcnlfZGF0ZV9pZCIsInNhbGVfbGltaXQiLCJwcm9kdWN0X3N0b2NrX2lkIiwiREJGaWx0ZXJGYWN0b3J5IiwiREJGaWx0ZXIiLCJNeXNxbERCRmlsdGVyIiwiTW9uZ29DbGllbnQiLCJpbnN0YW5jZSIsImZhY3RvcnkiLCJnZXRQbHVnXyIsImdldENyZWRfIiwiZ2V0UHJvZmlsZV8iLCJzZXRJbXBvcnRGdW5jdGlvbl8iLCJmbiIsIml0ZXJhdG9ycyIsImNvdW50ZXIiLCJmIiwibGltaXQiLCJjIiwiY2xpZW50IiwiY29ubmVjdCIsInVyaSIsImRhdGFiYXNlIiwiYWRkQ3Vyc29yRmxhZyIsImhhc05leHQiLCJuZXh0IiwiT2JqZWN0SUQiLCJUZXh0VXRpbCIsIkl0ZW1zIiwiUHJvZHVjdHMiLCJpdGVtSWQiLCJwcm9qZWN0IiwicHJvZHVjdFBhY2siLCJwcm9kdWN0IiwicXVhbnRpdGllcyIsInByb2R1Y3RTa3UiLCJxdWFudGl0eVNrdSIsInN0b2NrQXJyYXkiLCJNYXRoIiwibWluIiwiYXBwbHkiLCJmZXRjaCIsImNsYXNzMV92YWx1ZSIsImNsYXNzMl92YWx1ZSIsInVwZGF0ZU1hbnkiLCIkcHVzaCIsIiRlYWNoIiwiZ2V0VmFyaWF0aW9uIiwibGFiZWwiLCJjdXJyZW50IiwiZGVsaXZlcnkiLCJ2YWx1ZSIsImNsYXNzMV9uYW1lIiwiY2xhc3MyX25hbWUiLCJhdHRycyIsInMiLCJ2YXJpYXRpb25zIiwiJG1hdGNoIiwiT2JqZWN0IiwiYXNzaWduIiwiJHByb2plY3QiLCIkc29ydCIsInByb3BzIiwiZXhwIiwiUmVnRXhwIiwibWF0Y2giLCJ0b0hleFN0cmluZyIsIm1vZGVsQ2xhc3MiLCJjb252RGVsaXYiLCJwcm9kdWN0VHlwZUlkIiwiZGVsaXZlcnlGZWUiLCJhdHRyIiwidmFyaWF0aW9uIiwidmFyaWF0aW9uSHRtbCIsImRlc2NyaXB0aW9uRGV0YWlsIiwiamFuX2NvZGUiLCJkZXNjcmlwdGlvbl9kZXRhaWwiLCJkZXNjcmlwdGlvbiIsInByb2R1Y3RfY29kZSIsInByaWNlMDEiLCJyZXRhaWxfcHJpY2UiLCJwcmljZTAyIiwic2FsZXNfcHJpY2UiLCJwcm9kdWN0X3R5cGVfaWQiLCJkZWxpdmVyeV9mZWUiLCJkZWYiLCJpZExlbmd0aCIsInRpdGxlTGVuZ3RoIiwiaW1nUHJlZml4IiwiY2F0ZWdvcnkiLCJzdWJzdHI4IiwidXRpbEVycm9yIiwibWVzc2FnZSIsImZpbGVOYW1lIiwibGluZU51bWJlciIsImNvbHVtbk51bWJlciIsInN0YWNrIiwibW9tZW50IiwicG9vbCIsImNyZWF0ZVBvb2wiLCJwcm9maWxlTXVsdGkiLCJtdWx0aXBsZVN0YXRlbWVudHMiLCJwb29sTXVsdGkiLCJmb3JtYXREYXRlIiwiZGF0ZSIsImZvcm1hdCIsInJlcGxhY2UiLCJnZXRDb24iLCJ0aGVuIiwiY29uIiwicmVsZWFzZSIsInF1ZXJ5SW5zZXJ0XyIsImluc2VydElkIiwiZGF0YVNxbCIsIk1hcCIsImVzY2FwZSIsInZhbHVlcyIsInVwZGF0ZXMiLCJxdWVyeU11bHRpIiwicG9vbFN3YXAiLCJzdGFydFRyYW5zYWN0aW9uIiwiY29tbWl0Iiwicm9sbGJhY2siLCJvbiIsInBhdXNlIiwicmVzdW1lIiwiZ2V0Q29ubmVjdGlvbiIsIml0ZXJhdG9yIiwic2V0dXBJdGVyYXRvciIsIkl0ZXJhdG9yIiwicmVjIiwicmVzdWx0IiwidG90YWwiLCJuZXdSZWNvcmQiLCJzdWNjZXNzIiwiZXJyb3JPY3VycmVkIiwiaXRlRXJyb3IiLCJwaGFFcnJvciIsInRyYWNlIiwicmVjb3JkcyIsImxhc3RFcnJvciIsInRleHQiLCJsZW4iLCJ0cnVuY2F0aW9uIiwidW5kZWZpbmVkIiwidGV4dEFycmF5Iiwic3BsaXQiLCJzdHIiLCJuIiwiY2hhckF0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLEVBQUo7QUFBT0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0wsU0FBR0ssQ0FBSDtBQUFLOztBQUFqQixDQUEzQixFQUE4QyxDQUE5QztBQUFpRCxJQUFJQyxNQUFKO0FBQVdMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUUsVUFBSjtBQUFlTixPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYixFQUEyQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0UsaUJBQVdGLENBQVg7QUFBYTs7QUFBekIsQ0FBM0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSUcsT0FBSjtBQUFZUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUNBQVIsQ0FBYixFQUE0RDtBQUFDSyxVQUFRSCxDQUFSLEVBQVU7QUFBQ0csY0FBUUgsQ0FBUjtBQUFVOztBQUF0QixDQUE1RCxFQUFvRixDQUFwRjtBQWFoTyxJQUFJSSx1QkFBdUJGLFlBQTNCO0FBRUEsTUFBTUcsUUFBUSxlQUFkLEMsQ0FFQTs7QUFDQUMsT0FBT0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJILEtBQTNCLEVBQWtDRCxvQkFBbEM7QUFDQUUsT0FBT0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJILEtBQTNCLEVBQWtDLENBQUNJLEdBQUQsRUFBTUMsSUFBTixLQUFlO0FBQy9DO0FBRUEsUUFBTUMsU0FBU0MsT0FBT0MsU0FBUCxDQUFpQmxCLEdBQUdtQixRQUFwQixDQUFmO0FBQ0EsUUFBTUMsU0FBU0gsT0FBT0MsU0FBUCxDQUFpQmxCLEdBQUdxQixTQUFwQixDQUFmO0FBQ0EsUUFBTUMsV0FBV2hCLFFBQWpCOztBQUVBLE9BQUssSUFBSWlCLElBQVQsSUFBaUJULElBQUlVLEtBQUosQ0FBVUQsSUFBM0IsRUFBaUM7QUFDL0IsVUFBTUUsT0FBT1QsT0FBT08sS0FBS0csSUFBWixDQUFiLENBRCtCLENBRS9CO0FBQ0E7O0FBQ0EsUUFBSUMsV0FBWSxHQUFFckIsUUFBUyxNQUEzQixDQUorQixDQU0vQjs7QUFDQSxRQUFJc0IsV0FBV2QsSUFBSWUsSUFBSixDQUFTQyxRQUFULEdBQW9CLEdBQXBCLEdBQTBCSCxRQUF6QyxDQVArQixDQVMvQjtBQUVBOztBQUNBLFFBQUlJLE1BQU07QUFDUlQsZ0JBQVVBLFFBREY7QUFFUlUsc0JBQWdCVCxLQUFLVSxJQUZiO0FBR1JDLHdCQUFrQlA7QUFIVixLQUFWOztBQU1BLFFBQUc7QUFDRFAsYUFBT1EsUUFBUCxFQUFpQkgsSUFBakI7QUFDRCxLQUZELENBR0EsT0FBTVUsR0FBTixFQUFVO0FBQ1JKLFVBQUlLLEtBQUosR0FBWUQsR0FBWjtBQUNEOztBQUNEM0IsWUFBUTZCLE1BQVIsQ0FBZU4sR0FBZjtBQUVBLFdBQU9SLElBQVA7QUFFRDs7QUFBQTtBQUNEUixPQUFLdUIsU0FBTCxDQUFlLEdBQWY7QUFDQXZCLE9BQUt3QixHQUFMLENBQVNDLEtBQUtDLFNBQUwsQ0FBZTtBQUN0Qm5CLGNBQVVBLFFBRFk7QUFFdEJvQixhQUFTNUIsSUFBSWUsSUFBSixDQUFTQztBQUZJLEdBQWYsQ0FBVDtBQUtELENBMUNELEU7Ozs7Ozs7Ozs7O0FDbkJBLElBQUlhLE1BQUo7QUFBVzFDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzQyxhQUFPdEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFO0FBQTBFLElBQUl3QyxNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQWxELEVBQXlFLENBQXpFO0FBQTRFLElBQUl5QyxLQUFKLEVBQVVDLFlBQVY7QUFBdUI5QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUNBQVIsQ0FBYixFQUF3RDtBQUFDMkMsUUFBTXpDLENBQU4sRUFBUTtBQUFDeUMsWUFBTXpDLENBQU47QUFBUSxHQUFsQjs7QUFBbUIwQyxlQUFhMUMsQ0FBYixFQUFlO0FBQUMwQyxtQkFBYTFDLENBQWI7QUFBZTs7QUFBbEQsQ0FBeEQsRUFBNEcsQ0FBNUc7QUFBK0csSUFBSTJDLE1BQUo7QUFBVy9DLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQ0FBUixDQUFiLEVBQXlEO0FBQUM2QyxTQUFPM0MsQ0FBUCxFQUFTO0FBQUMyQyxhQUFPM0MsQ0FBUDtBQUFTOztBQUFwQixDQUF6RCxFQUErRSxDQUEvRTtBQWExYyxJQUFJNEMsTUFBTSxTQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLFVBQWQsRUFBMEJFLE1BQTFCO0FBQUEsb0NBQWtDO0FBQ2hDLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiLENBRGdDLENBR2hDO0FBQ0E7O0FBRUEsVUFBSVEsU0FBUyxJQUFJTCxNQUFKLENBQVdHLE9BQU9HLFdBQWxCLENBQWIsQ0FOZ0MsQ0FPaEM7QUFFQTtBQUNBOztBQUVBLFVBQUlDLFlBQVksZ0JBQWhCO0FBRUEsVUFBSUMsUUFBUSxJQUFJWixLQUFKLENBQVVPLE9BQU9NLEdBQVAsQ0FBV0MsSUFBckIsQ0FBWjtBQUVBLG9CQUFNTixPQUFPTyxLQUFQLENBQWEsd0JBQWIsRUFDSiwrQkFBWTtBQUNWLHNCQUFNSCxNQUFNSSxLQUFOLENBQVlMLFNBQVosQ0FBTjtBQUNELE9BRkQsQ0FESSxDQUFOLEVBaEJnQyxDQXFCaEM7QUFDQTs7QUFFQSxvQkFBTUgsT0FBT08sS0FBUCxDQUFhLHVCQUFiLEVBQ0osK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCQyxzQkFBbUJDLE1BQVAsNkJBQWtCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsZ0JBQUlDLE1BQU87Ozs7OzBCQUtHRCxPQUFPRSxXQUFZLE1BQUtGLE9BQU9HLE1BQU8sTUFBS0gsT0FBT0ksR0FBSSxNQUFLSixPQUFPSyxHQUFJLE1BQUtMLE9BQU9NLFVBQVcsTUFBS04sT0FBT08sSUFBSyxNQUFLUCxPQUFPUSxNQUFPLE1BQUtSLE9BQU9TLE1BQU8sTUFBS1QsT0FBT1UsTUFBTyxNQUFLVixPQUFPVyxNQUFPLE1BQUtYLE9BQU9ZLFlBQWEsTUFBS1osT0FBT2EsS0FBTSxNQUFLYixPQUFPYyxLQUFNLE1BQUtkLE9BQU9lLE9BQVEsTUFBS2YsT0FBT2dCLE1BQU8sTUFBS2hCLE9BQU9pQixNQUFPLE1BQUtqQixPQUFPa0IsS0FBTSxNQUFLbEIsT0FBT21CLEtBQU0sTUFBS25CLE9BQU9vQixLQUFNLE1BQUtwQixPQUFPcUIsS0FBTSxNQUFLckIsT0FBT3NCLEtBQU0sTUFBS3RCLE9BQU91QixLQUFNLE1BQUt2QixPQUFPd0IsS0FBTSxNQUFLeEIsT0FBT3lCLEtBQU0sTUFBS3pCLE9BQU8wQixRQUFTLE1BQUsxQixPQUFPMkIsSUFBSyxNQUFLM0IsT0FBTzRCLFVBQVcsTUFBSzVCLE9BQU82QixjQUFlLE1BQUs3QixPQUFPOEIsYUFBYyxNQUFLOUIsT0FBTytCLFNBQVUsTUFBSy9CLE9BQU9nQyxTQUFVLE1BQUtoQyxPQUFPaUMsSUFBSyxNQUFLakMsT0FBT2tDLFdBQVksTUFBS2xDLE9BQU9tQyxXQUFZLE1BQUtuQyxPQUFPb0MsT0FBUTs7aUJBTGxzQjs7QUFTQSxnQkFBSTtBQUNGLDRCQUFNNUMsTUFBTTZDLFdBQU4sQ0FDSixjQURJLEVBQ1k7QUFDZG5DLDZCQUFhRixPQUFPRSxXQUROO0FBRWRDLHdCQUFRSCxPQUFPRyxNQUZEO0FBR2RDLHFCQUFLSixPQUFPSSxHQUhFO0FBSWRDLHFCQUFLTCxPQUFPSyxHQUpFO0FBS2RDLDRCQUFZTixPQUFPTSxVQUxMO0FBTWRDLHNCQUFNUCxPQUFPTyxJQU5DO0FBT2RDLHdCQUFRUixPQUFPUSxNQVBEO0FBUWRDLHdCQUFRVCxPQUFPUyxNQVJEO0FBU2RDLHdCQUFRVixPQUFPVSxNQVREO0FBVWRDLHdCQUFRWCxPQUFPVyxNQVZEO0FBV2RDLDhCQUFjWixPQUFPWSxZQVhQO0FBWWRDLHVCQUFPYixPQUFPYSxLQVpBO0FBYWRDLHVCQUFPZCxPQUFPYyxLQWJBO0FBY2RDLHlCQUFTZixPQUFPZSxPQWRGO0FBZWRDLHdCQUFRaEIsT0FBT2dCLE1BZkQ7QUFnQmRDLHdCQUFRakIsT0FBT2lCLE1BaEJEO0FBaUJkQyx1QkFBT2xCLE9BQU9rQixLQWpCQTtBQWtCZEMsdUJBQU9uQixPQUFPbUIsS0FsQkE7QUFtQmRDLHVCQUFPcEIsT0FBT29CLEtBbkJBO0FBb0JkQyx1QkFBT3JCLE9BQU9xQixLQXBCQTtBQXFCZEMsdUJBQU90QixPQUFPc0IsS0FyQkE7QUFzQmRDLHVCQUFPdkIsT0FBT3VCLEtBdEJBO0FBdUJkQyx1QkFBT3hCLE9BQU93QixLQXZCQTtBQXdCZEMsdUJBQU96QixPQUFPeUIsS0F4QkE7QUF5QmRDLDBCQUFVMUIsT0FBTzBCLFFBekJIO0FBMEJkQyxzQkFBTTNCLE9BQU8yQixJQTFCQztBQTJCZEMsNEJBQVk1QixPQUFPNEIsVUEzQkw7QUE0QmRDLGdDQUFnQjdCLE9BQU82QixjQTVCVDtBQTZCZEMsK0JBQWU5QixPQUFPOEIsYUE3QlI7QUE4QmRDLDJCQUFXL0IsT0FBTytCLFNBOUJKO0FBK0JkQywyQkFBV2hDLE9BQU9nQyxTQS9CSjtBQWdDZEMsc0JBQU1qQyxPQUFPaUMsSUFoQ0M7QUFpQ2RDLDZCQUFhbEMsT0FBT2tDLFdBakNOO0FBa0NkQyw2QkFBYW5DLE9BQU9tQyxXQWxDTjtBQW1DZEMseUJBQVNwQyxPQUFPb0M7QUFuQ0YsZUFEWixDQUFOO0FBdUNELGFBeENELENBd0NFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWhFMkIsQ0FrRTVCOzs7QUFDQSxnQkFBSTtBQUNGLDRCQUFNOUMsTUFBTTZDLFdBQU4sQ0FDSixzQkFESSxFQUNvQjtBQUN0QkcscUNBQXFCLElBREM7QUFFdEJ0Qyw2QkFBYUYsT0FBT0UsV0FGRTtBQUd0QkksNEJBQVlOLE9BQU9NLFVBSEc7QUFJdEJDLHNCQUFNUCxPQUFPTyxJQUpTO0FBS3RCQyx3QkFBUVIsT0FBT1EsTUFMTztBQU10QkMsd0JBQVFULE9BQU9TLE1BTk87QUFPdEJDLHdCQUFRVixPQUFPVSxNQVBPO0FBUXRCQyx3QkFBUVgsT0FBT1csTUFSTztBQVN0QkMsOEJBQWNaLE9BQU9ZLFlBVEM7QUFVdEJDLHVCQUFPYixPQUFPYSxLQVZRO0FBV3RCQyx1QkFBT2QsT0FBT2MsS0FYUTtBQVl0QkMseUJBQVNmLE9BQU9lLE9BWk07QUFhdEJDLHdCQUFRaEIsT0FBT2dCLE1BYk87QUFjdEJDLHdCQUFRakIsT0FBT2lCLE1BZE87QUFldEJFLHVCQUFPbkIsT0FBT21CLEtBZlE7QUFnQnRCQyx1QkFBT3BCLE9BQU9vQixLQWhCUTtBQWlCdEJDLHVCQUFPckIsT0FBT3FCLEtBakJRO0FBa0J0QkMsdUJBQU90QixPQUFPc0IsS0FsQlE7QUFtQnRCQyx1QkFBT3ZCLE9BQU91QixLQW5CUTtBQW9CdEJDLHVCQUFPeEIsT0FBT3dCLEtBcEJRO0FBcUJ0QlUsNkJBQWFsQyxPQUFPa0MsV0FyQkU7QUFzQnRCQyw2QkFBYW5DLE9BQU9tQyxXQXRCRTtBQXVCdEJDLHlCQUFTcEMsT0FBT29DO0FBdkJNLGVBRHBCLENBQU47QUEyQkQsYUE1QkQsQ0E0QkUsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBakcyQixDQW1HNUI7OztBQUNBLGdCQUFJO0FBQ0YsNEJBQU05QyxNQUFNNkMsV0FBTixDQUNKLHVCQURJLEVBQ3FCO0FBQ3ZCSSxvQkFBSSxJQURtQjtBQUV2QnZDLDZCQUFhRixPQUFPRSxXQUZHO0FBR3ZCd0MsOEJBQWMxQyxPQUFPMEMsWUFIRTtBQUl2QlIsNkJBQWFsQyxPQUFPa0MsV0FKRztBQUt2QkMsNkJBQWFuQyxPQUFPbUMsV0FMRztBQU12QkMseUJBQVNwQyxPQUFPb0M7QUFOTyxlQURyQixDQUFOO0FBVUQsYUFYRCxDQVdFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWpIMkIsQ0FtSDVCOzs7QUFFQSxnQkFBSUssV0FBV2hFLE9BQU9pRSxXQUFQLENBQW1CLENBQW5CLEVBQXNCQyxRQUF0QixDQUErQixRQUEvQixFQUF5Q0MsU0FBekMsQ0FBbUQsQ0FBbkQsRUFBc0QsRUFBdEQsQ0FBZjtBQUVBLGdCQUFJQyxhQUFjLEdBQUUvQyxPQUFPUSxNQUFPLElBQUdSLE9BQU9TLE1BQU8sbUJBQWtCVCxPQUFPRSxXQUFZLEVBQXhGO0FBRUEsZ0JBQUk4QyxnQkFBZ0JoRCxPQUFPaUQsS0FBUCxHQUFlLEdBQW5DOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUlwRCxvQkFBWUwsTUFBTTZDLFdBQU4sQ0FDZCxZQURjLEVBQ0E7QUFDWmEsMkJBQVcsSUFEQztBQUVaQywyQkFBV1IsUUFGQztBQUdaUyw2QkFBYSxDQUhEO0FBR0k7QUFDaEJDLDZCQUFhTixVQUpEO0FBS1pPLCtCQUFlLENBTEg7QUFNWkMsaUNBQWlCLENBTkw7QUFPWkMsZ0NBQWdCLENBUEo7QUFRWkMsZ0NBQWdCVCxhQVJKO0FBU1pVLCtCQUFlLElBVEg7QUFVWkMsNkJBQWEsQ0FWRDtBQVdaQywrQkFBZSxDQVhIO0FBWVpDLG9DQUFvQixJQVpSO0FBYVozRCw2QkFBYUYsT0FBT0UsV0FiUjtBQWNaNEQscUNBQXFCLHFCQWRUO0FBZVpDLG1DQUFtQixxQkFmUDtBQWdCWjNCLHlCQUFTO0FBaEJHLGVBREEsRUFrQlg7QUFDREYsNkJBQWEsT0FEWjtBQUVEQyw2QkFBYTtBQUZaLGVBbEJXLENBQVosQ0FBSjtBQXVCRCxhQXhCRCxDQXdCRSxPQUFPRyxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRixXQXRKVztBQURpQixTQUFmLEVBeUpUQSxDQUFQLDZCQUFhO0FBQ1hsRCxpQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELFNBRkQsQ0F6SmdCLENBQVosQ0FBSjtBQThKQSxlQUFPekMsR0FBUDtBQUNELE9BaEtELENBREksQ0FBTjtBQW1LQSxhQUFPVCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0E1TEQ7QUFBQSxHQUZhOztBQWdNUCx1QkFBTixDQUE2QkMsT0FBN0I7QUFBQSxvQ0FBc0M7QUFDcEMsVUFBSUMsS0FBSyxJQUFJdEYsS0FBSixDQUFVcUYsT0FBVixDQUFUO0FBQ0EsVUFBSXBFLG9CQUFZcUUsR0FBR3RFLEtBQUgsQ0FBUyxnQkFBVCxDQUFaLENBQUo7QUFDQSxhQUFPQyxHQUFQO0FBQ0QsS0FKRDtBQUFBOztBQWhNYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSXNFLGVBQUo7QUFBb0JsSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDZ0ksa0JBQWdCOUgsQ0FBaEIsRUFBa0I7QUFBQzhILHNCQUFnQjlILENBQWhCO0FBQWtCOztBQUF0QyxDQUFqRCxFQUF5RixDQUF6RjtBQUE0RixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRzNILElBQUk0QyxNQUFNLGtCQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLE9BQWQsRUFBdUJtRixJQUF2QixFQUE2QnhFLFFBQVEsRUFBckMsRUFBeUN5RSxhQUFhLEVBQXREO0FBQUEsb0NBQTBEO0FBQ3hELFVBQUlDLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQkEsS0FBS0ksVUFBL0IsQ0FBYixDQUFKO0FBQ0EsVUFBSTNFLG9CQUFZeUUsS0FBS0csSUFBTCxDQUFVN0UsS0FBVixFQUFpQjtBQUFDeUUsb0JBQVlBO0FBQWIsT0FBakIsRUFBMkNLLE9BQTNDLEVBQVosQ0FBSjtBQUNBLGFBQU83RSxHQUFQO0FBQ0QsS0FKRDtBQUFBLEdBRmE7O0FBUWIsR0FBUSxHQUFFWixHQUFJLFlBQWQsRUFBNEJtRixJQUE1QixFQUFrQ3hFLFFBQVEsRUFBMUM7QUFBQSxvQ0FBOEM7QUFDNUMsVUFBSTBFLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQkEsS0FBS0ksVUFBL0IsQ0FBYixDQUFKO0FBQ0EsVUFBSTNFLG9CQUFZeUUsS0FBS0ssU0FBTCxDQUFlL0UsS0FBZixFQUFzQjhFLE9BQXRCLEVBQVosQ0FBSjtBQUNBLGFBQU83RSxHQUFQO0FBQ0QsS0FKRDtBQUFBOztBQVJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJK0UsY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFwRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBR3BILElBQUk0QyxNQUFNLGFBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjs7Ozs7QUFLQSxHQUFRLEdBQUVELEdBQUksV0FBZCxFQUEyQm1GLElBQTNCLEVBQWlDOUcsUUFBakMsRUFBMkN1SCxLQUEzQyxFQUFrREMsU0FBUyxJQUEzRCxFQUFpRUMsU0FBUyxJQUExRTtBQUFBLG9DQUFnRjtBQUM5RSxVQUFJQyxVQUFVLElBQUlKLGNBQUosRUFBZDtBQUNBLG9CQUFNSSxRQUFRQyxJQUFSLENBQWFiLElBQWIsQ0FBTjtBQUNBLFVBQUljLHlCQUFpQkYsUUFBUUcsUUFBUixDQUFpQjdILFFBQWpCLEVBQTJCdUgsS0FBM0IsRUFBa0NDLE1BQWxDLEVBQTBDQyxNQUExQyxDQUFqQixDQUFKO0FBQ0EsYUFBT0csUUFBUDtBQUNELEtBTEQ7QUFBQSxHQVBhOztBQWNiOzs7QUFHQSxHQUFRLEdBQUVqRyxHQUFJLGFBQWQsRUFBNkJtRixJQUE3QixFQUFtQ1MsS0FBbkMsRUFBMENDLFNBQVMsSUFBbkQsRUFBeURDLFNBQVMsSUFBbEU7QUFBQSxvQ0FBd0U7QUFDdEUsVUFBSUMsVUFBVSxJQUFJSixjQUFKLEVBQWQ7QUFDQSxvQkFBTUksUUFBUUMsSUFBUixDQUFhYixJQUFiLENBQU47QUFDQSxvQkFBTVksUUFBUUksVUFBUixDQUFtQlAsS0FBbkIsRUFBMEJDLE1BQTFCLEVBQWtDQyxNQUFsQyxDQUFOO0FBQ0QsS0FKRDtBQUFBOztBQWpCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSWxHLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWdKLGFBQUo7QUFBa0JwSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDa0osZ0JBQWNoSixDQUFkLEVBQWdCO0FBQUNnSixvQkFBY2hKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUlpSixRQUFKO0FBQWFySixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDbUosV0FBU2pKLENBQVQsRUFBVztBQUFDaUosZUFBU2pKLENBQVQ7QUFBVzs7QUFBeEIsQ0FBcEQsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSXVJLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQVlqZSxJQUFJNEMsTUFBTSxNQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxjQUFkLEVBQThCRSxNQUE5QjtBQUFBLG9DQUFzQztBQUNwQztBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsVUFBSVEsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBQ0EsVUFBSXVCLGlCQUFpQixJQUFJWixjQUFKLEVBQXJCO0FBQ0Esb0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTjtBQUVBLFVBQUlFLFdBQVcsSUFBSTdHLEtBQUosQ0FBVU8sT0FBT3VHLE9BQWpCLENBQWY7QUFDQSxVQUFJQyxNQUFNLElBQUlMLFFBQUosQ0FBYUcsUUFBYixDQUFWO0FBRUEsb0JBQU1yRyxPQUFPTyxLQUFQLENBQ0osT0FESSxFQUVKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSUMseUJBQWlCTixlQUFlTyxRQUFmLENBQXdCSCxLQUFLSSxHQUE3QixDQUFqQixDQUFKO0FBQ0EsMEJBQU1MLElBQUlNLFdBQUosQ0FBZ0JMLEtBQUtNLElBQUwsQ0FBVUMsV0FBVixDQUFzQkMsZ0JBQXRDLEVBQXdETixRQUF4RCxDQUFOO0FBQ0QsV0FIUztBQUZtQixTQUFmLENBQVosQ0FBSjtBQU9BLGVBQU9qRyxHQUFQO0FBQ0QsT0FURCxDQUZJLENBQU47QUFhQSxhQUFPVCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0F6QkQ7QUFBQSxHQUxhOztBQWdDYjtBQUNBO0FBRUEsR0FBUSxHQUFFL0UsR0FBSSxZQUFkLEVBQTRCRSxNQUE1QjtBQUFBLG9DQUFvQztBQUNsQyxVQUFJRSxTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWI7QUFDQSxVQUFJd0IsV0FBVyxJQUFJN0csS0FBSixDQUFVTyxPQUFPdUcsT0FBakIsQ0FBZjtBQUNBLFVBQUlDLE1BQU0sSUFBSUwsUUFBSixDQUFhRyxRQUFiLENBQVY7QUFFQSxVQUFJRCxpQkFBaUIsSUFBSVosY0FBSixFQUFyQjtBQUNBLG9CQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOa0MsQ0FRbEM7O0FBQ0EsVUFBSW5HLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSixlQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJUSxNQUFNUixRQUFRckIsVUFBbEI7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSThCLHlCQUFpQmQsZUFBZWUsZ0JBQWYsQ0FBZ0NwSCxPQUFPcUgsVUFBdkMsRUFBbURaLElBQW5ELENBQWpCLENBQUo7QUFFQSxrQkFBSWEsMEJBQWtCZCxJQUFJZSxhQUFKLENBQWtCSixRQUFsQixDQUFsQixDQUFKLENBSEUsQ0FLRjs7QUFDQSw0QkFBTUQsSUFBSU0sTUFBSixDQUFXO0FBQ2ZYLHFCQUFLSixLQUFLSTtBQURLLGVBQVgsRUFFSDtBQUNEWSxzQkFBTTtBQUNKLHNDQUFvQkgsVUFBVTVHO0FBRDFCO0FBREwsZUFGRyxDQUFOO0FBUUFULHFCQUFPeUgsUUFBUDtBQUNELGFBZkQsQ0FlRSxPQUFPdkUsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0FyQlM7QUFEbUIsU0FBZixFQXdCVEEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQXhCZ0IsQ0FBWixDQUFKO0FBNEJBLGVBQU96QyxHQUFQO0FBQ0QsT0E5QkQsQ0FGSSxDQUFOO0FBa0NBLG9CQUFNVCxPQUFPTyxLQUFQLENBQ0osZ0JBREksRUFFSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFDN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlRLE1BQU1SLFFBQVFyQixVQUFsQjs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJOEIseUJBQWlCZCxlQUFlZSxnQkFBZixDQUFnQ3BILE9BQU9xSCxVQUF2QyxFQUFtRFosSUFBbkQsQ0FBakIsQ0FBSjtBQUVBLDRCQUFNRCxJQUFJbUIsa0JBQUosQ0FBdUJSLFFBQXZCLENBQU47QUFDQSw0QkFBTVgsSUFBSW9CLGFBQUosQ0FBa0JULFFBQWxCLENBQU47QUFDQSw0QkFBTVgsSUFBSXFCLGdCQUFKLENBQXFCVixRQUFyQixDQUFOO0FBRUEsa0JBQUlSLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF3QkgsS0FBS0ksR0FBN0IsQ0FBakIsQ0FBSjtBQUNBLDRCQUFNTCxJQUFJTSxXQUFKLENBQWdCTCxLQUFLTSxJQUFMLENBQVVDLFdBQVYsQ0FBc0JDLGdCQUF0QyxFQUF3RE4sUUFBeEQsQ0FBTjtBQUVBMUcscUJBQU95SCxRQUFQO0FBQ0QsYUFYRCxDQVdFLE9BQU92RSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRixXQWpCUztBQURtQixTQUFmLEVBb0JUQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBcEJnQixDQUFaLENBQUo7QUF3QkEsZUFBT3pDLEdBQVA7QUFDRCxPQTFCRCxDQUZJLENBQU47QUE4QkEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBNUVEO0FBQUE7O0FBbkNhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNkQSxJQUFJbkYsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQU83UixJQUFJNEMsTUFBTSxNQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXVCRSxNQUF2QjtBQUFBLG9DQUErQjtBQUM3QjtBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsVUFBSVEsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBRUEsWUFBTWdELHlCQUFpQjVILE9BQU9TLE9BQVAsQ0FBZSxFQUFmLEVBQTBCd0MsQ0FBUCw2QkFBYTtBQUNyRCxjQUFNQSxDQUFOO0FBQ0QsT0FGeUMsQ0FBbkIsQ0FBakIsQ0FBTjtBQUdBLG9CQUFNbEQsT0FBT08sS0FBUCxDQUNKLFVBREksRUFFSiwrQkFBWTtBQUNWLGVBQU9zSCxRQUFQO0FBQ0QsT0FGRCxDQUZJLENBQU47QUFNQSxhQUFPN0gsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBaEJEO0FBQUE7O0FBTGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ1RBLElBQUluRixNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk2SyxNQUFKO0FBQVdqTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZLLGFBQU83SyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUk4SyxPQUFKO0FBQVlsTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDOEssY0FBUTlLLENBQVI7QUFBVTs7QUFBdEIsQ0FBakMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSStLLEtBQUo7QUFBVW5MLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMrSyxZQUFNL0ssQ0FBTjtBQUFROztBQUFwQixDQUFuQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJZ0wsUUFBSjtBQUFhcEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2dMLGVBQVNoTCxDQUFUO0FBQVc7O0FBQXZCLENBQWpDLEVBQTBELENBQTFEO0FBQTZELElBQUlpTCxHQUFKO0FBQVFyTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsS0FBUixDQUFiLEVBQTRCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDaUwsVUFBSWpMLENBQUo7QUFBTTs7QUFBbEIsQ0FBNUIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSWtMLFdBQUosRUFBZ0JDLFNBQWhCO0FBQTBCdkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDb0wsY0FBWWxMLENBQVosRUFBYztBQUFDa0wsa0JBQVlsTCxDQUFaO0FBQWMsR0FBOUI7O0FBQStCbUwsWUFBVW5MLENBQVYsRUFBWTtBQUFDbUwsZ0JBQVVuTCxDQUFWO0FBQVk7O0FBQXhELENBQS9CLEVBQXlGLENBQXpGO0FBZWx2QixNQUFNb0wsU0FBUyxRQUFmO0FBQ0EsTUFBTXhJLE1BQU0sT0FBWjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksUUFBZCxFQUF3QkUsTUFBeEI7QUFBQSxvQ0FBZ0M7QUFDOUI7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osUUFESSxFQUVKLCtCQUFZO0FBQ1YsY0FBTTZGLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTjtBQUNBLGNBQU1tQyxVQUFXLEdBQUV2SSxPQUFPdUksT0FBUSxRQUFsQztBQUNBLGNBQU1DLElBQUlSLFFBQVFTLGdCQUFSLENBQTBCLEdBQUVGLE9BQVEsSUFBR3ZJLE9BQU8wSSxhQUFjLEVBQTVELENBQVY7QUFDQSxjQUFNQyxJQUFJWCxRQUFRWSxpQkFBUixDQUEyQixHQUFFTCxPQUFRLElBQUd2SSxPQUFPNkksYUFBYyxFQUE3RCxDQUFWO0FBQ0EsWUFBSUMsSUFBSSxDQUFSO0FBQ0FOLFVBQUVPLElBQUYsQ0FBT2QsTUFBTWUsWUFBTixDQUFtQixNQUFuQixDQUFQLEVBQ0dELElBREgsQ0FDUWQsTUFBTWdCLFlBQU4sQ0FBbUIsT0FBbkIsQ0FEUixFQUVHRixJQUZILENBRVFaLElBQUllLEtBQUosQ0FBVTtBQUFDQyxtQkFBUztBQUFWLFNBQVYsQ0FGUixFQUdHSixJQUhILENBR1FaLElBQUlpQixTQUFKLENBQ0osQ0FBT3ZJLE1BQVAsRUFBZXdJLFFBQWYsOEJBQTRCO0FBQzFCLGNBQUlySyxNQUFNLElBQVYsQ0FEMEIsQ0FFMUI7O0FBQ0EsY0FBSTtBQUNGNkIsbUJBQU8sTUFBUCxrQkFBdUJ3RixlQUFlaUQsYUFBZixDQUE2QnpJLE9BQU8sTUFBUCxDQUE3QixDQUF2QjtBQUNELFdBRkQsQ0FFRSxPQUFPc0MsQ0FBUCxFQUFVO0FBQ1ZuRSxrQkFBTW1FLENBQU47QUFDRDs7QUFDRGtHLG1CQUFTckssR0FBVCxFQUFjNkIsTUFBZDtBQUNELFNBVEQsQ0FESSxDQUhSLEVBZUdrSSxJQWZILENBZVFaLElBQUk3SSxTQUFKLENBQWM7QUFBQ2lLLGtCQUFRO0FBQVQsU0FBZCxDQWZSLEVBZ0JHUixJQWhCSCxDQWdCUWQsTUFBTWUsWUFBTixDQUFtQixPQUFuQixDQWhCUixFQWlCR0QsSUFqQkgsQ0FpQlFkLE1BQU1nQixZQUFOLENBQW1CLE1BQW5CLENBakJSLEVBa0JHRixJQWxCSCxDQWtCUUosQ0FsQlI7QUFtQkQsT0ExQkQsQ0FGSSxDQUFOO0FBOEJELEtBbENEO0FBQUEsR0FMYTs7QUF5Q2I7QUFDQTtBQUVBLEdBQVEsR0FBRTdJLEdBQUksVUFBZCxFQUEwQkUsTUFBMUI7QUFBQSxvQ0FBa0M7QUFDaEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osUUFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUVBLGNBQU1OLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBZjtBQUNBLGNBQU11QixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOVSxDQVFWOztBQUNBLGNBQU1vRCxTQUFTLElBQUl6QixNQUFKLENBQVcvSCxPQUFPeUosVUFBbEIsQ0FBZixDQVRVLENBV1Y7O0FBQ0EsWUFBSTtBQUNGLHdCQUFNekIsUUFBUTBCLEtBQVIsQ0FBYzFKLE9BQU91SSxPQUFyQixDQUFOO0FBQ0QsU0FGRCxDQUVFLE9BQU9wRixDQUFQLEVBQVUsQ0FBRSxDQWRKLENBZ0JWOzs7QUFDQSxjQUFNb0YsVUFBVyxHQUFFdkksT0FBT3VJLE9BQVEsT0FBbEM7QUFDQSxzQkFBTVAsUUFBUTJCLE1BQVIsQ0FBZXBCLE9BQWYsQ0FBTjtBQUNBLHNCQUFNUCxRQUFRMEIsS0FBUixDQUFjbkIsT0FBZCxDQUFOLEVBbkJVLENBcUJWOztBQUNBLGNBQU1xQixZQUFhLEdBQUU1SixPQUFPdUksT0FBUSxTQUFwQztBQUNBLHNCQUFNUCxRQUFRMkIsTUFBUixDQUFlQyxTQUFmLENBQU47QUFDQSxzQkFBTTVCLFFBQVEwQixLQUFSLENBQWNFLFNBQWQsQ0FBTjtBQUVBLFlBQUlDLEtBQUssSUFBVCxDQTFCVSxDQTBCSTs7QUFDZCxZQUFJckwsV0FBVyxJQUFmLENBM0JVLENBMkJVOztBQUNwQixZQUFJTSxPQUFPLElBQVgsQ0E1QlUsQ0E0Qk07QUFFaEI7O0FBQ0EsWUFBSWdMLFNBQVMsQ0FBQyxNQUFELEVBQVMsTUFBVCxFQUFpQixNQUFqQixFQUF5QixJQUF6QixFQUErQixnQkFBL0IsRUFBaUQsTUFBakQsRUFBeUQsTUFBekQsRUFBaUUsT0FBakUsRUFBMEUsSUFBMUUsRUFBZ0YsUUFBaEYsRUFBMEYsSUFBMUYsRUFBZ0csTUFBaEcsRUFBd0csWUFBeEcsRUFBc0gsWUFBdEgsRUFBb0ksTUFBcEksRUFBNEksV0FBNUksRUFBeUosWUFBekosRUFBdUssT0FBdkssRUFBZ0wsU0FBaEwsRUFBMkwsT0FBM0wsRUFBb00sU0FBcE0sRUFBK00sS0FBL00sRUFBc04sU0FBdE4sRUFBaU8sS0FBak8sRUFBd08sU0FBeE8sRUFBbVAsS0FBblAsRUFBMFAsU0FBMVAsRUFBcVEsS0FBclEsRUFBNFEsU0FBNVEsRUFBdVIsS0FBdlIsRUFBOFIsU0FBOVIsRUFBeVMsS0FBelMsRUFBZ1QsU0FBaFQsRUFBMlQsS0FBM1QsRUFBa1UsU0FBbFUsRUFBNlUsS0FBN1UsRUFBb1YsU0FBcFYsRUFBK1YsS0FBL1YsRUFBc1csU0FBdFcsRUFBaVgsTUFBalgsRUFBeVgsVUFBelgsRUFBcVksTUFBclksRUFBNlksUUFBN1ksRUFBdVosU0FBdlosRUFBa2EsTUFBbGEsRUFBMGEsTUFBMWEsRUFBa2IsVUFBbGIsRUFBOGIsT0FBOWIsRUFBdWMsUUFBdmMsRUFBaWQsUUFBamQsRUFBMmQsV0FBM2QsRUFBd2UsUUFBeGUsRUFBa2YsS0FBbGYsRUFBeWYsY0FBemYsRUFBeWdCLFNBQXpnQixFQUFvaEIsU0FBcGhCLEVBQStoQixZQUEvaEIsRUFBNmlCLGNBQTdpQixFQUE2akIsUUFBN2pCLEVBQXVrQixPQUF2a0IsRUFBZ2xCLFFBQWhsQixFQUEwbEIsVUFBMWxCLEVBQXNtQixtQkFBdG1CLEVBQTJuQixnQkFBM25CLEVBQTZvQixVQUE3b0IsRUFBeXBCLG1CQUF6cEIsRUFBOHFCLGdCQUE5cUIsRUFBZ3NCLFVBQWhzQixFQUE0c0IsbUJBQTVzQixFQUFpdUIsZ0JBQWp1QixFQUFtdkIsVUFBbnZCLEVBQSt2QixtQkFBL3ZCLEVBQW94QixnQkFBcHhCLEVBQXN5QixVQUF0eUIsRUFBa3pCLG1CQUFsekIsRUFBdTBCLGdCQUF2MEIsRUFBeTFCLFVBQXoxQixFQUFxMkIsbUJBQXIyQixFQUEwM0IsZ0JBQTEzQixFQUE0NEIsVUFBNTRCLEVBQXc1QixtQkFBeDVCLEVBQTY2QixnQkFBNzZCLEVBQSs3QixVQUEvN0IsRUFBMjhCLG1CQUEzOEIsRUFBZytCLGdCQUFoK0IsRUFBay9CLFVBQWwvQixFQUE4L0IsbUJBQTkvQixFQUFtaEMsZ0JBQW5oQyxFQUFxaUMsV0FBcmlDLEVBQWtqQyxvQkFBbGpDLEVBQXdrQyxpQkFBeGtDLEVBQTJsQyxNQUEzbEMsRUFBbW1DLFdBQW5tQyxFQUFnbkMsU0FBaG5DLEVBQTJuQyxPQUEzbkMsRUFBb29DLGdCQUFwb0MsQ0FBYjtBQUNBLFlBQUlQLFNBQVNPLE9BQU9DLEdBQVAsQ0FBVzdNLEtBQU0sSUFBR0EsQ0FBRSxHQUF0QixFQUEwQjhNLElBQTFCLENBQStCLEdBQS9CLElBQXNDLElBQW5ELENBaENVLENBa0NWOztBQUNBUixlQUFPUyxhQUFQLEdBQThCQyxXQUFQLDZCQUF1QjtBQUM1Q3BMLGlCQUFPd0osU0FBUyxDQUFDLFVBQVU0QixXQUFYLEVBQXdCQyxLQUF4QixDQUE4QixDQUFDLENBQS9CLENBQWhCO0FBQ0FOLGVBQU0sR0FBRXRCLE9BQVEsSUFBR3pKLElBQUssRUFBeEI7QUFDQU4scUJBQVksR0FBRXFMLEVBQUcsSUFBRzdKLE9BQU9vSyxXQUFZLEVBQXZDO0FBQ0Esd0JBQU1wQyxRQUFRMEIsS0FBUixDQUFjRyxFQUFkLENBQU4sRUFKNEMsQ0FLNUM7O0FBQ0Esd0JBQU03QixRQUFRcUMsVUFBUixDQUFtQjdMLFFBQW5CLEVBQTZCeUosTUFBTXFDLE1BQU4sQ0FBYWYsTUFBYixFQUFxQixXQUFyQixDQUE3QixDQUFOO0FBQ0QsU0FQc0IsQ0FBdkIsQ0FuQ1UsQ0E0Q1Y7OztBQUNBQyxlQUFPZSxRQUFQLEdBQXlCQyxHQUFQLDZCQUFlO0FBQy9CLGNBQUlDLFFBQVFELElBQUlDLEtBQWhCO0FBQ0EsY0FBSWhFLE9BQU8rRCxJQUFJL0QsSUFBZixDQUYrQixDQUcvQjs7QUFDQSxjQUFJNUYsU0FBU2lKLE9BQU9DLEdBQVAsQ0FBVzdNLEtBQUs7QUFBRSxtQkFBT3VOLE1BQU12TixDQUFOLElBQVksSUFBR3VOLE1BQU12TixDQUFOLENBQVMsR0FBeEIsR0FBNkIsSUFBcEM7QUFBMEMsV0FBNUQsRUFBOEQ4TSxJQUE5RCxDQUFtRSxHQUFuRSxJQUEwRSxJQUF2RjtBQUNBLHdCQUFNaEMsUUFBUXFDLFVBQVIsQ0FBbUI3TCxRQUFuQixFQUE2QnlKLE1BQU1xQyxNQUFOLENBQWF6SixNQUFiLEVBQXFCLFdBQXJCLENBQTdCLENBQU4sRUFMK0IsQ0FNL0I7O0FBQ0EsZUFBSyxJQUFJNkosR0FBVCxJQUFnQmpFLEtBQUtrRSxNQUFyQixFQUE2QjtBQUMzQixnQkFBSUMsU0FBVSxHQUFFNUssT0FBT3JCLFFBQVMsSUFBRytMLEdBQUksRUFBdkM7QUFDQSxnQkFBSUcsU0FBVSxHQUFFaEIsRUFBRyxJQUFHYSxHQUFJLEVBQTFCOztBQUNBLGdCQUFJO0FBQ0Y7QUFDQSw0QkFBTTFDLFFBQVE4QyxNQUFSLENBQWVELE1BQWYsQ0FBTjtBQUNELGFBSEQsQ0FHRSxPQUFPMUgsQ0FBUCxFQUFVO0FBQ1YsNEJBQU02RSxRQUFRK0MsUUFBUixDQUFpQkgsTUFBakIsRUFBeUJDLE1BQXpCLENBQU47QUFDRDtBQUNGO0FBQ0YsU0FqQmlCLENBQWxCLENBN0NVLENBZ0VWOzs7QUFDQXJCLGVBQU93QixXQUFQLEdBQTRCZCxXQUFQLDZCQUF1QjtBQUMxQyxnQkFBTWUsTUFBTS9DLFNBQVMsS0FBVCxDQUFaO0FBQ0EsZ0JBQU1nRCxVQUFXLEdBQUV0QixTQUFVLElBQUc5SyxJQUFLLE1BQXJDO0FBQ0EsZ0JBQU1xTSxTQUFTbkQsUUFBUVksaUJBQVIsQ0FBMEJzQyxPQUExQixDQUFmO0FBQ0FELGNBQUlsQyxJQUFKLENBQVNvQyxNQUFUO0FBQ0FGLGNBQUlHLFNBQUosQ0FBY3ZCLEVBQWQsRUFBa0IsS0FBbEI7QUFDQW9CLGNBQUlJLFFBQUo7QUFDRCxTQVBvQixDQUFyQixDQWpFVSxDQTBFVjtBQUNBOzs7QUFFQSxZQUFJM0ssb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSUMseUJBQWlCTixlQUFlTyxRQUFmLENBQXdCSCxLQUFLSSxHQUE3QixDQUFqQixDQUFKLENBRGlDLENBRWpDOztBQUNBLGdCQUFJRixZQUFZRixLQUFLTSxJQUFMLENBQVUwRCxLQUFWLENBQWdCYSxXQUFoQyxFQUE2QztBQUMzQyxrQkFBSWIsc0JBQWNwRSxlQUFla0YsZ0JBQWYsQ0FBZ0N2TCxPQUFPL0MsT0FBdkMsRUFBZ0R3SixJQUFoRCxDQUFkLENBQUo7QUFDQSw0QkFBTStDLE9BQU9nQyxNQUFQLENBQWM7QUFBQ2YsdUJBQU9BLEtBQVI7QUFBZWhFLHNCQUFNQTtBQUFyQixlQUFkLENBQU47QUFDRDtBQUNGLFdBUFM7QUFGbUIsU0FBZixDQUFaLENBQUo7QUFXQStDLGVBQU9pQyxLQUFQO0FBRUEsZUFBTy9LLEdBQVA7QUFDRCxPQTNGRCxDQUZJLENBQU47QUErRkEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBcEdEO0FBQUE7O0FBNUNhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNsQkEvSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsK0JBQVIsQ0FBYjtBQUF1REYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBdkRGLE9BQU80TyxNQUFQLENBQWM7QUFBQ0MsV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSUMsS0FBSjtBQUFVOU8sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDNE8sUUFBTTFPLENBQU4sRUFBUTtBQUFDME8sWUFBTTFPLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFeEMsTUFBTXlPLFVBQVUsSUFBSUMsTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUErQjtBQUFDQyxnQkFBYTtBQUFkLENBQS9CLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDRlBoUCxPQUFPNE8sTUFBUCxDQUFjO0FBQUM3TCxVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJK0wsS0FBSjtBQUFVOU8sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDNE8sUUFBTTFPLENBQU4sRUFBUTtBQUFDME8sWUFBTTFPLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk2TyxJQUFKO0FBQVNqUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDNk8sV0FBSzdPLENBQUw7QUFBTzs7QUFBbkIsQ0FBN0IsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSThPLE9BQUo7QUFBWWxQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM4TyxjQUFROU8sQ0FBUjtBQUFVOztBQUF0QixDQUFwQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJK08sU0FBSjtBQUFjblAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDaVAsWUFBVS9PLENBQVYsRUFBWTtBQUFDK08sZ0JBQVUvTyxDQUFWO0FBQVk7O0FBQTFCLENBQWpDLEVBQTZELENBQTdEO0FBYW5aLE1BQU1nUCxVQUFVLElBQUlOLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBZ0M7QUFDOUNDLGdCQUFjO0FBRGdDLENBQWhDLENBQWhCOztBQUlPLE1BQU1qTSxNQUFOLFNBQXFCb00sU0FBckIsQ0FBK0I7QUFFcENFLGNBQVlDLFFBQVosRUFBc0I7QUFFcEIsUUFBSXRILFVBQVVvSCxRQUFRRyxPQUFSLENBQWdCO0FBQzVCeEYsV0FBS3VGO0FBRHVCLEtBQWhCLENBQWQ7QUFJQSxVQUFNdEgsT0FBTjtBQUVBLFFBQUlHLE9BQU8sS0FBS3FILE9BQUwsRUFBWDs7QUFFQSxZQUFRckgsS0FBS3NILElBQWI7QUFFRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSS9NLEtBQUosQ0FBVXdGLEtBQUsxRSxJQUFmLENBQWI7O0FBQ0EsYUFBS2tNLE1BQUwsR0FBYyxDQUFRQyxXQUFZN0wsTUFBRCxJQUFVLENBQUUsQ0FBL0IsRUFBaUM4TCxVQUFXeEosQ0FBRCxJQUFLLENBQUUsQ0FBbEQsOEJBQXdEO0FBQ3BFLGNBQUlyQyxNQUFPLGlCQUFnQm1FLEtBQUsySCxLQUFNLEVBQXRDO0FBQ0EsK0JBQWEsS0FBS0osS0FBTCxDQUFXSyxjQUFYLENBQTBCL0wsR0FBMUIsRUFBK0I0TCxRQUEvQixFQUF5Q0MsT0FBekMsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFFRjtBQUNFLGNBQU0sSUFBSUcsS0FBSixDQUFVLHVCQUFWLENBQU47QUFYSjtBQWNEO0FBRUQ7Ozs7OztBQUlNbk0sU0FBTixDQUFjb00sWUFBWSxFQUExQixFQUE4QkosVUFBaUJ4SixDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUF4QztBQUFBLG9DQUF5RDtBQUV2RCxVQUFJMkIsVUFBVSxLQUFLa0ksVUFBTCxFQUFkLENBRnVELENBSXZEOztBQUNBbEksY0FBUW1JLE9BQVIsQ0FBZ0JDLElBQWhCLENBQXFCO0FBQ25CWCxjQUFNLE1BRGE7QUFFbkI5TCxlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJME0sUUFBUSxFQUFaOztBQUNBLFdBQUssSUFBSWpOLE1BQVQsSUFBbUI0RSxRQUFRbUksT0FBM0IsRUFBb0M7QUFDbENFLGNBQU1qTixPQUFPcU0sSUFBYixJQUFxQjtBQUNuQjlMLGlCQUFPUCxPQUFPTyxLQURLO0FBRW5CME0saUJBQU87QUFGWSxTQUFyQjtBQUlEOztBQUVELG9CQUFNLEtBQUtWLE1BQUwsQ0FDRzVMLE1BQVAsNkJBQWdCO0FBQ2QsYUFBSyxJQUFJWCxNQUFULElBQW1CNEUsUUFBUW1JLE9BQTNCLEVBQW9DO0FBQ2xDLGNBQUl4TSxRQUFRdUwsUUFBUW9CLFFBQVIsQ0FBaUJsTixPQUFPTyxLQUF4QixDQUFaO0FBQ0EsY0FBSTRNLE9BQU90QixLQUFNdEwsS0FBTixDQUFYOztBQUNBLGNBQUk0TSxLQUFLeE0sTUFBTCxDQUFKLEVBQWtCO0FBQ2hCc00sa0JBQU1qTixPQUFPcU0sSUFBYixFQUFtQlksS0FBbkI7O0FBQ0EsZ0JBQUksT0FBT0osVUFBVTdNLE9BQU9xTSxJQUFqQixDQUFQLEtBQWtDLFdBQXRDLEVBQWtEO0FBQ2hELDRCQUFNUSxVQUFVN00sT0FBT3FNLElBQWpCLEVBQXVCMUwsTUFBdkIsQ0FBTjtBQUNEOztBQUNEO0FBQ0Q7QUFDRjtBQUNGLE9BWkQsQ0FESSxFQWNKOEwsT0FkSSxDQUFOLEVBbEJ1RCxDQW1DdkQ7O0FBQ0EsYUFBT1EsS0FBUDtBQUVELEtBdENEO0FBQUE7O0FBaENvQyxDOzs7Ozs7Ozs7OztBQ2pCdENyUSxPQUFPNE8sTUFBUCxDQUFjO0FBQUNPLGFBQVUsTUFBSUEsU0FBZjtBQUF5QnRNLFNBQU0sTUFBSUE7QUFBbkMsQ0FBZDtBQUF5RCxJQUFJaU0sS0FBSjtBQUFVOU8sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDNE8sUUFBTTFPLENBQU4sRUFBUTtBQUFDME8sWUFBTTFPLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBUW5OLE1BQU1vUSxTQUFTLElBQUkxQixNQUFNQyxVQUFWLENBQXFCLFFBQXJCLEVBQStCO0FBQzVDQyxnQkFBYztBQUQ4QixDQUEvQixDQUFmOztBQUlPLE1BQU1HLFNBQU4sQ0FBZ0I7QUFJckJFLGNBQVlySCxPQUFaLEVBQXFCO0FBQ25CLFNBQUtBLE9BQUwsR0FBZUEsT0FBZjtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQXdILFlBQVU7QUFDUixXQUFPLEtBQUt4SCxPQUFMLENBQWF5SSxZQUFwQjtBQUNEOztBQUVEUCxlQUFhO0FBQ1gsV0FBTyxLQUFLbEksT0FBWjtBQUNEOztBQUVEbkUsVUFBUTBJLFdBQWtCeEksTUFBUCw2QkFBa0IsQ0FBRSxDQUFwQixDQUFuQixFQUF5QzhMLFVBQWlCeEosQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBbkQsRUFBb0UsQ0FBRTs7QUFyQmpEOztBQXlCaEIsTUFBTXhELEtBQU4sU0FBb0JzTSxTQUFwQixDQUE4QjtBQUVuQ0UsY0FBWXFCLE9BQVosRUFBcUI7QUFFbkIsUUFBSTFJLFVBQVV3SSxPQUFPakIsT0FBUCxDQUFlO0FBQzNCeEYsV0FBSzJHO0FBRHNCLEtBQWYsQ0FBZDtBQUlBLFVBQU0xSSxPQUFOO0FBRUEsUUFBSUcsT0FBTyxLQUFLcUgsT0FBTCxFQUFYOztBQUVBLFlBQVFySCxLQUFLc0gsSUFBYjtBQUNFLFdBQUssT0FBTDtBQUNFLGFBQUtDLEtBQUwsR0FBYSxJQUFJL00sS0FBSixDQUFVd0YsS0FBSzFFLElBQWYsQ0FBYjs7QUFDQSxhQUFLa00sTUFBTCxHQUFxQjdOLEdBQVAsNkJBQWU7QUFDM0IsY0FBSWtDLE1BQU8saUJBQWdCbUUsS0FBSzJILEtBQU0sWUFBV2hPLElBQUk2TyxHQUFJLFNBQVE3TyxJQUFJMEUsRUFBRyxHQUF4RTtBQUNBLCtCQUFhLEtBQUtrSixLQUFMLENBQVcvTCxLQUFYLENBQWlCSyxHQUFqQixDQUFiO0FBQ0QsU0FIYSxDQUFkOztBQUlBOztBQUNGO0FBQ0UsY0FBTSxJQUFJZ00sS0FBSixDQUFVLG9CQUFWLENBQU47QUFUSjtBQVlEO0FBR0Q7Ozs7OztBQUlBbk0sVUFBUTBJLFdBQWtCeEksTUFBUCw2QkFBa0IsQ0FBRSxDQUFwQixDQUFuQixFQUF5QzhMLFVBQWlCeEosQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBbkQsRUFBb0U7QUFFbEUsUUFBSXVLLE1BQU1KLE9BQU9oSSxJQUFQLENBQVk7QUFDcEJrSSxlQUFTLEtBQUsxSSxPQUFMLENBQWErQjtBQURGLEtBQVosRUFFUDtBQUNEaUQsY0FBUTtBQUNOakQsYUFBSyxDQURDO0FBRU52RCxZQUFJLENBRkU7QUFHTm1LLGFBQUs7QUFIQztBQURQLEtBRk8sQ0FBVjtBQVVBLFdBQU8sSUFBSUUsT0FBSixDQUNMLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUVuQkgsVUFBSUksT0FBSixDQUNFLENBQU9sUCxHQUFQLEVBQVltUCxLQUFaLDhCQUFzQjtBQUNwQixZQUFJO0FBQ0YsY0FBSWxOLHVCQUFlLEtBQUs0TCxNQUFMLENBQVk3TixHQUFaLENBQWYsQ0FBSjtBQUNBLHdCQUFNeUssU0FBU3hJLE1BQVQsQ0FBTjtBQUNELFNBSEQsQ0FHRSxPQUFPc0MsQ0FBUCxFQUFVO0FBQ1Z3SixrQkFBUXhKLENBQVI7QUFDRDs7QUFDRCxZQUFJNEssUUFBUSxDQUFSLEtBQWNMLElBQUlQLEtBQUosRUFBbEIsRUFBK0I7QUFDN0JTO0FBQ0Q7QUFDRixPQVZELENBREY7QUFhRCxLQWhCSSxFQWlCTEksS0FqQkssQ0FrQko3SyxDQUFELElBQU87QUFDTCxZQUFNQSxDQUFOO0FBQ0QsS0FwQkksQ0FBUDtBQXVCRDs7QUFsRWtDLEM7Ozs7Ozs7Ozs7O0FDckNyQ3JHLE9BQU80TyxNQUFQLENBQWM7QUFBQ3JPLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUl1TyxLQUFKO0FBQVU5TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM0TyxRQUFNMU8sQ0FBTixFQUFRO0FBQUMwTyxZQUFNMU8sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUV4QyxNQUFNRyxVQUFVLElBQUl1TyxNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQStCO0FBQUNDLGdCQUFhO0FBQWQsQ0FBL0IsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNGUGhQLE9BQU80TyxNQUFQLENBQWM7QUFBQ3ZGLFlBQVMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUkxRyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFOztBQUUxQyxNQUFNaUosUUFBTixDQUFlO0FBQ3BCZ0csY0FBYUssUUFBUSxJQUFJL00sS0FBSixFQUFyQixFQUFrQztBQUNoQyxTQUFLd08sTUFBTCxHQUFjekIsS0FBZDtBQUNEOztBQUVLMUYsYUFBTixDQUFtQm9ILGNBQW5CLEVBQW1DdkgsV0FBVyxDQUE5QztBQUFBLG9DQUFpRDtBQUMvQyxvQkFBTSxLQUFLc0gsTUFBTCxDQUFZRSxXQUFaLENBQ0osbUJBREksRUFFSCxzQkFBcUJELGNBQWUsRUFGakMsRUFHSixFQUhJLEVBR0E7QUFDRkUsZUFBT3pILFFBREw7QUFFRjBILHlCQUFpQixDQUZmO0FBR0ZyTCxxQkFBYTtBQUhYLE9BSEEsQ0FBTjtBQVVBLG9CQUFNLEtBQUtpTCxNQUFMLENBQVlFLFdBQVosQ0FDSixtQkFESSxFQUVILHNCQUFxQkQsY0FBZSxFQUZqQyxFQUdKLEVBSEksRUFHQTtBQUNGRSxlQUFPekgsUUFETDtBQUVGM0QscUJBQWE7QUFGWCxPQUhBLENBQU47QUFRRCxLQW5CRDtBQUFBOztBQXFCTTZFLGtCQUFOLENBQXdCdkosSUFBeEI7QUFBQSxvQ0FBOEI7QUFDNUIsVUFBSWdRLFlBQVloUSxLQUFLK0ksVUFBckI7QUFFQSxVQUFJM0csTUFBTSxFQUFWLENBSDRCLENBSzVCOztBQUNBLFVBQUk2TixTQUFnQnpPLEdBQVAsNkJBQWU7QUFDMUIsWUFBSWdCLE1BQU87OzJCQUVVeEMsS0FBS2tRLFVBQVcsY0FBYTFPLEdBQUk7T0FGdEQ7QUFJQVksWUFBSXdNLElBQUosZUFBZSxLQUFLZSxNQUFMLENBQVl4TixLQUFaLENBQWtCSyxHQUFsQixDQUFmO0FBQ0QsT0FOWSxDQUFiLENBTjRCLENBYzVCOzs7QUFDQSxVQUFJMk4sUUFBZTNPLEdBQVAsNkJBQWU7QUFDekI7QUFDQSxZQUFJZ0IsTUFBTzs7MkJBRVV4QyxLQUFLa1EsVUFBVyxjQUFhMU8sR0FBSTtPQUZ0RDtBQUlBLFlBQUk0Tyx5QkFBaUIsS0FBS1QsTUFBTCxDQUFZeE4sS0FBWixDQUFrQkssR0FBbEIsQ0FBakIsQ0FBSjtBQUNBLFlBQUk0TixTQUFTLENBQVQsRUFBWSxVQUFaLENBQUosRUFBNkI7QUFFN0JoTyxZQUFJd00sSUFBSixlQUNRLEtBQUtlLE1BQUwsQ0FBWS9LLFdBQVosQ0FDSixpQkFESSxFQUVKLEVBRkksRUFHSjtBQUNFc0wsc0JBQVlsUSxLQUFLa1EsVUFEbkI7QUFFRTFPLGVBQUtBLEdBRlA7QUFHRXVILHNCQUFZaUgsU0FIZDtBQUlFdkwsdUJBQWE7QUFKZixTQUhJLENBRFI7QUFXRCxPQXBCVyxDQUFaOztBQXNCQSxXQUFLLElBQUk0TCxNQUFULElBQW1CclEsS0FBS3NRLElBQXhCLEVBQThCO0FBQzVCLGdCQUFRRCxPQUFPRSxHQUFmO0FBQ0UsZUFBSyxJQUFMO0FBQ0UsMEJBQU1KLE1BQU1FLE9BQU83TyxHQUFiLENBQU47QUFDQTs7QUFDRixlQUFLLEtBQUw7QUFDRSwwQkFBTXlPLE9BQU9JLE9BQU83TyxHQUFkLENBQU47QUFDQTtBQU5KO0FBUUQ7O0FBRUQsYUFBTztBQUNMWSxhQUFLQTtBQURBLE9BQVA7QUFHRCxLQW5ERDtBQUFBOztBQXFETWlILG9CQUFOLENBQTBCckosSUFBMUI7QUFBQSxvQ0FBZ0M7QUFDOUIsVUFBSXdRLFlBQVl4USxLQUFLa1EsVUFBckI7QUFDQSxVQUFJN0QsU0FBU3JNLEtBQUtxTSxNQUFsQjtBQUNBLFVBQUkyRCxZQUFZaFEsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVixDQUw4QixDQU85Qjs7QUFDQSxVQUFJSSxNQUFPLG9EQUFtRGdPLFNBQVUsRUFBeEU7QUFDQXBPLFVBQUl3TSxJQUFKLGVBQWUsS0FBS2UsTUFBTCxDQUFZeE4sS0FBWixDQUFrQkssR0FBbEIsQ0FBZixHQVQ4QixDQVc5Qjs7QUFDQSxXQUFLLElBQUlnSSxJQUFJLENBQWIsRUFBZ0JBLElBQUk2QixPQUFPb0UsTUFBM0IsRUFBbUNqRyxHQUFuQyxFQUF3QztBQUN0QyxzQkFBTSxLQUFLbUYsTUFBTCxDQUFZL0ssV0FBWixDQUNKLG1CQURJLEVBQ2lCO0FBQ25Cc0wsc0JBQVlNLFNBRE87QUFFbkJ6SCxzQkFBWWlILFNBRk87QUFHbkJVLHFCQUFXckUsT0FBTzdCLENBQVAsQ0FIUTtBQUluQm1HLGdCQUFNbkcsSUFBSTtBQUpTLFNBRGpCLEVBTUQ7QUFDRC9GLHVCQUFhO0FBRFosU0FOQyxDQUFOO0FBVUQ7O0FBRUQsYUFBTztBQUNMckMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0E1QkQ7QUFBQTs7QUE4Qk1rSCxlQUFOLENBQXFCdEosSUFBckI7QUFBQSxvQ0FBMkI7QUFDekIsVUFBSTRRLGFBQWEsRUFBakI7QUFDQSxVQUFJQyxPQUFPLEVBQVgsQ0FGeUIsQ0FJekI7O0FBRUFBLGFBQU8sQ0FDTCxRQURLLEVBRUwsTUFGSyxFQUdMLE1BSEssRUFJTCxrQkFKSyxFQUtMLG9CQUxLLEVBTUwsYUFOSyxFQU9MLFdBUEssQ0FBUDs7QUFTQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRCxvQkFBTSxLQUFLbkIsTUFBTCxDQUFZRSxXQUFaLENBQ0osYUFESSxFQUVILGdCQUFlN1AsS0FBS2tRLFVBQVcsRUFGNUIsRUFHSlUsVUFISSxFQUdRO0FBQ1ZsTSxxQkFBYTtBQURILE9BSFIsQ0FBTixFQW5CeUIsQ0EyQnpCOztBQUVBa00sbUJBQWEsRUFBYjtBQUNBQyxhQUFPLENBQ0wsa0JBREssRUFFTCxjQUZLLEVBR0wsWUFISyxFQUlMLFNBSkssRUFLTCxTQUxLLEVBTUwsY0FOSyxDQUFQOztBQVFBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVELFVBQUkxTyxvQkFBWSxLQUFLdU4sTUFBTCxDQUFZRSxXQUFaLENBQ2QsbUJBRGMsRUFFYixnQkFBZTdQLEtBQUtrUSxVQUFXLEVBRmxCLEVBR2RVLFVBSGMsRUFHRjtBQUNWbE0scUJBQWE7QUFESCxPQUhFLENBQVosQ0FBSjtBQVFBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBckREO0FBQUE7O0FBdURNNkcsZUFBTixDQUFxQmpKLElBQXJCO0FBQUEsb0NBQTJCO0FBQ3pCLFVBQUlnUSxZQUFZaFEsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVjtBQUVBLFVBQUl3TyxhQUFhLEVBQWpCO0FBQ0EsVUFBSUMsT0FBTyxFQUFYO0FBRUFBLGFBQU8sQ0FDTCxNQURLLEVBRUwsb0JBRkssQ0FBUCxDQVJ5QixDQVl6QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRDFPLFVBQUk4TixVQUFKLGlCQUF1QixLQUFLUCxNQUFMLENBQVkvSyxXQUFaLENBQ3JCLGFBRHFCLEVBRXJCZ00sVUFGcUIsRUFFVDtBQUNWN0gsb0JBQVlpSCxTQURGO0FBRVZ0TixnQkFBUSxDQUZFO0FBR1Y4QixjQUFNLE1BSEk7QUFJVnVNLDBCQUFrQixNQUpSO0FBS1ZDLHFCQUFhLE1BTEg7QUFNVkMsbUJBQVcsTUFORDtBQU9WeE0scUJBQWEsT0FQSDtBQVFWQyxxQkFBYTtBQVJILE9BRlMsQ0FBdkI7QUFjQWtNLG1CQUFhLEVBQWI7QUFDQUMsYUFBTyxDQUNMLGNBREssRUFFTCxpQkFGSyxFQUdMLFNBSEssRUFJTCxTQUpLLEVBS0wsY0FMSyxDQUFQLENBcEN5QixDQTJDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRDFPLFVBQUl1RyxnQkFBSixpQkFBNkIsS0FBS2dILE1BQUwsQ0FBWS9LLFdBQVosQ0FDM0IsbUJBRDJCLEVBRTNCZ00sVUFGMkIsRUFFZjtBQUNWN0gsb0JBQVlpSCxTQURGO0FBRVZFLG9CQUFZOU4sSUFBSThOLFVBRk47QUFHVkosZUFBTyxDQUhHO0FBSVZDLHlCQUFpQixDQUpQO0FBS1ZtQiw0QkFBb0IsTUFMVjtBQU1WQyw0QkFBb0IsTUFOVjtBQU9WQywwQkFBa0IsTUFQUjtBQVFWQyxvQkFBWSxNQVJGO0FBU1Y1TSxxQkFBYSxPQVRIO0FBVVZDLHFCQUFhO0FBVkgsT0FGZSxDQUE3Qjs7QUFnQkEsV0FBSyxJQUFJb00sQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVEMU8sVUFBSWtQLGdCQUFKLGlCQUE2QixLQUFLM0IsTUFBTCxDQUFZL0ssV0FBWixDQUMzQixtQkFEMkIsRUFDTixFQURNLEVBQ0Y7QUFDdkIrRCwwQkFBa0J2RyxJQUFJdUcsZ0JBREM7QUFFdkJJLG9CQUFZaUgsU0FGVztBQUd2QkYsZUFBTyxDQUhnQjtBQUl2QnJMLHFCQUFhLE9BSlU7QUFLdkJDLHFCQUFhO0FBTFUsT0FERSxDQUE3QixFQXpFeUIsQ0FtRnpCOztBQUNBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBdkZEO0FBQUE7O0FBcEtvQixDOzs7Ozs7Ozs7OztBQ0Z0QjVELE9BQU80TyxNQUFQLENBQWM7QUFBQ21FLG1CQUFnQixNQUFJQSxlQUFyQjtBQUFxQ0MsWUFBUyxNQUFJQSxRQUFsRDtBQUEyREMsaUJBQWMsTUFBSUEsYUFBN0U7QUFBMkY3SixpQkFBYyxNQUFJQTtBQUE3RyxDQUFkO0FBQTJJLElBQUkwRixLQUFKO0FBQVU5TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM0TyxRQUFNMU8sQ0FBTixFQUFRO0FBQUMwTyxZQUFNMU8sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSThTLFdBQUo7QUFBZ0JsVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNnVCxjQUFZOVMsQ0FBWixFQUFjO0FBQUM4UyxrQkFBWTlTLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSTZPLElBQUo7QUFBU2pQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM2TyxXQUFLN08sQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJOE8sT0FBSjtBQUFZbFAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzhPLGNBQVE5TyxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEOztBQVMxZixNQUFNMlMsZUFBTixDQUFzQjtBQUMzQjFELGNBQWFsSCxJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixRQUFJbUwsUUFBSjs7QUFDQSxZQUFRaEwsS0FBS3NILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRTBELG1CQUFXLElBQUlGLGFBQUosQ0FBa0I5SyxJQUFsQixFQUF3QkgsT0FBeEIsQ0FBWDtBQUZKOztBQUtBLFdBQU9tTCxRQUFQO0FBQ0Q7O0FBVDBCOztBQVl0QixNQUFNSCxRQUFOLENBQWU7QUFDcEIzRCxjQUFhbEgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsU0FBS0csSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS0gsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7O0FBRUQsU0FBT29MLE9BQVAsQ0FBZ0JqTCxJQUFoQixFQUFzQkgsT0FBdEIsRUFBK0I7QUFDN0IsWUFBUUcsS0FBS3NILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxlQUFPLElBQUl3RCxhQUFKLENBQWtCOUssSUFBbEIsRUFBd0JILE9BQXhCLENBQVA7O0FBQ0Y7QUFDRSxjQUFNLElBQUlnSSxLQUFKLENBQVUsbUJBQVYsQ0FBTjtBQUpKO0FBTUQ7O0FBRURxRCxhQUFZO0FBQ1YsV0FBTyxLQUFLbEwsSUFBWjtBQUNEOztBQUVEbUwsYUFBWTtBQUNWLFdBQU8sS0FBS25MLElBQUwsQ0FBVTFFLElBQWpCO0FBQ0Q7O0FBRUQ4UCxnQkFBZTtBQUNiLFdBQU8sS0FBS3ZMLE9BQVo7QUFDRDs7QUFFRHdMLHFCQUNFQyxLQUFLLENBQU83RCxXQUFXN0wsVUFBVSxDQUFFLENBQTlCLEVBQWdDOEwsVUFBVXhKLEtBQUssQ0FBRSxDQUFqRCw4QkFBc0QsQ0FBRSxDQUF4RCxDQURQLEVBRUU7QUFDQSxTQUFLc0osTUFBTCxHQUFjOEQsRUFBZDtBQUNEO0FBRUQ7Ozs7Ozs7Ozs7O0FBU001UCxTQUFOLENBQWU2UCxZQUFZLEVBQTNCO0FBQUEsb0NBQStCO0FBQzdCLFVBQUkxTCxVQUFVLEtBQUt1TCxXQUFMLEVBQWQsQ0FENkIsQ0FHN0I7O0FBQ0F2TCxjQUFRbUksT0FBUixDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJwTyxjQUFNLE1BRGE7QUFFbkIyQixlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJZ1EsVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSUMsQ0FBVCxJQUFjNUwsUUFBUW1JLE9BQXRCLEVBQStCLENBQzlCOztBQUVELFVBQUlBLFVBQVUsRUFBZDs7QUFFQSxXQUFLLElBQUl5RCxDQUFULElBQWM1TCxRQUFRbUksT0FBdEIsRUFBK0I7QUFDN0J3RCxnQkFBUUMsRUFBRTVSLElBQVYsSUFBa0I7QUFDaEIyQixpQkFBT2lRLEVBQUVqUSxLQURPO0FBRWhCa1EsaUJBQU8sT0FBT0QsRUFBRUMsS0FBVCxLQUFtQixXQUFuQixHQUFpQ0QsRUFBRUMsS0FBbkMsR0FBMkMsQ0FGbEM7QUFHaEJ4RCxpQkFBTztBQUhTLFNBQWxCO0FBS0FGLGdCQUFRQyxJQUFSLENBQ0U7QUFDRXBPLGdCQUFNNFIsRUFBRTVSLElBRFY7QUFFRXVPLGdCQUFNdEIsS0FBS0MsUUFBUW9CLFFBQVIsQ0FBaUJzRCxFQUFFalEsS0FBbkIsQ0FBTDtBQUZSLFNBREY7QUFNRDs7QUFFRCxvQkFBTSxLQUFLZ00sTUFBTCxDQUNKLENBQU81TCxNQUFQLEVBQWU2RixPQUFmLDhCQUEyQjtBQUN6QixhQUFLLElBQUlnSyxDQUFULElBQWN6RCxPQUFkLEVBQXVCO0FBQ3JCO0FBQ0EsY0FBSTJELElBQUlILFFBQVFDLEVBQUU1UixJQUFWLENBQVI7O0FBQ0EsY0FBSThSLEVBQUVELEtBQU4sRUFBYTtBQUNYLGdCQUFJQyxFQUFFekQsS0FBRixJQUFXeUQsRUFBRUQsS0FBakIsRUFBd0I7QUFDdEI7QUFDRDtBQUNGOztBQUVELGNBQUlELEVBQUVyRCxJQUFGLENBQU94TSxNQUFQLENBQUosRUFBb0I7QUFDbEI7QUFDQStQLGNBQUV6RCxLQUFGLEdBRmtCLENBSWxCOztBQUNBLGdCQUFJLE9BQU9xRCxVQUFVRSxFQUFFNVIsSUFBWixDQUFQLEtBQTZCLFdBQWpDLEVBQThDO0FBQzVDLDRCQUFNMFIsVUFBVUUsRUFBRTVSLElBQVosRUFBa0IrQixNQUFsQixFQUEwQjZGLE9BQTFCLENBQU47QUFDRDs7QUFDRDtBQUNEO0FBQ0Y7QUFDRixPQXJCRCxDQURJLENBQU4sRUE3QjZCLENBcUQ3Qjs7QUFDQSxhQUFPK0osT0FBUDtBQUNELEtBdkREO0FBQUE7O0FBMUNvQjs7QUFvR2YsTUFBTVYsYUFBTixTQUE0QkQsUUFBNUIsQ0FBcUM7QUFDMUMzRCxjQUFhbEgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTUcsSUFBTixFQUFZSCxPQUFaO0FBRUEsUUFBSXZFLE9BQU8sS0FBSzZQLFFBQUwsRUFBWDtBQUVBLFNBQUs1RCxLQUFMLEdBQWEsSUFBSS9NLEtBQUosQ0FBVWMsSUFBVixDQUFiO0FBQ0EsU0FBSytQLGtCQUFMLENBQXdCLENBQU81RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQsVUFBSTdMLE1BQU8saUJBQWdCbUUsS0FBSzJILEtBQU0sRUFBdEM7QUFDQSxVQUFJbE0sb0JBQVksS0FBSzhMLEtBQUwsQ0FBV0ssY0FBWCxDQUEwQi9MLEdBQTFCLEVBQStCNEwsUUFBL0IsRUFBMEN2SixDQUFELElBQU87QUFBRSxjQUFNQSxDQUFOO0FBQVMsT0FBM0QsQ0FBWixDQUFKO0FBQ0EsYUFBT3pDLEdBQVA7QUFDRCxLQUp1QixDQUF4QjtBQUtEOztBQVp5Qzs7QUFtQnJDLE1BQU13RixhQUFOLFNBQTRCNEosUUFBNUIsQ0FBcUM7QUFDMUMzRCxjQUFhbEgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTUcsSUFBTixFQUFZSCxPQUFaLEVBRDBCLENBRzFCOztBQUNBLFNBQUt3TCxrQkFBTCxDQUF3QixDQUFPNUQsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBQ25ELFVBQUlrRSxNQUFKO0FBQ0FBLDZCQUFlYixZQUFZYyxPQUFaLENBQW9CN0wsS0FBSzhMLEdBQXpCLENBQWYsRUFGbUQsQ0FJbkQ7O0FBQ0EsVUFBSWhNLEtBQUs4TCxPQUFPOUwsRUFBUCxDQUFVRSxLQUFLK0wsUUFBZixDQUFUO0FBQ0EsVUFBSTNMLGFBQWFOLEdBQUdNLFVBQUgsQ0FBY0osS0FBS0ksVUFBbkIsQ0FBakI7QUFFQSxVQUFJcUIsVUFBVTtBQUNabUssZ0JBQVFBLE1BREk7QUFFWnhMLG9CQUFZQSxVQUZBO0FBR1oyTCxrQkFBVWpNO0FBSEUsT0FBZDtBQU1BLFVBQUkySSxNQUFNckksV0FBV0MsSUFBWCxFQUFWLENBZG1ELENBZ0JuRDs7QUFDQW9JLFVBQUl1RCxhQUFKLENBQWtCLGlCQUFsQixFQUFxQyxJQUFyQyxFQWpCbUQsQ0FtQm5EOztBQUNBLFVBQUk7QUFDRiw2QkFBYXZELElBQUl3RCxPQUFKLEVBQWIsR0FBNEI7QUFDMUIsY0FBSXRTLG9CQUFZOE8sSUFBSXlELElBQUosRUFBWixDQUFKO0FBQ0Esd0JBQU16RSxTQUFTOU4sR0FBVCxFQUFjOEgsT0FBZCxDQUFOO0FBQ0Q7O0FBQUE7QUFDRixPQUxELFNBS1U7QUFDUjtBQUNBLHNCQUFNZ0gsSUFBSWpDLEtBQUosRUFBTjtBQUNEO0FBQ0YsS0E3QnVCLENBQXhCO0FBOEJEOztBQW5DeUMsQzs7Ozs7Ozs7Ozs7QUM1STVDM08sT0FBTzRPLE1BQVAsQ0FBYztBQUFDek8sV0FBUSxNQUFJd0k7QUFBYixDQUFkO0FBQTRDLElBQUlULGVBQUo7QUFBb0JsSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNnSSxrQkFBZ0I5SCxDQUFoQixFQUFrQjtBQUFDOEgsc0JBQWdCOUgsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXRDLEVBQThFLENBQTlFO0FBQWlGLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBOUMsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWtVLFFBQUo7QUFBYXRVLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ29VLFdBQVNsVSxDQUFULEVBQVc7QUFBQ2tVLGVBQVNsVSxDQUFUO0FBQVc7O0FBQXhCLENBQTdCLEVBQXVELENBQXZEO0FBQTBELElBQUltVSxRQUFKO0FBQWF2VSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDbVUsZUFBU25VLENBQVQ7QUFBVzs7QUFBdkIsQ0FBckMsRUFBOEQsQ0FBOUQ7O0FBVzNTLE1BQU11SSxjQUFOLENBQXFCO0FBQzVCSyxNQUFOLENBQVliLElBQVo7QUFBQSxvQ0FBa0I7QUFDaEIsV0FBS3FNLEtBQUwsaUJBQW1CdE0sZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEIsT0FBMUIsQ0FBbkI7QUFDQSxXQUFLc00sUUFBTCxpQkFBc0J2TSxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQixVQUExQixDQUF0QjtBQUNELEtBSEQ7QUFBQTs7QUFLTTJCLFVBQU4sQ0FBZ0I0SyxNQUFoQjtBQUFBLG9DQUF3QjtBQUN0QixVQUFJQyx3QkFBZ0IsS0FBS0gsS0FBTCxDQUFXakYsT0FBWCxDQUFtQjtBQUNyQ3hGLGFBQUsySztBQURnQyxPQUFuQixFQUVqQjtBQUNEdE0sb0JBQVk7QUFDVixxQkFBVztBQUREO0FBRFgsT0FGaUIsQ0FBaEIsQ0FBSjtBQU9BLFVBQUl3TSxjQUFjRCxRQUFRRSxPQUExQixDQVJzQixDQVV0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQUlDLGFBQWEsRUFBakI7O0FBRUEsV0FBSyxJQUFJQyxVQUFULElBQXVCSCxXQUF2QixFQUFvQztBQUNsQyxZQUFJSSxjQUFjLENBQWxCOztBQUVBLGFBQUssSUFBSWhELFNBQVQsSUFBc0IrQyxVQUF0QixFQUFrQztBQUNoQyxjQUFJSix3QkFBZ0IsS0FBS0YsUUFBTCxDQUFjbEYsT0FBZCxDQUFzQjtBQUN4Q3hGLGlCQUFLaUk7QUFEbUMsV0FBdEIsRUFFakI7QUFDRDVKLHdCQUFZO0FBQ1YsdUJBQVM7QUFEQztBQURYLFdBRmlCLENBQWhCLENBQUo7QUFPQSxjQUFJNk0sYUFBYU4sUUFBUXJELEtBQXpCLENBUmdDLENBVWhDOztBQUNBLGVBQUssSUFBSUEsS0FBVCxJQUFrQjJELFVBQWxCLEVBQThCO0FBQzVCRCwyQkFBZTFELE1BQU16SCxRQUFyQjtBQUNEO0FBQ0Y7O0FBRURpTCxtQkFBVzFFLElBQVgsQ0FBZ0I0RSxXQUFoQjtBQUNELE9BdENxQixDQXdDdEI7OztBQUNBLFVBQUluTCxXQUFXcUwsS0FBS0MsR0FBTCxDQUFTQyxLQUFULENBQWUsSUFBZixFQUFxQk4sVUFBckIsQ0FBZjtBQUVBLGFBQU9qTCxRQUFQO0FBQ0QsS0E1Q0Q7QUFBQTtBQThDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQk1YLFVBQU4sQ0FBZ0I3SCxRQUFoQixFQUEwQnVILEtBQTFCLEVBQWlDQyxTQUFTLElBQTFDLEVBQWdEQyxTQUFTLElBQXpEO0FBQUEsb0NBQStEO0FBQzdEO0FBQ0EsVUFBSStFLFNBQVN0TixRQUFRaUksSUFBUixDQUFhO0FBQ3hCbkgsa0JBQVVBO0FBRGMsT0FBYixFQUVWZ1UsS0FGVSxHQUVGcEksR0FGRSxDQUVHN00sQ0FBRCxJQUFPQSxFQUFFNkIsZ0JBRlgsQ0FBYixDQUY2RCxDQU03RDs7QUFDQSxVQUFJbUIsU0FBUyxFQUFiO0FBQ0FBLGFBQU93RixLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQVl6RixPQUFPa1MsWUFBUCxHQUFzQnpNLE1BQXRCO0FBQ1osVUFBSUMsTUFBSixFQUFZMUYsT0FBT21TLFlBQVAsR0FBc0J6TSxNQUF0QjtBQUVaLFVBQUlsRixvQkFBWSxLQUFLNFEsS0FBTCxDQUFXZ0IsVUFBWCxDQUNkcFMsTUFEYyxFQUNOO0FBQ05xUyxlQUFPO0FBQ0w1SCxrQkFBUTtBQUNONkgsbUJBQU83SDtBQUREO0FBREg7QUFERCxPQURNLENBQVosQ0FBSixDQVo2RCxDQXNCN0Q7O0FBQ0EsYUFBT0EsTUFBUDtBQUNELEtBeEJEO0FBQUE7QUEwQkE7Ozs7Ozs7Ozs7QUFRTTFFLFlBQU4sQ0FBa0JQLEtBQWxCLEVBQXlCQyxTQUFTLElBQWxDLEVBQXdDQyxTQUFTLElBQWpEO0FBQUEsb0NBQXVEO0FBQ3JEO0FBQ0EsVUFBSTFGLFNBQVMsRUFBYjtBQUNBQSxhQUFPd0YsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFZekYsT0FBT2tTLFlBQVAsR0FBc0J6TSxNQUF0QjtBQUNaLFVBQUlDLE1BQUosRUFBWTFGLE9BQU9tUyxZQUFQLEdBQXNCek0sTUFBdEI7QUFFWixVQUFJbEYsb0JBQVksS0FBSzRRLEtBQUwsQ0FBV2dCLFVBQVgsQ0FDZHBTLE1BRGMsRUFDTjtBQUNOdUgsY0FBTTtBQUNKa0Qsa0JBQVE7QUFESjtBQURBLE9BRE0sQ0FBWixDQUFKO0FBT0QsS0FkRDtBQUFBO0FBZ0JBOzs7Ozs7Ozs7Ozs7Ozs7O0FBY004SCxjQUFOLENBQW9CaE0sSUFBcEIsRUFBMEJnTCxPQUExQjtBQUFBLG9DQUFtQztBQUNqQzs7Ozs7Ozs7QUFRQSxVQUFJNUMsTUFBTSxDQUFDO0FBQ1Q2RCxlQUFPLE1BREU7QUFFVEMsaUJBQVNsTSxLQUFLbU0sUUFGTDtBQUdUbkIsaUJBQVM7QUFDUG9CLGlCQUFPO0FBREEsU0FIQTtBQU1UcFMsZUFBTztBQUNMMlIsd0JBQWMzTCxLQUFLMkwsWUFEZDtBQUVMQyx3QkFBYzVMLEtBQUs0TDtBQUZkO0FBTkUsT0FBRCxFQVdWO0FBQ0VLLGVBQU9qTSxLQUFLcU0sV0FEZDtBQUVFSCxpQkFBU2xNLEtBQUsyTCxZQUZoQjtBQUdFWCxpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUVwUyxlQUFPO0FBQ0xtUyxvQkFBVW5NLEtBQUttTSxRQURWO0FBRUxQLHdCQUFjNUwsS0FBSzRMO0FBRmQ7QUFOVCxPQVhVLEVBc0JWO0FBQ0VLLGVBQU9qTSxLQUFLc00sV0FEZDtBQUVFSixpQkFBU2xNLEtBQUs0TCxZQUZoQjtBQUdFWixpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUVwUyxlQUFPO0FBQ0xtUyxvQkFBVW5NLEtBQUttTSxRQURWO0FBRUxSLHdCQUFjM0wsS0FBSzJMO0FBRmQ7QUFOVCxPQXRCVSxDQUFWO0FBbUNBLFVBQUlZLFFBQVEsRUFBWjs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY3BFLEdBQWQsRUFBbUI7QUFDakJtRSxjQUFNOUYsSUFBTixDQUFXO0FBQ1RnRyxvQ0FBa0IsS0FBSzVCLEtBQUwsQ0FBVzlMLFNBQVgsQ0FDaEIsQ0FBQztBQUNDMk4sb0JBQVFDLE9BQU9DLE1BQVAsQ0FBY0osRUFBRXhTLEtBQWhCLEVBQXVCO0FBQzdCaUYscUJBQU9lLEtBQUtmO0FBRGlCLGFBQXZCO0FBRFQsV0FBRCxFQUtBO0FBQ0U0TixzQkFBVUYsT0FBT0MsTUFBUCxDQUFjSixFQUFFeEIsT0FBaEIsRUFBeUJBLE9BQXpCO0FBRFosV0FMQSxFQVFBO0FBQ0U4QixtQkFBTztBQUNMMU0sbUJBQUs7QUFEQTtBQURULFdBUkEsQ0FEZ0IsRUFlaEJ0QixPQWZnQixFQUFsQixDQURTO0FBaUJUaU8saUJBQU9QO0FBakJFLFNBQVg7QUFtQkQ7O0FBRUQsYUFBT0QsS0FBUDtBQUNELEtBckVEO0FBQUEsR0F6SWtDLENBZ05sQztBQUNBOzs7QUFDTTFKLGVBQU4sQ0FBcUJrQixHQUFyQjtBQUFBLG9DQUEwQjtBQUN4QixVQUFJL0QsSUFBSixDQUR3QixDQUV4Qjs7QUFDQSxVQUFJLE9BQU8rRCxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0IsWUFBSWlKLE1BQU0sSUFBSUMsTUFBSixDQUFZLEdBQUVsSixHQUFJLEdBQWxCLENBQVY7QUFDQSxZQUFJa0QsTUFBTSxLQUFLNEQsS0FBTCxDQUFXaE0sSUFBWCxDQUFnQixFQUFoQixFQUFvQjtBQUM1Qkosc0JBQVk7QUFDVlEsbUJBQU8sQ0FERztBQUVWME0sMEJBQWMsQ0FGSjtBQUdWQywwQkFBYztBQUhKO0FBRGdCLFNBQXBCLENBQVY7O0FBUUEsZUFBTyxDQUFQLEVBQVU7QUFDUixjQUFJO0FBQ0Y1TCxpQ0FBYWlILElBQUl5RCxJQUFKLEVBQWI7QUFDQSxnQkFBSXdDLHNCQUFjbE4sS0FBS0ksR0FBTCxDQUFTK00sV0FBVCxHQUF1QkQsS0FBdkIsQ0FBNkJGLEdBQTdCLENBQWQsQ0FBSjs7QUFDQSxnQkFBSUUsS0FBSixFQUFXO0FBQ1Q7QUFDRDtBQUNGLFdBTkQsQ0FNRSxPQUFPeFEsQ0FBUCxFQUFVO0FBQ1Y7QUFDQSxtQkFBT3FILEdBQVA7QUFDRDtBQUNGO0FBQ0YsT0F0QkQsTUFzQk87QUFDTC9ELGVBQU8rRCxHQUFQO0FBQ0Q7O0FBRUQsVUFBSXFKLGFBQWEsRUFBakI7QUFDQSxVQUFJcE4sS0FBS2YsS0FBVCxFQUFnQm1PLFdBQVczRyxJQUFYLENBQWdCekcsS0FBS2YsS0FBckI7QUFDaEIsVUFBSWUsS0FBSzJMLFlBQVQsRUFBdUJ5QixXQUFXM0csSUFBWCxDQUFnQnpHLEtBQUsyTCxZQUFyQjtBQUN2QixVQUFJM0wsS0FBSzRMLFlBQVQsRUFBdUJ3QixXQUFXM0csSUFBWCxDQUFnQnpHLEtBQUs0TCxZQUFyQjtBQUN2QixhQUFPd0IsV0FBVzdKLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBUDtBQUNELEtBbENEO0FBQUE7O0FBb0NNNUMsa0JBQU4sQ0FBd0JrSCxTQUF4QixFQUFtQzdILElBQW5DO0FBQUEsb0NBQXlDO0FBQ3ZDO0FBQ0EsVUFBSXFOLFlBQWFsQixRQUFELElBQWNBLGFBQWEsUUFBYixHQUF3QixPQUF4QixHQUFrQ0EsUUFBaEUsQ0FGdUMsQ0FJdkM7OztBQUNBLFVBQUk5RCxZQUFZLElBQWhCO0FBQ0EsVUFBSStFLGFBQWEsRUFBakIsQ0FOdUMsQ0FRdkM7QUFDQTs7QUFDQSxVQUFJcE4sS0FBS2YsS0FBVCxFQUFnQm1PLFdBQVczRyxJQUFYLENBQWdCekcsS0FBS2YsS0FBckI7QUFDaEIsVUFBSWUsS0FBSzJMLFlBQVQsRUFBdUJ5QixXQUFXM0csSUFBWCxDQUFnQnpHLEtBQUsyTCxZQUFyQjtBQUN2QixVQUFJM0wsS0FBSzRMLFlBQVQsRUFBdUJ3QixXQUFXM0csSUFBWCxDQUFnQnpHLEtBQUs0TCxZQUFyQixFQVpnQixDQWN2Qzs7QUFDQSxVQUFJMEIsYUFBSjs7QUFDQSxjQUFRdE4sS0FBS21NLFFBQWI7QUFDRSxhQUFLLEtBQUw7QUFDRW1CLDBCQUFnQixDQUFoQjtBQUNBOztBQUNGLGFBQUssUUFBTDtBQUNFQSwwQkFBZ0IsQ0FBaEI7QUFDQTs7QUFDRjtBQUNFQSwwQkFBZ0IsQ0FBaEI7QUFDQTtBQVRKLE9BaEJ1QyxDQTRCdkM7OztBQUNBLFVBQUluRixPQUFPLEVBQVg7O0FBQ0EsY0FBUW5JLEtBQUttTSxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VoRSxlQUFLMUIsSUFBTCxDQUFVO0FBQ1JwTixpQkFBSyxDQURHO0FBRVIrTyxpQkFBSztBQUZHLFdBQVYsRUFHRztBQUNEL08saUJBQUssQ0FESjtBQUVEK08saUJBQUs7QUFGSixXQUhIO0FBT0E7O0FBQ0YsYUFBSyxRQUFMO0FBQ0VELGVBQUsxQixJQUFMLENBQVU7QUFDUnBOLGlCQUFLLENBREc7QUFFUitPLGlCQUFLO0FBRkcsV0FBVixFQUdHO0FBQ0QvTyxpQkFBSyxDQURKO0FBRUQrTyxpQkFBSztBQUZKLFdBSEg7QUFPQTtBQWxCSixPQTlCdUMsQ0FtRHZDOzs7QUFDQSxVQUFJbUYsY0FBYyxJQUFsQjs7QUFDQSxjQUFRdk4sS0FBS21NLFFBQWI7QUFDRSxhQUFLLEtBQUw7QUFDRW9CLHdCQUFjLElBQWQ7QUFDQTs7QUFDRixhQUFLLFFBQUw7QUFDRUEsd0JBQWMsR0FBZDtBQUNBO0FBTkosT0FyRHVDLENBOER2QztBQUNBO0FBQ0E7OztBQUVBLFVBQUloQixzQkFBYyxLQUFLUCxZQUFMLENBQWtCaE0sSUFBbEIsRUFBd0I7QUFDeEMrSCxvQkFBWTtBQUQ0QixPQUF4QixDQUFkLENBQUosQ0FsRXVDLENBc0V2QztBQUVBOztBQUNBd0UsY0FBUUEsTUFBTWpKLEdBQU4sQ0FDTGtLLElBQUQsSUFBVTtBQUNSQSxhQUFLVCxLQUFMLENBQVdiLE9BQVgsR0FBcUJtQixVQUFVRyxLQUFLVCxLQUFMLENBQVdiLE9BQXJCLENBQXJCO0FBQ0FzQixhQUFLZixVQUFMLEdBQWtCZSxLQUFLZixVQUFMLENBQWdCbkosR0FBaEIsQ0FDZm1LLFNBQUQsSUFBZTtBQUNiQSxvQkFBVXJCLEtBQVYsR0FBa0JpQixVQUFVSSxVQUFVckIsS0FBcEIsQ0FBbEI7QUFDQSxpQkFBT3FCLFNBQVA7QUFDRCxTQUplLENBQWxCO0FBTUEsZUFBT0QsSUFBUDtBQUNELE9BVkssQ0FBUixDQXpFdUMsQ0FzRnZDOztBQUNBLFVBQUlFLGdCQUNGbkIsTUFBTWpKLEdBQU4sQ0FDR2tLLElBQUQsSUFDRSxrQ0FDRCxtQkFEQyxHQUVELGlFQUZDLEdBR0QsV0FBVUEsS0FBS1QsS0FBTCxDQUFXZCxLQUFNLFdBSDFCLEdBSUQsUUFKQyxHQUtGdUIsS0FBS2YsVUFBTCxDQUFnQm5KLEdBQWhCLENBQ0dtSyxTQUFELElBQWU7QUFDYixZQUFJRCxLQUFLVCxLQUFMLENBQVdiLE9BQVgsS0FBdUJ1QixVQUFVckIsS0FBckMsRUFBNEM7QUFDMUMsaUJBQVEsNkJBQTRCcUIsVUFBVTFGLFVBQVcsMEVBQXlFMEYsVUFBVXJCLEtBQU0sd0JBQWxKO0FBQ0QsU0FGRCxNQUVPO0FBQ0wsaUJBQVEsNkJBQTRCcUIsVUFBVTFGLFVBQVcsa0VBQWlFMEYsVUFBVXJCLEtBQU0sZUFBMUk7QUFDRDtBQUNGLE9BUEgsRUFRRTdJLElBUkYsQ0FRTyxFQVJQLENBTEUsR0FjRixRQWRFLEdBZUYsUUFqQkYsRUFrQkVBLElBbEJGLENBa0JPLEVBbEJQLENBREY7QUFxQkEsVUFBSW9LLG9CQUFxQjs7O01BR3ZCRCxhQUFjO0tBSGhCLENBNUd1QyxDQWtIdkM7O0FBQ0EsVUFBSTdWLE9BQU87QUFDVGtRLG9CQUFZTSxTQURIO0FBRVR6SCxvQkFBWWlILFNBRkg7QUFHVHhQLGNBQU8sR0FBRStVLFdBQVc3SixJQUFYLENBQWdCLEdBQWhCLENBQXFCLElBQUc4SixVQUFVck4sS0FBS21NLFFBQWYsQ0FBeUIsSUFBR25NLEtBQUszSCxJQUFLLElBQUcySCxLQUFLNE4sUUFBUyxFQUgvRTtBQUlUQyw0QkFBb0JGLGlCQUpYO0FBS1Q3RSxtQkFBVzlJLEtBQUs4TixXQUFMLEdBQW1CLEdBTHJCO0FBTVRDLHNCQUFjWCxXQUFXN0osSUFBWCxDQUFnQixHQUFoQixDQU5MO0FBT1R5SyxpQkFBU2hPLEtBQUtpTyxZQVBMO0FBUVRDLGlCQUFTbE8sS0FBS21PLFdBQUwsR0FBbUIsSUFSbkI7QUFReUI7QUFDbENqSyxnQkFBUWxFLEtBQUtrRSxNQVRKO0FBVVRrSyx5QkFBaUJkLGFBVlI7QUFXVG5GLGNBQU1BLElBWEc7QUFZVGtHLHNCQUFjZDtBQVpMLE9BQVg7QUFlQVosYUFBT0MsTUFBUCxDQUFjL1UsSUFBZCxFQUFvQm1JLEtBQUtNLElBQUwsQ0FBVUMsV0FBOUI7QUFFQSxhQUFPMUksSUFBUDtBQUNELEtBcklEO0FBQUEsR0F0UGtDLENBNlhsQzs7O0FBQ01pTixrQkFBTixDQUF3QndKLEdBQXhCLEVBQTZCdE8sSUFBN0I7QUFBQSxvQ0FBbUM7QUFDakMsWUFBTXVPLFdBQVcsRUFBakI7QUFDQSxZQUFNQyxjQUFjLEdBQXBCO0FBRUEsVUFBSXhLLFFBQVEsRUFBWixDQUppQyxDQUtqQzs7QUFDQUEsY0FBUXBMLEtBQUs2SixLQUFMLENBQVc3SixLQUFLQyxTQUFMLENBQWV5VixJQUFJdE8sS0FBS21NLFFBQVQsQ0FBZixDQUFYLENBQVIsQ0FOaUMsQ0FRakM7O0FBQ0EsWUFBTXNDLFlBQVksSUFBbEI7O0FBQ0EsV0FBSyxJQUFJcE0sSUFBSSxDQUFiLEVBQWdCQSxJQUFJckMsS0FBS2tFLE1BQUwsQ0FBWW9FLE1BQWhDLEVBQXdDakcsR0FBeEMsRUFBNkM7QUFDM0MyQixjQUFNeUssYUFBYXBNLElBQUksQ0FBakIsQ0FBTixJQUE2QnJDLEtBQUtrRSxNQUFMLENBQVk3QixDQUFaLENBQTdCO0FBQ0QsT0FaZ0MsQ0FjakM7OztBQUNBMkIsWUFBTSxNQUFOLElBQWdCaEUsS0FBS00sSUFBTCxDQUFVMEQsS0FBVixDQUFnQjBLLFFBQWhDO0FBQ0ExSyxZQUFNLE1BQU4sSUFBZ0I0RyxTQUFTK0QsT0FBVCxDQUFrQixHQUFELGNBQVMsS0FBSzlMLGFBQUwsQ0FBbUI3QyxJQUFuQixDQUFULENBQWtDLElBQUdBLEtBQUttTSxRQUFTLElBQUduTSxLQUFLM0gsSUFBSyxFQUFqRixFQUFvRm1XLFdBQXBGLENBQWhCO0FBQ0F4SyxZQUFNLE1BQU4sSUFBZ0JoRSxLQUFLbU8sV0FBckI7QUFDQW5LLFlBQU0sTUFBTixJQUFnQmhFLEtBQUttTyxXQUFyQjtBQUNBbkssWUFBTSxNQUFOLElBQWdCaEUsS0FBS0ksR0FBTCxDQUFTK00sV0FBVCxHQUF1QnpKLEtBQXZCLENBQTZCLENBQUM2SyxRQUE5QixDQUFoQjtBQUNBdkssWUFBTSxJQUFOLElBQWNoRSxLQUFLOE4sV0FBbkI7QUFDQTlKLFlBQU0sZ0JBQU4sSUFBMEJoRSxLQUFLNE4sUUFBL0I7QUFFQSxhQUFPNUosS0FBUDtBQUNELEtBeEJEO0FBQUE7O0FBOVhrQyxDOzs7Ozs7Ozs7OztBQ1hwQzNOLE9BQU80TyxNQUFQLENBQWM7QUFBQ3pPLFdBQVEsTUFBSW9ZO0FBQWIsQ0FBZDs7QUFBZSxNQUFNQSxTQUFOLENBQWdCO0FBQzdCLFNBQU9uTSxLQUFQLENBQWMvRixDQUFkLEVBQWlCO0FBQ2YsUUFBSXpDLE1BQU0sRUFBVjs7QUFFQSxRQUFJeUMsYUFBYTJKLEtBQWpCLEVBQXdCO0FBQ3RCcE0sVUFBSTRVLE9BQUosR0FBY25TLEVBQUVtUyxPQUFoQjtBQUNBNVUsVUFBSTVCLElBQUosR0FBV3FFLEVBQUVyRSxJQUFiO0FBQ0E0QixVQUFJNlUsUUFBSixHQUFlcFMsRUFBRW9TLFFBQWpCO0FBQ0E3VSxVQUFJOFUsVUFBSixHQUFpQnJTLEVBQUVxUyxVQUFuQjtBQUNBOVUsVUFBSStVLFlBQUosR0FBbUJ0UyxFQUFFc1MsWUFBckI7QUFDQS9VLFVBQUlnVixLQUFKLEdBQVl2UyxFQUFFdVMsS0FBZDtBQUNELEtBUEQsTUFPTztBQUNMaFYsWUFBTXlDLENBQU47QUFDRDs7QUFFRCxXQUFPekMsR0FBUDtBQUNEOztBQWhCNEIsQzs7Ozs7Ozs7Ozs7QUNBL0I1RCxPQUFPNE8sTUFBUCxDQUFjO0FBQUMxRyxtQkFBZ0IsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJZ0wsV0FBSjtBQUFnQmxULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ2dULGNBQVk5UyxDQUFaLEVBQWM7QUFBQzhTLGtCQUFZOVMsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTs7QUFFOUQsTUFBTThILGVBQU4sQ0FBc0I7QUFDM0IsU0FBYUksR0FBYixDQUFrQkgsSUFBbEIsRUFBd0JJLFVBQXhCO0FBQUEsb0NBQW9DO0FBQ2xDLFVBQUl3TCx1QkFBZWIsWUFBWWMsT0FBWixDQUFvQjdMLEtBQUs4TCxHQUF6QixDQUFmLENBQUo7QUFDQSxVQUFJaE0sS0FBSzhMLE9BQU85TCxFQUFQLENBQVVFLEtBQUsrTCxRQUFmLENBQVQ7QUFDQSxhQUFPak0sR0FBR00sVUFBSCxDQUFjQSxVQUFkLENBQVA7QUFDRCxLQUpEO0FBQUE7O0FBRDJCLEM7Ozs7Ozs7Ozs7O0FDRjdCdkksT0FBTzRPLE1BQVAsQ0FBYztBQUFDek8sV0FBUSxNQUFJd0M7QUFBYixDQUFkO0FBQW1DLElBQUkrTSxLQUFKO0FBQVUxUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDc1AsWUFBTXRQLENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSXlZLE1BQUo7QUFBVzdZLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN5WSxhQUFPelksQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDs7QUFHaEcsTUFBTXVDLEtBQU4sQ0FBWTtBQUN6QjBNLGNBQWFySCxPQUFiLEVBQXNCO0FBQ3BCO0FBQ0EsU0FBSzhRLElBQUwsR0FBWXBKLE1BQU1xSixVQUFOLENBQWlCL1EsT0FBakIsQ0FBWixDQUZvQixDQUlwQjs7QUFDQSxRQUFJZ1IsZUFBZTtBQUFDQywwQkFBb0I7QUFBckIsS0FBbkI7QUFDQTNDLFdBQU9DLE1BQVAsQ0FBY3lDLFlBQWQsRUFBNEJoUixPQUE1QjtBQUNBLFNBQUtrUixTQUFMLEdBQWlCeEosTUFBTXFKLFVBQU4sQ0FBaUJDLFlBQWpCLENBQWpCO0FBQ0Q7O0FBRUQsU0FBT0csVUFBUCxDQUFtQkMsSUFBbkIsRUFBeUI7QUFDdkIsV0FBT1AsT0FBT08sSUFBUCxFQUFhQyxNQUFiLEdBQXNCeFMsU0FBdEIsQ0FBZ0MsQ0FBaEMsRUFBbUMsRUFBbkMsRUFBdUN5UyxPQUF2QyxDQUErQyxHQUEvQyxFQUFvRCxHQUFwRCxDQUFQO0FBQ0Q7QUFFRDs7Ozs7O0FBSUEzVixRQUFPSyxHQUFQLEVBQVk7QUFDVjtBQUNBO0FBQ0EsV0FBTyxLQUFLdVYsTUFBTCxHQUNKQyxJQURJLENBRUZDLEdBQUQsSUFBUztBQUNQLGFBQU8sSUFBSTVJLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQTBJLFlBQUk5VixLQUFKLENBQVVLLEdBQVYsRUFBZSxDQUFDcUMsQ0FBRCxFQUFJekMsR0FBSixLQUFZO0FBQ3pCO0FBQ0E2VixjQUFJQyxPQUFKOztBQUNBLGNBQUlyVCxDQUFKLEVBQU87QUFDTDBLLG1CQUFPMUssQ0FBUDtBQUNELFdBRkQsTUFFT3lLLFFBQVFsTixHQUFSO0FBQ1IsU0FORDtBQU9ELE9BVkksQ0FBUDtBQVlELEtBZkUsRUFpQkpzTixLQWpCSSxDQWlCRzdLLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQW5CSSxDQUFQO0FBb0JEOztBQUVLc1QsY0FBTixDQUFvQjNWLEdBQXBCO0FBQUEsb0NBQXlCO0FBQ3ZCLFVBQUlKLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPSixJQUFJZ1csUUFBWDtBQUNELEtBSEQ7QUFBQTtBQUtBOzs7Ozs7OztBQU1NeFQsYUFBTixDQUFtQjBKLEtBQW5CLEVBQTBCdE8sT0FBTyxFQUFqQyxFQUFxQ3FZLFVBQVUsRUFBL0M7QUFBQSxvQ0FBbUQ7QUFDakQ7QUFDQTtBQUVBLFVBQUk3VixNQUFPLGVBQWM4TCxLQUFNLEdBQS9CO0FBRUEsVUFBSTdDLE1BQU0sSUFBSTZNLEdBQUosRUFBVjs7QUFDQSxXQUFLLElBQUl4SCxDQUFULElBQWNnRSxPQUFPakUsSUFBUCxDQUFZN1EsSUFBWixDQUFkLEVBQWlDO0FBQy9CLFlBQUlBLEtBQUs4USxDQUFMLE1BQVksSUFBaEIsRUFBc0I7QUFDcEJyRixjQUFJOEUsR0FBSixDQUFRTyxDQUFSLEVBQVcsTUFBWDtBQUNELFNBRkQsTUFFTyxJQUFJOVEsS0FBSzhRLENBQUwsRUFBUWpELFdBQVIsQ0FBb0JyTixJQUFwQixLQUE2QixNQUFqQyxFQUF5QztBQUM5QztBQUNBaUwsY0FBSThFLEdBQUosQ0FBUU8sQ0FBUixFQUFZLElBQUczUCxNQUFNd1csVUFBTixDQUFpQjNYLEtBQUs4USxDQUFMLENBQWpCLENBQTBCLEdBQXpDO0FBQ0QsU0FITSxNQUdBO0FBQ0xyRixjQUFJOEUsR0FBSixDQUFRTyxDQUFSLEVBQVksR0FBRTVDLE1BQU1xSyxNQUFOLENBQWF2WSxLQUFLOFEsQ0FBTCxDQUFiLENBQXNCLEVBQXBDO0FBQ0Q7QUFDRjs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBY2dFLE9BQU9qRSxJQUFQLENBQVl3SCxPQUFaLENBQWQsRUFBb0M7QUFDbEM1TSxZQUFJOEUsR0FBSixDQUFRTyxDQUFSLEVBQVd1SCxRQUFRdkgsQ0FBUixNQUFlLElBQWYsR0FBc0IsTUFBdEIsR0FBK0J1SCxRQUFRdkgsQ0FBUixDQUExQztBQUNEOztBQUVEdE8sYUFBUSxLQUFJLENBQUMsR0FBR2lKLElBQUlvRixJQUFKLEVBQUosRUFBZ0JuRixJQUFoQixDQUFxQixHQUFyQixDQUEwQixLQUF0QztBQUVBbEosYUFBUSxXQUFVLENBQUMsR0FBR2lKLElBQUkrTSxNQUFKLEVBQUosRUFBa0I5TSxJQUFsQixDQUF1QixHQUF2QixDQUE0QixLQUE5QztBQUVBLFVBQUl0SixvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT0osSUFBSWdXLFFBQVg7QUFDRCxLQTNCRDtBQUFBO0FBNkJBOzs7Ozs7Ozs7QUFPTXZJLGFBQU4sQ0FBbUJ2QixLQUFuQixFQUEwQjFNLE1BQTFCLEVBQWtDNUIsSUFBbEMsRUFBd0NxWSxPQUF4QztBQUFBLG9DQUFpRDtBQUMvQyxVQUFJN1YsTUFBTyxVQUFTOEwsS0FBTSxPQUExQjtBQUVBLFVBQUltSyxVQUFVLEVBQWQ7O0FBQ0EsV0FBSyxJQUFJM0gsQ0FBVCxJQUFjZ0UsT0FBT2pFLElBQVAsQ0FBWTdRLElBQVosQ0FBZCxFQUFpQztBQUMvQnlZLGdCQUFRN0osSUFBUixDQUFjLEdBQUVrQyxDQUFFLElBQUc1QyxNQUFNcUssTUFBTixDQUFhdlksS0FBSzhRLENBQUwsQ0FBYixDQUFzQixFQUEzQztBQUNEOztBQUNELFdBQUssSUFBSUEsQ0FBVCxJQUFjZ0UsT0FBT2pFLElBQVAsQ0FBWXdILE9BQVosQ0FBZCxFQUFvQztBQUNsQ0ksZ0JBQVE3SixJQUFSLENBQWMsR0FBRWtDLENBQUUsSUFBR3VILFFBQVF2SCxDQUFSLENBQVcsRUFBaEM7QUFDRDs7QUFDRHRPLGFBQU9pVyxRQUFRL00sSUFBUixDQUFhLEdBQWIsQ0FBUDtBQUVBbEosYUFBUSxVQUFTWixNQUFPLEdBQXhCO0FBRUEsVUFBSVEsb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9KLEdBQVA7QUFDRCxLQWhCRDtBQUFBLEdBM0Z5QixDQTZHekI7OztBQUNNc1csWUFBTixDQUFrQmxXLEdBQWxCO0FBQUEsb0NBQXVCO0FBQ3JCLFVBQUltVyxXQUFXLEtBQUtyQixJQUFwQjtBQUNBLFdBQUtBLElBQUwsR0FBWSxLQUFLSSxTQUFqQjs7QUFDQSxVQUFJO0FBQ0YsWUFBSXRWLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxlQUFPSixHQUFQO0FBQ0QsT0FIRCxTQUdVO0FBQ1IsYUFBS2tWLElBQUwsR0FBWXFCLFFBQVo7QUFDRDtBQUNGLEtBVEQ7QUFBQTs7QUFXTUMsa0JBQU47QUFBQSxvQ0FBMEI7QUFDeEIsb0JBQU0sS0FBS3pXLEtBQUwsQ0FBWSxvQkFBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNMFcsUUFBTjtBQUFBLG9DQUFnQjtBQUNkLG9CQUFNLEtBQUsxVyxLQUFMLENBQVksU0FBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNMlcsVUFBTjtBQUFBLG9DQUFrQjtBQUNoQixvQkFBTSxLQUFLM1csS0FBTCxDQUFZLFdBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJQW9NLGlCQUFnQi9MLEdBQWhCLEVBQXFCNEwsV0FBWTdMLE1BQUQsSUFBWSxDQUFFLENBQTlDLEVBQWdEOEwsVUFBV3hKLENBQUQsSUFBTyxDQUFFLENBQW5FLEVBQXFFO0FBQ25FLFdBQU8sS0FBS2tULE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUk1SSxPQUFKLENBQ0wsQ0FBT0MsT0FBUCxFQUFnQkMsTUFBaEIsOEJBQTJCO0FBQ3pCO0FBQ0EwSSxZQUFJOVYsS0FBSixDQUFVSyxHQUFWLEVBQ0d1VyxFQURILENBQ00sUUFETixFQUVLeFcsTUFBRCxJQUFZO0FBQ1YwVixjQUFJZSxLQUFKO0FBQ0E1SyxtQkFBUzdMLE1BQVQ7QUFDQTBWLGNBQUlnQixNQUFKO0FBQ0QsU0FOTCxFQU9HRixFQVBILENBT00sT0FQTixFQU9nQmxVLENBQUQsSUFBTztBQUNsQndKLGtCQUFReEosQ0FBUjtBQUNELFNBVEgsRUFVR2tVLEVBVkgsQ0FVTSxLQVZOLEVBVWEsTUFBTTtBQUNmZCxjQUFJQyxPQUFKO0FBQ0E1STtBQUNELFNBYkg7QUFjRCxPQWhCRCxDQURLLENBQVA7QUFtQkQsS0F0QkUsRUF3QkpJLEtBeEJJLENBd0JHN0ssQ0FBRCxJQUFPO0FBQ1osWUFBTUEsQ0FBTjtBQUNELEtBMUJJLENBQVA7QUEyQkQ7O0FBRURrVCxXQUFVO0FBQ1IsV0FBTyxJQUFJMUksT0FBSixDQUNMLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUNuQjtBQUNBLFdBQUsrSCxJQUFMLENBQVU0QixhQUFWLENBQXdCLENBQUNyVSxDQUFELEVBQUlvVCxHQUFKLEtBQVk7QUFDbEMsWUFBSXBULENBQUosRUFBTztBQUNMMEssaUJBQU8xSyxDQUFQO0FBQ0QsU0FGRCxNQUVPO0FBQ0x5SyxrQkFBUTJJLEdBQVI7QUFDRDtBQUNGLE9BTkQ7QUFPRCxLQVZJLEVBWUp2SSxLQVpJLENBYUY3SyxDQUFELElBQU87QUFDTCxZQUFNQSxDQUFOO0FBQ0QsS0FmRSxDQUFQO0FBaUJEOztBQXJMd0IsQzs7Ozs7Ozs7Ozs7QUNIM0JyRyxPQUFPNE8sTUFBUCxDQUFjO0FBQUN6TyxXQUFRLE1BQUk4SztBQUFiLENBQWQ7O0FBQWUsTUFBTUEsTUFBTixDQUFhO0FBQzFCb0UsY0FBYTFDLFVBQWIsRUFBeUI7QUFDdkIsU0FBS0EsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxTQUFLUSxhQUFMLEdBQXFCLElBQXJCO0FBQ0EsU0FBS00sUUFBTCxHQUFnQixJQUFoQjtBQUNBLFNBQUtTLFdBQUwsR0FBbUIsSUFBbkI7QUFDQSxTQUFLbUMsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLakQsV0FBTCxHQUFtQixDQUFuQjtBQUNEOztBQUVLc0IsUUFBTixDQUFjaEIsR0FBZDtBQUFBLG9DQUFtQjtBQUNqQjtBQUNBLFVBQUksS0FBSzJDLEtBQUwsR0FBYSxLQUFLMUQsVUFBbEIsS0FBaUMsQ0FBckMsRUFBd0M7QUFDdEMsWUFBSSxLQUFLUSxhQUFULEVBQXdCO0FBQ3RCLHdCQUFNLEtBQUtBLGFBQUwsQ0FBbUIsS0FBS0MsV0FBeEIsQ0FBTjtBQUNEO0FBQ0Y7O0FBQ0QsVUFBSSxLQUFLSyxRQUFULEVBQW1CO0FBQ2pCLHNCQUFNLEtBQUtBLFFBQUwsQ0FBY0MsR0FBZCxDQUFOO0FBQ0Q7O0FBQ0QsV0FBSzJDLEtBQUwsR0FWaUIsQ0FXakI7O0FBQ0EsVUFBSSxLQUFLQSxLQUFMLEdBQWEsS0FBSzFELFVBQWxCLEtBQWlDLENBQXJDLEVBQXdDO0FBQ3RDLGFBQUtnQyxLQUFMO0FBQ0EsYUFBS3ZCLFdBQUw7QUFDRDtBQUNGLEtBaEJEO0FBQUE7O0FBaUJBdUIsVUFBUztBQUNQLFFBQUksS0FBS1QsV0FBVCxFQUFzQjtBQUNwQixXQUFLQSxXQUFMLENBQWlCLEtBQUtkLFdBQXRCO0FBQ0Q7QUFDRjs7QUEvQnlCLEM7Ozs7Ozs7Ozs7O0FDQTVCcE4sT0FBTzRPLE1BQVAsQ0FBYztBQUFDek8sV0FBUSxNQUFJeUM7QUFBYixDQUFkO0FBQW9DLElBQUkyVixTQUFKO0FBQWN2WSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDbVksZ0JBQVVuWSxDQUFWO0FBQVk7O0FBQXhCLENBQWhDLEVBQTBELENBQTFEO0FBQTZELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBRzNHLE1BQU13QyxNQUFOLENBQWE7QUFDMUJ5TSxnQkFBZTtBQUNiLFNBQUt0TCxNQUFMLEdBQWMsRUFBZDtBQUNBLFNBQUsyUCxTQUFMLEdBQWlCLEVBQWpCO0FBQ0EsU0FBS2lILFFBQUwsR0FBZ0IsSUFBaEI7QUFDRDs7QUFFREMsa0JBQWlCO0FBQ2YsU0FBS0QsUUFBTCxHQUFnQixJQUFJRSxRQUFKLEVBQWhCO0FBQ0EsU0FBS25ILFNBQUwsQ0FBZXRELElBQWYsQ0FBb0IsS0FBS3VLLFFBQXpCO0FBQ0Q7O0FBRUtqWCxPQUFOLENBQWExQixPQUFPLEVBQXBCLEVBQXdCeVIsS0FBSywrQkFBWSxDQUFFLENBQWQsQ0FBN0I7QUFBQSxvQ0FBNkM7QUFDM0MsV0FBS21ILGFBQUw7QUFFQSxVQUFJRSxNQUFNLEVBQVY7O0FBRUEsVUFBSTtBQUNGLFlBQUlsWCxvQkFBWTZQLElBQVosQ0FBSjtBQUVBNkMsZUFBT0MsTUFBUCxDQUFjdUUsR0FBZCxFQUFtQjtBQUNqQnJMLGdCQUFNLFNBRFc7QUFFakIvTCxpQkFBTzFCLElBRlU7QUFHakIrWSxrQkFBUW5YO0FBSFMsU0FBbkI7QUFLRCxPQVJELENBUUUsT0FBT3lDLENBQVAsRUFBVTtBQUNWaVEsZUFBT0MsTUFBUCxDQUFjdUUsR0FBZCxFQUFtQjtBQUNqQnJMLGdCQUFNLE9BRFc7QUFFakIvTCxpQkFBTzFCLElBRlU7QUFHakIrWSxrQkFBUXhDLFVBQVVuTSxLQUFWLENBQWdCL0YsQ0FBaEI7QUFIUyxTQUFuQjtBQUtELE9BZEQsU0FjVTtBQUNSLFlBQUksS0FBS3NVLFFBQUwsQ0FBY0ssS0FBbEIsRUFBeUI7QUFDdkIxRSxpQkFBT0MsTUFBUCxDQUFjdUUsR0FBZCxFQUFtQjtBQUNqQkgsc0JBQVUsS0FBS0E7QUFERSxXQUFuQjtBQUdEOztBQUNELGFBQUs1VyxNQUFMLENBQVlxTSxJQUFaLENBQWlCMEssR0FBakI7QUFDRDtBQUNGLEtBM0JEO0FBQUE7O0FBNkJBbFEsV0FBVXFRLFNBQVYsRUFBcUI7QUFDbkIsU0FBS04sUUFBTCxDQUFjTyxPQUFkLENBQXNCRCxTQUF0QjtBQUNEOztBQUVEM1UsU0FBUTJVLFNBQVIsRUFBbUI7QUFDakIsU0FBS04sUUFBTCxDQUFjeFksS0FBZCxDQUFvQm9XLFVBQVVuTSxLQUFWLENBQWdCNk8sU0FBaEIsQ0FBcEI7QUFDRDs7QUFFREUsaUJBQWdCO0FBQ2QsUUFBSUMsV0FBVyxLQUFLMUgsU0FBTCxDQUFlbEwsSUFBZixDQUFvQm5DLEtBQUtBLEVBQUU4VSxZQUFGLEVBQXpCLENBQWY7QUFDQSxRQUFJRSxXQUFXLEtBQWY7O0FBQ0EsU0FBSyxJQUFJUCxHQUFULElBQWdCLEtBQUsvVyxNQUFyQixFQUE2QjtBQUMzQixVQUFJK1csSUFBSXJMLElBQUosS0FBYSxPQUFqQixFQUEwQjtBQUN4QjRMLG1CQUFXLElBQVg7QUFDQTtBQUNEO0FBQ0Y7O0FBQ0QsV0FBT0QsWUFBWUMsUUFBbkI7QUFDRDs7QUFFRHRULFlBQVc7QUFDVCxRQUFJLEtBQUtvVCxZQUFMLEVBQUosRUFBeUI7QUFDdkIsWUFBTSxJQUFJbmEsT0FBT2dQLEtBQVgsQ0FBaUIsS0FBS2pNLE1BQXRCLENBQU47QUFDRDs7QUFDRCxXQUFPLEtBQUtBLE1BQVo7QUFDRDs7QUFsRXlCOztBQXFFNUIsTUFBTThXLFFBQU4sQ0FBZTtBQUNieEwsZ0JBQWU7QUFDYixTQUFLMkwsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLTSxLQUFMLEdBQWE7QUFDWEosZUFBUztBQUNQRixlQUFPLENBREE7QUFFUE8saUJBQVM7QUFGRixPQURFO0FBS1hwWixhQUFPO0FBQ0w2WSxlQUFPLENBREY7QUFFTE8saUJBQVM7QUFGSjtBQUxJLEtBQWI7QUFVRDs7QUFFREwsVUFBU0QsU0FBVCxFQUFvQjtBQUNsQixRQUFJQSxTQUFKLEVBQWU7QUFDYixXQUFLSyxLQUFMLENBQVdKLE9BQVgsQ0FBbUJLLE9BQW5CLENBQTJCbkwsSUFBM0IsQ0FBZ0M2SyxTQUFoQztBQUNEOztBQUNELFNBQUtLLEtBQUwsQ0FBV0osT0FBWCxDQUFtQkYsS0FBbkI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBQ0Q3WSxRQUFPOFksU0FBUCxFQUFrQjtBQUNoQjtBQUNBLFFBQUlPLFlBQVksSUFBaEI7QUFDQSxRQUFJdkssUUFBUSxLQUFLcUssS0FBTCxDQUFXblosS0FBWCxDQUFpQm9aLE9BQWpCLENBQXlCdEosTUFBckM7O0FBQ0EsUUFBSWhCLEtBQUosRUFBVztBQUNUdUssa0JBQVksS0FBS0YsS0FBTCxDQUFXblosS0FBWCxDQUFpQm9aLE9BQWpCLENBQXlCdEssUUFBUSxDQUFqQyxDQUFaO0FBQ0QsS0FOZSxDQVFoQjs7O0FBQ0EsUUFBSTFPLEtBQUtDLFNBQUwsQ0FBZWdaLFNBQWYsTUFBOEJqWixLQUFLQyxTQUFMLENBQWV5WSxTQUFmLENBQWxDLEVBQTZEO0FBQzNELFVBQUlBLGFBQWFBLGNBQWMsRUFBM0IsSUFBaUNBLGNBQWMsRUFBbkQsRUFBdUQ7QUFDckQsYUFBS0ssS0FBTCxDQUFXblosS0FBWCxDQUFpQm9aLE9BQWpCLENBQXlCbkwsSUFBekIsQ0FBOEI2SyxTQUE5QjtBQUNEO0FBQ0Y7O0FBQ0QsU0FBS0ssS0FBTCxDQUFXblosS0FBWCxDQUFpQjZZLEtBQWpCO0FBQ0EsU0FBS0EsS0FBTDtBQUNEOztBQUVERyxpQkFBZ0I7QUFDZCxXQUFPLEtBQUtHLEtBQUwsQ0FBV25aLEtBQVgsQ0FBaUI2WSxLQUF4QjtBQUNEOztBQTFDWSxDOzs7Ozs7Ozs7OztBQ3hFZmhiLE9BQU80TyxNQUFQLENBQWM7QUFBQ3pPLFdBQVEsTUFBSW9VO0FBQWIsQ0FBZDs7QUFBZSxNQUFNQSxRQUFOLENBQWU7QUFDNUIsU0FBTytELE9BQVAsQ0FBZ0JtRCxJQUFoQixFQUFzQkMsR0FBdEIsRUFBMkJDLFVBQTNCLEVBQXVDO0FBQ3JDLFFBQUlBLGVBQWVDLFNBQW5CLEVBQThCO0FBQUVELG1CQUFhLEVBQWI7QUFBaUI7O0FBQ2pELFFBQUlFLFlBQVlKLEtBQUtLLEtBQUwsQ0FBVyxFQUFYLENBQWhCO0FBQ0EsUUFBSXpMLFFBQVEsQ0FBWjtBQUNBLFFBQUkwTCxNQUFNLEVBQVY7O0FBQ0EsU0FBSyxJQUFJL1AsSUFBSSxDQUFiLEVBQWdCQSxJQUFJNlAsVUFBVTVKLE1BQTlCLEVBQXNDakcsR0FBdEMsRUFBMkM7QUFDekMsVUFBSWdRLElBQUlqQyxPQUFPOEIsVUFBVTdQLENBQVYsQ0FBUCxDQUFSO0FBQ0EsVUFBSWdRLEVBQUUvSixNQUFGLEdBQVcsQ0FBZixFQUFrQjVCLFFBQWxCLEtBQ0tBLFNBQVMsQ0FBVDs7QUFDTCxVQUFJQSxRQUFRcUwsR0FBWixFQUFpQjtBQUNmLGVBQU9LLE1BQU1KLFVBQWI7QUFDRDs7QUFDREksYUFBT04sS0FBS1EsTUFBTCxDQUFZalEsQ0FBWixDQUFQO0FBQ0Q7O0FBQ0QsV0FBT3lQLElBQVA7QUFDRDs7QUFoQjJCLEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcbi8vICAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4vLyAgIHJlcy5lbmQoYEhlbGxvIHdvcmxkIGZyb206ICR7TWV0ZW9yLnJlbGVhc2V9YCk7XHJcbi8vIH0pO1xyXG5cclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnO1xyXG5cclxuLy8gUmVxdWlyZXMgbXVsdGlwYXJ0eSBcclxuaW1wb3J0IG11bHRpcGFydHkgZnJvbSAnY29ubmVjdC1tdWx0aXBhcnR5JztcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL3VwbG9hZHMnO1xyXG5sZXQgbXVsdGlwYXJ0eU1pZGRsZXdhcmUgPSBtdWx0aXBhcnR5KCk7XHJcblxyXG5jb25zdCByb3V0ZSA9ICcvdXBsb2FkL2ltYWdlJztcclxuXHJcbi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgZnVjLnVwbG9hZEZpbGUgKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIG11bHRpcGFydHlNaWRkbGV3YXJlKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIChyZXEsIHJlc3ApID0+IHtcclxuICAvLyBkb24ndCBmb3JnZXQgdG8gZGVsZXRlIGFsbCByZXEuZmlsZXMgd2hlbiBkb25lXHJcblxyXG4gIGNvbnN0IHJlYWRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMucmVhZEZpbGUpO1xyXG4gIGNvbnN0IHdyaXRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMud3JpdGVGaWxlKTtcclxuICBjb25zdCB1cGxvYWRJZCA9IHVuaXFpZCgpO1xyXG5cclxuICBmb3IgKGxldCBmaWxlIG9mIHJlcS5maWxlcy5maWxlKSB7XHJcbiAgICBjb25zdCBkYXRhID0gcmVhZGVyKGZpbGUucGF0aCk7XHJcbiAgICAvLyDjg5XjgqHjgqTjg6vlkI3jga7ph43opIfjgpLpgb/jgZHjgovjgZ/jgoHjgIHkuIDmhI/jga7jg5XjgqHjgqTjg6vlkI3jgpLkvZzmiJDjgZnjgotcclxuICAgIC8vIOalveWkqeOBruODleOCoeOCpOODq+WQjeaWh+Wtl+aVsOWItumZkDIw44Gr5ZCI44KP44Gb44KLXHJcbiAgICBsZXQgZmlsZW5hbWUgPSBgJHt1bmlxaWQoKX0uanBnYFxyXG5cclxuICAgIC8vIHNldCB0aGUgY29ycmVjdCBwYXRoIGZvciB0aGUgZmlsZSBub3QgdGhlIHRlbXBvcmFyeSBvbmUgZnJvbSB0aGUgQVBJOlxyXG4gICAgbGV0IHNhdmVQYXRoID0gcmVxLmJvZHkuaW1hZ2VkaXIgKyAnLycgKyBmaWxlbmFtZTtcclxuXHJcbiAgICAvLyBjb3B5IHRoZSBkYXRhIGZyb20gdGhlIHJlcS5maWxlcy5maWxlLnBhdGggYW5kIHBhc3RlIGl0IHRvIGZpbGUucGF0aFxyXG5cclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiee1kOaenOOCkuiomOmMsuOBmeOCi1xyXG4gICAgbGV0IGRvYyA9IHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgICBjbGllbnRGaWxlTmFtZTogZmlsZS5uYW1lLFxyXG4gICAgICB1cGxvYWRlZEZpbGVOYW1lOiBmaWxlbmFtZVxyXG4gICAgfTtcclxuICAgIFxyXG4gICAgdHJ5e1xyXG4gICAgICB3cml0ZXIoc2F2ZVBhdGgsIGRhdGEpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2goZXJyKXtcclxuICAgICAgZG9jLmVycm9yID0gZXJyO1xyXG4gICAgfVxyXG4gICAgVXBsb2Fkcy5pbnNlcnQoZG9jKTtcclxuXHJcbiAgICBkZWxldGUgZmlsZTtcclxuXHJcbiAgfTtcclxuICByZXNwLndyaXRlSGVhZCgyMDApO1xyXG4gIHJlc3AuZW5kKEpTT04uc3RyaW5naWZ5KHtcclxuICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgIHNhdmVEaXI6IHJlcS5ib2R5LmltYWdlZGlyXHJcbiAgfSkpO1xyXG5cclxufSk7IiwiaW1wb3J0IGNyeXB0byBmcm9tICdjcnlwdG8nXHJcblxyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQgUmVwb3J0IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgR3JvdXAsXHJcbiAgR3JvdXBGYWN0b3J5XHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3VwcydcclxuaW1wb3J0IHtcclxuICBGaWx0ZXJcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycydcclxuXHJcbmxldCB0YWcgPSAnY3ViZW1pZydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ubWlncmF0ZWBdIChjb25maWcpIHtcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICAvLyBzZXR1cCBncm91cFxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IEZpbHRlcihjb25maWcuc3JjRmlsdGVySWQpXHJcbiAgICAvLyBsZXQgcGx1ZyA9IGdyb3VwLmdldFBsdWcoKTtcclxuXHJcbiAgICAvLyBjaGVja2luZyBjb25uZWN0aW9uXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCB0ZXN0UXVlcnkgPSAnU0hPVyBEQVRBQkFTRVMnXHJcblxyXG4gICAgbGV0IGRzdERiID0gbmV3IE15U1FMKGNvbmZpZy5kc3QuY3JlZClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ0Nvbm5lY3QgdG8gRGVzdGluYXRpb24nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgYXdhaXQgZHN0RGIucXVlcnkodGVzdFF1ZXJ5KVxyXG4gICAgICB9KVxyXG5cclxuICAgIC8vIHByb2Nlc3MgZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAgLy9cclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ1NlbGVjdCBsb29wIGluIHNvdXJjZScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgbW9iaWxlTnVsbDogYXN5bmMgKHJlY29yZCkgPT4ge1xyXG4gICAgICAgICAgICAvLyAvLyDlgKTjgpLmlbTnkIZcclxuICAgICAgICAgICAgLy8gZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgLy8gICBpZiAocmVjb3JkW2tleV0gPT09IG51bGwpO1xyXG4gICAgICAgICAgICAvLyAgIGVsc2UgaWYgKHJlY29yZFtrZXldLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgICAgICAvLyAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IE15U1FMLmZvcm1hdERhdGUocmVjb3JkW2tleV0pO1xyXG4gICAgICAgICAgICAvLyAgICAgcmVjb3JkW2tleV0gPSBgXCIke3JlY29yZFtrZXldfVwiYDtcclxuICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lciDjgavkv53lrZhcclxuXHJcbiAgICAgICAgICAgIGxldCBzcWwgPSBgXHJcblxyXG4gICAgICAgICAgICAgICAgSU5TRVJUIGR0Yl9jdXN0b21lclxyXG4gICAgICAgICAgICAgICAgKCBcXGBjdXN0b21lcl9pZFxcYCwgXFxgc3RhdHVzXFxgLCBcXGBzZXhcXGAsIFxcYGpvYlxcYCwgXFxgY291bnRyeV9pZFxcYCwgXFxgcHJlZlxcYCwgXFxgbmFtZTAxXFxgLCBcXGBuYW1lMDJcXGAsIFxcYGthbmEwMVxcYCwgXFxga2FuYTAyXFxgLCBcXGBjb21wYW55X25hbWVcXGAsIFxcYHppcDAxXFxgLCBcXGB6aXAwMlxcYCwgXFxgemlwY29kZVxcYCwgXFxgYWRkcjAxXFxgLCBcXGBhZGRyMDJcXGAsIFxcYGVtYWlsXFxgLCBcXGB0ZWwwMVxcYCwgXFxgdGVsMDJcXGAsIFxcYHRlbDAzXFxgLCBcXGBmYXgwMVxcYCwgXFxgZmF4MDJcXGAsIFxcYGZheDAzXFxgLCBcXGBiaXJ0aFxcYCwgXFxgcGFzc3dvcmRcXGAsIFxcYHNhbHRcXGAsIFxcYHNlY3JldF9rZXlcXGAsIFxcYGZpcnN0X2J1eV9kYXRlXFxgLCBcXGBsYXN0X2J1eV9kYXRlXFxgLCBcXGBidXlfdGltZXNcXGAsIFxcYGJ1eV90b3RhbFxcYCwgXFxgbm90ZVxcYCwgXFxgY3JlYXRlX2RhdGVcXGAsIFxcYHVwZGF0ZV9kYXRlXFxgLCBcXGBkZWxfZmxnXFxgIClcclxuXHJcbiAgICAgICAgICAgICAgICBWQUxVRVMoICR7cmVjb3JkLmN1c3RvbWVyX2lkfSAsICR7cmVjb3JkLnN0YXR1c30gLCAke3JlY29yZC5zZXh9ICwgJHtyZWNvcmQuam9ifSAsICR7cmVjb3JkLmNvdW50cnlfaWR9ICwgJHtyZWNvcmQucHJlZn0gLCAke3JlY29yZC5uYW1lMDF9ICwgJHtyZWNvcmQubmFtZTAyfSAsICR7cmVjb3JkLmthbmEwMX0gLCAke3JlY29yZC5rYW5hMDJ9ICwgJHtyZWNvcmQuY29tcGFueV9uYW1lfSAsICR7cmVjb3JkLnppcDAxfSAsICR7cmVjb3JkLnppcDAyfSAsICR7cmVjb3JkLnppcGNvZGV9ICwgJHtyZWNvcmQuYWRkcjAxfSAsICR7cmVjb3JkLmFkZHIwMn0gLCAke3JlY29yZC5lbWFpbH0gLCAke3JlY29yZC50ZWwwMX0gLCAke3JlY29yZC50ZWwwMn0gLCAke3JlY29yZC50ZWwwM30gLCAke3JlY29yZC5mYXgwMX0gLCAke3JlY29yZC5mYXgwMn0gLCAke3JlY29yZC5mYXgwM30gLCAke3JlY29yZC5iaXJ0aH0gLCAke3JlY29yZC5wYXNzd29yZH0gLCAke3JlY29yZC5zYWx0fSAsICR7cmVjb3JkLnNlY3JldF9rZXl9ICwgJHtyZWNvcmQuZmlyc3RfYnV5X2RhdGV9ICwgJHtyZWNvcmQubGFzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5idXlfdGltZXN9ICwgJHtyZWNvcmQuYnV5X3RvdGFsfSAsICR7cmVjb3JkLm5vdGV9ICwgJHtyZWNvcmQuY3JlYXRlX2RhdGV9ICwgJHtyZWNvcmQudXBkYXRlX2RhdGV9ICwgJHtyZWNvcmQuZGVsX2ZsZ30gKVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBgXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgc3RhdHVzOiByZWNvcmQuc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgICBzZXg6IHJlY29yZC5zZXgsXHJcbiAgICAgICAgICAgICAgICAgIGpvYjogcmVjb3JkLmpvYixcclxuICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICBlbWFpbDogcmVjb3JkLmVtYWlsLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICBiaXJ0aDogcmVjb3JkLmJpcnRoLFxyXG4gICAgICAgICAgICAgICAgICBwYXNzd29yZDogcmVjb3JkLnBhc3N3b3JkLFxyXG4gICAgICAgICAgICAgICAgICBzYWx0OiByZWNvcmQuc2FsdCxcclxuICAgICAgICAgICAgICAgICAgc2VjcmV0X2tleTogcmVjb3JkLnNlY3JldF9rZXksXHJcbiAgICAgICAgICAgICAgICAgIGZpcnN0X2J1eV9kYXRlOiByZWNvcmQuZmlyc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGxhc3RfYnV5X2RhdGU6IHJlY29yZC5sYXN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBidXlfdGltZXM6IHJlY29yZC5idXlfdGltZXMsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90b3RhbDogcmVjb3JkLmJ1eV90b3RhbCxcclxuICAgICAgICAgICAgICAgICAgbm90ZTogcmVjb3JkLm5vdGUsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXJfYWRkcmVzc1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcl9hZGRyZXNzJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9hZGRyZXNzX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjg6Hjg6vjg57jgqzjg5fjg6njgrDjgqTjg7MgcGxnX21haWxtYWdhX2N1c3RvbWVyXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX21haWxtYWdhX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBpZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgbWFpbG1hZ2FfZmxnOiByZWNvcmQubWFpbG1hZ2FfZmxnLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8g44Kv44O844Od44Oz55m66KGM77yIRUNDVUJFMuOBruODneOCpOODs+ODiOmChOWFg++8iVxyXG5cclxuICAgICAgICAgICAgbGV0IGNvdXBvbkNkID0gY3J5cHRvLnJhbmRvbUJ5dGVzKDgpLnRvU3RyaW5nKCdiYXNlNjQnKS5zdWJzdHJpbmcoMCwgMTEpXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uTmFtZSA9IGAke3JlY29yZC5uYW1lMDF9ICR7cmVjb3JkLm5hbWUwMn0g5qeYIOOBlOWEquW+heOCr+ODvOODneODsyDkvJrlk6Hnlarlj7c6JHtyZWNvcmQuY3VzdG9tZXJfaWR9YFxyXG5cclxuICAgICAgICAgICAgbGV0IGRpc2NvdW50UHJpY2UgPSByZWNvcmQucG9pbnQgKyA1MDBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ3BsZ19jb3Vwb24nLCB7XHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2NkOiBjb3Vwb25DZCxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3R5cGU6IDMsIC8vIOWFqOWVhuWTgVxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbmFtZTogY291cG9uTmFtZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfdHlwZTogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3VzZV90aW1lOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fcmVsZWFzZTogMSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcHJpY2U6IGRpc2NvdW50UHJpY2UsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3JhdGU6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGVuYWJsZV9mbGFnOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbWVtYmVyOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbG93ZXJfbGltaXQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV9mcm9tX2RhdGU6ICcyMDE4LTA0LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX3RvX2RhdGU6ICcyMDE5LTA1LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogMFxyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgJ2N1YmVtaWcuc2VydmVyQ2hlY2snIChwcm9maWxlKSB7XHJcbiAgICBsZXQgZGIgPSBuZXcgTXlTUUwocHJvZmlsZSlcclxuICAgIGxldCByZXMgPSBhd2FpdCBkYi5xdWVyeSgnU0hPVyBEQVRBQkFTRVMnKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCB7IE1vbmdvQ29sbGVjdGlvbiB9IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9tb25nbydcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLmNvbGxlY3Rpb24nXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmZpbmRgXSAocGx1ZywgcXVlcnkgPSB7fSwgcHJvamVjdGlvbiA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuZmluZChxdWVyeSwge3Byb2plY3Rpb246IHByb2plY3Rpb259KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5hZ2dyZWdhdGVgXSAocGx1ZywgcXVlcnkgPSB7fSkge1xyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbilcclxuICAgIGxldCByZXMgPSBhd2FpdCBjb2xsLmFnZ3JlZ2F0ZShxdWVyeSkudG9BcnJheSgpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uLy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLml0ZW1zJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvKipcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+OCs+ODrOOCr+OCt+ODp+ODs+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOBvuOBmeOAglxyXG4gICAqIEBwYXJhbVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LnNldEltYWdlYF0gKHBsdWcsIHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpXHJcbiAgICBsZXQgdXBsb2FkZWQgPSBhd2FpdCBpdGVtY29uLnNldEltYWdlKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxLCBjbGFzczIpXHJcbiAgICByZXR1cm4gdXBsb2FkZWRcclxuICB9LFxyXG5cclxuICAvKipcclxuICAgKiDjgqLjgqTjg4bjg6Dmg4XloLHjg4fjg7zjgr/jg5njg7zjgrnjga7nlLvlg4/nmbvpjLLjgpLliYrpmaTjgZnjgovvvIjnlLvlg4/oh6rkvZPjga/liYrpmaTjgZfjgarjgYTvvIlcclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5jbGVhbkltYWdlYF0gKHBsdWcsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGF3YWl0IGl0ZW1jb24uY2xlYW5JbWFnZShtb2RlbCwgY2xhc3MxLCBjbGFzczIpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCB7XHJcbiAgQ3ViZTNBcGlcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvY3ViZTNhcGknXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnY3ViZSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDlnKjluqvmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlU3RvY2tgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgbGV0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKVxyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQilcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICflnKjluqvjga7mm7TmlrAnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVVBEQVRFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgIGF3YWl0IGFwaS51cGRhdGVTdG9jayhpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCwgcXVhbnRpdHkpXHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHnmbvpjLLjgajmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgIGxldCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQilcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpXHJcblxyXG4gICAgbGV0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+OBuOOBruWVhuWTgeeZu+mMsicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ0lOU0VSVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGluc2VydFJlcyA9IGF3YWl0IGFwaS5wcm9kdWN0Q3JlYXRlKGN1YmVJdGVtKVxyXG5cclxuICAgICAgICAgICAgICAvLyBpdGVtIOODh+ODvOOCv+ODmeODvOOCueOBuOOBrueZu+mMslxyXG4gICAgICAgICAgICAgIGF3YWl0IGNvbC51cGRhdGUoe1xyXG4gICAgICAgICAgICAgICAgX2lkOiBpdGVtLl9pZFxyXG4gICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AnOiBpbnNlcnRSZXMucmVzXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+WVhuWTgeaDheWgseOBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RJbWFnZVVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ3Rvb2wnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnRlc3RgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG5cclxuICAgIGNvbnN0IG5ld0xvY2FsID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe30sIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgIHRocm93IGVcclxuICAgIH0pXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg5XjgqPjg6vjgr/jg7zjg4bjgrnjg4gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIG5ld0xvY2FsXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgUGFja2V0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9wYWNrZXQnXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IGljb252IGZyb20gJ2ljb252LWxpdGUnXHJcbmltcG9ydCBhcmNoaXZlciBmcm9tICdhcmNoaXZlcidcclxuaW1wb3J0IGNzdiBmcm9tICdjc3YnXHJcbmltcG9ydCB7IFBhc3NUaHJvdWdoLCBUcmFuc2Zvcm0gfSBmcm9tICdzdHJlYW0nXHJcblxyXG5jb25zdCBwcmVmaXggPSAncGFja2V0J1xyXG5jb25zdCB0YWcgPSAneWF1Y3QnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Y+X5rOo44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm9yZGVyYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44Ok44OV44Kq44Kv5Y+X5rOoJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vb3JkZXJgXHJcbiAgICAgICAgY29uc3QgciA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlckxvYWRmaWxlfWApXHJcbiAgICAgICAgY29uc3QgdyA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJTYXZlZmlsZX1gKVxyXG4gICAgICAgIGxldCBpID0gMFxyXG4gICAgICAgIHIucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC5waXBlKGNzdi5wYXJzZSh7Y29sdW1uczogdHJ1ZX0pKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnRyYW5zZm9ybShcclxuICAgICAgICAgICAgYXN5bmMgKHJlY29yZCwgY2FsbGJhY2spID0+IHtcclxuICAgICAgICAgICAgICBsZXQgZXJyID0gbnVsbFxyXG4gICAgICAgICAgICAgIC8vIOeuoeeQhueVquWPt+OCkue9ruOBjeaPm+OBiOOCi1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICByZWNvcmRbJ+euoeeQhueVquWPtyddID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0TW9kZWxDbGFzcyhyZWNvcmRbJ+euoeeQhueVquWPtyddKVxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGVyciA9IGVcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgY2FsbGJhY2soZXJyLCByZWNvcmQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICkpXHJcbiAgICAgICAgICAucGlwZShjc3Yuc3RyaW5naWZ5KHtoZWFkZXI6IHRydWV9KSlcclxuICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLnBpcGUodylcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Ye65ZOB44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliaXRgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lh7rlk4EnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDnubDjgorov5TjgZflh6bnkIbjgpLku7vmhI/jga7vvIhwYWNrZXRTaXpl77yJ44Gn5YiG5YmyXHJcbiAgICAgICAgY29uc3QgcGFja2V0ID0gbmV3IFBhY2tldChjb25maWcucGFja2V0U2l6ZSlcclxuXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44KS5L2c5oiQ44GX55S75YOP44OH44O844K/44KS5Y+O6ZuG44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS93b3JrYFxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEucmVtb3ZlKHdvcmtkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG5cclxuICAgICAgICAvLyBaSVDjg5XjgqHjgqTjg6vjgpLkv53lrZjjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB1cGxvYWRkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vdXBsb2FkYFxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEucmVtb3ZlKHVwbG9hZGRpcilcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHVwbG9hZGRpcilcclxuXHJcbiAgICAgICAgbGV0IGNkID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jjg5Xjgqnjg6vjg4BcclxuICAgICAgICBsZXQgZmlsZW5hbWUgPSBudWxsIC8vIGNzduODleOCoeOCpOODq1xyXG4gICAgICAgIGxldCBuYW1lID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jnlarlj7dcclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kj44O844Or44OJ44KS5a6a576p44GX44CB6aCG55Wq44KS56K65a6a44GZ44KLXHJcbiAgICAgICAgbGV0IGZpZWxkcyA9IFsn566h55CG55Wq5Y+3JywgJ+OCq+ODhuOCtOODqicsICfjgr/jgqTjg4jjg6snLCAn6Kqs5piOJywgJ+OCueODiOOCouWGheWVhuWTgeaknOe0oueUqOOCreODvOODr+ODvOODiScsICfplovlp4vkvqHmoLwnLCAn5Y2z5rG65L6h5qC8JywgJ+WApOS4i+OBkuS6pOa4iScsICflgIvmlbAnLCAn5YWl5pyt5YCL5pWw5Yi26ZmQJywgJ+acn+mWkycsICfntYLkuobmmYLplpMnLCAn5ZWG5ZOB55m66YCB5YWD44Gu6YO96YGT5bqc55yMJywgJ+WVhuWTgeeZuumAgeWFg+OBruW4guWMuueUuuadkScsICfpgIHmlpnosqDmi4UnLCAn5Luj6YeR5YWI5omV44GE44CB5b6M5omV44GEJywgJ+iQveacreODiuODk+axuua4iOaWueazleioreWumicsICfllYblk4Hjga7nirbmhYsnLCAn5ZWG5ZOB44Gu54q25oWL5YKZ6ICDJywgJ+i/lOWTgeOBruWPr+WQpicsICfov5Tlk4Hjga7lj6/lkKblgpnogIMnLCAn55S75YOPMScsICfnlLvlg48x44Kz44Oh44Oz44OIJywgJ+eUu+WDjzInLCAn55S75YOPMuOCs+ODoeODs+ODiCcsICfnlLvlg48zJywgJ+eUu+WDjzPjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNCcsICfnlLvlg48044Kz44Oh44Oz44OIJywgJ+eUu+WDjzUnLCAn55S75YOPNeOCs+ODoeODs+ODiCcsICfnlLvlg482JywgJ+eUu+WDjzbjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNycsICfnlLvlg48344Kz44Oh44Oz44OIJywgJ+eUu+WDjzgnLCAn55S75YOPOOOCs+ODoeODs+ODiCcsICfnlLvlg485JywgJ+eUu+WDjznjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMTAnLCAn55S75YOPMTDjgrPjg6Hjg7Pjg4gnLCAn5pyA5L2O6KmV5L6hJywgJ+aCquipleWJsuWQiOWItumZkCcsICflhaXmnK3ogIXoqo3oqLzliLbpmZAnLCAn6Ieq5YuV5bu26ZW3JywgJ+aXqeacn+e1guS6hicsICfllYblk4Hjga7oh6rli5Xlho3lh7rlk4EnLCAn6Ieq5YuV5YCk5LiL44GSJywgJ+acgOS9juiQveacreS+oeagvCcsICfjg4Hjg6Pjg6rjg4bjgqPjg7wnLCAn5rOo55uu44Gu44Kq44O844Kv44K344On44OzJywgJ+WkquWtl+ODhuOCreOCueODiCcsICfog4zmma/oibInLCAn44K544OI44Ki44Ob44OD44OI44Kq44O844Kv44K344On44OzJywgJ+ebrueri+OBoeOCouOCpOOCs+ODsycsICfotIjnrZTlk4HjgqLjgqTjgrPjg7MnLCAnVOODneOCpOODs+ODiOOCquODl+OCt+ODp+ODsycsICfjgqLjg5XjgqPjg6rjgqjjgqTjg4jjgqrjg5fjgrfjg6fjg7MnLCAn6I2354mp44Gu5aSn44GN44GVJywgJ+iNt+eJqeOBrumHjemHjycsICfjga/jgZNCT09OJywgJ+OBneOBruS7lumFjemAgeaWueazlTEnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTInLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTMnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTQnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTUnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTYnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTcnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTgnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTknLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTEwJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+a1t+WklueZuumAgScsICfphY3pgIHmlrnms5Xjg7vpgIHmlpnoqK3lrponLCAn5Luj5byV5omL5pWw5paZ6Kit5a6aJywgJ+a2iOiyu+eojuioreWumicsICdKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ11cclxuICAgICAgICBsZXQgaGVhZGVyID0gZmllbGRzLm1hcCh2ID0+IGBcIiR7dn1cImApLmpvaW4oJywnKSArICdcXG4nXHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMlumWi+Wni+aZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldFN0YXJ0ID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBuYW1lID0gcHJlZml4ICsgKCcwMDAwMCcgKyBwYWNrZXRDb3VudCkuc2xpY2UoLTUpXHJcbiAgICAgICAgICBjZCA9IGAke3dvcmtkaXJ9LyR7bmFtZX1gXHJcbiAgICAgICAgICBmaWxlbmFtZSA9IGAke2NkfS8ke2NvbmZpZy5jc3ZGaWxlTmFtZX1gXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNkKVxyXG4gICAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44Gr44OV44Kj44O844Or44OJ44KS6Kit5a6a44GZ44KLXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShoZWFkZXIsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMluaZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldCA9IGFzeW5jIChhcmcpID0+IHtcclxuICAgICAgICAgIGxldCB5YXVjdCA9IGFyZy55YXVjdFxyXG4gICAgICAgICAgbGV0IGl0ZW0gPSBhcmcuaXRlbVxyXG4gICAgICAgICAgLy8gY3N244OV44Kh44Kk44Or44Gr44Os44Kz44O844OJ77yI5ZWG5ZOB44OG44Oz44OX44Os44O844OI77yJ44KS6L+95Yqg44GZ44KLXHJcbiAgICAgICAgICBsZXQgcmVjb3JkID0gZmllbGRzLm1hcCh2ID0+IHsgcmV0dXJuIHlhdWN0W3ZdID8gYFwiJHt5YXVjdFt2XX1cImAgOiAnXCJcIicgfSkuam9pbignLCcpICsgJ1xcbidcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKHJlY29yZCwgJ1NoaWZ0X0pJUycpKVxyXG4gICAgICAgICAgLy8g55S75YOP44OV44Kh44Kk44Or44KS44Kz44OU44O8XHJcbiAgICAgICAgICBmb3IgKGxldCBpbWcgb2YgaXRlbS5pbWFnZXMpIHtcclxuICAgICAgICAgICAgbGV0IGltZ1NyYyA9IGAke2NvbmZpZy5pbWFnZWRpcn0vJHtpbWd9YFxyXG4gICAgICAgICAgICBsZXQgaW1nVGd0ID0gYCR7Y2R9LyR7aW1nfWBcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAvLyDlkIzjgZjjg5XjgqHjgqTjg6vjgYzjgYLjgovloLTlkIjjga/jgrPjg5Tjg7zjgZfjgarjgYRcclxuICAgICAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFjY2VzcyhpbWdUZ3QpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBhd2FpdCBmc0V4dHJhLmNvcHlGaWxlKGltZ1NyYywgaW1nVGd0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jntYLkuobmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXRFbmQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHppcCA9IGFyY2hpdmVyKCd6aXAnKVxyXG4gICAgICAgICAgY29uc3QgemlwbmFtZSA9IGAke3VwbG9hZGRpcn0vJHtuYW1lfS56aXBgXHJcbiAgICAgICAgICBjb25zdCBvdXRwdXQgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKHppcG5hbWUpXHJcbiAgICAgICAgICB6aXAucGlwZShvdXRwdXQpXHJcbiAgICAgICAgICB6aXAuZGlyZWN0b3J5KGNkLCBmYWxzZSlcclxuICAgICAgICAgIHppcC5maW5hbGl6ZSgpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg6HjgqTjg7Pjg6vjg7zjg5dcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdUQVJHRVQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgLy8gaXRlbeOBq+Wumue+qeOBleOCjOOBpuOBhOOCi+acgOS9juW/heimgeWcqOW6q+OCiOOCiuWkmuOBhOWVhuWTgeOCkuWHuuWTgeOBmeOCi1xyXG4gICAgICAgICAgICBpZiAocXVhbnRpdHkgPj0gaXRlbS5tYWxsLnlhdWN0Lm1pblF1YW50aXR5KSB7XHJcbiAgICAgICAgICAgICAgbGV0IHlhdWN0ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1ZYXVjdChjb25maWcuZGVmYXVsdCwgaXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBwYWNrZXQuc3VibWl0KHt5YXVjdDogeWF1Y3QsIGl0ZW06IGl0ZW19KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcGFja2V0LmNsb3NlKClcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2NvbGxlY3Rpb24vY29uZmlncydcclxuXHJcbmltcG9ydCAnLi9yb3V0ZS91cGxvYWQvaW1hZ2UnXHJcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuIFxyXG5leHBvcnQgY29uc3QgQ29uZmlncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb25maWdzJyx7aWRHZW5lcmF0aW9uOidNT05HTyd9KTtcclxuXHJcbi8vIE1ldGVvci5tZXRob2RzKHsgXHJcbi8vICAgYXN5bmMgJ215c3FsU2VydmVycy5pbnNlcnQnICggbmV3U2VydmVyICl7XHJcbi8vICAgICByZXR1cm4gYXdhaXQgTXlzcWxTZXJ2ZXJzLmluc2VydChuZXdTZXJ2ZXIpO1xyXG4vLyAgIH1cclxuLy8gfSk7XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0JztcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnO1xyXG5pbXBvcnQgeyBHcm91cEJhc2UgfSBmcm9tICcuL2dyb3Vwcyc7XHJcblxyXG5jb25zdCBGaWx0ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZpbHRlcnMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZpbHRlciBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGZpbHRlcklkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBGaWx0ZXJzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGZpbHRlcklkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcblxyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKCBvblJlc3VsdCA9IChyZWNvcmQpPT57fSwgb25FcnJvciA9IChlKT0+e30gKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGxhdGZvcm0gdHlwZScpO1xyXG5cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7eyBmaWx0ZXJUeXBlOiBhc3luYyAocmVjb3JkICkgPT4ge30gfX0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoKGNhbGxiYWNrcyA9IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGUoKTtcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICB0eXBlOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnQgPSB7fTtcclxuICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgY291bnRbZmlsdGVyLnR5cGVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmaWx0ZXIucXVlcnksXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCk9PntcclxuICAgICAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgICAgICBsZXQgcXVlcnkgPSBtb2JqZWN0LnVuZXNjYXBlKGZpbHRlci5xdWVyeSk7XHJcbiAgICAgICAgICBsZXQgZXhhbSA9IHNpZnQoIHF1ZXJ5ICk7XHJcbiAgICAgICAgICBpZiggZXhhbShyZWNvcmQpICl7XHJcbiAgICAgICAgICAgIGNvdW50W2ZpbHRlci50eXBlXS5jb3VudCsrO1xyXG4gICAgICAgICAgICBpZiggdHlwZW9mIGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFja3NbZmlsdGVyLnR5cGVdKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBvbkVycm9yXHJcbiAgICApO1xyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnQ7XHJcblxyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbmNvbnN0IEdyb3VwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdncm91cHMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwQmFzZSB7XHJcblxyXG4gIHByb2ZpbGU7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb2ZpbGUpIHtcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBnZXRzICdQbHVnJyB3aXRjaCBpcyBhIHNldCBvZiBwcm9wZXJ0aWVzIG5lZWRlZFxyXG4gICAqIHdoZW4gY29ubmVjdCB0byBzb21lIHBsYXRmb3Jtc1xyXG4gICAqIHRvIGdldCBkYXRhcyhNZW1iZXJzIG9mIHRoZSBHcm91cClcclxuICAgKi9cclxuICBnZXRQbHVnKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZS5wbGF0Zm9ybVBsdWc7XHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZTtcclxuICB9XHJcblxyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge307XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXAgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihncm91cElkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBHcm91cHMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZ3JvdXBJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKGRvYykgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX0gV0hFUkUgXFxgJHtkb2Mua2V5fVxcYCA9IFwiJHtkb2MuaWR9XCJgO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBncm91cCB0eXBlJyk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7YXN5bmMgKHJlY29yZCk9PnZvaWR9IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IGN1ciA9IEdyb3Vwcy5maW5kKHtcclxuICAgICAgZ3JvdXBJZDogdGhpcy5wcm9maWxlLl9pZFxyXG4gICAgfSwge1xyXG4gICAgICBmaWVsZHM6IHtcclxuICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAga2V5OiAxXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGN1ci5mb3JFYWNoKFxyXG4gICAgICAgICAgYXN5bmMgKGRvYywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVjb3JkID0gYXdhaXQgdGhpcy5pbXBvcnQoZG9jKTtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFjayhyZWNvcmQpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgb25FcnJvcihlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaW5kZXggKyAxID09PSBjdXIuY291bnQoKSkge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICB9XHJcbiAgICApLmNhdGNoKFxyXG4gICAgICAoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbiBcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2Fkcycse2lkR2VuZXJhdGlvbjonTU9OR08nfSk7XHJcblxyXG4iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5cclxuZXhwb3J0IGNsYXNzIEN1YmUzQXBpIHtcclxuICBjb25zdHJ1Y3RvciAobXlzcWwgPSBuZXcgTXlTUUwoKSkge1xyXG4gICAgdGhpcy5teXNxbF8gPSBteXNxbFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHByb2R1Y3RDbGFzc0lkLCBxdWFudGl0eSA9IDApIHtcclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcclxuICAgICAge30sIHtcclxuICAgICAgICBzdG9jazogcXVhbnRpdHksXHJcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJyxcclxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXHJcbiAgICAgIHt9LCB7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RUYWdVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDliYrpmaTjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvZmYgPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDooajnpLrjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvbiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgLy8g44GZ44Gn44Gr6KGo56S644GV44KM44Gm44GE44KL44K/44Kw44GM44GC44KM44Gw5L2V44KC44GX44Gq44GEXHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIFNFTEVDVCBDT1VOVCgqKSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgbGV0IGNvdW50UmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKVxyXG4gICAgICBpZiAoY291bnRSZXNbMF1bJ0NPVU5UKCopJ10pIHJldHVyblxyXG5cclxuICAgICAgcmVzLnB1c2goXHJcbiAgICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAnZHRiX3Byb2R1Y3RfdGFnJyxcclxuICAgICAgICAgIHt9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBkYXRhLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgICAgIHRhZzogdGFnLFxyXG4gICAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKSlcclxuICAgIH1cclxuXHJcbiAgICBmb3IgKGxldCB0YWdTZXQgb2YgZGF0YS50YWdzKSB7XHJcbiAgICAgIHN3aXRjaCAodGFnU2V0LnNldCkge1xyXG4gICAgICAgIGNhc2UgJ29uJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29uKHRhZ1NldC50YWcpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICAgIGNhc2UgJ29mZic6XHJcbiAgICAgICAgICBhd2FpdCB0YWdvZmYodGFnU2V0LnRhZylcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdEltYWdlVXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgcHJvZHVjdElkID0gZGF0YS5wcm9kdWN0X2lkXHJcbiAgICBsZXQgaW1hZ2VzID0gZGF0YS5pbWFnZXNcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDllYblk4HjgavplqLpgKPjgZnjgovjgZnjgbnjgabjga7nlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgotcclxuICAgIGxldCBzcWwgPSBgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfaW1hZ2UgV0hFUkUgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdElkfWBcclxuICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbCkpXHJcblxyXG4gICAgLy8g5pS544KB44Gm55S75YOP44KS55m76Yyy44GX44Gq44GK44GZXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAnZHRiX3Byb2R1Y3RfaW1hZ2UnLCB7XHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICBmaWxlX25hbWU6IGltYWdlc1tpXSxcclxuICAgICAgICAgIHJhbms6IGkgKyAxXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdFVwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fVxyXG4gICAgbGV0IGtleXMgPSBbXVxyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0XHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3N0YXR1cycsXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ25vdGUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fbGlzdCcsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnLFxyXG4gICAgICAnc2VhcmNoX3dvcmQnLFxyXG4gICAgICAnZnJlZV9hcmVhJ1xyXG4gICAgXVxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RfY2xhc3NcclxuXHJcbiAgICB1cGRhdGVEYXRhID0ge31cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdkZWxpdmVyeV9kYXRlX2lkJyxcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdzYWxlX2xpbWl0JyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RDcmVhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBsZXQga2V5cyA9IFtdXHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJ1xyXG4gICAgXVxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiBpdGVtLm5hbWUsXHJcbiAgICAvLyAgIGRlc2NyaXB0aW9uX2RldGFpbDogaXRlbS5kZXNjcmlwdGlvbixcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgc3RhdHVzOiAxLFxyXG4gICAgICAgIG5vdGU6ICdOVUxMJyxcclxuICAgICAgICBkZXNjcmlwdGlvbl9saXN0OiAnTlVMTCcsXHJcbiAgICAgICAgc2VhcmNoX3dvcmQ6ICdOVUxMJyxcclxuICAgICAgICBmcmVlX2FyZWE6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAncHJvZHVjdF9jb2RlJyxcclxuICAgICAgJ3Byb2R1Y3RfdHlwZV9pZCcsXHJcbiAgICAgICdwcmljZTAxJyxcclxuICAgICAgJ3ByaWNlMDInLFxyXG4gICAgICAnZGVsaXZlcnlfZmVlJ1xyXG4gICAgXVxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBwcm9kdWN0X2NvZGU6IGl0ZW0ubW9kZWwsXHJcbiAgICAvLyAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxyXG4gICAgLy8gICBwcmljZTAyOiBpdGVtLnNhbGVzX3ByaWNlLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfY2xhc3NfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBwcm9kdWN0X2lkOiByZXMucHJvZHVjdF9pZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQxOiAnTlVMTCcsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQyOiAnTlVMTCcsXHJcbiAgICAgICAgZGVsaXZlcnlfZGF0ZV9pZDogJ05VTEwnLFxyXG4gICAgICAgIHNhbGVfbGltaXQ6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X3N0b2NrX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsIHt9LCB7XHJcbiAgICAgICAgcHJvZHVjdF9jbGFzc19pZDogcmVzLnByb2R1Y3RfY2xhc3NfaWQsXHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBmb3IgdGVzdFxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJ1xyXG5pbXBvcnQge01vbmdvQ2xpZW50fSBmcm9tICdtb25nb2RiJ1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCdcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnXHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXJGYWN0b3J5IHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgbGV0IGluc3RhbmNlXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgaW5zdGFuY2UgPSBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBpbnN0YW5jZVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgdGhpcy5wbHVnID0gcGx1Z1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZhY3RvcnkgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICByZXR1cm4gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSlcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGx1ZyB0eXBlJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldFBsdWdfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnBsdWdcclxuICB9XHJcblxyXG4gIGdldENyZWRfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnBsdWcuY3JlZFxyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZV8gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZVxyXG4gIH1cclxuXHJcbiAgc2V0SW1wb3J0RnVuY3Rpb25fIChcclxuICAgIGZuID0gYXN5bmMgKG9uUmVzdWx0ID0gcmVjb3JkID0+IHt9LCBvbkVycm9yID0gZSA9PiB7fSkgPT4ge31cclxuICApIHtcclxuICAgIHRoaXMuaW1wb3J0ID0gZm5cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIHVzZWFnZTpcclxuICAgKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHsgT2JqZWN0IH0gaXRlcmF0b3JzIHsgZmlsdGVyTmFtZTogYXN5bmMgKGRvYyxjb250ZXh0KT0+e30sIC4uLiB9IGl0ZXJhdG9yIGZvciBlYWNoIGZpbHRlcnNcclxuICAgKiBAcGFyYW0geyBhc3luYyBmdW5jdGlvbiB9IG9uRXJyb3IgZXJyb3IgaGFuZGxlciB3aGlsZSBpdGVyYXRpbmdcclxuICAgKiBAcmV0dXJucyB7IE9iamVjdCB9IHsgZmlsdGVyTmFtZTogeyBxdWVyeTogYW55LCBjb3VudDogbnVtYmVyIH0sIC4uLiB9XHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaCAoaXRlcmF0b3JzID0ge30pIHtcclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlXygpXHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgbmFtZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ZXIgPSB7fVxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgZmlsdGVycyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgICAgY291bnRlcltmLm5hbWVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmLnF1ZXJ5LFxyXG4gICAgICAgIGxpbWl0OiB0eXBlb2YgZi5saW1pdCAhPT0gJ3VuZGVmaW5lZCcgPyBmLmxpbWl0IDogMCxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9XHJcbiAgICAgIGZpbHRlcnMucHVzaChcclxuICAgICAgICB7XHJcbiAgICAgICAgICBuYW1lOiBmLm5hbWUsXHJcbiAgICAgICAgICBleGFtOiBzaWZ0KG1vYmplY3QudW5lc2NhcGUoZi5xdWVyeSkpXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQsIGNvbnRleHQpID0+IHtcclxuICAgICAgICBmb3IgKGxldCBmIG9mIGZpbHRlcnMpIHtcclxuICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgbGV0IGMgPSBjb3VudGVyW2YubmFtZV1cclxuICAgICAgICAgIGlmIChjLmxpbWl0KSB7XHJcbiAgICAgICAgICAgIGlmIChjLmNvdW50ID49IGMubGltaXQpIHtcclxuICAgICAgICAgICAgICBjb250aW51ZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKGYuZXhhbShyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgICBjLmNvdW50KytcclxuXHJcbiAgICAgICAgICAgIC8vIGl0ZXJhdG9yXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlcmF0b3JzW2YubmFtZV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgaXRlcmF0b3JzW2YubmFtZV0ocmVjb3JkLCBjb250ZXh0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnRlclxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE15c3FsREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpXHJcblxyXG4gICAgbGV0IGNyZWQgPSB0aGlzLmdldENyZWRfKClcclxuXHJcbiAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKGNyZWQpXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gXHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIChlKSA9PiB7IHRocm93IGUgfSlcclxuICAgICAgcmV0dXJuIHJlc1xyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBNb25nb05hdGl2ZSBmcm9tICdtb25nb2RiJztcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSBNb25nb05hdGl2ZS5Nb25nb0NsaWVudDtcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSByZXF1aXJlKCdtb25nb2RiJykuTW9uZ29DbGllbnQ7XHJcblxyXG5leHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICAvLyBtb25nbyDjgbjmjqXntppcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICBsZXQgY2xpZW50XHJcbiAgICAgIGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpXHJcblxyXG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcclxuICAgICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICAgIGxldCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pXHJcblxyXG4gICAgICBsZXQgY29udGV4dCA9IHtcclxuICAgICAgICBjbGllbnQ6IGNsaWVudCxcclxuICAgICAgICBjb2xsZWN0aW9uOiBjb2xsZWN0aW9uLFxyXG4gICAgICAgIGRhdGFiYXNlOiBkYlxyXG4gICAgICB9XHJcblxyXG4gICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKClcclxuXHJcbiAgICAgIC8vIOOCq+ODvOOCveODq+OBruOCv+OCpOODoOOCouOCpuODiOOCkuino+mZpFxyXG4gICAgICBjdXIuYWRkQ3Vyc29yRmxhZygnbm9DdXJzb3JUaW1lb3V0JywgdHJ1ZSlcclxuXHJcbiAgICAgIC8vIOOBmeOBueOBpuOBruODieOCreODpeODoeODs+ODiOOCkuODq+ODvOODl1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XHJcbiAgICAgICAgICBsZXQgZG9jID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQoZG9jLCBjb250ZXh0KVxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgLy8g44Kr44O844K944Or44KS6ZaL5pS+XHJcbiAgICAgICAgYXdhaXQgY3VyLmNsb3NlKClcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBtb25nb29zZSBmcm9tICdtb25nb29zZSc7XHJcblxyXG4vLyBleHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuLy8gICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbi8vICAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcclxuXHJcbi8vICAgICAvLyBtb25nbyDjgbjmjqXntppcclxuLy8gICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpO1xyXG4vLyAgICAgbGV0IGNvbnVyaSA9IGBtb25nb2RiOi8vJHtjcmVkLmhvc3R9OiR7Y3JlZC5wb3J0fS8ke2NyZWQuZGF0YWJhc2V9YDtcclxuLy8gICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoY29udXJpKTtcclxuXHJcbi8vICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLkvZzjgotcclxuLy8gICAgIGxldCBjb2xsZWN0aW9uID0gbW9uZ29vc2UuY29ubmVjdGlvbi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XHJcblxyXG4vLyAgICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbi8vICAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKTtcclxuXHJcbi8vICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4vLyAgICAgfSk7XHJcbi8vICAgfVxyXG4vLyB9XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29Db2xsZWN0aW9uXHJcbn0gZnJvbSAnLi4vdXRpbC9tb25nbydcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vY29sbGVjdGlvbi91cGxvYWRzJ1xyXG5pbXBvcnQge1xyXG4gIE9iamVjdElEXHJcbn0gZnJvbSAnYnNvbidcclxuaW1wb3J0IFRleHRVdGlsIGZyb20gJy4uL3V0aWwvdGV4dCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEl0ZW1Db250cm9sbGVyIHtcclxuICBhc3luYyBpbml0IChwbHVnKSB7XHJcbiAgICB0aGlzLkl0ZW1zID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCAnaXRlbXMnKVxyXG4gICAgdGhpcy5Qcm9kdWN0cyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ3Byb2R1Y3RzJylcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFN0b2NrIChpdGVtSWQpIHtcclxuICAgIGxldCBwcm9qZWN0ID0gYXdhaXQgdGhpcy5JdGVtcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBpdGVtSWRcclxuICAgIH0sIHtcclxuICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICdwcm9kdWN0JzogMVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgbGV0IHByb2R1Y3RQYWNrID0gcHJvamVjdC5wcm9kdWN0XHJcblxyXG4gICAgLy8gcHJvZHVjdCAqIDwtPiAqIGl0ZW1cclxuICAgIC8vIHByb2R1Y3RbXTog6KSH5pWw44Gu5ZWG5ZOB44KSMeODkeODg+OCseODvOOCuOOBqOOBl+OBpuiyqeWjslxyXG4gICAgLy8gcHJvZHVjdFtbXV06IOeVsOOBquOCi+a1gemAmue1jOi3r+OAgeeVsOOBquOCi+WOn+S+oeODu+S7leWFpeOCjOWApFxyXG4gICAgLy8gaXRlbTog55Ww44Gq44KL44K744O844Or44CB6LKp5aOy5b2i5oWLXHJcbiAgICAvLyDigLsgcHJvZHVjdCDjgYvjgonjga/jgIHosqnlo7Llj6/og73jgarlnKjluqvjgIHliKnnm4roqIjnrpfjga7jgZ/jgoHjga7mg4XloLHjgpLlvpfjgotcclxuXHJcbiAgICBsZXQgcXVhbnRpdGllcyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcHJvZHVjdFNrdSBvZiBwcm9kdWN0UGFjaykge1xyXG4gICAgICBsZXQgcXVhbnRpdHlTa3UgPSAwXHJcblxyXG4gICAgICBmb3IgKGxldCBwcm9kdWN0SWQgb2YgcHJvZHVjdFNrdSkge1xyXG4gICAgICAgIGxldCBwcm9qZWN0ID0gYXdhaXQgdGhpcy5Qcm9kdWN0cy5maW5kT25lKHtcclxuICAgICAgICAgIF9pZDogcHJvZHVjdElkXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgICAnc3RvY2snOiAxXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBsZXQgc3RvY2tBcnJheSA9IHByb2plY3Quc3RvY2tcclxuXHJcbiAgICAgICAgLy8g5Y2Y57SU44Gr44GZ44G544Gm44Gu5Zyo5bqr5ZWG5ZOB44CB55+t5pyf6ZaT5Y+W44KK5a+E44Gb5Y+v6IO95ZWG5ZOB44KS5ZCI566XXHJcbiAgICAgICAgZm9yIChsZXQgc3RvY2sgb2Ygc3RvY2tBcnJheSkge1xyXG4gICAgICAgICAgcXVhbnRpdHlTa3UgKz0gc3RvY2sucXVhbnRpdHlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHF1YW50aXRpZXMucHVzaChxdWFudGl0eVNrdSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDjgrvjg4Pjg4jllYblk4Hjga7loLTlkIjjgIHkuIDnlarlsJHjgarjgYTllYblk4HmlbDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBxdWFudGl0eSA9IE1hdGgubWluLmFwcGx5KG51bGwsIHF1YW50aXRpZXMpXHJcblxyXG4gICAgcmV0dXJuIHF1YW50aXR5XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44KL44CCXHJcbiAgICpcclxuICAgKiDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6vjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcclxuICAgKiBjbGFzczHjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOeJueWumuOBruWxnuaAp++8iOOCq+ODqeODvOOBquOBqe+8ieOBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOBq+WApOOCkuaMh+WumuOBl+OAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqIOOCguOBl2NsYXNzMuOBruOBv+aMh+WumuOBl+OBn+OBhOWgtOWQiOOBr2NsYXNzMeOBq251bGzjgpLmjIflrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS+i++8mkpLLTEwMOOBrkJMQUNL44Gu5ZWG5ZOB55S75YOP44KSXHJcbiAgICog44GZ44G544Gm44Gu44K144Kk44K677yIUyxNLEwsWEwsMlhMLDNYTCw0WEzigKbvvInjgavplqLpgKPku5jjgZHjgovloLTlkIhcclxuICAgKiBzZXRJbWFnZSggdXBsb2FkSWQsICdKSy0xMDAnLCAnQkxBQ0snICk7XHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdXBsb2FkSWQg5LiA5Zue44Gu44Ki44OD44OX44Ot44O844OJ55S75YOP44KS5p2f44Gt44Gm44GE44KLSUTjgIJtZXRlb3Ljg4fjg7zjgr/jg5njg7zjgrnjgIFVcGxvYWRz44Kz44Os44Kv44K344On44Oz5YaF44OJ44Kt44Ol44Oh44Oz44OI44GudXBsb2FkSWTjg5fjg63jg5Hjg4bjgqNcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIHNldEltYWdlICh1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OBruaDheWgseWPluW+l1xyXG4gICAgbGV0IGltYWdlcyA9IFVwbG9hZHMuZmluZCh7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZFxyXG4gICAgfSkuZmV0Y2goKS5tYXAoKHYpID0+IHYudXBsb2FkZWRGaWxlTmFtZSlcclxuXHJcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcclxuICAgIGxldCBmaWx0ZXIgPSB7fVxyXG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWxcclxuICAgIGlmIChjbGFzczEpIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczFcclxuICAgIGlmIChjbGFzczIpIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczJcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxyXG4gICAgICBmaWx0ZXIsIHtcclxuICAgICAgICAkcHVzaDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiB7XHJcbiAgICAgICAgICAgICRlYWNoOiBpbWFnZXNcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyDnmbvpjLLjgZfjgZ/nlLvlg4/jg5XjgqHjgqTjg6vlkI3kuIDopqdcclxuICAgIHJldHVybiBpbWFnZXNcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavnmbvpjLLjgZXjgozjgabjgYTjgovnlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgY2xlYW5JbWFnZSAobW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlciwge1xyXG4gICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgIGltYWdlczogW11cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBruWVhuWTgeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBruWxnuaAp+WIpeOBruWVhuWTgeaDheWgseOCkui/lOOBmeOAglxyXG4gICAqXHJcbiAgICog5byV5pWw44Go44GX44Gm5Y+X44GR5Y+W44KLaXRlbeOBr+S7u+aEj+OBruWVhuWTgeaDheWgseOAglxyXG4gICAqIGl0ZW3jgavplqLpgKPjgZnjgovllYblk4HnvqTjgavjgaTjgYTjgablv4XopoHjgarmg4XloLHjgpLmlbTnkIbjgZfov5TjgZnjgIJcclxuICAgKlxyXG4gICAqIHByb2plY3Tjgavlj4LnhafjgZfjgZ/jgYTllYblk4Hmg4XloLHjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZnjgovjgIJcclxuICAgKiDjg6Hjgr3jg4Pjg4njga7lkbzjgbPlh7rjgZfmmYLjgavlv4XopoHjgavlv5zjgZjjgaZwcm9qZWN044KS6Kit5a6a44GZ44KL44CCXHJcbiAgICpcclxuICAgKiDkvZXjgavms6jnm67jgZfjgabllYblk4Hjga7plqLpgKPmgKfjgpLmpJzlh7rjgZnjgovjgYvjga/jgIHjgZPjga7jg6Hjgr3jg4Pjg4nlhoXjgaflrprnvqnjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBpdGVtXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHByb2plY3RcclxuICAgKi9cclxuICBhc3luYyBnZXRWYXJpYXRpb24gKGl0ZW0sIHByb2plY3QpIHtcclxuICAgIC8qKlxyXG4gICAgICogYWdncmVnYXRpb27oqK3lrppcclxuICAgICAqXHJcbiAgICAgKiBsYWJlbDog5bGe5oCn5ZCN77yI6YWN6YCB5pa55rOV44CB44Kr44Op44O844CB44K144Kk44K644Gq44Gp77yJXHJcbiAgICAgKiBjdXJyZW50OiDmjIflrprjgZXjgozjgZ/jgqLjgqTjg4bjg6DvvIhpdGVt77yJ44GM6Kmy5b2T44GZ44KL6aCF55uuXHJcbiAgICAgKiBwb3JqZWN0OiDjg5Djg6rjgqjjg7zjgrfjg6fjg7PmpJzntKLjga7jgq3jg7zjgajjgarjgotpdGVt5YaF44Gu44OV44Kj44O844Or44OJ5ZCNICRb44OV44Kj44O844Or44OJ5ZCNXeW9ouW8j1xyXG4gICAgICogcXVlcnk6IGFnZ3JlZ2F0aW9u5a++6LGh44Go44GZ44KL44OJ44Kt44Ol44Oh44Oz44OI44Gu5qSc57Si5p2h5Lu2XHJcbiAgICAgKi9cclxuICAgIGxldCBzZXQgPSBbe1xyXG4gICAgICBsYWJlbDogJ+mFjemAgeaWueazlScsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRkZWxpdmVyeSdcclxuICAgICAgfSxcclxuICAgICAgcXVlcnk6IHtcclxuICAgICAgICBjbGFzczFfdmFsdWU6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxyXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MxX25hbWUsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckY2xhc3MxX3ZhbHVlJ1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MyX25hbWUsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MyX3ZhbHVlLFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckY2xhc3MyX3ZhbHVlJ1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgXVxyXG5cclxuICAgIGxldCBhdHRycyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcyBvZiBzZXQpIHtcclxuICAgICAgYXR0cnMucHVzaCh7XHJcbiAgICAgICAgdmFyaWF0aW9uczogYXdhaXQgdGhpcy5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbe1xyXG4gICAgICAgICAgICAkbWF0Y2g6IE9iamVjdC5hc3NpZ24ocy5xdWVyeSwge1xyXG4gICAgICAgICAgICAgIG1vZGVsOiBpdGVtLm1vZGVsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAkcHJvamVjdDogT2JqZWN0LmFzc2lnbihzLnByb2plY3QsIHByb2plY3QpXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAkc29ydDoge1xyXG4gICAgICAgICAgICAgIF9pZDogMVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKS50b0FycmF5KCksXHJcbiAgICAgICAgcHJvcHM6IHNcclxuICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gYXR0cnNcclxuICB9XHJcblxyXG4gIC8vIOODouODh+ODq+OCr+ODqeOCueW9ouW8j+OCkuS9nOOCi1xyXG4gIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cclxuICBhc3luYyBnZXRNb2RlbENsYXNzIChhcmcpIHtcclxuICAgIGxldCBpdGVtXHJcbiAgICAvLyBpdGVtIOOBjOaWh+Wtl+WIl+OBquOCieOAgWl0ZW3jga/ku7vmhI/jga7jgqrjg5bjgrjjgqfjgq/jg4hJROOBruacq+WwvuOBi+OCieS7u+aEj+OBruahgeaVsOOBrjE26YCy5pWwXHJcbiAgICBpZiAodHlwZW9mIGFyZyA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgbGV0IGV4cCA9IG5ldyBSZWdFeHAoYCR7YXJnfSRgKVxyXG4gICAgICBsZXQgY3VyID0gdGhpcy5JdGVtcy5maW5kKHt9LCB7XHJcbiAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgbW9kZWw6IDEsXHJcbiAgICAgICAgICBjbGFzczFfdmFsdWU6IDEsXHJcbiAgICAgICAgICBjbGFzczJfdmFsdWU6IDFcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICB3aGlsZSAoMSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBpdGVtID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICAgICAgbGV0IG1hdGNoID0gYXdhaXQgaXRlbS5faWQudG9IZXhTdHJpbmcoKS5tYXRjaChleHApXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyDoqbLlvZPjgZnjgotpdGVt44OH44O844K/44GM44Gq44GEXHJcbiAgICAgICAgICByZXR1cm4gYXJnXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpdGVtID0gYXJnXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuICAgIHJldHVybiBtb2RlbENsYXNzLmpvaW4oJy8nKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlMyAoY3JlYXRvcklkLCBpdGVtKSB7XHJcbiAgICAvLyDlgKTlpInmj5tcclxuICAgIGxldCBjb252RGVsaXYgPSAoZGVsaXZlcnkpID0+IGRlbGl2ZXJ5ID09PSAn44KG44GG44OR44Kx44OD44OIJyA/ICfjg53jgrnjg4jmipXlh70nIDogZGVsaXZlcnlcclxuXHJcbiAgICAvLyBwcm9kdWN0X2lkXHJcbiAgICBsZXQgcHJvZHVjdElkID0gbnVsbFxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG5cclxuICAgIC8vIOS4i+iomOOBruW9ouW8j+OCkuS9nOOCi1xyXG4gICAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuXHJcbiAgICAvLyDllYblk4HnqK7liKXjgpLlibLjgorlvZPjgabjgotcclxuICAgIGxldCBwcm9kdWN0VHlwZUlkXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDJcclxuICAgICAgICBicmVha1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCB0YWdzID0gW11cclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeWIpemAgeaWmeOCkuioreWumuOBmeOCi1xyXG4gICAgbGV0IGRlbGl2ZXJ5RmVlID0gbnVsbFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBudWxsXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICBkZWxpdmVyeUZlZSA9IDI0MFxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy9cclxuICAgIC8vIOmhp+WuouWQkeOBkeODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgemBuOaKnuapn+iDveOBruWun+ijhVxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6ICckbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJ1xyXG4gICAgfSlcclxuXHJcbiAgICAvLyBIVE1MIOODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgeOBlOOBqOOBruODquODs+OCr+S7mOOBjeODnOOCv+ODs+OCkuihqOekuuOBmeOCi1xyXG5cclxuICAgIC8vIOWApOOBruWkieaPm1xyXG4gICAgYXR0cnMgPSBhdHRycy5tYXAoXHJcbiAgICAgIChhdHRyKSA9PiB7XHJcbiAgICAgICAgYXR0ci5wcm9wcy5jdXJyZW50ID0gY29udkRlbGl2KGF0dHIucHJvcHMuY3VycmVudClcclxuICAgICAgICBhdHRyLnZhcmlhdGlvbnMgPSBhdHRyLnZhcmlhdGlvbnMubWFwKFxyXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xyXG4gICAgICAgICAgICB2YXJpYXRpb24udmFsdWUgPSBjb252RGVsaXYodmFyaWF0aW9uLnZhbHVlKVxyXG4gICAgICAgICAgICByZXR1cm4gdmFyaWF0aW9uXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIHJldHVybiBhdHRyXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBIVE1M55Sf5oiQXHJcbiAgICBsZXQgdmFyaWF0aW9uSHRtbCA9XHJcbiAgICAgIGF0dHJzLm1hcChcclxuICAgICAgICAoYXR0cikgPT5cclxuICAgICAgICAgICc8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWZsdWlkXCI+JyArXHJcbiAgICAgICAgYDxkaXYgY2xhc3M9XCJyb3dcIj5gICtcclxuICAgICAgICBgPGRpdiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLWJsb2NrIGJ0bi14c1wiPmAgK1xyXG4gICAgICAgIGA8c3Ryb25nPiR7YXR0ci5wcm9wcy5sYWJlbH08L3N0cm9uZz5gICtcclxuICAgICAgICBgPC9kaXY+YCArXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgaWYgKGF0dHIucHJvcHMuY3VycmVudCA9PT0gdmFyaWF0aW9uLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YSBocmVmPVwiL3Byb2R1Y3RzL2RldGFpbC8ke3ZhcmlhdGlvbi5wcm9kdWN0X2lkfVwiPjxidXR0b24gY2xhc3M9XCJidG4gYnRuLXN1Y2Nlc3MgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPjxzdHJvbmc+JHt2YXJpYXRpb24udmFsdWV9PC9zdHJvbmc+PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICByZXR1cm4gYDxhIGhyZWY9XCIvcHJvZHVjdHMvZGV0YWlsLyR7dmFyaWF0aW9uLnByb2R1Y3RfaWR9XCI+PGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICkuam9pbignJykgK1xyXG4gICAgICAgICc8L2Rpdj4nICtcclxuICAgICAgICAnPC9kaXY+J1xyXG4gICAgICApLmpvaW4oJycpXHJcblxyXG4gICAgbGV0IGRlc2NyaXB0aW9uRGV0YWlsID0gYFxyXG4gICAgPHNtYWxsPuKAuyDphY3pgIHmlrnms5Xjg7vjgqvjg6njg7zjg7vjgrXjgqTjgrrjga/kuIvoqJjjgYvjgonjgYrpgbjjgbPjgY/jgaDjgZXjgYTjgII8L3NtYWxsPlxyXG4gICAgPHNtYWxsIGNsYXNzPVwidGV4dC1kYW5nZXJcIj7igLsg5Zyo5bqr44GM44Gq44GE5ZWG5ZOB44Gu5aC05ZCI44CM44Oa44O844K444GM6KaL44Gk44GL44KK44G+44Gb44KT44CN44Go6KGo56S644GV44KM44G+44GZ44CCPC9zbWFsbD5cclxuICAgICR7dmFyaWF0aW9uSHRtbH1cclxuICAgIGBcclxuXHJcbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcclxuICAgIGxldCBkYXRhID0ge1xyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7Y29udkRlbGl2KGl0ZW0uZGVsaXZlcnkpfSAke2l0ZW0ubmFtZX0gJHtpdGVtLmphbl9jb2RlfWAsXHJcbiAgICAgIGRlc2NyaXB0aW9uX2RldGFpbDogZGVzY3JpcHRpb25EZXRhaWwsXHJcbiAgICAgIGZyZWVfYXJlYTogaXRlbS5kZXNjcmlwdGlvbiArICcgJyxcclxuICAgICAgcHJvZHVjdF9jb2RlOiBtb2RlbENsYXNzLmpvaW4oJy8nKSxcclxuICAgICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UgKiAwLjk1LCAvLyDmpb3lpKnkvqHmoLzjgYvjgok1JeWApOW8leOBjVxyXG4gICAgICBpbWFnZXM6IGl0ZW0uaW1hZ2VzLFxyXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RUeXBlSWQsXHJcbiAgICAgIHRhZ3M6IHRhZ3MsXHJcbiAgICAgIGRlbGl2ZXJ5X2ZlZTogZGVsaXZlcnlGZWVcclxuICAgIH1cclxuXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcClcclxuXHJcbiAgICByZXR1cm4gZGF0YVxyXG4gIH1cclxuXHJcbiAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44G444Gu5aSJ5o+bXHJcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdCAoZGVmLCBpdGVtKSB7XHJcbiAgICBjb25zdCBpZExlbmd0aCA9IDIwXHJcbiAgICBjb25zdCB0aXRsZUxlbmd0aCA9IDEzMFxyXG5cclxuICAgIGxldCB5YXVjdCA9IHt9XHJcbiAgICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjga7liJ3mnJ/lgKTvvIjjgobjgYbjg5HjgrHjg4Pjg4jjg7vlroXphY3kvr/jgafnlbDjgarjgovvvIlcclxuICAgIHlhdWN0ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkZWZbaXRlbS5kZWxpdmVyeV0pKVxyXG5cclxuICAgIC8vIOeUu+WDj+OBruiomOi/sFxyXG4gICAgY29uc3QgaW1nUHJlZml4ID0gJ+eUu+WDjydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgeWF1Y3RbaW1nUHJlZml4ICsgKGkgKyAxKV0gPSBpdGVtLmltYWdlc1tpXVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCv+OCpOODiOODq1xyXG4gICAgeWF1Y3RbJ+OCq+ODhuOCtOODqiddID0gaXRlbS5tYWxsLnlhdWN0LmNhdGVnb3J5XHJcbiAgICB5YXVjdFsn44K/44Kk44OI44OrJ10gPSBUZXh0VXRpbC5zdWJzdHI4KGAke2F3YWl0IHRoaXMuZ2V0TW9kZWxDbGFzcyhpdGVtKX0gJHtpdGVtLmRlbGl2ZXJ5fSAke2l0ZW0ubmFtZX1gLCB0aXRsZUxlbmd0aClcclxuICAgIHlhdWN0Wyfplovlp4vkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfljbPmsbrkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfnrqHnkIbnlarlj7cnXSA9IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkuc2xpY2UoLWlkTGVuZ3RoKVxyXG4gICAgeWF1Y3RbJ+iqrOaYjiddID0gaXRlbS5kZXNjcmlwdGlvblxyXG4gICAgeWF1Y3RbJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXSA9IGl0ZW0uamFuX2NvZGVcclxuXHJcbiAgICByZXR1cm4geWF1Y3RcclxuICB9XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgdXRpbEVycm9yIHtcclxuICBzdGF0aWMgcGFyc2UgKGUpIHtcclxuICAgIGxldCByZXMgPSB7fVxyXG5cclxuICAgIGlmIChlIGluc3RhbmNlb2YgRXJyb3IpIHtcclxuICAgICAgcmVzLm1lc3NhZ2UgPSBlLm1lc3NhZ2VcclxuICAgICAgcmVzLm5hbWUgPSBlLm5hbWVcclxuICAgICAgcmVzLmZpbGVOYW1lID0gZS5maWxlTmFtZVxyXG4gICAgICByZXMubGluZU51bWJlciA9IGUubGluZU51bWJlclxyXG4gICAgICByZXMuY29sdW1uTnVtYmVyID0gZS5jb2x1bW5OdW1iZXJcclxuICAgICAgcmVzLnN0YWNrID0gZS5zdGFja1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmVzID0gZVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiByZXNcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tICdtb25nb2RiJ1xyXG5cclxuZXhwb3J0IGNsYXNzIE1vbmdvQ29sbGVjdGlvbiB7XHJcbiAgc3RhdGljIGFzeW5jIGdldCAocGx1ZywgY29sbGVjdGlvbikge1xyXG4gICAgbGV0IGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpXHJcbiAgICBsZXQgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSlcclxuICAgIHJldHVybiBkYi5jb2xsZWN0aW9uKGNvbGxlY3Rpb24pXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCBteXNxbCBmcm9tICdteXNxbCdcclxuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNeVNRTCB7XHJcbiAgY29uc3RydWN0b3IgKHByb2ZpbGUpIHtcclxuICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+ODl+ODvOODq+WIneacn+WMllxyXG4gICAgdGhpcy5wb29sID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlKVxyXG5cclxuICAgIC8vIOikh+aVsOihjOOCueODhuODvOODiOODoeODs+ODiOWvvuW/nFxyXG4gICAgbGV0IHByb2ZpbGVNdWx0aSA9IHttdWx0aXBsZVN0YXRlbWVudHM6IHRydWV9XHJcbiAgICBPYmplY3QuYXNzaWduKHByb2ZpbGVNdWx0aSwgcHJvZmlsZSlcclxuICAgIHRoaXMucG9vbE11bHRpID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlTXVsdGkpXHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZm9ybWF0RGF0ZSAoZGF0ZSkge1xyXG4gICAgcmV0dXJuIG1vbWVudChkYXRlKS5mb3JtYXQoKS5zdWJzdHJpbmcoMCwgMTkpLnJlcGxhY2UoJ1QnLCAnICcpXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzcWxcclxuICAgKi9cclxuICBxdWVyeSAoc3FsKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pnorrnq4tcclxuICAgIC8vIGxldCBjb24gPSBhd2FpdCB0aGlzLmdldENvbigpO1xyXG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcclxuICAgICAgLnRoZW4oXHJcbiAgICAgICAgKGNvbikgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAgICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXHJcbiAgICAgICAgICAgICAgY29uLnF1ZXJ5KHNxbCwgKGUsIHJlcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8g44Kz44ON44Kv44K344On44Oz6ZaL5pS+XHJcbiAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpXHJcbiAgICAgICAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICAgICAgICByZWplY3QoZSlcclxuICAgICAgICAgICAgICAgIH0gZWxzZSByZXNvbHZlKHJlcylcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGVcclxuICAgICAgfSlcclxuICB9O1xyXG5cclxuICBhc3luYyBxdWVyeUluc2VydF8gKHNxbCkge1xyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZFxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdGFibGVcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7zjgIFudWxs44CBamF2YXNjcmlwdC0+bXlzcWzml6Xku5jlpInmj5vjgavjgoLlr77lv5xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICBhc3luYyBxdWVyeUluc2VydCAodGFibGUsIGRhdGEgPSB7fSwgZGF0YVNxbCA9IHt9KSB7XHJcbiAgICAvLyBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xyXG4gICAgLy8gcmV0dXJuIHJlcy5pbnNlcnRJZDtcclxuXHJcbiAgICBsZXQgc3FsID0gYElOU0VSVCBJTlRPICR7dGFibGV9IGBcclxuXHJcbiAgICBsZXQgbWFwID0gbmV3IE1hcCgpXHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdID09PSBudWxsKSB7XHJcbiAgICAgICAgbWFwLnNldChrLCAnTlVMTCcpXHJcbiAgICAgIH0gZWxzZSBpZiAoZGF0YVtrXS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnRGF0ZScpIHtcclxuICAgICAgICAvLyDml6Xku5jjgpLlpInmj5tcclxuICAgICAgICBtYXAuc2V0KGssIGBcIiR7TXlTUUwuZm9ybWF0RGF0ZShkYXRhW2tdKX1cImApXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbWFwLnNldChrLCBgJHtteXNxbC5lc2NhcGUoZGF0YVtrXSl9YClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xyXG4gICAgICBtYXAuc2V0KGssIGRhdGFTcWxba10gPT09IG51bGwgPyAnTlVMTCcgOiBkYXRhU3FsW2tdKVxyXG4gICAgfVxyXG5cclxuICAgIHNxbCArPSBgKCAke1suLi5tYXAua2V5cygpXS5qb2luKCcsJyl9ICkgYFxyXG5cclxuICAgIHNxbCArPSBgVkFMVUVTKCAke1suLi5tYXAudmFsdWVzKCldLmpvaW4oJywnKX0gKSBgXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZFxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdGFibGVcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gZmlsdGVyIFNRTCBVUERBVEXjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjga5XSEVSReWPpVxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhU3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xyXG4gICAqL1xyXG4gIGFzeW5jIHF1ZXJ5VXBkYXRlICh0YWJsZSwgZmlsdGVyLCBkYXRhLCBkYXRhU3FsKSB7XHJcbiAgICBsZXQgc3FsID0gYFVQREFURSAke3RhYmxlfSBTRVQgYFxyXG5cclxuICAgIGxldCB1cGRhdGVzID0gW11cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YSkpIHtcclxuICAgICAgdXBkYXRlcy5wdXNoKGAke2t9PSR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApXHJcbiAgICB9XHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGFTcWwpKSB7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke2RhdGFTcWxba119YClcclxuICAgIH1cclxuICAgIHNxbCArPSB1cGRhdGVzLmpvaW4oJywnKVxyXG5cclxuICAgIHNxbCArPSBgIFdIRVJFICR7ZmlsdGVyfSBgXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbiAgLy8gZW5hYmxlIHRvIHVzZSBtdWx0aXBsZSBzdGF0ZW1lbnRzXHJcbiAgYXN5bmMgcXVlcnlNdWx0aSAoc3FsKSB7XHJcbiAgICBsZXQgcG9vbFN3YXAgPSB0aGlzLnBvb2xcclxuICAgIHRoaXMucG9vbCA9IHRoaXMucG9vbE11bHRpXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICAgIHJldHVybiByZXNcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHRoaXMucG9vbCA9IHBvb2xTd2FwXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBzdGFydFRyYW5zYWN0aW9uICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYFNUQVJUIFRSQU5TQUNUSU9OO2ApXHJcbiAgfVxyXG5cclxuICBhc3luYyBjb21taXQgKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgQ09NTUlUO2ApXHJcbiAgfVxyXG5cclxuICBhc3luYyByb2xsYmFjayAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBST0xMQkFDSztgKVxyXG4gIH1cclxuXHJcbiAgc3RyZWFtaW5nUXVlcnkgKHNxbCwgb25SZXN1bHQgPSAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IChlKSA9PiB7fSkge1xyXG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcclxuICAgICAgLnRoZW4oXHJcbiAgICAgICAgKGNvbikgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAgICAgICBhc3luYyAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXHJcbiAgICAgICAgICAgICAgY29uLnF1ZXJ5KHNxbClcclxuICAgICAgICAgICAgICAgIC5vbigncmVzdWx0JyxcclxuICAgICAgICAgICAgICAgICAgKHJlY29yZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbi5wYXVzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgb25SZXN1bHQocmVjb3JkKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbi5yZXN1bWUoKVxyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlcnJvcicsIChlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIG9uRXJyb3IoZSlcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2VuZCcsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxyXG4gICAgICAgICAgICAgICAgICByZXNvbHZlKClcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZVxyXG4gICAgICB9KVxyXG4gIH1cclxuXHJcbiAgZ2V0Q29uICgpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIC8vIOODl+ODvOODq+OBi+OCieOBruOCs+ODjeOCr+OCt+ODp+ODs+eNsuW+l1xyXG4gICAgICAgIHRoaXMucG9vbC5nZXRDb25uZWN0aW9uKChlLCBjb24pID0+IHtcclxuICAgICAgICAgIGlmIChlKSB7XHJcbiAgICAgICAgICAgIHJlamVjdChlKVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVzb2x2ZShjb24pXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgICAuY2F0Y2goXHJcbiAgICAgICAgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICB9O1xyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIFBhY2tldCB7XHJcbiAgY29uc3RydWN0b3IgKHBhY2tldFNpemUpIHtcclxuICAgIHRoaXMucGFja2V0U2l6ZSA9IHBhY2tldFNpemVcclxuICAgIHRoaXMub25QYWNrZXRTdGFydCA9IG51bGxcclxuICAgIHRoaXMub25QYWNrZXQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0RW5kID0gbnVsbFxyXG4gICAgdGhpcy5jb3VudCA9IDBcclxuICAgIHRoaXMucGFja2V0Q291bnQgPSAwXHJcbiAgfVxyXG5cclxuICBhc3luYyBzdWJtaXQgKGFyZykge1xyXG4gICAgLy8gcGFja2V0U2l6ZeOBruWbnuaVsOOBlOOBqOOBq+OAgeWIneacn+WMluOCkuWRvOOBs+WHuuOBmVxyXG4gICAgaWYgKHRoaXMuY291bnQgJSB0aGlzLnBhY2tldFNpemUgPT09IDApIHtcclxuICAgICAgaWYgKHRoaXMub25QYWNrZXRTdGFydCkge1xyXG4gICAgICAgIGF3YWl0IHRoaXMub25QYWNrZXRTdGFydCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAodGhpcy5vblBhY2tldCkge1xyXG4gICAgICBhd2FpdCB0aGlzLm9uUGFja2V0KGFyZylcclxuICAgIH1cclxuICAgIHRoaXMuY291bnQrK1xyXG4gICAgLy8gcGFja2V0U2l6ZeOBruWbnuaVsOOBlOOBqOOBq+OAgee1guS6huWHpueQhuOCkuWRvOOBs+WHuuOBmVxyXG4gICAgaWYgKHRoaXMuY291bnQgJSB0aGlzLnBhY2tldFNpemUgPT09IDApIHtcclxuICAgICAgdGhpcy5jbG9zZSgpXHJcbiAgICAgIHRoaXMucGFja2V0Q291bnQrK1xyXG4gICAgfVxyXG4gIH1cclxuICBjbG9zZSAoKSB7XHJcbiAgICBpZiAodGhpcy5vblBhY2tldEVuZCkge1xyXG4gICAgICB0aGlzLm9uUGFja2V0RW5kKHRoaXMucGFja2V0Q291bnQpXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB1dGlsRXJyb3IgZnJvbSAnLi9lcnJvcidcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZXBvcnQge1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMucmVjb3JkID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3JzID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3IgPSBudWxsXHJcbiAgfVxyXG5cclxuICBzZXR1cEl0ZXJhdG9yICgpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IoKVxyXG4gICAgdGhpcy5pdGVyYXRvcnMucHVzaCh0aGlzLml0ZXJhdG9yKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGhhc2UgKG5hbWUgPSAnJywgZm4gPSBhc3luYyAoKSA9PiB7fSkge1xyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKClcclxuXHJcbiAgICBsZXQgcmVjID0ge31cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgZm4oKVxyXG5cclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnc3VjY2VzcycsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiByZXNcclxuICAgICAgfSlcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogdXRpbEVycm9yLnBhcnNlKGUpXHJcbiAgICAgIH0pXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci50b3RhbCkge1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgICBpdGVyYXRvcjogdGhpcy5pdGVyYXRvclxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5yZWNvcmQucHVzaChyZWMpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpU3VjY2VzcyAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLnN1Y2Nlc3MobmV3UmVjb3JkKVxyXG4gIH1cclxuXHJcbiAgaUVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IuZXJyb3IodXRpbEVycm9yLnBhcnNlKG5ld1JlY29yZCkpXHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQgKCkge1xyXG4gICAgbGV0IGl0ZUVycm9yID0gdGhpcy5pdGVyYXRvcnMuZmluZChlID0+IGUuZXJyb3JPY3VycmVkKCkpXHJcbiAgICBsZXQgcGhhRXJyb3IgPSBmYWxzZVxyXG4gICAgZm9yIChsZXQgcmVjIG9mIHRoaXMucmVjb3JkKSB7XHJcbiAgICAgIGlmIChyZWMudHlwZSA9PT0gJ2Vycm9yJykge1xyXG4gICAgICAgIHBoYUVycm9yID0gdHJ1ZVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBpdGVFcnJvciB8fCBwaGFFcnJvclxyXG4gIH1cclxuXHJcbiAgcHVibGlzaCAoKSB7XHJcbiAgICBpZiAodGhpcy5lcnJvck9jdXJyZWQoKSkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKHRoaXMucmVjb3JkKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMucmVjb3JkXHJcbiAgfVxyXG59XHJcblxyXG5jbGFzcyBJdGVyYXRvciB7XHJcbiAgY29uc3RydWN0b3IgKCkge1xyXG4gICAgdGhpcy50b3RhbCA9IDBcclxuICAgIHRoaXMudHJhY2UgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IHtcclxuICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICByZWNvcmRzOiBbXVxyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjoge1xyXG4gICAgICAgIHRvdGFsOiAwLFxyXG4gICAgICAgIHJlY29yZHM6IFtdXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLnRyYWNlLnN1Y2Nlc3MucmVjb3Jkcy5wdXNoKG5ld1JlY29yZClcclxuICAgIH1cclxuICAgIHRoaXMudHJhY2Uuc3VjY2Vzcy50b3RhbCsrXHJcbiAgICB0aGlzLnRvdGFsKytcclxuICB9XHJcbiAgZXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgLy8g55u05YmN44Gu44Ko44Op44O844KS5Y+W5b6XXHJcbiAgICBsZXQgbGFzdEVycm9yID0gbnVsbFxyXG4gICAgbGV0IGluZGV4ID0gdGhpcy50cmFjZS5lcnJvci5yZWNvcmRzLmxlbmd0aFxyXG4gICAgaWYgKGluZGV4KSB7XHJcbiAgICAgIGxhc3RFcnJvciA9IHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkc1tpbmRleCAtIDFdXHJcbiAgICB9XHJcblxyXG4gICAgLy8g55u05YmN44Go5ZCM44GY44Ko44Op44O844Gv55yB44GPXHJcbiAgICBpZiAoSlNPTi5zdHJpbmdpZnkobGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkcy5wdXNoKG5ld1JlY29yZClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy50cmFjZS5lcnJvci50b3RhbCsrXHJcbiAgICB0aGlzLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy50cmFjZS5lcnJvci50b3RhbFxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBUZXh0VXRpbCB7XHJcbiAgc3RhdGljIHN1YnN0cjggKHRleHQsIGxlbiwgdHJ1bmNhdGlvbikge1xyXG4gICAgaWYgKHRydW5jYXRpb24gPT09IHVuZGVmaW5lZCkgeyB0cnVuY2F0aW9uID0gJycgfVxyXG4gICAgdmFyIHRleHRBcnJheSA9IHRleHQuc3BsaXQoJycpXHJcbiAgICB2YXIgY291bnQgPSAwXHJcbiAgICB2YXIgc3RyID0gJydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGV4dEFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHZhciBuID0gZXNjYXBlKHRleHRBcnJheVtpXSlcclxuICAgICAgaWYgKG4ubGVuZ3RoIDwgNCkgY291bnQrK1xyXG4gICAgICBlbHNlIGNvdW50ICs9IDJcclxuICAgICAgaWYgKGNvdW50ID4gbGVuKSB7XHJcbiAgICAgICAgcmV0dXJuIHN0ciArIHRydW5jYXRpb25cclxuICAgICAgfVxyXG4gICAgICBzdHIgKz0gdGV4dC5jaGFyQXQoaSlcclxuICAgIH1cclxuICAgIHJldHVybiB0ZXh0XHJcbiAgfVxyXG59XHJcbiJdfQ==
