var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/route/upload/image.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube/cubemig.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 3);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 4);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 5);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let couponCd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let couponName = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discountPrice = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: couponCd,
                coupon_type: 3,
                // 全商品
                coupon_name: couponName,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discountPrice,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                customer_id: record.customer_id,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
        return res;
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/collection.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
      return res;
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.aggregate(query).toArray());
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let ItemController;
module.watch(require("../../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/service/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 5);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  //
  // 商品情報登録と更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              let quantity = Promise.await(itemController.getStock(item._id));
              Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/tooltest.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      const newLocal = Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
        throw e;
      })));
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return newLocal;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/yauct.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
let PassThrough, Transform;
module.watch(require("stream"), {
  PassThrough(v) {
    PassThrough = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 9);
const prefix = 'packet';
const tag = 'yauct';
Meteor.methods({
  //
  // ヤフオク受注ファイル
  [`yauctOrder.order`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク受注', () => Promise.asyncApply(() => {
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        const workdir = `${config.workdir}/order`;
        const r = fsExtra.createReadStream(`${workdir}/${config.loadfile}`);
        const w = fsExtra.createWriteStream(`${workdir}/${config.savefile}`);
        let i = 0;
        r.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
          columns: true
        })).pipe(csv.transform((record, callback) => Promise.asyncApply(() => {
          let err = null; // 管理番号を置き換える

          try {
            record['管理番号'] = Promise.await(itemController.getModelClass(record['管理番号']));
          } catch (e) {
            err = e;
          }

          callback(err, record);
        }))).pipe(csv.stringify({
          header: true
        })).pipe(iconv.decodeStream('UTF-8')).pipe(iconv.encodeStream('SJIS')).pipe(w);
      })));
    });
  },

  //
  // ヤフオク出品ファイル
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク出品', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 繰り返し処理を任意の（packetSize）で分割

        const packet = new Packet(config.packetSize); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // CSVファイルを作成し画像データを収集する場所


        const workdir = `${config.workdir}/work`;
        Promise.await(fsExtra.remove(workdir));
        Promise.await(fsExtra.mkdir(workdir)); // ZIPファイルを保存する場所

        const uploaddir = `${config.workdir}/upload`;
        Promise.await(fsExtra.remove(uploaddir));
        Promise.await(fsExtra.mkdir(uploaddir));
        let cd = null; // パケットフォルダ

        let filename = null; // csvファイル

        let name = null; // パケット番号
        // CSVフィールドを定義し、順番を確定する

        let fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
        let header = fields.map(v => `"${v}"`).join(',') + '\n'; // パケット化開始時

        packet.onPacketStart = packetCount => Promise.asyncApply(() => {
          name = prefix + ('00000' + packetCount).slice(-5);
          cd = `${workdir}/${name}`;
          filename = `${cd}/${config.csvFileName}`;
          Promise.await(fsExtra.mkdir(cd)); // CSVファイルにフィールドを設定する

          Promise.await(fsExtra.appendFile(filename, iconv.encode(header, 'Shift_JIS')));
        }); // パケット化時


        packet.onPacket = arg => Promise.asyncApply(() => {
          let yauct = arg.yauct;
          let item = arg.item; // csvファイルにレコード（商品テンプレート）を追加する

          let record = fields.map(v => {
            return yauct[v] ? `"${yauct[v]}"` : '""';
          }).join(',') + '\n';
          Promise.await(fsExtra.appendFile(filename, iconv.encode(record, 'Shift_JIS'))); // 画像ファイルをコピー

          for (let img of item.images) {
            let imgSrc = `${config.imagedir}/${img}`;
            let imgTgt = `${cd}/${img}`;

            try {
              // 同じファイルがある場合はコピーしない
              Promise.await(fsExtra.access(imgTgt));
            } catch (e) {
              Promise.await(fsExtra.copyFile(imgSrc, imgTgt));
            }
          }
        }); // パケット終了時


        packet.onPacketEnd = packetCount => Promise.asyncApply(() => {
          const zip = archiver('zip');
          const zipname = `${uploaddir}/${name}.zip`;
          const output = fsExtra.createWriteStream(zipname);
          zip.pipe(output);
          zip.directory(cd, false);
          zip.finalize();
        }); // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id)); // itemに定義されている最低必要在庫より多い商品を出品する

            if (quantity >= item.mall.yauct.minQuantity) {
              let yauct = Promise.await(itemController.convertItemYauct(config.default, item));
              Promise.await(packet.submit({
                yauct: yauct,
                item: item
              }));
            }
          })
        }));
        packet.close();
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/configs.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/filters.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/groups.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/uploads.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/cube3api.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  updateStock(productClassId, quantity = 0) {
    return Promise.asyncApply(() => {
      Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      }));
      Promise.await(this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      }));
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = []; // 削除するタグ

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      }); // 表示するタグ


      let tagon = tag => Promise.asyncApply(() => {
        // すでに表示されているタグがあれば何もしない
        let sql = `
      SELECT COUNT(*) FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        let countRes = Promise.await(this.mysql_.query(sql));
        if (countRes[0]['COUNT(*)']) return;
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creatorId,
          create_date: 'NOW()'
        })));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let productId = data.product_id;
      let images = data.images;
      let creatorId = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${productId}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        Promise.await(this.mysql_.queryInsert('dtb_product_image', {
          product_id: productId,
          creator_id: creatorId,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        }));
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let updateData = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      Promise.await(this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      })); // dtb_product_class

      updateData = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      let res = Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      }));
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = {};
      let updateData = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', updateData, {
        creator_id: creatorId,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      updateData = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', updateData, {
        creator_id: creatorId,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creatorId,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/dbfilter.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 3);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 4);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case 'mysql':
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    switch (plug.type) {
      case 'mysql':
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error('invalid plug type');
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   *
   *
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== 'undefined') {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      let res = Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
      return res;
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find(); // カーソルのタイムアウトを解除

      cur.addCursorFlag('noCursorTimeout', true); // すべてのドキュメントをループ

      try {
        while (Promise.await(cur.hasNext())) {
          let doc = Promise.await(cur.next());
          Promise.await(onResult(doc, context));
        }

        ;
      } finally {
        // カーソルを開放
        Promise.await(cur.close());
      }
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/items.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);
let ObjectID;
module.watch(require("bson"), {
  ObjectID(v) {
    ObjectID = v;
  }

}, 2);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(itemId) {
    return Promise.asyncApply(() => {
      let project = Promise.await(this.Items.findOne({
        _id: itemId
      }, {
        projection: {
          'product': 1
        }
      }));
      let productPack = project.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[[]]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let productSku of productPack) {
        let quantitySku = 0;

        for (let productId of productSku) {
          let project = Promise.await(this.Products.findOne({
            _id: productId
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stockArray = project.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stockArray) {
            quantitySku += stock.quantity;
          }
        }

        quantities.push(quantitySku);
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   *
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   *
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   *
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   *
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   *
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }
  /**
   * 指定の商品に関連する商品群の属性別の商品情報を返す。
   *
   * 引数として受け取るitemは任意の商品情報。
   * itemに関連する商品群について必要な情報を整理し返す。
   *
   * projectに参照したい商品情報フィールドを定義する。
   * メソッドの呼び出し時に必要に応じてprojectを設定する。
   *
   * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
   *
   * @param {Object} item
   * @param {Object} project
   */


  getVariation(item, project) {
    return Promise.asyncApply(() => {
      /**
       * aggregation設定
       *
       * label: 属性名（配送方法、カラー、サイズなど）
       * current: 指定されたアイテム（item）が該当する項目
       * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
       * query: aggregation対象とするドキュメントの検索条件
       */
      let set = [{
        label: '配送方法',
        current: item.delivery,
        project: {
          value: '$delivery'
        },
        query: {
          class1_value: item.class1_value,
          class2_value: item.class2_value
        }
      }, {
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          delivery: item.delivery,
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          delivery: item.delivery,
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }, {
            $sort: {
              _id: 1
            }
          }]).toArray()),
          props: s
        });
      }

      return attrs;
    });
  } // モデルクラス形式を作る
  // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]


  getModelClass(arg) {
    return Promise.asyncApply(() => {
      let item; // item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

      if (typeof arg === 'string') {
        let exp = new RegExp(`${arg}$`);
        let cur = this.Items.find({}, {
          projection: {
            model: 1,
            class1_value: 1,
            class2_value: 1
          }
        });

        while (1) {
          try {
            item = Promise.await(cur.next());
            let match = Promise.await(item._id.toHexString().match(exp));

            if (match) {
              break;
            }
          } catch (e) {
            // 該当するitemデータがない
            return arg;
          }
        }
      } else {
        item = arg;
      }

      let modelClass = [];
      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value);
      return modelClass.join('/');
    });
  }

  convertItemCube3(creatorId, item) {
    return Promise.asyncApply(() => {
      // 値変換
      let convDeliv = delivery => delivery === 'ゆうパケット' ? 'ポスト投函' : delivery; // product_id


      let productId = null;
      let modelClass = []; // 下記の形式を作る
      // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]

      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let productTypeId;

      switch (item.delivery) {
        case '宅配便':
          productTypeId = 1;
          break;

        case 'ゆうパケット':
          productTypeId = 2;
          break;

        default:
          productTypeId = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let deliveryFee = null;

      switch (item.delivery) {
        case '宅配便':
          deliveryFee = null;
          break;

        case 'ゆうパケット':
          deliveryFee = 240;
          break;
      } //
      // 顧客向けバリエーション商品選択機能の実装
      //


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      })); // HTML バリエーション商品ごとのリンク付きボタンを表示する
      // 値の変換

      attrs = attrs.map(attr => {
        attr.props.current = convDeliv(attr.props.current);
        attr.variations = attr.variations.map(variation => {
          variation.value = convDeliv(variation.value);
          return variation;
        });
        return attr;
      }); // HTML生成

      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row">` + `<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">` + `<strong>${attr.props.label}</strong>` + `</div>` + attr.variations.map(variation => {
        if (attr.props.current === variation.value) {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-success btn-sm btn-item-class-select"><strong>${variation.value}</strong></button></a>`;
        } else {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-sm btn-item-class-select">${variation.value}</button></a>`;
        }
      }).join('') + '</div>' + '</div>').join('');
      let descriptionDetail = `
    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>
    <small class="text-danger">※ 在庫がない商品の場合「ページが見つかりません」と表示されます。</small>
    ${variationHtml}
    `; // 商品データを作る

      let data = {
        product_id: productId,
        creator_id: creatorId,
        name: `${modelClass.join('/')} ${convDeliv(item.delivery)} ${item.name} ${item.jan_code}`,
        description_detail: descriptionDetail,
        free_area: item.description + ' ',
        product_code: modelClass.join('/'),
        price01: item.retail_price,
        price02: item.sales_price * 0.95,
        // 楽天価格から5%値引き
        images: item.images,
        product_type_id: productTypeId,
        tags: tags,
        delivery_fee: deliveryFee
      };
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  } // ヤフオクテンプレートへの変換


  convertItemYauct(def, item) {
    return Promise.asyncApply(() => {
      let yauct = {}; // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）

      yauct = def[item.delivery]; // 画像の記述

      const imgPrefix = '画像';

      for (let i = 0; i < item.images.length; i++) {
        yauct[imgPrefix + (i + 1)] = item.images[i];
      } // タイトル


      yauct['カテゴリ'] = item.mall.yauct.category;
      yauct['タイトル'] = `${Promise.await(this.getModelClass(item))} ${item.delivery} ${item.name}`;
      yauct['開始価格'] = item.sales_price;
      yauct['即決価格'] = item.sales_price;
      yauct['管理番号'] = item._id.toHexString().slice(-20);
      yauct['説明'] = item.description;
      yauct['JANコード・ISBNコード'] = item.jan_code;
      return yauct;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/error.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mongo.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mysql.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   *
   * @param {String} sql
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, dataSql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(dataSql)) {
        map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, dataSql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(dataSql)) {
        updates.push(`${k}=${dataSql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/packet.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Packet
});

class Packet {
  constructor(packetSize) {
    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  submit(arg) {
    return Promise.asyncApply(() => {
      // packetSizeの回数ごとに、初期化を呼び出す
      if (this.count % this.packetSize === 0) {
        if (this.onPacketStart) {
          Promise.await(this.onPacketStart(this.packetCount));
        }
      }

      if (this.onPacket) {
        Promise.await(this.onPacket(arg));
      }

      this.count++; // packetSizeの回数ごとに、終了処理を呼び出す

      if (this.count % this.packetSize === 0) {
        if (this.onPacketEnd) {
          Promise.await(this.onPacketEnd(this.packetCount));
        }

        this.packetCount++;
      }
    });
  }

  close() {
    this.onPacketEnd(this.packetCount);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/report.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  setupIterator() {
    this.iterator = new Iterator();
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.setupIterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    // 直前のエラーを取得
    let lastError = null;
    let index = this.trace.error.records.length;

    if (index) {
      lastError = this.trace.error.records[index - 1];
    } // 直前と同じエラーは省く


    if (JSON.stringify(lastError) !== JSON.stringify(newRecord)) {
      if (newRecord && newRecord !== {} && newRecord !== '') {
        this.trace.error.records.push(newRecord);
      }
    }

    this.trace.error.total++;
    this.total++;
  }

  errorOcurred() {
    return this.trace.error.total;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90b29sdGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3lhdWN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyJdLCJuYW1lcyI6WyJmcyIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsImRlZmF1bHQiLCJ2IiwidW5pcWlkIiwibXVsdGlwYXJ0eSIsIlVwbG9hZHMiLCJtdWx0aXBhcnR5TWlkZGxld2FyZSIsInJvdXRlIiwiV2ViQXBwIiwiY29ubmVjdEhhbmRsZXJzIiwidXNlIiwicmVxIiwicmVzcCIsInJlYWRlciIsIk1ldGVvciIsIndyYXBBc3luYyIsInJlYWRGaWxlIiwid3JpdGVyIiwid3JpdGVGaWxlIiwidXBsb2FkSWQiLCJmaWxlIiwiZmlsZXMiLCJkYXRhIiwicGF0aCIsImZpbGVuYW1lIiwic2F2ZVBhdGgiLCJib2R5IiwiaW1hZ2VkaXIiLCJkb2MiLCJjbGllbnRGaWxlTmFtZSIsIm5hbWUiLCJ1cGxvYWRlZEZpbGVOYW1lIiwiZXJyIiwiZXJyb3IiLCJpbnNlcnQiLCJ3cml0ZUhlYWQiLCJlbmQiLCJKU09OIiwic3RyaW5naWZ5Iiwic2F2ZURpciIsImNyeXB0byIsIk15U1FMIiwiUmVwb3J0IiwiR3JvdXAiLCJHcm91cEZhY3RvcnkiLCJGaWx0ZXIiLCJ0YWciLCJtZXRob2RzIiwiY29uZmlnIiwicmVwb3J0IiwiZmlsdGVyIiwic3JjRmlsdGVySWQiLCJ0ZXN0UXVlcnkiLCJkc3REYiIsImRzdCIsImNyZWQiLCJwaGFzZSIsInF1ZXJ5IiwicmVzIiwiZm9yZWFjaCIsIm1vYmlsZU51bGwiLCJyZWNvcmQiLCJzcWwiLCJjdXN0b21lcl9pZCIsInN0YXR1cyIsInNleCIsImpvYiIsImNvdW50cnlfaWQiLCJwcmVmIiwibmFtZTAxIiwibmFtZTAyIiwia2FuYTAxIiwia2FuYTAyIiwiY29tcGFueV9uYW1lIiwiemlwMDEiLCJ6aXAwMiIsInppcGNvZGUiLCJhZGRyMDEiLCJhZGRyMDIiLCJlbWFpbCIsInRlbDAxIiwidGVsMDIiLCJ0ZWwwMyIsImZheDAxIiwiZmF4MDIiLCJmYXgwMyIsImJpcnRoIiwicGFzc3dvcmQiLCJzYWx0Iiwic2VjcmV0X2tleSIsImZpcnN0X2J1eV9kYXRlIiwibGFzdF9idXlfZGF0ZSIsImJ1eV90aW1lcyIsImJ1eV90b3RhbCIsIm5vdGUiLCJjcmVhdGVfZGF0ZSIsInVwZGF0ZV9kYXRlIiwiZGVsX2ZsZyIsInF1ZXJ5SW5zZXJ0IiwiZSIsImlFcnJvciIsImN1c3RvbWVyX2FkZHJlc3NfaWQiLCJpZCIsIm1haWxtYWdhX2ZsZyIsImNvdXBvbkNkIiwicmFuZG9tQnl0ZXMiLCJ0b1N0cmluZyIsInN1YnN0cmluZyIsImNvdXBvbk5hbWUiLCJkaXNjb3VudFByaWNlIiwicG9pbnQiLCJjb3Vwb25faWQiLCJjb3Vwb25fY2QiLCJjb3Vwb25fdHlwZSIsImNvdXBvbl9uYW1lIiwiZGlzY291bnRfdHlwZSIsImNvdXBvbl91c2VfdGltZSIsImNvdXBvbl9yZWxlYXNlIiwiZGlzY291bnRfcHJpY2UiLCJkaXNjb3VudF9yYXRlIiwiZW5hYmxlX2ZsYWciLCJjb3Vwb25fbWVtYmVyIiwiY291cG9uX2xvd2VyX2xpbWl0IiwiYXZhaWxhYmxlX2Zyb21fZGF0ZSIsImF2YWlsYWJsZV90b19kYXRlIiwicHVibGlzaCIsInByb2ZpbGUiLCJkYiIsIk1vbmdvQ29sbGVjdGlvbiIsInBsdWciLCJwcm9qZWN0aW9uIiwiY29sbCIsImdldCIsImNvbGxlY3Rpb24iLCJmaW5kIiwidG9BcnJheSIsImFnZ3JlZ2F0ZSIsIkl0ZW1Db250cm9sbGVyIiwibW9kZWwiLCJjbGFzczEiLCJjbGFzczIiLCJpdGVtY29uIiwiaW5pdCIsInVwbG9hZGVkIiwic2V0SW1hZ2UiLCJjbGVhbkltYWdlIiwiTW9uZ29EQkZpbHRlciIsIkN1YmUzQXBpIiwiaXRlbXNEQiIsIml0ZW1Db250cm9sbGVyIiwidGFyZ2V0REIiLCJjdWJlM0RCIiwiYXBpIiwiaXRlbSIsImNvbnRleHQiLCJxdWFudGl0eSIsImdldFN0b2NrIiwiX2lkIiwidXBkYXRlU3RvY2siLCJtYWxsIiwic2hhcmFrdVNob3AiLCJwcm9kdWN0X2NsYXNzX2lkIiwiY29sIiwiY3ViZUl0ZW0iLCJjb252ZXJ0SXRlbUN1YmUzIiwiY3JlYXRvcl9pZCIsImluc2VydFJlcyIsInByb2R1Y3RDcmVhdGUiLCJ1cGRhdGUiLCIkc2V0IiwiaVN1Y2Nlc3MiLCJwcm9kdWN0SW1hZ2VVcGRhdGUiLCJwcm9kdWN0VXBkYXRlIiwicHJvZHVjdFRhZ1VwZGF0ZSIsIm5ld0xvY2FsIiwiUGFja2V0IiwiZnNFeHRyYSIsImljb252IiwiYXJjaGl2ZXIiLCJjc3YiLCJQYXNzVGhyb3VnaCIsIlRyYW5zZm9ybSIsInByZWZpeCIsIndvcmtkaXIiLCJyIiwiY3JlYXRlUmVhZFN0cmVhbSIsImxvYWRmaWxlIiwidyIsImNyZWF0ZVdyaXRlU3RyZWFtIiwic2F2ZWZpbGUiLCJpIiwicGlwZSIsImRlY29kZVN0cmVhbSIsImVuY29kZVN0cmVhbSIsInBhcnNlIiwiY29sdW1ucyIsInRyYW5zZm9ybSIsImNhbGxiYWNrIiwiZ2V0TW9kZWxDbGFzcyIsImhlYWRlciIsInBhY2tldCIsInBhY2tldFNpemUiLCJta2RpciIsInJlbW92ZSIsInVwbG9hZGRpciIsImNkIiwiZmllbGRzIiwibWFwIiwiam9pbiIsIm9uUGFja2V0U3RhcnQiLCJwYWNrZXRDb3VudCIsInNsaWNlIiwiY3N2RmlsZU5hbWUiLCJhcHBlbmRGaWxlIiwiZW5jb2RlIiwib25QYWNrZXQiLCJhcmciLCJ5YXVjdCIsImltZyIsImltYWdlcyIsImltZ1NyYyIsImltZ1RndCIsImFjY2VzcyIsImNvcHlGaWxlIiwib25QYWNrZXRFbmQiLCJ6aXAiLCJ6aXBuYW1lIiwib3V0cHV0IiwiZGlyZWN0b3J5IiwiZmluYWxpemUiLCJtaW5RdWFudGl0eSIsImNvbnZlcnRJdGVtWWF1Y3QiLCJzdWJtaXQiLCJjbG9zZSIsImV4cG9ydCIsIkNvbmZpZ3MiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJpZEdlbmVyYXRpb24iLCJzaWZ0IiwibW9iamVjdCIsIkdyb3VwQmFzZSIsIkZpbHRlcnMiLCJjb25zdHJ1Y3RvciIsImZpbHRlcklkIiwiZmluZE9uZSIsImdldFBsdWciLCJ0eXBlIiwibXlzcWwiLCJpbXBvcnQiLCJvblJlc3VsdCIsIm9uRXJyb3IiLCJ0YWJsZSIsInN0cmVhbWluZ1F1ZXJ5IiwiRXJyb3IiLCJjYWxsYmFja3MiLCJnZXRQcm9maWxlIiwiZmlsdGVycyIsInB1c2giLCJjb3VudCIsInVuZXNjYXBlIiwiZXhhbSIsIkdyb3VwcyIsInBsYXRmb3JtUGx1ZyIsImdyb3VwSWQiLCJrZXkiLCJjdXIiLCJQcm9taXNlIiwicmVzb2x2ZSIsInJlamVjdCIsImZvckVhY2giLCJpbmRleCIsImNhdGNoIiwibXlzcWxfIiwicHJvZHVjdENsYXNzSWQiLCJxdWVyeVVwZGF0ZSIsInN0b2NrIiwic3RvY2tfdW5saW1pdGVkIiwiY3JlYXRvcklkIiwidGFnb2ZmIiwicHJvZHVjdF9pZCIsInRhZ29uIiwiY291bnRSZXMiLCJ0YWdTZXQiLCJ0YWdzIiwic2V0IiwicHJvZHVjdElkIiwibGVuZ3RoIiwiZmlsZV9uYW1lIiwicmFuayIsInVwZGF0ZURhdGEiLCJrZXlzIiwiayIsImRlc2NyaXB0aW9uX2xpc3QiLCJzZWFyY2hfd29yZCIsImZyZWVfYXJlYSIsImNsYXNzX2NhdGVnb3J5X2lkMSIsImNsYXNzX2NhdGVnb3J5X2lkMiIsImRlbGl2ZXJ5X2RhdGVfaWQiLCJzYWxlX2xpbWl0IiwicHJvZHVjdF9zdG9ja19pZCIsIkRCRmlsdGVyRmFjdG9yeSIsIkRCRmlsdGVyIiwiTXlzcWxEQkZpbHRlciIsIk1vbmdvQ2xpZW50IiwiaW5zdGFuY2UiLCJmYWN0b3J5IiwiZ2V0UGx1Z18iLCJnZXRDcmVkXyIsImdldFByb2ZpbGVfIiwic2V0SW1wb3J0RnVuY3Rpb25fIiwiZm4iLCJpdGVyYXRvcnMiLCJjb3VudGVyIiwiZiIsImxpbWl0IiwiYyIsImNsaWVudCIsImNvbm5lY3QiLCJ1cmkiLCJkYXRhYmFzZSIsImFkZEN1cnNvckZsYWciLCJoYXNOZXh0IiwibmV4dCIsIk9iamVjdElEIiwiSXRlbXMiLCJQcm9kdWN0cyIsIml0ZW1JZCIsInByb2plY3QiLCJwcm9kdWN0UGFjayIsInByb2R1Y3QiLCJxdWFudGl0aWVzIiwicHJvZHVjdFNrdSIsInF1YW50aXR5U2t1Iiwic3RvY2tBcnJheSIsIk1hdGgiLCJtaW4iLCJhcHBseSIsImZldGNoIiwiY2xhc3MxX3ZhbHVlIiwiY2xhc3MyX3ZhbHVlIiwidXBkYXRlTWFueSIsIiRwdXNoIiwiJGVhY2giLCJnZXRWYXJpYXRpb24iLCJsYWJlbCIsImN1cnJlbnQiLCJkZWxpdmVyeSIsInZhbHVlIiwiY2xhc3MxX25hbWUiLCJjbGFzczJfbmFtZSIsImF0dHJzIiwicyIsInZhcmlhdGlvbnMiLCIkbWF0Y2giLCJPYmplY3QiLCJhc3NpZ24iLCIkcHJvamVjdCIsIiRzb3J0IiwicHJvcHMiLCJleHAiLCJSZWdFeHAiLCJtYXRjaCIsInRvSGV4U3RyaW5nIiwibW9kZWxDbGFzcyIsImNvbnZEZWxpdiIsInByb2R1Y3RUeXBlSWQiLCJkZWxpdmVyeUZlZSIsImF0dHIiLCJ2YXJpYXRpb24iLCJ2YXJpYXRpb25IdG1sIiwiZGVzY3JpcHRpb25EZXRhaWwiLCJqYW5fY29kZSIsImRlc2NyaXB0aW9uX2RldGFpbCIsImRlc2NyaXB0aW9uIiwicHJvZHVjdF9jb2RlIiwicHJpY2UwMSIsInJldGFpbF9wcmljZSIsInByaWNlMDIiLCJzYWxlc19wcmljZSIsInByb2R1Y3RfdHlwZV9pZCIsImRlbGl2ZXJ5X2ZlZSIsImRlZiIsImltZ1ByZWZpeCIsImNhdGVnb3J5IiwidXRpbEVycm9yIiwibWVzc2FnZSIsImZpbGVOYW1lIiwibGluZU51bWJlciIsImNvbHVtbk51bWJlciIsInN0YWNrIiwibW9tZW50IiwicG9vbCIsImNyZWF0ZVBvb2wiLCJwcm9maWxlTXVsdGkiLCJtdWx0aXBsZVN0YXRlbWVudHMiLCJwb29sTXVsdGkiLCJmb3JtYXREYXRlIiwiZGF0ZSIsImZvcm1hdCIsInJlcGxhY2UiLCJnZXRDb24iLCJ0aGVuIiwiY29uIiwicmVsZWFzZSIsInF1ZXJ5SW5zZXJ0XyIsImluc2VydElkIiwiZGF0YVNxbCIsIk1hcCIsImVzY2FwZSIsInZhbHVlcyIsInVwZGF0ZXMiLCJxdWVyeU11bHRpIiwicG9vbFN3YXAiLCJzdGFydFRyYW5zYWN0aW9uIiwiY29tbWl0Iiwicm9sbGJhY2siLCJvbiIsInBhdXNlIiwicmVzdW1lIiwiZ2V0Q29ubmVjdGlvbiIsIml0ZXJhdG9yIiwic2V0dXBJdGVyYXRvciIsIkl0ZXJhdG9yIiwicmVjIiwicmVzdWx0IiwidG90YWwiLCJuZXdSZWNvcmQiLCJzdWNjZXNzIiwiZXJyb3JPY3VycmVkIiwiaXRlRXJyb3IiLCJwaGFFcnJvciIsInRyYWNlIiwicmVjb3JkcyIsImxhc3RFcnJvciJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxFQUFKO0FBQU9DLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxJQUFSLENBQWIsRUFBMkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNMLFNBQUdLLENBQUg7QUFBSzs7QUFBakIsQ0FBM0IsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUMsTUFBSjtBQUFXTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlELElBQUlFLFVBQUo7QUFBZU4sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNFLGlCQUFXRixDQUFYO0FBQWE7O0FBQXpCLENBQTNDLEVBQXNFLENBQXRFO0FBQXlFLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFDQUFSLENBQWIsRUFBNEQ7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBNUQsRUFBb0YsQ0FBcEY7QUFhaE8sSUFBSUksdUJBQXVCRixZQUEzQjtBQUVBLE1BQU1HLFFBQVEsZUFBZCxDLENBRUE7O0FBQ0FDLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCSCxLQUEzQixFQUFrQ0Qsb0JBQWxDO0FBQ0FFLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCSCxLQUEzQixFQUFrQyxDQUFDSSxHQUFELEVBQU1DLElBQU4sS0FBZTtBQUMvQztBQUVBLFFBQU1DLFNBQVNDLE9BQU9DLFNBQVAsQ0FBaUJsQixHQUFHbUIsUUFBcEIsQ0FBZjtBQUNBLFFBQU1DLFNBQVNILE9BQU9DLFNBQVAsQ0FBaUJsQixHQUFHcUIsU0FBcEIsQ0FBZjtBQUNBLFFBQU1DLFdBQVdoQixRQUFqQjs7QUFFQSxPQUFLLElBQUlpQixJQUFULElBQWlCVCxJQUFJVSxLQUFKLENBQVVELElBQTNCLEVBQWlDO0FBQy9CLFVBQU1FLE9BQU9ULE9BQU9PLEtBQUtHLElBQVosQ0FBYixDQUQrQixDQUUvQjtBQUNBOztBQUNBLFFBQUlDLFdBQVksR0FBRXJCLFFBQVMsTUFBM0IsQ0FKK0IsQ0FNL0I7O0FBQ0EsUUFBSXNCLFdBQVdkLElBQUllLElBQUosQ0FBU0MsUUFBVCxHQUFvQixHQUFwQixHQUEwQkgsUUFBekMsQ0FQK0IsQ0FTL0I7QUFFQTs7QUFDQSxRQUFJSSxNQUFNO0FBQ1JULGdCQUFVQSxRQURGO0FBRVJVLHNCQUFnQlQsS0FBS1UsSUFGYjtBQUdSQyx3QkFBa0JQO0FBSFYsS0FBVjs7QUFNQSxRQUFHO0FBQ0RQLGFBQU9RLFFBQVAsRUFBaUJILElBQWpCO0FBQ0QsS0FGRCxDQUdBLE9BQU1VLEdBQU4sRUFBVTtBQUNSSixVQUFJSyxLQUFKLEdBQVlELEdBQVo7QUFDRDs7QUFDRDNCLFlBQVE2QixNQUFSLENBQWVOLEdBQWY7QUFFQSxXQUFPUixJQUFQO0FBRUQ7O0FBQUE7QUFDRFIsT0FBS3VCLFNBQUwsQ0FBZSxHQUFmO0FBQ0F2QixPQUFLd0IsR0FBTCxDQUFTQyxLQUFLQyxTQUFMLENBQWU7QUFDdEJuQixjQUFVQSxRQURZO0FBRXRCb0IsYUFBUzVCLElBQUllLElBQUosQ0FBU0M7QUFGSSxHQUFmLENBQVQ7QUFLRCxDQTFDRCxFOzs7Ozs7Ozs7OztBQ25CQSxJQUFJYSxNQUFKO0FBQVcxQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDc0MsYUFBT3RDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJd0MsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUFsRCxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJeUMsS0FBSixFQUFVQyxZQUFWO0FBQXVCOUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlDQUFSLENBQWIsRUFBd0Q7QUFBQzJDLFFBQU16QyxDQUFOLEVBQVE7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CMEMsZUFBYTFDLENBQWIsRUFBZTtBQUFDMEMsbUJBQWExQyxDQUFiO0FBQWU7O0FBQWxELENBQXhELEVBQTRHLENBQTVHO0FBQStHLElBQUkyQyxNQUFKO0FBQVcvQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0NBQVIsQ0FBYixFQUF5RDtBQUFDNkMsU0FBTzNDLENBQVAsRUFBUztBQUFDMkMsYUFBTzNDLENBQVA7QUFBUzs7QUFBcEIsQ0FBekQsRUFBK0UsQ0FBL0U7QUFhMWMsSUFBSTRDLE1BQU0sU0FBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxVQUFkLEVBQTBCRSxNQUExQjtBQUFBLG9DQUFrQztBQUNoQyxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYixDQURnQyxDQUdoQztBQUNBOztBQUVBLFVBQUlRLFNBQVMsSUFBSUwsTUFBSixDQUFXRyxPQUFPRyxXQUFsQixDQUFiLENBTmdDLENBT2hDO0FBRUE7QUFDQTs7QUFFQSxVQUFJQyxZQUFZLGdCQUFoQjtBQUVBLFVBQUlDLFFBQVEsSUFBSVosS0FBSixDQUFVTyxPQUFPTSxHQUFQLENBQVdDLElBQXJCLENBQVo7QUFFQSxvQkFBTU4sT0FBT08sS0FBUCxDQUFhLHdCQUFiLEVBQ0osK0JBQVk7QUFDVixzQkFBTUgsTUFBTUksS0FBTixDQUFZTCxTQUFaLENBQU47QUFDRCxPQUZELENBREksQ0FBTixFQWhCZ0MsQ0FxQmhDO0FBQ0E7O0FBRUEsb0JBQU1ILE9BQU9PLEtBQVAsQ0FBYSx1QkFBYixFQUNKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUM3QkMsc0JBQW1CQyxNQUFQLDZCQUFrQjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLGdCQUFJQyxNQUFPOzs7OzswQkFLR0QsT0FBT0UsV0FBWSxNQUFLRixPQUFPRyxNQUFPLE1BQUtILE9BQU9JLEdBQUksTUFBS0osT0FBT0ssR0FBSSxNQUFLTCxPQUFPTSxVQUFXLE1BQUtOLE9BQU9PLElBQUssTUFBS1AsT0FBT1EsTUFBTyxNQUFLUixPQUFPUyxNQUFPLE1BQUtULE9BQU9VLE1BQU8sTUFBS1YsT0FBT1csTUFBTyxNQUFLWCxPQUFPWSxZQUFhLE1BQUtaLE9BQU9hLEtBQU0sTUFBS2IsT0FBT2MsS0FBTSxNQUFLZCxPQUFPZSxPQUFRLE1BQUtmLE9BQU9nQixNQUFPLE1BQUtoQixPQUFPaUIsTUFBTyxNQUFLakIsT0FBT2tCLEtBQU0sTUFBS2xCLE9BQU9tQixLQUFNLE1BQUtuQixPQUFPb0IsS0FBTSxNQUFLcEIsT0FBT3FCLEtBQU0sTUFBS3JCLE9BQU9zQixLQUFNLE1BQUt0QixPQUFPdUIsS0FBTSxNQUFLdkIsT0FBT3dCLEtBQU0sTUFBS3hCLE9BQU95QixLQUFNLE1BQUt6QixPQUFPMEIsUUFBUyxNQUFLMUIsT0FBTzJCLElBQUssTUFBSzNCLE9BQU80QixVQUFXLE1BQUs1QixPQUFPNkIsY0FBZSxNQUFLN0IsT0FBTzhCLGFBQWMsTUFBSzlCLE9BQU8rQixTQUFVLE1BQUsvQixPQUFPZ0MsU0FBVSxNQUFLaEMsT0FBT2lDLElBQUssTUFBS2pDLE9BQU9rQyxXQUFZLE1BQUtsQyxPQUFPbUMsV0FBWSxNQUFLbkMsT0FBT29DLE9BQVE7O2lCQUxsc0I7O0FBU0EsZ0JBQUk7QUFDRiw0QkFBTTVDLE1BQU02QyxXQUFOLENBQ0osY0FESSxFQUNZO0FBQ2RuQyw2QkFBYUYsT0FBT0UsV0FETjtBQUVkQyx3QkFBUUgsT0FBT0csTUFGRDtBQUdkQyxxQkFBS0osT0FBT0ksR0FIRTtBQUlkQyxxQkFBS0wsT0FBT0ssR0FKRTtBQUtkQyw0QkFBWU4sT0FBT00sVUFMTDtBQU1kQyxzQkFBTVAsT0FBT08sSUFOQztBQU9kQyx3QkFBUVIsT0FBT1EsTUFQRDtBQVFkQyx3QkFBUVQsT0FBT1MsTUFSRDtBQVNkQyx3QkFBUVYsT0FBT1UsTUFURDtBQVVkQyx3QkFBUVgsT0FBT1csTUFWRDtBQVdkQyw4QkFBY1osT0FBT1ksWUFYUDtBQVlkQyx1QkFBT2IsT0FBT2EsS0FaQTtBQWFkQyx1QkFBT2QsT0FBT2MsS0FiQTtBQWNkQyx5QkFBU2YsT0FBT2UsT0FkRjtBQWVkQyx3QkFBUWhCLE9BQU9nQixNQWZEO0FBZ0JkQyx3QkFBUWpCLE9BQU9pQixNQWhCRDtBQWlCZEMsdUJBQU9sQixPQUFPa0IsS0FqQkE7QUFrQmRDLHVCQUFPbkIsT0FBT21CLEtBbEJBO0FBbUJkQyx1QkFBT3BCLE9BQU9vQixLQW5CQTtBQW9CZEMsdUJBQU9yQixPQUFPcUIsS0FwQkE7QUFxQmRDLHVCQUFPdEIsT0FBT3NCLEtBckJBO0FBc0JkQyx1QkFBT3ZCLE9BQU91QixLQXRCQTtBQXVCZEMsdUJBQU94QixPQUFPd0IsS0F2QkE7QUF3QmRDLHVCQUFPekIsT0FBT3lCLEtBeEJBO0FBeUJkQywwQkFBVTFCLE9BQU8wQixRQXpCSDtBQTBCZEMsc0JBQU0zQixPQUFPMkIsSUExQkM7QUEyQmRDLDRCQUFZNUIsT0FBTzRCLFVBM0JMO0FBNEJkQyxnQ0FBZ0I3QixPQUFPNkIsY0E1QlQ7QUE2QmRDLCtCQUFlOUIsT0FBTzhCLGFBN0JSO0FBOEJkQywyQkFBVy9CLE9BQU8rQixTQTlCSjtBQStCZEMsMkJBQVdoQyxPQUFPZ0MsU0EvQko7QUFnQ2RDLHNCQUFNakMsT0FBT2lDLElBaENDO0FBaUNkQyw2QkFBYWxDLE9BQU9rQyxXQWpDTjtBQWtDZEMsNkJBQWFuQyxPQUFPbUMsV0FsQ047QUFtQ2RDLHlCQUFTcEMsT0FBT29DO0FBbkNGLGVBRFosQ0FBTjtBQXVDRCxhQXhDRCxDQXdDRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFoRTJCLENBa0U1Qjs7O0FBQ0EsZ0JBQUk7QUFDRiw0QkFBTTlDLE1BQU02QyxXQUFOLENBQ0osc0JBREksRUFDb0I7QUFDdEJHLHFDQUFxQixJQURDO0FBRXRCdEMsNkJBQWFGLE9BQU9FLFdBRkU7QUFHdEJJLDRCQUFZTixPQUFPTSxVQUhHO0FBSXRCQyxzQkFBTVAsT0FBT08sSUFKUztBQUt0QkMsd0JBQVFSLE9BQU9RLE1BTE87QUFNdEJDLHdCQUFRVCxPQUFPUyxNQU5PO0FBT3RCQyx3QkFBUVYsT0FBT1UsTUFQTztBQVF0QkMsd0JBQVFYLE9BQU9XLE1BUk87QUFTdEJDLDhCQUFjWixPQUFPWSxZQVRDO0FBVXRCQyx1QkFBT2IsT0FBT2EsS0FWUTtBQVd0QkMsdUJBQU9kLE9BQU9jLEtBWFE7QUFZdEJDLHlCQUFTZixPQUFPZSxPQVpNO0FBYXRCQyx3QkFBUWhCLE9BQU9nQixNQWJPO0FBY3RCQyx3QkFBUWpCLE9BQU9pQixNQWRPO0FBZXRCRSx1QkFBT25CLE9BQU9tQixLQWZRO0FBZ0J0QkMsdUJBQU9wQixPQUFPb0IsS0FoQlE7QUFpQnRCQyx1QkFBT3JCLE9BQU9xQixLQWpCUTtBQWtCdEJDLHVCQUFPdEIsT0FBT3NCLEtBbEJRO0FBbUJ0QkMsdUJBQU92QixPQUFPdUIsS0FuQlE7QUFvQnRCQyx1QkFBT3hCLE9BQU93QixLQXBCUTtBQXFCdEJVLDZCQUFhbEMsT0FBT2tDLFdBckJFO0FBc0J0QkMsNkJBQWFuQyxPQUFPbUMsV0F0QkU7QUF1QnRCQyx5QkFBU3BDLE9BQU9vQztBQXZCTSxlQURwQixDQUFOO0FBMkJELGFBNUJELENBNEJFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWpHMkIsQ0FtRzVCOzs7QUFDQSxnQkFBSTtBQUNGLDRCQUFNOUMsTUFBTTZDLFdBQU4sQ0FDSix1QkFESSxFQUNxQjtBQUN2Qkksb0JBQUksSUFEbUI7QUFFdkJ2Qyw2QkFBYUYsT0FBT0UsV0FGRztBQUd2QndDLDhCQUFjMUMsT0FBTzBDLFlBSEU7QUFJdkJSLDZCQUFhbEMsT0FBT2tDLFdBSkc7QUFLdkJDLDZCQUFhbkMsT0FBT21DLFdBTEc7QUFNdkJDLHlCQUFTcEMsT0FBT29DO0FBTk8sZUFEckIsQ0FBTjtBQVVELGFBWEQsQ0FXRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFqSDJCLENBbUg1Qjs7O0FBRUEsZ0JBQUlLLFdBQVdoRSxPQUFPaUUsV0FBUCxDQUFtQixDQUFuQixFQUFzQkMsUUFBdEIsQ0FBK0IsUUFBL0IsRUFBeUNDLFNBQXpDLENBQW1ELENBQW5ELEVBQXNELEVBQXRELENBQWY7QUFFQSxnQkFBSUMsYUFBYyxHQUFFL0MsT0FBT1EsTUFBTyxJQUFHUixPQUFPUyxNQUFPLG1CQUFrQlQsT0FBT0UsV0FBWSxFQUF4RjtBQUVBLGdCQUFJOEMsZ0JBQWdCaEQsT0FBT2lELEtBQVAsR0FBZSxHQUFuQzs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJcEQsb0JBQVlMLE1BQU02QyxXQUFOLENBQ2QsWUFEYyxFQUNBO0FBQ1phLDJCQUFXLElBREM7QUFFWkMsMkJBQVdSLFFBRkM7QUFHWlMsNkJBQWEsQ0FIRDtBQUdJO0FBQ2hCQyw2QkFBYU4sVUFKRDtBQUtaTywrQkFBZSxDQUxIO0FBTVpDLGlDQUFpQixDQU5MO0FBT1pDLGdDQUFnQixDQVBKO0FBUVpDLGdDQUFnQlQsYUFSSjtBQVNaVSwrQkFBZSxJQVRIO0FBVVpDLDZCQUFhLENBVkQ7QUFXWkMsK0JBQWUsQ0FYSDtBQVlaQyxvQ0FBb0IsSUFaUjtBQWFaM0QsNkJBQWFGLE9BQU9FLFdBYlI7QUFjWjRELHFDQUFxQixxQkFkVDtBQWVaQyxtQ0FBbUIscUJBZlA7QUFnQlozQix5QkFBUztBQWhCRyxlQURBLEVBa0JYO0FBQ0RGLDZCQUFhLE9BRFo7QUFFREMsNkJBQWE7QUFGWixlQWxCVyxDQUFaLENBQUo7QUF1QkQsYUF4QkQsQ0F3QkUsT0FBT0csQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0F0Slc7QUFEaUIsU0FBZixFQXlKVEEsQ0FBUCw2QkFBYTtBQUNYbEQsaUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxTQUZELENBekpnQixDQUFaLENBQUo7QUE4SkEsZUFBT3pDLEdBQVA7QUFDRCxPQWhLRCxDQURJLENBQU47QUFtS0EsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBNUxEO0FBQUEsR0FGYTs7QUFnTVAsdUJBQU4sQ0FBNkJDLE9BQTdCO0FBQUEsb0NBQXNDO0FBQ3BDLFVBQUlDLEtBQUssSUFBSXRGLEtBQUosQ0FBVXFGLE9BQVYsQ0FBVDtBQUNBLFVBQUlwRSxvQkFBWXFFLEdBQUd0RSxLQUFILENBQVMsZ0JBQVQsQ0FBWixDQUFKO0FBQ0EsYUFBT0MsR0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFoTWEsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBLElBQUlzRSxlQUFKO0FBQW9CbEksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ2dJLGtCQUFnQjlILENBQWhCLEVBQWtCO0FBQUM4SCxzQkFBZ0I5SCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBakQsRUFBeUYsQ0FBekY7QUFBNEYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUczSCxJQUFJNEMsTUFBTSxrQkFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXVCbUYsSUFBdkIsRUFBNkJ4RSxRQUFRLEVBQXJDLEVBQXlDeUUsYUFBYSxFQUF0RDtBQUFBLG9DQUEwRDtBQUN4RCxVQUFJQyxxQkFBYUgsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEJBLEtBQUtJLFVBQS9CLENBQWIsQ0FBSjtBQUNBLFVBQUkzRSxvQkFBWXlFLEtBQUtHLElBQUwsQ0FBVTdFLEtBQVYsRUFBaUI7QUFBQ3lFLG9CQUFZQTtBQUFiLE9BQWpCLEVBQTJDSyxPQUEzQyxFQUFaLENBQUo7QUFDQSxhQUFPN0UsR0FBUDtBQUNELEtBSkQ7QUFBQSxHQUZhOztBQVFiLEdBQVEsR0FBRVosR0FBSSxZQUFkLEVBQTRCbUYsSUFBNUIsRUFBa0N4RSxRQUFRLEVBQTFDO0FBQUEsb0NBQThDO0FBQzVDLFVBQUkwRSxxQkFBYUgsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEJBLEtBQUtJLFVBQS9CLENBQWIsQ0FBSjtBQUNBLFVBQUkzRSxvQkFBWXlFLEtBQUtLLFNBQUwsQ0FBZS9FLEtBQWYsRUFBc0I4RSxPQUF0QixFQUFaLENBQUo7QUFDQSxhQUFPN0UsR0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFSYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSStFLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBcEQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUdwSCxJQUFJNEMsTUFBTSxhQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7Ozs7O0FBS0EsR0FBUSxHQUFFRCxHQUFJLFdBQWQsRUFBMkJtRixJQUEzQixFQUFpQzlHLFFBQWpDLEVBQTJDdUgsS0FBM0MsRUFBa0RDLFNBQVMsSUFBM0QsRUFBaUVDLFNBQVMsSUFBMUU7QUFBQSxvQ0FBZ0Y7QUFDOUUsVUFBSUMsVUFBVSxJQUFJSixjQUFKLEVBQWQ7QUFDQSxvQkFBTUksUUFBUUMsSUFBUixDQUFhYixJQUFiLENBQU47QUFDQSxVQUFJYyx5QkFBaUJGLFFBQVFHLFFBQVIsQ0FBaUI3SCxRQUFqQixFQUEyQnVILEtBQTNCLEVBQWtDQyxNQUFsQyxFQUEwQ0MsTUFBMUMsQ0FBakIsQ0FBSjtBQUNBLGFBQU9HLFFBQVA7QUFDRCxLQUxEO0FBQUEsR0FQYTs7QUFjYjs7O0FBR0EsR0FBUSxHQUFFakcsR0FBSSxhQUFkLEVBQTZCbUYsSUFBN0IsRUFBbUNTLEtBQW5DLEVBQTBDQyxTQUFTLElBQW5ELEVBQXlEQyxTQUFTLElBQWxFO0FBQUEsb0NBQXdFO0FBQ3RFLFVBQUlDLFVBQVUsSUFBSUosY0FBSixFQUFkO0FBQ0Esb0JBQU1JLFFBQVFDLElBQVIsQ0FBYWIsSUFBYixDQUFOO0FBQ0Esb0JBQU1ZLFFBQVFJLFVBQVIsQ0FBbUJQLEtBQW5CLEVBQTBCQyxNQUExQixFQUFrQ0MsTUFBbEMsQ0FBTjtBQUNELEtBSkQ7QUFBQTs7QUFqQmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBLElBQUlsRyxNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJaUosUUFBSjtBQUFhckosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ21KLFdBQVNqSixDQUFULEVBQVc7QUFBQ2lKLGVBQVNqSixDQUFUO0FBQVc7O0FBQXhCLENBQXBELEVBQThFLENBQTlFO0FBQWlGLElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQTlDLEVBQW9FLENBQXBFO0FBQXVFLElBQUl1SSxjQUFKO0FBQW1CM0ksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1SSxxQkFBZXZJLENBQWY7QUFBaUI7O0FBQTdCLENBQWpELEVBQWdGLENBQWhGO0FBQW1GLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFZamUsSUFBSTRDLE1BQU0sTUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksY0FBZCxFQUE4QkUsTUFBOUI7QUFBQSxvQ0FBc0M7QUFDcEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLFVBQUlRLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBYjtBQUNBLFVBQUl1QixpQkFBaUIsSUFBSVosY0FBSixFQUFyQjtBQUNBLG9CQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU47QUFFQSxVQUFJRSxXQUFXLElBQUk3RyxLQUFKLENBQVVPLE9BQU91RyxPQUFqQixDQUFmO0FBQ0EsVUFBSUMsTUFBTSxJQUFJTCxRQUFKLENBQWFHLFFBQWIsQ0FBVjtBQUVBLG9CQUFNckcsT0FBT08sS0FBUCxDQUNKLE9BREksRUFFSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFFN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlDLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF3QkgsS0FBS0ksR0FBN0IsQ0FBakIsQ0FBSjtBQUNBLDBCQUFNTCxJQUFJTSxXQUFKLENBQWdCTCxLQUFLTSxJQUFMLENBQVVDLFdBQVYsQ0FBc0JDLGdCQUF0QyxFQUF3RE4sUUFBeEQsQ0FBTjtBQUNELFdBSFM7QUFGbUIsU0FBZixDQUFaLENBQUo7QUFPQSxlQUFPakcsR0FBUDtBQUNELE9BVEQsQ0FGSSxDQUFOO0FBYUEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBekJEO0FBQUEsR0FMYTs7QUFnQ2I7QUFDQTtBQUVBLEdBQVEsR0FBRS9FLEdBQUksWUFBZCxFQUE0QkUsTUFBNUI7QUFBQSxvQ0FBb0M7QUFDbEMsVUFBSUUsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBQ0EsVUFBSXdCLFdBQVcsSUFBSTdHLEtBQUosQ0FBVU8sT0FBT3VHLE9BQWpCLENBQWY7QUFDQSxVQUFJQyxNQUFNLElBQUlMLFFBQUosQ0FBYUcsUUFBYixDQUFWO0FBRUEsVUFBSUQsaUJBQWlCLElBQUlaLGNBQUosRUFBckI7QUFDQSxvQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOLEVBTmtDLENBUWxDOztBQUNBLFVBQUluRyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osZUFESSxFQUVKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUM3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSVEsTUFBTVIsUUFBUXJCLFVBQWxCOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUk4Qix5QkFBaUJkLGVBQWVlLGdCQUFmLENBQWdDcEgsT0FBT3FILFVBQXZDLEVBQW1EWixJQUFuRCxDQUFqQixDQUFKO0FBRUEsa0JBQUlhLDBCQUFrQmQsSUFBSWUsYUFBSixDQUFrQkosUUFBbEIsQ0FBbEIsQ0FBSixDQUhFLENBS0Y7O0FBQ0EsNEJBQU1ELElBQUlNLE1BQUosQ0FBVztBQUNmWCxxQkFBS0osS0FBS0k7QUFESyxlQUFYLEVBRUg7QUFDRFksc0JBQU07QUFDSixzQ0FBb0JILFVBQVU1RztBQUQxQjtBQURMLGVBRkcsQ0FBTjtBQVFBVCxxQkFBT3lILFFBQVA7QUFDRCxhQWZELENBZUUsT0FBT3ZFLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBckJTO0FBRG1CLFNBQWYsRUF3QlRBLENBQVAsNkJBQWE7QUFDWCxnQkFBTUEsQ0FBTjtBQUNELFNBRkQsQ0F4QmdCLENBQVosQ0FBSjtBQTRCQSxlQUFPekMsR0FBUDtBQUNELE9BOUJELENBRkksQ0FBTjtBQWtDQSxvQkFBTVQsT0FBT08sS0FBUCxDQUNKLGdCQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJUSxNQUFNUixRQUFRckIsVUFBbEI7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSThCLHlCQUFpQmQsZUFBZWUsZ0JBQWYsQ0FBZ0NwSCxPQUFPcUgsVUFBdkMsRUFBbURaLElBQW5ELENBQWpCLENBQUo7QUFFQSw0QkFBTUQsSUFBSW1CLGtCQUFKLENBQXVCUixRQUF2QixDQUFOO0FBQ0EsNEJBQU1YLElBQUlvQixhQUFKLENBQWtCVCxRQUFsQixDQUFOO0FBQ0EsNEJBQU1YLElBQUlxQixnQkFBSixDQUFxQlYsUUFBckIsQ0FBTjtBQUVBLGtCQUFJUix5QkFBaUJOLGVBQWVPLFFBQWYsQ0FBd0JILEtBQUtJLEdBQTdCLENBQWpCLENBQUo7QUFDQSw0QkFBTUwsSUFBSU0sV0FBSixDQUFnQkwsS0FBS00sSUFBTCxDQUFVQyxXQUFWLENBQXNCQyxnQkFBdEMsRUFBd0ROLFFBQXhELENBQU47QUFFQTFHLHFCQUFPeUgsUUFBUDtBQUNELGFBWEQsQ0FXRSxPQUFPdkUsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0FqQlM7QUFEbUIsU0FBZixFQW9CVEEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQXBCZ0IsQ0FBWixDQUFKO0FBd0JBLGVBQU96QyxHQUFQO0FBQ0QsT0ExQkQsQ0FGSSxDQUFOO0FBOEJBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTVFRDtBQUFBOztBQW5DYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZEEsSUFBSW5GLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWdKLGFBQUo7QUFBa0JwSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDa0osZ0JBQWNoSixDQUFkLEVBQWdCO0FBQUNnSixvQkFBY2hKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQTlDLEVBQW9FLENBQXBFO0FBQXVFLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFPN1IsSUFBSTRDLE1BQU0sTUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksT0FBZCxFQUF1QkUsTUFBdkI7QUFBQSxvQ0FBK0I7QUFDN0I7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLFVBQUlRLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBYjtBQUVBLFlBQU1nRCx5QkFBaUI1SCxPQUFPUyxPQUFQLENBQWUsRUFBZixFQUEwQndDLENBQVAsNkJBQWE7QUFDckQsY0FBTUEsQ0FBTjtBQUNELE9BRnlDLENBQW5CLENBQWpCLENBQU47QUFHQSxvQkFBTWxELE9BQU9PLEtBQVAsQ0FDSixVQURJLEVBRUosK0JBQVk7QUFDVixlQUFPc0gsUUFBUDtBQUNELE9BRkQsQ0FGSSxDQUFOO0FBTUEsYUFBTzdILE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQWhCRDtBQUFBOztBQUxhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNUQSxJQUFJbkYsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVJLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJNkssTUFBSjtBQUFXakwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM2SyxhQUFPN0ssQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJOEssT0FBSjtBQUFZbEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzhLLGNBQVE5SyxDQUFSO0FBQVU7O0FBQXRCLENBQWpDLEVBQXlELENBQXpEO0FBQTRELElBQUkrSyxLQUFKO0FBQVVuTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiLEVBQW1DO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDK0ssWUFBTS9LLENBQU47QUFBUTs7QUFBcEIsQ0FBbkMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSWdMLFFBQUo7QUFBYXBMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNnTCxlQUFTaEwsQ0FBVDtBQUFXOztBQUF2QixDQUFqQyxFQUEwRCxDQUExRDtBQUE2RCxJQUFJaUwsR0FBSjtBQUFRckwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLEtBQVIsQ0FBYixFQUE0QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2lMLFVBQUlqTCxDQUFKO0FBQU07O0FBQWxCLENBQTVCLEVBQWdELENBQWhEO0FBQW1ELElBQUlrTCxXQUFKLEVBQWdCQyxTQUFoQjtBQUEwQnZMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ29MLGNBQVlsTCxDQUFaLEVBQWM7QUFBQ2tMLGtCQUFZbEwsQ0FBWjtBQUFjLEdBQTlCOztBQUErQm1MLFlBQVVuTCxDQUFWLEVBQVk7QUFBQ21MLGdCQUFVbkwsQ0FBVjtBQUFZOztBQUF4RCxDQUEvQixFQUF5RixDQUF6RjtBQWVsdkIsTUFBTW9MLFNBQVMsUUFBZjtBQUNBLE1BQU14SSxNQUFNLE9BQVo7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxrQkFBUixFQUE0QkMsTUFBNUI7QUFBQSxvQ0FBb0M7QUFDbEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osUUFESSxFQUVKLCtCQUFZO0FBQ1YsY0FBTTZGLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTjtBQUNBLGNBQU1tQyxVQUFXLEdBQUV2SSxPQUFPdUksT0FBUSxRQUFsQztBQUNBLGNBQU1DLElBQUlSLFFBQVFTLGdCQUFSLENBQTBCLEdBQUVGLE9BQVEsSUFBR3ZJLE9BQU8wSSxRQUFTLEVBQXZELENBQVY7QUFDQSxjQUFNQyxJQUFJWCxRQUFRWSxpQkFBUixDQUEyQixHQUFFTCxPQUFRLElBQUd2SSxPQUFPNkksUUFBUyxFQUF4RCxDQUFWO0FBQ0EsWUFBSUMsSUFBSSxDQUFSO0FBQ0FOLFVBQUVPLElBQUYsQ0FBT2QsTUFBTWUsWUFBTixDQUFtQixNQUFuQixDQUFQLEVBQ0dELElBREgsQ0FDUWQsTUFBTWdCLFlBQU4sQ0FBbUIsT0FBbkIsQ0FEUixFQUVHRixJQUZILENBRVFaLElBQUllLEtBQUosQ0FBVTtBQUFDQyxtQkFBUztBQUFWLFNBQVYsQ0FGUixFQUdHSixJQUhILENBR1FaLElBQUlpQixTQUFKLENBQ0osQ0FBT3ZJLE1BQVAsRUFBZXdJLFFBQWYsOEJBQTRCO0FBQzFCLGNBQUlySyxNQUFNLElBQVYsQ0FEMEIsQ0FFMUI7O0FBQ0EsY0FBSTtBQUNGNkIsbUJBQU8sTUFBUCxrQkFBdUJ3RixlQUFlaUQsYUFBZixDQUE2QnpJLE9BQU8sTUFBUCxDQUE3QixDQUF2QjtBQUNELFdBRkQsQ0FFRSxPQUFPc0MsQ0FBUCxFQUFVO0FBQ1ZuRSxrQkFBTW1FLENBQU47QUFDRDs7QUFDRGtHLG1CQUFTckssR0FBVCxFQUFjNkIsTUFBZDtBQUNELFNBVEQsQ0FESSxDQUhSLEVBZUdrSSxJQWZILENBZVFaLElBQUk3SSxTQUFKLENBQWM7QUFBQ2lLLGtCQUFRO0FBQVQsU0FBZCxDQWZSLEVBZ0JHUixJQWhCSCxDQWdCUWQsTUFBTWUsWUFBTixDQUFtQixPQUFuQixDQWhCUixFQWlCR0QsSUFqQkgsQ0FpQlFkLE1BQU1nQixZQUFOLENBQW1CLE1BQW5CLENBakJSLEVBa0JHRixJQWxCSCxDQWtCUUosQ0FsQlI7QUFtQkQsT0ExQkQsQ0FGSSxDQUFOO0FBOEJELEtBbENEO0FBQUEsR0FMYTs7QUF5Q2I7QUFDQTtBQUVBLEdBQVEsR0FBRTdJLEdBQUksVUFBZCxFQUEwQkUsTUFBMUI7QUFBQSxvQ0FBa0M7QUFDaEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osUUFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUVBLGNBQU1OLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBZjtBQUNBLGNBQU11QixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOVSxDQVFWOztBQUNBLGNBQU1vRCxTQUFTLElBQUl6QixNQUFKLENBQVcvSCxPQUFPeUosVUFBbEIsQ0FBZixDQVRVLENBV1Y7O0FBQ0EsWUFBSTtBQUNGLHdCQUFNekIsUUFBUTBCLEtBQVIsQ0FBYzFKLE9BQU91SSxPQUFyQixDQUFOO0FBQ0QsU0FGRCxDQUVFLE9BQU9wRixDQUFQLEVBQVUsQ0FBRSxDQWRKLENBZ0JWOzs7QUFDQSxjQUFNb0YsVUFBVyxHQUFFdkksT0FBT3VJLE9BQVEsT0FBbEM7QUFDQSxzQkFBTVAsUUFBUTJCLE1BQVIsQ0FBZXBCLE9BQWYsQ0FBTjtBQUNBLHNCQUFNUCxRQUFRMEIsS0FBUixDQUFjbkIsT0FBZCxDQUFOLEVBbkJVLENBcUJWOztBQUNBLGNBQU1xQixZQUFhLEdBQUU1SixPQUFPdUksT0FBUSxTQUFwQztBQUNBLHNCQUFNUCxRQUFRMkIsTUFBUixDQUFlQyxTQUFmLENBQU47QUFDQSxzQkFBTTVCLFFBQVEwQixLQUFSLENBQWNFLFNBQWQsQ0FBTjtBQUVBLFlBQUlDLEtBQUssSUFBVCxDQTFCVSxDQTBCSTs7QUFDZCxZQUFJckwsV0FBVyxJQUFmLENBM0JVLENBMkJVOztBQUNwQixZQUFJTSxPQUFPLElBQVgsQ0E1QlUsQ0E0Qk07QUFFaEI7O0FBQ0EsWUFBSWdMLFNBQVMsQ0FBQyxNQUFELEVBQVMsTUFBVCxFQUFpQixNQUFqQixFQUF5QixJQUF6QixFQUErQixnQkFBL0IsRUFBaUQsTUFBakQsRUFBeUQsTUFBekQsRUFBaUUsT0FBakUsRUFBMEUsSUFBMUUsRUFBZ0YsUUFBaEYsRUFBMEYsSUFBMUYsRUFBZ0csTUFBaEcsRUFBd0csWUFBeEcsRUFBc0gsWUFBdEgsRUFBb0ksTUFBcEksRUFBNEksV0FBNUksRUFBeUosWUFBekosRUFBdUssT0FBdkssRUFBZ0wsU0FBaEwsRUFBMkwsT0FBM0wsRUFBb00sU0FBcE0sRUFBK00sS0FBL00sRUFBc04sU0FBdE4sRUFBaU8sS0FBak8sRUFBd08sU0FBeE8sRUFBbVAsS0FBblAsRUFBMFAsU0FBMVAsRUFBcVEsS0FBclEsRUFBNFEsU0FBNVEsRUFBdVIsS0FBdlIsRUFBOFIsU0FBOVIsRUFBeVMsS0FBelMsRUFBZ1QsU0FBaFQsRUFBMlQsS0FBM1QsRUFBa1UsU0FBbFUsRUFBNlUsS0FBN1UsRUFBb1YsU0FBcFYsRUFBK1YsS0FBL1YsRUFBc1csU0FBdFcsRUFBaVgsTUFBalgsRUFBeVgsVUFBelgsRUFBcVksTUFBclksRUFBNlksUUFBN1ksRUFBdVosU0FBdlosRUFBa2EsTUFBbGEsRUFBMGEsTUFBMWEsRUFBa2IsVUFBbGIsRUFBOGIsT0FBOWIsRUFBdWMsUUFBdmMsRUFBaWQsUUFBamQsRUFBMmQsV0FBM2QsRUFBd2UsUUFBeGUsRUFBa2YsS0FBbGYsRUFBeWYsY0FBemYsRUFBeWdCLFNBQXpnQixFQUFvaEIsU0FBcGhCLEVBQStoQixZQUEvaEIsRUFBNmlCLGNBQTdpQixFQUE2akIsUUFBN2pCLEVBQXVrQixPQUF2a0IsRUFBZ2xCLFFBQWhsQixFQUEwbEIsVUFBMWxCLEVBQXNtQixtQkFBdG1CLEVBQTJuQixnQkFBM25CLEVBQTZvQixVQUE3b0IsRUFBeXBCLG1CQUF6cEIsRUFBOHFCLGdCQUE5cUIsRUFBZ3NCLFVBQWhzQixFQUE0c0IsbUJBQTVzQixFQUFpdUIsZ0JBQWp1QixFQUFtdkIsVUFBbnZCLEVBQSt2QixtQkFBL3ZCLEVBQW94QixnQkFBcHhCLEVBQXN5QixVQUF0eUIsRUFBa3pCLG1CQUFsekIsRUFBdTBCLGdCQUF2MEIsRUFBeTFCLFVBQXoxQixFQUFxMkIsbUJBQXIyQixFQUEwM0IsZ0JBQTEzQixFQUE0NEIsVUFBNTRCLEVBQXc1QixtQkFBeDVCLEVBQTY2QixnQkFBNzZCLEVBQSs3QixVQUEvN0IsRUFBMjhCLG1CQUEzOEIsRUFBZytCLGdCQUFoK0IsRUFBay9CLFVBQWwvQixFQUE4L0IsbUJBQTkvQixFQUFtaEMsZ0JBQW5oQyxFQUFxaUMsV0FBcmlDLEVBQWtqQyxvQkFBbGpDLEVBQXdrQyxpQkFBeGtDLEVBQTJsQyxNQUEzbEMsRUFBbW1DLFdBQW5tQyxFQUFnbkMsU0FBaG5DLEVBQTJuQyxPQUEzbkMsRUFBb29DLGdCQUFwb0MsQ0FBYjtBQUNBLFlBQUlQLFNBQVNPLE9BQU9DLEdBQVAsQ0FBVzdNLEtBQU0sSUFBR0EsQ0FBRSxHQUF0QixFQUEwQjhNLElBQTFCLENBQStCLEdBQS9CLElBQXNDLElBQW5ELENBaENVLENBa0NWOztBQUNBUixlQUFPUyxhQUFQLEdBQThCQyxXQUFQLDZCQUF1QjtBQUM1Q3BMLGlCQUFPd0osU0FBUyxDQUFDLFVBQVU0QixXQUFYLEVBQXdCQyxLQUF4QixDQUE4QixDQUFDLENBQS9CLENBQWhCO0FBQ0FOLGVBQU0sR0FBRXRCLE9BQVEsSUFBR3pKLElBQUssRUFBeEI7QUFDQU4scUJBQVksR0FBRXFMLEVBQUcsSUFBRzdKLE9BQU9vSyxXQUFZLEVBQXZDO0FBQ0Esd0JBQU1wQyxRQUFRMEIsS0FBUixDQUFjRyxFQUFkLENBQU4sRUFKNEMsQ0FLNUM7O0FBQ0Esd0JBQU03QixRQUFRcUMsVUFBUixDQUFtQjdMLFFBQW5CLEVBQTZCeUosTUFBTXFDLE1BQU4sQ0FBYWYsTUFBYixFQUFxQixXQUFyQixDQUE3QixDQUFOO0FBQ0QsU0FQc0IsQ0FBdkIsQ0FuQ1UsQ0E0Q1Y7OztBQUNBQyxlQUFPZSxRQUFQLEdBQXlCQyxHQUFQLDZCQUFlO0FBQy9CLGNBQUlDLFFBQVFELElBQUlDLEtBQWhCO0FBQ0EsY0FBSWhFLE9BQU8rRCxJQUFJL0QsSUFBZixDQUYrQixDQUcvQjs7QUFDQSxjQUFJNUYsU0FBU2lKLE9BQU9DLEdBQVAsQ0FBVzdNLEtBQUs7QUFBRSxtQkFBT3VOLE1BQU12TixDQUFOLElBQVksSUFBR3VOLE1BQU12TixDQUFOLENBQVMsR0FBeEIsR0FBNkIsSUFBcEM7QUFBMEMsV0FBNUQsRUFBOEQ4TSxJQUE5RCxDQUFtRSxHQUFuRSxJQUEwRSxJQUF2RjtBQUNBLHdCQUFNaEMsUUFBUXFDLFVBQVIsQ0FBbUI3TCxRQUFuQixFQUE2QnlKLE1BQU1xQyxNQUFOLENBQWF6SixNQUFiLEVBQXFCLFdBQXJCLENBQTdCLENBQU4sRUFMK0IsQ0FNL0I7O0FBQ0EsZUFBSyxJQUFJNkosR0FBVCxJQUFnQmpFLEtBQUtrRSxNQUFyQixFQUE2QjtBQUMzQixnQkFBSUMsU0FBVSxHQUFFNUssT0FBT3JCLFFBQVMsSUFBRytMLEdBQUksRUFBdkM7QUFDQSxnQkFBSUcsU0FBVSxHQUFFaEIsRUFBRyxJQUFHYSxHQUFJLEVBQTFCOztBQUNBLGdCQUFJO0FBQ0Y7QUFDQSw0QkFBTTFDLFFBQVE4QyxNQUFSLENBQWVELE1BQWYsQ0FBTjtBQUNELGFBSEQsQ0FHRSxPQUFPMUgsQ0FBUCxFQUFVO0FBQ1YsNEJBQU02RSxRQUFRK0MsUUFBUixDQUFpQkgsTUFBakIsRUFBeUJDLE1BQXpCLENBQU47QUFDRDtBQUNGO0FBQ0YsU0FqQmlCLENBQWxCLENBN0NVLENBZ0VWOzs7QUFDQXJCLGVBQU93QixXQUFQLEdBQTRCZCxXQUFQLDZCQUF1QjtBQUMxQyxnQkFBTWUsTUFBTS9DLFNBQVMsS0FBVCxDQUFaO0FBQ0EsZ0JBQU1nRCxVQUFXLEdBQUV0QixTQUFVLElBQUc5SyxJQUFLLE1BQXJDO0FBQ0EsZ0JBQU1xTSxTQUFTbkQsUUFBUVksaUJBQVIsQ0FBMEJzQyxPQUExQixDQUFmO0FBQ0FELGNBQUlsQyxJQUFKLENBQVNvQyxNQUFUO0FBQ0FGLGNBQUlHLFNBQUosQ0FBY3ZCLEVBQWQsRUFBa0IsS0FBbEI7QUFDQW9CLGNBQUlJLFFBQUo7QUFDRCxTQVBvQixDQUFyQixDQWpFVSxDQTBFVjtBQUNBOzs7QUFFQSxZQUFJM0ssb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSUMseUJBQWlCTixlQUFlTyxRQUFmLENBQXdCSCxLQUFLSSxHQUE3QixDQUFqQixDQUFKLENBRGlDLENBRWpDOztBQUNBLGdCQUFJRixZQUFZRixLQUFLTSxJQUFMLENBQVUwRCxLQUFWLENBQWdCYSxXQUFoQyxFQUE2QztBQUMzQyxrQkFBSWIsc0JBQWNwRSxlQUFla0YsZ0JBQWYsQ0FBZ0N2TCxPQUFPL0MsT0FBdkMsRUFBZ0R3SixJQUFoRCxDQUFkLENBQUo7QUFDQSw0QkFBTStDLE9BQU9nQyxNQUFQLENBQWM7QUFBQ2YsdUJBQU9BLEtBQVI7QUFBZWhFLHNCQUFNQTtBQUFyQixlQUFkLENBQU47QUFDRDtBQUNGLFdBUFM7QUFGbUIsU0FBZixDQUFaLENBQUo7QUFXQStDLGVBQU9pQyxLQUFQO0FBRUEsZUFBTy9LLEdBQVA7QUFDRCxPQTNGRCxDQUZJLENBQU47QUErRkEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBcEdEO0FBQUE7O0FBNUNhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNsQkEvSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsK0JBQVIsQ0FBYjtBQUF1REYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBdkRGLE9BQU80TyxNQUFQLENBQWM7QUFBQ0MsV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSUMsS0FBSjtBQUFVOU8sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDNE8sUUFBTTFPLENBQU4sRUFBUTtBQUFDME8sWUFBTTFPLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFeEMsTUFBTXlPLFVBQVUsSUFBSUMsTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUErQjtBQUFDQyxnQkFBYTtBQUFkLENBQS9CLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDRlBoUCxPQUFPNE8sTUFBUCxDQUFjO0FBQUM3TCxVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJK0wsS0FBSjtBQUFVOU8sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDNE8sUUFBTTFPLENBQU4sRUFBUTtBQUFDME8sWUFBTTFPLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk2TyxJQUFKO0FBQVNqUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDNk8sV0FBSzdPLENBQUw7QUFBTzs7QUFBbkIsQ0FBN0IsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSThPLE9BQUo7QUFBWWxQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM4TyxjQUFROU8sQ0FBUjtBQUFVOztBQUF0QixDQUFwQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJK08sU0FBSjtBQUFjblAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDaVAsWUFBVS9PLENBQVYsRUFBWTtBQUFDK08sZ0JBQVUvTyxDQUFWO0FBQVk7O0FBQTFCLENBQWpDLEVBQTZELENBQTdEO0FBYW5aLE1BQU1nUCxVQUFVLElBQUlOLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBZ0M7QUFDOUNDLGdCQUFjO0FBRGdDLENBQWhDLENBQWhCOztBQUlPLE1BQU1qTSxNQUFOLFNBQXFCb00sU0FBckIsQ0FBK0I7QUFFcENFLGNBQVlDLFFBQVosRUFBc0I7QUFFcEIsUUFBSXRILFVBQVVvSCxRQUFRRyxPQUFSLENBQWdCO0FBQzVCeEYsV0FBS3VGO0FBRHVCLEtBQWhCLENBQWQ7QUFJQSxVQUFNdEgsT0FBTjtBQUVBLFFBQUlHLE9BQU8sS0FBS3FILE9BQUwsRUFBWDs7QUFFQSxZQUFRckgsS0FBS3NILElBQWI7QUFFRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSS9NLEtBQUosQ0FBVXdGLEtBQUsxRSxJQUFmLENBQWI7O0FBQ0EsYUFBS2tNLE1BQUwsR0FBYyxDQUFRQyxXQUFZN0wsTUFBRCxJQUFVLENBQUUsQ0FBL0IsRUFBaUM4TCxVQUFXeEosQ0FBRCxJQUFLLENBQUUsQ0FBbEQsOEJBQXdEO0FBQ3BFLGNBQUlyQyxNQUFPLGlCQUFnQm1FLEtBQUsySCxLQUFNLEVBQXRDO0FBQ0EsK0JBQWEsS0FBS0osS0FBTCxDQUFXSyxjQUFYLENBQTBCL0wsR0FBMUIsRUFBK0I0TCxRQUEvQixFQUF5Q0MsT0FBekMsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFFRjtBQUNFLGNBQU0sSUFBSUcsS0FBSixDQUFVLHVCQUFWLENBQU47QUFYSjtBQWNEO0FBRUQ7Ozs7OztBQUlNbk0sU0FBTixDQUFjb00sWUFBWSxFQUExQixFQUE4QkosVUFBaUJ4SixDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUF4QztBQUFBLG9DQUF5RDtBQUV2RCxVQUFJMkIsVUFBVSxLQUFLa0ksVUFBTCxFQUFkLENBRnVELENBSXZEOztBQUNBbEksY0FBUW1JLE9BQVIsQ0FBZ0JDLElBQWhCLENBQXFCO0FBQ25CWCxjQUFNLE1BRGE7QUFFbkI5TCxlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJME0sUUFBUSxFQUFaOztBQUNBLFdBQUssSUFBSWpOLE1BQVQsSUFBbUI0RSxRQUFRbUksT0FBM0IsRUFBb0M7QUFDbENFLGNBQU1qTixPQUFPcU0sSUFBYixJQUFxQjtBQUNuQjlMLGlCQUFPUCxPQUFPTyxLQURLO0FBRW5CME0saUJBQU87QUFGWSxTQUFyQjtBQUlEOztBQUVELG9CQUFNLEtBQUtWLE1BQUwsQ0FDRzVMLE1BQVAsNkJBQWdCO0FBQ2QsYUFBSyxJQUFJWCxNQUFULElBQW1CNEUsUUFBUW1JLE9BQTNCLEVBQW9DO0FBQ2xDLGNBQUl4TSxRQUFRdUwsUUFBUW9CLFFBQVIsQ0FBaUJsTixPQUFPTyxLQUF4QixDQUFaO0FBQ0EsY0FBSTRNLE9BQU90QixLQUFNdEwsS0FBTixDQUFYOztBQUNBLGNBQUk0TSxLQUFLeE0sTUFBTCxDQUFKLEVBQWtCO0FBQ2hCc00sa0JBQU1qTixPQUFPcU0sSUFBYixFQUFtQlksS0FBbkI7O0FBQ0EsZ0JBQUksT0FBT0osVUFBVTdNLE9BQU9xTSxJQUFqQixDQUFQLEtBQWtDLFdBQXRDLEVBQWtEO0FBQ2hELDRCQUFNUSxVQUFVN00sT0FBT3FNLElBQWpCLEVBQXVCMUwsTUFBdkIsQ0FBTjtBQUNEOztBQUNEO0FBQ0Q7QUFDRjtBQUNGLE9BWkQsQ0FESSxFQWNKOEwsT0FkSSxDQUFOLEVBbEJ1RCxDQW1DdkQ7O0FBQ0EsYUFBT1EsS0FBUDtBQUVELEtBdENEO0FBQUE7O0FBaENvQyxDOzs7Ozs7Ozs7OztBQ2pCdENyUSxPQUFPNE8sTUFBUCxDQUFjO0FBQUNPLGFBQVUsTUFBSUEsU0FBZjtBQUF5QnRNLFNBQU0sTUFBSUE7QUFBbkMsQ0FBZDtBQUF5RCxJQUFJaU0sS0FBSjtBQUFVOU8sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDNE8sUUFBTTFPLENBQU4sRUFBUTtBQUFDME8sWUFBTTFPLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBUW5OLE1BQU1vUSxTQUFTLElBQUkxQixNQUFNQyxVQUFWLENBQXFCLFFBQXJCLEVBQStCO0FBQzVDQyxnQkFBYztBQUQ4QixDQUEvQixDQUFmOztBQUlPLE1BQU1HLFNBQU4sQ0FBZ0I7QUFJckJFLGNBQVlySCxPQUFaLEVBQXFCO0FBQ25CLFNBQUtBLE9BQUwsR0FBZUEsT0FBZjtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQXdILFlBQVU7QUFDUixXQUFPLEtBQUt4SCxPQUFMLENBQWF5SSxZQUFwQjtBQUNEOztBQUVEUCxlQUFhO0FBQ1gsV0FBTyxLQUFLbEksT0FBWjtBQUNEOztBQUVEbkUsVUFBUTBJLFdBQWtCeEksTUFBUCw2QkFBa0IsQ0FBRSxDQUFwQixDQUFuQixFQUF5QzhMLFVBQWlCeEosQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBbkQsRUFBb0UsQ0FBRTs7QUFyQmpEOztBQXlCaEIsTUFBTXhELEtBQU4sU0FBb0JzTSxTQUFwQixDQUE4QjtBQUVuQ0UsY0FBWXFCLE9BQVosRUFBcUI7QUFFbkIsUUFBSTFJLFVBQVV3SSxPQUFPakIsT0FBUCxDQUFlO0FBQzNCeEYsV0FBSzJHO0FBRHNCLEtBQWYsQ0FBZDtBQUlBLFVBQU0xSSxPQUFOO0FBRUEsUUFBSUcsT0FBTyxLQUFLcUgsT0FBTCxFQUFYOztBQUVBLFlBQVFySCxLQUFLc0gsSUFBYjtBQUNFLFdBQUssT0FBTDtBQUNFLGFBQUtDLEtBQUwsR0FBYSxJQUFJL00sS0FBSixDQUFVd0YsS0FBSzFFLElBQWYsQ0FBYjs7QUFDQSxhQUFLa00sTUFBTCxHQUFxQjdOLEdBQVAsNkJBQWU7QUFDM0IsY0FBSWtDLE1BQU8saUJBQWdCbUUsS0FBSzJILEtBQU0sWUFBV2hPLElBQUk2TyxHQUFJLFNBQVE3TyxJQUFJMEUsRUFBRyxHQUF4RTtBQUNBLCtCQUFhLEtBQUtrSixLQUFMLENBQVcvTCxLQUFYLENBQWlCSyxHQUFqQixDQUFiO0FBQ0QsU0FIYSxDQUFkOztBQUlBOztBQUNGO0FBQ0UsY0FBTSxJQUFJZ00sS0FBSixDQUFVLG9CQUFWLENBQU47QUFUSjtBQVlEO0FBR0Q7Ozs7OztBQUlBbk0sVUFBUTBJLFdBQWtCeEksTUFBUCw2QkFBa0IsQ0FBRSxDQUFwQixDQUFuQixFQUF5QzhMLFVBQWlCeEosQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBbkQsRUFBb0U7QUFFbEUsUUFBSXVLLE1BQU1KLE9BQU9oSSxJQUFQLENBQVk7QUFDcEJrSSxlQUFTLEtBQUsxSSxPQUFMLENBQWErQjtBQURGLEtBQVosRUFFUDtBQUNEaUQsY0FBUTtBQUNOakQsYUFBSyxDQURDO0FBRU52RCxZQUFJLENBRkU7QUFHTm1LLGFBQUs7QUFIQztBQURQLEtBRk8sQ0FBVjtBQVVBLFdBQU8sSUFBSUUsT0FBSixDQUNMLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUVuQkgsVUFBSUksT0FBSixDQUNFLENBQU9sUCxHQUFQLEVBQVltUCxLQUFaLDhCQUFzQjtBQUNwQixZQUFJO0FBQ0YsY0FBSWxOLHVCQUFlLEtBQUs0TCxNQUFMLENBQVk3TixHQUFaLENBQWYsQ0FBSjtBQUNBLHdCQUFNeUssU0FBU3hJLE1BQVQsQ0FBTjtBQUNELFNBSEQsQ0FHRSxPQUFPc0MsQ0FBUCxFQUFVO0FBQ1Z3SixrQkFBUXhKLENBQVI7QUFDRDs7QUFDRCxZQUFJNEssUUFBUSxDQUFSLEtBQWNMLElBQUlQLEtBQUosRUFBbEIsRUFBK0I7QUFDN0JTO0FBQ0Q7QUFDRixPQVZELENBREY7QUFhRCxLQWhCSSxFQWlCTEksS0FqQkssQ0FrQko3SyxDQUFELElBQU87QUFDTCxZQUFNQSxDQUFOO0FBQ0QsS0FwQkksQ0FBUDtBQXVCRDs7QUFsRWtDLEM7Ozs7Ozs7Ozs7O0FDckNyQ3JHLE9BQU80TyxNQUFQLENBQWM7QUFBQ3JPLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUl1TyxLQUFKO0FBQVU5TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM0TyxRQUFNMU8sQ0FBTixFQUFRO0FBQUMwTyxZQUFNMU8sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUV4QyxNQUFNRyxVQUFVLElBQUl1TyxNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQStCO0FBQUNDLGdCQUFhO0FBQWQsQ0FBL0IsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNGUGhQLE9BQU80TyxNQUFQLENBQWM7QUFBQ3ZGLFlBQVMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUkxRyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFOztBQUUxQyxNQUFNaUosUUFBTixDQUFlO0FBQ3BCZ0csY0FBYUssUUFBUSxJQUFJL00sS0FBSixFQUFyQixFQUFrQztBQUNoQyxTQUFLd08sTUFBTCxHQUFjekIsS0FBZDtBQUNEOztBQUVLMUYsYUFBTixDQUFtQm9ILGNBQW5CLEVBQW1DdkgsV0FBVyxDQUE5QztBQUFBLG9DQUFpRDtBQUMvQyxvQkFBTSxLQUFLc0gsTUFBTCxDQUFZRSxXQUFaLENBQ0osbUJBREksRUFFSCxzQkFBcUJELGNBQWUsRUFGakMsRUFHSixFQUhJLEVBR0E7QUFDRkUsZUFBT3pILFFBREw7QUFFRjBILHlCQUFpQixDQUZmO0FBR0ZyTCxxQkFBYTtBQUhYLE9BSEEsQ0FBTjtBQVVBLG9CQUFNLEtBQUtpTCxNQUFMLENBQVlFLFdBQVosQ0FDSixtQkFESSxFQUVILHNCQUFxQkQsY0FBZSxFQUZqQyxFQUdKLEVBSEksRUFHQTtBQUNGRSxlQUFPekgsUUFETDtBQUVGM0QscUJBQWE7QUFGWCxPQUhBLENBQU47QUFRRCxLQW5CRDtBQUFBOztBQXFCTTZFLGtCQUFOLENBQXdCdkosSUFBeEI7QUFBQSxvQ0FBOEI7QUFDNUIsVUFBSWdRLFlBQVloUSxLQUFLK0ksVUFBckI7QUFFQSxVQUFJM0csTUFBTSxFQUFWLENBSDRCLENBSzVCOztBQUNBLFVBQUk2TixTQUFnQnpPLEdBQVAsNkJBQWU7QUFDMUIsWUFBSWdCLE1BQU87OzJCQUVVeEMsS0FBS2tRLFVBQVcsY0FBYTFPLEdBQUk7T0FGdEQ7QUFJQVksWUFBSXdNLElBQUosZUFBZSxLQUFLZSxNQUFMLENBQVl4TixLQUFaLENBQWtCSyxHQUFsQixDQUFmO0FBQ0QsT0FOWSxDQUFiLENBTjRCLENBYzVCOzs7QUFDQSxVQUFJMk4sUUFBZTNPLEdBQVAsNkJBQWU7QUFDekI7QUFDQSxZQUFJZ0IsTUFBTzs7MkJBRVV4QyxLQUFLa1EsVUFBVyxjQUFhMU8sR0FBSTtPQUZ0RDtBQUlBLFlBQUk0Tyx5QkFBaUIsS0FBS1QsTUFBTCxDQUFZeE4sS0FBWixDQUFrQkssR0FBbEIsQ0FBakIsQ0FBSjtBQUNBLFlBQUk0TixTQUFTLENBQVQsRUFBWSxVQUFaLENBQUosRUFBNkI7QUFFN0JoTyxZQUFJd00sSUFBSixlQUNRLEtBQUtlLE1BQUwsQ0FBWS9LLFdBQVosQ0FDSixpQkFESSxFQUVKLEVBRkksRUFHSjtBQUNFc0wsc0JBQVlsUSxLQUFLa1EsVUFEbkI7QUFFRTFPLGVBQUtBLEdBRlA7QUFHRXVILHNCQUFZaUgsU0FIZDtBQUlFdkwsdUJBQWE7QUFKZixTQUhJLENBRFI7QUFXRCxPQXBCVyxDQUFaOztBQXNCQSxXQUFLLElBQUk0TCxNQUFULElBQW1CclEsS0FBS3NRLElBQXhCLEVBQThCO0FBQzVCLGdCQUFRRCxPQUFPRSxHQUFmO0FBQ0UsZUFBSyxJQUFMO0FBQ0UsMEJBQU1KLE1BQU1FLE9BQU83TyxHQUFiLENBQU47QUFDQTs7QUFDRixlQUFLLEtBQUw7QUFDRSwwQkFBTXlPLE9BQU9JLE9BQU83TyxHQUFkLENBQU47QUFDQTtBQU5KO0FBUUQ7O0FBRUQsYUFBTztBQUNMWSxhQUFLQTtBQURBLE9BQVA7QUFHRCxLQW5ERDtBQUFBOztBQXFETWlILG9CQUFOLENBQTBCckosSUFBMUI7QUFBQSxvQ0FBZ0M7QUFDOUIsVUFBSXdRLFlBQVl4USxLQUFLa1EsVUFBckI7QUFDQSxVQUFJN0QsU0FBU3JNLEtBQUtxTSxNQUFsQjtBQUNBLFVBQUkyRCxZQUFZaFEsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVixDQUw4QixDQU85Qjs7QUFDQSxVQUFJSSxNQUFPLG9EQUFtRGdPLFNBQVUsRUFBeEU7QUFDQXBPLFVBQUl3TSxJQUFKLGVBQWUsS0FBS2UsTUFBTCxDQUFZeE4sS0FBWixDQUFrQkssR0FBbEIsQ0FBZixHQVQ4QixDQVc5Qjs7QUFDQSxXQUFLLElBQUlnSSxJQUFJLENBQWIsRUFBZ0JBLElBQUk2QixPQUFPb0UsTUFBM0IsRUFBbUNqRyxHQUFuQyxFQUF3QztBQUN0QyxzQkFBTSxLQUFLbUYsTUFBTCxDQUFZL0ssV0FBWixDQUNKLG1CQURJLEVBQ2lCO0FBQ25Cc0wsc0JBQVlNLFNBRE87QUFFbkJ6SCxzQkFBWWlILFNBRk87QUFHbkJVLHFCQUFXckUsT0FBTzdCLENBQVAsQ0FIUTtBQUluQm1HLGdCQUFNbkcsSUFBSTtBQUpTLFNBRGpCLEVBTUQ7QUFDRC9GLHVCQUFhO0FBRFosU0FOQyxDQUFOO0FBVUQ7O0FBRUQsYUFBTztBQUNMckMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0E1QkQ7QUFBQTs7QUE4Qk1rSCxlQUFOLENBQXFCdEosSUFBckI7QUFBQSxvQ0FBMkI7QUFDekIsVUFBSTRRLGFBQWEsRUFBakI7QUFDQSxVQUFJQyxPQUFPLEVBQVgsQ0FGeUIsQ0FJekI7O0FBRUFBLGFBQU8sQ0FDTCxRQURLLEVBRUwsTUFGSyxFQUdMLE1BSEssRUFJTCxrQkFKSyxFQUtMLG9CQUxLLEVBTUwsYUFOSyxFQU9MLFdBUEssQ0FBUDs7QUFTQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRCxvQkFBTSxLQUFLbkIsTUFBTCxDQUFZRSxXQUFaLENBQ0osYUFESSxFQUVILGdCQUFlN1AsS0FBS2tRLFVBQVcsRUFGNUIsRUFHSlUsVUFISSxFQUdRO0FBQ1ZsTSxxQkFBYTtBQURILE9BSFIsQ0FBTixFQW5CeUIsQ0EyQnpCOztBQUVBa00sbUJBQWEsRUFBYjtBQUNBQyxhQUFPLENBQ0wsa0JBREssRUFFTCxjQUZLLEVBR0wsWUFISyxFQUlMLFNBSkssRUFLTCxTQUxLLEVBTUwsY0FOSyxDQUFQOztBQVFBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVELFVBQUkxTyxvQkFBWSxLQUFLdU4sTUFBTCxDQUFZRSxXQUFaLENBQ2QsbUJBRGMsRUFFYixnQkFBZTdQLEtBQUtrUSxVQUFXLEVBRmxCLEVBR2RVLFVBSGMsRUFHRjtBQUNWbE0scUJBQWE7QUFESCxPQUhFLENBQVosQ0FBSjtBQVFBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBckREO0FBQUE7O0FBdURNNkcsZUFBTixDQUFxQmpKLElBQXJCO0FBQUEsb0NBQTJCO0FBQ3pCLFVBQUlnUSxZQUFZaFEsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVjtBQUVBLFVBQUl3TyxhQUFhLEVBQWpCO0FBQ0EsVUFBSUMsT0FBTyxFQUFYO0FBRUFBLGFBQU8sQ0FDTCxNQURLLEVBRUwsb0JBRkssQ0FBUCxDQVJ5QixDQVl6QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRDFPLFVBQUk4TixVQUFKLGlCQUF1QixLQUFLUCxNQUFMLENBQVkvSyxXQUFaLENBQ3JCLGFBRHFCLEVBRXJCZ00sVUFGcUIsRUFFVDtBQUNWN0gsb0JBQVlpSCxTQURGO0FBRVZ0TixnQkFBUSxDQUZFO0FBR1Y4QixjQUFNLE1BSEk7QUFJVnVNLDBCQUFrQixNQUpSO0FBS1ZDLHFCQUFhLE1BTEg7QUFNVkMsbUJBQVcsTUFORDtBQU9WeE0scUJBQWEsT0FQSDtBQVFWQyxxQkFBYTtBQVJILE9BRlMsQ0FBdkI7QUFjQWtNLG1CQUFhLEVBQWI7QUFDQUMsYUFBTyxDQUNMLGNBREssRUFFTCxpQkFGSyxFQUdMLFNBSEssRUFJTCxTQUpLLEVBS0wsY0FMSyxDQUFQLENBcEN5QixDQTJDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRDFPLFVBQUl1RyxnQkFBSixpQkFBNkIsS0FBS2dILE1BQUwsQ0FBWS9LLFdBQVosQ0FDM0IsbUJBRDJCLEVBRTNCZ00sVUFGMkIsRUFFZjtBQUNWN0gsb0JBQVlpSCxTQURGO0FBRVZFLG9CQUFZOU4sSUFBSThOLFVBRk47QUFHVkosZUFBTyxDQUhHO0FBSVZDLHlCQUFpQixDQUpQO0FBS1ZtQiw0QkFBb0IsTUFMVjtBQU1WQyw0QkFBb0IsTUFOVjtBQU9WQywwQkFBa0IsTUFQUjtBQVFWQyxvQkFBWSxNQVJGO0FBU1Y1TSxxQkFBYSxPQVRIO0FBVVZDLHFCQUFhO0FBVkgsT0FGZSxDQUE3Qjs7QUFnQkEsV0FBSyxJQUFJb00sQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVEMU8sVUFBSWtQLGdCQUFKLGlCQUE2QixLQUFLM0IsTUFBTCxDQUFZL0ssV0FBWixDQUMzQixtQkFEMkIsRUFDTixFQURNLEVBQ0Y7QUFDdkIrRCwwQkFBa0J2RyxJQUFJdUcsZ0JBREM7QUFFdkJJLG9CQUFZaUgsU0FGVztBQUd2QkYsZUFBTyxDQUhnQjtBQUl2QnJMLHFCQUFhLE9BSlU7QUFLdkJDLHFCQUFhO0FBTFUsT0FERSxDQUE3QixFQXpFeUIsQ0FtRnpCOztBQUNBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBdkZEO0FBQUE7O0FBcEtvQixDOzs7Ozs7Ozs7OztBQ0Z0QjVELE9BQU80TyxNQUFQLENBQWM7QUFBQ21FLG1CQUFnQixNQUFJQSxlQUFyQjtBQUFxQ0MsWUFBUyxNQUFJQSxRQUFsRDtBQUEyREMsaUJBQWMsTUFBSUEsYUFBN0U7QUFBMkY3SixpQkFBYyxNQUFJQTtBQUE3RyxDQUFkO0FBQTJJLElBQUkwRixLQUFKO0FBQVU5TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM0TyxRQUFNMU8sQ0FBTixFQUFRO0FBQUMwTyxZQUFNMU8sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSThTLFdBQUo7QUFBZ0JsVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNnVCxjQUFZOVMsQ0FBWixFQUFjO0FBQUM4UyxrQkFBWTlTLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSTZPLElBQUo7QUFBU2pQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM2TyxXQUFLN08sQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJOE8sT0FBSjtBQUFZbFAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzhPLGNBQVE5TyxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEOztBQVMxZixNQUFNMlMsZUFBTixDQUFzQjtBQUMzQjFELGNBQWFsSCxJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixRQUFJbUwsUUFBSjs7QUFDQSxZQUFRaEwsS0FBS3NILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRTBELG1CQUFXLElBQUlGLGFBQUosQ0FBa0I5SyxJQUFsQixFQUF3QkgsT0FBeEIsQ0FBWDtBQUZKOztBQUtBLFdBQU9tTCxRQUFQO0FBQ0Q7O0FBVDBCOztBQVl0QixNQUFNSCxRQUFOLENBQWU7QUFDcEIzRCxjQUFhbEgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsU0FBS0csSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS0gsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7O0FBRUQsU0FBT29MLE9BQVAsQ0FBZ0JqTCxJQUFoQixFQUFzQkgsT0FBdEIsRUFBK0I7QUFDN0IsWUFBUUcsS0FBS3NILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxlQUFPLElBQUl3RCxhQUFKLENBQWtCOUssSUFBbEIsRUFBd0JILE9BQXhCLENBQVA7O0FBQ0Y7QUFDRSxjQUFNLElBQUlnSSxLQUFKLENBQVUsbUJBQVYsQ0FBTjtBQUpKO0FBTUQ7O0FBRURxRCxhQUFZO0FBQ1YsV0FBTyxLQUFLbEwsSUFBWjtBQUNEOztBQUVEbUwsYUFBWTtBQUNWLFdBQU8sS0FBS25MLElBQUwsQ0FBVTFFLElBQWpCO0FBQ0Q7O0FBRUQ4UCxnQkFBZTtBQUNiLFdBQU8sS0FBS3ZMLE9BQVo7QUFDRDs7QUFFRHdMLHFCQUNFQyxLQUFLLENBQU83RCxXQUFXN0wsVUFBVSxDQUFFLENBQTlCLEVBQWdDOEwsVUFBVXhKLEtBQUssQ0FBRSxDQUFqRCw4QkFBc0QsQ0FBRSxDQUF4RCxDQURQLEVBRUU7QUFDQSxTQUFLc0osTUFBTCxHQUFjOEQsRUFBZDtBQUNEO0FBRUQ7Ozs7Ozs7Ozs7O0FBU001UCxTQUFOLENBQWU2UCxZQUFZLEVBQTNCO0FBQUEsb0NBQStCO0FBQzdCLFVBQUkxTCxVQUFVLEtBQUt1TCxXQUFMLEVBQWQsQ0FENkIsQ0FHN0I7O0FBQ0F2TCxjQUFRbUksT0FBUixDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJwTyxjQUFNLE1BRGE7QUFFbkIyQixlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJZ1EsVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSUMsQ0FBVCxJQUFjNUwsUUFBUW1JLE9BQXRCLEVBQStCLENBQzlCOztBQUVELFVBQUlBLFVBQVUsRUFBZDs7QUFFQSxXQUFLLElBQUl5RCxDQUFULElBQWM1TCxRQUFRbUksT0FBdEIsRUFBK0I7QUFDN0J3RCxnQkFBUUMsRUFBRTVSLElBQVYsSUFBa0I7QUFDaEIyQixpQkFBT2lRLEVBQUVqUSxLQURPO0FBRWhCa1EsaUJBQU8sT0FBT0QsRUFBRUMsS0FBVCxLQUFtQixXQUFuQixHQUFpQ0QsRUFBRUMsS0FBbkMsR0FBMkMsQ0FGbEM7QUFHaEJ4RCxpQkFBTztBQUhTLFNBQWxCO0FBS0FGLGdCQUFRQyxJQUFSLENBQ0U7QUFDRXBPLGdCQUFNNFIsRUFBRTVSLElBRFY7QUFFRXVPLGdCQUFNdEIsS0FBS0MsUUFBUW9CLFFBQVIsQ0FBaUJzRCxFQUFFalEsS0FBbkIsQ0FBTDtBQUZSLFNBREY7QUFNRDs7QUFFRCxvQkFBTSxLQUFLZ00sTUFBTCxDQUNKLENBQU81TCxNQUFQLEVBQWU2RixPQUFmLDhCQUEyQjtBQUN6QixhQUFLLElBQUlnSyxDQUFULElBQWN6RCxPQUFkLEVBQXVCO0FBQ3JCO0FBQ0EsY0FBSTJELElBQUlILFFBQVFDLEVBQUU1UixJQUFWLENBQVI7O0FBQ0EsY0FBSThSLEVBQUVELEtBQU4sRUFBYTtBQUNYLGdCQUFJQyxFQUFFekQsS0FBRixJQUFXeUQsRUFBRUQsS0FBakIsRUFBd0I7QUFDdEI7QUFDRDtBQUNGOztBQUVELGNBQUlELEVBQUVyRCxJQUFGLENBQU94TSxNQUFQLENBQUosRUFBb0I7QUFDbEI7QUFDQStQLGNBQUV6RCxLQUFGLEdBRmtCLENBSWxCOztBQUNBLGdCQUFJLE9BQU9xRCxVQUFVRSxFQUFFNVIsSUFBWixDQUFQLEtBQTZCLFdBQWpDLEVBQThDO0FBQzVDLDRCQUFNMFIsVUFBVUUsRUFBRTVSLElBQVosRUFBa0IrQixNQUFsQixFQUEwQjZGLE9BQTFCLENBQU47QUFDRDs7QUFDRDtBQUNEO0FBQ0Y7QUFDRixPQXJCRCxDQURJLENBQU4sRUE3QjZCLENBcUQ3Qjs7QUFDQSxhQUFPK0osT0FBUDtBQUNELEtBdkREO0FBQUE7O0FBMUNvQjs7QUFvR2YsTUFBTVYsYUFBTixTQUE0QkQsUUFBNUIsQ0FBcUM7QUFDMUMzRCxjQUFhbEgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTUcsSUFBTixFQUFZSCxPQUFaO0FBRUEsUUFBSXZFLE9BQU8sS0FBSzZQLFFBQUwsRUFBWDtBQUVBLFNBQUs1RCxLQUFMLEdBQWEsSUFBSS9NLEtBQUosQ0FBVWMsSUFBVixDQUFiO0FBQ0EsU0FBSytQLGtCQUFMLENBQXdCLENBQU81RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQsVUFBSTdMLE1BQU8saUJBQWdCbUUsS0FBSzJILEtBQU0sRUFBdEM7QUFDQSxVQUFJbE0sb0JBQVksS0FBSzhMLEtBQUwsQ0FBV0ssY0FBWCxDQUEwQi9MLEdBQTFCLEVBQStCNEwsUUFBL0IsRUFBMEN2SixDQUFELElBQU87QUFBRSxjQUFNQSxDQUFOO0FBQVMsT0FBM0QsQ0FBWixDQUFKO0FBQ0EsYUFBT3pDLEdBQVA7QUFDRCxLQUp1QixDQUF4QjtBQUtEOztBQVp5Qzs7QUFtQnJDLE1BQU13RixhQUFOLFNBQTRCNEosUUFBNUIsQ0FBcUM7QUFDMUMzRCxjQUFhbEgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTUcsSUFBTixFQUFZSCxPQUFaLEVBRDBCLENBRzFCOztBQUNBLFNBQUt3TCxrQkFBTCxDQUF3QixDQUFPNUQsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBQ25ELFVBQUlrRSxNQUFKO0FBQ0FBLDZCQUFlYixZQUFZYyxPQUFaLENBQW9CN0wsS0FBSzhMLEdBQXpCLENBQWYsRUFGbUQsQ0FJbkQ7O0FBQ0EsVUFBSWhNLEtBQUs4TCxPQUFPOUwsRUFBUCxDQUFVRSxLQUFLK0wsUUFBZixDQUFUO0FBQ0EsVUFBSTNMLGFBQWFOLEdBQUdNLFVBQUgsQ0FBY0osS0FBS0ksVUFBbkIsQ0FBakI7QUFFQSxVQUFJcUIsVUFBVTtBQUNabUssZ0JBQVFBLE1BREk7QUFFWnhMLG9CQUFZQSxVQUZBO0FBR1oyTCxrQkFBVWpNO0FBSEUsT0FBZDtBQU1BLFVBQUkySSxNQUFNckksV0FBV0MsSUFBWCxFQUFWLENBZG1ELENBZ0JuRDs7QUFDQW9JLFVBQUl1RCxhQUFKLENBQWtCLGlCQUFsQixFQUFxQyxJQUFyQyxFQWpCbUQsQ0FtQm5EOztBQUNBLFVBQUk7QUFDRiw2QkFBYXZELElBQUl3RCxPQUFKLEVBQWIsR0FBNEI7QUFDMUIsY0FBSXRTLG9CQUFZOE8sSUFBSXlELElBQUosRUFBWixDQUFKO0FBQ0Esd0JBQU16RSxTQUFTOU4sR0FBVCxFQUFjOEgsT0FBZCxDQUFOO0FBQ0Q7O0FBQUE7QUFDRixPQUxELFNBS1U7QUFDUjtBQUNBLHNCQUFNZ0gsSUFBSWpDLEtBQUosRUFBTjtBQUNEO0FBQ0YsS0E3QnVCLENBQXhCO0FBOEJEOztBQW5DeUMsQzs7Ozs7Ozs7Ozs7QUM1STVDM08sT0FBTzRPLE1BQVAsQ0FBYztBQUFDek8sV0FBUSxNQUFJd0k7QUFBYixDQUFkO0FBQTRDLElBQUlULGVBQUo7QUFBb0JsSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNnSSxrQkFBZ0I5SCxDQUFoQixFQUFrQjtBQUFDOEgsc0JBQWdCOUgsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXRDLEVBQThFLENBQTlFO0FBQWlGLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBOUMsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWtVLFFBQUo7QUFBYXRVLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ29VLFdBQVNsVSxDQUFULEVBQVc7QUFBQ2tVLGVBQVNsVSxDQUFUO0FBQVc7O0FBQXhCLENBQTdCLEVBQXVELENBQXZEOztBQVVwTyxNQUFNdUksY0FBTixDQUFxQjtBQUM1QkssTUFBTixDQUFZYixJQUFaO0FBQUEsb0NBQWtCO0FBQ2hCLFdBQUtvTSxLQUFMLGlCQUFtQnJNLGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCLE9BQTFCLENBQW5CO0FBQ0EsV0FBS3FNLFFBQUwsaUJBQXNCdE0sZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEIsVUFBMUIsQ0FBdEI7QUFDRCxLQUhEO0FBQUE7O0FBS00yQixVQUFOLENBQWdCMkssTUFBaEI7QUFBQSxvQ0FBd0I7QUFDdEIsVUFBSUMsd0JBQWdCLEtBQUtILEtBQUwsQ0FBV2hGLE9BQVgsQ0FBbUI7QUFDckN4RixhQUFLMEs7QUFEZ0MsT0FBbkIsRUFFakI7QUFDRHJNLG9CQUFZO0FBQ1YscUJBQVc7QUFERDtBQURYLE9BRmlCLENBQWhCLENBQUo7QUFPQSxVQUFJdU0sY0FBY0QsUUFBUUUsT0FBMUIsQ0FSc0IsQ0FVdEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxVQUFJQyxhQUFhLEVBQWpCOztBQUVBLFdBQUssSUFBSUMsVUFBVCxJQUF1QkgsV0FBdkIsRUFBb0M7QUFDbEMsWUFBSUksY0FBYyxDQUFsQjs7QUFFQSxhQUFLLElBQUkvQyxTQUFULElBQXNCOEMsVUFBdEIsRUFBa0M7QUFDaEMsY0FBSUosd0JBQWdCLEtBQUtGLFFBQUwsQ0FBY2pGLE9BQWQsQ0FBc0I7QUFDeEN4RixpQkFBS2lJO0FBRG1DLFdBQXRCLEVBRWpCO0FBQ0Q1Six3QkFBWTtBQUNWLHVCQUFTO0FBREM7QUFEWCxXQUZpQixDQUFoQixDQUFKO0FBT0EsY0FBSTRNLGFBQWFOLFFBQVFwRCxLQUF6QixDQVJnQyxDQVVoQzs7QUFDQSxlQUFLLElBQUlBLEtBQVQsSUFBa0IwRCxVQUFsQixFQUE4QjtBQUM1QkQsMkJBQWV6RCxNQUFNekgsUUFBckI7QUFDRDtBQUNGOztBQUVEZ0wsbUJBQVd6RSxJQUFYLENBQWdCMkUsV0FBaEI7QUFDRCxPQXRDcUIsQ0F3Q3RCOzs7QUFDQSxVQUFJbEwsV0FBV29MLEtBQUtDLEdBQUwsQ0FBU0MsS0FBVCxDQUFlLElBQWYsRUFBcUJOLFVBQXJCLENBQWY7QUFFQSxhQUFPaEwsUUFBUDtBQUNELEtBNUNEO0FBQUE7QUE4Q0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJNWCxVQUFOLENBQWdCN0gsUUFBaEIsRUFBMEJ1SCxLQUExQixFQUFpQ0MsU0FBUyxJQUExQyxFQUFnREMsU0FBUyxJQUF6RDtBQUFBLG9DQUErRDtBQUM3RDtBQUNBLFVBQUkrRSxTQUFTdE4sUUFBUWlJLElBQVIsQ0FBYTtBQUN4Qm5ILGtCQUFVQTtBQURjLE9BQWIsRUFFVitULEtBRlUsR0FFRm5JLEdBRkUsQ0FFRzdNLENBQUQsSUFBT0EsRUFBRTZCLGdCQUZYLENBQWIsQ0FGNkQsQ0FNN0Q7O0FBQ0EsVUFBSW1CLFNBQVMsRUFBYjtBQUNBQSxhQUFPd0YsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFZekYsT0FBT2lTLFlBQVAsR0FBc0J4TSxNQUF0QjtBQUNaLFVBQUlDLE1BQUosRUFBWTFGLE9BQU9rUyxZQUFQLEdBQXNCeE0sTUFBdEI7QUFFWixVQUFJbEYsb0JBQVksS0FBSzJRLEtBQUwsQ0FBV2dCLFVBQVgsQ0FDZG5TLE1BRGMsRUFDTjtBQUNOb1MsZUFBTztBQUNMM0gsa0JBQVE7QUFDTjRILG1CQUFPNUg7QUFERDtBQURIO0FBREQsT0FETSxDQUFaLENBQUosQ0FaNkQsQ0FzQjdEOztBQUNBLGFBQU9BLE1BQVA7QUFDRCxLQXhCRDtBQUFBO0FBMEJBOzs7Ozs7Ozs7O0FBUU0xRSxZQUFOLENBQWtCUCxLQUFsQixFQUF5QkMsU0FBUyxJQUFsQyxFQUF3Q0MsU0FBUyxJQUFqRDtBQUFBLG9DQUF1RDtBQUNyRDtBQUNBLFVBQUkxRixTQUFTLEVBQWI7QUFDQUEsYUFBT3dGLEtBQVAsR0FBZUEsS0FBZjtBQUNBLFVBQUlDLE1BQUosRUFBWXpGLE9BQU9pUyxZQUFQLEdBQXNCeE0sTUFBdEI7QUFDWixVQUFJQyxNQUFKLEVBQVkxRixPQUFPa1MsWUFBUCxHQUFzQnhNLE1BQXRCO0FBRVosVUFBSWxGLG9CQUFZLEtBQUsyUSxLQUFMLENBQVdnQixVQUFYLENBQ2RuUyxNQURjLEVBQ047QUFDTnVILGNBQU07QUFDSmtELGtCQUFRO0FBREo7QUFEQSxPQURNLENBQVosQ0FBSjtBQU9ELEtBZEQ7QUFBQTtBQWdCQTs7Ozs7Ozs7Ozs7Ozs7OztBQWNNNkgsY0FBTixDQUFvQi9MLElBQXBCLEVBQTBCK0ssT0FBMUI7QUFBQSxvQ0FBbUM7QUFDakM7Ozs7Ozs7O0FBUUEsVUFBSTNDLE1BQU0sQ0FBQztBQUNUNEQsZUFBTyxNQURFO0FBRVRDLGlCQUFTak0sS0FBS2tNLFFBRkw7QUFHVG5CLGlCQUFTO0FBQ1BvQixpQkFBTztBQURBLFNBSEE7QUFNVG5TLGVBQU87QUFDTDBSLHdCQUFjMUwsS0FBSzBMLFlBRGQ7QUFFTEMsd0JBQWMzTCxLQUFLMkw7QUFGZDtBQU5FLE9BQUQsRUFXVjtBQUNFSyxlQUFPaE0sS0FBS29NLFdBRGQ7QUFFRUgsaUJBQVNqTSxLQUFLMEwsWUFGaEI7QUFHRVgsaUJBQVM7QUFDUG9CLGlCQUFPO0FBREEsU0FIWDtBQU1FblMsZUFBTztBQUNMa1Msb0JBQVVsTSxLQUFLa00sUUFEVjtBQUVMUCx3QkFBYzNMLEtBQUsyTDtBQUZkO0FBTlQsT0FYVSxFQXNCVjtBQUNFSyxlQUFPaE0sS0FBS3FNLFdBRGQ7QUFFRUosaUJBQVNqTSxLQUFLMkwsWUFGaEI7QUFHRVosaUJBQVM7QUFDUG9CLGlCQUFPO0FBREEsU0FIWDtBQU1FblMsZUFBTztBQUNMa1Msb0JBQVVsTSxLQUFLa00sUUFEVjtBQUVMUix3QkFBYzFMLEtBQUswTDtBQUZkO0FBTlQsT0F0QlUsQ0FBVjtBQW1DQSxVQUFJWSxRQUFRLEVBQVo7O0FBRUEsV0FBSyxJQUFJQyxDQUFULElBQWNuRSxHQUFkLEVBQW1CO0FBQ2pCa0UsY0FBTTdGLElBQU4sQ0FBVztBQUNUK0Ysb0NBQWtCLEtBQUs1QixLQUFMLENBQVc3TCxTQUFYLENBQ2hCLENBQUM7QUFDQzBOLG9CQUFRQyxPQUFPQyxNQUFQLENBQWNKLEVBQUV2UyxLQUFoQixFQUF1QjtBQUM3QmlGLHFCQUFPZSxLQUFLZjtBQURpQixhQUF2QjtBQURULFdBQUQsRUFLQTtBQUNFMk4sc0JBQVVGLE9BQU9DLE1BQVAsQ0FBY0osRUFBRXhCLE9BQWhCLEVBQXlCQSxPQUF6QjtBQURaLFdBTEEsRUFRQTtBQUNFOEIsbUJBQU87QUFDTHpNLG1CQUFLO0FBREE7QUFEVCxXQVJBLENBRGdCLEVBZWhCdEIsT0FmZ0IsRUFBbEIsQ0FEUztBQWlCVGdPLGlCQUFPUDtBQWpCRSxTQUFYO0FBbUJEOztBQUVELGFBQU9ELEtBQVA7QUFDRCxLQXJFRDtBQUFBLEdBeklrQyxDQWdObEM7QUFDQTs7O0FBQ016SixlQUFOLENBQXFCa0IsR0FBckI7QUFBQSxvQ0FBMEI7QUFDeEIsVUFBSS9ELElBQUosQ0FEd0IsQ0FFeEI7O0FBQ0EsVUFBSSxPQUFPK0QsR0FBUCxLQUFlLFFBQW5CLEVBQTZCO0FBQzNCLFlBQUlnSixNQUFNLElBQUlDLE1BQUosQ0FBWSxHQUFFakosR0FBSSxHQUFsQixDQUFWO0FBQ0EsWUFBSWtELE1BQU0sS0FBSzJELEtBQUwsQ0FBVy9MLElBQVgsQ0FBZ0IsRUFBaEIsRUFBb0I7QUFDNUJKLHNCQUFZO0FBQ1ZRLG1CQUFPLENBREc7QUFFVnlNLDBCQUFjLENBRko7QUFHVkMsMEJBQWM7QUFISjtBQURnQixTQUFwQixDQUFWOztBQVFBLGVBQU8sQ0FBUCxFQUFVO0FBQ1IsY0FBSTtBQUNGM0wsaUNBQWFpSCxJQUFJeUQsSUFBSixFQUFiO0FBQ0EsZ0JBQUl1QyxzQkFBY2pOLEtBQUtJLEdBQUwsQ0FBUzhNLFdBQVQsR0FBdUJELEtBQXZCLENBQTZCRixHQUE3QixDQUFkLENBQUo7O0FBQ0EsZ0JBQUlFLEtBQUosRUFBVztBQUNUO0FBQ0Q7QUFDRixXQU5ELENBTUUsT0FBT3ZRLENBQVAsRUFBVTtBQUNWO0FBQ0EsbUJBQU9xSCxHQUFQO0FBQ0Q7QUFDRjtBQUVGLE9BdkJELE1BdUJPO0FBQ0wvRCxlQUFPK0QsR0FBUDtBQUNEOztBQUVELFVBQUlvSixhQUFhLEVBQWpCO0FBQ0EsVUFBSW5OLEtBQUtmLEtBQVQsRUFBZ0JrTyxXQUFXMUcsSUFBWCxDQUFnQnpHLEtBQUtmLEtBQXJCO0FBQ2hCLFVBQUllLEtBQUswTCxZQUFULEVBQXVCeUIsV0FBVzFHLElBQVgsQ0FBZ0J6RyxLQUFLMEwsWUFBckI7QUFDdkIsVUFBSTFMLEtBQUsyTCxZQUFULEVBQXVCd0IsV0FBVzFHLElBQVgsQ0FBZ0J6RyxLQUFLMkwsWUFBckI7QUFDdkIsYUFBT3dCLFdBQVc1SixJQUFYLENBQWdCLEdBQWhCLENBQVA7QUFDRCxLQW5DRDtBQUFBOztBQXFDTTVDLGtCQUFOLENBQXdCa0gsU0FBeEIsRUFBbUM3SCxJQUFuQztBQUFBLG9DQUF5QztBQUN2QztBQUNBLFVBQUlvTixZQUFhbEIsUUFBRCxJQUFjQSxhQUFhLFFBQWIsR0FBd0IsT0FBeEIsR0FBa0NBLFFBQWhFLENBRnVDLENBSXZDOzs7QUFDQSxVQUFJN0QsWUFBWSxJQUFoQjtBQUNBLFVBQUk4RSxhQUFhLEVBQWpCLENBTnVDLENBUXZDO0FBQ0E7O0FBQ0EsVUFBSW5OLEtBQUtmLEtBQVQsRUFBZ0JrTyxXQUFXMUcsSUFBWCxDQUFnQnpHLEtBQUtmLEtBQXJCO0FBQ2hCLFVBQUllLEtBQUswTCxZQUFULEVBQXVCeUIsV0FBVzFHLElBQVgsQ0FBZ0J6RyxLQUFLMEwsWUFBckI7QUFDdkIsVUFBSTFMLEtBQUsyTCxZQUFULEVBQXVCd0IsV0FBVzFHLElBQVgsQ0FBZ0J6RyxLQUFLMkwsWUFBckIsRUFaZ0IsQ0FjdkM7O0FBQ0EsVUFBSTBCLGFBQUo7O0FBQ0EsY0FBUXJOLEtBQUtrTSxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VtQiwwQkFBZ0IsQ0FBaEI7QUFDQTs7QUFDRixhQUFLLFFBQUw7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7O0FBQ0Y7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7QUFUSixPQWhCdUMsQ0E0QnZDOzs7QUFDQSxVQUFJbEYsT0FBTyxFQUFYOztBQUNBLGNBQVFuSSxLQUFLa00sUUFBYjtBQUNFLGFBQUssS0FBTDtBQUNFL0QsZUFBSzFCLElBQUwsQ0FBVTtBQUNScE4saUJBQUssQ0FERztBQUVSK08saUJBQUs7QUFGRyxXQUFWLEVBR0c7QUFDRC9PLGlCQUFLLENBREo7QUFFRCtPLGlCQUFLO0FBRkosV0FISDtBQU9BOztBQUNGLGFBQUssUUFBTDtBQUNFRCxlQUFLMUIsSUFBTCxDQUFVO0FBQ1JwTixpQkFBSyxDQURHO0FBRVIrTyxpQkFBSztBQUZHLFdBQVYsRUFHRztBQUNEL08saUJBQUssQ0FESjtBQUVEK08saUJBQUs7QUFGSixXQUhIO0FBT0E7QUFsQkosT0E5QnVDLENBbUR2Qzs7O0FBQ0EsVUFBSWtGLGNBQWMsSUFBbEI7O0FBQ0EsY0FBUXROLEtBQUtrTSxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VvQix3QkFBYyxJQUFkO0FBQ0E7O0FBQ0YsYUFBSyxRQUFMO0FBQ0VBLHdCQUFjLEdBQWQ7QUFDQTtBQU5KLE9BckR1QyxDQThEdkM7QUFDQTtBQUNBOzs7QUFFQSxVQUFJaEIsc0JBQWMsS0FBS1AsWUFBTCxDQUFrQi9MLElBQWxCLEVBQXdCO0FBQ3hDK0gsb0JBQVk7QUFENEIsT0FBeEIsQ0FBZCxDQUFKLENBbEV1QyxDQXNFdkM7QUFFQTs7QUFDQXVFLGNBQVFBLE1BQU1oSixHQUFOLENBQ0xpSyxJQUFELElBQVU7QUFDUkEsYUFBS1QsS0FBTCxDQUFXYixPQUFYLEdBQXFCbUIsVUFBVUcsS0FBS1QsS0FBTCxDQUFXYixPQUFyQixDQUFyQjtBQUNBc0IsYUFBS2YsVUFBTCxHQUFrQmUsS0FBS2YsVUFBTCxDQUFnQmxKLEdBQWhCLENBQ2ZrSyxTQUFELElBQWU7QUFDYkEsb0JBQVVyQixLQUFWLEdBQWtCaUIsVUFBVUksVUFBVXJCLEtBQXBCLENBQWxCO0FBQ0EsaUJBQU9xQixTQUFQO0FBQ0QsU0FKZSxDQUFsQjtBQU1BLGVBQU9ELElBQVA7QUFDRCxPQVZLLENBQVIsQ0F6RXVDLENBc0Z2Qzs7QUFDQSxVQUFJRSxnQkFDRm5CLE1BQU1oSixHQUFOLENBQ0dpSyxJQUFELElBQ0Usa0NBQ0QsbUJBREMsR0FFRCxpRUFGQyxHQUdELFdBQVVBLEtBQUtULEtBQUwsQ0FBV2QsS0FBTSxXQUgxQixHQUlELFFBSkMsR0FLRnVCLEtBQUtmLFVBQUwsQ0FBZ0JsSixHQUFoQixDQUNHa0ssU0FBRCxJQUFlO0FBQ2IsWUFBSUQsS0FBS1QsS0FBTCxDQUFXYixPQUFYLEtBQXVCdUIsVUFBVXJCLEtBQXJDLEVBQTRDO0FBQzFDLGlCQUFRLDZCQUE0QnFCLFVBQVV6RixVQUFXLDBFQUF5RXlGLFVBQVVyQixLQUFNLHdCQUFsSjtBQUNELFNBRkQsTUFFTztBQUNMLGlCQUFRLDZCQUE0QnFCLFVBQVV6RixVQUFXLGtFQUFpRXlGLFVBQVVyQixLQUFNLGVBQTFJO0FBQ0Q7QUFDRixPQVBILEVBUUU1SSxJQVJGLENBUU8sRUFSUCxDQUxFLEdBY0YsUUFkRSxHQWVGLFFBakJGLEVBa0JFQSxJQWxCRixDQWtCTyxFQWxCUCxDQURGO0FBcUJBLFVBQUltSyxvQkFBcUI7OztNQUd2QkQsYUFBYztLQUhoQixDQTVHdUMsQ0FrSHZDOztBQUNBLFVBQUk1VixPQUFPO0FBQ1RrUSxvQkFBWU0sU0FESDtBQUVUekgsb0JBQVlpSCxTQUZIO0FBR1R4UCxjQUFPLEdBQUU4VSxXQUFXNUosSUFBWCxDQUFnQixHQUFoQixDQUFxQixJQUFHNkosVUFBVXBOLEtBQUtrTSxRQUFmLENBQXlCLElBQUdsTSxLQUFLM0gsSUFBSyxJQUFHMkgsS0FBSzJOLFFBQVMsRUFIL0U7QUFJVEMsNEJBQW9CRixpQkFKWDtBQUtUNUUsbUJBQVc5SSxLQUFLNk4sV0FBTCxHQUFtQixHQUxyQjtBQU1UQyxzQkFBY1gsV0FBVzVKLElBQVgsQ0FBZ0IsR0FBaEIsQ0FOTDtBQU9Ud0ssaUJBQVMvTixLQUFLZ08sWUFQTDtBQVFUQyxpQkFBU2pPLEtBQUtrTyxXQUFMLEdBQW1CLElBUm5CO0FBUXlCO0FBQ2xDaEssZ0JBQVFsRSxLQUFLa0UsTUFUSjtBQVVUaUsseUJBQWlCZCxhQVZSO0FBV1RsRixjQUFNQSxJQVhHO0FBWVRpRyxzQkFBY2Q7QUFaTCxPQUFYO0FBZUFaLGFBQU9DLE1BQVAsQ0FBYzlVLElBQWQsRUFBb0JtSSxLQUFLTSxJQUFMLENBQVVDLFdBQTlCO0FBRUEsYUFBTzFJLElBQVA7QUFDRCxLQXJJRDtBQUFBLEdBdlBrQyxDQThYbEM7OztBQUNNaU4sa0JBQU4sQ0FBd0J1SixHQUF4QixFQUE2QnJPLElBQTdCO0FBQUEsb0NBQW1DO0FBQ2pDLFVBQUlnRSxRQUFRLEVBQVosQ0FEaUMsQ0FFakM7O0FBQ0FBLGNBQVFxSyxJQUFJck8sS0FBS2tNLFFBQVQsQ0FBUixDQUhpQyxDQUtqQzs7QUFDQSxZQUFNb0MsWUFBWSxJQUFsQjs7QUFDQSxXQUFLLElBQUlqTSxJQUFJLENBQWIsRUFBZ0JBLElBQUlyQyxLQUFLa0UsTUFBTCxDQUFZb0UsTUFBaEMsRUFBd0NqRyxHQUF4QyxFQUE2QztBQUMzQzJCLGNBQU1zSyxhQUFhak0sSUFBSSxDQUFqQixDQUFOLElBQTZCckMsS0FBS2tFLE1BQUwsQ0FBWTdCLENBQVosQ0FBN0I7QUFDRCxPQVRnQyxDQVdqQzs7O0FBQ0EyQixZQUFNLE1BQU4sSUFBZ0JoRSxLQUFLTSxJQUFMLENBQVUwRCxLQUFWLENBQWdCdUssUUFBaEM7QUFDQXZLLFlBQU0sTUFBTixJQUFpQixHQUFELGNBQVMsS0FBS25CLGFBQUwsQ0FBbUI3QyxJQUFuQixDQUFULENBQWtDLElBQUdBLEtBQUtrTSxRQUFTLElBQUdsTSxLQUFLM0gsSUFBSyxFQUFoRjtBQUNBMkwsWUFBTSxNQUFOLElBQWdCaEUsS0FBS2tPLFdBQXJCO0FBQ0FsSyxZQUFNLE1BQU4sSUFBZ0JoRSxLQUFLa08sV0FBckI7QUFDQWxLLFlBQU0sTUFBTixJQUFnQmhFLEtBQUtJLEdBQUwsQ0FBUzhNLFdBQVQsR0FBdUJ4SixLQUF2QixDQUE2QixDQUFDLEVBQTlCLENBQWhCO0FBQ0FNLFlBQU0sSUFBTixJQUFjaEUsS0FBSzZOLFdBQW5CO0FBQ0E3SixZQUFNLGdCQUFOLElBQTBCaEUsS0FBSzJOLFFBQS9CO0FBRUEsYUFBTzNKLEtBQVA7QUFDRCxLQXJCRDtBQUFBOztBQS9Ya0MsQzs7Ozs7Ozs7Ozs7QUNWcEMzTixPQUFPNE8sTUFBUCxDQUFjO0FBQUN6TyxXQUFRLE1BQUlnWTtBQUFiLENBQWQ7O0FBQWUsTUFBTUEsU0FBTixDQUFnQjtBQUM3QixTQUFPL0wsS0FBUCxDQUFjL0YsQ0FBZCxFQUFpQjtBQUNmLFFBQUl6QyxNQUFNLEVBQVY7O0FBRUEsUUFBSXlDLGFBQWEySixLQUFqQixFQUF3QjtBQUN0QnBNLFVBQUl3VSxPQUFKLEdBQWMvUixFQUFFK1IsT0FBaEI7QUFDQXhVLFVBQUk1QixJQUFKLEdBQVdxRSxFQUFFckUsSUFBYjtBQUNBNEIsVUFBSXlVLFFBQUosR0FBZWhTLEVBQUVnUyxRQUFqQjtBQUNBelUsVUFBSTBVLFVBQUosR0FBaUJqUyxFQUFFaVMsVUFBbkI7QUFDQTFVLFVBQUkyVSxZQUFKLEdBQW1CbFMsRUFBRWtTLFlBQXJCO0FBQ0EzVSxVQUFJNFUsS0FBSixHQUFZblMsRUFBRW1TLEtBQWQ7QUFDRCxLQVBELE1BT087QUFDTDVVLFlBQU15QyxDQUFOO0FBQ0Q7O0FBRUQsV0FBT3pDLEdBQVA7QUFDRDs7QUFoQjRCLEM7Ozs7Ozs7Ozs7O0FDQS9CNUQsT0FBTzRPLE1BQVAsQ0FBYztBQUFDMUcsbUJBQWdCLE1BQUlBO0FBQXJCLENBQWQ7QUFBcUQsSUFBSWdMLFdBQUo7QUFBZ0JsVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNnVCxjQUFZOVMsQ0FBWixFQUFjO0FBQUM4UyxrQkFBWTlTLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7O0FBRTlELE1BQU04SCxlQUFOLENBQXNCO0FBQzNCLFNBQWFJLEdBQWIsQ0FBa0JILElBQWxCLEVBQXdCSSxVQUF4QjtBQUFBLG9DQUFvQztBQUNsQyxVQUFJd0wsdUJBQWViLFlBQVljLE9BQVosQ0FBb0I3TCxLQUFLOEwsR0FBekIsQ0FBZixDQUFKO0FBQ0EsVUFBSWhNLEtBQUs4TCxPQUFPOUwsRUFBUCxDQUFVRSxLQUFLK0wsUUFBZixDQUFUO0FBQ0EsYUFBT2pNLEdBQUdNLFVBQUgsQ0FBY0EsVUFBZCxDQUFQO0FBQ0QsS0FKRDtBQUFBOztBQUQyQixDOzs7Ozs7Ozs7OztBQ0Y3QnZJLE9BQU80TyxNQUFQLENBQWM7QUFBQ3pPLFdBQVEsTUFBSXdDO0FBQWIsQ0FBZDtBQUFtQyxJQUFJK00sS0FBSjtBQUFVMVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3NQLFlBQU10UCxDQUFOO0FBQVE7O0FBQXBCLENBQTlCLEVBQW9ELENBQXBEO0FBQXVELElBQUlxWSxNQUFKO0FBQVd6WSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDcVksYUFBT3JZLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7O0FBR2hHLE1BQU11QyxLQUFOLENBQVk7QUFDekIwTSxjQUFhckgsT0FBYixFQUFzQjtBQUNwQjtBQUNBLFNBQUswUSxJQUFMLEdBQVloSixNQUFNaUosVUFBTixDQUFpQjNRLE9BQWpCLENBQVosQ0FGb0IsQ0FJcEI7O0FBQ0EsUUFBSTRRLGVBQWU7QUFBQ0MsMEJBQW9CO0FBQXJCLEtBQW5CO0FBQ0F4QyxXQUFPQyxNQUFQLENBQWNzQyxZQUFkLEVBQTRCNVEsT0FBNUI7QUFDQSxTQUFLOFEsU0FBTCxHQUFpQnBKLE1BQU1pSixVQUFOLENBQWlCQyxZQUFqQixDQUFqQjtBQUNEOztBQUVELFNBQU9HLFVBQVAsQ0FBbUJDLElBQW5CLEVBQXlCO0FBQ3ZCLFdBQU9QLE9BQU9PLElBQVAsRUFBYUMsTUFBYixHQUFzQnBTLFNBQXRCLENBQWdDLENBQWhDLEVBQW1DLEVBQW5DLEVBQXVDcVMsT0FBdkMsQ0FBK0MsR0FBL0MsRUFBb0QsR0FBcEQsQ0FBUDtBQUNEO0FBRUQ7Ozs7OztBQUlBdlYsUUFBT0ssR0FBUCxFQUFZO0FBQ1Y7QUFDQTtBQUNBLFdBQU8sS0FBS21WLE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUl4SSxPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ25CO0FBQ0FzSSxZQUFJMVYsS0FBSixDQUFVSyxHQUFWLEVBQWUsQ0FBQ3FDLENBQUQsRUFBSXpDLEdBQUosS0FBWTtBQUN6QjtBQUNBeVYsY0FBSUMsT0FBSjs7QUFDQSxjQUFJalQsQ0FBSixFQUFPO0FBQ0wwSyxtQkFBTzFLLENBQVA7QUFDRCxXQUZELE1BRU95SyxRQUFRbE4sR0FBUjtBQUNSLFNBTkQ7QUFPRCxPQVZJLENBQVA7QUFZRCxLQWZFLEVBaUJKc04sS0FqQkksQ0FpQkc3SyxDQUFELElBQU87QUFDWixZQUFNQSxDQUFOO0FBQ0QsS0FuQkksQ0FBUDtBQW9CRDs7QUFFS2tULGNBQU4sQ0FBb0J2VixHQUFwQjtBQUFBLG9DQUF5QjtBQUN2QixVQUFJSixvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT0osSUFBSTRWLFFBQVg7QUFDRCxLQUhEO0FBQUE7QUFLQTs7Ozs7Ozs7QUFNTXBULGFBQU4sQ0FBbUIwSixLQUFuQixFQUEwQnRPLE9BQU8sRUFBakMsRUFBcUNpWSxVQUFVLEVBQS9DO0FBQUEsb0NBQW1EO0FBQ2pEO0FBQ0E7QUFFQSxVQUFJelYsTUFBTyxlQUFjOEwsS0FBTSxHQUEvQjtBQUVBLFVBQUk3QyxNQUFNLElBQUl5TSxHQUFKLEVBQVY7O0FBQ0EsV0FBSyxJQUFJcEgsQ0FBVCxJQUFjK0QsT0FBT2hFLElBQVAsQ0FBWTdRLElBQVosQ0FBZCxFQUFpQztBQUMvQixZQUFJQSxLQUFLOFEsQ0FBTCxNQUFZLElBQWhCLEVBQXNCO0FBQ3BCckYsY0FBSThFLEdBQUosQ0FBUU8sQ0FBUixFQUFXLE1BQVg7QUFDRCxTQUZELE1BRU8sSUFBSTlRLEtBQUs4USxDQUFMLEVBQVFqRCxXQUFSLENBQW9Cck4sSUFBcEIsS0FBNkIsTUFBakMsRUFBeUM7QUFDOUM7QUFDQWlMLGNBQUk4RSxHQUFKLENBQVFPLENBQVIsRUFBWSxJQUFHM1AsTUFBTW9XLFVBQU4sQ0FBaUJ2WCxLQUFLOFEsQ0FBTCxDQUFqQixDQUEwQixHQUF6QztBQUNELFNBSE0sTUFHQTtBQUNMckYsY0FBSThFLEdBQUosQ0FBUU8sQ0FBUixFQUFZLEdBQUU1QyxNQUFNaUssTUFBTixDQUFhblksS0FBSzhRLENBQUwsQ0FBYixDQUFzQixFQUFwQztBQUNEO0FBQ0Y7O0FBQ0QsV0FBSyxJQUFJQSxDQUFULElBQWMrRCxPQUFPaEUsSUFBUCxDQUFZb0gsT0FBWixDQUFkLEVBQW9DO0FBQ2xDeE0sWUFBSThFLEdBQUosQ0FBUU8sQ0FBUixFQUFXbUgsUUFBUW5ILENBQVIsTUFBZSxJQUFmLEdBQXNCLE1BQXRCLEdBQStCbUgsUUFBUW5ILENBQVIsQ0FBMUM7QUFDRDs7QUFFRHRPLGFBQVEsS0FBSSxDQUFDLEdBQUdpSixJQUFJb0YsSUFBSixFQUFKLEVBQWdCbkYsSUFBaEIsQ0FBcUIsR0FBckIsQ0FBMEIsS0FBdEM7QUFFQWxKLGFBQVEsV0FBVSxDQUFDLEdBQUdpSixJQUFJMk0sTUFBSixFQUFKLEVBQWtCMU0sSUFBbEIsQ0FBdUIsR0FBdkIsQ0FBNEIsS0FBOUM7QUFFQSxVQUFJdEosb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9KLElBQUk0VixRQUFYO0FBQ0QsS0EzQkQ7QUFBQTtBQTZCQTs7Ozs7Ozs7O0FBT01uSSxhQUFOLENBQW1CdkIsS0FBbkIsRUFBMEIxTSxNQUExQixFQUFrQzVCLElBQWxDLEVBQXdDaVksT0FBeEM7QUFBQSxvQ0FBaUQ7QUFDL0MsVUFBSXpWLE1BQU8sVUFBUzhMLEtBQU0sT0FBMUI7QUFFQSxVQUFJK0osVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSXZILENBQVQsSUFBYytELE9BQU9oRSxJQUFQLENBQVk3USxJQUFaLENBQWQsRUFBaUM7QUFDL0JxWSxnQkFBUXpKLElBQVIsQ0FBYyxHQUFFa0MsQ0FBRSxJQUFHNUMsTUFBTWlLLE1BQU4sQ0FBYW5ZLEtBQUs4USxDQUFMLENBQWIsQ0FBc0IsRUFBM0M7QUFDRDs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBYytELE9BQU9oRSxJQUFQLENBQVlvSCxPQUFaLENBQWQsRUFBb0M7QUFDbENJLGdCQUFRekosSUFBUixDQUFjLEdBQUVrQyxDQUFFLElBQUdtSCxRQUFRbkgsQ0FBUixDQUFXLEVBQWhDO0FBQ0Q7O0FBQ0R0TyxhQUFPNlYsUUFBUTNNLElBQVIsQ0FBYSxHQUFiLENBQVA7QUFFQWxKLGFBQVEsVUFBU1osTUFBTyxHQUF4QjtBQUVBLFVBQUlRLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPSixHQUFQO0FBQ0QsS0FoQkQ7QUFBQSxHQTNGeUIsQ0E2R3pCOzs7QUFDTWtXLFlBQU4sQ0FBa0I5VixHQUFsQjtBQUFBLG9DQUF1QjtBQUNyQixVQUFJK1YsV0FBVyxLQUFLckIsSUFBcEI7QUFDQSxXQUFLQSxJQUFMLEdBQVksS0FBS0ksU0FBakI7O0FBQ0EsVUFBSTtBQUNGLFlBQUlsVixvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsZUFBT0osR0FBUDtBQUNELE9BSEQsU0FHVTtBQUNSLGFBQUs4VSxJQUFMLEdBQVlxQixRQUFaO0FBQ0Q7QUFDRixLQVREO0FBQUE7O0FBV01DLGtCQUFOO0FBQUEsb0NBQTBCO0FBQ3hCLG9CQUFNLEtBQUtyVyxLQUFMLENBQVksb0JBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJTXNXLFFBQU47QUFBQSxvQ0FBZ0I7QUFDZCxvQkFBTSxLQUFLdFcsS0FBTCxDQUFZLFNBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJTXVXLFVBQU47QUFBQSxvQ0FBa0I7QUFDaEIsb0JBQU0sS0FBS3ZXLEtBQUwsQ0FBWSxXQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSUFvTSxpQkFBZ0IvTCxHQUFoQixFQUFxQjRMLFdBQVk3TCxNQUFELElBQVksQ0FBRSxDQUE5QyxFQUFnRDhMLFVBQVd4SixDQUFELElBQU8sQ0FBRSxDQUFuRSxFQUFxRTtBQUNuRSxXQUFPLEtBQUs4UyxNQUFMLEdBQ0pDLElBREksQ0FFRkMsR0FBRCxJQUFTO0FBQ1AsYUFBTyxJQUFJeEksT0FBSixDQUNMLENBQU9DLE9BQVAsRUFBZ0JDLE1BQWhCLDhCQUEyQjtBQUN6QjtBQUNBc0ksWUFBSTFWLEtBQUosQ0FBVUssR0FBVixFQUNHbVcsRUFESCxDQUNNLFFBRE4sRUFFS3BXLE1BQUQsSUFBWTtBQUNWc1YsY0FBSWUsS0FBSjtBQUNBeEssbUJBQVM3TCxNQUFUO0FBQ0FzVixjQUFJZ0IsTUFBSjtBQUNELFNBTkwsRUFPR0YsRUFQSCxDQU9NLE9BUE4sRUFPZ0I5VCxDQUFELElBQU87QUFDbEJ3SixrQkFBUXhKLENBQVI7QUFDRCxTQVRILEVBVUc4VCxFQVZILENBVU0sS0FWTixFQVVhLE1BQU07QUFDZmQsY0FBSUMsT0FBSjtBQUNBeEk7QUFDRCxTQWJIO0FBY0QsT0FoQkQsQ0FESyxDQUFQO0FBbUJELEtBdEJFLEVBd0JKSSxLQXhCSSxDQXdCRzdLLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQTFCSSxDQUFQO0FBMkJEOztBQUVEOFMsV0FBVTtBQUNSLFdBQU8sSUFBSXRJLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQSxXQUFLMkgsSUFBTCxDQUFVNEIsYUFBVixDQUF3QixDQUFDalUsQ0FBRCxFQUFJZ1QsR0FBSixLQUFZO0FBQ2xDLFlBQUloVCxDQUFKLEVBQU87QUFDTDBLLGlCQUFPMUssQ0FBUDtBQUNELFNBRkQsTUFFTztBQUNMeUssa0JBQVF1SSxHQUFSO0FBQ0Q7QUFDRixPQU5EO0FBT0QsS0FWSSxFQVlKbkksS0FaSSxDQWFGN0ssQ0FBRCxJQUFPO0FBQ0wsWUFBTUEsQ0FBTjtBQUNELEtBZkUsQ0FBUDtBQWlCRDs7QUFyTHdCLEM7Ozs7Ozs7Ozs7O0FDSDNCckcsT0FBTzRPLE1BQVAsQ0FBYztBQUFDek8sV0FBUSxNQUFJOEs7QUFBYixDQUFkOztBQUFlLE1BQU1BLE1BQU4sQ0FBYTtBQUMxQm9FLGNBQWExQyxVQUFiLEVBQXlCO0FBQ3ZCLFNBQUtBLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EsU0FBS1EsYUFBTCxHQUFxQixJQUFyQjtBQUNBLFNBQUtNLFFBQUwsR0FBZ0IsSUFBaEI7QUFDQSxTQUFLUyxXQUFMLEdBQW1CLElBQW5CO0FBQ0EsU0FBS21DLEtBQUwsR0FBYSxDQUFiO0FBQ0EsU0FBS2pELFdBQUwsR0FBbUIsQ0FBbkI7QUFDRDs7QUFFS3NCLFFBQU4sQ0FBY2hCLEdBQWQ7QUFBQSxvQ0FBbUI7QUFDakI7QUFDQSxVQUFJLEtBQUsyQyxLQUFMLEdBQWEsS0FBSzFELFVBQWxCLEtBQWlDLENBQXJDLEVBQXdDO0FBQ3RDLFlBQUksS0FBS1EsYUFBVCxFQUF3QjtBQUN0Qix3QkFBTSxLQUFLQSxhQUFMLENBQW1CLEtBQUtDLFdBQXhCLENBQU47QUFDRDtBQUNGOztBQUNELFVBQUksS0FBS0ssUUFBVCxFQUFtQjtBQUNqQixzQkFBTSxLQUFLQSxRQUFMLENBQWNDLEdBQWQsQ0FBTjtBQUNEOztBQUNELFdBQUsyQyxLQUFMLEdBVmlCLENBV2pCOztBQUNBLFVBQUksS0FBS0EsS0FBTCxHQUFhLEtBQUsxRCxVQUFsQixLQUFpQyxDQUFyQyxFQUF3QztBQUN0QyxZQUFJLEtBQUt1QixXQUFULEVBQXNCO0FBQ3BCLHdCQUFNLEtBQUtBLFdBQUwsQ0FBaUIsS0FBS2QsV0FBdEIsQ0FBTjtBQUNEOztBQUNELGFBQUtBLFdBQUw7QUFDRDtBQUNGLEtBbEJEO0FBQUE7O0FBbUJBdUIsVUFBUztBQUNQLFNBQUtULFdBQUwsQ0FBaUIsS0FBS2QsV0FBdEI7QUFDRDs7QUEvQnlCLEM7Ozs7Ozs7Ozs7O0FDQTVCcE4sT0FBTzRPLE1BQVAsQ0FBYztBQUFDek8sV0FBUSxNQUFJeUM7QUFBYixDQUFkO0FBQW9DLElBQUl1VixTQUFKO0FBQWNuWSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDK1gsZ0JBQVUvWCxDQUFWO0FBQVk7O0FBQXhCLENBQWhDLEVBQTBELENBQTFEO0FBQTZELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBRzNHLE1BQU13QyxNQUFOLENBQWE7QUFDMUJ5TSxnQkFBZTtBQUNiLFNBQUt0TCxNQUFMLEdBQWMsRUFBZDtBQUNBLFNBQUsyUCxTQUFMLEdBQWlCLEVBQWpCO0FBQ0EsU0FBSzZHLFFBQUwsR0FBZ0IsSUFBaEI7QUFDRDs7QUFFREMsa0JBQWlCO0FBQ2YsU0FBS0QsUUFBTCxHQUFnQixJQUFJRSxRQUFKLEVBQWhCO0FBQ0EsU0FBSy9HLFNBQUwsQ0FBZXRELElBQWYsQ0FBb0IsS0FBS21LLFFBQXpCO0FBQ0Q7O0FBRUs3VyxPQUFOLENBQWExQixPQUFPLEVBQXBCLEVBQXdCeVIsS0FBSywrQkFBWSxDQUFFLENBQWQsQ0FBN0I7QUFBQSxvQ0FBNkM7QUFDM0MsV0FBSytHLGFBQUw7QUFFQSxVQUFJRSxNQUFNLEVBQVY7O0FBRUEsVUFBSTtBQUNGLFlBQUk5VyxvQkFBWTZQLElBQVosQ0FBSjtBQUVBNEMsZUFBT0MsTUFBUCxDQUFjb0UsR0FBZCxFQUFtQjtBQUNqQmpMLGdCQUFNLFNBRFc7QUFFakIvTCxpQkFBTzFCLElBRlU7QUFHakIyWSxrQkFBUS9XO0FBSFMsU0FBbkI7QUFLRCxPQVJELENBUUUsT0FBT3lDLENBQVAsRUFBVTtBQUNWZ1EsZUFBT0MsTUFBUCxDQUFjb0UsR0FBZCxFQUFtQjtBQUNqQmpMLGdCQUFNLE9BRFc7QUFFakIvTCxpQkFBTzFCLElBRlU7QUFHakIyWSxrQkFBUXhDLFVBQVUvTCxLQUFWLENBQWdCL0YsQ0FBaEI7QUFIUyxTQUFuQjtBQUtELE9BZEQsU0FjVTtBQUNSLFlBQUksS0FBS2tVLFFBQUwsQ0FBY0ssS0FBbEIsRUFBeUI7QUFDdkJ2RSxpQkFBT0MsTUFBUCxDQUFjb0UsR0FBZCxFQUFtQjtBQUNqQkgsc0JBQVUsS0FBS0E7QUFERSxXQUFuQjtBQUdEOztBQUNELGFBQUt4VyxNQUFMLENBQVlxTSxJQUFaLENBQWlCc0ssR0FBakI7QUFDRDtBQUNGLEtBM0JEO0FBQUE7O0FBNkJBOVAsV0FBVWlRLFNBQVYsRUFBcUI7QUFDbkIsU0FBS04sUUFBTCxDQUFjTyxPQUFkLENBQXNCRCxTQUF0QjtBQUNEOztBQUVEdlUsU0FBUXVVLFNBQVIsRUFBbUI7QUFDakIsU0FBS04sUUFBTCxDQUFjcFksS0FBZCxDQUFvQmdXLFVBQVUvTCxLQUFWLENBQWdCeU8sU0FBaEIsQ0FBcEI7QUFDRDs7QUFFREUsaUJBQWdCO0FBQ2QsUUFBSUMsV0FBVyxLQUFLdEgsU0FBTCxDQUFlbEwsSUFBZixDQUFvQm5DLEtBQUtBLEVBQUUwVSxZQUFGLEVBQXpCLENBQWY7QUFDQSxRQUFJRSxXQUFXLEtBQWY7O0FBQ0EsU0FBSyxJQUFJUCxHQUFULElBQWdCLEtBQUszVyxNQUFyQixFQUE2QjtBQUMzQixVQUFJMlcsSUFBSWpMLElBQUosS0FBYSxPQUFqQixFQUEwQjtBQUN4QndMLG1CQUFXLElBQVg7QUFDQTtBQUNEO0FBQ0Y7O0FBQ0QsV0FBT0QsWUFBWUMsUUFBbkI7QUFDRDs7QUFFRGxULFlBQVc7QUFDVCxRQUFJLEtBQUtnVCxZQUFMLEVBQUosRUFBeUI7QUFDdkIsWUFBTSxJQUFJL1osT0FBT2dQLEtBQVgsQ0FBaUIsS0FBS2pNLE1BQXRCLENBQU47QUFDRDs7QUFDRCxXQUFPLEtBQUtBLE1BQVo7QUFDRDs7QUFsRXlCOztBQXFFNUIsTUFBTTBXLFFBQU4sQ0FBZTtBQUNicEwsZ0JBQWU7QUFDYixTQUFLdUwsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLTSxLQUFMLEdBQWE7QUFDWEosZUFBUztBQUNQRixlQUFPLENBREE7QUFFUE8saUJBQVM7QUFGRixPQURFO0FBS1hoWixhQUFPO0FBQ0x5WSxlQUFPLENBREY7QUFFTE8saUJBQVM7QUFGSjtBQUxJLEtBQWI7QUFVRDs7QUFFREwsVUFBU0QsU0FBVCxFQUFvQjtBQUNsQixRQUFJQSxTQUFKLEVBQWU7QUFDYixXQUFLSyxLQUFMLENBQVdKLE9BQVgsQ0FBbUJLLE9BQW5CLENBQTJCL0ssSUFBM0IsQ0FBZ0N5SyxTQUFoQztBQUNEOztBQUNELFNBQUtLLEtBQUwsQ0FBV0osT0FBWCxDQUFtQkYsS0FBbkI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBQ0R6WSxRQUFPMFksU0FBUCxFQUFrQjtBQUNoQjtBQUNBLFFBQUlPLFlBQVksSUFBaEI7QUFDQSxRQUFJbkssUUFBUSxLQUFLaUssS0FBTCxDQUFXL1ksS0FBWCxDQUFpQmdaLE9BQWpCLENBQXlCbEosTUFBckM7O0FBQ0EsUUFBSWhCLEtBQUosRUFBVztBQUNUbUssa0JBQVksS0FBS0YsS0FBTCxDQUFXL1ksS0FBWCxDQUFpQmdaLE9BQWpCLENBQXlCbEssUUFBUSxDQUFqQyxDQUFaO0FBQ0QsS0FOZSxDQVFoQjs7O0FBQ0EsUUFBSTFPLEtBQUtDLFNBQUwsQ0FBZTRZLFNBQWYsTUFBOEI3WSxLQUFLQyxTQUFMLENBQWVxWSxTQUFmLENBQWxDLEVBQTZEO0FBQzNELFVBQUlBLGFBQWFBLGNBQWMsRUFBM0IsSUFBaUNBLGNBQWMsRUFBbkQsRUFBdUQ7QUFDckQsYUFBS0ssS0FBTCxDQUFXL1ksS0FBWCxDQUFpQmdaLE9BQWpCLENBQXlCL0ssSUFBekIsQ0FBOEJ5SyxTQUE5QjtBQUNEO0FBQ0Y7O0FBQ0QsU0FBS0ssS0FBTCxDQUFXL1ksS0FBWCxDQUFpQnlZLEtBQWpCO0FBQ0EsU0FBS0EsS0FBTDtBQUNEOztBQUVERyxpQkFBZ0I7QUFDZCxXQUFPLEtBQUtHLEtBQUwsQ0FBVy9ZLEtBQVgsQ0FBaUJ5WSxLQUF4QjtBQUNEOztBQTFDWSxDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIChyZXEsIHJlcywgbmV4dCkgPT4ge1xyXG4vLyAgIHJlcy53cml0ZUhlYWQoMjAwKTtcclxuLy8gICByZXMuZW5kKGBIZWxsbyB3b3JsZCBmcm9tOiAke01ldGVvci5yZWxlYXNlfWApO1xyXG4vLyB9KTtcclxuXHJcbmltcG9ydCBmcyBmcm9tICdmcyc7XHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJztcclxuXHJcbi8vIFJlcXVpcmVzIG11bHRpcGFydHkgXHJcbmltcG9ydCBtdWx0aXBhcnR5IGZyb20gJ2Nvbm5lY3QtbXVsdGlwYXJ0eSc7XHJcbmltcG9ydCB7XHJcbiAgVXBsb2Fkc1xyXG59IGZyb20gJy4uLy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi91cGxvYWRzJztcclxubGV0IG11bHRpcGFydHlNaWRkbGV3YXJlID0gbXVsdGlwYXJ0eSgpO1xyXG5cclxuY29uc3Qgcm91dGUgPSAnL3VwbG9hZC9pbWFnZSc7XHJcblxyXG4vLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIGZ1Yy51cGxvYWRGaWxlICk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCBtdWx0aXBhcnR5TWlkZGxld2FyZSk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCAocmVxLCByZXNwKSA9PiB7XHJcbiAgLy8gZG9uJ3QgZm9yZ2V0IHRvIGRlbGV0ZSBhbGwgcmVxLmZpbGVzIHdoZW4gZG9uZVxyXG5cclxuICBjb25zdCByZWFkZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLnJlYWRGaWxlKTtcclxuICBjb25zdCB3cml0ZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLndyaXRlRmlsZSk7XHJcbiAgY29uc3QgdXBsb2FkSWQgPSB1bmlxaWQoKTtcclxuXHJcbiAgZm9yIChsZXQgZmlsZSBvZiByZXEuZmlsZXMuZmlsZSkge1xyXG4gICAgY29uc3QgZGF0YSA9IHJlYWRlcihmaWxlLnBhdGgpO1xyXG4gICAgLy8g44OV44Kh44Kk44Or5ZCN44Gu6YeN6KSH44KS6YG/44GR44KL44Gf44KB44CB5LiA5oSP44Gu44OV44Kh44Kk44Or5ZCN44KS5L2c5oiQ44GZ44KLXHJcbiAgICAvLyDmpb3lpKnjga7jg5XjgqHjgqTjg6vlkI3mloflrZfmlbDliLbpmZAyMOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IGZpbGVuYW1lID0gYCR7dW5pcWlkKCl9LmpwZ2BcclxuXHJcbiAgICAvLyBzZXQgdGhlIGNvcnJlY3QgcGF0aCBmb3IgdGhlIGZpbGUgbm90IHRoZSB0ZW1wb3Jhcnkgb25lIGZyb20gdGhlIEFQSTpcclxuICAgIGxldCBzYXZlUGF0aCA9IHJlcS5ib2R5LmltYWdlZGlyICsgJy8nICsgZmlsZW5hbWU7XHJcblxyXG4gICAgLy8gY29weSB0aGUgZGF0YSBmcm9tIHRoZSByZXEuZmlsZXMuZmlsZS5wYXRoIGFuZCBwYXN0ZSBpdCB0byBmaWxlLnBhdGhcclxuXHJcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nntZDmnpzjgpLoqJjpjLLjgZnjgotcclxuICAgIGxldCBkb2MgPSB7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgICAgY2xpZW50RmlsZU5hbWU6IGZpbGUubmFtZSxcclxuICAgICAgdXBsb2FkZWRGaWxlTmFtZTogZmlsZW5hbWVcclxuICAgIH07XHJcbiAgICBcclxuICAgIHRyeXtcclxuICAgICAgd3JpdGVyKHNhdmVQYXRoLCBkYXRhKTtcclxuICAgIH1cclxuICAgIGNhdGNoKGVycil7XHJcbiAgICAgIGRvYy5lcnJvciA9IGVycjtcclxuICAgIH1cclxuICAgIFVwbG9hZHMuaW5zZXJ0KGRvYyk7XHJcblxyXG4gICAgZGVsZXRlIGZpbGU7XHJcblxyXG4gIH07XHJcbiAgcmVzcC53cml0ZUhlYWQoMjAwKTtcclxuICByZXNwLmVuZChKU09OLnN0cmluZ2lmeSh7XHJcbiAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICBzYXZlRGlyOiByZXEuYm9keS5pbWFnZWRpclxyXG4gIH0pKTtcclxuXHJcbn0pOyIsImltcG9ydCBjcnlwdG8gZnJvbSAnY3J5cHRvJ1xyXG5cclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IFJlcG9ydCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIEdyb3VwLFxyXG4gIEdyb3VwRmFjdG9yeVxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9ncm91cHMnXHJcbmltcG9ydCB7XHJcbiAgRmlsdGVyXHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2ZpbHRlcnMnXHJcblxyXG5sZXQgdGFnID0gJ2N1YmVtaWcnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm1pZ3JhdGVgXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgLy8gc2V0dXAgZ3JvdXBcclxuICAgIC8vXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBGaWx0ZXIoY29uZmlnLnNyY0ZpbHRlcklkKVxyXG4gICAgLy8gbGV0IHBsdWcgPSBncm91cC5nZXRQbHVnKCk7XHJcblxyXG4gICAgLy8gY2hlY2tpbmcgY29ubmVjdGlvblxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgdGVzdFF1ZXJ5ID0gJ1NIT1cgREFUQUJBU0VTJ1xyXG5cclxuICAgIGxldCBkc3REYiA9IG5ldyBNeVNRTChjb25maWcuZHN0LmNyZWQpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKCdDb25uZWN0IHRvIERlc3RpbmF0aW9uJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5KHRlc3RRdWVyeSlcclxuICAgICAgfSlcclxuXHJcbiAgICAvLyBwcm9jZXNzIGZvciBlYWNoIG1lbWJlcnNcclxuICAgIC8vXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKCdTZWxlY3QgbG9vcCBpbiBzb3VyY2UnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgIG1vYmlsZU51bGw6IGFzeW5jIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgLy8gLy8g5YCk44KS5pW055CGXHJcbiAgICAgICAgICAgIC8vIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgIC8vICAgaWYgKHJlY29yZFtrZXldID09PSBudWxsKTtcclxuICAgICAgICAgICAgLy8gICBlbHNlIGlmIChyZWNvcmRba2V5XS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnRGF0ZScpIHtcclxuICAgICAgICAgICAgLy8gICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgICAgICAvLyAgICAgcmVjb3JkW2tleV0gPSBNeVNRTC5mb3JtYXREYXRlKHJlY29yZFtrZXldKTtcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gYFwiJHtyZWNvcmRba2V5XX1cImA7XHJcbiAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXIg44Gr5L+d5a2YXHJcblxyXG4gICAgICAgICAgICBsZXQgc3FsID0gYFxyXG5cclxuICAgICAgICAgICAgICAgIElOU0VSVCBkdGJfY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICggXFxgY3VzdG9tZXJfaWRcXGAsIFxcYHN0YXR1c1xcYCwgXFxgc2V4XFxgLCBcXGBqb2JcXGAsIFxcYGNvdW50cnlfaWRcXGAsIFxcYHByZWZcXGAsIFxcYG5hbWUwMVxcYCwgXFxgbmFtZTAyXFxgLCBcXGBrYW5hMDFcXGAsIFxcYGthbmEwMlxcYCwgXFxgY29tcGFueV9uYW1lXFxgLCBcXGB6aXAwMVxcYCwgXFxgemlwMDJcXGAsIFxcYHppcGNvZGVcXGAsIFxcYGFkZHIwMVxcYCwgXFxgYWRkcjAyXFxgLCBcXGBlbWFpbFxcYCwgXFxgdGVsMDFcXGAsIFxcYHRlbDAyXFxgLCBcXGB0ZWwwM1xcYCwgXFxgZmF4MDFcXGAsIFxcYGZheDAyXFxgLCBcXGBmYXgwM1xcYCwgXFxgYmlydGhcXGAsIFxcYHBhc3N3b3JkXFxgLCBcXGBzYWx0XFxgLCBcXGBzZWNyZXRfa2V5XFxgLCBcXGBmaXJzdF9idXlfZGF0ZVxcYCwgXFxgbGFzdF9idXlfZGF0ZVxcYCwgXFxgYnV5X3RpbWVzXFxgLCBcXGBidXlfdG90YWxcXGAsIFxcYG5vdGVcXGAsIFxcYGNyZWF0ZV9kYXRlXFxgLCBcXGB1cGRhdGVfZGF0ZVxcYCwgXFxgZGVsX2ZsZ1xcYCApXHJcblxyXG4gICAgICAgICAgICAgICAgVkFMVUVTKCAke3JlY29yZC5jdXN0b21lcl9pZH0gLCAke3JlY29yZC5zdGF0dXN9ICwgJHtyZWNvcmQuc2V4fSAsICR7cmVjb3JkLmpvYn0gLCAke3JlY29yZC5jb3VudHJ5X2lkfSAsICR7cmVjb3JkLnByZWZ9ICwgJHtyZWNvcmQubmFtZTAxfSAsICR7cmVjb3JkLm5hbWUwMn0gLCAke3JlY29yZC5rYW5hMDF9ICwgJHtyZWNvcmQua2FuYTAyfSAsICR7cmVjb3JkLmNvbXBhbnlfbmFtZX0gLCAke3JlY29yZC56aXAwMX0gLCAke3JlY29yZC56aXAwMn0gLCAke3JlY29yZC56aXBjb2RlfSAsICR7cmVjb3JkLmFkZHIwMX0gLCAke3JlY29yZC5hZGRyMDJ9ICwgJHtyZWNvcmQuZW1haWx9ICwgJHtyZWNvcmQudGVsMDF9ICwgJHtyZWNvcmQudGVsMDJ9ICwgJHtyZWNvcmQudGVsMDN9ICwgJHtyZWNvcmQuZmF4MDF9ICwgJHtyZWNvcmQuZmF4MDJ9ICwgJHtyZWNvcmQuZmF4MDN9ICwgJHtyZWNvcmQuYmlydGh9ICwgJHtyZWNvcmQucGFzc3dvcmR9ICwgJHtyZWNvcmQuc2FsdH0gLCAke3JlY29yZC5zZWNyZXRfa2V5fSAsICR7cmVjb3JkLmZpcnN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmxhc3RfYnV5X2RhdGV9ICwgJHtyZWNvcmQuYnV5X3RpbWVzfSAsICR7cmVjb3JkLmJ1eV90b3RhbH0gLCAke3JlY29yZC5ub3RlfSAsICR7cmVjb3JkLmNyZWF0ZV9kYXRlfSAsICR7cmVjb3JkLnVwZGF0ZV9kYXRlfSAsICR7cmVjb3JkLmRlbF9mbGd9IClcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgYFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdkdGJfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVjb3JkLnN0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgc2V4OiByZWNvcmQuc2V4LFxyXG4gICAgICAgICAgICAgICAgICBqb2I6IHJlY29yZC5qb2IsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgZW1haWw6IHJlY29yZC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgYmlydGg6IHJlY29yZC5iaXJ0aCxcclxuICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHJlY29yZC5wYXNzd29yZCxcclxuICAgICAgICAgICAgICAgICAgc2FsdDogcmVjb3JkLnNhbHQsXHJcbiAgICAgICAgICAgICAgICAgIHNlY3JldF9rZXk6IHJlY29yZC5zZWNyZXRfa2V5LFxyXG4gICAgICAgICAgICAgICAgICBmaXJzdF9idXlfZGF0ZTogcmVjb3JkLmZpcnN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBsYXN0X2J1eV9kYXRlOiByZWNvcmQubGFzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RpbWVzOiByZWNvcmQuYnV5X3RpbWVzLFxyXG4gICAgICAgICAgICAgICAgICBidXlfdG90YWw6IHJlY29yZC5idXlfdG90YWwsXHJcbiAgICAgICAgICAgICAgICAgIG5vdGU6IHJlY29yZC5ub3RlLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyX2FkZHJlc3NcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdkdGJfY3VzdG9tZXJfYWRkcmVzcycsIHtcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfYWRkcmVzc19pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8g44Oh44Or44Oe44Ks44OX44Op44Kw44Kk44OzIHBsZ19tYWlsbWFnYV9jdXN0b21lclxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ3BsZ19tYWlsbWFnYV9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIG1haWxtYWdhX2ZsZzogcmVjb3JkLm1haWxtYWdhX2ZsZyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOOCr+ODvOODneODs+eZuuihjO+8iEVDQ1VCRTLjga7jg53jgqTjg7Pjg4jpgoTlhYPvvIlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25DZCA9IGNyeXB0by5yYW5kb21CeXRlcyg4KS50b1N0cmluZygnYmFzZTY0Jykuc3Vic3RyaW5nKDAsIDExKVxyXG5cclxuICAgICAgICAgICAgbGV0IGNvdXBvbk5hbWUgPSBgJHtyZWNvcmQubmFtZTAxfSAke3JlY29yZC5uYW1lMDJ9IOanmCDjgZTlhKrlvoXjgq/jg7zjg53jg7Mg5Lya5ZOh55Wq5Y+3OiR7cmVjb3JkLmN1c3RvbWVyX2lkfWBcclxuXHJcbiAgICAgICAgICAgIGxldCBkaXNjb3VudFByaWNlID0gcmVjb3JkLnBvaW50ICsgNTAwXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfY291cG9uJywge1xyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25faWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9jZDogY291cG9uQ2QsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl90eXBlOiAzLCAvLyDlhajllYblk4FcclxuICAgICAgICAgICAgICAgICAgY291cG9uX25hbWU6IGNvdXBvbk5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3R5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl91c2VfdGltZTogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3JlbGVhc2U6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3ByaWNlOiBkaXNjb3VudFByaWNlLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9yYXRlOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBlbmFibGVfZmxhZzogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX21lbWJlcjogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2xvd2VyX2xpbWl0OiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfZnJvbV9kYXRlOiAnMjAxOC0wNC0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV90b19kYXRlOiAnMjAxOS0wNS0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IDBcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIGFzeW5jICdjdWJlbWlnLnNlcnZlckNoZWNrJyAocHJvZmlsZSkge1xyXG4gICAgbGV0IGRiID0gbmV3IE15U1FMKHByb2ZpbGUpXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgZGIucXVlcnkoJ1NIT1cgREFUQUJBU0VTJylcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgeyBNb25nb0NvbGxlY3Rpb24gfSBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbW9uZ28nXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdqbGluZS5jb2xsZWN0aW9uJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5maW5kYF0gKHBsdWcsIHF1ZXJ5ID0ge30sIHByb2plY3Rpb24gPSB7fSkge1xyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbilcclxuICAgIGxldCByZXMgPSBhd2FpdCBjb2xsLmZpbmQocXVlcnksIHtwcm9qZWN0aW9uOiBwcm9qZWN0aW9ufSkudG9BcnJheSgpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uYWdncmVnYXRlYF0gKHBsdWcsIHF1ZXJ5ID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5hZ2dyZWdhdGUocXVlcnkpLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi8uLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdqbGluZS5pdGVtcydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgb7jgZnjgIJcclxuICAgKiBAcGFyYW1cclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5zZXRJbWFnZWBdIChwbHVnLCB1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgbGV0IHVwbG9hZGVkID0gYXdhaXQgaXRlbWNvbi5zZXRJbWFnZSh1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSwgY2xhc3MyKVxyXG4gICAgcmV0dXJuIHVwbG9hZGVkXHJcbiAgfSxcclxuXHJcbiAgLyoqXHJcbiAgICog44Ki44Kk44OG44Og5oOF5aCx44OH44O844K/44OZ44O844K544Gu55S75YOP55m76Yyy44KS5YmK6Zmk44GZ44KL77yI55S75YOP6Ieq5L2T44Gv5YmK6Zmk44GX44Gq44GE77yJXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uY2xlYW5JbWFnZWBdIChwbHVnLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpXHJcbiAgICBhd2FpdCBpdGVtY29uLmNsZWFuSW1hZ2UobW9kZWwsIGNsYXNzMSwgY2xhc3MyKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQge1xyXG4gIEN1YmUzQXBpXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2N1YmUnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5Zyo5bqr5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZVN0b2NrYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgIGxldCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgIGxldCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQilcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn5Zyo5bqr44Gu5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5KVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx55m76Yyy44Go5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliSXRlbWBdIChjb25maWcpIHtcclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpXHJcbiAgICBsZXQgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKVxyXG5cclxuICAgIGxldCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0VDQ1VCRTPjgbjjga7llYblk4HnmbvpjLInLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICdJTlNFUlQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgY29sID0gY29udGV4dC5jb2xsZWN0aW9uXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCBjdWJlSXRlbSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnLmNyZWF0b3JfaWQsIGl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIGxldCBpbnNlcnRSZXMgPSBhd2FpdCBhcGkucHJvZHVjdENyZWF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgLy8gaXRlbSDjg4fjg7zjgr/jg5njg7zjgrnjgbjjga7nmbvpjLJcclxuICAgICAgICAgICAgICBhd2FpdCBjb2wudXBkYXRlKHtcclxuICAgICAgICAgICAgICAgIF9pZDogaXRlbS5faWRcclxuICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICAgICAgICAgICdtYWxsLnNoYXJha3VTaG9wJzogaW5zZXJ0UmVzLnJlc1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0pXHJcblxyXG4gICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0VDQ1VCRTPllYblk4Hmg4XloLHjga7mm7TmlrAnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICdVUERBVEUnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgY29sID0gY29udGV4dC5jb2xsZWN0aW9uXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCBjdWJlSXRlbSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnLmNyZWF0b3JfaWQsIGl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0SW1hZ2VVcGRhdGUoY3ViZUl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RVcGRhdGUoY3ViZUl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RUYWdVcGRhdGUoY3ViZUl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS51cGRhdGVTdG9jayhpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCwgcXVhbnRpdHkpXHJcblxyXG4gICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICd0b29sJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS50ZXN0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuXHJcbiAgICBjb25zdCBuZXdMb2NhbCA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHt9LCBhc3luYyAoZSkgPT4ge1xyXG4gICAgICB0aHJvdyBlXHJcbiAgICB9KVxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44OV44Kj44Or44K/44O844OG44K544OIJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBuZXdMb2NhbFxyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IFBhY2tldCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcGFja2V0J1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgYXJjaGl2ZXIgZnJvbSAnYXJjaGl2ZXInXHJcbmltcG9ydCBjc3YgZnJvbSAnY3N2J1xyXG5pbXBvcnQgeyBQYXNzVGhyb3VnaCwgVHJhbnNmb3JtIH0gZnJvbSAnc3RyZWFtJ1xyXG5cclxuY29uc3QgcHJlZml4ID0gJ3BhY2tldCdcclxuY29uc3QgdGFnID0gJ3lhdWN0J1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOODpOODleOCquOCr+WPl+azqOODleOCoeOCpOODq1xyXG5cclxuICBhc3luYyBbYHlhdWN0T3JkZXIub3JkZXJgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lj5fms6gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9vcmRlcmBcclxuICAgICAgICBjb25zdCByID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLmxvYWRmaWxlfWApXHJcbiAgICAgICAgY29uc3QgdyA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcuc2F2ZWZpbGV9YClcclxuICAgICAgICBsZXQgaSA9IDBcclxuICAgICAgICByLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAucGlwZShjc3YucGFyc2Uoe2NvbHVtbnM6IHRydWV9KSlcclxuICAgICAgICAgIC5waXBlKGNzdi50cmFuc2Zvcm0oXHJcbiAgICAgICAgICAgIGFzeW5jIChyZWNvcmQsIGNhbGxiYWNrKSA9PiB7XHJcbiAgICAgICAgICAgICAgbGV0IGVyciA9IG51bGxcclxuICAgICAgICAgICAgICAvLyDnrqHnkIbnlarlj7fjgpLnva7jgY3mj5vjgYjjgotcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgcmVjb3JkWyfnrqHnkIbnlarlj7cnXSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldE1vZGVsQ2xhc3MocmVjb3JkWyfnrqHnkIbnlarlj7cnXSlcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBlcnIgPSBlXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNhbGxiYWNrKGVyciwgcmVjb3JkKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC5waXBlKHcpXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOODpOODleOCquOCr+WHuuWTgeODleOCoeOCpOODq1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYml0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44Ok44OV44Kq44Kv5Ye65ZOBJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g57mw44KK6L+U44GX5Yem55CG44KS5Lu75oSP44Gu77yIcGFja2V0U2l6Ze+8ieOBp+WIhuWJslxyXG4gICAgICAgIGNvbnN0IHBhY2tldCA9IG5ldyBQYWNrZXQoY29uZmlnLnBhY2tldFNpemUpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIENTVuODleOCoeOCpOODq+OCkuS9nOaIkOOBl+eUu+WDj+ODh+ODvOOCv+OCkuWPjumbhuOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vd29ya2BcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh3b3JrZGlyKVxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuXHJcbiAgICAgICAgLy8gWklQ44OV44Kh44Kk44Or44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3QgdXBsb2FkZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L3VwbG9hZGBcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh1cGxvYWRkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih1cGxvYWRkaXIpXHJcblxyXG4gICAgICAgIGxldCBjZCA9IG51bGwgLy8g44OR44Kx44OD44OI44OV44Kp44Or44OAXHJcbiAgICAgICAgbGV0IGZpbGVuYW1lID0gbnVsbCAvLyBjc3bjg5XjgqHjgqTjg6tcclxuICAgICAgICBsZXQgbmFtZSA9IG51bGwgLy8g44OR44Kx44OD44OI55Wq5Y+3XHJcblxyXG4gICAgICAgIC8vIENTVuODleOCo+ODvOODq+ODieOCkuWumue+qeOBl+OAgemghueVquOCkueiuuWumuOBmeOCi1xyXG4gICAgICAgIGxldCBmaWVsZHMgPSBbJ+euoeeQhueVquWPtycsICfjgqvjg4bjgrTjg6onLCAn44K/44Kk44OI44OrJywgJ+iqrOaYjicsICfjgrnjg4jjgqLlhoXllYblk4HmpJzntKLnlKjjgq3jg7zjg6/jg7zjg4knLCAn6ZaL5aeL5L6h5qC8JywgJ+WNs+axuuS+oeagvCcsICflgKTkuIvjgZLkuqTmuIknLCAn5YCL5pWwJywgJ+WFpeacreWAi+aVsOWItumZkCcsICfmnJ/plpMnLCAn57WC5LqG5pmC6ZaTJywgJ+WVhuWTgeeZuumAgeWFg+OBrumDvemBk+W6nOecjCcsICfllYblk4HnmbrpgIHlhYPjga7luILljLrnlLrmnZEnLCAn6YCB5paZ6LKg5ouFJywgJ+S7o+mHkeWFiOaJleOBhOOAgeW+jOaJleOBhCcsICfokL3mnK3jg4rjg5PmsbrmuIjmlrnms5XoqK3lrponLCAn5ZWG5ZOB44Gu54q25oWLJywgJ+WVhuWTgeOBrueKtuaFi+WCmeiAgycsICfov5Tlk4Hjga7lj6/lkKYnLCAn6L+U5ZOB44Gu5Y+v5ZCm5YKZ6ICDJywgJ+eUu+WDjzEnLCAn55S75YOPMeOCs+ODoeODs+ODiCcsICfnlLvlg48yJywgJ+eUu+WDjzLjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMycsICfnlLvlg48z44Kz44Oh44Oz44OIJywgJ+eUu+WDjzQnLCAn55S75YOPNOOCs+ODoeODs+ODiCcsICfnlLvlg481JywgJ+eUu+WDjzXjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNicsICfnlLvlg48244Kz44Oh44Oz44OIJywgJ+eUu+WDjzcnLCAn55S75YOPN+OCs+ODoeODs+ODiCcsICfnlLvlg484JywgJ+eUu+WDjzjjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOScsICfnlLvlg48544Kz44Oh44Oz44OIJywgJ+eUu+WDjzEwJywgJ+eUu+WDjzEw44Kz44Oh44Oz44OIJywgJ+acgOS9juipleS+oScsICfmgqroqZXlibLlkIjliLbpmZAnLCAn5YWl5pyt6ICF6KqN6Ki85Yi26ZmQJywgJ+iHquWLleW7tumVtycsICfml6nmnJ/ntYLkuoYnLCAn5ZWG5ZOB44Gu6Ieq5YuV5YaN5Ye65ZOBJywgJ+iHquWLleWApOS4i+OBkicsICfmnIDkvY7okL3mnK3kvqHmoLwnLCAn44OB44Oj44Oq44OG44Kj44O8JywgJ+azqOebruOBruOCquODvOOCr+OCt+ODp+ODsycsICflpKrlrZfjg4bjgq3jgrnjg4gnLCAn6IOM5pmv6ImyJywgJ+OCueODiOOCouODm+ODg+ODiOOCquODvOOCr+OCt+ODp+ODsycsICfnm67nq4vjgaHjgqLjgqTjgrPjg7MnLCAn6LSI562U5ZOB44Ki44Kk44Kz44OzJywgJ1Tjg53jgqTjg7Pjg4jjgqrjg5fjgrfjg6fjg7MnLCAn44Ki44OV44Kj44Oq44Ko44Kk44OI44Kq44OX44K344On44OzJywgJ+iNt+eJqeOBruWkp+OBjeOBlScsICfojbfnianjga7ph43ph48nLCAn44Gv44GTQk9PTicsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxJywgJ+OBneOBruS7lumFjemAgeaWueazlTHmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UyJywgJ+OBneOBruS7lumFjemAgeaWueazlTLmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UzJywgJ+OBneOBruS7lumFjemAgeaWueazlTPmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U0JywgJ+OBneOBruS7lumFjemAgeaWueazlTTmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U1JywgJ+OBneOBruS7lumFjemAgeaWueazlTXmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U2JywgJ+OBneOBruS7lumFjemAgeaWueazlTbmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U3JywgJ+OBneOBruS7lumFjemAgeaWueazlTfmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U4JywgJ+OBneOBruS7lumFjemAgeaWueazlTjmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U5JywgJ+OBneOBruS7lumFjemAgeaWueazlTnmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOWFqOWbveS4gOW+i+S+oeagvCcsICfmtbflpJbnmbrpgIEnLCAn6YWN6YCB5pa55rOV44O76YCB5paZ6Kit5a6aJywgJ+S7o+W8leaJi+aVsOaWmeioreWumicsICfmtojosrvnqI7oqK3lrponLCAnSkFO44Kz44O844OJ44O7SVNCTuOCs+ODvOODiSddXHJcbiAgICAgICAgbGV0IGhlYWRlciA9IGZpZWxkcy5tYXAodiA9PiBgXCIke3Z9XCJgKS5qb2luKCcsJykgKyAnXFxuJ1xyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbplovlp4vmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXRTdGFydCA9IGFzeW5jIChwYWNrZXRDb3VudCkgPT4ge1xyXG4gICAgICAgICAgbmFtZSA9IHByZWZpeCArICgnMDAwMDAnICsgcGFja2V0Q291bnQpLnNsaWNlKC01KVxyXG4gICAgICAgICAgY2QgPSBgJHt3b3JrZGlyfS8ke25hbWV9YFxyXG4gICAgICAgICAgZmlsZW5hbWUgPSBgJHtjZH0vJHtjb25maWcuY3N2RmlsZU5hbWV9YFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2RpcihjZClcclxuICAgICAgICAgIC8vIENTVuODleOCoeOCpOODq+OBq+ODleOCo+ODvOODq+ODieOCkuioreWumuOBmeOCi1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUoaGVhZGVyLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXQgPSBhc3luYyAoYXJnKSA9PiB7XHJcbiAgICAgICAgICBsZXQgeWF1Y3QgPSBhcmcueWF1Y3RcclxuICAgICAgICAgIGxldCBpdGVtID0gYXJnLml0ZW1cclxuICAgICAgICAgIC8vIGNzduODleOCoeOCpOODq+OBq+ODrOOCs+ODvOODie+8iOWVhuWTgeODhuODs+ODl+ODrOODvOODiO+8ieOCkui/veWKoOOBmeOCi1xyXG4gICAgICAgICAgbGV0IHJlY29yZCA9IGZpZWxkcy5tYXAodiA9PiB7IHJldHVybiB5YXVjdFt2XSA/IGBcIiR7eWF1Y3Rbdl19XCJgIDogJ1wiXCInIH0pLmpvaW4oJywnKSArICdcXG4nXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShyZWNvcmQsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICAgIC8vIOeUu+WDj+ODleOCoeOCpOODq+OCkuOCs+ODlOODvFxyXG4gICAgICAgICAgZm9yIChsZXQgaW1nIG9mIGl0ZW0uaW1hZ2VzKSB7XHJcbiAgICAgICAgICAgIGxldCBpbWdTcmMgPSBgJHtjb25maWcuaW1hZ2VkaXJ9LyR7aW1nfWBcclxuICAgICAgICAgICAgbGV0IGltZ1RndCA9IGAke2NkfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgLy8g5ZCM44GY44OV44Kh44Kk44Or44GM44GC44KL5aC05ZCI44Gv44Kz44OU44O844GX44Gq44GEXHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5hY2Nlc3MoaW1nVGd0KVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5jb3B5RmlsZShpbWdTcmMsIGltZ1RndClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI57WC5LqG5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0RW5kID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB6aXAgPSBhcmNoaXZlcignemlwJylcclxuICAgICAgICAgIGNvbnN0IHppcG5hbWUgPSBgJHt1cGxvYWRkaXJ9LyR7bmFtZX0uemlwYFxyXG4gICAgICAgICAgY29uc3Qgb3V0cHV0ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbSh6aXBuYW1lKVxyXG4gICAgICAgICAgemlwLnBpcGUob3V0cHV0KVxyXG4gICAgICAgICAgemlwLmRpcmVjdG9yeShjZCwgZmFsc2UpXHJcbiAgICAgICAgICB6aXAuZmluYWxpemUoKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgIC8vIGl0ZW3jgavlrprnvqnjgZXjgozjgabjgYTjgovmnIDkvY7lv4XopoHlnKjluqvjgojjgorlpJrjgYTllYblk4HjgpLlh7rlk4HjgZnjgotcclxuICAgICAgICAgICAgaWYgKHF1YW50aXR5ID49IGl0ZW0ubWFsbC55YXVjdC5taW5RdWFudGl0eSkge1xyXG4gICAgICAgICAgICAgIGxldCB5YXVjdCA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtWWF1Y3QoY29uZmlnLmRlZmF1bHQsIGl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgcGFja2V0LnN1Ym1pdCh7eWF1Y3Q6IHlhdWN0LCBpdGVtOiBpdGVtfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHBhY2tldC5jbG9zZSgpXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCAnLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MnXHJcblxyXG5pbXBvcnQgJy4vcm91dGUvdXBsb2FkL2ltYWdlJ1xyXG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbiBcclxuZXhwb3J0IGNvbnN0IENvbmZpZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29uZmlncycse2lkR2VuZXJhdGlvbjonTU9OR08nfSk7XHJcblxyXG4vLyBNZXRlb3IubWV0aG9kcyh7IFxyXG4vLyAgIGFzeW5jICdteXNxbFNlcnZlcnMuaW5zZXJ0JyAoIG5ld1NlcnZlciApe1xyXG4vLyAgICAgcmV0dXJuIGF3YWl0IE15c3FsU2VydmVycy5pbnNlcnQobmV3U2VydmVyKTtcclxuLy8gICB9XHJcbi8vIH0pO1xyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCc7XHJcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0JztcclxuaW1wb3J0IHsgR3JvdXBCYXNlIH0gZnJvbSAnLi9ncm91cHMnO1xyXG5cclxuY29uc3QgRmlsdGVycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdmaWx0ZXJzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBGaWx0ZXIgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcihmaWx0ZXJJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gRmlsdGVycy5maW5kT25lKHtcclxuICAgICAgX2lkOiBmaWx0ZXJJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG5cclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jICggb25SZXN1bHQgPSAocmVjb3JkKT0+e30sIG9uRXJyb3IgPSAoZSk9Pnt9ICkgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgb25FcnJvcik7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsYXRmb3JtIHR5cGUnKTtcclxuXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge3sgZmlsdGVyVHlwZTogYXN5bmMgKHJlY29yZCApID0+IHt9IH19IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaChjYWxsYmFja3MgPSB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlKCk7XHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgdHlwZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ID0ge307XHJcbiAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgIGNvdW50W2ZpbHRlci50eXBlXSA9IHtcclxuICAgICAgICBxdWVyeTogZmlsdGVyLnF1ZXJ5LFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQpPT57XHJcbiAgICAgICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICAgICAgbGV0IHF1ZXJ5ID0gbW9iamVjdC51bmVzY2FwZShmaWx0ZXIucXVlcnkpO1xyXG4gICAgICAgICAgbGV0IGV4YW0gPSBzaWZ0KCBxdWVyeSApO1xyXG4gICAgICAgICAgaWYoIGV4YW0ocmVjb3JkKSApe1xyXG4gICAgICAgICAgICBjb3VudFtmaWx0ZXIudHlwZV0uY291bnQrKztcclxuICAgICAgICAgICAgaWYoIHR5cGVvZiBjYWxsYmFja3NbZmlsdGVyLnR5cGVdICE9PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2tzW2ZpbHRlci50eXBlXShyZWNvcmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgb25FcnJvclxyXG4gICAgKTtcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50O1xyXG5cclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG5jb25zdCBHcm91cHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZ3JvdXBzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cEJhc2Uge1xyXG5cclxuICBwcm9maWxlO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9maWxlKSB7XHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogZ2V0cyAnUGx1Zycgd2l0Y2ggaXMgYSBzZXQgb2YgcHJvcGVydGllcyBuZWVkZWRcclxuICAgKiB3aGVuIGNvbm5lY3QgdG8gc29tZSBwbGF0Zm9ybXNcclxuICAgKiB0byBnZXQgZGF0YXMoTWVtYmVycyBvZiB0aGUgR3JvdXApXHJcbiAgICovXHJcbiAgZ2V0UGx1ZygpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGUucGxhdGZvcm1QbHVnO1xyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZSgpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHt9O1xyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZ3JvdXBJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gR3JvdXBzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGdyb3VwSWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jIChkb2MpID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9IFdIRVJFIFxcYCR7ZG9jLmtleX1cXGAgPSBcIiR7ZG9jLmlkfVwiYDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgZ3JvdXAgdHlwZScpO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge2FzeW5jIChyZWNvcmQpPT52b2lkfSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBjdXIgPSBHcm91cHMuZmluZCh7XHJcbiAgICAgIGdyb3VwSWQ6IHRoaXMucHJvZmlsZS5faWRcclxuICAgIH0sIHtcclxuICAgICAgZmllbGRzOiB7XHJcbiAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgIGlkOiAxLFxyXG4gICAgICAgIGtleTogMVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBcclxuICAgICAgICBjdXIuZm9yRWFjaChcclxuICAgICAgICAgIGFzeW5jIChkb2MsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlY29yZCA9IGF3YWl0IHRoaXMuaW1wb3J0KGRvYyk7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2socmVjb3JkKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIG9uRXJyb3IoZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGluZGV4ICsgMSA9PT0gY3VyLmNvdW50KCkpIHtcclxuICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgfVxyXG4gICAgKS5jYXRjaChcclxuICAgICAgKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICB9XHJcblxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG4gXHJcbmV4cG9ydCBjb25zdCBVcGxvYWRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VwbG9hZHMnLHtpZEdlbmVyYXRpb246J01PTkdPJ30pO1xyXG5cclxuIiwiaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuXHJcbmV4cG9ydCBjbGFzcyBDdWJlM0FwaSB7XHJcbiAgY29uc3RydWN0b3IgKG15c3FsID0gbmV3IE15U1FMKCkpIHtcclxuICAgIHRoaXMubXlzcWxfID0gbXlzcWxcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZVN0b2NrIChwcm9kdWN0Q2xhc3NJZCwgcXVhbnRpdHkgPSAwKSB7XHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXHJcbiAgICAgIHt9LCB7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsXHJcbiAgICAgIGBwcm9kdWN0X2NsYXNzX2lkID0gJHtwcm9kdWN0Q2xhc3NJZH1gLFxyXG4gICAgICB7fSwge1xyXG4gICAgICAgIHN0b2NrOiBxdWFudGl0eSxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VGFnVXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IFtdXHJcblxyXG4gICAgLy8g5YmK6Zmk44GZ44KL44K/44KwXHJcbiAgICBsZXQgdGFnb2ZmID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICBsZXQgc3FsID0gYFxyXG4gICAgICBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF90YWcgXHJcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxyXG4gICAgICBgXHJcbiAgICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbCkpXHJcbiAgICB9XHJcblxyXG4gICAgLy8g6KGo56S644GZ44KL44K/44KwXHJcbiAgICBsZXQgdGFnb24gPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIC8vIOOBmeOBp+OBq+ihqOekuuOBleOCjOOBpuOBhOOCi+OCv+OCsOOBjOOBguOCjOOBsOS9leOCguOBl+OBquOBhFxyXG4gICAgICBsZXQgc3FsID0gYFxyXG4gICAgICBTRUxFQ1QgQ09VTlQoKikgRlJPTSBkdGJfcHJvZHVjdF90YWcgXHJcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxyXG4gICAgICBgXHJcbiAgICAgIGxldCBjb3VudFJlcyA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbClcclxuICAgICAgaWYgKGNvdW50UmVzWzBdWydDT1VOVCgqKSddKSByZXR1cm5cclxuXHJcbiAgICAgIHJlcy5wdXNoKFxyXG4gICAgICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgJ2R0Yl9wcm9kdWN0X3RhZycsXHJcbiAgICAgICAgICB7fSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgcHJvZHVjdF9pZDogZGF0YS5wcm9kdWN0X2lkLFxyXG4gICAgICAgICAgICB0YWc6IHRhZyxcclxuICAgICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICkpXHJcbiAgICB9XHJcblxyXG4gICAgZm9yIChsZXQgdGFnU2V0IG9mIGRhdGEudGFncykge1xyXG4gICAgICBzd2l0Y2ggKHRhZ1NldC5zZXQpIHtcclxuICAgICAgICBjYXNlICdvbic6XHJcbiAgICAgICAgICBhd2FpdCB0YWdvbih0YWdTZXQudGFnKVxyXG4gICAgICAgICAgYnJlYWtcclxuICAgICAgICBjYXNlICdvZmYnOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb2ZmKHRhZ1NldC50YWcpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RJbWFnZVVwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IHByb2R1Y3RJZCA9IGRhdGEucHJvZHVjdF9pZFxyXG4gICAgbGV0IGltYWdlcyA9IGRhdGEuaW1hZ2VzXHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IFtdXHJcblxyXG4gICAgLy8g5ZWG5ZOB44Gr6Zai6YCj44GZ44KL44GZ44G544Gm44Gu55S75YOP5oOF5aCx44KS5YmK6Zmk44GZ44KLXHJcbiAgICBsZXQgc3FsID0gYERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X2ltYWdlIFdIRVJFIHByb2R1Y3RfaWQgPSAke3Byb2R1Y3RJZH1gXHJcbiAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpKVxyXG5cclxuICAgIC8vIOaUueOCgeOBpueUu+WDj+OCkueZu+mMsuOBl+OBquOBiuOBmVxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgJ2R0Yl9wcm9kdWN0X2ltYWdlJywge1xyXG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxyXG4gICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgICAgZmlsZV9uYW1lOiBpbWFnZXNbaV0sXHJcbiAgICAgICAgICByYW5rOiBpICsgMVxyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCB1cGRhdGVEYXRhID0ge31cclxuICAgIGxldCBrZXlzID0gW11cclxuXHJcbiAgICAvLyBkdGJfcHJvZHVjdFxyXG5cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdzdGF0dXMnLFxyXG4gICAgICAnbmFtZScsXHJcbiAgICAgICdub3RlJyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2xpc3QnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJyxcclxuICAgICAgJ3NlYXJjaF93b3JkJyxcclxuICAgICAgJ2ZyZWVfYXJlYSdcclxuICAgIF1cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcclxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0X2NsYXNzXHJcblxyXG4gICAgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnZGVsaXZlcnlfZGF0ZV9pZCcsXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAnc2FsZV9saW1pdCcsXHJcbiAgICAgICdwcmljZTAxJyxcclxuICAgICAgJ3ByaWNlMDInLFxyXG4gICAgICAnZGVsaXZlcnlfZmVlJ1xyXG4gICAgXVxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0Q3JlYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IHt9XHJcblxyXG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fVxyXG4gICAgbGV0IGtleXMgPSBbXVxyXG5cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCdcclxuICAgIF1cclxuICAgIC8vIHtcclxuICAgIC8vICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgLy8gICBkZXNjcmlwdGlvbl9kZXRhaWw6IGl0ZW0uZGVzY3JpcHRpb24sXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHN0YXR1czogMSxcclxuICAgICAgICBub3RlOiAnTlVMTCcsXHJcbiAgICAgICAgZGVzY3JpcHRpb25fbGlzdDogJ05VTEwnLFxyXG4gICAgICAgIHNlYXJjaF93b3JkOiAnTlVMTCcsXHJcbiAgICAgICAgZnJlZV9hcmVhOiAnTlVMTCcsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHVwZGF0ZURhdGEgPSB7fVxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdwcm9kdWN0X3R5cGVfaWQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJyxcclxuICAgICAgJ2RlbGl2ZXJ5X2ZlZSdcclxuICAgIF1cclxuICAgIC8vIHtcclxuICAgIC8vICAgcHJvZHVjdF9jb2RlOiBpdGVtLm1vZGVsLFxyXG4gICAgLy8gICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcclxuICAgIC8vICAgcHJpY2UwMjogaXRlbS5zYWxlc19wcmljZSxcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2NsYXNzX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgcHJvZHVjdF9pZDogcmVzLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgc3RvY2s6IDAsXHJcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxyXG4gICAgICAgIGNsYXNzX2NhdGVnb3J5X2lkMTogJ05VTEwnLFxyXG4gICAgICAgIGNsYXNzX2NhdGVnb3J5X2lkMjogJ05VTEwnLFxyXG4gICAgICAgIGRlbGl2ZXJ5X2RhdGVfaWQ6ICdOVUxMJyxcclxuICAgICAgICBzYWxlX2xpbWl0OiAnTlVMTCcsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9zdG9ja19pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLCB7fSwge1xyXG4gICAgICAgIHByb2R1Y3RfY2xhc3NfaWQ6IHJlcy5wcm9kdWN0X2NsYXNzX2lkLFxyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gZm9yIHRlc3RcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNb25nb0NsaWVudH0gZnJvbSAnbW9uZ29kYidcclxuXHJcbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXHJcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnXHJcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0J1xyXG5cclxuZXhwb3J0IGNsYXNzIERCRmlsdGVyRmFjdG9yeSB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIGxldCBpbnN0YW5jZVxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIGluc3RhbmNlID0gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSlcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gaW5zdGFuY2VcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHRoaXMucGx1ZyA9IHBsdWdcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGVcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmYWN0b3J5IChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgcmV0dXJuIG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsdWcgdHlwZScpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBnZXRQbHVnXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wbHVnXHJcbiAgfVxyXG5cclxuICBnZXRDcmVkXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wbHVnLmNyZWRcclxuICB9XHJcblxyXG4gIGdldFByb2ZpbGVfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGVcclxuICB9XHJcblxyXG4gIHNldEltcG9ydEZ1bmN0aW9uXyAoXHJcbiAgICBmbiA9IGFzeW5jIChvblJlc3VsdCA9IHJlY29yZCA9PiB7fSwgb25FcnJvciA9IGUgPT4ge30pID0+IHt9XHJcbiAgKSB7XHJcbiAgICB0aGlzLmltcG9ydCA9IGZuXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiB1c2VhZ2U6XHJcbiAgICpcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7IE9iamVjdCB9IGl0ZXJhdG9ycyB7IGZpbHRlck5hbWU6IGFzeW5jIChkb2MsY29udGV4dCk9Pnt9LCAuLi4gfSBpdGVyYXRvciBmb3IgZWFjaCBmaWx0ZXJzXHJcbiAgICogQHBhcmFtIHsgYXN5bmMgZnVuY3Rpb24gfSBvbkVycm9yIGVycm9yIGhhbmRsZXIgd2hpbGUgaXRlcmF0aW5nXHJcbiAgICogQHJldHVybnMgeyBPYmplY3QgfSB7IGZpbHRlck5hbWU6IHsgcXVlcnk6IGFueSwgY291bnQ6IG51bWJlciB9LCAuLi4gfVxyXG4gICAqL1xyXG4gIGFzeW5jIGZvcmVhY2ggKGl0ZXJhdG9ycyA9IHt9KSB7XHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZV8oKVxyXG5cclxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXHJcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XHJcbiAgICAgIG5hbWU6ICdtaXNjJyxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBjb3VudGVyID0ge31cclxuICAgIGZvciAobGV0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IGZpbHRlcnMgPSBbXVxyXG5cclxuICAgIGZvciAobGV0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XHJcbiAgICAgIGNvdW50ZXJbZi5uYW1lXSA9IHtcclxuICAgICAgICBxdWVyeTogZi5xdWVyeSxcclxuICAgICAgICBsaW1pdDogdHlwZW9mIGYubGltaXQgIT09ICd1bmRlZmluZWQnID8gZi5saW1pdCA6IDAsXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfVxyXG4gICAgICBmaWx0ZXJzLnB1c2goXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbmFtZTogZi5uYW1lLFxyXG4gICAgICAgICAgZXhhbTogc2lmdChtb2JqZWN0LnVuZXNjYXBlKGYucXVlcnkpKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgZm9yIChsZXQgZiBvZiBmaWx0ZXJzKSB7XHJcbiAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgIGxldCBjID0gY291bnRlcltmLm5hbWVdXHJcbiAgICAgICAgICBpZiAoYy5saW1pdCkge1xyXG4gICAgICAgICAgICBpZiAoYy5jb3VudCA+PSBjLmxpbWl0KSB7XHJcbiAgICAgICAgICAgICAgY29udGludWVcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChmLmV4YW0ocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgICAgYy5jb3VudCsrXHJcblxyXG4gICAgICAgICAgICAvLyBpdGVyYXRvclxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZXJhdG9yc1tmLm5hbWVdICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGl0ZXJhdG9yc1tmLm5hbWVdKHJlY29yZCwgY29udGV4dClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVha1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50ZXJcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBNeXNxbERCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKVxyXG5cclxuICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpXHJcblxyXG4gICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChjcmVkKVxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YFxyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCAoZSkgPT4geyB0aHJvdyBlIH0pXHJcbiAgICAgIHJldHVybiByZXNcclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgTW9uZ29OYXRpdmUgZnJvbSAnbW9uZ29kYic7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gTW9uZ29OYXRpdmUuTW9uZ29DbGllbnQ7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gcmVxdWlyZSgnbW9uZ29kYicpLk1vbmdvQ2xpZW50O1xyXG5cclxuZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpXHJcblxyXG4gICAgLy8gbW9uZ28g44G45o6l57aaXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgbGV0IGNsaWVudFxyXG4gICAgICBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG5cclxuICAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5Y+W5b6XXHJcbiAgICAgIGxldCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKVxyXG4gICAgICBsZXQgY29sbGVjdGlvbiA9IGRiLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKVxyXG5cclxuICAgICAgbGV0IGNvbnRleHQgPSB7XHJcbiAgICAgICAgY2xpZW50OiBjbGllbnQsXHJcbiAgICAgICAgY29sbGVjdGlvbjogY29sbGVjdGlvbixcclxuICAgICAgICBkYXRhYmFzZTogZGJcclxuICAgICAgfVxyXG5cclxuICAgICAgbGV0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpXHJcblxyXG4gICAgICAvLyDjgqvjg7zjgr3jg6vjga7jgr/jgqTjg6DjgqLjgqbjg4jjgpLop6PpmaRcclxuICAgICAgY3VyLmFkZEN1cnNvckZsYWcoJ25vQ3Vyc29yVGltZW91dCcsIHRydWUpXHJcblxyXG4gICAgICAvLyDjgZnjgbnjgabjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgpLjg6vjg7zjg5dcclxuICAgICAgdHJ5IHtcclxuICAgICAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICAgICAgbGV0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgICAgIGF3YWl0IG9uUmVzdWx0KGRvYywgY29udGV4dClcclxuICAgICAgICB9O1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIC8vIOOCq+ODvOOCveODq+OCkumWi+aUvlxyXG4gICAgICAgIGF3YWl0IGN1ci5jbG9zZSgpXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbi8vICAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xyXG4vLyAgICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XHJcblxyXG4vLyAgICAgLy8gbW9uZ28g44G45o6l57aaXHJcbi8vICAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuLy8gICAgIGxldCBjb251cmkgPSBgbW9uZ29kYjovLyR7Y3JlZC5ob3N0fToke2NyZWQucG9ydH0vJHtjcmVkLmRhdGFiYXNlfWA7XHJcbi8vICAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KGNvbnVyaSk7XHJcblxyXG4vLyAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5L2c44KLXHJcbi8vICAgICBsZXQgY29sbGVjdGlvbiA9IG1vbmdvb3NlLmNvbm5lY3Rpb24uY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG5cclxuLy8gICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4vLyAgICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XHJcblxyXG4vLyAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH1cclxuLy8gfVxyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvQ29sbGVjdGlvblxyXG59IGZyb20gJy4uL3V0aWwvbW9uZ28nXHJcbmltcG9ydCB7XHJcbiAgVXBsb2Fkc1xyXG59IGZyb20gJy4uL2NvbGxlY3Rpb24vdXBsb2FkcydcclxuaW1wb3J0IHtcclxuICBPYmplY3RJRFxyXG59IGZyb20gJ2Jzb24nXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtQ29udHJvbGxlciB7XHJcbiAgYXN5bmMgaW5pdCAocGx1Zykge1xyXG4gICAgdGhpcy5JdGVtcyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ2l0ZW1zJylcclxuICAgIHRoaXMuUHJvZHVjdHMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdwcm9kdWN0cycpXHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTdG9jayAoaXRlbUlkKSB7XHJcbiAgICBsZXQgcHJvamVjdCA9IGF3YWl0IHRoaXMuSXRlbXMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogaXRlbUlkXHJcbiAgICB9LCB7XHJcbiAgICAgIHByb2plY3Rpb246IHtcclxuICAgICAgICAncHJvZHVjdCc6IDFcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIGxldCBwcm9kdWN0UGFjayA9IHByb2plY3QucHJvZHVjdFxyXG5cclxuICAgIC8vIHByb2R1Y3QgKiA8LT4gKiBpdGVtXHJcbiAgICAvLyBwcm9kdWN0W106IOikh+aVsOOBruWVhuWTgeOCkjHjg5Hjg4PjgrHjg7zjgrjjgajjgZfjgabosqnlo7JcclxuICAgIC8vIHByb2R1Y3RbW11dOiDnlbDjgarjgovmtYHpgJrntYzot6/jgIHnlbDjgarjgovljp/kvqHjg7vku5XlhaXjgozlgKRcclxuICAgIC8vIGl0ZW06IOeVsOOBquOCi+OCu+ODvOODq+OAgeiyqeWjsuW9ouaFi1xyXG4gICAgLy8g4oC7IHByb2R1Y3Qg44GL44KJ44Gv44CB6LKp5aOy5Y+v6IO944Gq5Zyo5bqr44CB5Yip55uK6KiI566X44Gu44Gf44KB44Gu5oOF5aCx44KS5b6X44KLXHJcblxyXG4gICAgbGV0IHF1YW50aXRpZXMgPSBbXVxyXG5cclxuICAgIGZvciAobGV0IHByb2R1Y3RTa3Ugb2YgcHJvZHVjdFBhY2spIHtcclxuICAgICAgbGV0IHF1YW50aXR5U2t1ID0gMFxyXG5cclxuICAgICAgZm9yIChsZXQgcHJvZHVjdElkIG9mIHByb2R1Y3RTa3UpIHtcclxuICAgICAgICBsZXQgcHJvamVjdCA9IGF3YWl0IHRoaXMuUHJvZHVjdHMuZmluZE9uZSh7XHJcbiAgICAgICAgICBfaWQ6IHByb2R1Y3RJZFxyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIHByb2plY3Rpb246IHtcclxuICAgICAgICAgICAgJ3N0b2NrJzogMVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgbGV0IHN0b2NrQXJyYXkgPSBwcm9qZWN0LnN0b2NrXHJcblxyXG4gICAgICAgIC8vIOWNmOe0lOOBq+OBmeOBueOBpuOBruWcqOW6q+WVhuWTgeOAgeefreacn+mWk+WPluOCiuWvhOOBm+WPr+iDveWVhuWTgeOCkuWQiOeul1xyXG4gICAgICAgIGZvciAobGV0IHN0b2NrIG9mIHN0b2NrQXJyYXkpIHtcclxuICAgICAgICAgIHF1YW50aXR5U2t1ICs9IHN0b2NrLnF1YW50aXR5XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBxdWFudGl0aWVzLnB1c2gocXVhbnRpdHlTa3UpXHJcbiAgICB9XHJcblxyXG4gICAgLy8g44K744OD44OI5ZWG5ZOB44Gu5aC05ZCI44CB5LiA55Wq5bCR44Gq44GE5ZWG5ZOB5pWw44Gr5ZCI44KP44Gb44KLXHJcbiAgICBsZXQgcXVhbnRpdHkgPSBNYXRoLm1pbi5hcHBseShudWxsLCBxdWFudGl0aWVzKVxyXG5cclxuICAgIHJldHVybiBxdWFudGl0eVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOCi+OAglxyXG4gICAqXHJcbiAgICog44Oh44O844Kr44O844Oi44OH44Or44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXHJcbiAgICogY2xhc3Mx44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXHJcbiAgICpcclxuICAgKiDnibnlrprjga7lsZ7mgKfvvIjjgqvjg6njg7zjgarjganvvInjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcclxuICAgKiBjbGFzczHjgavlgKTjgpLmjIflrprjgZfjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcclxuICAgKiDjgoLjgZdjbGFzczLjga7jgb/mjIflrprjgZfjgZ/jgYTloLTlkIjjga9jbGFzczHjgatudWxs44KS5oyH5a6a44GZ44KL44CCXHJcbiAgICpcclxuICAgKiDkvovvvJpKSy0xMDDjga5CTEFDS+OBruWVhuWTgeeUu+WDj+OCklxyXG4gICAqIOOBmeOBueOBpuOBruOCteOCpOOCuu+8iFMsTSxMLFhMLDJYTCwzWEwsNFhM4oCm77yJ44Gr6Zai6YCj5LuY44GR44KL5aC05ZCIXHJcbiAgICogc2V0SW1hZ2UoIHVwbG9hZElkLCAnSkstMTAwJywgJ0JMQUNLJyApO1xyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHVwbG9hZElkIOS4gOWbnuOBruOCouODg+ODl+ODreODvOODieeUu+WDj+OCkuadn+OBreOBpuOBhOOCi0lE44CCbWV0ZW9y44OH44O844K/44OZ44O844K544CBVXBsb2Fkc+OCs+ODrOOCr+OCt+ODp+ODs+WGheODieOCreODpeODoeODs+ODiOOBrnVwbG9hZElk44OX44Ot44OR44OG44KjXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKi9cclxuICBhc3luYyBzZXRJbWFnZSAodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jga7mg4XloLHlj5blvpdcclxuICAgIGxldCBpbWFnZXMgPSBVcGxvYWRzLmZpbmQoe1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWRcclxuICAgIH0pLmZldGNoKCkubWFwKCh2KSA9PiB2LnVwbG9hZGVkRmlsZU5hbWUpXHJcblxyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge31cclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsXHJcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxXHJcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLCB7XHJcbiAgICAgICAgJHB1c2g6IHtcclxuICAgICAgICAgIGltYWdlczoge1xyXG4gICAgICAgICAgICAkZWFjaDogaW1hZ2VzXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8g55m76Yyy44GX44Gf55S75YOP44OV44Kh44Kk44Or5ZCN5LiA6KanXHJcbiAgICByZXR1cm4gaW1hZ2VzXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr55m76Yyy44GV44KM44Gm44GE44KL55S75YOP5oOF5aCx44KS5YmK6Zmk44GZ44KL44CCXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIGNsZWFuSW1hZ2UgKG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcclxuICAgIGxldCBmaWx0ZXIgPSB7fVxyXG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWxcclxuICAgIGlmIChjbGFzczEpIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczFcclxuICAgIGlmIChjbGFzczIpIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczJcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxyXG4gICAgICBmaWx0ZXIsIHtcclxuICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICBpbWFnZXM6IFtdXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDmjIflrprjga7llYblk4HjgavplqLpgKPjgZnjgovllYblk4HnvqTjga7lsZ7mgKfliKXjga7llYblk4Hmg4XloLHjgpLov5TjgZnjgIJcclxuICAgKlxyXG4gICAqIOW8leaVsOOBqOOBl+OBpuWPl+OBkeWPluOCi2l0ZW3jga/ku7vmhI/jga7llYblk4Hmg4XloLHjgIJcclxuICAgKiBpdGVt44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gr44Gk44GE44Gm5b+F6KaB44Gq5oOF5aCx44KS5pW055CG44GX6L+U44GZ44CCXHJcbiAgICpcclxuICAgKiBwcm9qZWN044Gr5Y+C54Wn44GX44Gf44GE5ZWG5ZOB5oOF5aCx44OV44Kj44O844Or44OJ44KS5a6a576p44GZ44KL44CCXHJcbiAgICog44Oh44K944OD44OJ44Gu5ZG844Gz5Ye644GX5pmC44Gr5b+F6KaB44Gr5b+c44GY44GmcHJvamVjdOOCkuioreWumuOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog5L2V44Gr5rOo55uu44GX44Gm5ZWG5ZOB44Gu6Zai6YCj5oCn44KS5qSc5Ye644GZ44KL44GL44Gv44CB44GT44Gu44Oh44K944OD44OJ5YaF44Gn5a6a576p44GZ44KL44CCXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge09iamVjdH0gaXRlbVxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBwcm9qZWN0XHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0VmFyaWF0aW9uIChpdGVtLCBwcm9qZWN0KSB7XHJcbiAgICAvKipcclxuICAgICAqIGFnZ3JlZ2F0aW9u6Kit5a6aXHJcbiAgICAgKlxyXG4gICAgICogbGFiZWw6IOWxnuaAp+WQje+8iOmFjemAgeaWueazleOAgeOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqe+8iVxyXG4gICAgICogY3VycmVudDog5oyH5a6a44GV44KM44Gf44Ki44Kk44OG44Og77yIaXRlbe+8ieOBjOipsuW9k+OBmeOCi+mgheebrlxyXG4gICAgICogcG9yamVjdDog44OQ44Oq44Ko44O844K344On44Oz5qSc57Si44Gu44Kt44O844Go44Gq44KLaXRlbeWGheOBruODleOCo+ODvOODq+ODieWQjSAkW+ODleOCo+ODvOODq+ODieWQjV3lvaLlvI9cclxuICAgICAqIHF1ZXJ5OiBhZ2dyZWdhdGlvbuWvvuixoeOBqOOBmeOCi+ODieOCreODpeODoeODs+ODiOOBruaknOe0ouadoeS7tlxyXG4gICAgICovXHJcbiAgICBsZXQgc2V0ID0gW3tcclxuICAgICAgbGFiZWw6ICfphY3pgIHmlrnms5UnLFxyXG4gICAgICBjdXJyZW50OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckZGVsaXZlcnknXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgY2xhc3MxX3ZhbHVlOiBpdGVtLmNsYXNzMV92YWx1ZSxcclxuICAgICAgICBjbGFzczJfdmFsdWU6IGl0ZW0uY2xhc3MyX3ZhbHVlXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBpdGVtLmNsYXNzMV9uYW1lLFxyXG4gICAgICBjdXJyZW50OiBpdGVtLmNsYXNzMV92YWx1ZSxcclxuICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgIHZhbHVlOiAnJGNsYXNzMV92YWx1ZSdcclxuICAgICAgfSxcclxuICAgICAgcXVlcnk6IHtcclxuICAgICAgICBkZWxpdmVyeTogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgICBjbGFzczJfdmFsdWU6IGl0ZW0uY2xhc3MyX3ZhbHVlXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBpdGVtLmNsYXNzMl9uYW1lLFxyXG4gICAgICBjdXJyZW50OiBpdGVtLmNsYXNzMl92YWx1ZSxcclxuICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgIHZhbHVlOiAnJGNsYXNzMl92YWx1ZSdcclxuICAgICAgfSxcclxuICAgICAgcXVlcnk6IHtcclxuICAgICAgICBkZWxpdmVyeTogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgICBjbGFzczFfdmFsdWU6IGl0ZW0uY2xhc3MxX3ZhbHVlXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIF1cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBbXVxyXG5cclxuICAgIGZvciAobGV0IHMgb2Ygc2V0KSB7XHJcbiAgICAgIGF0dHJzLnB1c2goe1xyXG4gICAgICAgIHZhcmlhdGlvbnM6IGF3YWl0IHRoaXMuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW3tcclxuICAgICAgICAgICAgJG1hdGNoOiBPYmplY3QuYXNzaWduKHMucXVlcnksIHtcclxuICAgICAgICAgICAgICBtb2RlbDogaXRlbS5tb2RlbFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgJHByb2plY3Q6IE9iamVjdC5hc3NpZ24ocy5wcm9qZWN0LCBwcm9qZWN0KVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgJHNvcnQ6IHtcclxuICAgICAgICAgICAgICBfaWQ6IDFcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgICkudG9BcnJheSgpLFxyXG4gICAgICAgIHByb3BzOiBzXHJcbiAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGF0dHJzXHJcbiAgfVxyXG5cclxuICAvLyDjg6Ljg4fjg6vjgq/jg6njgrnlvaLlvI/jgpLkvZzjgotcclxuICAvLyBb44Oh44O844Kr44O844Kz44O844OJXS9b5bGe5oCnMe+8iOOCq+ODqeODvOOBquOBqe+8iV0vW+WxnuaApzLvvIjjgrXjgqTjgrrjgarjganvvIldXHJcbiAgYXN5bmMgZ2V0TW9kZWxDbGFzcyAoYXJnKSB7XHJcbiAgICBsZXQgaXRlbVxyXG4gICAgLy8gaXRlbSDjgYzmloflrZfliJfjgarjgonjgIFpdGVt44Gv5Lu75oSP44Gu44Kq44OW44K444Kn44Kv44OISUTjga7mnKvlsL7jgYvjgonku7vmhI/jga7moYHmlbDjga4xNumAsuaVsFxyXG4gICAgaWYgKHR5cGVvZiBhcmcgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgIGxldCBleHAgPSBuZXcgUmVnRXhwKGAke2FyZ30kYClcclxuICAgICAgbGV0IGN1ciA9IHRoaXMuSXRlbXMuZmluZCh7fSwge1xyXG4gICAgICAgIHByb2plY3Rpb246IHtcclxuICAgICAgICAgIG1vZGVsOiAxLFxyXG4gICAgICAgICAgY2xhc3MxX3ZhbHVlOiAxLFxyXG4gICAgICAgICAgY2xhc3MyX3ZhbHVlOiAxXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgICAgd2hpbGUgKDEpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgaXRlbSA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgICAgIGxldCBtYXRjaCA9IGF3YWl0IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkubWF0Y2goZXhwKVxyXG4gICAgICAgICAgaWYgKG1hdGNoKSB7XHJcbiAgICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgLy8g6Kmy5b2T44GZ44KLaXRlbeODh+ODvOOCv+OBjOOBquOBhFxyXG4gICAgICAgICAgcmV0dXJuIGFyZ1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGl0ZW0gPSBhcmdcclxuICAgIH1cclxuXHJcbiAgICBsZXQgbW9kZWxDbGFzcyA9IFtdXHJcbiAgICBpZiAoaXRlbS5tb2RlbCkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0ubW9kZWwpXHJcbiAgICBpZiAoaXRlbS5jbGFzczFfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMV92YWx1ZSlcclxuICAgIGlmIChpdGVtLmNsYXNzMl92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MyX3ZhbHVlKVxyXG4gICAgcmV0dXJuIG1vZGVsQ2xhc3Muam9pbignLycpXHJcbiAgfVxyXG5cclxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzIChjcmVhdG9ySWQsIGl0ZW0pIHtcclxuICAgIC8vIOWApOWkieaPm1xyXG4gICAgbGV0IGNvbnZEZWxpdiA9IChkZWxpdmVyeSkgPT4gZGVsaXZlcnkgPT09ICfjgobjgYbjg5HjgrHjg4Pjg4gnID8gJ+ODneOCueODiOaKleWHvScgOiBkZWxpdmVyeVxyXG5cclxuICAgIC8vIHByb2R1Y3RfaWRcclxuICAgIGxldCBwcm9kdWN0SWQgPSBudWxsXHJcbiAgICBsZXQgbW9kZWxDbGFzcyA9IFtdXHJcblxyXG4gICAgLy8g5LiL6KiY44Gu5b2i5byP44KS5L2c44KLXHJcbiAgICAvLyBb44Oh44O844Kr44O844Kz44O844OJXS9b5bGe5oCnMe+8iOOCq+ODqeODvOOBquOBqe+8iV0vW+WxnuaApzLvvIjjgrXjgqTjgrrjgarjganvvIldXHJcbiAgICBpZiAoaXRlbS5tb2RlbCkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0ubW9kZWwpXHJcbiAgICBpZiAoaXRlbS5jbGFzczFfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMV92YWx1ZSlcclxuICAgIGlmIChpdGVtLmNsYXNzMl92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MyX3ZhbHVlKVxyXG5cclxuICAgIC8vIOWVhuWTgeeoruWIpeOCkuWJsuOCiuW9k+OBpuOCi1xyXG4gICAgbGV0IHByb2R1Y3RUeXBlSWRcclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMlxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDFcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeOCv+OCsOOCkuioreWumuOBmeOCi1xyXG4gICAgbGV0IHRhZ3MgPSBbXVxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgdGFncy5wdXNoKHtcclxuICAgICAgICAgIHRhZzogNCxcclxuICAgICAgICAgIHNldDogJ29uJ1xyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIHRhZzogNSxcclxuICAgICAgICAgIHNldDogJ29mZidcclxuICAgICAgICB9KVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgdGFncy5wdXNoKHtcclxuICAgICAgICAgIHRhZzogNSxcclxuICAgICAgICAgIHNldDogJ29uJ1xyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIHRhZzogNCxcclxuICAgICAgICAgIHNldDogJ29mZidcclxuICAgICAgICB9KVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB5Yil6YCB5paZ44KS6Kit5a6a44GZ44KLXHJcbiAgICBsZXQgZGVsaXZlcnlGZWUgPSBudWxsXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICBkZWxpdmVyeUZlZSA9IG51bGxcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIGRlbGl2ZXJ5RmVlID0gMjQwXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvL1xyXG4gICAgLy8g6aGn5a6i5ZCR44GR44OQ44Oq44Ko44O844K344On44Oz5ZWG5ZOB6YG45oqe5qmf6IO944Gu5a6f6KOFXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBhdHRycyA9IGF3YWl0IHRoaXMuZ2V0VmFyaWF0aW9uKGl0ZW0sIHtcclxuICAgICAgcHJvZHVjdF9pZDogJyRtYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfaWQnXHJcbiAgICB9KVxyXG5cclxuICAgIC8vIEhUTUwg44OQ44Oq44Ko44O844K344On44Oz5ZWG5ZOB44GU44Go44Gu44Oq44Oz44Kv5LuY44GN44Oc44K/44Oz44KS6KGo56S644GZ44KLXHJcblxyXG4gICAgLy8g5YCk44Gu5aSJ5o+bXHJcbiAgICBhdHRycyA9IGF0dHJzLm1hcChcclxuICAgICAgKGF0dHIpID0+IHtcclxuICAgICAgICBhdHRyLnByb3BzLmN1cnJlbnQgPSBjb252RGVsaXYoYXR0ci5wcm9wcy5jdXJyZW50KVxyXG4gICAgICAgIGF0dHIudmFyaWF0aW9ucyA9IGF0dHIudmFyaWF0aW9ucy5tYXAoXHJcbiAgICAgICAgICAodmFyaWF0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgIHZhcmlhdGlvbi52YWx1ZSA9IGNvbnZEZWxpdih2YXJpYXRpb24udmFsdWUpXHJcbiAgICAgICAgICAgIHJldHVybiB2YXJpYXRpb25cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgcmV0dXJuIGF0dHJcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIEhUTUznlJ/miJBcclxuICAgIGxldCB2YXJpYXRpb25IdG1sID1cclxuICAgICAgYXR0cnMubWFwKFxyXG4gICAgICAgIChhdHRyKSA9PlxyXG4gICAgICAgICAgJzxkaXYgY2xhc3M9XCJjb250YWluZXItZmx1aWRcIj4nICtcclxuICAgICAgICBgPGRpdiBjbGFzcz1cInJvd1wiPmAgK1xyXG4gICAgICAgIGA8ZGl2IHN0eWxlPVwib3BhY2l0eTowLjNcIiBjbGFzcz1cImJ0biBidG4taW5mbyBidG4tYmxvY2sgYnRuLXhzXCI+YCArXHJcbiAgICAgICAgYDxzdHJvbmc+JHthdHRyLnByb3BzLmxhYmVsfTwvc3Ryb25nPmAgK1xyXG4gICAgICAgIGA8L2Rpdj5gICtcclxuICAgICAgICBhdHRyLnZhcmlhdGlvbnMubWFwKFxyXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoYXR0ci5wcm9wcy5jdXJyZW50ID09PSB2YXJpYXRpb24udmFsdWUpIHtcclxuICAgICAgICAgICAgICByZXR1cm4gYDxhIGhyZWY9XCIvcHJvZHVjdHMvZGV0YWlsLyR7dmFyaWF0aW9uLnByb2R1Y3RfaWR9XCI+PGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc3VjY2VzcyBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+PHN0cm9uZz4ke3ZhcmlhdGlvbi52YWx1ZX08L3N0cm9uZz48L2J1dHRvbj48L2E+YFxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIHJldHVybiBgPGEgaHJlZj1cIi9wcm9kdWN0cy9kZXRhaWwvJHt2YXJpYXRpb24ucHJvZHVjdF9pZH1cIj48YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj48L2E+YFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKS5qb2luKCcnKSArXHJcbiAgICAgICAgJzwvZGl2PicgK1xyXG4gICAgICAgICc8L2Rpdj4nXHJcbiAgICAgICkuam9pbignJylcclxuXHJcbiAgICBsZXQgZGVzY3JpcHRpb25EZXRhaWwgPSBgXHJcbiAgICA8c21hbGw+4oC7IOmFjemAgeaWueazleODu+OCq+ODqeODvOODu+OCteOCpOOCuuOBr+S4i+iomOOBi+OCieOBiumBuOOBs+OBj+OBoOOBleOBhOOAgjwvc21hbGw+XHJcbiAgICA8c21hbGwgY2xhc3M9XCJ0ZXh0LWRhbmdlclwiPuKAuyDlnKjluqvjgYzjgarjgYTllYblk4Hjga7loLTlkIjjgIzjg5rjg7zjgrjjgYzopovjgaTjgYvjgorjgb7jgZvjgpPjgI3jgajooajnpLrjgZXjgozjgb7jgZnjgII8L3NtYWxsPlxyXG4gICAgJHt2YXJpYXRpb25IdG1sfVxyXG4gICAgYFxyXG5cclxuICAgIC8vIOWVhuWTgeODh+ODvOOCv+OCkuS9nOOCi1xyXG4gICAgbGV0IGRhdGEgPSB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcclxuICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICBuYW1lOiBgJHttb2RlbENsYXNzLmpvaW4oJy8nKX0gJHtjb252RGVsaXYoaXRlbS5kZWxpdmVyeSl9ICR7aXRlbS5uYW1lfSAke2l0ZW0uamFuX2NvZGV9YCxcclxuICAgICAgZGVzY3JpcHRpb25fZGV0YWlsOiBkZXNjcmlwdGlvbkRldGFpbCxcclxuICAgICAgZnJlZV9hcmVhOiBpdGVtLmRlc2NyaXB0aW9uICsgJyAnLFxyXG4gICAgICBwcm9kdWN0X2NvZGU6IG1vZGVsQ2xhc3Muam9pbignLycpLFxyXG4gICAgICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcclxuICAgICAgcHJpY2UwMjogaXRlbS5zYWxlc19wcmljZSAqIDAuOTUsIC8vIOalveWkqeS+oeagvOOBi+OCiTUl5YCk5byV44GNXHJcbiAgICAgIGltYWdlczogaXRlbS5pbWFnZXMsXHJcbiAgICAgIHByb2R1Y3RfdHlwZV9pZDogcHJvZHVjdFR5cGVJZCxcclxuICAgICAgdGFnczogdGFncyxcclxuICAgICAgZGVsaXZlcnlfZmVlOiBkZWxpdmVyeUZlZVxyXG4gICAgfVxyXG5cclxuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgaXRlbS5tYWxsLnNoYXJha3VTaG9wKVxyXG5cclxuICAgIHJldHVybiBkYXRhXHJcbiAgfVxyXG5cclxuICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjgbjjga7lpInmj5tcclxuICBhc3luYyBjb252ZXJ0SXRlbVlhdWN0IChkZWYsIGl0ZW0pIHtcclxuICAgIGxldCB5YXVjdCA9IHt9XHJcbiAgICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjga7liJ3mnJ/lgKTvvIjjgobjgYbjg5HjgrHjg4Pjg4jjg7vlroXphY3kvr/jgafnlbDjgarjgovvvIlcclxuICAgIHlhdWN0ID0gZGVmW2l0ZW0uZGVsaXZlcnldXHJcblxyXG4gICAgLy8g55S75YOP44Gu6KiY6L+wXHJcbiAgICBjb25zdCBpbWdQcmVmaXggPSAn55S75YOPJ1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtLmltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICB5YXVjdFtpbWdQcmVmaXggKyAoaSArIDEpXSA9IGl0ZW0uaW1hZ2VzW2ldXHJcbiAgICB9XHJcblxyXG4gICAgLy8g44K/44Kk44OI44OrXHJcbiAgICB5YXVjdFsn44Kr44OG44K044OqJ10gPSBpdGVtLm1hbGwueWF1Y3QuY2F0ZWdvcnlcclxuICAgIHlhdWN0Wyfjgr/jgqTjg4jjg6snXSA9IGAke2F3YWl0IHRoaXMuZ2V0TW9kZWxDbGFzcyhpdGVtKX0gJHtpdGVtLmRlbGl2ZXJ5fSAke2l0ZW0ubmFtZX1gXHJcbiAgICB5YXVjdFsn6ZaL5aeL5L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlXHJcbiAgICB5YXVjdFsn5Y2z5rG65L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlXHJcbiAgICB5YXVjdFsn566h55CG55Wq5Y+3J10gPSBpdGVtLl9pZC50b0hleFN0cmluZygpLnNsaWNlKC0yMClcclxuICAgIHlhdWN0WyfoqqzmmI4nXSA9IGl0ZW0uZGVzY3JpcHRpb25cclxuICAgIHlhdWN0WydKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ10gPSBpdGVtLmphbl9jb2RlXHJcblxyXG4gICAgcmV0dXJuIHlhdWN0XHJcbiAgfVxyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIHV0aWxFcnJvciB7XHJcbiAgc3RhdGljIHBhcnNlIChlKSB7XHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICAgIHJlcy5tZXNzYWdlID0gZS5tZXNzYWdlXHJcbiAgICAgIHJlcy5uYW1lID0gZS5uYW1lXHJcbiAgICAgIHJlcy5maWxlTmFtZSA9IGUuZmlsZU5hbWVcclxuICAgICAgcmVzLmxpbmVOdW1iZXIgPSBlLmxpbmVOdW1iZXJcclxuICAgICAgcmVzLmNvbHVtbk51bWJlciA9IGUuY29sdW1uTnVtYmVyXHJcbiAgICAgIHJlcy5zdGFjayA9IGUuc3RhY2tcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlcyA9IGVcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvQ2xpZW50IH0gZnJvbSAnbW9uZ29kYidcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0NvbGxlY3Rpb24ge1xyXG4gIHN0YXRpYyBhc3luYyBnZXQgKHBsdWcsIGNvbGxlY3Rpb24pIHtcclxuICAgIGxldCBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG4gICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICByZXR1cm4gZGIuY29sbGVjdGlvbihjb2xsZWN0aW9uKVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnXHJcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlTUUwge1xyXG4gIGNvbnN0cnVjdG9yIChwcm9maWxlKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pjg5fjg7zjg6vliJ3mnJ/ljJZcclxuICAgIHRoaXMucG9vbCA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZSlcclxuXHJcbiAgICAvLyDopIfmlbDooYzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jlr77lv5xcclxuICAgIGxldCBwcm9maWxlTXVsdGkgPSB7bXVsdGlwbGVTdGF0ZW1lbnRzOiB0cnVlfVxyXG4gICAgT2JqZWN0LmFzc2lnbihwcm9maWxlTXVsdGksIHByb2ZpbGUpXHJcbiAgICB0aGlzLnBvb2xNdWx0aSA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZU11bHRpKVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZvcm1hdERhdGUgKGRhdGUpIHtcclxuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsIDE5KS5yZXBsYWNlKCdUJywgJyAnKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsXHJcbiAgICovXHJcbiAgcXVlcnkgKHNxbCkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz56K656uLXHJcbiAgICAvLyBsZXQgY29uID0gYXdhaXQgdGhpcy5nZXRDb24oKTtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwsIChlLCByZXMpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+mWi+aUvlxyXG4gICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxyXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXMpXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnRfIChzcWwpIHtcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O844CBbnVsbOOAgWphdmFzY3JpcHQtPm15c3Fs5pel5LuY5aSJ5o+b44Gr44KC5a++5b+cXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnQgKHRhYmxlLCBkYXRhID0ge30sIGRhdGFTcWwgPSB7fSkge1xyXG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgXHJcblxyXG4gICAgbGV0IG1hcCA9IG5ldyBNYXAoKVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCkge1xyXG4gICAgICAgIG1hcC5zZXQoaywgJ05VTEwnKVxyXG4gICAgICB9IGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG1hcC5zZXQoaywgYCR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgbWFwLnNldChrLCBkYXRhU3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YVNxbFtrXSlcclxuICAgIH1cclxuXHJcbiAgICBzcWwgKz0gYCggJHtbLi4ubWFwLmtleXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBzcWwgKz0gYFZBTFVFUyggJHtbLi4ubWFwLnZhbHVlcygpXS5qb2luKCcsJyl9ICkgYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICBhc3luYyBxdWVyeVVwZGF0ZSAodGFibGUsIGZpbHRlciwgZGF0YSwgZGF0YVNxbCkge1xyXG4gICAgbGV0IHNxbCA9IGBVUERBVEUgJHt0YWJsZX0gU0VUIGBcclxuXHJcbiAgICBsZXQgdXBkYXRlcyA9IFtdXHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgfVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhU3FsW2tdfWApXHJcbiAgICB9XHJcbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJylcclxuXHJcbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIC8vIGVuYWJsZSB0byB1c2UgbXVsdGlwbGUgc3RhdGVtZW50c1xyXG4gIGFzeW5jIHF1ZXJ5TXVsdGkgKHNxbCkge1xyXG4gICAgbGV0IHBvb2xTd2FwID0gdGhpcy5wb29sXHJcbiAgICB0aGlzLnBvb2wgPSB0aGlzLnBvb2xNdWx0aVxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3RhcnRUcmFuc2FjdGlvbiAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBTVEFSVCBUUkFOU0FDVElPTjtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29tbWl0ICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYENPTU1JVDtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcm9sbGJhY2sgKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgUk9MTEJBQ0s7YClcclxuICB9XHJcblxyXG4gIHN0cmVhbWluZ1F1ZXJ5IChzcWwsIG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pIHtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwpXHJcbiAgICAgICAgICAgICAgICAub24oJ3Jlc3VsdCcsXHJcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb24ucGF1c2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0KHJlY29yZClcclxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKClcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGVcclxuICAgICAgfSlcclxuICB9XHJcblxyXG4gIGdldENvbiAoKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAvLyDjg5fjg7zjg6vjgYvjgonjga7jgrPjg43jgq/jgrfjg6fjg7PnjbLlvpdcclxuICAgICAgICB0aGlzLnBvb2wuZ2V0Q29ubmVjdGlvbigoZSwgY29uKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICByZWplY3QoZSlcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUoY29uKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLmNhdGNoKFxyXG4gICAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgfTtcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBQYWNrZXQge1xyXG4gIGNvbnN0cnVjdG9yIChwYWNrZXRTaXplKSB7XHJcbiAgICB0aGlzLnBhY2tldFNpemUgPSBwYWNrZXRTaXplXHJcbiAgICB0aGlzLm9uUGFja2V0U3RhcnQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldEVuZCA9IG51bGxcclxuICAgIHRoaXMuY291bnQgPSAwXHJcbiAgICB0aGlzLnBhY2tldENvdW50ID0gMFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0IChhcmcpIHtcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHliJ3mnJ/ljJbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0U3RhcnQpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLm9uUGFja2V0U3RhcnQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMub25QYWNrZXQpIHtcclxuICAgICAgYXdhaXQgdGhpcy5vblBhY2tldChhcmcpXHJcbiAgICB9XHJcbiAgICB0aGlzLmNvdW50KytcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHntYLkuoblh6bnkIbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0RW5kKSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMucGFja2V0Q291bnQrK1xyXG4gICAgfVxyXG4gIH1cclxuICBjbG9zZSAoKSB7XHJcbiAgICB0aGlzLm9uUGFja2V0RW5kKHRoaXMucGFja2V0Q291bnQpXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB1dGlsRXJyb3IgZnJvbSAnLi9lcnJvcidcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZXBvcnQge1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMucmVjb3JkID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3JzID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3IgPSBudWxsXHJcbiAgfVxyXG5cclxuICBzZXR1cEl0ZXJhdG9yICgpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IoKVxyXG4gICAgdGhpcy5pdGVyYXRvcnMucHVzaCh0aGlzLml0ZXJhdG9yKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGhhc2UgKG5hbWUgPSAnJywgZm4gPSBhc3luYyAoKSA9PiB7fSkge1xyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKClcclxuXHJcbiAgICBsZXQgcmVjID0ge31cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgZm4oKVxyXG5cclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnc3VjY2VzcycsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiByZXNcclxuICAgICAgfSlcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogdXRpbEVycm9yLnBhcnNlKGUpXHJcbiAgICAgIH0pXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci50b3RhbCkge1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgICBpdGVyYXRvcjogdGhpcy5pdGVyYXRvclxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5yZWNvcmQucHVzaChyZWMpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpU3VjY2VzcyAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLnN1Y2Nlc3MobmV3UmVjb3JkKVxyXG4gIH1cclxuXHJcbiAgaUVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IuZXJyb3IodXRpbEVycm9yLnBhcnNlKG5ld1JlY29yZCkpXHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQgKCkge1xyXG4gICAgbGV0IGl0ZUVycm9yID0gdGhpcy5pdGVyYXRvcnMuZmluZChlID0+IGUuZXJyb3JPY3VycmVkKCkpXHJcbiAgICBsZXQgcGhhRXJyb3IgPSBmYWxzZVxyXG4gICAgZm9yIChsZXQgcmVjIG9mIHRoaXMucmVjb3JkKSB7XHJcbiAgICAgIGlmIChyZWMudHlwZSA9PT0gJ2Vycm9yJykge1xyXG4gICAgICAgIHBoYUVycm9yID0gdHJ1ZVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBpdGVFcnJvciB8fCBwaGFFcnJvclxyXG4gIH1cclxuXHJcbiAgcHVibGlzaCAoKSB7XHJcbiAgICBpZiAodGhpcy5lcnJvck9jdXJyZWQoKSkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKHRoaXMucmVjb3JkKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMucmVjb3JkXHJcbiAgfVxyXG59XHJcblxyXG5jbGFzcyBJdGVyYXRvciB7XHJcbiAgY29uc3RydWN0b3IgKCkge1xyXG4gICAgdGhpcy50b3RhbCA9IDBcclxuICAgIHRoaXMudHJhY2UgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IHtcclxuICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICByZWNvcmRzOiBbXVxyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjoge1xyXG4gICAgICAgIHRvdGFsOiAwLFxyXG4gICAgICAgIHJlY29yZHM6IFtdXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLnRyYWNlLnN1Y2Nlc3MucmVjb3Jkcy5wdXNoKG5ld1JlY29yZClcclxuICAgIH1cclxuICAgIHRoaXMudHJhY2Uuc3VjY2Vzcy50b3RhbCsrXHJcbiAgICB0aGlzLnRvdGFsKytcclxuICB9XHJcbiAgZXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgLy8g55u05YmN44Gu44Ko44Op44O844KS5Y+W5b6XXHJcbiAgICBsZXQgbGFzdEVycm9yID0gbnVsbFxyXG4gICAgbGV0IGluZGV4ID0gdGhpcy50cmFjZS5lcnJvci5yZWNvcmRzLmxlbmd0aFxyXG4gICAgaWYgKGluZGV4KSB7XHJcbiAgICAgIGxhc3RFcnJvciA9IHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkc1tpbmRleCAtIDFdXHJcbiAgICB9XHJcblxyXG4gICAgLy8g55u05YmN44Go5ZCM44GY44Ko44Op44O844Gv55yB44GPXHJcbiAgICBpZiAoSlNPTi5zdHJpbmdpZnkobGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkcy5wdXNoKG5ld1JlY29yZClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy50cmFjZS5lcnJvci50b3RhbCsrXHJcbiAgICB0aGlzLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy50cmFjZS5lcnJvci50b3RhbFxyXG4gIH1cclxufVxyXG4iXX0=
