var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/route/upload/image.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube/cubemig.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 3);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 4);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 5);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let couponCd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let couponName = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discountPrice = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: couponCd,
                coupon_type: 3,
                // 全商品
                coupon_name: couponName,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discountPrice,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                customer_id: record.customer_id,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
        return res;
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/collection.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
      return res;
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.aggregate(query).toArray());
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let ItemController;
module.watch(require("../../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/service/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 5);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  //
  // 商品情報登録と更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              let quantity = Promise.await(itemController.getStock(item._id));
              Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/tooltest.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      const newLocal = Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
        throw e;
      })));
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return newLocal;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/yauct.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
let PassThrough, Transform;
module.watch(require("stream"), {
  PassThrough(v) {
    PassThrough = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 9);
const prefix = 'packet';
const tag = 'yauct';
Meteor.methods({
  //
  // ヤフオク受注ファイル
  [`${tag}.order`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク受注', () => Promise.asyncApply(() => {
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        const workdir = `${config.workdir}/order`;
        const r = fsExtra.createReadStream(`${workdir}/${config.orderLoadfile}`);
        const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`);
        let i = 0;
        r.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
          columns: true
        })).pipe(csv.transform((record, callback) => Promise.asyncApply(() => {
          let err = null; // 管理番号を置き換える

          try {
            record['管理番号'] = Promise.await(itemController.getModelClass(record['管理番号']));
          } catch (e) {
            err = e;
          }

          callback(err, record);
        }))).pipe(csv.stringify({
          header: true
        })).pipe(iconv.decodeStream('UTF-8')).pipe(iconv.encodeStream('SJIS')).pipe(w);
      })));
    });
  },

  //
  // ヤフオク出品ファイル
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク出品', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 繰り返し処理を任意の（packetSize）で分割

        const packet = new Packet(config.packetSize); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // CSVファイルを作成し画像データを収集する場所


        const workdir = `${config.workdir}/work`;
        Promise.await(fsExtra.remove(workdir));
        Promise.await(fsExtra.mkdir(workdir)); // ZIPファイルを保存する場所

        const uploaddir = `${config.workdir}/upload`;
        Promise.await(fsExtra.remove(uploaddir));
        Promise.await(fsExtra.mkdir(uploaddir));
        let cd = null; // パケットフォルダ

        let filename = null; // csvファイル

        let name = null; // パケット番号
        // CSVフィールドを定義し、順番を確定する

        let fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
        let header = fields.map(v => `"${v}"`).join(',') + '\n'; // パケット化開始時

        packet.onPacketStart = packetCount => Promise.asyncApply(() => {
          name = prefix + ('00000' + packetCount).slice(-5);
          cd = `${workdir}/${name}`;
          filename = `${cd}/${config.csvFileName}`;
          Promise.await(fsExtra.mkdir(cd)); // CSVファイルにフィールドを設定する

          Promise.await(fsExtra.appendFile(filename, iconv.encode(header, 'Shift_JIS')));
        }); // パケット化時


        packet.onPacket = arg => Promise.asyncApply(() => {
          let yauct = arg.yauct;
          let item = arg.item; // csvファイルにレコード（商品テンプレート）を追加する

          let record = fields.map(v => {
            return yauct[v] ? `"${yauct[v]}"` : '""';
          }).join(',') + '\n';
          Promise.await(fsExtra.appendFile(filename, iconv.encode(record, 'Shift_JIS'))); // 画像ファイルをコピー

          for (let img of item.images) {
            let imgSrc = `${config.imagedir}/${img}`;
            let imgTgt = `${cd}/${img}`;

            try {
              // 同じファイルがある場合はコピーしない
              Promise.await(fsExtra.access(imgTgt));
            } catch (e) {
              Promise.await(fsExtra.copyFile(imgSrc, imgTgt));
            }
          }
        }); // パケット終了時


        packet.onPacketEnd = packetCount => Promise.asyncApply(() => {
          const zip = archiver('zip');
          const zipname = `${uploaddir}/${name}.zip`;
          const output = fsExtra.createWriteStream(zipname);
          zip.pipe(output);
          zip.directory(cd, false);
          zip.finalize();
        }); // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id)); // itemに定義されている最低必要在庫より多い商品を出品する

            if (quantity >= item.mall.yauct.minQuantity) {
              let yauct = Promise.await(itemController.convertItemYauct(config.default, item));
              Promise.await(packet.submit({
                yauct: yauct,
                item: item
              }));
            }
          })
        }));
        packet.close();
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/configs.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/filters.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/groups.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/uploads.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/cube3api.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  updateStock(productClassId, quantity = 0) {
    return Promise.asyncApply(() => {
      Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      }));
      Promise.await(this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      }));
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = []; // 削除するタグ

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      }); // 表示するタグ


      let tagon = tag => Promise.asyncApply(() => {
        // すでに表示されているタグがあれば何もしない
        let sql = `
      SELECT COUNT(*) FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        let countRes = Promise.await(this.mysql_.query(sql));
        if (countRes[0]['COUNT(*)']) return;
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creatorId,
          create_date: 'NOW()'
        })));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let productId = data.product_id;
      let images = data.images;
      let creatorId = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${productId}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        Promise.await(this.mysql_.queryInsert('dtb_product_image', {
          product_id: productId,
          creator_id: creatorId,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        }));
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let updateData = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      Promise.await(this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      })); // dtb_product_class

      updateData = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      let res = Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      }));
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = {};
      let updateData = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', updateData, {
        creator_id: creatorId,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      updateData = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', updateData, {
        creator_id: creatorId,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creatorId,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/dbfilter.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 3);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 4);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case 'mysql':
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    switch (plug.type) {
      case 'mysql':
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error('invalid plug type');
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   *
   *
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== 'undefined') {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      let res = Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
      return res;
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find(); // カーソルのタイムアウトを解除

      cur.addCursorFlag('noCursorTimeout', true); // すべてのドキュメントをループ

      try {
        while (Promise.await(cur.hasNext())) {
          let doc = Promise.await(cur.next());
          Promise.await(onResult(doc, context));
        }

        ;
      } finally {
        // カーソルを開放
        Promise.await(cur.close());
      }
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/items.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);
let ObjectID;
module.watch(require("bson"), {
  ObjectID(v) {
    ObjectID = v;
  }

}, 2);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(itemId) {
    return Promise.asyncApply(() => {
      let project = Promise.await(this.Items.findOne({
        _id: itemId
      }, {
        projection: {
          'product': 1
        }
      }));
      let productPack = project.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[[]]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let productSku of productPack) {
        let quantitySku = 0;

        for (let productId of productSku) {
          let project = Promise.await(this.Products.findOne({
            _id: productId
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stockArray = project.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stockArray) {
            quantitySku += stock.quantity;
          }
        }

        quantities.push(quantitySku);
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   *
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   *
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   *
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   *
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   *
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }
  /**
   * 指定の商品に関連する商品群の属性別の商品情報を返す。
   *
   * 引数として受け取るitemは任意の商品情報。
   * itemに関連する商品群について必要な情報を整理し返す。
   *
   * projectに参照したい商品情報フィールドを定義する。
   * メソッドの呼び出し時に必要に応じてprojectを設定する。
   *
   * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
   *
   * @param {Object} item
   * @param {Object} project
   */


  getVariation(item, project) {
    return Promise.asyncApply(() => {
      /**
       * aggregation設定
       *
       * label: 属性名（配送方法、カラー、サイズなど）
       * current: 指定されたアイテム（item）が該当する項目
       * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
       * query: aggregation対象とするドキュメントの検索条件
       */
      let set = [{
        label: '配送方法',
        current: item.delivery,
        project: {
          value: '$delivery'
        },
        query: {
          class1_value: item.class1_value,
          class2_value: item.class2_value
        }
      }, {
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          delivery: item.delivery,
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          delivery: item.delivery,
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }, {
            $sort: {
              _id: 1
            }
          }]).toArray()),
          props: s
        });
      }

      return attrs;
    });
  } // モデルクラス形式を作る
  // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]


  getModelClass(arg) {
    return Promise.asyncApply(() => {
      let item; // item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

      if (typeof arg === 'string') {
        let exp = new RegExp(`${arg}$`);
        let cur = this.Items.find({}, {
          projection: {
            model: 1,
            class1_value: 1,
            class2_value: 1
          }
        });

        while (1) {
          try {
            item = Promise.await(cur.next());
            let match = Promise.await(item._id.toHexString().match(exp));

            if (match) {
              break;
            }
          } catch (e) {
            // 該当するitemデータがない
            return arg;
          }
        }
      } else {
        item = arg;
      }

      let modelClass = [];
      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value);
      return modelClass.join('/');
    });
  }

  convertItemCube3(creatorId, item) {
    return Promise.asyncApply(() => {
      // 値変換
      let convDeliv = delivery => delivery === 'ゆうパケット' ? 'ポスト投函' : delivery; // product_id


      let productId = null;
      let modelClass = []; // 下記の形式を作る
      // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]

      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let productTypeId;

      switch (item.delivery) {
        case '宅配便':
          productTypeId = 1;
          break;

        case 'ゆうパケット':
          productTypeId = 2;
          break;

        default:
          productTypeId = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let deliveryFee = null;

      switch (item.delivery) {
        case '宅配便':
          deliveryFee = null;
          break;

        case 'ゆうパケット':
          deliveryFee = 240;
          break;
      } //
      // 顧客向けバリエーション商品選択機能の実装
      //


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      })); // HTML バリエーション商品ごとのリンク付きボタンを表示する
      // 値の変換

      attrs = attrs.map(attr => {
        attr.props.current = convDeliv(attr.props.current);
        attr.variations = attr.variations.map(variation => {
          variation.value = convDeliv(variation.value);
          return variation;
        });
        return attr;
      }); // HTML生成

      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row">` + `<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">` + `<strong>${attr.props.label}</strong>` + `</div>` + attr.variations.map(variation => {
        if (attr.props.current === variation.value) {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-success btn-sm btn-item-class-select"><strong>${variation.value}</strong></button></a>`;
        } else {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-sm btn-item-class-select">${variation.value}</button></a>`;
        }
      }).join('') + '</div>' + '</div>').join('');
      let descriptionDetail = `
    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>
    <small class="text-danger">※ 在庫がない商品の場合「ページが見つかりません」と表示されます。</small>
    ${variationHtml}
    `; // 商品データを作る

      let data = {
        product_id: productId,
        creator_id: creatorId,
        name: `${modelClass.join('/')} ${convDeliv(item.delivery)} ${item.name} ${item.jan_code}`,
        description_detail: descriptionDetail,
        free_area: item.description + ' ',
        product_code: modelClass.join('/'),
        price01: item.retail_price,
        price02: item.sales_price * 0.95,
        // 楽天価格から5%値引き
        images: item.images,
        product_type_id: productTypeId,
        tags: tags,
        delivery_fee: deliveryFee
      };
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  } // ヤフオクテンプレートへの変換


  convertItemYauct(def, item) {
    return Promise.asyncApply(() => {
      let yauct = {}; // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）

      yauct = def[item.delivery]; // 画像の記述

      const imgPrefix = '画像';

      for (let i = 0; i < item.images.length; i++) {
        yauct[imgPrefix + (i + 1)] = item.images[i];
      } // タイトル


      yauct['カテゴリ'] = item.mall.yauct.category;
      yauct['タイトル'] = `${Promise.await(this.getModelClass(item))} ${item.delivery} ${item.name}`;
      yauct['開始価格'] = item.sales_price;
      yauct['即決価格'] = item.sales_price;
      yauct['管理番号'] = item._id.toHexString().slice(-20);
      yauct['説明'] = item.description;
      yauct['JANコード・ISBNコード'] = item.jan_code;
      return yauct;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/error.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mongo.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mysql.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   *
   * @param {String} sql
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, dataSql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(dataSql)) {
        map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, dataSql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(dataSql)) {
        updates.push(`${k}=${dataSql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/packet.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Packet
});

class Packet {
  constructor(packetSize) {
    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  submit(arg) {
    return Promise.asyncApply(() => {
      // packetSizeの回数ごとに、初期化を呼び出す
      if (this.count % this.packetSize === 0) {
        if (this.onPacketStart) {
          Promise.await(this.onPacketStart(this.packetCount));
        }
      }

      if (this.onPacket) {
        Promise.await(this.onPacket(arg));
      }

      this.count++; // packetSizeの回数ごとに、終了処理を呼び出す

      if (this.count % this.packetSize === 0) {
        if (this.onPacketEnd) {
          Promise.await(this.onPacketEnd(this.packetCount));
        }

        this.packetCount++;
      }
    });
  }

  close() {
    this.onPacketEnd(this.packetCount);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/report.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  setupIterator() {
    this.iterator = new Iterator();
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.setupIterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    // 直前のエラーを取得
    let lastError = null;
    let index = this.trace.error.records.length;

    if (index) {
      lastError = this.trace.error.records[index - 1];
    } // 直前と同じエラーは省く


    if (JSON.stringify(lastError) !== JSON.stringify(newRecord)) {
      if (newRecord && newRecord !== {} && newRecord !== '') {
        this.trace.error.records.push(newRecord);
      }
    }

    this.trace.error.total++;
    this.total++;
  }

  errorOcurred() {
    return this.trace.error.total;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90b29sdGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3lhdWN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyJdLCJuYW1lcyI6WyJmcyIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsImRlZmF1bHQiLCJ2IiwidW5pcWlkIiwibXVsdGlwYXJ0eSIsIlVwbG9hZHMiLCJtdWx0aXBhcnR5TWlkZGxld2FyZSIsInJvdXRlIiwiV2ViQXBwIiwiY29ubmVjdEhhbmRsZXJzIiwidXNlIiwicmVxIiwicmVzcCIsInJlYWRlciIsIk1ldGVvciIsIndyYXBBc3luYyIsInJlYWRGaWxlIiwid3JpdGVyIiwid3JpdGVGaWxlIiwidXBsb2FkSWQiLCJmaWxlIiwiZmlsZXMiLCJkYXRhIiwicGF0aCIsImZpbGVuYW1lIiwic2F2ZVBhdGgiLCJib2R5IiwiaW1hZ2VkaXIiLCJkb2MiLCJjbGllbnRGaWxlTmFtZSIsIm5hbWUiLCJ1cGxvYWRlZEZpbGVOYW1lIiwiZXJyIiwiZXJyb3IiLCJpbnNlcnQiLCJ3cml0ZUhlYWQiLCJlbmQiLCJKU09OIiwic3RyaW5naWZ5Iiwic2F2ZURpciIsImNyeXB0byIsIk15U1FMIiwiUmVwb3J0IiwiR3JvdXAiLCJHcm91cEZhY3RvcnkiLCJGaWx0ZXIiLCJ0YWciLCJtZXRob2RzIiwiY29uZmlnIiwicmVwb3J0IiwiZmlsdGVyIiwic3JjRmlsdGVySWQiLCJ0ZXN0UXVlcnkiLCJkc3REYiIsImRzdCIsImNyZWQiLCJwaGFzZSIsInF1ZXJ5IiwicmVzIiwiZm9yZWFjaCIsIm1vYmlsZU51bGwiLCJyZWNvcmQiLCJzcWwiLCJjdXN0b21lcl9pZCIsInN0YXR1cyIsInNleCIsImpvYiIsImNvdW50cnlfaWQiLCJwcmVmIiwibmFtZTAxIiwibmFtZTAyIiwia2FuYTAxIiwia2FuYTAyIiwiY29tcGFueV9uYW1lIiwiemlwMDEiLCJ6aXAwMiIsInppcGNvZGUiLCJhZGRyMDEiLCJhZGRyMDIiLCJlbWFpbCIsInRlbDAxIiwidGVsMDIiLCJ0ZWwwMyIsImZheDAxIiwiZmF4MDIiLCJmYXgwMyIsImJpcnRoIiwicGFzc3dvcmQiLCJzYWx0Iiwic2VjcmV0X2tleSIsImZpcnN0X2J1eV9kYXRlIiwibGFzdF9idXlfZGF0ZSIsImJ1eV90aW1lcyIsImJ1eV90b3RhbCIsIm5vdGUiLCJjcmVhdGVfZGF0ZSIsInVwZGF0ZV9kYXRlIiwiZGVsX2ZsZyIsInF1ZXJ5SW5zZXJ0IiwiZSIsImlFcnJvciIsImN1c3RvbWVyX2FkZHJlc3NfaWQiLCJpZCIsIm1haWxtYWdhX2ZsZyIsImNvdXBvbkNkIiwicmFuZG9tQnl0ZXMiLCJ0b1N0cmluZyIsInN1YnN0cmluZyIsImNvdXBvbk5hbWUiLCJkaXNjb3VudFByaWNlIiwicG9pbnQiLCJjb3Vwb25faWQiLCJjb3Vwb25fY2QiLCJjb3Vwb25fdHlwZSIsImNvdXBvbl9uYW1lIiwiZGlzY291bnRfdHlwZSIsImNvdXBvbl91c2VfdGltZSIsImNvdXBvbl9yZWxlYXNlIiwiZGlzY291bnRfcHJpY2UiLCJkaXNjb3VudF9yYXRlIiwiZW5hYmxlX2ZsYWciLCJjb3Vwb25fbWVtYmVyIiwiY291cG9uX2xvd2VyX2xpbWl0IiwiYXZhaWxhYmxlX2Zyb21fZGF0ZSIsImF2YWlsYWJsZV90b19kYXRlIiwicHVibGlzaCIsInByb2ZpbGUiLCJkYiIsIk1vbmdvQ29sbGVjdGlvbiIsInBsdWciLCJwcm9qZWN0aW9uIiwiY29sbCIsImdldCIsImNvbGxlY3Rpb24iLCJmaW5kIiwidG9BcnJheSIsImFnZ3JlZ2F0ZSIsIkl0ZW1Db250cm9sbGVyIiwibW9kZWwiLCJjbGFzczEiLCJjbGFzczIiLCJpdGVtY29uIiwiaW5pdCIsInVwbG9hZGVkIiwic2V0SW1hZ2UiLCJjbGVhbkltYWdlIiwiTW9uZ29EQkZpbHRlciIsIkN1YmUzQXBpIiwiaXRlbXNEQiIsIml0ZW1Db250cm9sbGVyIiwidGFyZ2V0REIiLCJjdWJlM0RCIiwiYXBpIiwiaXRlbSIsImNvbnRleHQiLCJxdWFudGl0eSIsImdldFN0b2NrIiwiX2lkIiwidXBkYXRlU3RvY2siLCJtYWxsIiwic2hhcmFrdVNob3AiLCJwcm9kdWN0X2NsYXNzX2lkIiwiY29sIiwiY3ViZUl0ZW0iLCJjb252ZXJ0SXRlbUN1YmUzIiwiY3JlYXRvcl9pZCIsImluc2VydFJlcyIsInByb2R1Y3RDcmVhdGUiLCJ1cGRhdGUiLCIkc2V0IiwiaVN1Y2Nlc3MiLCJwcm9kdWN0SW1hZ2VVcGRhdGUiLCJwcm9kdWN0VXBkYXRlIiwicHJvZHVjdFRhZ1VwZGF0ZSIsIm5ld0xvY2FsIiwiUGFja2V0IiwiZnNFeHRyYSIsImljb252IiwiYXJjaGl2ZXIiLCJjc3YiLCJQYXNzVGhyb3VnaCIsIlRyYW5zZm9ybSIsInByZWZpeCIsIndvcmtkaXIiLCJyIiwiY3JlYXRlUmVhZFN0cmVhbSIsIm9yZGVyTG9hZGZpbGUiLCJ3IiwiY3JlYXRlV3JpdGVTdHJlYW0iLCJvcmRlclNhdmVmaWxlIiwiaSIsInBpcGUiLCJkZWNvZGVTdHJlYW0iLCJlbmNvZGVTdHJlYW0iLCJwYXJzZSIsImNvbHVtbnMiLCJ0cmFuc2Zvcm0iLCJjYWxsYmFjayIsImdldE1vZGVsQ2xhc3MiLCJoZWFkZXIiLCJwYWNrZXQiLCJwYWNrZXRTaXplIiwibWtkaXIiLCJyZW1vdmUiLCJ1cGxvYWRkaXIiLCJjZCIsImZpZWxkcyIsIm1hcCIsImpvaW4iLCJvblBhY2tldFN0YXJ0IiwicGFja2V0Q291bnQiLCJzbGljZSIsImNzdkZpbGVOYW1lIiwiYXBwZW5kRmlsZSIsImVuY29kZSIsIm9uUGFja2V0IiwiYXJnIiwieWF1Y3QiLCJpbWciLCJpbWFnZXMiLCJpbWdTcmMiLCJpbWdUZ3QiLCJhY2Nlc3MiLCJjb3B5RmlsZSIsIm9uUGFja2V0RW5kIiwiemlwIiwiemlwbmFtZSIsIm91dHB1dCIsImRpcmVjdG9yeSIsImZpbmFsaXplIiwibWluUXVhbnRpdHkiLCJjb252ZXJ0SXRlbVlhdWN0Iiwic3VibWl0IiwiY2xvc2UiLCJleHBvcnQiLCJDb25maWdzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiaWRHZW5lcmF0aW9uIiwic2lmdCIsIm1vYmplY3QiLCJHcm91cEJhc2UiLCJGaWx0ZXJzIiwiY29uc3RydWN0b3IiLCJmaWx0ZXJJZCIsImZpbmRPbmUiLCJnZXRQbHVnIiwidHlwZSIsIm15c3FsIiwiaW1wb3J0Iiwib25SZXN1bHQiLCJvbkVycm9yIiwidGFibGUiLCJzdHJlYW1pbmdRdWVyeSIsIkVycm9yIiwiY2FsbGJhY2tzIiwiZ2V0UHJvZmlsZSIsImZpbHRlcnMiLCJwdXNoIiwiY291bnQiLCJ1bmVzY2FwZSIsImV4YW0iLCJHcm91cHMiLCJwbGF0Zm9ybVBsdWciLCJncm91cElkIiwia2V5IiwiY3VyIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJmb3JFYWNoIiwiaW5kZXgiLCJjYXRjaCIsIm15c3FsXyIsInByb2R1Y3RDbGFzc0lkIiwicXVlcnlVcGRhdGUiLCJzdG9jayIsInN0b2NrX3VubGltaXRlZCIsImNyZWF0b3JJZCIsInRhZ29mZiIsInByb2R1Y3RfaWQiLCJ0YWdvbiIsImNvdW50UmVzIiwidGFnU2V0IiwidGFncyIsInNldCIsInByb2R1Y3RJZCIsImxlbmd0aCIsImZpbGVfbmFtZSIsInJhbmsiLCJ1cGRhdGVEYXRhIiwia2V5cyIsImsiLCJkZXNjcmlwdGlvbl9saXN0Iiwic2VhcmNoX3dvcmQiLCJmcmVlX2FyZWEiLCJjbGFzc19jYXRlZ29yeV9pZDEiLCJjbGFzc19jYXRlZ29yeV9pZDIiLCJkZWxpdmVyeV9kYXRlX2lkIiwic2FsZV9saW1pdCIsInByb2R1Y3Rfc3RvY2tfaWQiLCJEQkZpbHRlckZhY3RvcnkiLCJEQkZpbHRlciIsIk15c3FsREJGaWx0ZXIiLCJNb25nb0NsaWVudCIsImluc3RhbmNlIiwiZmFjdG9yeSIsImdldFBsdWdfIiwiZ2V0Q3JlZF8iLCJnZXRQcm9maWxlXyIsInNldEltcG9ydEZ1bmN0aW9uXyIsImZuIiwiaXRlcmF0b3JzIiwiY291bnRlciIsImYiLCJsaW1pdCIsImMiLCJjbGllbnQiLCJjb25uZWN0IiwidXJpIiwiZGF0YWJhc2UiLCJhZGRDdXJzb3JGbGFnIiwiaGFzTmV4dCIsIm5leHQiLCJPYmplY3RJRCIsIkl0ZW1zIiwiUHJvZHVjdHMiLCJpdGVtSWQiLCJwcm9qZWN0IiwicHJvZHVjdFBhY2siLCJwcm9kdWN0IiwicXVhbnRpdGllcyIsInByb2R1Y3RTa3UiLCJxdWFudGl0eVNrdSIsInN0b2NrQXJyYXkiLCJNYXRoIiwibWluIiwiYXBwbHkiLCJmZXRjaCIsImNsYXNzMV92YWx1ZSIsImNsYXNzMl92YWx1ZSIsInVwZGF0ZU1hbnkiLCIkcHVzaCIsIiRlYWNoIiwiZ2V0VmFyaWF0aW9uIiwibGFiZWwiLCJjdXJyZW50IiwiZGVsaXZlcnkiLCJ2YWx1ZSIsImNsYXNzMV9uYW1lIiwiY2xhc3MyX25hbWUiLCJhdHRycyIsInMiLCJ2YXJpYXRpb25zIiwiJG1hdGNoIiwiT2JqZWN0IiwiYXNzaWduIiwiJHByb2plY3QiLCIkc29ydCIsInByb3BzIiwiZXhwIiwiUmVnRXhwIiwibWF0Y2giLCJ0b0hleFN0cmluZyIsIm1vZGVsQ2xhc3MiLCJjb252RGVsaXYiLCJwcm9kdWN0VHlwZUlkIiwiZGVsaXZlcnlGZWUiLCJhdHRyIiwidmFyaWF0aW9uIiwidmFyaWF0aW9uSHRtbCIsImRlc2NyaXB0aW9uRGV0YWlsIiwiamFuX2NvZGUiLCJkZXNjcmlwdGlvbl9kZXRhaWwiLCJkZXNjcmlwdGlvbiIsInByb2R1Y3RfY29kZSIsInByaWNlMDEiLCJyZXRhaWxfcHJpY2UiLCJwcmljZTAyIiwic2FsZXNfcHJpY2UiLCJwcm9kdWN0X3R5cGVfaWQiLCJkZWxpdmVyeV9mZWUiLCJkZWYiLCJpbWdQcmVmaXgiLCJjYXRlZ29yeSIsInV0aWxFcnJvciIsIm1lc3NhZ2UiLCJmaWxlTmFtZSIsImxpbmVOdW1iZXIiLCJjb2x1bW5OdW1iZXIiLCJzdGFjayIsIm1vbWVudCIsInBvb2wiLCJjcmVhdGVQb29sIiwicHJvZmlsZU11bHRpIiwibXVsdGlwbGVTdGF0ZW1lbnRzIiwicG9vbE11bHRpIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJmb3JtYXQiLCJyZXBsYWNlIiwiZ2V0Q29uIiwidGhlbiIsImNvbiIsInJlbGVhc2UiLCJxdWVyeUluc2VydF8iLCJpbnNlcnRJZCIsImRhdGFTcWwiLCJNYXAiLCJlc2NhcGUiLCJ2YWx1ZXMiLCJ1cGRhdGVzIiwicXVlcnlNdWx0aSIsInBvb2xTd2FwIiwic3RhcnRUcmFuc2FjdGlvbiIsImNvbW1pdCIsInJvbGxiYWNrIiwib24iLCJwYXVzZSIsInJlc3VtZSIsImdldENvbm5lY3Rpb24iLCJpdGVyYXRvciIsInNldHVwSXRlcmF0b3IiLCJJdGVyYXRvciIsInJlYyIsInJlc3VsdCIsInRvdGFsIiwibmV3UmVjb3JkIiwic3VjY2VzcyIsImVycm9yT2N1cnJlZCIsIml0ZUVycm9yIiwicGhhRXJyb3IiLCJ0cmFjZSIsInJlY29yZHMiLCJsYXN0RXJyb3IiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsRUFBSjtBQUFPQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsSUFBUixDQUFiLEVBQTJCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDTCxTQUFHSyxDQUFIO0FBQUs7O0FBQWpCLENBQTNCLEVBQThDLENBQTlDO0FBQWlELElBQUlDLE1BQUo7QUFBV0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJRSxVQUFKO0FBQWVOLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDRSxpQkFBV0YsQ0FBWDtBQUFhOztBQUF6QixDQUEzQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJRyxPQUFKO0FBQVlQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQ0FBUixDQUFiLEVBQTREO0FBQUNLLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTVELEVBQW9GLENBQXBGO0FBYWhPLElBQUlJLHVCQUF1QkYsWUFBM0I7QUFFQSxNQUFNRyxRQUFRLGVBQWQsQyxDQUVBOztBQUNBQyxPQUFPQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQkgsS0FBM0IsRUFBa0NELG9CQUFsQztBQUNBRSxPQUFPQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQkgsS0FBM0IsRUFBa0MsQ0FBQ0ksR0FBRCxFQUFNQyxJQUFOLEtBQWU7QUFDL0M7QUFFQSxRQUFNQyxTQUFTQyxPQUFPQyxTQUFQLENBQWlCbEIsR0FBR21CLFFBQXBCLENBQWY7QUFDQSxRQUFNQyxTQUFTSCxPQUFPQyxTQUFQLENBQWlCbEIsR0FBR3FCLFNBQXBCLENBQWY7QUFDQSxRQUFNQyxXQUFXaEIsUUFBakI7O0FBRUEsT0FBSyxJQUFJaUIsSUFBVCxJQUFpQlQsSUFBSVUsS0FBSixDQUFVRCxJQUEzQixFQUFpQztBQUMvQixVQUFNRSxPQUFPVCxPQUFPTyxLQUFLRyxJQUFaLENBQWIsQ0FEK0IsQ0FFL0I7QUFDQTs7QUFDQSxRQUFJQyxXQUFZLEdBQUVyQixRQUFTLE1BQTNCLENBSitCLENBTS9COztBQUNBLFFBQUlzQixXQUFXZCxJQUFJZSxJQUFKLENBQVNDLFFBQVQsR0FBb0IsR0FBcEIsR0FBMEJILFFBQXpDLENBUCtCLENBUy9CO0FBRUE7O0FBQ0EsUUFBSUksTUFBTTtBQUNSVCxnQkFBVUEsUUFERjtBQUVSVSxzQkFBZ0JULEtBQUtVLElBRmI7QUFHUkMsd0JBQWtCUDtBQUhWLEtBQVY7O0FBTUEsUUFBRztBQUNEUCxhQUFPUSxRQUFQLEVBQWlCSCxJQUFqQjtBQUNELEtBRkQsQ0FHQSxPQUFNVSxHQUFOLEVBQVU7QUFDUkosVUFBSUssS0FBSixHQUFZRCxHQUFaO0FBQ0Q7O0FBQ0QzQixZQUFRNkIsTUFBUixDQUFlTixHQUFmO0FBRUEsV0FBT1IsSUFBUDtBQUVEOztBQUFBO0FBQ0RSLE9BQUt1QixTQUFMLENBQWUsR0FBZjtBQUNBdkIsT0FBS3dCLEdBQUwsQ0FBU0MsS0FBS0MsU0FBTCxDQUFlO0FBQ3RCbkIsY0FBVUEsUUFEWTtBQUV0Qm9CLGFBQVM1QixJQUFJZSxJQUFKLENBQVNDO0FBRkksR0FBZixDQUFUO0FBS0QsQ0ExQ0QsRTs7Ozs7Ozs7Ozs7QUNuQkEsSUFBSWEsTUFBSjtBQUFXMUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3NDLGFBQU90QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBakQsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSXdDLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwyQkFBUixDQUFiLEVBQWtEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBbEQsRUFBeUUsQ0FBekU7QUFBNEUsSUFBSXlDLEtBQUosRUFBVUMsWUFBVjtBQUF1QjlDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxpQ0FBUixDQUFiLEVBQXdEO0FBQUMyQyxRQUFNekMsQ0FBTixFQUFRO0FBQUN5QyxZQUFNekMsQ0FBTjtBQUFRLEdBQWxCOztBQUFtQjBDLGVBQWExQyxDQUFiLEVBQWU7QUFBQzBDLG1CQUFhMUMsQ0FBYjtBQUFlOztBQUFsRCxDQUF4RCxFQUE0RyxDQUE1RztBQUErRyxJQUFJMkMsTUFBSjtBQUFXL0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGtDQUFSLENBQWIsRUFBeUQ7QUFBQzZDLFNBQU8zQyxDQUFQLEVBQVM7QUFBQzJDLGFBQU8zQyxDQUFQO0FBQVM7O0FBQXBCLENBQXpELEVBQStFLENBQS9FO0FBYTFjLElBQUk0QyxNQUFNLFNBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYixHQUFRLEdBQUVELEdBQUksVUFBZCxFQUEwQkUsTUFBMUI7QUFBQSxvQ0FBa0M7QUFDaEMsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWIsQ0FEZ0MsQ0FHaEM7QUFDQTs7QUFFQSxVQUFJUSxTQUFTLElBQUlMLE1BQUosQ0FBV0csT0FBT0csV0FBbEIsQ0FBYixDQU5nQyxDQU9oQztBQUVBO0FBQ0E7O0FBRUEsVUFBSUMsWUFBWSxnQkFBaEI7QUFFQSxVQUFJQyxRQUFRLElBQUlaLEtBQUosQ0FBVU8sT0FBT00sR0FBUCxDQUFXQyxJQUFyQixDQUFaO0FBRUEsb0JBQU1OLE9BQU9PLEtBQVAsQ0FBYSx3QkFBYixFQUNKLCtCQUFZO0FBQ1Ysc0JBQU1ILE1BQU1JLEtBQU4sQ0FBWUwsU0FBWixDQUFOO0FBQ0QsT0FGRCxDQURJLENBQU4sRUFoQmdDLENBcUJoQztBQUNBOztBQUVBLG9CQUFNSCxPQUFPTyxLQUFQLENBQWEsdUJBQWIsRUFDSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFDN0JDLHNCQUFtQkMsTUFBUCw2QkFBa0I7QUFDNUI7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBRUE7QUFFQSxnQkFBSUMsTUFBTzs7Ozs7MEJBS0dELE9BQU9FLFdBQVksTUFBS0YsT0FBT0csTUFBTyxNQUFLSCxPQUFPSSxHQUFJLE1BQUtKLE9BQU9LLEdBQUksTUFBS0wsT0FBT00sVUFBVyxNQUFLTixPQUFPTyxJQUFLLE1BQUtQLE9BQU9RLE1BQU8sTUFBS1IsT0FBT1MsTUFBTyxNQUFLVCxPQUFPVSxNQUFPLE1BQUtWLE9BQU9XLE1BQU8sTUFBS1gsT0FBT1ksWUFBYSxNQUFLWixPQUFPYSxLQUFNLE1BQUtiLE9BQU9jLEtBQU0sTUFBS2QsT0FBT2UsT0FBUSxNQUFLZixPQUFPZ0IsTUFBTyxNQUFLaEIsT0FBT2lCLE1BQU8sTUFBS2pCLE9BQU9rQixLQUFNLE1BQUtsQixPQUFPbUIsS0FBTSxNQUFLbkIsT0FBT29CLEtBQU0sTUFBS3BCLE9BQU9xQixLQUFNLE1BQUtyQixPQUFPc0IsS0FBTSxNQUFLdEIsT0FBT3VCLEtBQU0sTUFBS3ZCLE9BQU93QixLQUFNLE1BQUt4QixPQUFPeUIsS0FBTSxNQUFLekIsT0FBTzBCLFFBQVMsTUFBSzFCLE9BQU8yQixJQUFLLE1BQUszQixPQUFPNEIsVUFBVyxNQUFLNUIsT0FBTzZCLGNBQWUsTUFBSzdCLE9BQU84QixhQUFjLE1BQUs5QixPQUFPK0IsU0FBVSxNQUFLL0IsT0FBT2dDLFNBQVUsTUFBS2hDLE9BQU9pQyxJQUFLLE1BQUtqQyxPQUFPa0MsV0FBWSxNQUFLbEMsT0FBT21DLFdBQVksTUFBS25DLE9BQU9vQyxPQUFROztpQkFMbHNCOztBQVNBLGdCQUFJO0FBQ0YsNEJBQU01QyxNQUFNNkMsV0FBTixDQUNKLGNBREksRUFDWTtBQUNkbkMsNkJBQWFGLE9BQU9FLFdBRE47QUFFZEMsd0JBQVFILE9BQU9HLE1BRkQ7QUFHZEMscUJBQUtKLE9BQU9JLEdBSEU7QUFJZEMscUJBQUtMLE9BQU9LLEdBSkU7QUFLZEMsNEJBQVlOLE9BQU9NLFVBTEw7QUFNZEMsc0JBQU1QLE9BQU9PLElBTkM7QUFPZEMsd0JBQVFSLE9BQU9RLE1BUEQ7QUFRZEMsd0JBQVFULE9BQU9TLE1BUkQ7QUFTZEMsd0JBQVFWLE9BQU9VLE1BVEQ7QUFVZEMsd0JBQVFYLE9BQU9XLE1BVkQ7QUFXZEMsOEJBQWNaLE9BQU9ZLFlBWFA7QUFZZEMsdUJBQU9iLE9BQU9hLEtBWkE7QUFhZEMsdUJBQU9kLE9BQU9jLEtBYkE7QUFjZEMseUJBQVNmLE9BQU9lLE9BZEY7QUFlZEMsd0JBQVFoQixPQUFPZ0IsTUFmRDtBQWdCZEMsd0JBQVFqQixPQUFPaUIsTUFoQkQ7QUFpQmRDLHVCQUFPbEIsT0FBT2tCLEtBakJBO0FBa0JkQyx1QkFBT25CLE9BQU9tQixLQWxCQTtBQW1CZEMsdUJBQU9wQixPQUFPb0IsS0FuQkE7QUFvQmRDLHVCQUFPckIsT0FBT3FCLEtBcEJBO0FBcUJkQyx1QkFBT3RCLE9BQU9zQixLQXJCQTtBQXNCZEMsdUJBQU92QixPQUFPdUIsS0F0QkE7QUF1QmRDLHVCQUFPeEIsT0FBT3dCLEtBdkJBO0FBd0JkQyx1QkFBT3pCLE9BQU95QixLQXhCQTtBQXlCZEMsMEJBQVUxQixPQUFPMEIsUUF6Qkg7QUEwQmRDLHNCQUFNM0IsT0FBTzJCLElBMUJDO0FBMkJkQyw0QkFBWTVCLE9BQU80QixVQTNCTDtBQTRCZEMsZ0NBQWdCN0IsT0FBTzZCLGNBNUJUO0FBNkJkQywrQkFBZTlCLE9BQU84QixhQTdCUjtBQThCZEMsMkJBQVcvQixPQUFPK0IsU0E5Qko7QUErQmRDLDJCQUFXaEMsT0FBT2dDLFNBL0JKO0FBZ0NkQyxzQkFBTWpDLE9BQU9pQyxJQWhDQztBQWlDZEMsNkJBQWFsQyxPQUFPa0MsV0FqQ047QUFrQ2RDLDZCQUFhbkMsT0FBT21DLFdBbENOO0FBbUNkQyx5QkFBU3BDLE9BQU9vQztBQW5DRixlQURaLENBQU47QUF1Q0QsYUF4Q0QsQ0F3Q0UsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBaEUyQixDQWtFNUI7OztBQUNBLGdCQUFJO0FBQ0YsNEJBQU05QyxNQUFNNkMsV0FBTixDQUNKLHNCQURJLEVBQ29CO0FBQ3RCRyxxQ0FBcUIsSUFEQztBQUV0QnRDLDZCQUFhRixPQUFPRSxXQUZFO0FBR3RCSSw0QkFBWU4sT0FBT00sVUFIRztBQUl0QkMsc0JBQU1QLE9BQU9PLElBSlM7QUFLdEJDLHdCQUFRUixPQUFPUSxNQUxPO0FBTXRCQyx3QkFBUVQsT0FBT1MsTUFOTztBQU90QkMsd0JBQVFWLE9BQU9VLE1BUE87QUFRdEJDLHdCQUFRWCxPQUFPVyxNQVJPO0FBU3RCQyw4QkFBY1osT0FBT1ksWUFUQztBQVV0QkMsdUJBQU9iLE9BQU9hLEtBVlE7QUFXdEJDLHVCQUFPZCxPQUFPYyxLQVhRO0FBWXRCQyx5QkFBU2YsT0FBT2UsT0FaTTtBQWF0QkMsd0JBQVFoQixPQUFPZ0IsTUFiTztBQWN0QkMsd0JBQVFqQixPQUFPaUIsTUFkTztBQWV0QkUsdUJBQU9uQixPQUFPbUIsS0FmUTtBQWdCdEJDLHVCQUFPcEIsT0FBT29CLEtBaEJRO0FBaUJ0QkMsdUJBQU9yQixPQUFPcUIsS0FqQlE7QUFrQnRCQyx1QkFBT3RCLE9BQU9zQixLQWxCUTtBQW1CdEJDLHVCQUFPdkIsT0FBT3VCLEtBbkJRO0FBb0J0QkMsdUJBQU94QixPQUFPd0IsS0FwQlE7QUFxQnRCVSw2QkFBYWxDLE9BQU9rQyxXQXJCRTtBQXNCdEJDLDZCQUFhbkMsT0FBT21DLFdBdEJFO0FBdUJ0QkMseUJBQVNwQyxPQUFPb0M7QUF2Qk0sZUFEcEIsQ0FBTjtBQTJCRCxhQTVCRCxDQTRCRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFqRzJCLENBbUc1Qjs7O0FBQ0EsZ0JBQUk7QUFDRiw0QkFBTTlDLE1BQU02QyxXQUFOLENBQ0osdUJBREksRUFDcUI7QUFDdkJJLG9CQUFJLElBRG1CO0FBRXZCdkMsNkJBQWFGLE9BQU9FLFdBRkc7QUFHdkJ3Qyw4QkFBYzFDLE9BQU8wQyxZQUhFO0FBSXZCUiw2QkFBYWxDLE9BQU9rQyxXQUpHO0FBS3ZCQyw2QkFBYW5DLE9BQU9tQyxXQUxHO0FBTXZCQyx5QkFBU3BDLE9BQU9vQztBQU5PLGVBRHJCLENBQU47QUFVRCxhQVhELENBV0UsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBakgyQixDQW1INUI7OztBQUVBLGdCQUFJSyxXQUFXaEUsT0FBT2lFLFdBQVAsQ0FBbUIsQ0FBbkIsRUFBc0JDLFFBQXRCLENBQStCLFFBQS9CLEVBQXlDQyxTQUF6QyxDQUFtRCxDQUFuRCxFQUFzRCxFQUF0RCxDQUFmO0FBRUEsZ0JBQUlDLGFBQWMsR0FBRS9DLE9BQU9RLE1BQU8sSUFBR1IsT0FBT1MsTUFBTyxtQkFBa0JULE9BQU9FLFdBQVksRUFBeEY7QUFFQSxnQkFBSThDLGdCQUFnQmhELE9BQU9pRCxLQUFQLEdBQWUsR0FBbkM7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSXBELG9CQUFZTCxNQUFNNkMsV0FBTixDQUNkLFlBRGMsRUFDQTtBQUNaYSwyQkFBVyxJQURDO0FBRVpDLDJCQUFXUixRQUZDO0FBR1pTLDZCQUFhLENBSEQ7QUFHSTtBQUNoQkMsNkJBQWFOLFVBSkQ7QUFLWk8sK0JBQWUsQ0FMSDtBQU1aQyxpQ0FBaUIsQ0FOTDtBQU9aQyxnQ0FBZ0IsQ0FQSjtBQVFaQyxnQ0FBZ0JULGFBUko7QUFTWlUsK0JBQWUsSUFUSDtBQVVaQyw2QkFBYSxDQVZEO0FBV1pDLCtCQUFlLENBWEg7QUFZWkMsb0NBQW9CLElBWlI7QUFhWjNELDZCQUFhRixPQUFPRSxXQWJSO0FBY1o0RCxxQ0FBcUIscUJBZFQ7QUFlWkMsbUNBQW1CLHFCQWZQO0FBZ0JaM0IseUJBQVM7QUFoQkcsZUFEQSxFQWtCWDtBQUNERiw2QkFBYSxPQURaO0FBRURDLDZCQUFhO0FBRlosZUFsQlcsQ0FBWixDQUFKO0FBdUJELGFBeEJELENBd0JFLE9BQU9HLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBdEpXO0FBRGlCLFNBQWYsRUF5SlRBLENBQVAsNkJBQWE7QUFDWGxELGlCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsU0FGRCxDQXpKZ0IsQ0FBWixDQUFKO0FBOEpBLGVBQU96QyxHQUFQO0FBQ0QsT0FoS0QsQ0FESSxDQUFOO0FBbUtBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTVMRDtBQUFBLEdBRmE7O0FBZ01QLHVCQUFOLENBQTZCQyxPQUE3QjtBQUFBLG9DQUFzQztBQUNwQyxVQUFJQyxLQUFLLElBQUl0RixLQUFKLENBQVVxRixPQUFWLENBQVQ7QUFDQSxVQUFJcEUsb0JBQVlxRSxHQUFHdEUsS0FBSCxDQUFTLGdCQUFULENBQVosQ0FBSjtBQUNBLGFBQU9DLEdBQVA7QUFDRCxLQUpEO0FBQUE7O0FBaE1hLENBQWYsRTs7Ozs7Ozs7Ozs7QUNmQSxJQUFJc0UsZUFBSjtBQUFvQmxJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNnSSxrQkFBZ0I5SCxDQUFoQixFQUFrQjtBQUFDOEgsc0JBQWdCOUgsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQWpELEVBQXlGLENBQXpGO0FBQTRGLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHM0gsSUFBSTRDLE1BQU0sa0JBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYixHQUFRLEdBQUVELEdBQUksT0FBZCxFQUF1Qm1GLElBQXZCLEVBQTZCeEUsUUFBUSxFQUFyQyxFQUF5Q3lFLGFBQWEsRUFBdEQ7QUFBQSxvQ0FBMEQ7QUFDeEQsVUFBSUMscUJBQWFILGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCQSxLQUFLSSxVQUEvQixDQUFiLENBQUo7QUFDQSxVQUFJM0Usb0JBQVl5RSxLQUFLRyxJQUFMLENBQVU3RSxLQUFWLEVBQWlCO0FBQUN5RSxvQkFBWUE7QUFBYixPQUFqQixFQUEyQ0ssT0FBM0MsRUFBWixDQUFKO0FBQ0EsYUFBTzdFLEdBQVA7QUFDRCxLQUpEO0FBQUEsR0FGYTs7QUFRYixHQUFRLEdBQUVaLEdBQUksWUFBZCxFQUE0Qm1GLElBQTVCLEVBQWtDeEUsUUFBUSxFQUExQztBQUFBLG9DQUE4QztBQUM1QyxVQUFJMEUscUJBQWFILGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCQSxLQUFLSSxVQUEvQixDQUFiLENBQUo7QUFDQSxVQUFJM0Usb0JBQVl5RSxLQUFLSyxTQUFMLENBQWUvRSxLQUFmLEVBQXNCOEUsT0FBdEIsRUFBWixDQUFKO0FBQ0EsYUFBTzdFLEdBQVA7QUFDRCxLQUpEO0FBQUE7O0FBUmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBLElBQUkrRSxjQUFKO0FBQW1CM0ksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1SSxxQkFBZXZJLENBQWY7QUFBaUI7O0FBQTdCLENBQXBELEVBQW1GLENBQW5GO0FBQXNGLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFHcEgsSUFBSTRDLE1BQU0sYUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViOzs7OztBQUtBLEdBQVEsR0FBRUQsR0FBSSxXQUFkLEVBQTJCbUYsSUFBM0IsRUFBaUM5RyxRQUFqQyxFQUEyQ3VILEtBQTNDLEVBQWtEQyxTQUFTLElBQTNELEVBQWlFQyxTQUFTLElBQTFFO0FBQUEsb0NBQWdGO0FBQzlFLFVBQUlDLFVBQVUsSUFBSUosY0FBSixFQUFkO0FBQ0Esb0JBQU1JLFFBQVFDLElBQVIsQ0FBYWIsSUFBYixDQUFOO0FBQ0EsVUFBSWMseUJBQWlCRixRQUFRRyxRQUFSLENBQWlCN0gsUUFBakIsRUFBMkJ1SCxLQUEzQixFQUFrQ0MsTUFBbEMsRUFBMENDLE1BQTFDLENBQWpCLENBQUo7QUFDQSxhQUFPRyxRQUFQO0FBQ0QsS0FMRDtBQUFBLEdBUGE7O0FBY2I7OztBQUdBLEdBQVEsR0FBRWpHLEdBQUksYUFBZCxFQUE2Qm1GLElBQTdCLEVBQW1DUyxLQUFuQyxFQUEwQ0MsU0FBUyxJQUFuRCxFQUF5REMsU0FBUyxJQUFsRTtBQUFBLG9DQUF3RTtBQUN0RSxVQUFJQyxVQUFVLElBQUlKLGNBQUosRUFBZDtBQUNBLG9CQUFNSSxRQUFRQyxJQUFSLENBQWFiLElBQWIsQ0FBTjtBQUNBLG9CQUFNWSxRQUFRSSxVQUFSLENBQW1CUCxLQUFuQixFQUEwQkMsTUFBMUIsRUFBa0NDLE1BQWxDLENBQU47QUFDRCxLQUpEO0FBQUE7O0FBakJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJbEcsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSWlKLFFBQUo7QUFBYXJKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNtSixXQUFTakosQ0FBVCxFQUFXO0FBQUNpSixlQUFTakosQ0FBVDtBQUFXOztBQUF4QixDQUFwRCxFQUE4RSxDQUE5RTtBQUFpRixJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUE5QyxFQUFvRSxDQUFwRTtBQUF1RSxJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBWWplLElBQUk0QyxNQUFNLE1BQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLGNBQWQsRUFBOEJFLE1BQTlCO0FBQUEsb0NBQXNDO0FBQ3BDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxVQUFJUSxTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWI7QUFDQSxVQUFJdUIsaUJBQWlCLElBQUlaLGNBQUosRUFBckI7QUFDQSxvQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOO0FBRUEsVUFBSUUsV0FBVyxJQUFJN0csS0FBSixDQUFVTyxPQUFPdUcsT0FBakIsQ0FBZjtBQUNBLFVBQUlDLE1BQU0sSUFBSUwsUUFBSixDQUFhRyxRQUFiLENBQVY7QUFFQSxvQkFBTXJHLE9BQU9PLEtBQVAsQ0FDSixPQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBRTdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJQyx5QkFBaUJOLGVBQWVPLFFBQWYsQ0FBd0JILEtBQUtJLEdBQTdCLENBQWpCLENBQUo7QUFDQSwwQkFBTUwsSUFBSU0sV0FBSixDQUFnQkwsS0FBS00sSUFBTCxDQUFVQyxXQUFWLENBQXNCQyxnQkFBdEMsRUFBd0ROLFFBQXhELENBQU47QUFDRCxXQUhTO0FBRm1CLFNBQWYsQ0FBWixDQUFKO0FBT0EsZUFBT2pHLEdBQVA7QUFDRCxPQVRELENBRkksQ0FBTjtBQWFBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQXpCRDtBQUFBLEdBTGE7O0FBZ0NiO0FBQ0E7QUFFQSxHQUFRLEdBQUUvRSxHQUFJLFlBQWQsRUFBNEJFLE1BQTVCO0FBQUEsb0NBQW9DO0FBQ2xDLFVBQUlFLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBYjtBQUNBLFVBQUl3QixXQUFXLElBQUk3RyxLQUFKLENBQVVPLE9BQU91RyxPQUFqQixDQUFmO0FBQ0EsVUFBSUMsTUFBTSxJQUFJTCxRQUFKLENBQWFHLFFBQWIsQ0FBVjtBQUVBLFVBQUlELGlCQUFpQixJQUFJWixjQUFKLEVBQXJCO0FBQ0Esb0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTixFQU5rQyxDQVFsQzs7QUFDQSxVQUFJbkcsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLGVBREksRUFFSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFDN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlRLE1BQU1SLFFBQVFyQixVQUFsQjs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJOEIseUJBQWlCZCxlQUFlZSxnQkFBZixDQUFnQ3BILE9BQU9xSCxVQUF2QyxFQUFtRFosSUFBbkQsQ0FBakIsQ0FBSjtBQUVBLGtCQUFJYSwwQkFBa0JkLElBQUllLGFBQUosQ0FBa0JKLFFBQWxCLENBQWxCLENBQUosQ0FIRSxDQUtGOztBQUNBLDRCQUFNRCxJQUFJTSxNQUFKLENBQVc7QUFDZlgscUJBQUtKLEtBQUtJO0FBREssZUFBWCxFQUVIO0FBQ0RZLHNCQUFNO0FBQ0osc0NBQW9CSCxVQUFVNUc7QUFEMUI7QUFETCxlQUZHLENBQU47QUFRQVQscUJBQU95SCxRQUFQO0FBQ0QsYUFmRCxDQWVFLE9BQU92RSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRixXQXJCUztBQURtQixTQUFmLEVBd0JUQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBeEJnQixDQUFaLENBQUo7QUE0QkEsZUFBT3pDLEdBQVA7QUFDRCxPQTlCRCxDQUZJLENBQU47QUFrQ0Esb0JBQU1ULE9BQU9PLEtBQVAsQ0FDSixnQkFESSxFQUVKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUM3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSVEsTUFBTVIsUUFBUXJCLFVBQWxCOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUk4Qix5QkFBaUJkLGVBQWVlLGdCQUFmLENBQWdDcEgsT0FBT3FILFVBQXZDLEVBQW1EWixJQUFuRCxDQUFqQixDQUFKO0FBRUEsNEJBQU1ELElBQUltQixrQkFBSixDQUF1QlIsUUFBdkIsQ0FBTjtBQUNBLDRCQUFNWCxJQUFJb0IsYUFBSixDQUFrQlQsUUFBbEIsQ0FBTjtBQUNBLDRCQUFNWCxJQUFJcUIsZ0JBQUosQ0FBcUJWLFFBQXJCLENBQU47QUFFQSxrQkFBSVIseUJBQWlCTixlQUFlTyxRQUFmLENBQXdCSCxLQUFLSSxHQUE3QixDQUFqQixDQUFKO0FBQ0EsNEJBQU1MLElBQUlNLFdBQUosQ0FBZ0JMLEtBQUtNLElBQUwsQ0FBVUMsV0FBVixDQUFzQkMsZ0JBQXRDLEVBQXdETixRQUF4RCxDQUFOO0FBRUExRyxxQkFBT3lILFFBQVA7QUFDRCxhQVhELENBV0UsT0FBT3ZFLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBakJTO0FBRG1CLFNBQWYsRUFvQlRBLENBQVAsNkJBQWE7QUFDWCxnQkFBTUEsQ0FBTjtBQUNELFNBRkQsQ0FwQmdCLENBQVosQ0FBSjtBQXdCQSxlQUFPekMsR0FBUDtBQUNELE9BMUJELENBRkksQ0FBTjtBQThCQSxhQUFPVCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0E1RUQ7QUFBQTs7QUFuQ2EsQ0FBZixFOzs7Ozs7Ozs7OztBQ2RBLElBQUluRixNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUE5QyxFQUFvRSxDQUFwRTtBQUF1RSxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBTzdSLElBQUk0QyxNQUFNLE1BQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLE9BQWQsRUFBdUJFLE1BQXZCO0FBQUEsb0NBQStCO0FBQzdCO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxVQUFJUSxTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWI7QUFFQSxZQUFNZ0QseUJBQWlCNUgsT0FBT1MsT0FBUCxDQUFlLEVBQWYsRUFBMEJ3QyxDQUFQLDZCQUFhO0FBQ3JELGNBQU1BLENBQU47QUFDRCxPQUZ5QyxDQUFuQixDQUFqQixDQUFOO0FBR0Esb0JBQU1sRCxPQUFPTyxLQUFQLENBQ0osVUFESSxFQUVKLCtCQUFZO0FBQ1YsZUFBT3NILFFBQVA7QUFDRCxPQUZELENBRkksQ0FBTjtBQU1BLGFBQU83SCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0FoQkQ7QUFBQTs7QUFMYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDVEEsSUFBSW5GLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWdKLGFBQUo7QUFBa0JwSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDa0osZ0JBQWNoSixDQUFkLEVBQWdCO0FBQUNnSixvQkFBY2hKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUl1SSxjQUFKO0FBQW1CM0ksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1SSxxQkFBZXZJLENBQWY7QUFBaUI7O0FBQTdCLENBQWpELEVBQWdGLENBQWhGO0FBQW1GLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTZLLE1BQUo7QUFBV2pMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDNkssYUFBTzdLLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSThLLE9BQUo7QUFBWWxMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM4SyxjQUFROUssQ0FBUjtBQUFVOztBQUF0QixDQUFqQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJK0ssS0FBSjtBQUFVbkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFlBQVIsQ0FBYixFQUFtQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQytLLFlBQU0vSyxDQUFOO0FBQVE7O0FBQXBCLENBQW5DLEVBQXlELENBQXpEO0FBQTRELElBQUlnTCxRQUFKO0FBQWFwTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDZ0wsZUFBU2hMLENBQVQ7QUFBVzs7QUFBdkIsQ0FBakMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSWlMLEdBQUo7QUFBUXJMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxLQUFSLENBQWIsRUFBNEI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNpTCxVQUFJakwsQ0FBSjtBQUFNOztBQUFsQixDQUE1QixFQUFnRCxDQUFoRDtBQUFtRCxJQUFJa0wsV0FBSixFQUFnQkMsU0FBaEI7QUFBMEJ2TCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNvTCxjQUFZbEwsQ0FBWixFQUFjO0FBQUNrTCxrQkFBWWxMLENBQVo7QUFBYyxHQUE5Qjs7QUFBK0JtTCxZQUFVbkwsQ0FBVixFQUFZO0FBQUNtTCxnQkFBVW5MLENBQVY7QUFBWTs7QUFBeEQsQ0FBL0IsRUFBeUYsQ0FBekY7QUFlbHZCLE1BQU1vTCxTQUFTLFFBQWY7QUFDQSxNQUFNeEksTUFBTSxPQUFaO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxRQUFkLEVBQXdCRSxNQUF4QjtBQUFBLG9DQUFnQztBQUM5QjtBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSixRQURJLEVBRUosK0JBQVk7QUFDVixjQUFNNkYsaUJBQWlCLElBQUlaLGNBQUosRUFBdkI7QUFDQSxzQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOO0FBQ0EsY0FBTW1DLFVBQVcsR0FBRXZJLE9BQU91SSxPQUFRLFFBQWxDO0FBQ0EsY0FBTUMsSUFBSVIsUUFBUVMsZ0JBQVIsQ0FBMEIsR0FBRUYsT0FBUSxJQUFHdkksT0FBTzBJLGFBQWMsRUFBNUQsQ0FBVjtBQUNBLGNBQU1DLElBQUlYLFFBQVFZLGlCQUFSLENBQTJCLEdBQUVMLE9BQVEsSUFBR3ZJLE9BQU82SSxhQUFjLEVBQTdELENBQVY7QUFDQSxZQUFJQyxJQUFJLENBQVI7QUFDQU4sVUFBRU8sSUFBRixDQUFPZCxNQUFNZSxZQUFOLENBQW1CLE1BQW5CLENBQVAsRUFDR0QsSUFESCxDQUNRZCxNQUFNZ0IsWUFBTixDQUFtQixPQUFuQixDQURSLEVBRUdGLElBRkgsQ0FFUVosSUFBSWUsS0FBSixDQUFVO0FBQUNDLG1CQUFTO0FBQVYsU0FBVixDQUZSLEVBR0dKLElBSEgsQ0FHUVosSUFBSWlCLFNBQUosQ0FDSixDQUFPdkksTUFBUCxFQUFld0ksUUFBZiw4QkFBNEI7QUFDMUIsY0FBSXJLLE1BQU0sSUFBVixDQUQwQixDQUUxQjs7QUFDQSxjQUFJO0FBQ0Y2QixtQkFBTyxNQUFQLGtCQUF1QndGLGVBQWVpRCxhQUFmLENBQTZCekksT0FBTyxNQUFQLENBQTdCLENBQXZCO0FBQ0QsV0FGRCxDQUVFLE9BQU9zQyxDQUFQLEVBQVU7QUFDVm5FLGtCQUFNbUUsQ0FBTjtBQUNEOztBQUNEa0csbUJBQVNySyxHQUFULEVBQWM2QixNQUFkO0FBQ0QsU0FURCxDQURJLENBSFIsRUFlR2tJLElBZkgsQ0FlUVosSUFBSTdJLFNBQUosQ0FBYztBQUFDaUssa0JBQVE7QUFBVCxTQUFkLENBZlIsRUFnQkdSLElBaEJILENBZ0JRZCxNQUFNZSxZQUFOLENBQW1CLE9BQW5CLENBaEJSLEVBaUJHRCxJQWpCSCxDQWlCUWQsTUFBTWdCLFlBQU4sQ0FBbUIsTUFBbkIsQ0FqQlIsRUFrQkdGLElBbEJILENBa0JRSixDQWxCUjtBQW1CRCxPQTFCRCxDQUZJLENBQU47QUE4QkQsS0FsQ0Q7QUFBQSxHQUxhOztBQXlDYjtBQUNBO0FBRUEsR0FBUSxHQUFFN0ksR0FBSSxVQUFkLEVBQTBCRSxNQUExQjtBQUFBLG9DQUFrQztBQUNoQztBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSixRQURJLEVBRUosK0JBQVk7QUFDVjtBQUNBO0FBRUEsY0FBTU4sU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFmO0FBQ0EsY0FBTXVCLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTixFQU5VLENBUVY7O0FBQ0EsY0FBTW9ELFNBQVMsSUFBSXpCLE1BQUosQ0FBVy9ILE9BQU95SixVQUFsQixDQUFmLENBVFUsQ0FXVjs7QUFDQSxZQUFJO0FBQ0Ysd0JBQU16QixRQUFRMEIsS0FBUixDQUFjMUosT0FBT3VJLE9BQXJCLENBQU47QUFDRCxTQUZELENBRUUsT0FBT3BGLENBQVAsRUFBVSxDQUFFLENBZEosQ0FnQlY7OztBQUNBLGNBQU1vRixVQUFXLEdBQUV2SSxPQUFPdUksT0FBUSxPQUFsQztBQUNBLHNCQUFNUCxRQUFRMkIsTUFBUixDQUFlcEIsT0FBZixDQUFOO0FBQ0Esc0JBQU1QLFFBQVEwQixLQUFSLENBQWNuQixPQUFkLENBQU4sRUFuQlUsQ0FxQlY7O0FBQ0EsY0FBTXFCLFlBQWEsR0FBRTVKLE9BQU91SSxPQUFRLFNBQXBDO0FBQ0Esc0JBQU1QLFFBQVEyQixNQUFSLENBQWVDLFNBQWYsQ0FBTjtBQUNBLHNCQUFNNUIsUUFBUTBCLEtBQVIsQ0FBY0UsU0FBZCxDQUFOO0FBRUEsWUFBSUMsS0FBSyxJQUFULENBMUJVLENBMEJJOztBQUNkLFlBQUlyTCxXQUFXLElBQWYsQ0EzQlUsQ0EyQlU7O0FBQ3BCLFlBQUlNLE9BQU8sSUFBWCxDQTVCVSxDQTRCTTtBQUVoQjs7QUFDQSxZQUFJZ0wsU0FBUyxDQUFDLE1BQUQsRUFBUyxNQUFULEVBQWlCLE1BQWpCLEVBQXlCLElBQXpCLEVBQStCLGdCQUEvQixFQUFpRCxNQUFqRCxFQUF5RCxNQUF6RCxFQUFpRSxPQUFqRSxFQUEwRSxJQUExRSxFQUFnRixRQUFoRixFQUEwRixJQUExRixFQUFnRyxNQUFoRyxFQUF3RyxZQUF4RyxFQUFzSCxZQUF0SCxFQUFvSSxNQUFwSSxFQUE0SSxXQUE1SSxFQUF5SixZQUF6SixFQUF1SyxPQUF2SyxFQUFnTCxTQUFoTCxFQUEyTCxPQUEzTCxFQUFvTSxTQUFwTSxFQUErTSxLQUEvTSxFQUFzTixTQUF0TixFQUFpTyxLQUFqTyxFQUF3TyxTQUF4TyxFQUFtUCxLQUFuUCxFQUEwUCxTQUExUCxFQUFxUSxLQUFyUSxFQUE0USxTQUE1USxFQUF1UixLQUF2UixFQUE4UixTQUE5UixFQUF5UyxLQUF6UyxFQUFnVCxTQUFoVCxFQUEyVCxLQUEzVCxFQUFrVSxTQUFsVSxFQUE2VSxLQUE3VSxFQUFvVixTQUFwVixFQUErVixLQUEvVixFQUFzVyxTQUF0VyxFQUFpWCxNQUFqWCxFQUF5WCxVQUF6WCxFQUFxWSxNQUFyWSxFQUE2WSxRQUE3WSxFQUF1WixTQUF2WixFQUFrYSxNQUFsYSxFQUEwYSxNQUExYSxFQUFrYixVQUFsYixFQUE4YixPQUE5YixFQUF1YyxRQUF2YyxFQUFpZCxRQUFqZCxFQUEyZCxXQUEzZCxFQUF3ZSxRQUF4ZSxFQUFrZixLQUFsZixFQUF5ZixjQUF6ZixFQUF5Z0IsU0FBemdCLEVBQW9oQixTQUFwaEIsRUFBK2hCLFlBQS9oQixFQUE2aUIsY0FBN2lCLEVBQTZqQixRQUE3akIsRUFBdWtCLE9BQXZrQixFQUFnbEIsUUFBaGxCLEVBQTBsQixVQUExbEIsRUFBc21CLG1CQUF0bUIsRUFBMm5CLGdCQUEzbkIsRUFBNm9CLFVBQTdvQixFQUF5cEIsbUJBQXpwQixFQUE4cUIsZ0JBQTlxQixFQUFnc0IsVUFBaHNCLEVBQTRzQixtQkFBNXNCLEVBQWl1QixnQkFBanVCLEVBQW12QixVQUFudkIsRUFBK3ZCLG1CQUEvdkIsRUFBb3hCLGdCQUFweEIsRUFBc3lCLFVBQXR5QixFQUFrekIsbUJBQWx6QixFQUF1MEIsZ0JBQXYwQixFQUF5MUIsVUFBejFCLEVBQXEyQixtQkFBcjJCLEVBQTAzQixnQkFBMTNCLEVBQTQ0QixVQUE1NEIsRUFBdzVCLG1CQUF4NUIsRUFBNjZCLGdCQUE3NkIsRUFBKzdCLFVBQS83QixFQUEyOEIsbUJBQTM4QixFQUFnK0IsZ0JBQWgrQixFQUFrL0IsVUFBbC9CLEVBQTgvQixtQkFBOS9CLEVBQW1oQyxnQkFBbmhDLEVBQXFpQyxXQUFyaUMsRUFBa2pDLG9CQUFsakMsRUFBd2tDLGlCQUF4a0MsRUFBMmxDLE1BQTNsQyxFQUFtbUMsV0FBbm1DLEVBQWduQyxTQUFobkMsRUFBMm5DLE9BQTNuQyxFQUFvb0MsZ0JBQXBvQyxDQUFiO0FBQ0EsWUFBSVAsU0FBU08sT0FBT0MsR0FBUCxDQUFXN00sS0FBTSxJQUFHQSxDQUFFLEdBQXRCLEVBQTBCOE0sSUFBMUIsQ0FBK0IsR0FBL0IsSUFBc0MsSUFBbkQsQ0FoQ1UsQ0FrQ1Y7O0FBQ0FSLGVBQU9TLGFBQVAsR0FBOEJDLFdBQVAsNkJBQXVCO0FBQzVDcEwsaUJBQU93SixTQUFTLENBQUMsVUFBVTRCLFdBQVgsRUFBd0JDLEtBQXhCLENBQThCLENBQUMsQ0FBL0IsQ0FBaEI7QUFDQU4sZUFBTSxHQUFFdEIsT0FBUSxJQUFHekosSUFBSyxFQUF4QjtBQUNBTixxQkFBWSxHQUFFcUwsRUFBRyxJQUFHN0osT0FBT29LLFdBQVksRUFBdkM7QUFDQSx3QkFBTXBDLFFBQVEwQixLQUFSLENBQWNHLEVBQWQsQ0FBTixFQUo0QyxDQUs1Qzs7QUFDQSx3QkFBTTdCLFFBQVFxQyxVQUFSLENBQW1CN0wsUUFBbkIsRUFBNkJ5SixNQUFNcUMsTUFBTixDQUFhZixNQUFiLEVBQXFCLFdBQXJCLENBQTdCLENBQU47QUFDRCxTQVBzQixDQUF2QixDQW5DVSxDQTRDVjs7O0FBQ0FDLGVBQU9lLFFBQVAsR0FBeUJDLEdBQVAsNkJBQWU7QUFDL0IsY0FBSUMsUUFBUUQsSUFBSUMsS0FBaEI7QUFDQSxjQUFJaEUsT0FBTytELElBQUkvRCxJQUFmLENBRitCLENBRy9COztBQUNBLGNBQUk1RixTQUFTaUosT0FBT0MsR0FBUCxDQUFXN00sS0FBSztBQUFFLG1CQUFPdU4sTUFBTXZOLENBQU4sSUFBWSxJQUFHdU4sTUFBTXZOLENBQU4sQ0FBUyxHQUF4QixHQUE2QixJQUFwQztBQUEwQyxXQUE1RCxFQUE4RDhNLElBQTlELENBQW1FLEdBQW5FLElBQTBFLElBQXZGO0FBQ0Esd0JBQU1oQyxRQUFRcUMsVUFBUixDQUFtQjdMLFFBQW5CLEVBQTZCeUosTUFBTXFDLE1BQU4sQ0FBYXpKLE1BQWIsRUFBcUIsV0FBckIsQ0FBN0IsQ0FBTixFQUwrQixDQU0vQjs7QUFDQSxlQUFLLElBQUk2SixHQUFULElBQWdCakUsS0FBS2tFLE1BQXJCLEVBQTZCO0FBQzNCLGdCQUFJQyxTQUFVLEdBQUU1SyxPQUFPckIsUUFBUyxJQUFHK0wsR0FBSSxFQUF2QztBQUNBLGdCQUFJRyxTQUFVLEdBQUVoQixFQUFHLElBQUdhLEdBQUksRUFBMUI7O0FBQ0EsZ0JBQUk7QUFDRjtBQUNBLDRCQUFNMUMsUUFBUThDLE1BQVIsQ0FBZUQsTUFBZixDQUFOO0FBQ0QsYUFIRCxDQUdFLE9BQU8xSCxDQUFQLEVBQVU7QUFDViw0QkFBTTZFLFFBQVErQyxRQUFSLENBQWlCSCxNQUFqQixFQUF5QkMsTUFBekIsQ0FBTjtBQUNEO0FBQ0Y7QUFDRixTQWpCaUIsQ0FBbEIsQ0E3Q1UsQ0FnRVY7OztBQUNBckIsZUFBT3dCLFdBQVAsR0FBNEJkLFdBQVAsNkJBQXVCO0FBQzFDLGdCQUFNZSxNQUFNL0MsU0FBUyxLQUFULENBQVo7QUFDQSxnQkFBTWdELFVBQVcsR0FBRXRCLFNBQVUsSUFBRzlLLElBQUssTUFBckM7QUFDQSxnQkFBTXFNLFNBQVNuRCxRQUFRWSxpQkFBUixDQUEwQnNDLE9BQTFCLENBQWY7QUFDQUQsY0FBSWxDLElBQUosQ0FBU29DLE1BQVQ7QUFDQUYsY0FBSUcsU0FBSixDQUFjdkIsRUFBZCxFQUFrQixLQUFsQjtBQUNBb0IsY0FBSUksUUFBSjtBQUNELFNBUG9CLENBQXJCLENBakVVLENBMEVWO0FBQ0E7OztBQUVBLFlBQUkzSyxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBRTdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJQyx5QkFBaUJOLGVBQWVPLFFBQWYsQ0FBd0JILEtBQUtJLEdBQTdCLENBQWpCLENBQUosQ0FEaUMsQ0FFakM7O0FBQ0EsZ0JBQUlGLFlBQVlGLEtBQUtNLElBQUwsQ0FBVTBELEtBQVYsQ0FBZ0JhLFdBQWhDLEVBQTZDO0FBQzNDLGtCQUFJYixzQkFBY3BFLGVBQWVrRixnQkFBZixDQUFnQ3ZMLE9BQU8vQyxPQUF2QyxFQUFnRHdKLElBQWhELENBQWQsQ0FBSjtBQUNBLDRCQUFNK0MsT0FBT2dDLE1BQVAsQ0FBYztBQUFDZix1QkFBT0EsS0FBUjtBQUFlaEUsc0JBQU1BO0FBQXJCLGVBQWQsQ0FBTjtBQUNEO0FBQ0YsV0FQUztBQUZtQixTQUFmLENBQVosQ0FBSjtBQVdBK0MsZUFBT2lDLEtBQVA7QUFFQSxlQUFPL0ssR0FBUDtBQUNELE9BM0ZELENBRkksQ0FBTjtBQStGQSxhQUFPVCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0FwR0Q7QUFBQTs7QUE1Q2EsQ0FBZixFOzs7Ozs7Ozs7OztBQ2xCQS9ILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwrQkFBUixDQUFiO0FBQXVERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0F2REYsT0FBTzRPLE1BQVAsQ0FBYztBQUFDQyxXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJQyxLQUFKO0FBQVU5TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM0TyxRQUFNMU8sQ0FBTixFQUFRO0FBQUMwTyxZQUFNMU8sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUV4QyxNQUFNeU8sVUFBVSxJQUFJQyxNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQStCO0FBQUNDLGdCQUFhO0FBQWQsQ0FBL0IsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNGUGhQLE9BQU80TyxNQUFQLENBQWM7QUFBQzdMLFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUkrTCxLQUFKO0FBQVU5TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM0TyxRQUFNMU8sQ0FBTixFQUFRO0FBQUMwTyxZQUFNMU8sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTZPLElBQUo7QUFBU2pQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM2TyxXQUFLN08sQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJOE8sT0FBSjtBQUFZbFAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzhPLGNBQVE5TyxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEO0FBQStELElBQUkrTyxTQUFKO0FBQWNuUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNpUCxZQUFVL08sQ0FBVixFQUFZO0FBQUMrTyxnQkFBVS9PLENBQVY7QUFBWTs7QUFBMUIsQ0FBakMsRUFBNkQsQ0FBN0Q7QUFhblosTUFBTWdQLFVBQVUsSUFBSU4sTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUFnQztBQUM5Q0MsZ0JBQWM7QUFEZ0MsQ0FBaEMsQ0FBaEI7O0FBSU8sTUFBTWpNLE1BQU4sU0FBcUJvTSxTQUFyQixDQUErQjtBQUVwQ0UsY0FBWUMsUUFBWixFQUFzQjtBQUVwQixRQUFJdEgsVUFBVW9ILFFBQVFHLE9BQVIsQ0FBZ0I7QUFDNUJ4RixXQUFLdUY7QUFEdUIsS0FBaEIsQ0FBZDtBQUlBLFVBQU10SCxPQUFOO0FBRUEsUUFBSUcsT0FBTyxLQUFLcUgsT0FBTCxFQUFYOztBQUVBLFlBQVFySCxLQUFLc0gsSUFBYjtBQUVFLFdBQUssT0FBTDtBQUNFLGFBQUtDLEtBQUwsR0FBYSxJQUFJL00sS0FBSixDQUFVd0YsS0FBSzFFLElBQWYsQ0FBYjs7QUFDQSxhQUFLa00sTUFBTCxHQUFjLENBQVFDLFdBQVk3TCxNQUFELElBQVUsQ0FBRSxDQUEvQixFQUFpQzhMLFVBQVd4SixDQUFELElBQUssQ0FBRSxDQUFsRCw4QkFBd0Q7QUFDcEUsY0FBSXJDLE1BQU8saUJBQWdCbUUsS0FBSzJILEtBQU0sRUFBdEM7QUFDQSwrQkFBYSxLQUFLSixLQUFMLENBQVdLLGNBQVgsQ0FBMEIvTCxHQUExQixFQUErQjRMLFFBQS9CLEVBQXlDQyxPQUF6QyxDQUFiO0FBQ0QsU0FIYSxDQUFkOztBQUlBOztBQUVGO0FBQ0UsY0FBTSxJQUFJRyxLQUFKLENBQVUsdUJBQVYsQ0FBTjtBQVhKO0FBY0Q7QUFFRDs7Ozs7O0FBSU1uTSxTQUFOLENBQWNvTSxZQUFZLEVBQTFCLEVBQThCSixVQUFpQnhKLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQXhDO0FBQUEsb0NBQXlEO0FBRXZELFVBQUkyQixVQUFVLEtBQUtrSSxVQUFMLEVBQWQsQ0FGdUQsQ0FJdkQ7O0FBQ0FsSSxjQUFRbUksT0FBUixDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJYLGNBQU0sTUFEYTtBQUVuQjlMLGVBQU87QUFGWSxPQUFyQjtBQUtBLFVBQUkwTSxRQUFRLEVBQVo7O0FBQ0EsV0FBSyxJQUFJak4sTUFBVCxJQUFtQjRFLFFBQVFtSSxPQUEzQixFQUFvQztBQUNsQ0UsY0FBTWpOLE9BQU9xTSxJQUFiLElBQXFCO0FBQ25COUwsaUJBQU9QLE9BQU9PLEtBREs7QUFFbkIwTSxpQkFBTztBQUZZLFNBQXJCO0FBSUQ7O0FBRUQsb0JBQU0sS0FBS1YsTUFBTCxDQUNHNUwsTUFBUCw2QkFBZ0I7QUFDZCxhQUFLLElBQUlYLE1BQVQsSUFBbUI0RSxRQUFRbUksT0FBM0IsRUFBb0M7QUFDbEMsY0FBSXhNLFFBQVF1TCxRQUFRb0IsUUFBUixDQUFpQmxOLE9BQU9PLEtBQXhCLENBQVo7QUFDQSxjQUFJNE0sT0FBT3RCLEtBQU10TCxLQUFOLENBQVg7O0FBQ0EsY0FBSTRNLEtBQUt4TSxNQUFMLENBQUosRUFBa0I7QUFDaEJzTSxrQkFBTWpOLE9BQU9xTSxJQUFiLEVBQW1CWSxLQUFuQjs7QUFDQSxnQkFBSSxPQUFPSixVQUFVN00sT0FBT3FNLElBQWpCLENBQVAsS0FBa0MsV0FBdEMsRUFBa0Q7QUFDaEQsNEJBQU1RLFVBQVU3TSxPQUFPcU0sSUFBakIsRUFBdUIxTCxNQUF2QixDQUFOO0FBQ0Q7O0FBQ0Q7QUFDRDtBQUNGO0FBQ0YsT0FaRCxDQURJLEVBY0o4TCxPQWRJLENBQU4sRUFsQnVELENBbUN2RDs7QUFDQSxhQUFPUSxLQUFQO0FBRUQsS0F0Q0Q7QUFBQTs7QUFoQ29DLEM7Ozs7Ozs7Ozs7O0FDakJ0Q3JRLE9BQU80TyxNQUFQLENBQWM7QUFBQ08sYUFBVSxNQUFJQSxTQUFmO0FBQXlCdE0sU0FBTSxNQUFJQTtBQUFuQyxDQUFkO0FBQXlELElBQUlpTSxLQUFKO0FBQVU5TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM0TyxRQUFNMU8sQ0FBTixFQUFRO0FBQUMwTyxZQUFNMU8sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFRbk4sTUFBTW9RLFNBQVMsSUFBSTFCLE1BQU1DLFVBQVYsQ0FBcUIsUUFBckIsRUFBK0I7QUFDNUNDLGdCQUFjO0FBRDhCLENBQS9CLENBQWY7O0FBSU8sTUFBTUcsU0FBTixDQUFnQjtBQUlyQkUsY0FBWXJILE9BQVosRUFBcUI7QUFDbkIsU0FBS0EsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBd0gsWUFBVTtBQUNSLFdBQU8sS0FBS3hILE9BQUwsQ0FBYXlJLFlBQXBCO0FBQ0Q7O0FBRURQLGVBQWE7QUFDWCxXQUFPLEtBQUtsSSxPQUFaO0FBQ0Q7O0FBRURuRSxVQUFRMEksV0FBa0J4SSxNQUFQLDZCQUFrQixDQUFFLENBQXBCLENBQW5CLEVBQXlDOEwsVUFBaUJ4SixDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUFuRCxFQUFvRSxDQUFFOztBQXJCakQ7O0FBeUJoQixNQUFNeEQsS0FBTixTQUFvQnNNLFNBQXBCLENBQThCO0FBRW5DRSxjQUFZcUIsT0FBWixFQUFxQjtBQUVuQixRQUFJMUksVUFBVXdJLE9BQU9qQixPQUFQLENBQWU7QUFDM0J4RixXQUFLMkc7QUFEc0IsS0FBZixDQUFkO0FBSUEsVUFBTTFJLE9BQU47QUFFQSxRQUFJRyxPQUFPLEtBQUtxSCxPQUFMLEVBQVg7O0FBRUEsWUFBUXJILEtBQUtzSCxJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UsYUFBS0MsS0FBTCxHQUFhLElBQUkvTSxLQUFKLENBQVV3RixLQUFLMUUsSUFBZixDQUFiOztBQUNBLGFBQUtrTSxNQUFMLEdBQXFCN04sR0FBUCw2QkFBZTtBQUMzQixjQUFJa0MsTUFBTyxpQkFBZ0JtRSxLQUFLMkgsS0FBTSxZQUFXaE8sSUFBSTZPLEdBQUksU0FBUTdPLElBQUkwRSxFQUFHLEdBQXhFO0FBQ0EsK0JBQWEsS0FBS2tKLEtBQUwsQ0FBVy9MLEtBQVgsQ0FBaUJLLEdBQWpCLENBQWI7QUFDRCxTQUhhLENBQWQ7O0FBSUE7O0FBQ0Y7QUFDRSxjQUFNLElBQUlnTSxLQUFKLENBQVUsb0JBQVYsQ0FBTjtBQVRKO0FBWUQ7QUFHRDs7Ozs7O0FBSUFuTSxVQUFRMEksV0FBa0J4SSxNQUFQLDZCQUFrQixDQUFFLENBQXBCLENBQW5CLEVBQXlDOEwsVUFBaUJ4SixDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUFuRCxFQUFvRTtBQUVsRSxRQUFJdUssTUFBTUosT0FBT2hJLElBQVAsQ0FBWTtBQUNwQmtJLGVBQVMsS0FBSzFJLE9BQUwsQ0FBYStCO0FBREYsS0FBWixFQUVQO0FBQ0RpRCxjQUFRO0FBQ05qRCxhQUFLLENBREM7QUFFTnZELFlBQUksQ0FGRTtBQUdObUssYUFBSztBQUhDO0FBRFAsS0FGTyxDQUFWO0FBVUEsV0FBTyxJQUFJRSxPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBRW5CSCxVQUFJSSxPQUFKLENBQ0UsQ0FBT2xQLEdBQVAsRUFBWW1QLEtBQVosOEJBQXNCO0FBQ3BCLFlBQUk7QUFDRixjQUFJbE4sdUJBQWUsS0FBSzRMLE1BQUwsQ0FBWTdOLEdBQVosQ0FBZixDQUFKO0FBQ0Esd0JBQU15SyxTQUFTeEksTUFBVCxDQUFOO0FBQ0QsU0FIRCxDQUdFLE9BQU9zQyxDQUFQLEVBQVU7QUFDVndKLGtCQUFReEosQ0FBUjtBQUNEOztBQUNELFlBQUk0SyxRQUFRLENBQVIsS0FBY0wsSUFBSVAsS0FBSixFQUFsQixFQUErQjtBQUM3QlM7QUFDRDtBQUNGLE9BVkQsQ0FERjtBQWFELEtBaEJJLEVBaUJMSSxLQWpCSyxDQWtCSjdLLENBQUQsSUFBTztBQUNMLFlBQU1BLENBQU47QUFDRCxLQXBCSSxDQUFQO0FBdUJEOztBQWxFa0MsQzs7Ozs7Ozs7Ozs7QUNyQ3JDckcsT0FBTzRPLE1BQVAsQ0FBYztBQUFDck8sV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSXVPLEtBQUo7QUFBVTlPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQzRPLFFBQU0xTyxDQUFOLEVBQVE7QUFBQzBPLFlBQU0xTyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRXhDLE1BQU1HLFVBQVUsSUFBSXVPLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBK0I7QUFBQ0MsZ0JBQWE7QUFBZCxDQUEvQixDQUFoQixDOzs7Ozs7Ozs7OztBQ0ZQaFAsT0FBTzRPLE1BQVAsQ0FBYztBQUFDdkYsWUFBUyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSTFHLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBakQsRUFBdUUsQ0FBdkU7O0FBRTFDLE1BQU1pSixRQUFOLENBQWU7QUFDcEJnRyxjQUFhSyxRQUFRLElBQUkvTSxLQUFKLEVBQXJCLEVBQWtDO0FBQ2hDLFNBQUt3TyxNQUFMLEdBQWN6QixLQUFkO0FBQ0Q7O0FBRUsxRixhQUFOLENBQW1Cb0gsY0FBbkIsRUFBbUN2SCxXQUFXLENBQTlDO0FBQUEsb0NBQWlEO0FBQy9DLG9CQUFNLEtBQUtzSCxNQUFMLENBQVlFLFdBQVosQ0FDSixtQkFESSxFQUVILHNCQUFxQkQsY0FBZSxFQUZqQyxFQUdKLEVBSEksRUFHQTtBQUNGRSxlQUFPekgsUUFETDtBQUVGMEgseUJBQWlCLENBRmY7QUFHRnJMLHFCQUFhO0FBSFgsT0FIQSxDQUFOO0FBVUEsb0JBQU0sS0FBS2lMLE1BQUwsQ0FBWUUsV0FBWixDQUNKLG1CQURJLEVBRUgsc0JBQXFCRCxjQUFlLEVBRmpDLEVBR0osRUFISSxFQUdBO0FBQ0ZFLGVBQU96SCxRQURMO0FBRUYzRCxxQkFBYTtBQUZYLE9BSEEsQ0FBTjtBQVFELEtBbkJEO0FBQUE7O0FBcUJNNkUsa0JBQU4sQ0FBd0J2SixJQUF4QjtBQUFBLG9DQUE4QjtBQUM1QixVQUFJZ1EsWUFBWWhRLEtBQUsrSSxVQUFyQjtBQUVBLFVBQUkzRyxNQUFNLEVBQVYsQ0FINEIsQ0FLNUI7O0FBQ0EsVUFBSTZOLFNBQWdCek8sR0FBUCw2QkFBZTtBQUMxQixZQUFJZ0IsTUFBTzs7MkJBRVV4QyxLQUFLa1EsVUFBVyxjQUFhMU8sR0FBSTtPQUZ0RDtBQUlBWSxZQUFJd00sSUFBSixlQUFlLEtBQUtlLE1BQUwsQ0FBWXhOLEtBQVosQ0FBa0JLLEdBQWxCLENBQWY7QUFDRCxPQU5ZLENBQWIsQ0FONEIsQ0FjNUI7OztBQUNBLFVBQUkyTixRQUFlM08sR0FBUCw2QkFBZTtBQUN6QjtBQUNBLFlBQUlnQixNQUFPOzsyQkFFVXhDLEtBQUtrUSxVQUFXLGNBQWExTyxHQUFJO09BRnREO0FBSUEsWUFBSTRPLHlCQUFpQixLQUFLVCxNQUFMLENBQVl4TixLQUFaLENBQWtCSyxHQUFsQixDQUFqQixDQUFKO0FBQ0EsWUFBSTROLFNBQVMsQ0FBVCxFQUFZLFVBQVosQ0FBSixFQUE2QjtBQUU3QmhPLFlBQUl3TSxJQUFKLGVBQ1EsS0FBS2UsTUFBTCxDQUFZL0ssV0FBWixDQUNKLGlCQURJLEVBRUosRUFGSSxFQUdKO0FBQ0VzTCxzQkFBWWxRLEtBQUtrUSxVQURuQjtBQUVFMU8sZUFBS0EsR0FGUDtBQUdFdUgsc0JBQVlpSCxTQUhkO0FBSUV2TCx1QkFBYTtBQUpmLFNBSEksQ0FEUjtBQVdELE9BcEJXLENBQVo7O0FBc0JBLFdBQUssSUFBSTRMLE1BQVQsSUFBbUJyUSxLQUFLc1EsSUFBeEIsRUFBOEI7QUFDNUIsZ0JBQVFELE9BQU9FLEdBQWY7QUFDRSxlQUFLLElBQUw7QUFDRSwwQkFBTUosTUFBTUUsT0FBTzdPLEdBQWIsQ0FBTjtBQUNBOztBQUNGLGVBQUssS0FBTDtBQUNFLDBCQUFNeU8sT0FBT0ksT0FBTzdPLEdBQWQsQ0FBTjtBQUNBO0FBTko7QUFRRDs7QUFFRCxhQUFPO0FBQ0xZLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBbkREO0FBQUE7O0FBcURNaUgsb0JBQU4sQ0FBMEJySixJQUExQjtBQUFBLG9DQUFnQztBQUM5QixVQUFJd1EsWUFBWXhRLEtBQUtrUSxVQUFyQjtBQUNBLFVBQUk3RCxTQUFTck0sS0FBS3FNLE1BQWxCO0FBQ0EsVUFBSTJELFlBQVloUSxLQUFLK0ksVUFBckI7QUFFQSxVQUFJM0csTUFBTSxFQUFWLENBTDhCLENBTzlCOztBQUNBLFVBQUlJLE1BQU8sb0RBQW1EZ08sU0FBVSxFQUF4RTtBQUNBcE8sVUFBSXdNLElBQUosZUFBZSxLQUFLZSxNQUFMLENBQVl4TixLQUFaLENBQWtCSyxHQUFsQixDQUFmLEdBVDhCLENBVzlCOztBQUNBLFdBQUssSUFBSWdJLElBQUksQ0FBYixFQUFnQkEsSUFBSTZCLE9BQU9vRSxNQUEzQixFQUFtQ2pHLEdBQW5DLEVBQXdDO0FBQ3RDLHNCQUFNLEtBQUttRixNQUFMLENBQVkvSyxXQUFaLENBQ0osbUJBREksRUFDaUI7QUFDbkJzTCxzQkFBWU0sU0FETztBQUVuQnpILHNCQUFZaUgsU0FGTztBQUduQlUscUJBQVdyRSxPQUFPN0IsQ0FBUCxDQUhRO0FBSW5CbUcsZ0JBQU1uRyxJQUFJO0FBSlMsU0FEakIsRUFNRDtBQUNEL0YsdUJBQWE7QUFEWixTQU5DLENBQU47QUFVRDs7QUFFRCxhQUFPO0FBQ0xyQyxhQUFLQTtBQURBLE9BQVA7QUFHRCxLQTVCRDtBQUFBOztBQThCTWtILGVBQU4sQ0FBcUJ0SixJQUFyQjtBQUFBLG9DQUEyQjtBQUN6QixVQUFJNFEsYUFBYSxFQUFqQjtBQUNBLFVBQUlDLE9BQU8sRUFBWCxDQUZ5QixDQUl6Qjs7QUFFQUEsYUFBTyxDQUNMLFFBREssRUFFTCxNQUZLLEVBR0wsTUFISyxFQUlMLGtCQUpLLEVBS0wsb0JBTEssRUFNTCxhQU5LLEVBT0wsV0FQSyxDQUFQOztBQVNBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVELG9CQUFNLEtBQUtuQixNQUFMLENBQVlFLFdBQVosQ0FDSixhQURJLEVBRUgsZ0JBQWU3UCxLQUFLa1EsVUFBVyxFQUY1QixFQUdKVSxVQUhJLEVBR1E7QUFDVmxNLHFCQUFhO0FBREgsT0FIUixDQUFOLEVBbkJ5QixDQTJCekI7O0FBRUFrTSxtQkFBYSxFQUFiO0FBQ0FDLGFBQU8sQ0FDTCxrQkFESyxFQUVMLGNBRkssRUFHTCxZQUhLLEVBSUwsU0FKSyxFQUtMLFNBTEssRUFNTCxjQU5LLENBQVA7O0FBUUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSTdRLEtBQUs4USxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQjlRLEtBQUs4USxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQsVUFBSTFPLG9CQUFZLEtBQUt1TixNQUFMLENBQVlFLFdBQVosQ0FDZCxtQkFEYyxFQUViLGdCQUFlN1AsS0FBS2tRLFVBQVcsRUFGbEIsRUFHZFUsVUFIYyxFQUdGO0FBQ1ZsTSxxQkFBYTtBQURILE9BSEUsQ0FBWixDQUFKO0FBUUEsYUFBTztBQUNMdEMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0FyREQ7QUFBQTs7QUF1RE02RyxlQUFOLENBQXFCakosSUFBckI7QUFBQSxvQ0FBMkI7QUFDekIsVUFBSWdRLFlBQVloUSxLQUFLK0ksVUFBckI7QUFFQSxVQUFJM0csTUFBTSxFQUFWO0FBRUEsVUFBSXdPLGFBQWEsRUFBakI7QUFDQSxVQUFJQyxPQUFPLEVBQVg7QUFFQUEsYUFBTyxDQUNMLE1BREssRUFFTCxvQkFGSyxDQUFQLENBUnlCLENBWXpCO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVEMU8sVUFBSThOLFVBQUosaUJBQXVCLEtBQUtQLE1BQUwsQ0FBWS9LLFdBQVosQ0FDckIsYUFEcUIsRUFFckJnTSxVQUZxQixFQUVUO0FBQ1Y3SCxvQkFBWWlILFNBREY7QUFFVnROLGdCQUFRLENBRkU7QUFHVjhCLGNBQU0sTUFISTtBQUlWdU0sMEJBQWtCLE1BSlI7QUFLVkMscUJBQWEsTUFMSDtBQU1WQyxtQkFBVyxNQU5EO0FBT1Z4TSxxQkFBYSxPQVBIO0FBUVZDLHFCQUFhO0FBUkgsT0FGUyxDQUF2QjtBQWNBa00sbUJBQWEsRUFBYjtBQUNBQyxhQUFPLENBQ0wsY0FESyxFQUVMLGlCQUZLLEVBR0wsU0FISyxFQUlMLFNBSkssRUFLTCxjQUxLLENBQVAsQ0FwQ3lCLENBMkN6QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVEMU8sVUFBSXVHLGdCQUFKLGlCQUE2QixLQUFLZ0gsTUFBTCxDQUFZL0ssV0FBWixDQUMzQixtQkFEMkIsRUFFM0JnTSxVQUYyQixFQUVmO0FBQ1Y3SCxvQkFBWWlILFNBREY7QUFFVkUsb0JBQVk5TixJQUFJOE4sVUFGTjtBQUdWSixlQUFPLENBSEc7QUFJVkMseUJBQWlCLENBSlA7QUFLVm1CLDRCQUFvQixNQUxWO0FBTVZDLDRCQUFvQixNQU5WO0FBT1ZDLDBCQUFrQixNQVBSO0FBUVZDLG9CQUFZLE1BUkY7QUFTVjVNLHFCQUFhLE9BVEg7QUFVVkMscUJBQWE7QUFWSCxPQUZlLENBQTdCOztBQWdCQSxXQUFLLElBQUlvTSxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSTdRLEtBQUs4USxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQjlRLEtBQUs4USxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQxTyxVQUFJa1AsZ0JBQUosaUJBQTZCLEtBQUszQixNQUFMLENBQVkvSyxXQUFaLENBQzNCLG1CQUQyQixFQUNOLEVBRE0sRUFDRjtBQUN2QitELDBCQUFrQnZHLElBQUl1RyxnQkFEQztBQUV2Qkksb0JBQVlpSCxTQUZXO0FBR3ZCRixlQUFPLENBSGdCO0FBSXZCckwscUJBQWEsT0FKVTtBQUt2QkMscUJBQWE7QUFMVSxPQURFLENBQTdCLEVBekV5QixDQW1GekI7O0FBQ0EsYUFBTztBQUNMdEMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0F2RkQ7QUFBQTs7QUFwS29CLEM7Ozs7Ozs7Ozs7O0FDRnRCNUQsT0FBTzRPLE1BQVAsQ0FBYztBQUFDbUUsbUJBQWdCLE1BQUlBLGVBQXJCO0FBQXFDQyxZQUFTLE1BQUlBLFFBQWxEO0FBQTJEQyxpQkFBYyxNQUFJQSxhQUE3RTtBQUEyRjdKLGlCQUFjLE1BQUlBO0FBQTdHLENBQWQ7QUFBMkksSUFBSTBGLEtBQUo7QUFBVTlPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQzRPLFFBQU0xTyxDQUFOLEVBQVE7QUFBQzBPLFlBQU0xTyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJOFMsV0FBSjtBQUFnQmxULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ2dULGNBQVk5UyxDQUFaLEVBQWM7QUFBQzhTLGtCQUFZOVMsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTtBQUFtRSxJQUFJNk8sSUFBSjtBQUFTalAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE1BQVIsQ0FBYixFQUE2QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZPLFdBQUs3TyxDQUFMO0FBQU87O0FBQW5CLENBQTdCLEVBQWtELENBQWxEO0FBQXFELElBQUk4TyxPQUFKO0FBQVlsUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDOE8sY0FBUTlPLENBQVI7QUFBVTs7QUFBdEIsQ0FBcEMsRUFBNEQsQ0FBNUQ7O0FBUzFmLE1BQU0yUyxlQUFOLENBQXNCO0FBQzNCMUQsY0FBYWxILElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFFBQUltTCxRQUFKOztBQUNBLFlBQVFoTCxLQUFLc0gsSUFBYjtBQUNFLFdBQUssT0FBTDtBQUNFMEQsbUJBQVcsSUFBSUYsYUFBSixDQUFrQjlLLElBQWxCLEVBQXdCSCxPQUF4QixDQUFYO0FBRko7O0FBS0EsV0FBT21MLFFBQVA7QUFDRDs7QUFUMEI7O0FBWXRCLE1BQU1ILFFBQU4sQ0FBZTtBQUNwQjNELGNBQWFsSCxJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixTQUFLRyxJQUFMLEdBQVlBLElBQVo7QUFDQSxTQUFLSCxPQUFMLEdBQWVBLE9BQWY7QUFDRDs7QUFFRCxTQUFPb0wsT0FBUCxDQUFnQmpMLElBQWhCLEVBQXNCSCxPQUF0QixFQUErQjtBQUM3QixZQUFRRyxLQUFLc0gsSUFBYjtBQUNFLFdBQUssT0FBTDtBQUNFLGVBQU8sSUFBSXdELGFBQUosQ0FBa0I5SyxJQUFsQixFQUF3QkgsT0FBeEIsQ0FBUDs7QUFDRjtBQUNFLGNBQU0sSUFBSWdJLEtBQUosQ0FBVSxtQkFBVixDQUFOO0FBSko7QUFNRDs7QUFFRHFELGFBQVk7QUFDVixXQUFPLEtBQUtsTCxJQUFaO0FBQ0Q7O0FBRURtTCxhQUFZO0FBQ1YsV0FBTyxLQUFLbkwsSUFBTCxDQUFVMUUsSUFBakI7QUFDRDs7QUFFRDhQLGdCQUFlO0FBQ2IsV0FBTyxLQUFLdkwsT0FBWjtBQUNEOztBQUVEd0wscUJBQ0VDLEtBQUssQ0FBTzdELFdBQVc3TCxVQUFVLENBQUUsQ0FBOUIsRUFBZ0M4TCxVQUFVeEosS0FBSyxDQUFFLENBQWpELDhCQUFzRCxDQUFFLENBQXhELENBRFAsRUFFRTtBQUNBLFNBQUtzSixNQUFMLEdBQWM4RCxFQUFkO0FBQ0Q7QUFFRDs7Ozs7Ozs7Ozs7QUFTTTVQLFNBQU4sQ0FBZTZQLFlBQVksRUFBM0I7QUFBQSxvQ0FBK0I7QUFDN0IsVUFBSTFMLFVBQVUsS0FBS3VMLFdBQUwsRUFBZCxDQUQ2QixDQUc3Qjs7QUFDQXZMLGNBQVFtSSxPQUFSLENBQWdCQyxJQUFoQixDQUFxQjtBQUNuQnBPLGNBQU0sTUFEYTtBQUVuQjJCLGVBQU87QUFGWSxPQUFyQjtBQUtBLFVBQUlnUSxVQUFVLEVBQWQ7O0FBQ0EsV0FBSyxJQUFJQyxDQUFULElBQWM1TCxRQUFRbUksT0FBdEIsRUFBK0IsQ0FDOUI7O0FBRUQsVUFBSUEsVUFBVSxFQUFkOztBQUVBLFdBQUssSUFBSXlELENBQVQsSUFBYzVMLFFBQVFtSSxPQUF0QixFQUErQjtBQUM3QndELGdCQUFRQyxFQUFFNVIsSUFBVixJQUFrQjtBQUNoQjJCLGlCQUFPaVEsRUFBRWpRLEtBRE87QUFFaEJrUSxpQkFBTyxPQUFPRCxFQUFFQyxLQUFULEtBQW1CLFdBQW5CLEdBQWlDRCxFQUFFQyxLQUFuQyxHQUEyQyxDQUZsQztBQUdoQnhELGlCQUFPO0FBSFMsU0FBbEI7QUFLQUYsZ0JBQVFDLElBQVIsQ0FDRTtBQUNFcE8sZ0JBQU00UixFQUFFNVIsSUFEVjtBQUVFdU8sZ0JBQU10QixLQUFLQyxRQUFRb0IsUUFBUixDQUFpQnNELEVBQUVqUSxLQUFuQixDQUFMO0FBRlIsU0FERjtBQU1EOztBQUVELG9CQUFNLEtBQUtnTSxNQUFMLENBQ0osQ0FBTzVMLE1BQVAsRUFBZTZGLE9BQWYsOEJBQTJCO0FBQ3pCLGFBQUssSUFBSWdLLENBQVQsSUFBY3pELE9BQWQsRUFBdUI7QUFDckI7QUFDQSxjQUFJMkQsSUFBSUgsUUFBUUMsRUFBRTVSLElBQVYsQ0FBUjs7QUFDQSxjQUFJOFIsRUFBRUQsS0FBTixFQUFhO0FBQ1gsZ0JBQUlDLEVBQUV6RCxLQUFGLElBQVd5RCxFQUFFRCxLQUFqQixFQUF3QjtBQUN0QjtBQUNEO0FBQ0Y7O0FBRUQsY0FBSUQsRUFBRXJELElBQUYsQ0FBT3hNLE1BQVAsQ0FBSixFQUFvQjtBQUNsQjtBQUNBK1AsY0FBRXpELEtBQUYsR0FGa0IsQ0FJbEI7O0FBQ0EsZ0JBQUksT0FBT3FELFVBQVVFLEVBQUU1UixJQUFaLENBQVAsS0FBNkIsV0FBakMsRUFBOEM7QUFDNUMsNEJBQU0wUixVQUFVRSxFQUFFNVIsSUFBWixFQUFrQitCLE1BQWxCLEVBQTBCNkYsT0FBMUIsQ0FBTjtBQUNEOztBQUNEO0FBQ0Q7QUFDRjtBQUNGLE9BckJELENBREksQ0FBTixFQTdCNkIsQ0FxRDdCOztBQUNBLGFBQU8rSixPQUFQO0FBQ0QsS0F2REQ7QUFBQTs7QUExQ29COztBQW9HZixNQUFNVixhQUFOLFNBQTRCRCxRQUE1QixDQUFxQztBQUMxQzNELGNBQWFsSCxJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixVQUFNRyxJQUFOLEVBQVlILE9BQVo7QUFFQSxRQUFJdkUsT0FBTyxLQUFLNlAsUUFBTCxFQUFYO0FBRUEsU0FBSzVELEtBQUwsR0FBYSxJQUFJL00sS0FBSixDQUFVYyxJQUFWLENBQWI7QUFDQSxTQUFLK1Asa0JBQUwsQ0FBd0IsQ0FBTzVELFFBQVAsRUFBaUJDLE9BQWpCLDhCQUE2QjtBQUNuRCxVQUFJN0wsTUFBTyxpQkFBZ0JtRSxLQUFLMkgsS0FBTSxFQUF0QztBQUNBLFVBQUlsTSxvQkFBWSxLQUFLOEwsS0FBTCxDQUFXSyxjQUFYLENBQTBCL0wsR0FBMUIsRUFBK0I0TCxRQUEvQixFQUEwQ3ZKLENBQUQsSUFBTztBQUFFLGNBQU1BLENBQU47QUFBUyxPQUEzRCxDQUFaLENBQUo7QUFDQSxhQUFPekMsR0FBUDtBQUNELEtBSnVCLENBQXhCO0FBS0Q7O0FBWnlDOztBQW1CckMsTUFBTXdGLGFBQU4sU0FBNEI0SixRQUE1QixDQUFxQztBQUMxQzNELGNBQWFsSCxJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixVQUFNRyxJQUFOLEVBQVlILE9BQVosRUFEMEIsQ0FHMUI7O0FBQ0EsU0FBS3dMLGtCQUFMLENBQXdCLENBQU81RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQsVUFBSWtFLE1BQUo7QUFDQUEsNkJBQWViLFlBQVljLE9BQVosQ0FBb0I3TCxLQUFLOEwsR0FBekIsQ0FBZixFQUZtRCxDQUluRDs7QUFDQSxVQUFJaE0sS0FBSzhMLE9BQU85TCxFQUFQLENBQVVFLEtBQUsrTCxRQUFmLENBQVQ7QUFDQSxVQUFJM0wsYUFBYU4sR0FBR00sVUFBSCxDQUFjSixLQUFLSSxVQUFuQixDQUFqQjtBQUVBLFVBQUlxQixVQUFVO0FBQ1ptSyxnQkFBUUEsTUFESTtBQUVaeEwsb0JBQVlBLFVBRkE7QUFHWjJMLGtCQUFVak07QUFIRSxPQUFkO0FBTUEsVUFBSTJJLE1BQU1ySSxXQUFXQyxJQUFYLEVBQVYsQ0FkbUQsQ0FnQm5EOztBQUNBb0ksVUFBSXVELGFBQUosQ0FBa0IsaUJBQWxCLEVBQXFDLElBQXJDLEVBakJtRCxDQW1CbkQ7O0FBQ0EsVUFBSTtBQUNGLDZCQUFhdkQsSUFBSXdELE9BQUosRUFBYixHQUE0QjtBQUMxQixjQUFJdFMsb0JBQVk4TyxJQUFJeUQsSUFBSixFQUFaLENBQUo7QUFDQSx3QkFBTXpFLFNBQVM5TixHQUFULEVBQWM4SCxPQUFkLENBQU47QUFDRDs7QUFBQTtBQUNGLE9BTEQsU0FLVTtBQUNSO0FBQ0Esc0JBQU1nSCxJQUFJakMsS0FBSixFQUFOO0FBQ0Q7QUFDRixLQTdCdUIsQ0FBeEI7QUE4QkQ7O0FBbkN5QyxDOzs7Ozs7Ozs7OztBQzVJNUMzTyxPQUFPNE8sTUFBUCxDQUFjO0FBQUN6TyxXQUFRLE1BQUl3STtBQUFiLENBQWQ7QUFBNEMsSUFBSVQsZUFBSjtBQUFvQmxJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2dJLGtCQUFnQjlILENBQWhCLEVBQWtCO0FBQUM4SCxzQkFBZ0I5SCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBdEMsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSUcsT0FBSjtBQUFZUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDSyxVQUFRSCxDQUFSLEVBQVU7QUFBQ0csY0FBUUgsQ0FBUjtBQUFVOztBQUF0QixDQUE5QyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJa1UsUUFBSjtBQUFhdFUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE1BQVIsQ0FBYixFQUE2QjtBQUFDb1UsV0FBU2xVLENBQVQsRUFBVztBQUFDa1UsZUFBU2xVLENBQVQ7QUFBVzs7QUFBeEIsQ0FBN0IsRUFBdUQsQ0FBdkQ7O0FBVXBPLE1BQU11SSxjQUFOLENBQXFCO0FBQzVCSyxNQUFOLENBQVliLElBQVo7QUFBQSxvQ0FBa0I7QUFDaEIsV0FBS29NLEtBQUwsaUJBQW1Cck0sZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEIsT0FBMUIsQ0FBbkI7QUFDQSxXQUFLcU0sUUFBTCxpQkFBc0J0TSxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQixVQUExQixDQUF0QjtBQUNELEtBSEQ7QUFBQTs7QUFLTTJCLFVBQU4sQ0FBZ0IySyxNQUFoQjtBQUFBLG9DQUF3QjtBQUN0QixVQUFJQyx3QkFBZ0IsS0FBS0gsS0FBTCxDQUFXaEYsT0FBWCxDQUFtQjtBQUNyQ3hGLGFBQUswSztBQURnQyxPQUFuQixFQUVqQjtBQUNEck0sb0JBQVk7QUFDVixxQkFBVztBQUREO0FBRFgsT0FGaUIsQ0FBaEIsQ0FBSjtBQU9BLFVBQUl1TSxjQUFjRCxRQUFRRSxPQUExQixDQVJzQixDQVV0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQUlDLGFBQWEsRUFBakI7O0FBRUEsV0FBSyxJQUFJQyxVQUFULElBQXVCSCxXQUF2QixFQUFvQztBQUNsQyxZQUFJSSxjQUFjLENBQWxCOztBQUVBLGFBQUssSUFBSS9DLFNBQVQsSUFBc0I4QyxVQUF0QixFQUFrQztBQUNoQyxjQUFJSix3QkFBZ0IsS0FBS0YsUUFBTCxDQUFjakYsT0FBZCxDQUFzQjtBQUN4Q3hGLGlCQUFLaUk7QUFEbUMsV0FBdEIsRUFFakI7QUFDRDVKLHdCQUFZO0FBQ1YsdUJBQVM7QUFEQztBQURYLFdBRmlCLENBQWhCLENBQUo7QUFPQSxjQUFJNE0sYUFBYU4sUUFBUXBELEtBQXpCLENBUmdDLENBVWhDOztBQUNBLGVBQUssSUFBSUEsS0FBVCxJQUFrQjBELFVBQWxCLEVBQThCO0FBQzVCRCwyQkFBZXpELE1BQU16SCxRQUFyQjtBQUNEO0FBQ0Y7O0FBRURnTCxtQkFBV3pFLElBQVgsQ0FBZ0IyRSxXQUFoQjtBQUNELE9BdENxQixDQXdDdEI7OztBQUNBLFVBQUlsTCxXQUFXb0wsS0FBS0MsR0FBTCxDQUFTQyxLQUFULENBQWUsSUFBZixFQUFxQk4sVUFBckIsQ0FBZjtBQUVBLGFBQU9oTCxRQUFQO0FBQ0QsS0E1Q0Q7QUFBQTtBQThDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQk1YLFVBQU4sQ0FBZ0I3SCxRQUFoQixFQUEwQnVILEtBQTFCLEVBQWlDQyxTQUFTLElBQTFDLEVBQWdEQyxTQUFTLElBQXpEO0FBQUEsb0NBQStEO0FBQzdEO0FBQ0EsVUFBSStFLFNBQVN0TixRQUFRaUksSUFBUixDQUFhO0FBQ3hCbkgsa0JBQVVBO0FBRGMsT0FBYixFQUVWK1QsS0FGVSxHQUVGbkksR0FGRSxDQUVHN00sQ0FBRCxJQUFPQSxFQUFFNkIsZ0JBRlgsQ0FBYixDQUY2RCxDQU03RDs7QUFDQSxVQUFJbUIsU0FBUyxFQUFiO0FBQ0FBLGFBQU93RixLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQVl6RixPQUFPaVMsWUFBUCxHQUFzQnhNLE1BQXRCO0FBQ1osVUFBSUMsTUFBSixFQUFZMUYsT0FBT2tTLFlBQVAsR0FBc0J4TSxNQUF0QjtBQUVaLFVBQUlsRixvQkFBWSxLQUFLMlEsS0FBTCxDQUFXZ0IsVUFBWCxDQUNkblMsTUFEYyxFQUNOO0FBQ05vUyxlQUFPO0FBQ0wzSCxrQkFBUTtBQUNONEgsbUJBQU81SDtBQUREO0FBREg7QUFERCxPQURNLENBQVosQ0FBSixDQVo2RCxDQXNCN0Q7O0FBQ0EsYUFBT0EsTUFBUDtBQUNELEtBeEJEO0FBQUE7QUEwQkE7Ozs7Ozs7Ozs7QUFRTTFFLFlBQU4sQ0FBa0JQLEtBQWxCLEVBQXlCQyxTQUFTLElBQWxDLEVBQXdDQyxTQUFTLElBQWpEO0FBQUEsb0NBQXVEO0FBQ3JEO0FBQ0EsVUFBSTFGLFNBQVMsRUFBYjtBQUNBQSxhQUFPd0YsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFZekYsT0FBT2lTLFlBQVAsR0FBc0J4TSxNQUF0QjtBQUNaLFVBQUlDLE1BQUosRUFBWTFGLE9BQU9rUyxZQUFQLEdBQXNCeE0sTUFBdEI7QUFFWixVQUFJbEYsb0JBQVksS0FBSzJRLEtBQUwsQ0FBV2dCLFVBQVgsQ0FDZG5TLE1BRGMsRUFDTjtBQUNOdUgsY0FBTTtBQUNKa0Qsa0JBQVE7QUFESjtBQURBLE9BRE0sQ0FBWixDQUFKO0FBT0QsS0FkRDtBQUFBO0FBZ0JBOzs7Ozs7Ozs7Ozs7Ozs7O0FBY002SCxjQUFOLENBQW9CL0wsSUFBcEIsRUFBMEIrSyxPQUExQjtBQUFBLG9DQUFtQztBQUNqQzs7Ozs7Ozs7QUFRQSxVQUFJM0MsTUFBTSxDQUFDO0FBQ1Q0RCxlQUFPLE1BREU7QUFFVEMsaUJBQVNqTSxLQUFLa00sUUFGTDtBQUdUbkIsaUJBQVM7QUFDUG9CLGlCQUFPO0FBREEsU0FIQTtBQU1UblMsZUFBTztBQUNMMFIsd0JBQWMxTCxLQUFLMEwsWUFEZDtBQUVMQyx3QkFBYzNMLEtBQUsyTDtBQUZkO0FBTkUsT0FBRCxFQVdWO0FBQ0VLLGVBQU9oTSxLQUFLb00sV0FEZDtBQUVFSCxpQkFBU2pNLEtBQUswTCxZQUZoQjtBQUdFWCxpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUVuUyxlQUFPO0FBQ0xrUyxvQkFBVWxNLEtBQUtrTSxRQURWO0FBRUxQLHdCQUFjM0wsS0FBSzJMO0FBRmQ7QUFOVCxPQVhVLEVBc0JWO0FBQ0VLLGVBQU9oTSxLQUFLcU0sV0FEZDtBQUVFSixpQkFBU2pNLEtBQUsyTCxZQUZoQjtBQUdFWixpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUVuUyxlQUFPO0FBQ0xrUyxvQkFBVWxNLEtBQUtrTSxRQURWO0FBRUxSLHdCQUFjMUwsS0FBSzBMO0FBRmQ7QUFOVCxPQXRCVSxDQUFWO0FBbUNBLFVBQUlZLFFBQVEsRUFBWjs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY25FLEdBQWQsRUFBbUI7QUFDakJrRSxjQUFNN0YsSUFBTixDQUFXO0FBQ1QrRixvQ0FBa0IsS0FBSzVCLEtBQUwsQ0FBVzdMLFNBQVgsQ0FDaEIsQ0FBQztBQUNDME4sb0JBQVFDLE9BQU9DLE1BQVAsQ0FBY0osRUFBRXZTLEtBQWhCLEVBQXVCO0FBQzdCaUYscUJBQU9lLEtBQUtmO0FBRGlCLGFBQXZCO0FBRFQsV0FBRCxFQUtBO0FBQ0UyTixzQkFBVUYsT0FBT0MsTUFBUCxDQUFjSixFQUFFeEIsT0FBaEIsRUFBeUJBLE9BQXpCO0FBRFosV0FMQSxFQVFBO0FBQ0U4QixtQkFBTztBQUNMek0sbUJBQUs7QUFEQTtBQURULFdBUkEsQ0FEZ0IsRUFlaEJ0QixPQWZnQixFQUFsQixDQURTO0FBaUJUZ08saUJBQU9QO0FBakJFLFNBQVg7QUFtQkQ7O0FBRUQsYUFBT0QsS0FBUDtBQUNELEtBckVEO0FBQUEsR0F6SWtDLENBZ05sQztBQUNBOzs7QUFDTXpKLGVBQU4sQ0FBcUJrQixHQUFyQjtBQUFBLG9DQUEwQjtBQUN4QixVQUFJL0QsSUFBSixDQUR3QixDQUV4Qjs7QUFDQSxVQUFJLE9BQU8rRCxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0IsWUFBSWdKLE1BQU0sSUFBSUMsTUFBSixDQUFZLEdBQUVqSixHQUFJLEdBQWxCLENBQVY7QUFDQSxZQUFJa0QsTUFBTSxLQUFLMkQsS0FBTCxDQUFXL0wsSUFBWCxDQUFnQixFQUFoQixFQUFvQjtBQUM1Qkosc0JBQVk7QUFDVlEsbUJBQU8sQ0FERztBQUVWeU0sMEJBQWMsQ0FGSjtBQUdWQywwQkFBYztBQUhKO0FBRGdCLFNBQXBCLENBQVY7O0FBUUEsZUFBTyxDQUFQLEVBQVU7QUFDUixjQUFJO0FBQ0YzTCxpQ0FBYWlILElBQUl5RCxJQUFKLEVBQWI7QUFDQSxnQkFBSXVDLHNCQUFjak4sS0FBS0ksR0FBTCxDQUFTOE0sV0FBVCxHQUF1QkQsS0FBdkIsQ0FBNkJGLEdBQTdCLENBQWQsQ0FBSjs7QUFDQSxnQkFBSUUsS0FBSixFQUFXO0FBQ1Q7QUFDRDtBQUNGLFdBTkQsQ0FNRSxPQUFPdlEsQ0FBUCxFQUFVO0FBQ1Y7QUFDQSxtQkFBT3FILEdBQVA7QUFDRDtBQUNGO0FBQ0YsT0F0QkQsTUFzQk87QUFDTC9ELGVBQU8rRCxHQUFQO0FBQ0Q7O0FBRUQsVUFBSW9KLGFBQWEsRUFBakI7QUFDQSxVQUFJbk4sS0FBS2YsS0FBVCxFQUFnQmtPLFdBQVcxRyxJQUFYLENBQWdCekcsS0FBS2YsS0FBckI7QUFDaEIsVUFBSWUsS0FBSzBMLFlBQVQsRUFBdUJ5QixXQUFXMUcsSUFBWCxDQUFnQnpHLEtBQUswTCxZQUFyQjtBQUN2QixVQUFJMUwsS0FBSzJMLFlBQVQsRUFBdUJ3QixXQUFXMUcsSUFBWCxDQUFnQnpHLEtBQUsyTCxZQUFyQjtBQUN2QixhQUFPd0IsV0FBVzVKLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBUDtBQUNELEtBbENEO0FBQUE7O0FBb0NNNUMsa0JBQU4sQ0FBd0JrSCxTQUF4QixFQUFtQzdILElBQW5DO0FBQUEsb0NBQXlDO0FBQ3ZDO0FBQ0EsVUFBSW9OLFlBQWFsQixRQUFELElBQWNBLGFBQWEsUUFBYixHQUF3QixPQUF4QixHQUFrQ0EsUUFBaEUsQ0FGdUMsQ0FJdkM7OztBQUNBLFVBQUk3RCxZQUFZLElBQWhCO0FBQ0EsVUFBSThFLGFBQWEsRUFBakIsQ0FOdUMsQ0FRdkM7QUFDQTs7QUFDQSxVQUFJbk4sS0FBS2YsS0FBVCxFQUFnQmtPLFdBQVcxRyxJQUFYLENBQWdCekcsS0FBS2YsS0FBckI7QUFDaEIsVUFBSWUsS0FBSzBMLFlBQVQsRUFBdUJ5QixXQUFXMUcsSUFBWCxDQUFnQnpHLEtBQUswTCxZQUFyQjtBQUN2QixVQUFJMUwsS0FBSzJMLFlBQVQsRUFBdUJ3QixXQUFXMUcsSUFBWCxDQUFnQnpHLEtBQUsyTCxZQUFyQixFQVpnQixDQWN2Qzs7QUFDQSxVQUFJMEIsYUFBSjs7QUFDQSxjQUFRck4sS0FBS2tNLFFBQWI7QUFDRSxhQUFLLEtBQUw7QUFDRW1CLDBCQUFnQixDQUFoQjtBQUNBOztBQUNGLGFBQUssUUFBTDtBQUNFQSwwQkFBZ0IsQ0FBaEI7QUFDQTs7QUFDRjtBQUNFQSwwQkFBZ0IsQ0FBaEI7QUFDQTtBQVRKLE9BaEJ1QyxDQTRCdkM7OztBQUNBLFVBQUlsRixPQUFPLEVBQVg7O0FBQ0EsY0FBUW5JLEtBQUtrTSxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0UvRCxlQUFLMUIsSUFBTCxDQUFVO0FBQ1JwTixpQkFBSyxDQURHO0FBRVIrTyxpQkFBSztBQUZHLFdBQVYsRUFHRztBQUNEL08saUJBQUssQ0FESjtBQUVEK08saUJBQUs7QUFGSixXQUhIO0FBT0E7O0FBQ0YsYUFBSyxRQUFMO0FBQ0VELGVBQUsxQixJQUFMLENBQVU7QUFDUnBOLGlCQUFLLENBREc7QUFFUitPLGlCQUFLO0FBRkcsV0FBVixFQUdHO0FBQ0QvTyxpQkFBSyxDQURKO0FBRUQrTyxpQkFBSztBQUZKLFdBSEg7QUFPQTtBQWxCSixPQTlCdUMsQ0FtRHZDOzs7QUFDQSxVQUFJa0YsY0FBYyxJQUFsQjs7QUFDQSxjQUFRdE4sS0FBS2tNLFFBQWI7QUFDRSxhQUFLLEtBQUw7QUFDRW9CLHdCQUFjLElBQWQ7QUFDQTs7QUFDRixhQUFLLFFBQUw7QUFDRUEsd0JBQWMsR0FBZDtBQUNBO0FBTkosT0FyRHVDLENBOER2QztBQUNBO0FBQ0E7OztBQUVBLFVBQUloQixzQkFBYyxLQUFLUCxZQUFMLENBQWtCL0wsSUFBbEIsRUFBd0I7QUFDeEMrSCxvQkFBWTtBQUQ0QixPQUF4QixDQUFkLENBQUosQ0FsRXVDLENBc0V2QztBQUVBOztBQUNBdUUsY0FBUUEsTUFBTWhKLEdBQU4sQ0FDTGlLLElBQUQsSUFBVTtBQUNSQSxhQUFLVCxLQUFMLENBQVdiLE9BQVgsR0FBcUJtQixVQUFVRyxLQUFLVCxLQUFMLENBQVdiLE9BQXJCLENBQXJCO0FBQ0FzQixhQUFLZixVQUFMLEdBQWtCZSxLQUFLZixVQUFMLENBQWdCbEosR0FBaEIsQ0FDZmtLLFNBQUQsSUFBZTtBQUNiQSxvQkFBVXJCLEtBQVYsR0FBa0JpQixVQUFVSSxVQUFVckIsS0FBcEIsQ0FBbEI7QUFDQSxpQkFBT3FCLFNBQVA7QUFDRCxTQUplLENBQWxCO0FBTUEsZUFBT0QsSUFBUDtBQUNELE9BVkssQ0FBUixDQXpFdUMsQ0FzRnZDOztBQUNBLFVBQUlFLGdCQUNGbkIsTUFBTWhKLEdBQU4sQ0FDR2lLLElBQUQsSUFDRSxrQ0FDRCxtQkFEQyxHQUVELGlFQUZDLEdBR0QsV0FBVUEsS0FBS1QsS0FBTCxDQUFXZCxLQUFNLFdBSDFCLEdBSUQsUUFKQyxHQUtGdUIsS0FBS2YsVUFBTCxDQUFnQmxKLEdBQWhCLENBQ0drSyxTQUFELElBQWU7QUFDYixZQUFJRCxLQUFLVCxLQUFMLENBQVdiLE9BQVgsS0FBdUJ1QixVQUFVckIsS0FBckMsRUFBNEM7QUFDMUMsaUJBQVEsNkJBQTRCcUIsVUFBVXpGLFVBQVcsMEVBQXlFeUYsVUFBVXJCLEtBQU0sd0JBQWxKO0FBQ0QsU0FGRCxNQUVPO0FBQ0wsaUJBQVEsNkJBQTRCcUIsVUFBVXpGLFVBQVcsa0VBQWlFeUYsVUFBVXJCLEtBQU0sZUFBMUk7QUFDRDtBQUNGLE9BUEgsRUFRRTVJLElBUkYsQ0FRTyxFQVJQLENBTEUsR0FjRixRQWRFLEdBZUYsUUFqQkYsRUFrQkVBLElBbEJGLENBa0JPLEVBbEJQLENBREY7QUFxQkEsVUFBSW1LLG9CQUFxQjs7O01BR3ZCRCxhQUFjO0tBSGhCLENBNUd1QyxDQWtIdkM7O0FBQ0EsVUFBSTVWLE9BQU87QUFDVGtRLG9CQUFZTSxTQURIO0FBRVR6SCxvQkFBWWlILFNBRkg7QUFHVHhQLGNBQU8sR0FBRThVLFdBQVc1SixJQUFYLENBQWdCLEdBQWhCLENBQXFCLElBQUc2SixVQUFVcE4sS0FBS2tNLFFBQWYsQ0FBeUIsSUFBR2xNLEtBQUszSCxJQUFLLElBQUcySCxLQUFLMk4sUUFBUyxFQUgvRTtBQUlUQyw0QkFBb0JGLGlCQUpYO0FBS1Q1RSxtQkFBVzlJLEtBQUs2TixXQUFMLEdBQW1CLEdBTHJCO0FBTVRDLHNCQUFjWCxXQUFXNUosSUFBWCxDQUFnQixHQUFoQixDQU5MO0FBT1R3SyxpQkFBUy9OLEtBQUtnTyxZQVBMO0FBUVRDLGlCQUFTak8sS0FBS2tPLFdBQUwsR0FBbUIsSUFSbkI7QUFReUI7QUFDbENoSyxnQkFBUWxFLEtBQUtrRSxNQVRKO0FBVVRpSyx5QkFBaUJkLGFBVlI7QUFXVGxGLGNBQU1BLElBWEc7QUFZVGlHLHNCQUFjZDtBQVpMLE9BQVg7QUFlQVosYUFBT0MsTUFBUCxDQUFjOVUsSUFBZCxFQUFvQm1JLEtBQUtNLElBQUwsQ0FBVUMsV0FBOUI7QUFFQSxhQUFPMUksSUFBUDtBQUNELEtBcklEO0FBQUEsR0F0UGtDLENBNlhsQzs7O0FBQ01pTixrQkFBTixDQUF3QnVKLEdBQXhCLEVBQTZCck8sSUFBN0I7QUFBQSxvQ0FBbUM7QUFDakMsVUFBSWdFLFFBQVEsRUFBWixDQURpQyxDQUVqQzs7QUFDQUEsY0FBUXFLLElBQUlyTyxLQUFLa00sUUFBVCxDQUFSLENBSGlDLENBS2pDOztBQUNBLFlBQU1vQyxZQUFZLElBQWxCOztBQUNBLFdBQUssSUFBSWpNLElBQUksQ0FBYixFQUFnQkEsSUFBSXJDLEtBQUtrRSxNQUFMLENBQVlvRSxNQUFoQyxFQUF3Q2pHLEdBQXhDLEVBQTZDO0FBQzNDMkIsY0FBTXNLLGFBQWFqTSxJQUFJLENBQWpCLENBQU4sSUFBNkJyQyxLQUFLa0UsTUFBTCxDQUFZN0IsQ0FBWixDQUE3QjtBQUNELE9BVGdDLENBV2pDOzs7QUFDQTJCLFlBQU0sTUFBTixJQUFnQmhFLEtBQUtNLElBQUwsQ0FBVTBELEtBQVYsQ0FBZ0J1SyxRQUFoQztBQUNBdkssWUFBTSxNQUFOLElBQWlCLEdBQUQsY0FBUyxLQUFLbkIsYUFBTCxDQUFtQjdDLElBQW5CLENBQVQsQ0FBa0MsSUFBR0EsS0FBS2tNLFFBQVMsSUFBR2xNLEtBQUszSCxJQUFLLEVBQWhGO0FBQ0EyTCxZQUFNLE1BQU4sSUFBZ0JoRSxLQUFLa08sV0FBckI7QUFDQWxLLFlBQU0sTUFBTixJQUFnQmhFLEtBQUtrTyxXQUFyQjtBQUNBbEssWUFBTSxNQUFOLElBQWdCaEUsS0FBS0ksR0FBTCxDQUFTOE0sV0FBVCxHQUF1QnhKLEtBQXZCLENBQTZCLENBQUMsRUFBOUIsQ0FBaEI7QUFDQU0sWUFBTSxJQUFOLElBQWNoRSxLQUFLNk4sV0FBbkI7QUFDQTdKLFlBQU0sZ0JBQU4sSUFBMEJoRSxLQUFLMk4sUUFBL0I7QUFFQSxhQUFPM0osS0FBUDtBQUNELEtBckJEO0FBQUE7O0FBOVhrQyxDOzs7Ozs7Ozs7OztBQ1ZwQzNOLE9BQU80TyxNQUFQLENBQWM7QUFBQ3pPLFdBQVEsTUFBSWdZO0FBQWIsQ0FBZDs7QUFBZSxNQUFNQSxTQUFOLENBQWdCO0FBQzdCLFNBQU8vTCxLQUFQLENBQWMvRixDQUFkLEVBQWlCO0FBQ2YsUUFBSXpDLE1BQU0sRUFBVjs7QUFFQSxRQUFJeUMsYUFBYTJKLEtBQWpCLEVBQXdCO0FBQ3RCcE0sVUFBSXdVLE9BQUosR0FBYy9SLEVBQUUrUixPQUFoQjtBQUNBeFUsVUFBSTVCLElBQUosR0FBV3FFLEVBQUVyRSxJQUFiO0FBQ0E0QixVQUFJeVUsUUFBSixHQUFlaFMsRUFBRWdTLFFBQWpCO0FBQ0F6VSxVQUFJMFUsVUFBSixHQUFpQmpTLEVBQUVpUyxVQUFuQjtBQUNBMVUsVUFBSTJVLFlBQUosR0FBbUJsUyxFQUFFa1MsWUFBckI7QUFDQTNVLFVBQUk0VSxLQUFKLEdBQVluUyxFQUFFbVMsS0FBZDtBQUNELEtBUEQsTUFPTztBQUNMNVUsWUFBTXlDLENBQU47QUFDRDs7QUFFRCxXQUFPekMsR0FBUDtBQUNEOztBQWhCNEIsQzs7Ozs7Ozs7Ozs7QUNBL0I1RCxPQUFPNE8sTUFBUCxDQUFjO0FBQUMxRyxtQkFBZ0IsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJZ0wsV0FBSjtBQUFnQmxULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ2dULGNBQVk5UyxDQUFaLEVBQWM7QUFBQzhTLGtCQUFZOVMsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTs7QUFFOUQsTUFBTThILGVBQU4sQ0FBc0I7QUFDM0IsU0FBYUksR0FBYixDQUFrQkgsSUFBbEIsRUFBd0JJLFVBQXhCO0FBQUEsb0NBQW9DO0FBQ2xDLFVBQUl3TCx1QkFBZWIsWUFBWWMsT0FBWixDQUFvQjdMLEtBQUs4TCxHQUF6QixDQUFmLENBQUo7QUFDQSxVQUFJaE0sS0FBSzhMLE9BQU85TCxFQUFQLENBQVVFLEtBQUsrTCxRQUFmLENBQVQ7QUFDQSxhQUFPak0sR0FBR00sVUFBSCxDQUFjQSxVQUFkLENBQVA7QUFDRCxLQUpEO0FBQUE7O0FBRDJCLEM7Ozs7Ozs7Ozs7O0FDRjdCdkksT0FBTzRPLE1BQVAsQ0FBYztBQUFDek8sV0FBUSxNQUFJd0M7QUFBYixDQUFkO0FBQW1DLElBQUkrTSxLQUFKO0FBQVUxUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDc1AsWUFBTXRQLENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSXFZLE1BQUo7QUFBV3pZLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNxWSxhQUFPclksQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDs7QUFHaEcsTUFBTXVDLEtBQU4sQ0FBWTtBQUN6QjBNLGNBQWFySCxPQUFiLEVBQXNCO0FBQ3BCO0FBQ0EsU0FBSzBRLElBQUwsR0FBWWhKLE1BQU1pSixVQUFOLENBQWlCM1EsT0FBakIsQ0FBWixDQUZvQixDQUlwQjs7QUFDQSxRQUFJNFEsZUFBZTtBQUFDQywwQkFBb0I7QUFBckIsS0FBbkI7QUFDQXhDLFdBQU9DLE1BQVAsQ0FBY3NDLFlBQWQsRUFBNEI1USxPQUE1QjtBQUNBLFNBQUs4USxTQUFMLEdBQWlCcEosTUFBTWlKLFVBQU4sQ0FBaUJDLFlBQWpCLENBQWpCO0FBQ0Q7O0FBRUQsU0FBT0csVUFBUCxDQUFtQkMsSUFBbkIsRUFBeUI7QUFDdkIsV0FBT1AsT0FBT08sSUFBUCxFQUFhQyxNQUFiLEdBQXNCcFMsU0FBdEIsQ0FBZ0MsQ0FBaEMsRUFBbUMsRUFBbkMsRUFBdUNxUyxPQUF2QyxDQUErQyxHQUEvQyxFQUFvRCxHQUFwRCxDQUFQO0FBQ0Q7QUFFRDs7Ozs7O0FBSUF2VixRQUFPSyxHQUFQLEVBQVk7QUFDVjtBQUNBO0FBQ0EsV0FBTyxLQUFLbVYsTUFBTCxHQUNKQyxJQURJLENBRUZDLEdBQUQsSUFBUztBQUNQLGFBQU8sSUFBSXhJLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQXNJLFlBQUkxVixLQUFKLENBQVVLLEdBQVYsRUFBZSxDQUFDcUMsQ0FBRCxFQUFJekMsR0FBSixLQUFZO0FBQ3pCO0FBQ0F5VixjQUFJQyxPQUFKOztBQUNBLGNBQUlqVCxDQUFKLEVBQU87QUFDTDBLLG1CQUFPMUssQ0FBUDtBQUNELFdBRkQsTUFFT3lLLFFBQVFsTixHQUFSO0FBQ1IsU0FORDtBQU9ELE9BVkksQ0FBUDtBQVlELEtBZkUsRUFpQkpzTixLQWpCSSxDQWlCRzdLLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQW5CSSxDQUFQO0FBb0JEOztBQUVLa1QsY0FBTixDQUFvQnZWLEdBQXBCO0FBQUEsb0NBQXlCO0FBQ3ZCLFVBQUlKLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPSixJQUFJNFYsUUFBWDtBQUNELEtBSEQ7QUFBQTtBQUtBOzs7Ozs7OztBQU1NcFQsYUFBTixDQUFtQjBKLEtBQW5CLEVBQTBCdE8sT0FBTyxFQUFqQyxFQUFxQ2lZLFVBQVUsRUFBL0M7QUFBQSxvQ0FBbUQ7QUFDakQ7QUFDQTtBQUVBLFVBQUl6VixNQUFPLGVBQWM4TCxLQUFNLEdBQS9CO0FBRUEsVUFBSTdDLE1BQU0sSUFBSXlNLEdBQUosRUFBVjs7QUFDQSxXQUFLLElBQUlwSCxDQUFULElBQWMrRCxPQUFPaEUsSUFBUCxDQUFZN1EsSUFBWixDQUFkLEVBQWlDO0FBQy9CLFlBQUlBLEtBQUs4USxDQUFMLE1BQVksSUFBaEIsRUFBc0I7QUFDcEJyRixjQUFJOEUsR0FBSixDQUFRTyxDQUFSLEVBQVcsTUFBWDtBQUNELFNBRkQsTUFFTyxJQUFJOVEsS0FBSzhRLENBQUwsRUFBUWpELFdBQVIsQ0FBb0JyTixJQUFwQixLQUE2QixNQUFqQyxFQUF5QztBQUM5QztBQUNBaUwsY0FBSThFLEdBQUosQ0FBUU8sQ0FBUixFQUFZLElBQUczUCxNQUFNb1csVUFBTixDQUFpQnZYLEtBQUs4USxDQUFMLENBQWpCLENBQTBCLEdBQXpDO0FBQ0QsU0FITSxNQUdBO0FBQ0xyRixjQUFJOEUsR0FBSixDQUFRTyxDQUFSLEVBQVksR0FBRTVDLE1BQU1pSyxNQUFOLENBQWFuWSxLQUFLOFEsQ0FBTCxDQUFiLENBQXNCLEVBQXBDO0FBQ0Q7QUFDRjs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBYytELE9BQU9oRSxJQUFQLENBQVlvSCxPQUFaLENBQWQsRUFBb0M7QUFDbEN4TSxZQUFJOEUsR0FBSixDQUFRTyxDQUFSLEVBQVdtSCxRQUFRbkgsQ0FBUixNQUFlLElBQWYsR0FBc0IsTUFBdEIsR0FBK0JtSCxRQUFRbkgsQ0FBUixDQUExQztBQUNEOztBQUVEdE8sYUFBUSxLQUFJLENBQUMsR0FBR2lKLElBQUlvRixJQUFKLEVBQUosRUFBZ0JuRixJQUFoQixDQUFxQixHQUFyQixDQUEwQixLQUF0QztBQUVBbEosYUFBUSxXQUFVLENBQUMsR0FBR2lKLElBQUkyTSxNQUFKLEVBQUosRUFBa0IxTSxJQUFsQixDQUF1QixHQUF2QixDQUE0QixLQUE5QztBQUVBLFVBQUl0SixvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT0osSUFBSTRWLFFBQVg7QUFDRCxLQTNCRDtBQUFBO0FBNkJBOzs7Ozs7Ozs7QUFPTW5JLGFBQU4sQ0FBbUJ2QixLQUFuQixFQUEwQjFNLE1BQTFCLEVBQWtDNUIsSUFBbEMsRUFBd0NpWSxPQUF4QztBQUFBLG9DQUFpRDtBQUMvQyxVQUFJelYsTUFBTyxVQUFTOEwsS0FBTSxPQUExQjtBQUVBLFVBQUkrSixVQUFVLEVBQWQ7O0FBQ0EsV0FBSyxJQUFJdkgsQ0FBVCxJQUFjK0QsT0FBT2hFLElBQVAsQ0FBWTdRLElBQVosQ0FBZCxFQUFpQztBQUMvQnFZLGdCQUFRekosSUFBUixDQUFjLEdBQUVrQyxDQUFFLElBQUc1QyxNQUFNaUssTUFBTixDQUFhblksS0FBSzhRLENBQUwsQ0FBYixDQUFzQixFQUEzQztBQUNEOztBQUNELFdBQUssSUFBSUEsQ0FBVCxJQUFjK0QsT0FBT2hFLElBQVAsQ0FBWW9ILE9BQVosQ0FBZCxFQUFvQztBQUNsQ0ksZ0JBQVF6SixJQUFSLENBQWMsR0FBRWtDLENBQUUsSUFBR21ILFFBQVFuSCxDQUFSLENBQVcsRUFBaEM7QUFDRDs7QUFDRHRPLGFBQU82VixRQUFRM00sSUFBUixDQUFhLEdBQWIsQ0FBUDtBQUVBbEosYUFBUSxVQUFTWixNQUFPLEdBQXhCO0FBRUEsVUFBSVEsb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9KLEdBQVA7QUFDRCxLQWhCRDtBQUFBLEdBM0Z5QixDQTZHekI7OztBQUNNa1csWUFBTixDQUFrQjlWLEdBQWxCO0FBQUEsb0NBQXVCO0FBQ3JCLFVBQUkrVixXQUFXLEtBQUtyQixJQUFwQjtBQUNBLFdBQUtBLElBQUwsR0FBWSxLQUFLSSxTQUFqQjs7QUFDQSxVQUFJO0FBQ0YsWUFBSWxWLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxlQUFPSixHQUFQO0FBQ0QsT0FIRCxTQUdVO0FBQ1IsYUFBSzhVLElBQUwsR0FBWXFCLFFBQVo7QUFDRDtBQUNGLEtBVEQ7QUFBQTs7QUFXTUMsa0JBQU47QUFBQSxvQ0FBMEI7QUFDeEIsb0JBQU0sS0FBS3JXLEtBQUwsQ0FBWSxvQkFBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNc1csUUFBTjtBQUFBLG9DQUFnQjtBQUNkLG9CQUFNLEtBQUt0VyxLQUFMLENBQVksU0FBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNdVcsVUFBTjtBQUFBLG9DQUFrQjtBQUNoQixvQkFBTSxLQUFLdlcsS0FBTCxDQUFZLFdBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJQW9NLGlCQUFnQi9MLEdBQWhCLEVBQXFCNEwsV0FBWTdMLE1BQUQsSUFBWSxDQUFFLENBQTlDLEVBQWdEOEwsVUFBV3hKLENBQUQsSUFBTyxDQUFFLENBQW5FLEVBQXFFO0FBQ25FLFdBQU8sS0FBSzhTLE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUl4SSxPQUFKLENBQ0wsQ0FBT0MsT0FBUCxFQUFnQkMsTUFBaEIsOEJBQTJCO0FBQ3pCO0FBQ0FzSSxZQUFJMVYsS0FBSixDQUFVSyxHQUFWLEVBQ0dtVyxFQURILENBQ00sUUFETixFQUVLcFcsTUFBRCxJQUFZO0FBQ1ZzVixjQUFJZSxLQUFKO0FBQ0F4SyxtQkFBUzdMLE1BQVQ7QUFDQXNWLGNBQUlnQixNQUFKO0FBQ0QsU0FOTCxFQU9HRixFQVBILENBT00sT0FQTixFQU9nQjlULENBQUQsSUFBTztBQUNsQndKLGtCQUFReEosQ0FBUjtBQUNELFNBVEgsRUFVRzhULEVBVkgsQ0FVTSxLQVZOLEVBVWEsTUFBTTtBQUNmZCxjQUFJQyxPQUFKO0FBQ0F4STtBQUNELFNBYkg7QUFjRCxPQWhCRCxDQURLLENBQVA7QUFtQkQsS0F0QkUsRUF3QkpJLEtBeEJJLENBd0JHN0ssQ0FBRCxJQUFPO0FBQ1osWUFBTUEsQ0FBTjtBQUNELEtBMUJJLENBQVA7QUEyQkQ7O0FBRUQ4UyxXQUFVO0FBQ1IsV0FBTyxJQUFJdEksT0FBSixDQUNMLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUNuQjtBQUNBLFdBQUsySCxJQUFMLENBQVU0QixhQUFWLENBQXdCLENBQUNqVSxDQUFELEVBQUlnVCxHQUFKLEtBQVk7QUFDbEMsWUFBSWhULENBQUosRUFBTztBQUNMMEssaUJBQU8xSyxDQUFQO0FBQ0QsU0FGRCxNQUVPO0FBQ0x5SyxrQkFBUXVJLEdBQVI7QUFDRDtBQUNGLE9BTkQ7QUFPRCxLQVZJLEVBWUpuSSxLQVpJLENBYUY3SyxDQUFELElBQU87QUFDTCxZQUFNQSxDQUFOO0FBQ0QsS0FmRSxDQUFQO0FBaUJEOztBQXJMd0IsQzs7Ozs7Ozs7Ozs7QUNIM0JyRyxPQUFPNE8sTUFBUCxDQUFjO0FBQUN6TyxXQUFRLE1BQUk4SztBQUFiLENBQWQ7O0FBQWUsTUFBTUEsTUFBTixDQUFhO0FBQzFCb0UsY0FBYTFDLFVBQWIsRUFBeUI7QUFDdkIsU0FBS0EsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxTQUFLUSxhQUFMLEdBQXFCLElBQXJCO0FBQ0EsU0FBS00sUUFBTCxHQUFnQixJQUFoQjtBQUNBLFNBQUtTLFdBQUwsR0FBbUIsSUFBbkI7QUFDQSxTQUFLbUMsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLakQsV0FBTCxHQUFtQixDQUFuQjtBQUNEOztBQUVLc0IsUUFBTixDQUFjaEIsR0FBZDtBQUFBLG9DQUFtQjtBQUNqQjtBQUNBLFVBQUksS0FBSzJDLEtBQUwsR0FBYSxLQUFLMUQsVUFBbEIsS0FBaUMsQ0FBckMsRUFBd0M7QUFDdEMsWUFBSSxLQUFLUSxhQUFULEVBQXdCO0FBQ3RCLHdCQUFNLEtBQUtBLGFBQUwsQ0FBbUIsS0FBS0MsV0FBeEIsQ0FBTjtBQUNEO0FBQ0Y7O0FBQ0QsVUFBSSxLQUFLSyxRQUFULEVBQW1CO0FBQ2pCLHNCQUFNLEtBQUtBLFFBQUwsQ0FBY0MsR0FBZCxDQUFOO0FBQ0Q7O0FBQ0QsV0FBSzJDLEtBQUwsR0FWaUIsQ0FXakI7O0FBQ0EsVUFBSSxLQUFLQSxLQUFMLEdBQWEsS0FBSzFELFVBQWxCLEtBQWlDLENBQXJDLEVBQXdDO0FBQ3RDLFlBQUksS0FBS3VCLFdBQVQsRUFBc0I7QUFDcEIsd0JBQU0sS0FBS0EsV0FBTCxDQUFpQixLQUFLZCxXQUF0QixDQUFOO0FBQ0Q7O0FBQ0QsYUFBS0EsV0FBTDtBQUNEO0FBQ0YsS0FsQkQ7QUFBQTs7QUFtQkF1QixVQUFTO0FBQ1AsU0FBS1QsV0FBTCxDQUFpQixLQUFLZCxXQUF0QjtBQUNEOztBQS9CeUIsQzs7Ozs7Ozs7Ozs7QUNBNUJwTixPQUFPNE8sTUFBUCxDQUFjO0FBQUN6TyxXQUFRLE1BQUl5QztBQUFiLENBQWQ7QUFBb0MsSUFBSXVWLFNBQUo7QUFBY25ZLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMrWCxnQkFBVS9YLENBQVY7QUFBWTs7QUFBeEIsQ0FBaEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFHM0csTUFBTXdDLE1BQU4sQ0FBYTtBQUMxQnlNLGdCQUFlO0FBQ2IsU0FBS3RMLE1BQUwsR0FBYyxFQUFkO0FBQ0EsU0FBSzJQLFNBQUwsR0FBaUIsRUFBakI7QUFDQSxTQUFLNkcsUUFBTCxHQUFnQixJQUFoQjtBQUNEOztBQUVEQyxrQkFBaUI7QUFDZixTQUFLRCxRQUFMLEdBQWdCLElBQUlFLFFBQUosRUFBaEI7QUFDQSxTQUFLL0csU0FBTCxDQUFldEQsSUFBZixDQUFvQixLQUFLbUssUUFBekI7QUFDRDs7QUFFSzdXLE9BQU4sQ0FBYTFCLE9BQU8sRUFBcEIsRUFBd0J5UixLQUFLLCtCQUFZLENBQUUsQ0FBZCxDQUE3QjtBQUFBLG9DQUE2QztBQUMzQyxXQUFLK0csYUFBTDtBQUVBLFVBQUlFLE1BQU0sRUFBVjs7QUFFQSxVQUFJO0FBQ0YsWUFBSTlXLG9CQUFZNlAsSUFBWixDQUFKO0FBRUE0QyxlQUFPQyxNQUFQLENBQWNvRSxHQUFkLEVBQW1CO0FBQ2pCakwsZ0JBQU0sU0FEVztBQUVqQi9MLGlCQUFPMUIsSUFGVTtBQUdqQjJZLGtCQUFRL1c7QUFIUyxTQUFuQjtBQUtELE9BUkQsQ0FRRSxPQUFPeUMsQ0FBUCxFQUFVO0FBQ1ZnUSxlQUFPQyxNQUFQLENBQWNvRSxHQUFkLEVBQW1CO0FBQ2pCakwsZ0JBQU0sT0FEVztBQUVqQi9MLGlCQUFPMUIsSUFGVTtBQUdqQjJZLGtCQUFReEMsVUFBVS9MLEtBQVYsQ0FBZ0IvRixDQUFoQjtBQUhTLFNBQW5CO0FBS0QsT0FkRCxTQWNVO0FBQ1IsWUFBSSxLQUFLa1UsUUFBTCxDQUFjSyxLQUFsQixFQUF5QjtBQUN2QnZFLGlCQUFPQyxNQUFQLENBQWNvRSxHQUFkLEVBQW1CO0FBQ2pCSCxzQkFBVSxLQUFLQTtBQURFLFdBQW5CO0FBR0Q7O0FBQ0QsYUFBS3hXLE1BQUwsQ0FBWXFNLElBQVosQ0FBaUJzSyxHQUFqQjtBQUNEO0FBQ0YsS0EzQkQ7QUFBQTs7QUE2QkE5UCxXQUFVaVEsU0FBVixFQUFxQjtBQUNuQixTQUFLTixRQUFMLENBQWNPLE9BQWQsQ0FBc0JELFNBQXRCO0FBQ0Q7O0FBRUR2VSxTQUFRdVUsU0FBUixFQUFtQjtBQUNqQixTQUFLTixRQUFMLENBQWNwWSxLQUFkLENBQW9CZ1csVUFBVS9MLEtBQVYsQ0FBZ0J5TyxTQUFoQixDQUFwQjtBQUNEOztBQUVERSxpQkFBZ0I7QUFDZCxRQUFJQyxXQUFXLEtBQUt0SCxTQUFMLENBQWVsTCxJQUFmLENBQW9CbkMsS0FBS0EsRUFBRTBVLFlBQUYsRUFBekIsQ0FBZjtBQUNBLFFBQUlFLFdBQVcsS0FBZjs7QUFDQSxTQUFLLElBQUlQLEdBQVQsSUFBZ0IsS0FBSzNXLE1BQXJCLEVBQTZCO0FBQzNCLFVBQUkyVyxJQUFJakwsSUFBSixLQUFhLE9BQWpCLEVBQTBCO0FBQ3hCd0wsbUJBQVcsSUFBWDtBQUNBO0FBQ0Q7QUFDRjs7QUFDRCxXQUFPRCxZQUFZQyxRQUFuQjtBQUNEOztBQUVEbFQsWUFBVztBQUNULFFBQUksS0FBS2dULFlBQUwsRUFBSixFQUF5QjtBQUN2QixZQUFNLElBQUkvWixPQUFPZ1AsS0FBWCxDQUFpQixLQUFLak0sTUFBdEIsQ0FBTjtBQUNEOztBQUNELFdBQU8sS0FBS0EsTUFBWjtBQUNEOztBQWxFeUI7O0FBcUU1QixNQUFNMFcsUUFBTixDQUFlO0FBQ2JwTCxnQkFBZTtBQUNiLFNBQUt1TCxLQUFMLEdBQWEsQ0FBYjtBQUNBLFNBQUtNLEtBQUwsR0FBYTtBQUNYSixlQUFTO0FBQ1BGLGVBQU8sQ0FEQTtBQUVQTyxpQkFBUztBQUZGLE9BREU7QUFLWGhaLGFBQU87QUFDTHlZLGVBQU8sQ0FERjtBQUVMTyxpQkFBUztBQUZKO0FBTEksS0FBYjtBQVVEOztBQUVETCxVQUFTRCxTQUFULEVBQW9CO0FBQ2xCLFFBQUlBLFNBQUosRUFBZTtBQUNiLFdBQUtLLEtBQUwsQ0FBV0osT0FBWCxDQUFtQkssT0FBbkIsQ0FBMkIvSyxJQUEzQixDQUFnQ3lLLFNBQWhDO0FBQ0Q7O0FBQ0QsU0FBS0ssS0FBTCxDQUFXSixPQUFYLENBQW1CRixLQUFuQjtBQUNBLFNBQUtBLEtBQUw7QUFDRDs7QUFDRHpZLFFBQU8wWSxTQUFQLEVBQWtCO0FBQ2hCO0FBQ0EsUUFBSU8sWUFBWSxJQUFoQjtBQUNBLFFBQUluSyxRQUFRLEtBQUtpSyxLQUFMLENBQVcvWSxLQUFYLENBQWlCZ1osT0FBakIsQ0FBeUJsSixNQUFyQzs7QUFDQSxRQUFJaEIsS0FBSixFQUFXO0FBQ1RtSyxrQkFBWSxLQUFLRixLQUFMLENBQVcvWSxLQUFYLENBQWlCZ1osT0FBakIsQ0FBeUJsSyxRQUFRLENBQWpDLENBQVo7QUFDRCxLQU5lLENBUWhCOzs7QUFDQSxRQUFJMU8sS0FBS0MsU0FBTCxDQUFlNFksU0FBZixNQUE4QjdZLEtBQUtDLFNBQUwsQ0FBZXFZLFNBQWYsQ0FBbEMsRUFBNkQ7QUFDM0QsVUFBSUEsYUFBYUEsY0FBYyxFQUEzQixJQUFpQ0EsY0FBYyxFQUFuRCxFQUF1RDtBQUNyRCxhQUFLSyxLQUFMLENBQVcvWSxLQUFYLENBQWlCZ1osT0FBakIsQ0FBeUIvSyxJQUF6QixDQUE4QnlLLFNBQTlCO0FBQ0Q7QUFDRjs7QUFDRCxTQUFLSyxLQUFMLENBQVcvWSxLQUFYLENBQWlCeVksS0FBakI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBRURHLGlCQUFnQjtBQUNkLFdBQU8sS0FBS0csS0FBTCxDQUFXL1ksS0FBWCxDQUFpQnlZLEtBQXhCO0FBQ0Q7O0FBMUNZLEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcbi8vICAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4vLyAgIHJlcy5lbmQoYEhlbGxvIHdvcmxkIGZyb206ICR7TWV0ZW9yLnJlbGVhc2V9YCk7XHJcbi8vIH0pO1xyXG5cclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnO1xyXG5cclxuLy8gUmVxdWlyZXMgbXVsdGlwYXJ0eSBcclxuaW1wb3J0IG11bHRpcGFydHkgZnJvbSAnY29ubmVjdC1tdWx0aXBhcnR5JztcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL3VwbG9hZHMnO1xyXG5sZXQgbXVsdGlwYXJ0eU1pZGRsZXdhcmUgPSBtdWx0aXBhcnR5KCk7XHJcblxyXG5jb25zdCByb3V0ZSA9ICcvdXBsb2FkL2ltYWdlJztcclxuXHJcbi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgZnVjLnVwbG9hZEZpbGUgKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIG11bHRpcGFydHlNaWRkbGV3YXJlKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIChyZXEsIHJlc3ApID0+IHtcclxuICAvLyBkb24ndCBmb3JnZXQgdG8gZGVsZXRlIGFsbCByZXEuZmlsZXMgd2hlbiBkb25lXHJcblxyXG4gIGNvbnN0IHJlYWRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMucmVhZEZpbGUpO1xyXG4gIGNvbnN0IHdyaXRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMud3JpdGVGaWxlKTtcclxuICBjb25zdCB1cGxvYWRJZCA9IHVuaXFpZCgpO1xyXG5cclxuICBmb3IgKGxldCBmaWxlIG9mIHJlcS5maWxlcy5maWxlKSB7XHJcbiAgICBjb25zdCBkYXRhID0gcmVhZGVyKGZpbGUucGF0aCk7XHJcbiAgICAvLyDjg5XjgqHjgqTjg6vlkI3jga7ph43opIfjgpLpgb/jgZHjgovjgZ/jgoHjgIHkuIDmhI/jga7jg5XjgqHjgqTjg6vlkI3jgpLkvZzmiJDjgZnjgotcclxuICAgIC8vIOalveWkqeOBruODleOCoeOCpOODq+WQjeaWh+Wtl+aVsOWItumZkDIw44Gr5ZCI44KP44Gb44KLXHJcbiAgICBsZXQgZmlsZW5hbWUgPSBgJHt1bmlxaWQoKX0uanBnYFxyXG5cclxuICAgIC8vIHNldCB0aGUgY29ycmVjdCBwYXRoIGZvciB0aGUgZmlsZSBub3QgdGhlIHRlbXBvcmFyeSBvbmUgZnJvbSB0aGUgQVBJOlxyXG4gICAgbGV0IHNhdmVQYXRoID0gcmVxLmJvZHkuaW1hZ2VkaXIgKyAnLycgKyBmaWxlbmFtZTtcclxuXHJcbiAgICAvLyBjb3B5IHRoZSBkYXRhIGZyb20gdGhlIHJlcS5maWxlcy5maWxlLnBhdGggYW5kIHBhc3RlIGl0IHRvIGZpbGUucGF0aFxyXG5cclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiee1kOaenOOCkuiomOmMsuOBmeOCi1xyXG4gICAgbGV0IGRvYyA9IHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgICBjbGllbnRGaWxlTmFtZTogZmlsZS5uYW1lLFxyXG4gICAgICB1cGxvYWRlZEZpbGVOYW1lOiBmaWxlbmFtZVxyXG4gICAgfTtcclxuICAgIFxyXG4gICAgdHJ5e1xyXG4gICAgICB3cml0ZXIoc2F2ZVBhdGgsIGRhdGEpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2goZXJyKXtcclxuICAgICAgZG9jLmVycm9yID0gZXJyO1xyXG4gICAgfVxyXG4gICAgVXBsb2Fkcy5pbnNlcnQoZG9jKTtcclxuXHJcbiAgICBkZWxldGUgZmlsZTtcclxuXHJcbiAgfTtcclxuICByZXNwLndyaXRlSGVhZCgyMDApO1xyXG4gIHJlc3AuZW5kKEpTT04uc3RyaW5naWZ5KHtcclxuICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgIHNhdmVEaXI6IHJlcS5ib2R5LmltYWdlZGlyXHJcbiAgfSkpO1xyXG5cclxufSk7IiwiaW1wb3J0IGNyeXB0byBmcm9tICdjcnlwdG8nXHJcblxyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQgUmVwb3J0IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgR3JvdXAsXHJcbiAgR3JvdXBGYWN0b3J5XHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3VwcydcclxuaW1wb3J0IHtcclxuICBGaWx0ZXJcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycydcclxuXHJcbmxldCB0YWcgPSAnY3ViZW1pZydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ubWlncmF0ZWBdIChjb25maWcpIHtcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICAvLyBzZXR1cCBncm91cFxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IEZpbHRlcihjb25maWcuc3JjRmlsdGVySWQpXHJcbiAgICAvLyBsZXQgcGx1ZyA9IGdyb3VwLmdldFBsdWcoKTtcclxuXHJcbiAgICAvLyBjaGVja2luZyBjb25uZWN0aW9uXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCB0ZXN0UXVlcnkgPSAnU0hPVyBEQVRBQkFTRVMnXHJcblxyXG4gICAgbGV0IGRzdERiID0gbmV3IE15U1FMKGNvbmZpZy5kc3QuY3JlZClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ0Nvbm5lY3QgdG8gRGVzdGluYXRpb24nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgYXdhaXQgZHN0RGIucXVlcnkodGVzdFF1ZXJ5KVxyXG4gICAgICB9KVxyXG5cclxuICAgIC8vIHByb2Nlc3MgZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAgLy9cclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ1NlbGVjdCBsb29wIGluIHNvdXJjZScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgbW9iaWxlTnVsbDogYXN5bmMgKHJlY29yZCkgPT4ge1xyXG4gICAgICAgICAgICAvLyAvLyDlgKTjgpLmlbTnkIZcclxuICAgICAgICAgICAgLy8gZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgLy8gICBpZiAocmVjb3JkW2tleV0gPT09IG51bGwpO1xyXG4gICAgICAgICAgICAvLyAgIGVsc2UgaWYgKHJlY29yZFtrZXldLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgICAgICAvLyAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IE15U1FMLmZvcm1hdERhdGUocmVjb3JkW2tleV0pO1xyXG4gICAgICAgICAgICAvLyAgICAgcmVjb3JkW2tleV0gPSBgXCIke3JlY29yZFtrZXldfVwiYDtcclxuICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lciDjgavkv53lrZhcclxuXHJcbiAgICAgICAgICAgIGxldCBzcWwgPSBgXHJcblxyXG4gICAgICAgICAgICAgICAgSU5TRVJUIGR0Yl9jdXN0b21lclxyXG4gICAgICAgICAgICAgICAgKCBcXGBjdXN0b21lcl9pZFxcYCwgXFxgc3RhdHVzXFxgLCBcXGBzZXhcXGAsIFxcYGpvYlxcYCwgXFxgY291bnRyeV9pZFxcYCwgXFxgcHJlZlxcYCwgXFxgbmFtZTAxXFxgLCBcXGBuYW1lMDJcXGAsIFxcYGthbmEwMVxcYCwgXFxga2FuYTAyXFxgLCBcXGBjb21wYW55X25hbWVcXGAsIFxcYHppcDAxXFxgLCBcXGB6aXAwMlxcYCwgXFxgemlwY29kZVxcYCwgXFxgYWRkcjAxXFxgLCBcXGBhZGRyMDJcXGAsIFxcYGVtYWlsXFxgLCBcXGB0ZWwwMVxcYCwgXFxgdGVsMDJcXGAsIFxcYHRlbDAzXFxgLCBcXGBmYXgwMVxcYCwgXFxgZmF4MDJcXGAsIFxcYGZheDAzXFxgLCBcXGBiaXJ0aFxcYCwgXFxgcGFzc3dvcmRcXGAsIFxcYHNhbHRcXGAsIFxcYHNlY3JldF9rZXlcXGAsIFxcYGZpcnN0X2J1eV9kYXRlXFxgLCBcXGBsYXN0X2J1eV9kYXRlXFxgLCBcXGBidXlfdGltZXNcXGAsIFxcYGJ1eV90b3RhbFxcYCwgXFxgbm90ZVxcYCwgXFxgY3JlYXRlX2RhdGVcXGAsIFxcYHVwZGF0ZV9kYXRlXFxgLCBcXGBkZWxfZmxnXFxgIClcclxuXHJcbiAgICAgICAgICAgICAgICBWQUxVRVMoICR7cmVjb3JkLmN1c3RvbWVyX2lkfSAsICR7cmVjb3JkLnN0YXR1c30gLCAke3JlY29yZC5zZXh9ICwgJHtyZWNvcmQuam9ifSAsICR7cmVjb3JkLmNvdW50cnlfaWR9ICwgJHtyZWNvcmQucHJlZn0gLCAke3JlY29yZC5uYW1lMDF9ICwgJHtyZWNvcmQubmFtZTAyfSAsICR7cmVjb3JkLmthbmEwMX0gLCAke3JlY29yZC5rYW5hMDJ9ICwgJHtyZWNvcmQuY29tcGFueV9uYW1lfSAsICR7cmVjb3JkLnppcDAxfSAsICR7cmVjb3JkLnppcDAyfSAsICR7cmVjb3JkLnppcGNvZGV9ICwgJHtyZWNvcmQuYWRkcjAxfSAsICR7cmVjb3JkLmFkZHIwMn0gLCAke3JlY29yZC5lbWFpbH0gLCAke3JlY29yZC50ZWwwMX0gLCAke3JlY29yZC50ZWwwMn0gLCAke3JlY29yZC50ZWwwM30gLCAke3JlY29yZC5mYXgwMX0gLCAke3JlY29yZC5mYXgwMn0gLCAke3JlY29yZC5mYXgwM30gLCAke3JlY29yZC5iaXJ0aH0gLCAke3JlY29yZC5wYXNzd29yZH0gLCAke3JlY29yZC5zYWx0fSAsICR7cmVjb3JkLnNlY3JldF9rZXl9ICwgJHtyZWNvcmQuZmlyc3RfYnV5X2RhdGV9ICwgJHtyZWNvcmQubGFzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5idXlfdGltZXN9ICwgJHtyZWNvcmQuYnV5X3RvdGFsfSAsICR7cmVjb3JkLm5vdGV9ICwgJHtyZWNvcmQuY3JlYXRlX2RhdGV9ICwgJHtyZWNvcmQudXBkYXRlX2RhdGV9ICwgJHtyZWNvcmQuZGVsX2ZsZ30gKVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBgXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgc3RhdHVzOiByZWNvcmQuc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgICBzZXg6IHJlY29yZC5zZXgsXHJcbiAgICAgICAgICAgICAgICAgIGpvYjogcmVjb3JkLmpvYixcclxuICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICBlbWFpbDogcmVjb3JkLmVtYWlsLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICBiaXJ0aDogcmVjb3JkLmJpcnRoLFxyXG4gICAgICAgICAgICAgICAgICBwYXNzd29yZDogcmVjb3JkLnBhc3N3b3JkLFxyXG4gICAgICAgICAgICAgICAgICBzYWx0OiByZWNvcmQuc2FsdCxcclxuICAgICAgICAgICAgICAgICAgc2VjcmV0X2tleTogcmVjb3JkLnNlY3JldF9rZXksXHJcbiAgICAgICAgICAgICAgICAgIGZpcnN0X2J1eV9kYXRlOiByZWNvcmQuZmlyc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGxhc3RfYnV5X2RhdGU6IHJlY29yZC5sYXN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBidXlfdGltZXM6IHJlY29yZC5idXlfdGltZXMsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90b3RhbDogcmVjb3JkLmJ1eV90b3RhbCxcclxuICAgICAgICAgICAgICAgICAgbm90ZTogcmVjb3JkLm5vdGUsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXJfYWRkcmVzc1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcl9hZGRyZXNzJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9hZGRyZXNzX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjg6Hjg6vjg57jgqzjg5fjg6njgrDjgqTjg7MgcGxnX21haWxtYWdhX2N1c3RvbWVyXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX21haWxtYWdhX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBpZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgbWFpbG1hZ2FfZmxnOiByZWNvcmQubWFpbG1hZ2FfZmxnLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8g44Kv44O844Od44Oz55m66KGM77yIRUNDVUJFMuOBruODneOCpOODs+ODiOmChOWFg++8iVxyXG5cclxuICAgICAgICAgICAgbGV0IGNvdXBvbkNkID0gY3J5cHRvLnJhbmRvbUJ5dGVzKDgpLnRvU3RyaW5nKCdiYXNlNjQnKS5zdWJzdHJpbmcoMCwgMTEpXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uTmFtZSA9IGAke3JlY29yZC5uYW1lMDF9ICR7cmVjb3JkLm5hbWUwMn0g5qeYIOOBlOWEquW+heOCr+ODvOODneODsyDkvJrlk6Hnlarlj7c6JHtyZWNvcmQuY3VzdG9tZXJfaWR9YFxyXG5cclxuICAgICAgICAgICAgbGV0IGRpc2NvdW50UHJpY2UgPSByZWNvcmQucG9pbnQgKyA1MDBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ3BsZ19jb3Vwb24nLCB7XHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2NkOiBjb3Vwb25DZCxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3R5cGU6IDMsIC8vIOWFqOWVhuWTgVxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbmFtZTogY291cG9uTmFtZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfdHlwZTogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3VzZV90aW1lOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fcmVsZWFzZTogMSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcHJpY2U6IGRpc2NvdW50UHJpY2UsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3JhdGU6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGVuYWJsZV9mbGFnOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbWVtYmVyOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbG93ZXJfbGltaXQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV9mcm9tX2RhdGU6ICcyMDE4LTA0LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX3RvX2RhdGU6ICcyMDE5LTA1LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogMFxyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgJ2N1YmVtaWcuc2VydmVyQ2hlY2snIChwcm9maWxlKSB7XHJcbiAgICBsZXQgZGIgPSBuZXcgTXlTUUwocHJvZmlsZSlcclxuICAgIGxldCByZXMgPSBhd2FpdCBkYi5xdWVyeSgnU0hPVyBEQVRBQkFTRVMnKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCB7IE1vbmdvQ29sbGVjdGlvbiB9IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9tb25nbydcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLmNvbGxlY3Rpb24nXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmZpbmRgXSAocGx1ZywgcXVlcnkgPSB7fSwgcHJvamVjdGlvbiA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuZmluZChxdWVyeSwge3Byb2plY3Rpb246IHByb2plY3Rpb259KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5hZ2dyZWdhdGVgXSAocGx1ZywgcXVlcnkgPSB7fSkge1xyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbilcclxuICAgIGxldCByZXMgPSBhd2FpdCBjb2xsLmFnZ3JlZ2F0ZShxdWVyeSkudG9BcnJheSgpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uLy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLml0ZW1zJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvKipcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+OCs+ODrOOCr+OCt+ODp+ODs+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOBvuOBmeOAglxyXG4gICAqIEBwYXJhbVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LnNldEltYWdlYF0gKHBsdWcsIHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpXHJcbiAgICBsZXQgdXBsb2FkZWQgPSBhd2FpdCBpdGVtY29uLnNldEltYWdlKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxLCBjbGFzczIpXHJcbiAgICByZXR1cm4gdXBsb2FkZWRcclxuICB9LFxyXG5cclxuICAvKipcclxuICAgKiDjgqLjgqTjg4bjg6Dmg4XloLHjg4fjg7zjgr/jg5njg7zjgrnjga7nlLvlg4/nmbvpjLLjgpLliYrpmaTjgZnjgovvvIjnlLvlg4/oh6rkvZPjga/liYrpmaTjgZfjgarjgYTvvIlcclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5jbGVhbkltYWdlYF0gKHBsdWcsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGF3YWl0IGl0ZW1jb24uY2xlYW5JbWFnZShtb2RlbCwgY2xhc3MxLCBjbGFzczIpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCB7XHJcbiAgQ3ViZTNBcGlcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvY3ViZTNhcGknXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnY3ViZSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDlnKjluqvmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlU3RvY2tgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgbGV0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKVxyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQilcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICflnKjluqvjga7mm7TmlrAnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVVBEQVRFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgIGF3YWl0IGFwaS51cGRhdGVTdG9jayhpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCwgcXVhbnRpdHkpXHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHnmbvpjLLjgajmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgIGxldCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQilcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpXHJcblxyXG4gICAgbGV0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+OBuOOBruWVhuWTgeeZu+mMsicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ0lOU0VSVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGluc2VydFJlcyA9IGF3YWl0IGFwaS5wcm9kdWN0Q3JlYXRlKGN1YmVJdGVtKVxyXG5cclxuICAgICAgICAgICAgICAvLyBpdGVtIOODh+ODvOOCv+ODmeODvOOCueOBuOOBrueZu+mMslxyXG4gICAgICAgICAgICAgIGF3YWl0IGNvbC51cGRhdGUoe1xyXG4gICAgICAgICAgICAgICAgX2lkOiBpdGVtLl9pZFxyXG4gICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AnOiBpbnNlcnRSZXMucmVzXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+WVhuWTgeaDheWgseOBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RJbWFnZVVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ3Rvb2wnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnRlc3RgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG5cclxuICAgIGNvbnN0IG5ld0xvY2FsID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe30sIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgIHRocm93IGVcclxuICAgIH0pXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg5XjgqPjg6vjgr/jg7zjg4bjgrnjg4gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIG5ld0xvY2FsXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgUGFja2V0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9wYWNrZXQnXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IGljb252IGZyb20gJ2ljb252LWxpdGUnXHJcbmltcG9ydCBhcmNoaXZlciBmcm9tICdhcmNoaXZlcidcclxuaW1wb3J0IGNzdiBmcm9tICdjc3YnXHJcbmltcG9ydCB7IFBhc3NUaHJvdWdoLCBUcmFuc2Zvcm0gfSBmcm9tICdzdHJlYW0nXHJcblxyXG5jb25zdCBwcmVmaXggPSAncGFja2V0J1xyXG5jb25zdCB0YWcgPSAneWF1Y3QnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Y+X5rOo44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm9yZGVyYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44Ok44OV44Kq44Kv5Y+X5rOoJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vb3JkZXJgXHJcbiAgICAgICAgY29uc3QgciA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlckxvYWRmaWxlfWApXHJcbiAgICAgICAgY29uc3QgdyA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJTYXZlZmlsZX1gKVxyXG4gICAgICAgIGxldCBpID0gMFxyXG4gICAgICAgIHIucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC5waXBlKGNzdi5wYXJzZSh7Y29sdW1uczogdHJ1ZX0pKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnRyYW5zZm9ybShcclxuICAgICAgICAgICAgYXN5bmMgKHJlY29yZCwgY2FsbGJhY2spID0+IHtcclxuICAgICAgICAgICAgICBsZXQgZXJyID0gbnVsbFxyXG4gICAgICAgICAgICAgIC8vIOeuoeeQhueVquWPt+OCkue9ruOBjeaPm+OBiOOCi1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICByZWNvcmRbJ+euoeeQhueVquWPtyddID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0TW9kZWxDbGFzcyhyZWNvcmRbJ+euoeeQhueVquWPtyddKVxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGVyciA9IGVcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgY2FsbGJhY2soZXJyLCByZWNvcmQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICkpXHJcbiAgICAgICAgICAucGlwZShjc3Yuc3RyaW5naWZ5KHtoZWFkZXI6IHRydWV9KSlcclxuICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLnBpcGUodylcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Ye65ZOB44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliaXRgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lh7rlk4EnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDnubDjgorov5TjgZflh6bnkIbjgpLku7vmhI/jga7vvIhwYWNrZXRTaXpl77yJ44Gn5YiG5YmyXHJcbiAgICAgICAgY29uc3QgcGFja2V0ID0gbmV3IFBhY2tldChjb25maWcucGFja2V0U2l6ZSlcclxuXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44KS5L2c5oiQ44GX55S75YOP44OH44O844K/44KS5Y+O6ZuG44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS93b3JrYFxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEucmVtb3ZlKHdvcmtkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG5cclxuICAgICAgICAvLyBaSVDjg5XjgqHjgqTjg6vjgpLkv53lrZjjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB1cGxvYWRkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vdXBsb2FkYFxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEucmVtb3ZlKHVwbG9hZGRpcilcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHVwbG9hZGRpcilcclxuXHJcbiAgICAgICAgbGV0IGNkID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jjg5Xjgqnjg6vjg4BcclxuICAgICAgICBsZXQgZmlsZW5hbWUgPSBudWxsIC8vIGNzduODleOCoeOCpOODq1xyXG4gICAgICAgIGxldCBuYW1lID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jnlarlj7dcclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kj44O844Or44OJ44KS5a6a576p44GX44CB6aCG55Wq44KS56K65a6a44GZ44KLXHJcbiAgICAgICAgbGV0IGZpZWxkcyA9IFsn566h55CG55Wq5Y+3JywgJ+OCq+ODhuOCtOODqicsICfjgr/jgqTjg4jjg6snLCAn6Kqs5piOJywgJ+OCueODiOOCouWGheWVhuWTgeaknOe0oueUqOOCreODvOODr+ODvOODiScsICfplovlp4vkvqHmoLwnLCAn5Y2z5rG65L6h5qC8JywgJ+WApOS4i+OBkuS6pOa4iScsICflgIvmlbAnLCAn5YWl5pyt5YCL5pWw5Yi26ZmQJywgJ+acn+mWkycsICfntYLkuobmmYLplpMnLCAn5ZWG5ZOB55m66YCB5YWD44Gu6YO96YGT5bqc55yMJywgJ+WVhuWTgeeZuumAgeWFg+OBruW4guWMuueUuuadkScsICfpgIHmlpnosqDmi4UnLCAn5Luj6YeR5YWI5omV44GE44CB5b6M5omV44GEJywgJ+iQveacreODiuODk+axuua4iOaWueazleioreWumicsICfllYblk4Hjga7nirbmhYsnLCAn5ZWG5ZOB44Gu54q25oWL5YKZ6ICDJywgJ+i/lOWTgeOBruWPr+WQpicsICfov5Tlk4Hjga7lj6/lkKblgpnogIMnLCAn55S75YOPMScsICfnlLvlg48x44Kz44Oh44Oz44OIJywgJ+eUu+WDjzInLCAn55S75YOPMuOCs+ODoeODs+ODiCcsICfnlLvlg48zJywgJ+eUu+WDjzPjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNCcsICfnlLvlg48044Kz44Oh44Oz44OIJywgJ+eUu+WDjzUnLCAn55S75YOPNeOCs+ODoeODs+ODiCcsICfnlLvlg482JywgJ+eUu+WDjzbjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNycsICfnlLvlg48344Kz44Oh44Oz44OIJywgJ+eUu+WDjzgnLCAn55S75YOPOOOCs+ODoeODs+ODiCcsICfnlLvlg485JywgJ+eUu+WDjznjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMTAnLCAn55S75YOPMTDjgrPjg6Hjg7Pjg4gnLCAn5pyA5L2O6KmV5L6hJywgJ+aCquipleWJsuWQiOWItumZkCcsICflhaXmnK3ogIXoqo3oqLzliLbpmZAnLCAn6Ieq5YuV5bu26ZW3JywgJ+aXqeacn+e1guS6hicsICfllYblk4Hjga7oh6rli5Xlho3lh7rlk4EnLCAn6Ieq5YuV5YCk5LiL44GSJywgJ+acgOS9juiQveacreS+oeagvCcsICfjg4Hjg6Pjg6rjg4bjgqPjg7wnLCAn5rOo55uu44Gu44Kq44O844Kv44K344On44OzJywgJ+WkquWtl+ODhuOCreOCueODiCcsICfog4zmma/oibInLCAn44K544OI44Ki44Ob44OD44OI44Kq44O844Kv44K344On44OzJywgJ+ebrueri+OBoeOCouOCpOOCs+ODsycsICfotIjnrZTlk4HjgqLjgqTjgrPjg7MnLCAnVOODneOCpOODs+ODiOOCquODl+OCt+ODp+ODsycsICfjgqLjg5XjgqPjg6rjgqjjgqTjg4jjgqrjg5fjgrfjg6fjg7MnLCAn6I2354mp44Gu5aSn44GN44GVJywgJ+iNt+eJqeOBrumHjemHjycsICfjga/jgZNCT09OJywgJ+OBneOBruS7lumFjemAgeaWueazlTEnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTInLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTMnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTQnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTUnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTYnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTcnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTgnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTknLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTEwJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+a1t+WklueZuumAgScsICfphY3pgIHmlrnms5Xjg7vpgIHmlpnoqK3lrponLCAn5Luj5byV5omL5pWw5paZ6Kit5a6aJywgJ+a2iOiyu+eojuioreWumicsICdKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ11cclxuICAgICAgICBsZXQgaGVhZGVyID0gZmllbGRzLm1hcCh2ID0+IGBcIiR7dn1cImApLmpvaW4oJywnKSArICdcXG4nXHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMlumWi+Wni+aZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldFN0YXJ0ID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBuYW1lID0gcHJlZml4ICsgKCcwMDAwMCcgKyBwYWNrZXRDb3VudCkuc2xpY2UoLTUpXHJcbiAgICAgICAgICBjZCA9IGAke3dvcmtkaXJ9LyR7bmFtZX1gXHJcbiAgICAgICAgICBmaWxlbmFtZSA9IGAke2NkfS8ke2NvbmZpZy5jc3ZGaWxlTmFtZX1gXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNkKVxyXG4gICAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44Gr44OV44Kj44O844Or44OJ44KS6Kit5a6a44GZ44KLXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShoZWFkZXIsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMluaZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldCA9IGFzeW5jIChhcmcpID0+IHtcclxuICAgICAgICAgIGxldCB5YXVjdCA9IGFyZy55YXVjdFxyXG4gICAgICAgICAgbGV0IGl0ZW0gPSBhcmcuaXRlbVxyXG4gICAgICAgICAgLy8gY3N244OV44Kh44Kk44Or44Gr44Os44Kz44O844OJ77yI5ZWG5ZOB44OG44Oz44OX44Os44O844OI77yJ44KS6L+95Yqg44GZ44KLXHJcbiAgICAgICAgICBsZXQgcmVjb3JkID0gZmllbGRzLm1hcCh2ID0+IHsgcmV0dXJuIHlhdWN0W3ZdID8gYFwiJHt5YXVjdFt2XX1cImAgOiAnXCJcIicgfSkuam9pbignLCcpICsgJ1xcbidcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKHJlY29yZCwgJ1NoaWZ0X0pJUycpKVxyXG4gICAgICAgICAgLy8g55S75YOP44OV44Kh44Kk44Or44KS44Kz44OU44O8XHJcbiAgICAgICAgICBmb3IgKGxldCBpbWcgb2YgaXRlbS5pbWFnZXMpIHtcclxuICAgICAgICAgICAgbGV0IGltZ1NyYyA9IGAke2NvbmZpZy5pbWFnZWRpcn0vJHtpbWd9YFxyXG4gICAgICAgICAgICBsZXQgaW1nVGd0ID0gYCR7Y2R9LyR7aW1nfWBcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAvLyDlkIzjgZjjg5XjgqHjgqTjg6vjgYzjgYLjgovloLTlkIjjga/jgrPjg5Tjg7zjgZfjgarjgYRcclxuICAgICAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFjY2VzcyhpbWdUZ3QpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBhd2FpdCBmc0V4dHJhLmNvcHlGaWxlKGltZ1NyYywgaW1nVGd0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jntYLkuobmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXRFbmQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHppcCA9IGFyY2hpdmVyKCd6aXAnKVxyXG4gICAgICAgICAgY29uc3QgemlwbmFtZSA9IGAke3VwbG9hZGRpcn0vJHtuYW1lfS56aXBgXHJcbiAgICAgICAgICBjb25zdCBvdXRwdXQgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKHppcG5hbWUpXHJcbiAgICAgICAgICB6aXAucGlwZShvdXRwdXQpXHJcbiAgICAgICAgICB6aXAuZGlyZWN0b3J5KGNkLCBmYWxzZSlcclxuICAgICAgICAgIHppcC5maW5hbGl6ZSgpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg6HjgqTjg7Pjg6vjg7zjg5dcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdUQVJHRVQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgLy8gaXRlbeOBq+Wumue+qeOBleOCjOOBpuOBhOOCi+acgOS9juW/heimgeWcqOW6q+OCiOOCiuWkmuOBhOWVhuWTgeOCkuWHuuWTgeOBmeOCi1xyXG4gICAgICAgICAgICBpZiAocXVhbnRpdHkgPj0gaXRlbS5tYWxsLnlhdWN0Lm1pblF1YW50aXR5KSB7XHJcbiAgICAgICAgICAgICAgbGV0IHlhdWN0ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1ZYXVjdChjb25maWcuZGVmYXVsdCwgaXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBwYWNrZXQuc3VibWl0KHt5YXVjdDogeWF1Y3QsIGl0ZW06IGl0ZW19KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcGFja2V0LmNsb3NlKClcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2NvbGxlY3Rpb24vY29uZmlncydcclxuXHJcbmltcG9ydCAnLi9yb3V0ZS91cGxvYWQvaW1hZ2UnXHJcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuIFxyXG5leHBvcnQgY29uc3QgQ29uZmlncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb25maWdzJyx7aWRHZW5lcmF0aW9uOidNT05HTyd9KTtcclxuXHJcbi8vIE1ldGVvci5tZXRob2RzKHsgXHJcbi8vICAgYXN5bmMgJ215c3FsU2VydmVycy5pbnNlcnQnICggbmV3U2VydmVyICl7XHJcbi8vICAgICByZXR1cm4gYXdhaXQgTXlzcWxTZXJ2ZXJzLmluc2VydChuZXdTZXJ2ZXIpO1xyXG4vLyAgIH1cclxuLy8gfSk7XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0JztcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnO1xyXG5pbXBvcnQgeyBHcm91cEJhc2UgfSBmcm9tICcuL2dyb3Vwcyc7XHJcblxyXG5jb25zdCBGaWx0ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZpbHRlcnMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZpbHRlciBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGZpbHRlcklkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBGaWx0ZXJzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGZpbHRlcklkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcblxyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKCBvblJlc3VsdCA9IChyZWNvcmQpPT57fSwgb25FcnJvciA9IChlKT0+e30gKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGxhdGZvcm0gdHlwZScpO1xyXG5cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7eyBmaWx0ZXJUeXBlOiBhc3luYyAocmVjb3JkICkgPT4ge30gfX0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoKGNhbGxiYWNrcyA9IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGUoKTtcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICB0eXBlOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnQgPSB7fTtcclxuICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgY291bnRbZmlsdGVyLnR5cGVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmaWx0ZXIucXVlcnksXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCk9PntcclxuICAgICAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgICAgICBsZXQgcXVlcnkgPSBtb2JqZWN0LnVuZXNjYXBlKGZpbHRlci5xdWVyeSk7XHJcbiAgICAgICAgICBsZXQgZXhhbSA9IHNpZnQoIHF1ZXJ5ICk7XHJcbiAgICAgICAgICBpZiggZXhhbShyZWNvcmQpICl7XHJcbiAgICAgICAgICAgIGNvdW50W2ZpbHRlci50eXBlXS5jb3VudCsrO1xyXG4gICAgICAgICAgICBpZiggdHlwZW9mIGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFja3NbZmlsdGVyLnR5cGVdKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBvbkVycm9yXHJcbiAgICApO1xyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnQ7XHJcblxyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbmNvbnN0IEdyb3VwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdncm91cHMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwQmFzZSB7XHJcblxyXG4gIHByb2ZpbGU7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb2ZpbGUpIHtcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBnZXRzICdQbHVnJyB3aXRjaCBpcyBhIHNldCBvZiBwcm9wZXJ0aWVzIG5lZWRlZFxyXG4gICAqIHdoZW4gY29ubmVjdCB0byBzb21lIHBsYXRmb3Jtc1xyXG4gICAqIHRvIGdldCBkYXRhcyhNZW1iZXJzIG9mIHRoZSBHcm91cClcclxuICAgKi9cclxuICBnZXRQbHVnKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZS5wbGF0Zm9ybVBsdWc7XHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZTtcclxuICB9XHJcblxyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge307XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXAgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihncm91cElkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBHcm91cHMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZ3JvdXBJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKGRvYykgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX0gV0hFUkUgXFxgJHtkb2Mua2V5fVxcYCA9IFwiJHtkb2MuaWR9XCJgO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBncm91cCB0eXBlJyk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7YXN5bmMgKHJlY29yZCk9PnZvaWR9IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IGN1ciA9IEdyb3Vwcy5maW5kKHtcclxuICAgICAgZ3JvdXBJZDogdGhpcy5wcm9maWxlLl9pZFxyXG4gICAgfSwge1xyXG4gICAgICBmaWVsZHM6IHtcclxuICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAga2V5OiAxXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGN1ci5mb3JFYWNoKFxyXG4gICAgICAgICAgYXN5bmMgKGRvYywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVjb3JkID0gYXdhaXQgdGhpcy5pbXBvcnQoZG9jKTtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFjayhyZWNvcmQpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgb25FcnJvcihlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaW5kZXggKyAxID09PSBjdXIuY291bnQoKSkge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICB9XHJcbiAgICApLmNhdGNoKFxyXG4gICAgICAoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbiBcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2Fkcycse2lkR2VuZXJhdGlvbjonTU9OR08nfSk7XHJcblxyXG4iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5cclxuZXhwb3J0IGNsYXNzIEN1YmUzQXBpIHtcclxuICBjb25zdHJ1Y3RvciAobXlzcWwgPSBuZXcgTXlTUUwoKSkge1xyXG4gICAgdGhpcy5teXNxbF8gPSBteXNxbFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHByb2R1Y3RDbGFzc0lkLCBxdWFudGl0eSA9IDApIHtcclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcclxuICAgICAge30sIHtcclxuICAgICAgICBzdG9jazogcXVhbnRpdHksXHJcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJyxcclxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXHJcbiAgICAgIHt9LCB7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RUYWdVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDliYrpmaTjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvZmYgPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDooajnpLrjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvbiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgLy8g44GZ44Gn44Gr6KGo56S644GV44KM44Gm44GE44KL44K/44Kw44GM44GC44KM44Gw5L2V44KC44GX44Gq44GEXHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIFNFTEVDVCBDT1VOVCgqKSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgbGV0IGNvdW50UmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKVxyXG4gICAgICBpZiAoY291bnRSZXNbMF1bJ0NPVU5UKCopJ10pIHJldHVyblxyXG5cclxuICAgICAgcmVzLnB1c2goXHJcbiAgICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAnZHRiX3Byb2R1Y3RfdGFnJyxcclxuICAgICAgICAgIHt9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBkYXRhLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgICAgIHRhZzogdGFnLFxyXG4gICAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKSlcclxuICAgIH1cclxuXHJcbiAgICBmb3IgKGxldCB0YWdTZXQgb2YgZGF0YS50YWdzKSB7XHJcbiAgICAgIHN3aXRjaCAodGFnU2V0LnNldCkge1xyXG4gICAgICAgIGNhc2UgJ29uJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29uKHRhZ1NldC50YWcpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICAgIGNhc2UgJ29mZic6XHJcbiAgICAgICAgICBhd2FpdCB0YWdvZmYodGFnU2V0LnRhZylcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdEltYWdlVXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgcHJvZHVjdElkID0gZGF0YS5wcm9kdWN0X2lkXHJcbiAgICBsZXQgaW1hZ2VzID0gZGF0YS5pbWFnZXNcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDllYblk4HjgavplqLpgKPjgZnjgovjgZnjgbnjgabjga7nlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgotcclxuICAgIGxldCBzcWwgPSBgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfaW1hZ2UgV0hFUkUgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdElkfWBcclxuICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbCkpXHJcblxyXG4gICAgLy8g5pS544KB44Gm55S75YOP44KS55m76Yyy44GX44Gq44GK44GZXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAnZHRiX3Byb2R1Y3RfaW1hZ2UnLCB7XHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICBmaWxlX25hbWU6IGltYWdlc1tpXSxcclxuICAgICAgICAgIHJhbms6IGkgKyAxXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdFVwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fVxyXG4gICAgbGV0IGtleXMgPSBbXVxyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0XHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3N0YXR1cycsXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ25vdGUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fbGlzdCcsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnLFxyXG4gICAgICAnc2VhcmNoX3dvcmQnLFxyXG4gICAgICAnZnJlZV9hcmVhJ1xyXG4gICAgXVxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RfY2xhc3NcclxuXHJcbiAgICB1cGRhdGVEYXRhID0ge31cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdkZWxpdmVyeV9kYXRlX2lkJyxcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdzYWxlX2xpbWl0JyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RDcmVhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBsZXQga2V5cyA9IFtdXHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJ1xyXG4gICAgXVxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiBpdGVtLm5hbWUsXHJcbiAgICAvLyAgIGRlc2NyaXB0aW9uX2RldGFpbDogaXRlbS5kZXNjcmlwdGlvbixcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgc3RhdHVzOiAxLFxyXG4gICAgICAgIG5vdGU6ICdOVUxMJyxcclxuICAgICAgICBkZXNjcmlwdGlvbl9saXN0OiAnTlVMTCcsXHJcbiAgICAgICAgc2VhcmNoX3dvcmQ6ICdOVUxMJyxcclxuICAgICAgICBmcmVlX2FyZWE6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAncHJvZHVjdF9jb2RlJyxcclxuICAgICAgJ3Byb2R1Y3RfdHlwZV9pZCcsXHJcbiAgICAgICdwcmljZTAxJyxcclxuICAgICAgJ3ByaWNlMDInLFxyXG4gICAgICAnZGVsaXZlcnlfZmVlJ1xyXG4gICAgXVxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBwcm9kdWN0X2NvZGU6IGl0ZW0ubW9kZWwsXHJcbiAgICAvLyAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxyXG4gICAgLy8gICBwcmljZTAyOiBpdGVtLnNhbGVzX3ByaWNlLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfY2xhc3NfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBwcm9kdWN0X2lkOiByZXMucHJvZHVjdF9pZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQxOiAnTlVMTCcsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQyOiAnTlVMTCcsXHJcbiAgICAgICAgZGVsaXZlcnlfZGF0ZV9pZDogJ05VTEwnLFxyXG4gICAgICAgIHNhbGVfbGltaXQ6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X3N0b2NrX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsIHt9LCB7XHJcbiAgICAgICAgcHJvZHVjdF9jbGFzc19pZDogcmVzLnByb2R1Y3RfY2xhc3NfaWQsXHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBmb3IgdGVzdFxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJ1xyXG5pbXBvcnQge01vbmdvQ2xpZW50fSBmcm9tICdtb25nb2RiJ1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCdcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnXHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXJGYWN0b3J5IHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgbGV0IGluc3RhbmNlXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgaW5zdGFuY2UgPSBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBpbnN0YW5jZVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgdGhpcy5wbHVnID0gcGx1Z1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZhY3RvcnkgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICByZXR1cm4gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSlcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGx1ZyB0eXBlJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldFBsdWdfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnBsdWdcclxuICB9XHJcblxyXG4gIGdldENyZWRfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnBsdWcuY3JlZFxyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZV8gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZVxyXG4gIH1cclxuXHJcbiAgc2V0SW1wb3J0RnVuY3Rpb25fIChcclxuICAgIGZuID0gYXN5bmMgKG9uUmVzdWx0ID0gcmVjb3JkID0+IHt9LCBvbkVycm9yID0gZSA9PiB7fSkgPT4ge31cclxuICApIHtcclxuICAgIHRoaXMuaW1wb3J0ID0gZm5cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIHVzZWFnZTpcclxuICAgKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHsgT2JqZWN0IH0gaXRlcmF0b3JzIHsgZmlsdGVyTmFtZTogYXN5bmMgKGRvYyxjb250ZXh0KT0+e30sIC4uLiB9IGl0ZXJhdG9yIGZvciBlYWNoIGZpbHRlcnNcclxuICAgKiBAcGFyYW0geyBhc3luYyBmdW5jdGlvbiB9IG9uRXJyb3IgZXJyb3IgaGFuZGxlciB3aGlsZSBpdGVyYXRpbmdcclxuICAgKiBAcmV0dXJucyB7IE9iamVjdCB9IHsgZmlsdGVyTmFtZTogeyBxdWVyeTogYW55LCBjb3VudDogbnVtYmVyIH0sIC4uLiB9XHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaCAoaXRlcmF0b3JzID0ge30pIHtcclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlXygpXHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgbmFtZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ZXIgPSB7fVxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgZmlsdGVycyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgICAgY291bnRlcltmLm5hbWVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmLnF1ZXJ5LFxyXG4gICAgICAgIGxpbWl0OiB0eXBlb2YgZi5saW1pdCAhPT0gJ3VuZGVmaW5lZCcgPyBmLmxpbWl0IDogMCxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9XHJcbiAgICAgIGZpbHRlcnMucHVzaChcclxuICAgICAgICB7XHJcbiAgICAgICAgICBuYW1lOiBmLm5hbWUsXHJcbiAgICAgICAgICBleGFtOiBzaWZ0KG1vYmplY3QudW5lc2NhcGUoZi5xdWVyeSkpXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQsIGNvbnRleHQpID0+IHtcclxuICAgICAgICBmb3IgKGxldCBmIG9mIGZpbHRlcnMpIHtcclxuICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgbGV0IGMgPSBjb3VudGVyW2YubmFtZV1cclxuICAgICAgICAgIGlmIChjLmxpbWl0KSB7XHJcbiAgICAgICAgICAgIGlmIChjLmNvdW50ID49IGMubGltaXQpIHtcclxuICAgICAgICAgICAgICBjb250aW51ZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKGYuZXhhbShyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgICBjLmNvdW50KytcclxuXHJcbiAgICAgICAgICAgIC8vIGl0ZXJhdG9yXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlcmF0b3JzW2YubmFtZV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgaXRlcmF0b3JzW2YubmFtZV0ocmVjb3JkLCBjb250ZXh0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnRlclxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE15c3FsREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpXHJcblxyXG4gICAgbGV0IGNyZWQgPSB0aGlzLmdldENyZWRfKClcclxuXHJcbiAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKGNyZWQpXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gXHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIChlKSA9PiB7IHRocm93IGUgfSlcclxuICAgICAgcmV0dXJuIHJlc1xyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBNb25nb05hdGl2ZSBmcm9tICdtb25nb2RiJztcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSBNb25nb05hdGl2ZS5Nb25nb0NsaWVudDtcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSByZXF1aXJlKCdtb25nb2RiJykuTW9uZ29DbGllbnQ7XHJcblxyXG5leHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICAvLyBtb25nbyDjgbjmjqXntppcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICBsZXQgY2xpZW50XHJcbiAgICAgIGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpXHJcblxyXG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcclxuICAgICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICAgIGxldCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pXHJcblxyXG4gICAgICBsZXQgY29udGV4dCA9IHtcclxuICAgICAgICBjbGllbnQ6IGNsaWVudCxcclxuICAgICAgICBjb2xsZWN0aW9uOiBjb2xsZWN0aW9uLFxyXG4gICAgICAgIGRhdGFiYXNlOiBkYlxyXG4gICAgICB9XHJcblxyXG4gICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKClcclxuXHJcbiAgICAgIC8vIOOCq+ODvOOCveODq+OBruOCv+OCpOODoOOCouOCpuODiOOCkuino+mZpFxyXG4gICAgICBjdXIuYWRkQ3Vyc29yRmxhZygnbm9DdXJzb3JUaW1lb3V0JywgdHJ1ZSlcclxuXHJcbiAgICAgIC8vIOOBmeOBueOBpuOBruODieOCreODpeODoeODs+ODiOOCkuODq+ODvOODl1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XHJcbiAgICAgICAgICBsZXQgZG9jID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQoZG9jLCBjb250ZXh0KVxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgLy8g44Kr44O844K944Or44KS6ZaL5pS+XHJcbiAgICAgICAgYXdhaXQgY3VyLmNsb3NlKClcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBtb25nb29zZSBmcm9tICdtb25nb29zZSc7XHJcblxyXG4vLyBleHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuLy8gICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbi8vICAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcclxuXHJcbi8vICAgICAvLyBtb25nbyDjgbjmjqXntppcclxuLy8gICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpO1xyXG4vLyAgICAgbGV0IGNvbnVyaSA9IGBtb25nb2RiOi8vJHtjcmVkLmhvc3R9OiR7Y3JlZC5wb3J0fS8ke2NyZWQuZGF0YWJhc2V9YDtcclxuLy8gICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoY29udXJpKTtcclxuXHJcbi8vICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLkvZzjgotcclxuLy8gICAgIGxldCBjb2xsZWN0aW9uID0gbW9uZ29vc2UuY29ubmVjdGlvbi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XHJcblxyXG4vLyAgICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbi8vICAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKTtcclxuXHJcbi8vICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4vLyAgICAgfSk7XHJcbi8vICAgfVxyXG4vLyB9XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29Db2xsZWN0aW9uXHJcbn0gZnJvbSAnLi4vdXRpbC9tb25nbydcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vY29sbGVjdGlvbi91cGxvYWRzJ1xyXG5pbXBvcnQge1xyXG4gIE9iamVjdElEXHJcbn0gZnJvbSAnYnNvbidcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEl0ZW1Db250cm9sbGVyIHtcclxuICBhc3luYyBpbml0IChwbHVnKSB7XHJcbiAgICB0aGlzLkl0ZW1zID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCAnaXRlbXMnKVxyXG4gICAgdGhpcy5Qcm9kdWN0cyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ3Byb2R1Y3RzJylcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFN0b2NrIChpdGVtSWQpIHtcclxuICAgIGxldCBwcm9qZWN0ID0gYXdhaXQgdGhpcy5JdGVtcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBpdGVtSWRcclxuICAgIH0sIHtcclxuICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICdwcm9kdWN0JzogMVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgbGV0IHByb2R1Y3RQYWNrID0gcHJvamVjdC5wcm9kdWN0XHJcblxyXG4gICAgLy8gcHJvZHVjdCAqIDwtPiAqIGl0ZW1cclxuICAgIC8vIHByb2R1Y3RbXTog6KSH5pWw44Gu5ZWG5ZOB44KSMeODkeODg+OCseODvOOCuOOBqOOBl+OBpuiyqeWjslxyXG4gICAgLy8gcHJvZHVjdFtbXV06IOeVsOOBquOCi+a1gemAmue1jOi3r+OAgeeVsOOBquOCi+WOn+S+oeODu+S7leWFpeOCjOWApFxyXG4gICAgLy8gaXRlbTog55Ww44Gq44KL44K744O844Or44CB6LKp5aOy5b2i5oWLXHJcbiAgICAvLyDigLsgcHJvZHVjdCDjgYvjgonjga/jgIHosqnlo7Llj6/og73jgarlnKjluqvjgIHliKnnm4roqIjnrpfjga7jgZ/jgoHjga7mg4XloLHjgpLlvpfjgotcclxuXHJcbiAgICBsZXQgcXVhbnRpdGllcyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcHJvZHVjdFNrdSBvZiBwcm9kdWN0UGFjaykge1xyXG4gICAgICBsZXQgcXVhbnRpdHlTa3UgPSAwXHJcblxyXG4gICAgICBmb3IgKGxldCBwcm9kdWN0SWQgb2YgcHJvZHVjdFNrdSkge1xyXG4gICAgICAgIGxldCBwcm9qZWN0ID0gYXdhaXQgdGhpcy5Qcm9kdWN0cy5maW5kT25lKHtcclxuICAgICAgICAgIF9pZDogcHJvZHVjdElkXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgICAnc3RvY2snOiAxXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBsZXQgc3RvY2tBcnJheSA9IHByb2plY3Quc3RvY2tcclxuXHJcbiAgICAgICAgLy8g5Y2Y57SU44Gr44GZ44G544Gm44Gu5Zyo5bqr5ZWG5ZOB44CB55+t5pyf6ZaT5Y+W44KK5a+E44Gb5Y+v6IO95ZWG5ZOB44KS5ZCI566XXHJcbiAgICAgICAgZm9yIChsZXQgc3RvY2sgb2Ygc3RvY2tBcnJheSkge1xyXG4gICAgICAgICAgcXVhbnRpdHlTa3UgKz0gc3RvY2sucXVhbnRpdHlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHF1YW50aXRpZXMucHVzaChxdWFudGl0eVNrdSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDjgrvjg4Pjg4jllYblk4Hjga7loLTlkIjjgIHkuIDnlarlsJHjgarjgYTllYblk4HmlbDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBxdWFudGl0eSA9IE1hdGgubWluLmFwcGx5KG51bGwsIHF1YW50aXRpZXMpXHJcblxyXG4gICAgcmV0dXJuIHF1YW50aXR5XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44KL44CCXHJcbiAgICpcclxuICAgKiDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6vjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcclxuICAgKiBjbGFzczHjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOeJueWumuOBruWxnuaAp++8iOOCq+ODqeODvOOBquOBqe+8ieOBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOBq+WApOOCkuaMh+WumuOBl+OAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqIOOCguOBl2NsYXNzMuOBruOBv+aMh+WumuOBl+OBn+OBhOWgtOWQiOOBr2NsYXNzMeOBq251bGzjgpLmjIflrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS+i++8mkpLLTEwMOOBrkJMQUNL44Gu5ZWG5ZOB55S75YOP44KSXHJcbiAgICog44GZ44G544Gm44Gu44K144Kk44K677yIUyxNLEwsWEwsMlhMLDNYTCw0WEzigKbvvInjgavplqLpgKPku5jjgZHjgovloLTlkIhcclxuICAgKiBzZXRJbWFnZSggdXBsb2FkSWQsICdKSy0xMDAnLCAnQkxBQ0snICk7XHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdXBsb2FkSWQg5LiA5Zue44Gu44Ki44OD44OX44Ot44O844OJ55S75YOP44KS5p2f44Gt44Gm44GE44KLSUTjgIJtZXRlb3Ljg4fjg7zjgr/jg5njg7zjgrnjgIFVcGxvYWRz44Kz44Os44Kv44K344On44Oz5YaF44OJ44Kt44Ol44Oh44Oz44OI44GudXBsb2FkSWTjg5fjg63jg5Hjg4bjgqNcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIHNldEltYWdlICh1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OBruaDheWgseWPluW+l1xyXG4gICAgbGV0IGltYWdlcyA9IFVwbG9hZHMuZmluZCh7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZFxyXG4gICAgfSkuZmV0Y2goKS5tYXAoKHYpID0+IHYudXBsb2FkZWRGaWxlTmFtZSlcclxuXHJcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcclxuICAgIGxldCBmaWx0ZXIgPSB7fVxyXG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWxcclxuICAgIGlmIChjbGFzczEpIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczFcclxuICAgIGlmIChjbGFzczIpIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczJcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxyXG4gICAgICBmaWx0ZXIsIHtcclxuICAgICAgICAkcHVzaDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiB7XHJcbiAgICAgICAgICAgICRlYWNoOiBpbWFnZXNcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyDnmbvpjLLjgZfjgZ/nlLvlg4/jg5XjgqHjgqTjg6vlkI3kuIDopqdcclxuICAgIHJldHVybiBpbWFnZXNcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavnmbvpjLLjgZXjgozjgabjgYTjgovnlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgY2xlYW5JbWFnZSAobW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlciwge1xyXG4gICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgIGltYWdlczogW11cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBruWVhuWTgeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBruWxnuaAp+WIpeOBruWVhuWTgeaDheWgseOCkui/lOOBmeOAglxyXG4gICAqXHJcbiAgICog5byV5pWw44Go44GX44Gm5Y+X44GR5Y+W44KLaXRlbeOBr+S7u+aEj+OBruWVhuWTgeaDheWgseOAglxyXG4gICAqIGl0ZW3jgavplqLpgKPjgZnjgovllYblk4HnvqTjgavjgaTjgYTjgablv4XopoHjgarmg4XloLHjgpLmlbTnkIbjgZfov5TjgZnjgIJcclxuICAgKlxyXG4gICAqIHByb2plY3Tjgavlj4LnhafjgZfjgZ/jgYTllYblk4Hmg4XloLHjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZnjgovjgIJcclxuICAgKiDjg6Hjgr3jg4Pjg4njga7lkbzjgbPlh7rjgZfmmYLjgavlv4XopoHjgavlv5zjgZjjgaZwcm9qZWN044KS6Kit5a6a44GZ44KL44CCXHJcbiAgICpcclxuICAgKiDkvZXjgavms6jnm67jgZfjgabllYblk4Hjga7plqLpgKPmgKfjgpLmpJzlh7rjgZnjgovjgYvjga/jgIHjgZPjga7jg6Hjgr3jg4Pjg4nlhoXjgaflrprnvqnjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBpdGVtXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHByb2plY3RcclxuICAgKi9cclxuICBhc3luYyBnZXRWYXJpYXRpb24gKGl0ZW0sIHByb2plY3QpIHtcclxuICAgIC8qKlxyXG4gICAgICogYWdncmVnYXRpb27oqK3lrppcclxuICAgICAqXHJcbiAgICAgKiBsYWJlbDog5bGe5oCn5ZCN77yI6YWN6YCB5pa55rOV44CB44Kr44Op44O844CB44K144Kk44K644Gq44Gp77yJXHJcbiAgICAgKiBjdXJyZW50OiDmjIflrprjgZXjgozjgZ/jgqLjgqTjg4bjg6DvvIhpdGVt77yJ44GM6Kmy5b2T44GZ44KL6aCF55uuXHJcbiAgICAgKiBwb3JqZWN0OiDjg5Djg6rjgqjjg7zjgrfjg6fjg7PmpJzntKLjga7jgq3jg7zjgajjgarjgotpdGVt5YaF44Gu44OV44Kj44O844Or44OJ5ZCNICRb44OV44Kj44O844Or44OJ5ZCNXeW9ouW8j1xyXG4gICAgICogcXVlcnk6IGFnZ3JlZ2F0aW9u5a++6LGh44Go44GZ44KL44OJ44Kt44Ol44Oh44Oz44OI44Gu5qSc57Si5p2h5Lu2XHJcbiAgICAgKi9cclxuICAgIGxldCBzZXQgPSBbe1xyXG4gICAgICBsYWJlbDogJ+mFjemAgeaWueazlScsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRkZWxpdmVyeSdcclxuICAgICAgfSxcclxuICAgICAgcXVlcnk6IHtcclxuICAgICAgICBjbGFzczFfdmFsdWU6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxyXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MxX25hbWUsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckY2xhc3MxX3ZhbHVlJ1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MyX25hbWUsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MyX3ZhbHVlLFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckY2xhc3MyX3ZhbHVlJ1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgXVxyXG5cclxuICAgIGxldCBhdHRycyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcyBvZiBzZXQpIHtcclxuICAgICAgYXR0cnMucHVzaCh7XHJcbiAgICAgICAgdmFyaWF0aW9uczogYXdhaXQgdGhpcy5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbe1xyXG4gICAgICAgICAgICAkbWF0Y2g6IE9iamVjdC5hc3NpZ24ocy5xdWVyeSwge1xyXG4gICAgICAgICAgICAgIG1vZGVsOiBpdGVtLm1vZGVsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAkcHJvamVjdDogT2JqZWN0LmFzc2lnbihzLnByb2plY3QsIHByb2plY3QpXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAkc29ydDoge1xyXG4gICAgICAgICAgICAgIF9pZDogMVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKS50b0FycmF5KCksXHJcbiAgICAgICAgcHJvcHM6IHNcclxuICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gYXR0cnNcclxuICB9XHJcblxyXG4gIC8vIOODouODh+ODq+OCr+ODqeOCueW9ouW8j+OCkuS9nOOCi1xyXG4gIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cclxuICBhc3luYyBnZXRNb2RlbENsYXNzIChhcmcpIHtcclxuICAgIGxldCBpdGVtXHJcbiAgICAvLyBpdGVtIOOBjOaWh+Wtl+WIl+OBquOCieOAgWl0ZW3jga/ku7vmhI/jga7jgqrjg5bjgrjjgqfjgq/jg4hJROOBruacq+WwvuOBi+OCieS7u+aEj+OBruahgeaVsOOBrjE26YCy5pWwXHJcbiAgICBpZiAodHlwZW9mIGFyZyA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgbGV0IGV4cCA9IG5ldyBSZWdFeHAoYCR7YXJnfSRgKVxyXG4gICAgICBsZXQgY3VyID0gdGhpcy5JdGVtcy5maW5kKHt9LCB7XHJcbiAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgbW9kZWw6IDEsXHJcbiAgICAgICAgICBjbGFzczFfdmFsdWU6IDEsXHJcbiAgICAgICAgICBjbGFzczJfdmFsdWU6IDFcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICB3aGlsZSAoMSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBpdGVtID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICAgICAgbGV0IG1hdGNoID0gYXdhaXQgaXRlbS5faWQudG9IZXhTdHJpbmcoKS5tYXRjaChleHApXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyDoqbLlvZPjgZnjgotpdGVt44OH44O844K/44GM44Gq44GEXHJcbiAgICAgICAgICByZXR1cm4gYXJnXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpdGVtID0gYXJnXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuICAgIHJldHVybiBtb2RlbENsYXNzLmpvaW4oJy8nKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlMyAoY3JlYXRvcklkLCBpdGVtKSB7XHJcbiAgICAvLyDlgKTlpInmj5tcclxuICAgIGxldCBjb252RGVsaXYgPSAoZGVsaXZlcnkpID0+IGRlbGl2ZXJ5ID09PSAn44KG44GG44OR44Kx44OD44OIJyA/ICfjg53jgrnjg4jmipXlh70nIDogZGVsaXZlcnlcclxuXHJcbiAgICAvLyBwcm9kdWN0X2lkXHJcbiAgICBsZXQgcHJvZHVjdElkID0gbnVsbFxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG5cclxuICAgIC8vIOS4i+iomOOBruW9ouW8j+OCkuS9nOOCi1xyXG4gICAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuXHJcbiAgICAvLyDllYblk4HnqK7liKXjgpLlibLjgorlvZPjgabjgotcclxuICAgIGxldCBwcm9kdWN0VHlwZUlkXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDJcclxuICAgICAgICBicmVha1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCB0YWdzID0gW11cclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeWIpemAgeaWmeOCkuioreWumuOBmeOCi1xyXG4gICAgbGV0IGRlbGl2ZXJ5RmVlID0gbnVsbFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBudWxsXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICBkZWxpdmVyeUZlZSA9IDI0MFxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy9cclxuICAgIC8vIOmhp+WuouWQkeOBkeODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgemBuOaKnuapn+iDveOBruWun+ijhVxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6ICckbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJ1xyXG4gICAgfSlcclxuXHJcbiAgICAvLyBIVE1MIOODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgeOBlOOBqOOBruODquODs+OCr+S7mOOBjeODnOOCv+ODs+OCkuihqOekuuOBmeOCi1xyXG5cclxuICAgIC8vIOWApOOBruWkieaPm1xyXG4gICAgYXR0cnMgPSBhdHRycy5tYXAoXHJcbiAgICAgIChhdHRyKSA9PiB7XHJcbiAgICAgICAgYXR0ci5wcm9wcy5jdXJyZW50ID0gY29udkRlbGl2KGF0dHIucHJvcHMuY3VycmVudClcclxuICAgICAgICBhdHRyLnZhcmlhdGlvbnMgPSBhdHRyLnZhcmlhdGlvbnMubWFwKFxyXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xyXG4gICAgICAgICAgICB2YXJpYXRpb24udmFsdWUgPSBjb252RGVsaXYodmFyaWF0aW9uLnZhbHVlKVxyXG4gICAgICAgICAgICByZXR1cm4gdmFyaWF0aW9uXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIHJldHVybiBhdHRyXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBIVE1M55Sf5oiQXHJcbiAgICBsZXQgdmFyaWF0aW9uSHRtbCA9XHJcbiAgICAgIGF0dHJzLm1hcChcclxuICAgICAgICAoYXR0cikgPT5cclxuICAgICAgICAgICc8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWZsdWlkXCI+JyArXHJcbiAgICAgICAgYDxkaXYgY2xhc3M9XCJyb3dcIj5gICtcclxuICAgICAgICBgPGRpdiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLWJsb2NrIGJ0bi14c1wiPmAgK1xyXG4gICAgICAgIGA8c3Ryb25nPiR7YXR0ci5wcm9wcy5sYWJlbH08L3N0cm9uZz5gICtcclxuICAgICAgICBgPC9kaXY+YCArXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgaWYgKGF0dHIucHJvcHMuY3VycmVudCA9PT0gdmFyaWF0aW9uLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YSBocmVmPVwiL3Byb2R1Y3RzL2RldGFpbC8ke3ZhcmlhdGlvbi5wcm9kdWN0X2lkfVwiPjxidXR0b24gY2xhc3M9XCJidG4gYnRuLXN1Y2Nlc3MgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPjxzdHJvbmc+JHt2YXJpYXRpb24udmFsdWV9PC9zdHJvbmc+PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICByZXR1cm4gYDxhIGhyZWY9XCIvcHJvZHVjdHMvZGV0YWlsLyR7dmFyaWF0aW9uLnByb2R1Y3RfaWR9XCI+PGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICkuam9pbignJykgK1xyXG4gICAgICAgICc8L2Rpdj4nICtcclxuICAgICAgICAnPC9kaXY+J1xyXG4gICAgICApLmpvaW4oJycpXHJcblxyXG4gICAgbGV0IGRlc2NyaXB0aW9uRGV0YWlsID0gYFxyXG4gICAgPHNtYWxsPuKAuyDphY3pgIHmlrnms5Xjg7vjgqvjg6njg7zjg7vjgrXjgqTjgrrjga/kuIvoqJjjgYvjgonjgYrpgbjjgbPjgY/jgaDjgZXjgYTjgII8L3NtYWxsPlxyXG4gICAgPHNtYWxsIGNsYXNzPVwidGV4dC1kYW5nZXJcIj7igLsg5Zyo5bqr44GM44Gq44GE5ZWG5ZOB44Gu5aC05ZCI44CM44Oa44O844K444GM6KaL44Gk44GL44KK44G+44Gb44KT44CN44Go6KGo56S644GV44KM44G+44GZ44CCPC9zbWFsbD5cclxuICAgICR7dmFyaWF0aW9uSHRtbH1cclxuICAgIGBcclxuXHJcbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcclxuICAgIGxldCBkYXRhID0ge1xyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7Y29udkRlbGl2KGl0ZW0uZGVsaXZlcnkpfSAke2l0ZW0ubmFtZX0gJHtpdGVtLmphbl9jb2RlfWAsXHJcbiAgICAgIGRlc2NyaXB0aW9uX2RldGFpbDogZGVzY3JpcHRpb25EZXRhaWwsXHJcbiAgICAgIGZyZWVfYXJlYTogaXRlbS5kZXNjcmlwdGlvbiArICcgJyxcclxuICAgICAgcHJvZHVjdF9jb2RlOiBtb2RlbENsYXNzLmpvaW4oJy8nKSxcclxuICAgICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UgKiAwLjk1LCAvLyDmpb3lpKnkvqHmoLzjgYvjgok1JeWApOW8leOBjVxyXG4gICAgICBpbWFnZXM6IGl0ZW0uaW1hZ2VzLFxyXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RUeXBlSWQsXHJcbiAgICAgIHRhZ3M6IHRhZ3MsXHJcbiAgICAgIGRlbGl2ZXJ5X2ZlZTogZGVsaXZlcnlGZWVcclxuICAgIH1cclxuXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcClcclxuXHJcbiAgICByZXR1cm4gZGF0YVxyXG4gIH1cclxuXHJcbiAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44G444Gu5aSJ5o+bXHJcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdCAoZGVmLCBpdGVtKSB7XHJcbiAgICBsZXQgeWF1Y3QgPSB7fVxyXG4gICAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44Gu5Yid5pyf5YCk77yI44KG44GG44OR44Kx44OD44OI44O75a6F6YWN5L6/44Gn55Ww44Gq44KL77yJXHJcbiAgICB5YXVjdCA9IGRlZltpdGVtLmRlbGl2ZXJ5XVxyXG5cclxuICAgIC8vIOeUu+WDj+OBruiomOi/sFxyXG4gICAgY29uc3QgaW1nUHJlZml4ID0gJ+eUu+WDjydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgeWF1Y3RbaW1nUHJlZml4ICsgKGkgKyAxKV0gPSBpdGVtLmltYWdlc1tpXVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCv+OCpOODiOODq1xyXG4gICAgeWF1Y3RbJ+OCq+ODhuOCtOODqiddID0gaXRlbS5tYWxsLnlhdWN0LmNhdGVnb3J5XHJcbiAgICB5YXVjdFsn44K/44Kk44OI44OrJ10gPSBgJHthd2FpdCB0aGlzLmdldE1vZGVsQ2xhc3MoaXRlbSl9ICR7aXRlbS5kZWxpdmVyeX0gJHtpdGVtLm5hbWV9YFxyXG4gICAgeWF1Y3RbJ+mWi+Wni+S+oeagvCddID0gaXRlbS5zYWxlc19wcmljZVxyXG4gICAgeWF1Y3RbJ+WNs+axuuS+oeagvCddID0gaXRlbS5zYWxlc19wcmljZVxyXG4gICAgeWF1Y3RbJ+euoeeQhueVquWPtyddID0gaXRlbS5faWQudG9IZXhTdHJpbmcoKS5zbGljZSgtMjApXHJcbiAgICB5YXVjdFsn6Kqs5piOJ10gPSBpdGVtLmRlc2NyaXB0aW9uXHJcbiAgICB5YXVjdFsnSkFO44Kz44O844OJ44O7SVNCTuOCs+ODvOODiSddID0gaXRlbS5qYW5fY29kZVxyXG5cclxuICAgIHJldHVybiB5YXVjdFxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyB1dGlsRXJyb3Ige1xyXG4gIHN0YXRpYyBwYXJzZSAoZSkge1xyXG4gICAgbGV0IHJlcyA9IHt9XHJcblxyXG4gICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICByZXMubWVzc2FnZSA9IGUubWVzc2FnZVxyXG4gICAgICByZXMubmFtZSA9IGUubmFtZVxyXG4gICAgICByZXMuZmlsZU5hbWUgPSBlLmZpbGVOYW1lXHJcbiAgICAgIHJlcy5saW5lTnVtYmVyID0gZS5saW5lTnVtYmVyXHJcbiAgICAgIHJlcy5jb2x1bW5OdW1iZXIgPSBlLmNvbHVtbk51bWJlclxyXG4gICAgICByZXMuc3RhY2sgPSBlLnN0YWNrXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXMgPSBlXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInXHJcblxyXG5leHBvcnQgY2xhc3MgTW9uZ29Db2xsZWN0aW9uIHtcclxuICBzdGF0aWMgYXN5bmMgZ2V0IChwbHVnLCBjb2xsZWN0aW9uKSB7XHJcbiAgICBsZXQgY2xpZW50ID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSlcclxuICAgIGxldCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKVxyXG4gICAgcmV0dXJuIGRiLmNvbGxlY3Rpb24oY29sbGVjdGlvbilcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IG15c3FsIGZyb20gJ215c3FsJ1xyXG5pbXBvcnQgbW9tZW50IGZyb20gJ21vbWVudCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE15U1FMIHtcclxuICBjb25zdHJ1Y3RvciAocHJvZmlsZSkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz44OX44O844Or5Yid5pyf5YyWXHJcbiAgICB0aGlzLnBvb2wgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGUpXHJcblxyXG4gICAgLy8g6KSH5pWw6KGM44K544OG44O844OI44Oh44Oz44OI5a++5b+cXHJcbiAgICBsZXQgcHJvZmlsZU11bHRpID0ge211bHRpcGxlU3RhdGVtZW50czogdHJ1ZX1cclxuICAgIE9iamVjdC5hc3NpZ24ocHJvZmlsZU11bHRpLCBwcm9maWxlKVxyXG4gICAgdGhpcy5wb29sTXVsdGkgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGVNdWx0aSlcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmb3JtYXREYXRlIChkYXRlKSB7XHJcbiAgICByZXR1cm4gbW9tZW50KGRhdGUpLmZvcm1hdCgpLnN1YnN0cmluZygwLCAxOSkucmVwbGFjZSgnVCcsICcgJylcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNxbFxyXG4gICAqL1xyXG4gIHF1ZXJ5IChzcWwpIHtcclxuICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+eiuueri1xyXG4gICAgLy8gbGV0IGNvbiA9IGF3YWl0IHRoaXMuZ2V0Q29uKCk7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxyXG4gICAgICAudGhlbihcclxuICAgICAgICAoY29uKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcclxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsLCAoZSwgcmVzKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7PplovmlL5cclxuICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgIGlmIChlKSB7XHJcbiAgICAgICAgICAgICAgICAgIHJlamVjdChlKVxyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHJlc29sdmUocmVzKVxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZVxyXG4gICAgICB9KVxyXG4gIH07XHJcblxyXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0XyAoc3FsKSB7XHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzLmluc2VydElkXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB0YWJsZVxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvOOAgW51bGzjgIFqYXZhc2NyaXB0LT5teXNxbOaXpeS7mOWkieaPm+OBq+OCguWvvuW/nFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhU3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xyXG4gICAqL1xyXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0ICh0YWJsZSwgZGF0YSA9IHt9LCBkYXRhU3FsID0ge30pIHtcclxuICAgIC8vIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XHJcbiAgICAvLyByZXR1cm4gcmVzLmluc2VydElkO1xyXG5cclxuICAgIGxldCBzcWwgPSBgSU5TRVJUIElOVE8gJHt0YWJsZX0gYFxyXG5cclxuICAgIGxldCBtYXAgPSBuZXcgTWFwKClcclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YSkpIHtcclxuICAgICAgaWYgKGRhdGFba10gPT09IG51bGwpIHtcclxuICAgICAgICBtYXAuc2V0KGssICdOVUxMJylcclxuICAgICAgfSBlbHNlIGlmIChkYXRhW2tdLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgIG1hcC5zZXQoaywgYFwiJHtNeVNRTC5mb3JtYXREYXRlKGRhdGFba10pfVwiYClcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICBtYXAuc2V0KGssIGAke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGFTcWwpKSB7XHJcbiAgICAgIG1hcC5zZXQoaywgZGF0YVNxbFtrXSA9PT0gbnVsbCA/ICdOVUxMJyA6IGRhdGFTcWxba10pXHJcbiAgICB9XHJcblxyXG4gICAgc3FsICs9IGAoICR7Wy4uLm1hcC5rZXlzKCldLmpvaW4oJywnKX0gKSBgXHJcblxyXG4gICAgc3FsICs9IGBWQUxVRVMoICR7Wy4uLm1hcC52YWx1ZXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzLmluc2VydElkXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB0YWJsZVxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBmaWx0ZXIgU1FMIFVQREFUReOCueODhuODvOODiOODoeODs+ODiOOBrldIRVJF5Y+lXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O8XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlVcGRhdGUgKHRhYmxlLCBmaWx0ZXIsIGRhdGEsIGRhdGFTcWwpIHtcclxuICAgIGxldCBzcWwgPSBgVVBEQVRFICR7dGFibGV9IFNFVCBgXHJcblxyXG4gICAgbGV0IHVwZGF0ZXMgPSBbXVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtteXNxbC5lc2NhcGUoZGF0YVtrXSl9YClcclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgdXBkYXRlcy5wdXNoKGAke2t9PSR7ZGF0YVNxbFtrXX1gKVxyXG4gICAgfVxyXG4gICAgc3FsICs9IHVwZGF0ZXMuam9pbignLCcpXHJcblxyXG4gICAgc3FsICs9IGAgV0hFUkUgJHtmaWx0ZXJ9IGBcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICAvLyBlbmFibGUgdG8gdXNlIG11bHRpcGxlIHN0YXRlbWVudHNcclxuICBhc3luYyBxdWVyeU11bHRpIChzcWwpIHtcclxuICAgIGxldCBwb29sU3dhcCA9IHRoaXMucG9vbFxyXG4gICAgdGhpcy5wb29sID0gdGhpcy5wb29sTXVsdGlcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgICAgcmV0dXJuIHJlc1xyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgdGhpcy5wb29sID0gcG9vbFN3YXBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHN0YXJ0VHJhbnNhY3Rpb24gKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgU1RBUlQgVFJBTlNBQ1RJT047YClcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbW1pdCAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBDT01NSVQ7YClcclxuICB9XHJcblxyXG4gIGFzeW5jIHJvbGxiYWNrICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYFJPTExCQUNLO2ApXHJcbiAgfVxyXG5cclxuICBzdHJlYW1pbmdRdWVyeSAoc3FsLCBvblJlc3VsdCA9IChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gKGUpID0+IHt9KSB7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxyXG4gICAgICAudGhlbihcclxuICAgICAgICAoY29uKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgICAgIGFzeW5jIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcclxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsKVxyXG4gICAgICAgICAgICAgICAgLm9uKCdyZXN1bHQnLFxyXG4gICAgICAgICAgICAgICAgICAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uLnBhdXNlKClcclxuICAgICAgICAgICAgICAgICAgICBvblJlc3VsdChyZWNvcmQpXHJcbiAgICAgICAgICAgICAgICAgICAgY29uLnJlc3VtZSgpXHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2Vycm9yJywgKGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgb25FcnJvcihlKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZW5kJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpXHJcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUoKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfVxyXG5cclxuICBnZXRDb24gKCkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgLy8g44OX44O844Or44GL44KJ44Gu44Kz44ON44Kv44K344On44Oz542y5b6XXHJcbiAgICAgICAgdGhpcy5wb29sLmdldENvbm5lY3Rpb24oKGUsIGNvbikgPT4ge1xyXG4gICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICByZXNvbHZlKGNvbilcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgICAgIC5jYXRjaChcclxuICAgICAgICAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gIH07XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGFja2V0IHtcclxuICBjb25zdHJ1Y3RvciAocGFja2V0U2l6ZSkge1xyXG4gICAgdGhpcy5wYWNrZXRTaXplID0gcGFja2V0U2l6ZVxyXG4gICAgdGhpcy5vblBhY2tldFN0YXJ0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldCA9IG51bGxcclxuICAgIHRoaXMub25QYWNrZXRFbmQgPSBudWxsXHJcbiAgICB0aGlzLmNvdW50ID0gMFxyXG4gICAgdGhpcy5wYWNrZXRDb3VudCA9IDBcclxuICB9XHJcblxyXG4gIGFzeW5jIHN1Ym1pdCAoYXJnKSB7XHJcbiAgICAvLyBwYWNrZXRTaXpl44Gu5Zue5pWw44GU44Go44Gr44CB5Yid5pyf5YyW44KS5ZG844Gz5Ye644GZXHJcbiAgICBpZiAodGhpcy5jb3VudCAlIHRoaXMucGFja2V0U2l6ZSA9PT0gMCkge1xyXG4gICAgICBpZiAodGhpcy5vblBhY2tldFN0YXJ0KSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5vblBhY2tldFN0YXJ0KHRoaXMucGFja2V0Q291bnQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLm9uUGFja2V0KSB7XHJcbiAgICAgIGF3YWl0IHRoaXMub25QYWNrZXQoYXJnKVxyXG4gICAgfVxyXG4gICAgdGhpcy5jb3VudCsrXHJcbiAgICAvLyBwYWNrZXRTaXpl44Gu5Zue5pWw44GU44Go44Gr44CB57WC5LqG5Yem55CG44KS5ZG844Gz5Ye644GZXHJcbiAgICBpZiAodGhpcy5jb3VudCAlIHRoaXMucGFja2V0U2l6ZSA9PT0gMCkge1xyXG4gICAgICBpZiAodGhpcy5vblBhY2tldEVuZCkge1xyXG4gICAgICAgIGF3YWl0IHRoaXMub25QYWNrZXRFbmQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgICB0aGlzLnBhY2tldENvdW50KytcclxuICAgIH1cclxuICB9XHJcbiAgY2xvc2UgKCkge1xyXG4gICAgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdXRpbEVycm9yIGZyb20gJy4vZXJyb3InXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVwb3J0IHtcclxuICBjb25zdHJ1Y3RvciAoKSB7XHJcbiAgICB0aGlzLnJlY29yZCA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9ycyA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgc2V0dXBJdGVyYXRvciAoKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbmV3IEl0ZXJhdG9yKClcclxuICAgIHRoaXMuaXRlcmF0b3JzLnB1c2godGhpcy5pdGVyYXRvcilcclxuICB9XHJcblxyXG4gIGFzeW5jIHBoYXNlIChuYW1lID0gJycsIGZuID0gYXN5bmMgKCkgPT4ge30pIHtcclxuICAgIHRoaXMuc2V0dXBJdGVyYXRvcigpXHJcblxyXG4gICAgbGV0IHJlYyA9IHt9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGZuKClcclxuXHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogcmVzXHJcbiAgICAgIH0pXHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHV0aWxFcnJvci5wYXJzZShlKVxyXG4gICAgICB9KVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgaWYgKHRoaXMuaXRlcmF0b3IudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3JcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMucmVjb3JkLnB1c2gocmVjKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaVN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5zdWNjZXNzKG5ld1JlY29yZClcclxuICB9XHJcblxyXG4gIGlFcnJvciAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLmVycm9yKHV0aWxFcnJvci5wYXJzZShuZXdSZWNvcmQpKVxyXG4gIH1cclxuXHJcbiAgZXJyb3JPY3VycmVkICgpIHtcclxuICAgIGxldCBpdGVFcnJvciA9IHRoaXMuaXRlcmF0b3JzLmZpbmQoZSA9PiBlLmVycm9yT2N1cnJlZCgpKVxyXG4gICAgbGV0IHBoYUVycm9yID0gZmFsc2VcclxuICAgIGZvciAobGV0IHJlYyBvZiB0aGlzLnJlY29yZCkge1xyXG4gICAgICBpZiAocmVjLnR5cGUgPT09ICdlcnJvcicpIHtcclxuICAgICAgICBwaGFFcnJvciA9IHRydWVcclxuICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXRlRXJyb3IgfHwgcGhhRXJyb3JcclxuICB9XHJcblxyXG4gIHB1Ymxpc2ggKCkge1xyXG4gICAgaWYgKHRoaXMuZXJyb3JPY3VycmVkKCkpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcih0aGlzLnJlY29yZClcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnJlY29yZFxyXG4gIH1cclxufVxyXG5cclxuY2xhc3MgSXRlcmF0b3Ige1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMudG90YWwgPSAwXHJcbiAgICB0aGlzLnRyYWNlID0ge1xyXG4gICAgICBzdWNjZXNzOiB7XHJcbiAgICAgICAgdG90YWw6IDAsXHJcbiAgICAgICAgcmVjb3JkczogW11cclxuICAgICAgfSxcclxuICAgICAgZXJyb3I6IHtcclxuICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICByZWNvcmRzOiBbXVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdWNjZXNzIChuZXdSZWNvcmQpIHtcclxuICAgIGlmIChuZXdSZWNvcmQpIHtcclxuICAgICAgdGhpcy50cmFjZS5zdWNjZXNzLnJlY29yZHMucHVzaChuZXdSZWNvcmQpXHJcbiAgICB9XHJcbiAgICB0aGlzLnRyYWNlLnN1Y2Nlc3MudG90YWwrK1xyXG4gICAgdGhpcy50b3RhbCsrXHJcbiAgfVxyXG4gIGVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIC8vIOebtOWJjeOBruOCqOODqeODvOOCkuWPluW+l1xyXG4gICAgbGV0IGxhc3RFcnJvciA9IG51bGxcclxuICAgIGxldCBpbmRleCA9IHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkcy5sZW5ndGhcclxuICAgIGlmIChpbmRleCkge1xyXG4gICAgICBsYXN0RXJyb3IgPSB0aGlzLnRyYWNlLmVycm9yLnJlY29yZHNbaW5kZXggLSAxXVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOebtOWJjeOBqOWQjOOBmOOCqOODqeODvOOBr+ecgeOBj1xyXG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KGxhc3RFcnJvcikgIT09IEpTT04uc3RyaW5naWZ5KG5ld1JlY29yZCkpIHtcclxuICAgICAgaWYgKG5ld1JlY29yZCAmJiBuZXdSZWNvcmQgIT09IHt9ICYmIG5ld1JlY29yZCAhPT0gJycpIHtcclxuICAgICAgICB0aGlzLnRyYWNlLmVycm9yLnJlY29yZHMucHVzaChuZXdSZWNvcmQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHRoaXMudHJhY2UuZXJyb3IudG90YWwrK1xyXG4gICAgdGhpcy50b3RhbCsrXHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQgKCkge1xyXG4gICAgcmV0dXJuIHRoaXMudHJhY2UuZXJyb3IudG90YWxcclxuICB9XHJcbn1cclxuIl19
