var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/route/upload/image.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube/cubemig.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 3);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 4);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 5);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let couponCd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let couponName = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discountPrice = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: couponCd,
                coupon_type: 3,
                // 全商品
                coupon_name: couponName,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discountPrice,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                customer_id: record.customer_id,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
        return res;
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/collection.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
      return res;
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.aggregate(query).toArray());
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let ItemController;
module.watch(require("../../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/service/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 5);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  //
  // 商品情報登録と更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              let quantity = Promise.await(itemController.getStock(item._id));
              Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/tooltest.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      const newLocal = Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
        throw e;
      })));
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return newLocal;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/wowma.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
let PassThrough, Transform;
module.watch(require("stream"), {
  PassThrough(v) {
    PassThrough = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 9);
let request;
module.watch(require("request-promise"), {
  default(v) {
    request = v;
  }

}, 10);
const tag = 'wowma';
Meteor.methods({
  //
  // WOWMA商品情報取得
  [`${tag}.getItem`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('WOWMA! 商品情報取得', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // APIから取得した商品情報を保存する場所


        const workdir = `${config.workdir}/items_${new Date().getTime()}`; // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(workdir));
        } catch (e) {} // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let options = JSON.parse(JSON.stringify(config.wowmaApi));
            options.uri = `${options.uri}/searchItemInfo`;
            options.qs.itemCode = item.mall.wowma.itemCode;
            let repos = Promise.await(request(options));
            let filename = `${workdir}/${item.model}.xml`;
            Promise.await(fsExtra.writeFile(filename, repos));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  [`${tag}.setDelivery`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('WOWMA! 配送方法登録', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // APIから取得した商品情報を保存する場所


        const workdir = `${config.workdir}/items_${new Date().getTime()}`; // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(workdir));
        } catch (e) {} // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let options = JSON.parse(JSON.stringify(config.wowmaApi));
            options.uri = `${options.uri}/searchItemInfo`;
            options.qs.itemCode = item.mall.wowma.itemCode;
            let repos = Promise.await(request(options));
            let filename = `${workdir}/${item.model}.xml`;
            Promise.await(fsExtra.writeFile(filename, repos));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/yauct.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
let PassThrough, Transform;
module.watch(require("stream"), {
  PassThrough(v) {
    PassThrough = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 9);
const prefix = 'packet';
const tag = 'yauct';
Meteor.methods({
  //
  // ヤフオク受注ファイル
  [`${tag}.order`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク受注', () => Promise.asyncApply(() => {
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        const workdir = `${config.workdir}/order`;
        const r = fsExtra.createReadStream(`${workdir}/${config.orderLoadfile}`);
        const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`);
        r.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
          columns: true
        })).pipe(csv.transform((record, callback) => Promise.asyncApply(() => {
          let err = null; // 管理番号を置き換える

          try {
            record['管理番号'] = Promise.await(itemController.getModelClass(record['管理番号']));
          } catch (e) {
            err = e;
          }

          callback(err, record);
        }))).pipe(csv.stringify({
          header: true
        })).pipe(iconv.decodeStream('UTF-8')).pipe(iconv.encodeStream('SJIS')).pipe(w);
      })));
    });
  },

  //
  // ヤフオク出品ファイル
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク出品', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 繰り返し処理を任意の（packetSize）で分割

        const packet = new Packet(config.packetSize); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // CSVファイルを作成し画像データを収集する場所


        const workdir = `${config.workdir}/work`;
        Promise.await(fsExtra.remove(workdir));
        Promise.await(fsExtra.mkdir(workdir)); // ZIPファイルを保存する場所

        const uploaddir = `${config.workdir}/upload`;
        Promise.await(fsExtra.remove(uploaddir));
        Promise.await(fsExtra.mkdir(uploaddir));
        let cd = null; // パケットフォルダ

        let filename = null; // csvファイル

        let name = null; // パケット番号
        // CSVフィールドを定義し、順番を確定する

        let fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
        let header = fields.map(v => `"${v}"`).join(',') + '\n'; // パケット化開始時

        packet.onPacketStart = packetCount => Promise.asyncApply(() => {
          name = prefix + ('00000' + packetCount).slice(-5);
          cd = `${workdir}/${name}`;
          filename = `${cd}/${config.csvFileName}`;
          Promise.await(fsExtra.mkdir(cd)); // CSVファイルにフィールドを設定する

          Promise.await(fsExtra.appendFile(filename, iconv.encode(header, 'Shift_JIS')));
        }); // パケット化時


        packet.onPacket = arg => Promise.asyncApply(() => {
          let yauct = arg.yauct;
          let item = arg.item; // csvファイルにレコード（商品テンプレート）を追加する

          let record = fields.map(v => {
            return yauct[v] ? `"${yauct[v]}"` : '""';
          }).join(',') + '\n';
          Promise.await(fsExtra.appendFile(filename, iconv.encode(record, 'Shift_JIS'))); // 画像ファイルをコピー

          for (let img of item.images) {
            let imgSrc = `${config.imagedir}/${img}`;
            let imgTgt = `${cd}/${img}`;

            try {
              // 同じファイルがある場合はコピーしない
              Promise.await(fsExtra.access(imgTgt));
            } catch (e) {
              Promise.await(fsExtra.copyFile(imgSrc, imgTgt));
            }
          }
        }); // パケット終了時


        packet.onPacketEnd = packetCount => Promise.asyncApply(() => {
          const zip = archiver('zip');
          const zipname = `${uploaddir}/${name}.zip`;
          const output = fsExtra.createWriteStream(zipname);
          zip.pipe(output);
          zip.directory(cd, false);
          zip.finalize();
        }); // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id)); // itemに定義されている最低必要在庫より多い商品を出品する

            if (quantity >= item.mall.yauct.minQuantity) {
              let yauct = Promise.await(itemController.convertItemYauct(config.default, item));
              Promise.await(packet.submit({
                yauct: yauct,
                item: item
              }));
            }
          })
        }));
        packet.close();
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/configs.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/filters.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/groups.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/uploads.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/cube3api.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  updateStock(productClassId, quantity = 0) {
    return Promise.asyncApply(() => {
      Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      }));
      Promise.await(this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      }));
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = []; // 削除するタグ

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      }); // 表示するタグ


      let tagon = tag => Promise.asyncApply(() => {
        // すでに表示されているタグがあれば何もしない
        let sql = `
      SELECT COUNT(*) FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        let countRes = Promise.await(this.mysql_.query(sql));
        if (countRes[0]['COUNT(*)']) return;
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creatorId,
          create_date: 'NOW()'
        })));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let productId = data.product_id;
      let images = data.images;
      let creatorId = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${productId}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        Promise.await(this.mysql_.queryInsert('dtb_product_image', {
          product_id: productId,
          creator_id: creatorId,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        }));
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let updateData = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      Promise.await(this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      })); // dtb_product_class

      updateData = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      let res = Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      }));
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = {};
      let updateData = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', updateData, {
        creator_id: creatorId,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      updateData = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', updateData, {
        creator_id: creatorId,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creatorId,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/dbfilter.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 3);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 4);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case 'mysql':
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    switch (plug.type) {
      case 'mysql':
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error('invalid plug type');
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   *
   *
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== 'undefined') {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      let res = Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
      return res;
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find(); // カーソルのタイムアウトを解除

      cur.addCursorFlag('noCursorTimeout', true); // すべてのドキュメントをループ

      try {
        while (Promise.await(cur.hasNext())) {
          let doc = Promise.await(cur.next());
          Promise.await(onResult(doc, context));
        }

        ;
      } finally {
        // カーソルを開放
        Promise.await(cur.close());
      }
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/items.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);
let ObjectID;
module.watch(require("bson"), {
  ObjectID(v) {
    ObjectID = v;
  }

}, 2);
let TextUtil;
module.watch(require("../util/text"), {
  default(v) {
    TextUtil = v;
  }

}, 3);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(itemId) {
    return Promise.asyncApply(() => {
      let project = Promise.await(this.Items.findOne({
        _id: itemId
      }, {
        projection: {
          'product': 1
        }
      }));
      let productPack = project.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[[]]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let productSku of productPack) {
        let quantitySku = 0;

        for (let productId of productSku) {
          let project = Promise.await(this.Products.findOne({
            _id: productId
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stockArray = project.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stockArray) {
            quantitySku += stock.quantity;
          }
        }

        quantities.push(quantitySku);
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   *
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   *
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   *
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   *
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   *
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }
  /**
   * 指定の商品に関連する商品群の属性別の商品情報を返す。
   *
   * 引数として受け取るitemは任意の商品情報。
   * itemに関連する商品群について必要な情報を整理し返す。
   *
   * projectに参照したい商品情報フィールドを定義する。
   * メソッドの呼び出し時に必要に応じてprojectを設定する。
   *
   * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
   *
   * @param {Object} item
   * @param {Object} project
   */


  getVariation(item, project) {
    return Promise.asyncApply(() => {
      /**
       * aggregation設定
       *
       * label: 属性名（配送方法、カラー、サイズなど）
       * current: 指定されたアイテム（item）が該当する項目
       * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
       * query: aggregation対象とするドキュメントの検索条件
       */
      let set = [{
        label: '配送方法',
        current: item.delivery,
        project: {
          value: '$delivery'
        },
        query: {
          class1_value: item.class1_value,
          class2_value: item.class2_value
        }
      }, {
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          delivery: item.delivery,
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          delivery: item.delivery,
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }, {
            $sort: {
              _id: 1
            }
          }]).toArray()),
          props: s
        });
      }

      for (let attr of attrs) {
        for (let v of attr.variations) {
          v.stock = Promise.await(this.getStock(v._id));
        }
      }

      return attrs;
    });
  } // モデルクラス形式を作る
  // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]


  getModelClass(arg) {
    return Promise.asyncApply(() => {
      let item; // item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

      if (typeof arg === 'string') {
        let exp = new RegExp(`${arg}$`);
        let cur = this.Items.find({}, {
          projection: {
            model: 1,
            class1_value: 1,
            class2_value: 1
          }
        });

        while (1) {
          try {
            item = Promise.await(cur.next());
            let match = Promise.await(item._id.toHexString().match(exp));

            if (match) {
              break;
            }
          } catch (e) {
            // 該当するitemデータがない
            cur.close();
            return arg;
          }
        }

        cur.close();
      } else {
        item = arg;
      }

      let modelClass = [];
      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value);
      return modelClass.join('/');
    });
  }

  convertItemCube3(creatorId, item) {
    return Promise.asyncApply(() => {
      // 値変換
      let convDeliv = delivery => delivery === 'ゆうパケット' ? 'ポスト投函' : delivery; // product_id


      let productId = null;
      let modelClass = []; // 下記の形式を作る
      // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]

      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let productTypeId;

      switch (item.delivery) {
        case '宅配便':
          productTypeId = 1;
          break;

        case 'ゆうパケット':
          productTypeId = 2;
          break;

        default:
          productTypeId = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let deliveryFee = null;

      switch (item.delivery) {
        case '宅配便':
          deliveryFee = null;
          break;

        case 'ゆうパケット':
          deliveryFee = 240;
          break;
      } //
      // 顧客向けバリエーション商品選択機能の実装
      //


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      })); // HTML バリエーション商品ごとのリンク付きボタンを表示する
      // 値の変換

      attrs = attrs.map(attr => {
        attr.props.current = convDeliv(attr.props.current);
        attr.variations = attr.variations.map(variation => {
          variation.value = convDeliv(variation.value);
          return variation;
        });
        return attr;
      }); // HTML生成

      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row">` + `<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">` + `<strong>${attr.props.label}</strong>` + `</div>` + attr.variations.map(variation => {
        if (attr.props.current === variation.value) {
          // 表示中の商品ボタン
          return `<button class="btn btn-success btn-sm btn-item-class-select"><strong>${variation.value}</strong></button>`;
        } else if (variation.stock > 0) {
          // 販売可能商品のボタン
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-sm btn-item-class-select">${variation.value}</button></a>`;
        } else {
          // 販売不可能商品のボタン（在庫なし）
          return `<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">${variation.value}</button>`;
        }
      }).join('') + '</div>' + '</div>').join('');
      let descriptionDetail = `
    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>
    ${variationHtml}
    `; // 商品データを作る

      let data = {
        product_id: productId,
        creator_id: creatorId,
        name: `${modelClass.join('/')} ${convDeliv(item.delivery)} ${item.name} ${item.jan_code}`,
        description_detail: descriptionDetail,
        free_area: item.description + ' ',
        product_code: modelClass.join('/'),
        price01: item.retail_price,
        price02: item.sales_price * 0.95,
        // 楽天価格から5%値引き
        images: item.images,
        product_type_id: productTypeId,
        tags: tags,
        delivery_fee: deliveryFee
      };
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  } // ヤフオクテンプレートへの変換


  convertItemYauct(def, item) {
    return Promise.asyncApply(() => {
      const idLength = 20;
      const titleLength = 130;
      let yauct = {}; // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）

      yauct = JSON.parse(JSON.stringify(def[item.delivery])); // 画像の記述

      const imgPrefix = '画像';

      for (let i = 0; i < item.images.length; i++) {
        yauct[imgPrefix + (i + 1)] = item.images[i];
      } // タイトル


      yauct['カテゴリ'] = item.mall.yauct.category;
      yauct['タイトル'] = TextUtil.substr8(`${Promise.await(this.getModelClass(item))} ${item.delivery} ${item.name}`, titleLength);
      yauct['開始価格'] = item.sales_price;
      yauct['即決価格'] = item.sales_price;
      yauct['管理番号'] = item._id.toHexString().slice(-idLength);
      yauct['説明'] = item.description;
      yauct['JANコード・ISBNコード'] = item.jan_code;
      return yauct;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/error.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mongo.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mysql.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   *
   * @param {String} sql
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, dataSql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(dataSql)) {
        map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, dataSql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(dataSql)) {
        updates.push(`${k}=${dataSql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/packet.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Packet
});

class Packet {
  constructor(packetSize) {
    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  submit(arg) {
    return Promise.asyncApply(() => {
      // packetSizeの回数ごとに、初期化を呼び出す
      if (this.count % this.packetSize === 0) {
        if (this.onPacketStart) {
          Promise.await(this.onPacketStart(this.packetCount));
        }
      }

      if (this.onPacket) {
        Promise.await(this.onPacket(arg));
      }

      this.count++; // packetSizeの回数ごとに、終了処理を呼び出す

      if (this.count % this.packetSize === 0) {
        this.close();
        this.packetCount++;
      }
    });
  }

  close() {
    if (this.onPacketEnd) {
      this.onPacketEnd(this.packetCount);
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/report.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  setupIterator() {
    this.iterator = new Iterator();
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.setupIterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    // 直前のエラーを取得
    let lastError = null;
    let index = this.trace.error.records.length;

    if (index) {
      lastError = this.trace.error.records[index - 1];
    } // 直前と同じエラーは省く


    if (JSON.stringify(lastError) !== JSON.stringify(newRecord)) {
      if (newRecord && newRecord !== {} && newRecord !== '') {
        this.trace.error.records.push(newRecord);
      }
    }

    this.trace.error.total++;
    this.total++;
  }

  errorOcurred() {
    return this.trace.error.total;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/text.js                                                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => TextUtil
});

class TextUtil {
  static substr8(text, len, truncation) {
    if (truncation === undefined) {
      truncation = '';
    }

    var textArray = text.split('');
    var count = 0;
    var str = '';

    for (let i = 0; i < textArray.length; i++) {
      var n = escape(textArray[i]);
      if (n.length < 4) count++;else count += 2;

      if (count > len) {
        return str + truncation;
      }

      str += text.charAt(i);
    }

    return text;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90b29sdGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIveWF1Y3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vY29uZmlncy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2ZpbHRlcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9ncm91cHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi91cGxvYWRzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvY3ViZTNhcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvZXJyb3IuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9tb25nby5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL215c3FsLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvcGFja2V0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvcmVwb3J0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvdGV4dC5qcyJdLCJuYW1lcyI6WyJmcyIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsImRlZmF1bHQiLCJ2IiwidW5pcWlkIiwibXVsdGlwYXJ0eSIsIlVwbG9hZHMiLCJtdWx0aXBhcnR5TWlkZGxld2FyZSIsInJvdXRlIiwiV2ViQXBwIiwiY29ubmVjdEhhbmRsZXJzIiwidXNlIiwicmVxIiwicmVzcCIsInJlYWRlciIsIk1ldGVvciIsIndyYXBBc3luYyIsInJlYWRGaWxlIiwid3JpdGVyIiwid3JpdGVGaWxlIiwidXBsb2FkSWQiLCJmaWxlIiwiZmlsZXMiLCJkYXRhIiwicGF0aCIsImZpbGVuYW1lIiwic2F2ZVBhdGgiLCJib2R5IiwiaW1hZ2VkaXIiLCJkb2MiLCJjbGllbnRGaWxlTmFtZSIsIm5hbWUiLCJ1cGxvYWRlZEZpbGVOYW1lIiwiZXJyIiwiZXJyb3IiLCJpbnNlcnQiLCJ3cml0ZUhlYWQiLCJlbmQiLCJKU09OIiwic3RyaW5naWZ5Iiwic2F2ZURpciIsImNyeXB0byIsIk15U1FMIiwiUmVwb3J0IiwiR3JvdXAiLCJHcm91cEZhY3RvcnkiLCJGaWx0ZXIiLCJ0YWciLCJtZXRob2RzIiwiY29uZmlnIiwicmVwb3J0IiwiZmlsdGVyIiwic3JjRmlsdGVySWQiLCJ0ZXN0UXVlcnkiLCJkc3REYiIsImRzdCIsImNyZWQiLCJwaGFzZSIsInF1ZXJ5IiwicmVzIiwiZm9yZWFjaCIsIm1vYmlsZU51bGwiLCJyZWNvcmQiLCJzcWwiLCJjdXN0b21lcl9pZCIsInN0YXR1cyIsInNleCIsImpvYiIsImNvdW50cnlfaWQiLCJwcmVmIiwibmFtZTAxIiwibmFtZTAyIiwia2FuYTAxIiwia2FuYTAyIiwiY29tcGFueV9uYW1lIiwiemlwMDEiLCJ6aXAwMiIsInppcGNvZGUiLCJhZGRyMDEiLCJhZGRyMDIiLCJlbWFpbCIsInRlbDAxIiwidGVsMDIiLCJ0ZWwwMyIsImZheDAxIiwiZmF4MDIiLCJmYXgwMyIsImJpcnRoIiwicGFzc3dvcmQiLCJzYWx0Iiwic2VjcmV0X2tleSIsImZpcnN0X2J1eV9kYXRlIiwibGFzdF9idXlfZGF0ZSIsImJ1eV90aW1lcyIsImJ1eV90b3RhbCIsIm5vdGUiLCJjcmVhdGVfZGF0ZSIsInVwZGF0ZV9kYXRlIiwiZGVsX2ZsZyIsInF1ZXJ5SW5zZXJ0IiwiZSIsImlFcnJvciIsImN1c3RvbWVyX2FkZHJlc3NfaWQiLCJpZCIsIm1haWxtYWdhX2ZsZyIsImNvdXBvbkNkIiwicmFuZG9tQnl0ZXMiLCJ0b1N0cmluZyIsInN1YnN0cmluZyIsImNvdXBvbk5hbWUiLCJkaXNjb3VudFByaWNlIiwicG9pbnQiLCJjb3Vwb25faWQiLCJjb3Vwb25fY2QiLCJjb3Vwb25fdHlwZSIsImNvdXBvbl9uYW1lIiwiZGlzY291bnRfdHlwZSIsImNvdXBvbl91c2VfdGltZSIsImNvdXBvbl9yZWxlYXNlIiwiZGlzY291bnRfcHJpY2UiLCJkaXNjb3VudF9yYXRlIiwiZW5hYmxlX2ZsYWciLCJjb3Vwb25fbWVtYmVyIiwiY291cG9uX2xvd2VyX2xpbWl0IiwiYXZhaWxhYmxlX2Zyb21fZGF0ZSIsImF2YWlsYWJsZV90b19kYXRlIiwicHVibGlzaCIsInByb2ZpbGUiLCJkYiIsIk1vbmdvQ29sbGVjdGlvbiIsInBsdWciLCJwcm9qZWN0aW9uIiwiY29sbCIsImdldCIsImNvbGxlY3Rpb24iLCJmaW5kIiwidG9BcnJheSIsImFnZ3JlZ2F0ZSIsIkl0ZW1Db250cm9sbGVyIiwibW9kZWwiLCJjbGFzczEiLCJjbGFzczIiLCJpdGVtY29uIiwiaW5pdCIsInVwbG9hZGVkIiwic2V0SW1hZ2UiLCJjbGVhbkltYWdlIiwiTW9uZ29EQkZpbHRlciIsIkN1YmUzQXBpIiwiaXRlbXNEQiIsIml0ZW1Db250cm9sbGVyIiwidGFyZ2V0REIiLCJjdWJlM0RCIiwiYXBpIiwiaXRlbSIsImNvbnRleHQiLCJxdWFudGl0eSIsImdldFN0b2NrIiwiX2lkIiwidXBkYXRlU3RvY2siLCJtYWxsIiwic2hhcmFrdVNob3AiLCJwcm9kdWN0X2NsYXNzX2lkIiwiY29sIiwiY3ViZUl0ZW0iLCJjb252ZXJ0SXRlbUN1YmUzIiwiY3JlYXRvcl9pZCIsImluc2VydFJlcyIsInByb2R1Y3RDcmVhdGUiLCJ1cGRhdGUiLCIkc2V0IiwiaVN1Y2Nlc3MiLCJwcm9kdWN0SW1hZ2VVcGRhdGUiLCJwcm9kdWN0VXBkYXRlIiwicHJvZHVjdFRhZ1VwZGF0ZSIsIm5ld0xvY2FsIiwiUGFja2V0IiwiZnNFeHRyYSIsImljb252IiwiYXJjaGl2ZXIiLCJjc3YiLCJQYXNzVGhyb3VnaCIsIlRyYW5zZm9ybSIsInJlcXVlc3QiLCJta2RpciIsIndvcmtkaXIiLCJEYXRlIiwiZ2V0VGltZSIsIm9wdGlvbnMiLCJwYXJzZSIsIndvd21hQXBpIiwidXJpIiwicXMiLCJpdGVtQ29kZSIsIndvd21hIiwicmVwb3MiLCJwcmVmaXgiLCJyIiwiY3JlYXRlUmVhZFN0cmVhbSIsIm9yZGVyTG9hZGZpbGUiLCJ3IiwiY3JlYXRlV3JpdGVTdHJlYW0iLCJvcmRlclNhdmVmaWxlIiwicGlwZSIsImRlY29kZVN0cmVhbSIsImVuY29kZVN0cmVhbSIsImNvbHVtbnMiLCJ0cmFuc2Zvcm0iLCJjYWxsYmFjayIsImdldE1vZGVsQ2xhc3MiLCJoZWFkZXIiLCJwYWNrZXQiLCJwYWNrZXRTaXplIiwicmVtb3ZlIiwidXBsb2FkZGlyIiwiY2QiLCJmaWVsZHMiLCJtYXAiLCJqb2luIiwib25QYWNrZXRTdGFydCIsInBhY2tldENvdW50Iiwic2xpY2UiLCJjc3ZGaWxlTmFtZSIsImFwcGVuZEZpbGUiLCJlbmNvZGUiLCJvblBhY2tldCIsImFyZyIsInlhdWN0IiwiaW1nIiwiaW1hZ2VzIiwiaW1nU3JjIiwiaW1nVGd0IiwiYWNjZXNzIiwiY29weUZpbGUiLCJvblBhY2tldEVuZCIsInppcCIsInppcG5hbWUiLCJvdXRwdXQiLCJkaXJlY3RvcnkiLCJmaW5hbGl6ZSIsIm1pblF1YW50aXR5IiwiY29udmVydEl0ZW1ZYXVjdCIsInN1Ym1pdCIsImNsb3NlIiwiZXhwb3J0IiwiQ29uZmlncyIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsImlkR2VuZXJhdGlvbiIsInNpZnQiLCJtb2JqZWN0IiwiR3JvdXBCYXNlIiwiRmlsdGVycyIsImNvbnN0cnVjdG9yIiwiZmlsdGVySWQiLCJmaW5kT25lIiwiZ2V0UGx1ZyIsInR5cGUiLCJteXNxbCIsImltcG9ydCIsIm9uUmVzdWx0Iiwib25FcnJvciIsInRhYmxlIiwic3RyZWFtaW5nUXVlcnkiLCJFcnJvciIsImNhbGxiYWNrcyIsImdldFByb2ZpbGUiLCJmaWx0ZXJzIiwicHVzaCIsImNvdW50IiwidW5lc2NhcGUiLCJleGFtIiwiR3JvdXBzIiwicGxhdGZvcm1QbHVnIiwiZ3JvdXBJZCIsImtleSIsImN1ciIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiZm9yRWFjaCIsImluZGV4IiwiY2F0Y2giLCJteXNxbF8iLCJwcm9kdWN0Q2xhc3NJZCIsInF1ZXJ5VXBkYXRlIiwic3RvY2siLCJzdG9ja191bmxpbWl0ZWQiLCJjcmVhdG9ySWQiLCJ0YWdvZmYiLCJwcm9kdWN0X2lkIiwidGFnb24iLCJjb3VudFJlcyIsInRhZ1NldCIsInRhZ3MiLCJzZXQiLCJwcm9kdWN0SWQiLCJpIiwibGVuZ3RoIiwiZmlsZV9uYW1lIiwicmFuayIsInVwZGF0ZURhdGEiLCJrZXlzIiwiayIsImRlc2NyaXB0aW9uX2xpc3QiLCJzZWFyY2hfd29yZCIsImZyZWVfYXJlYSIsImNsYXNzX2NhdGVnb3J5X2lkMSIsImNsYXNzX2NhdGVnb3J5X2lkMiIsImRlbGl2ZXJ5X2RhdGVfaWQiLCJzYWxlX2xpbWl0IiwicHJvZHVjdF9zdG9ja19pZCIsIkRCRmlsdGVyRmFjdG9yeSIsIkRCRmlsdGVyIiwiTXlzcWxEQkZpbHRlciIsIk1vbmdvQ2xpZW50IiwiaW5zdGFuY2UiLCJmYWN0b3J5IiwiZ2V0UGx1Z18iLCJnZXRDcmVkXyIsImdldFByb2ZpbGVfIiwic2V0SW1wb3J0RnVuY3Rpb25fIiwiZm4iLCJpdGVyYXRvcnMiLCJjb3VudGVyIiwiZiIsImxpbWl0IiwiYyIsImNsaWVudCIsImNvbm5lY3QiLCJkYXRhYmFzZSIsImFkZEN1cnNvckZsYWciLCJoYXNOZXh0IiwibmV4dCIsIk9iamVjdElEIiwiVGV4dFV0aWwiLCJJdGVtcyIsIlByb2R1Y3RzIiwiaXRlbUlkIiwicHJvamVjdCIsInByb2R1Y3RQYWNrIiwicHJvZHVjdCIsInF1YW50aXRpZXMiLCJwcm9kdWN0U2t1IiwicXVhbnRpdHlTa3UiLCJzdG9ja0FycmF5IiwiTWF0aCIsIm1pbiIsImFwcGx5IiwiZmV0Y2giLCJjbGFzczFfdmFsdWUiLCJjbGFzczJfdmFsdWUiLCJ1cGRhdGVNYW55IiwiJHB1c2giLCIkZWFjaCIsImdldFZhcmlhdGlvbiIsImxhYmVsIiwiY3VycmVudCIsImRlbGl2ZXJ5IiwidmFsdWUiLCJjbGFzczFfbmFtZSIsImNsYXNzMl9uYW1lIiwiYXR0cnMiLCJzIiwidmFyaWF0aW9ucyIsIiRtYXRjaCIsIk9iamVjdCIsImFzc2lnbiIsIiRwcm9qZWN0IiwiJHNvcnQiLCJwcm9wcyIsImF0dHIiLCJleHAiLCJSZWdFeHAiLCJtYXRjaCIsInRvSGV4U3RyaW5nIiwibW9kZWxDbGFzcyIsImNvbnZEZWxpdiIsInByb2R1Y3RUeXBlSWQiLCJkZWxpdmVyeUZlZSIsInZhcmlhdGlvbiIsInZhcmlhdGlvbkh0bWwiLCJkZXNjcmlwdGlvbkRldGFpbCIsImphbl9jb2RlIiwiZGVzY3JpcHRpb25fZGV0YWlsIiwiZGVzY3JpcHRpb24iLCJwcm9kdWN0X2NvZGUiLCJwcmljZTAxIiwicmV0YWlsX3ByaWNlIiwicHJpY2UwMiIsInNhbGVzX3ByaWNlIiwicHJvZHVjdF90eXBlX2lkIiwiZGVsaXZlcnlfZmVlIiwiZGVmIiwiaWRMZW5ndGgiLCJ0aXRsZUxlbmd0aCIsImltZ1ByZWZpeCIsImNhdGVnb3J5Iiwic3Vic3RyOCIsInV0aWxFcnJvciIsIm1lc3NhZ2UiLCJmaWxlTmFtZSIsImxpbmVOdW1iZXIiLCJjb2x1bW5OdW1iZXIiLCJzdGFjayIsIm1vbWVudCIsInBvb2wiLCJjcmVhdGVQb29sIiwicHJvZmlsZU11bHRpIiwibXVsdGlwbGVTdGF0ZW1lbnRzIiwicG9vbE11bHRpIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJmb3JtYXQiLCJyZXBsYWNlIiwiZ2V0Q29uIiwidGhlbiIsImNvbiIsInJlbGVhc2UiLCJxdWVyeUluc2VydF8iLCJpbnNlcnRJZCIsImRhdGFTcWwiLCJNYXAiLCJlc2NhcGUiLCJ2YWx1ZXMiLCJ1cGRhdGVzIiwicXVlcnlNdWx0aSIsInBvb2xTd2FwIiwic3RhcnRUcmFuc2FjdGlvbiIsImNvbW1pdCIsInJvbGxiYWNrIiwib24iLCJwYXVzZSIsInJlc3VtZSIsImdldENvbm5lY3Rpb24iLCJpdGVyYXRvciIsInNldHVwSXRlcmF0b3IiLCJJdGVyYXRvciIsInJlYyIsInJlc3VsdCIsInRvdGFsIiwibmV3UmVjb3JkIiwic3VjY2VzcyIsImVycm9yT2N1cnJlZCIsIml0ZUVycm9yIiwicGhhRXJyb3IiLCJ0cmFjZSIsInJlY29yZHMiLCJsYXN0RXJyb3IiLCJ0ZXh0IiwibGVuIiwidHJ1bmNhdGlvbiIsInVuZGVmaW5lZCIsInRleHRBcnJheSIsInNwbGl0Iiwic3RyIiwibiIsImNoYXJBdCJdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7QUFBQSxJQUFJQSxFQUFKO0FBQU9DLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxJQUFSLENBQWIsRUFBMkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNMLFNBQUdLLENBQUg7QUFBSzs7QUFBakIsQ0FBM0IsRUFBOEMsQ0FBOUM7QUFBaUQsSUFBSUMsTUFBSjtBQUFXTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDQyxhQUFPRCxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREO0FBQXlELElBQUlFLFVBQUo7QUFBZU4sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLG9CQUFSLENBQWIsRUFBMkM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNFLGlCQUFXRixDQUFYO0FBQWE7O0FBQXpCLENBQTNDLEVBQXNFLENBQXRFO0FBQXlFLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHFDQUFSLENBQWIsRUFBNEQ7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBNUQsRUFBb0YsQ0FBcEY7QUFhaE8sSUFBSUksdUJBQXVCRixZQUEzQjtBQUVBLE1BQU1HLFFBQVEsZUFBZCxDLENBRUE7O0FBQ0FDLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCSCxLQUEzQixFQUFrQ0Qsb0JBQWxDO0FBQ0FFLE9BQU9DLGVBQVAsQ0FBdUJDLEdBQXZCLENBQTJCSCxLQUEzQixFQUFrQyxDQUFDSSxHQUFELEVBQU1DLElBQU4sS0FBZTtBQUMvQztBQUVBLFFBQU1DLFNBQVNDLE9BQU9DLFNBQVAsQ0FBaUJsQixHQUFHbUIsUUFBcEIsQ0FBZjtBQUNBLFFBQU1DLFNBQVNILE9BQU9DLFNBQVAsQ0FBaUJsQixHQUFHcUIsU0FBcEIsQ0FBZjtBQUNBLFFBQU1DLFdBQVdoQixRQUFqQjs7QUFFQSxPQUFLLElBQUlpQixJQUFULElBQWlCVCxJQUFJVSxLQUFKLENBQVVELElBQTNCLEVBQWlDO0FBQy9CLFVBQU1FLE9BQU9ULE9BQU9PLEtBQUtHLElBQVosQ0FBYixDQUQrQixDQUUvQjtBQUNBOztBQUNBLFFBQUlDLFdBQVksR0FBRXJCLFFBQVMsTUFBM0IsQ0FKK0IsQ0FNL0I7O0FBQ0EsUUFBSXNCLFdBQVdkLElBQUllLElBQUosQ0FBU0MsUUFBVCxHQUFvQixHQUFwQixHQUEwQkgsUUFBekMsQ0FQK0IsQ0FTL0I7QUFFQTs7QUFDQSxRQUFJSSxNQUFNO0FBQ1JULGdCQUFVQSxRQURGO0FBRVJVLHNCQUFnQlQsS0FBS1UsSUFGYjtBQUdSQyx3QkFBa0JQO0FBSFYsS0FBVjs7QUFNQSxRQUFHO0FBQ0RQLGFBQU9RLFFBQVAsRUFBaUJILElBQWpCO0FBQ0QsS0FGRCxDQUdBLE9BQU1VLEdBQU4sRUFBVTtBQUNSSixVQUFJSyxLQUFKLEdBQVlELEdBQVo7QUFDRDs7QUFDRDNCLFlBQVE2QixNQUFSLENBQWVOLEdBQWY7QUFFQSxXQUFPUixJQUFQO0FBRUQ7O0FBQUE7QUFDRFIsT0FBS3VCLFNBQUwsQ0FBZSxHQUFmO0FBQ0F2QixPQUFLd0IsR0FBTCxDQUFTQyxLQUFLQyxTQUFMLENBQWU7QUFDdEJuQixjQUFVQSxRQURZO0FBRXRCb0IsYUFBUzVCLElBQUllLElBQUosQ0FBU0M7QUFGSSxHQUFmLENBQVQ7QUFLRCxDQTFDRCxFOzs7Ozs7Ozs7OztBQ25CQSxJQUFJYSxNQUFKO0FBQVcxQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDc0MsYUFBT3RDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJd0MsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUFsRCxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJeUMsS0FBSixFQUFVQyxZQUFWO0FBQXVCOUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlDQUFSLENBQWIsRUFBd0Q7QUFBQzJDLFFBQU16QyxDQUFOLEVBQVE7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CMEMsZUFBYTFDLENBQWIsRUFBZTtBQUFDMEMsbUJBQWExQyxDQUFiO0FBQWU7O0FBQWxELENBQXhELEVBQTRHLENBQTVHO0FBQStHLElBQUkyQyxNQUFKO0FBQVcvQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0NBQVIsQ0FBYixFQUF5RDtBQUFDNkMsU0FBTzNDLENBQVAsRUFBUztBQUFDMkMsYUFBTzNDLENBQVA7QUFBUzs7QUFBcEIsQ0FBekQsRUFBK0UsQ0FBL0U7QUFhMWMsSUFBSTRDLE1BQU0sU0FBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxVQUFkLEVBQTBCRSxNQUExQjtBQUFBLG9DQUFrQztBQUNoQyxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYixDQURnQyxDQUdoQztBQUNBOztBQUVBLFVBQUlRLFNBQVMsSUFBSUwsTUFBSixDQUFXRyxPQUFPRyxXQUFsQixDQUFiLENBTmdDLENBT2hDO0FBRUE7QUFDQTs7QUFFQSxVQUFJQyxZQUFZLGdCQUFoQjtBQUVBLFVBQUlDLFFBQVEsSUFBSVosS0FBSixDQUFVTyxPQUFPTSxHQUFQLENBQVdDLElBQXJCLENBQVo7QUFFQSxvQkFBTU4sT0FBT08sS0FBUCxDQUFhLHdCQUFiLEVBQ0osK0JBQVk7QUFDVixzQkFBTUgsTUFBTUksS0FBTixDQUFZTCxTQUFaLENBQU47QUFDRCxPQUZELENBREksQ0FBTixFQWhCZ0MsQ0FxQmhDO0FBQ0E7O0FBRUEsb0JBQU1ILE9BQU9PLEtBQVAsQ0FBYSx1QkFBYixFQUNKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUM3QkMsc0JBQW1CQyxNQUFQLDZCQUFrQjtBQUM1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLGdCQUFJQyxNQUFPOzs7OzswQkFLR0QsT0FBT0UsV0FBWSxNQUFLRixPQUFPRyxNQUFPLE1BQUtILE9BQU9JLEdBQUksTUFBS0osT0FBT0ssR0FBSSxNQUFLTCxPQUFPTSxVQUFXLE1BQUtOLE9BQU9PLElBQUssTUFBS1AsT0FBT1EsTUFBTyxNQUFLUixPQUFPUyxNQUFPLE1BQUtULE9BQU9VLE1BQU8sTUFBS1YsT0FBT1csTUFBTyxNQUFLWCxPQUFPWSxZQUFhLE1BQUtaLE9BQU9hLEtBQU0sTUFBS2IsT0FBT2MsS0FBTSxNQUFLZCxPQUFPZSxPQUFRLE1BQUtmLE9BQU9nQixNQUFPLE1BQUtoQixPQUFPaUIsTUFBTyxNQUFLakIsT0FBT2tCLEtBQU0sTUFBS2xCLE9BQU9tQixLQUFNLE1BQUtuQixPQUFPb0IsS0FBTSxNQUFLcEIsT0FBT3FCLEtBQU0sTUFBS3JCLE9BQU9zQixLQUFNLE1BQUt0QixPQUFPdUIsS0FBTSxNQUFLdkIsT0FBT3dCLEtBQU0sTUFBS3hCLE9BQU95QixLQUFNLE1BQUt6QixPQUFPMEIsUUFBUyxNQUFLMUIsT0FBTzJCLElBQUssTUFBSzNCLE9BQU80QixVQUFXLE1BQUs1QixPQUFPNkIsY0FBZSxNQUFLN0IsT0FBTzhCLGFBQWMsTUFBSzlCLE9BQU8rQixTQUFVLE1BQUsvQixPQUFPZ0MsU0FBVSxNQUFLaEMsT0FBT2lDLElBQUssTUFBS2pDLE9BQU9rQyxXQUFZLE1BQUtsQyxPQUFPbUMsV0FBWSxNQUFLbkMsT0FBT29DLE9BQVE7O2lCQUxsc0I7O0FBU0EsZ0JBQUk7QUFDRiw0QkFBTTVDLE1BQU02QyxXQUFOLENBQ0osY0FESSxFQUNZO0FBQ2RuQyw2QkFBYUYsT0FBT0UsV0FETjtBQUVkQyx3QkFBUUgsT0FBT0csTUFGRDtBQUdkQyxxQkFBS0osT0FBT0ksR0FIRTtBQUlkQyxxQkFBS0wsT0FBT0ssR0FKRTtBQUtkQyw0QkFBWU4sT0FBT00sVUFMTDtBQU1kQyxzQkFBTVAsT0FBT08sSUFOQztBQU9kQyx3QkFBUVIsT0FBT1EsTUFQRDtBQVFkQyx3QkFBUVQsT0FBT1MsTUFSRDtBQVNkQyx3QkFBUVYsT0FBT1UsTUFURDtBQVVkQyx3QkFBUVgsT0FBT1csTUFWRDtBQVdkQyw4QkFBY1osT0FBT1ksWUFYUDtBQVlkQyx1QkFBT2IsT0FBT2EsS0FaQTtBQWFkQyx1QkFBT2QsT0FBT2MsS0FiQTtBQWNkQyx5QkFBU2YsT0FBT2UsT0FkRjtBQWVkQyx3QkFBUWhCLE9BQU9nQixNQWZEO0FBZ0JkQyx3QkFBUWpCLE9BQU9pQixNQWhCRDtBQWlCZEMsdUJBQU9sQixPQUFPa0IsS0FqQkE7QUFrQmRDLHVCQUFPbkIsT0FBT21CLEtBbEJBO0FBbUJkQyx1QkFBT3BCLE9BQU9vQixLQW5CQTtBQW9CZEMsdUJBQU9yQixPQUFPcUIsS0FwQkE7QUFxQmRDLHVCQUFPdEIsT0FBT3NCLEtBckJBO0FBc0JkQyx1QkFBT3ZCLE9BQU91QixLQXRCQTtBQXVCZEMsdUJBQU94QixPQUFPd0IsS0F2QkE7QUF3QmRDLHVCQUFPekIsT0FBT3lCLEtBeEJBO0FBeUJkQywwQkFBVTFCLE9BQU8wQixRQXpCSDtBQTBCZEMsc0JBQU0zQixPQUFPMkIsSUExQkM7QUEyQmRDLDRCQUFZNUIsT0FBTzRCLFVBM0JMO0FBNEJkQyxnQ0FBZ0I3QixPQUFPNkIsY0E1QlQ7QUE2QmRDLCtCQUFlOUIsT0FBTzhCLGFBN0JSO0FBOEJkQywyQkFBVy9CLE9BQU8rQixTQTlCSjtBQStCZEMsMkJBQVdoQyxPQUFPZ0MsU0EvQko7QUFnQ2RDLHNCQUFNakMsT0FBT2lDLElBaENDO0FBaUNkQyw2QkFBYWxDLE9BQU9rQyxXQWpDTjtBQWtDZEMsNkJBQWFuQyxPQUFPbUMsV0FsQ047QUFtQ2RDLHlCQUFTcEMsT0FBT29DO0FBbkNGLGVBRFosQ0FBTjtBQXVDRCxhQXhDRCxDQXdDRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFoRTJCLENBa0U1Qjs7O0FBQ0EsZ0JBQUk7QUFDRiw0QkFBTTlDLE1BQU02QyxXQUFOLENBQ0osc0JBREksRUFDb0I7QUFDdEJHLHFDQUFxQixJQURDO0FBRXRCdEMsNkJBQWFGLE9BQU9FLFdBRkU7QUFHdEJJLDRCQUFZTixPQUFPTSxVQUhHO0FBSXRCQyxzQkFBTVAsT0FBT08sSUFKUztBQUt0QkMsd0JBQVFSLE9BQU9RLE1BTE87QUFNdEJDLHdCQUFRVCxPQUFPUyxNQU5PO0FBT3RCQyx3QkFBUVYsT0FBT1UsTUFQTztBQVF0QkMsd0JBQVFYLE9BQU9XLE1BUk87QUFTdEJDLDhCQUFjWixPQUFPWSxZQVRDO0FBVXRCQyx1QkFBT2IsT0FBT2EsS0FWUTtBQVd0QkMsdUJBQU9kLE9BQU9jLEtBWFE7QUFZdEJDLHlCQUFTZixPQUFPZSxPQVpNO0FBYXRCQyx3QkFBUWhCLE9BQU9nQixNQWJPO0FBY3RCQyx3QkFBUWpCLE9BQU9pQixNQWRPO0FBZXRCRSx1QkFBT25CLE9BQU9tQixLQWZRO0FBZ0J0QkMsdUJBQU9wQixPQUFPb0IsS0FoQlE7QUFpQnRCQyx1QkFBT3JCLE9BQU9xQixLQWpCUTtBQWtCdEJDLHVCQUFPdEIsT0FBT3NCLEtBbEJRO0FBbUJ0QkMsdUJBQU92QixPQUFPdUIsS0FuQlE7QUFvQnRCQyx1QkFBT3hCLE9BQU93QixLQXBCUTtBQXFCdEJVLDZCQUFhbEMsT0FBT2tDLFdBckJFO0FBc0J0QkMsNkJBQWFuQyxPQUFPbUMsV0F0QkU7QUF1QnRCQyx5QkFBU3BDLE9BQU9vQztBQXZCTSxlQURwQixDQUFOO0FBMkJELGFBNUJELENBNEJFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWpHMkIsQ0FtRzVCOzs7QUFDQSxnQkFBSTtBQUNGLDRCQUFNOUMsTUFBTTZDLFdBQU4sQ0FDSix1QkFESSxFQUNxQjtBQUN2Qkksb0JBQUksSUFEbUI7QUFFdkJ2Qyw2QkFBYUYsT0FBT0UsV0FGRztBQUd2QndDLDhCQUFjMUMsT0FBTzBDLFlBSEU7QUFJdkJSLDZCQUFhbEMsT0FBT2tDLFdBSkc7QUFLdkJDLDZCQUFhbkMsT0FBT21DLFdBTEc7QUFNdkJDLHlCQUFTcEMsT0FBT29DO0FBTk8sZUFEckIsQ0FBTjtBQVVELGFBWEQsQ0FXRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFqSDJCLENBbUg1Qjs7O0FBRUEsZ0JBQUlLLFdBQVdoRSxPQUFPaUUsV0FBUCxDQUFtQixDQUFuQixFQUFzQkMsUUFBdEIsQ0FBK0IsUUFBL0IsRUFBeUNDLFNBQXpDLENBQW1ELENBQW5ELEVBQXNELEVBQXRELENBQWY7QUFFQSxnQkFBSUMsYUFBYyxHQUFFL0MsT0FBT1EsTUFBTyxJQUFHUixPQUFPUyxNQUFPLG1CQUFrQlQsT0FBT0UsV0FBWSxFQUF4RjtBQUVBLGdCQUFJOEMsZ0JBQWdCaEQsT0FBT2lELEtBQVAsR0FBZSxHQUFuQzs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJcEQsb0JBQVlMLE1BQU02QyxXQUFOLENBQ2QsWUFEYyxFQUNBO0FBQ1phLDJCQUFXLElBREM7QUFFWkMsMkJBQVdSLFFBRkM7QUFHWlMsNkJBQWEsQ0FIRDtBQUdJO0FBQ2hCQyw2QkFBYU4sVUFKRDtBQUtaTywrQkFBZSxDQUxIO0FBTVpDLGlDQUFpQixDQU5MO0FBT1pDLGdDQUFnQixDQVBKO0FBUVpDLGdDQUFnQlQsYUFSSjtBQVNaVSwrQkFBZSxJQVRIO0FBVVpDLDZCQUFhLENBVkQ7QUFXWkMsK0JBQWUsQ0FYSDtBQVlaQyxvQ0FBb0IsSUFaUjtBQWFaM0QsNkJBQWFGLE9BQU9FLFdBYlI7QUFjWjRELHFDQUFxQixxQkFkVDtBQWVaQyxtQ0FBbUIscUJBZlA7QUFnQlozQix5QkFBUztBQWhCRyxlQURBLEVBa0JYO0FBQ0RGLDZCQUFhLE9BRFo7QUFFREMsNkJBQWE7QUFGWixlQWxCVyxDQUFaLENBQUo7QUF1QkQsYUF4QkQsQ0F3QkUsT0FBT0csQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0F0Slc7QUFEaUIsU0FBZixFQXlKVEEsQ0FBUCw2QkFBYTtBQUNYbEQsaUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxTQUZELENBekpnQixDQUFaLENBQUo7QUE4SkEsZUFBT3pDLEdBQVA7QUFDRCxPQWhLRCxDQURJLENBQU47QUFtS0EsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBNUxEO0FBQUEsR0FGYTs7QUFnTVAsdUJBQU4sQ0FBNkJDLE9BQTdCO0FBQUEsb0NBQXNDO0FBQ3BDLFVBQUlDLEtBQUssSUFBSXRGLEtBQUosQ0FBVXFGLE9BQVYsQ0FBVDtBQUNBLFVBQUlwRSxvQkFBWXFFLEdBQUd0RSxLQUFILENBQVMsZ0JBQVQsQ0FBWixDQUFKO0FBQ0EsYUFBT0MsR0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFoTWEsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBLElBQUlzRSxlQUFKO0FBQW9CbEksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ2dJLGtCQUFnQjlILENBQWhCLEVBQWtCO0FBQUM4SCxzQkFBZ0I5SCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBakQsRUFBeUYsQ0FBekY7QUFBNEYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUczSCxJQUFJNEMsTUFBTSxrQkFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXVCbUYsSUFBdkIsRUFBNkJ4RSxRQUFRLEVBQXJDLEVBQXlDeUUsYUFBYSxFQUF0RDtBQUFBLG9DQUEwRDtBQUN4RCxVQUFJQyxxQkFBYUgsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEJBLEtBQUtJLFVBQS9CLENBQWIsQ0FBSjtBQUNBLFVBQUkzRSxvQkFBWXlFLEtBQUtHLElBQUwsQ0FBVTdFLEtBQVYsRUFBaUI7QUFBQ3lFLG9CQUFZQTtBQUFiLE9BQWpCLEVBQTJDSyxPQUEzQyxFQUFaLENBQUo7QUFDQSxhQUFPN0UsR0FBUDtBQUNELEtBSkQ7QUFBQSxHQUZhOztBQVFiLEdBQVEsR0FBRVosR0FBSSxZQUFkLEVBQTRCbUYsSUFBNUIsRUFBa0N4RSxRQUFRLEVBQTFDO0FBQUEsb0NBQThDO0FBQzVDLFVBQUkwRSxxQkFBYUgsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEJBLEtBQUtJLFVBQS9CLENBQWIsQ0FBSjtBQUNBLFVBQUkzRSxvQkFBWXlFLEtBQUtLLFNBQUwsQ0FBZS9FLEtBQWYsRUFBc0I4RSxPQUF0QixFQUFaLENBQUo7QUFDQSxhQUFPN0UsR0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFSYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSStFLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBcEQsRUFBbUYsQ0FBbkY7QUFBc0YsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUdwSCxJQUFJNEMsTUFBTSxhQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7Ozs7O0FBS0EsR0FBUSxHQUFFRCxHQUFJLFdBQWQsRUFBMkJtRixJQUEzQixFQUFpQzlHLFFBQWpDLEVBQTJDdUgsS0FBM0MsRUFBa0RDLFNBQVMsSUFBM0QsRUFBaUVDLFNBQVMsSUFBMUU7QUFBQSxvQ0FBZ0Y7QUFDOUUsVUFBSUMsVUFBVSxJQUFJSixjQUFKLEVBQWQ7QUFDQSxvQkFBTUksUUFBUUMsSUFBUixDQUFhYixJQUFiLENBQU47QUFDQSxVQUFJYyx5QkFBaUJGLFFBQVFHLFFBQVIsQ0FBaUI3SCxRQUFqQixFQUEyQnVILEtBQTNCLEVBQWtDQyxNQUFsQyxFQUEwQ0MsTUFBMUMsQ0FBakIsQ0FBSjtBQUNBLGFBQU9HLFFBQVA7QUFDRCxLQUxEO0FBQUEsR0FQYTs7QUFjYjs7O0FBR0EsR0FBUSxHQUFFakcsR0FBSSxhQUFkLEVBQTZCbUYsSUFBN0IsRUFBbUNTLEtBQW5DLEVBQTBDQyxTQUFTLElBQW5ELEVBQXlEQyxTQUFTLElBQWxFO0FBQUEsb0NBQXdFO0FBQ3RFLFVBQUlDLFVBQVUsSUFBSUosY0FBSixFQUFkO0FBQ0Esb0JBQU1JLFFBQVFDLElBQVIsQ0FBYWIsSUFBYixDQUFOO0FBQ0Esb0JBQU1ZLFFBQVFJLFVBQVIsQ0FBbUJQLEtBQW5CLEVBQTBCQyxNQUExQixFQUFrQ0MsTUFBbEMsQ0FBTjtBQUNELEtBSkQ7QUFBQTs7QUFqQmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0xBLElBQUlsRyxNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJaUosUUFBSjtBQUFhckosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ21KLFdBQVNqSixDQUFULEVBQVc7QUFBQ2lKLGVBQVNqSixDQUFUO0FBQVc7O0FBQXhCLENBQXBELEVBQThFLENBQTlFO0FBQWlGLElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQTlDLEVBQW9FLENBQXBFO0FBQXVFLElBQUl1SSxjQUFKO0FBQW1CM0ksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1SSxxQkFBZXZJLENBQWY7QUFBaUI7O0FBQTdCLENBQWpELEVBQWdGLENBQWhGO0FBQW1GLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFZamUsSUFBSTRDLE1BQU0sTUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksY0FBZCxFQUE4QkUsTUFBOUI7QUFBQSxvQ0FBc0M7QUFDcEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLFVBQUlRLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBYjtBQUNBLFVBQUl1QixpQkFBaUIsSUFBSVosY0FBSixFQUFyQjtBQUNBLG9CQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU47QUFFQSxVQUFJRSxXQUFXLElBQUk3RyxLQUFKLENBQVVPLE9BQU91RyxPQUFqQixDQUFmO0FBQ0EsVUFBSUMsTUFBTSxJQUFJTCxRQUFKLENBQWFHLFFBQWIsQ0FBVjtBQUVBLG9CQUFNckcsT0FBT08sS0FBUCxDQUNKLE9BREksRUFFSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFFN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlDLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF3QkgsS0FBS0ksR0FBN0IsQ0FBakIsQ0FBSjtBQUNBLDBCQUFNTCxJQUFJTSxXQUFKLENBQWdCTCxLQUFLTSxJQUFMLENBQVVDLFdBQVYsQ0FBc0JDLGdCQUF0QyxFQUF3RE4sUUFBeEQsQ0FBTjtBQUNELFdBSFM7QUFGbUIsU0FBZixDQUFaLENBQUo7QUFPQSxlQUFPakcsR0FBUDtBQUNELE9BVEQsQ0FGSSxDQUFOO0FBYUEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBekJEO0FBQUEsR0FMYTs7QUFnQ2I7QUFDQTtBQUVBLEdBQVEsR0FBRS9FLEdBQUksWUFBZCxFQUE0QkUsTUFBNUI7QUFBQSxvQ0FBb0M7QUFDbEMsVUFBSUUsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBQ0EsVUFBSXdCLFdBQVcsSUFBSTdHLEtBQUosQ0FBVU8sT0FBT3VHLE9BQWpCLENBQWY7QUFDQSxVQUFJQyxNQUFNLElBQUlMLFFBQUosQ0FBYUcsUUFBYixDQUFWO0FBRUEsVUFBSUQsaUJBQWlCLElBQUlaLGNBQUosRUFBckI7QUFDQSxvQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOLEVBTmtDLENBUWxDOztBQUNBLFVBQUluRyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osZUFESSxFQUVKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUM3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSVEsTUFBTVIsUUFBUXJCLFVBQWxCOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUk4Qix5QkFBaUJkLGVBQWVlLGdCQUFmLENBQWdDcEgsT0FBT3FILFVBQXZDLEVBQW1EWixJQUFuRCxDQUFqQixDQUFKO0FBRUEsa0JBQUlhLDBCQUFrQmQsSUFBSWUsYUFBSixDQUFrQkosUUFBbEIsQ0FBbEIsQ0FBSixDQUhFLENBS0Y7O0FBQ0EsNEJBQU1ELElBQUlNLE1BQUosQ0FBVztBQUNmWCxxQkFBS0osS0FBS0k7QUFESyxlQUFYLEVBRUg7QUFDRFksc0JBQU07QUFDSixzQ0FBb0JILFVBQVU1RztBQUQxQjtBQURMLGVBRkcsQ0FBTjtBQVFBVCxxQkFBT3lILFFBQVA7QUFDRCxhQWZELENBZUUsT0FBT3ZFLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBckJTO0FBRG1CLFNBQWYsRUF3QlRBLENBQVAsNkJBQWE7QUFDWCxnQkFBTUEsQ0FBTjtBQUNELFNBRkQsQ0F4QmdCLENBQVosQ0FBSjtBQTRCQSxlQUFPekMsR0FBUDtBQUNELE9BOUJELENBRkksQ0FBTjtBQWtDQSxvQkFBTVQsT0FBT08sS0FBUCxDQUNKLGdCQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJUSxNQUFNUixRQUFRckIsVUFBbEI7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSThCLHlCQUFpQmQsZUFBZWUsZ0JBQWYsQ0FBZ0NwSCxPQUFPcUgsVUFBdkMsRUFBbURaLElBQW5ELENBQWpCLENBQUo7QUFFQSw0QkFBTUQsSUFBSW1CLGtCQUFKLENBQXVCUixRQUF2QixDQUFOO0FBQ0EsNEJBQU1YLElBQUlvQixhQUFKLENBQWtCVCxRQUFsQixDQUFOO0FBQ0EsNEJBQU1YLElBQUlxQixnQkFBSixDQUFxQlYsUUFBckIsQ0FBTjtBQUVBLGtCQUFJUix5QkFBaUJOLGVBQWVPLFFBQWYsQ0FBd0JILEtBQUtJLEdBQTdCLENBQWpCLENBQUo7QUFDQSw0QkFBTUwsSUFBSU0sV0FBSixDQUFnQkwsS0FBS00sSUFBTCxDQUFVQyxXQUFWLENBQXNCQyxnQkFBdEMsRUFBd0ROLFFBQXhELENBQU47QUFFQTFHLHFCQUFPeUgsUUFBUDtBQUNELGFBWEQsQ0FXRSxPQUFPdkUsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0FqQlM7QUFEbUIsU0FBZixFQW9CVEEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQXBCZ0IsQ0FBWixDQUFKO0FBd0JBLGVBQU96QyxHQUFQO0FBQ0QsT0ExQkQsQ0FGSSxDQUFOO0FBOEJBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTVFRDtBQUFBOztBQW5DYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZEEsSUFBSW5GLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWdKLGFBQUo7QUFBa0JwSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDa0osZ0JBQWNoSixDQUFkLEVBQWdCO0FBQUNnSixvQkFBY2hKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQTlDLEVBQW9FLENBQXBFO0FBQXVFLElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFPN1IsSUFBSTRDLE1BQU0sTUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksT0FBZCxFQUF1QkUsTUFBdkI7QUFBQSxvQ0FBK0I7QUFDN0I7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLFVBQUlRLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBYjtBQUVBLFlBQU1nRCx5QkFBaUI1SCxPQUFPUyxPQUFQLENBQWUsRUFBZixFQUEwQndDLENBQVAsNkJBQWE7QUFDckQsY0FBTUEsQ0FBTjtBQUNELE9BRnlDLENBQW5CLENBQWpCLENBQU47QUFHQSxvQkFBTWxELE9BQU9PLEtBQVAsQ0FDSixVQURJLEVBRUosK0JBQVk7QUFDVixlQUFPc0gsUUFBUDtBQUNELE9BRkQsQ0FGSSxDQUFOO0FBTUEsYUFBTzdILE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQWhCRDtBQUFBOztBQUxhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNUQSxJQUFJbkYsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVJLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJNkssTUFBSjtBQUFXakwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM2SyxhQUFPN0ssQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJOEssT0FBSjtBQUFZbEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzhLLGNBQVE5SyxDQUFSO0FBQVU7O0FBQXRCLENBQWpDLEVBQXlELENBQXpEO0FBQTRELElBQUkrSyxLQUFKO0FBQVVuTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsWUFBUixDQUFiLEVBQW1DO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDK0ssWUFBTS9LLENBQU47QUFBUTs7QUFBcEIsQ0FBbkMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSWdMLFFBQUo7QUFBYXBMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNnTCxlQUFTaEwsQ0FBVDtBQUFXOztBQUF2QixDQUFqQyxFQUEwRCxDQUExRDtBQUE2RCxJQUFJaUwsR0FBSjtBQUFRckwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLEtBQVIsQ0FBYixFQUE0QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2lMLFVBQUlqTCxDQUFKO0FBQU07O0FBQWxCLENBQTVCLEVBQWdELENBQWhEO0FBQW1ELElBQUlrTCxXQUFKLEVBQWdCQyxTQUFoQjtBQUEwQnZMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ29MLGNBQVlsTCxDQUFaLEVBQWM7QUFBQ2tMLGtCQUFZbEwsQ0FBWjtBQUFjLEdBQTlCOztBQUErQm1MLFlBQVVuTCxDQUFWLEVBQVk7QUFBQ21MLGdCQUFVbkwsQ0FBVjtBQUFZOztBQUF4RCxDQUEvQixFQUF5RixDQUF6RjtBQUE0RixJQUFJb0wsT0FBSjtBQUFZeEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlCQUFSLENBQWIsRUFBd0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNvTCxjQUFRcEwsQ0FBUjtBQUFVOztBQUF0QixDQUF4QyxFQUFnRSxFQUFoRTtBQWdCMTFCLE1BQU00QyxNQUFNLE9BQVo7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLFVBQWQsRUFBMEJFLE1BQTFCO0FBQUEsb0NBQWtDO0FBQ2hDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLGVBREksRUFFSiwrQkFBWTtBQUNWO0FBQ0E7QUFFQSxjQUFNTixTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWY7QUFDQSxjQUFNdUIsaUJBQWlCLElBQUlaLGNBQUosRUFBdkI7QUFDQSxzQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOLEVBTlUsQ0FRVjs7QUFDQSxZQUFJO0FBQ0Ysd0JBQU00QixRQUFRTyxLQUFSLENBQWN2SSxPQUFPd0ksT0FBckIsQ0FBTjtBQUNELFNBRkQsQ0FFRSxPQUFPckYsQ0FBUCxFQUFVLENBQUUsQ0FYSixDQWFWOzs7QUFDQSxjQUFNcUYsVUFBVyxHQUFFeEksT0FBT3dJLE9BQVEsVUFBVSxJQUFJQyxJQUFKLEVBQUQsQ0FBYUMsT0FBYixFQUF1QixFQUFsRSxDQWRVLENBZVY7O0FBQ0EsWUFBSTtBQUNGLHdCQUFNVixRQUFRTyxLQUFSLENBQWNDLE9BQWQsQ0FBTjtBQUNELFNBRkQsQ0FFRSxPQUFPckYsQ0FBUCxFQUFVLENBQUUsQ0FsQkosQ0FvQlY7QUFDQTs7O0FBRUEsWUFBSXpDLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFFN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlpQyxVQUFVdEosS0FBS3VKLEtBQUwsQ0FBV3ZKLEtBQUtDLFNBQUwsQ0FBZVUsT0FBTzZJLFFBQXRCLENBQVgsQ0FBZDtBQUNBRixvQkFBUUcsR0FBUixHQUFlLEdBQUVILFFBQVFHLEdBQUksaUJBQTdCO0FBQ0FILG9CQUFRSSxFQUFSLENBQVdDLFFBQVgsR0FBc0J2QyxLQUFLTSxJQUFMLENBQVVrQyxLQUFWLENBQWdCRCxRQUF0QztBQUVBLGdCQUFJRSxzQkFBY1osUUFBUUssT0FBUixDQUFkLENBQUo7QUFDQSxnQkFBSW5LLFdBQVksR0FBRWdLLE9BQVEsSUFBRy9CLEtBQUtmLEtBQU0sTUFBeEM7QUFFQSwwQkFBTXNDLFFBQVE5SixTQUFSLENBQWtCTSxRQUFsQixFQUE0QjBLLEtBQTVCLENBQU47QUFDRCxXQVRTO0FBRm1CLFNBQWYsQ0FBWixDQUFKO0FBYUEsZUFBT3hJLEdBQVA7QUFDRCxPQXJDRCxDQUZJLENBQU47QUF5Q0EsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBOUNEO0FBQUEsR0FMYTs7QUFxRGIsR0FBUSxHQUFFL0UsR0FBSSxjQUFkLEVBQThCRSxNQUE5QjtBQUFBLG9DQUFzQztBQUNwQztBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSixlQURJLEVBRUosK0JBQVk7QUFDVjtBQUNBO0FBRUEsY0FBTU4sU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFmO0FBQ0EsY0FBTXVCLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTixFQU5VLENBUVY7O0FBQ0EsWUFBSTtBQUNGLHdCQUFNNEIsUUFBUU8sS0FBUixDQUFjdkksT0FBT3dJLE9BQXJCLENBQU47QUFDRCxTQUZELENBRUUsT0FBT3JGLENBQVAsRUFBVSxDQUFFLENBWEosQ0FhVjs7O0FBQ0EsY0FBTXFGLFVBQVcsR0FBRXhJLE9BQU93SSxPQUFRLFVBQVUsSUFBSUMsSUFBSixFQUFELENBQWFDLE9BQWIsRUFBdUIsRUFBbEUsQ0FkVSxDQWVWOztBQUNBLFlBQUk7QUFDRix3QkFBTVYsUUFBUU8sS0FBUixDQUFjQyxPQUFkLENBQU47QUFDRCxTQUZELENBRUUsT0FBT3JGLENBQVAsRUFBVSxDQUFFLENBbEJKLENBb0JWO0FBQ0E7OztBQUVBLFlBQUl6QyxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBRTdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJaUMsVUFBVXRKLEtBQUt1SixLQUFMLENBQVd2SixLQUFLQyxTQUFMLENBQWVVLE9BQU82SSxRQUF0QixDQUFYLENBQWQ7QUFDQUYsb0JBQVFHLEdBQVIsR0FBZSxHQUFFSCxRQUFRRyxHQUFJLGlCQUE3QjtBQUNBSCxvQkFBUUksRUFBUixDQUFXQyxRQUFYLEdBQXNCdkMsS0FBS00sSUFBTCxDQUFVa0MsS0FBVixDQUFnQkQsUUFBdEM7QUFFQSxnQkFBSUUsc0JBQWNaLFFBQVFLLE9BQVIsQ0FBZCxDQUFKO0FBQ0EsZ0JBQUluSyxXQUFZLEdBQUVnSyxPQUFRLElBQUcvQixLQUFLZixLQUFNLE1BQXhDO0FBRUEsMEJBQU1zQyxRQUFROUosU0FBUixDQUFrQk0sUUFBbEIsRUFBNEIwSyxLQUE1QixDQUFOO0FBQ0QsV0FUUztBQUZtQixTQUFmLENBQVosQ0FBSjtBQWFBLGVBQU94SSxHQUFQO0FBQ0QsT0FyQ0QsQ0FGSSxDQUFOO0FBeUNBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQTlDRDtBQUFBOztBQXJEYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDbEJBLElBQUluRixNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk2SyxNQUFKO0FBQVdqTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZLLGFBQU83SyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUk4SyxPQUFKO0FBQVlsTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDOEssY0FBUTlLLENBQVI7QUFBVTs7QUFBdEIsQ0FBakMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSStLLEtBQUo7QUFBVW5MLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMrSyxZQUFNL0ssQ0FBTjtBQUFROztBQUFwQixDQUFuQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJZ0wsUUFBSjtBQUFhcEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2dMLGVBQVNoTCxDQUFUO0FBQVc7O0FBQXZCLENBQWpDLEVBQTBELENBQTFEO0FBQTZELElBQUlpTCxHQUFKO0FBQVFyTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsS0FBUixDQUFiLEVBQTRCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDaUwsVUFBSWpMLENBQUo7QUFBTTs7QUFBbEIsQ0FBNUIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSWtMLFdBQUosRUFBZ0JDLFNBQWhCO0FBQTBCdkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDb0wsY0FBWWxMLENBQVosRUFBYztBQUFDa0wsa0JBQVlsTCxDQUFaO0FBQWMsR0FBOUI7O0FBQStCbUwsWUFBVW5MLENBQVYsRUFBWTtBQUFDbUwsZ0JBQVVuTCxDQUFWO0FBQVk7O0FBQXhELENBQS9CLEVBQXlGLENBQXpGO0FBZWx2QixNQUFNaU0sU0FBUyxRQUFmO0FBQ0EsTUFBTXJKLE1BQU0sT0FBWjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksUUFBZCxFQUF3QkUsTUFBeEI7QUFBQSxvQ0FBZ0M7QUFDOUI7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osUUFESSxFQUVKLCtCQUFZO0FBQ1YsY0FBTTZGLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTjtBQUNBLGNBQU1vQyxVQUFXLEdBQUV4SSxPQUFPd0ksT0FBUSxRQUFsQztBQUNBLGNBQU1ZLElBQUlwQixRQUFRcUIsZ0JBQVIsQ0FBMEIsR0FBRWIsT0FBUSxJQUFHeEksT0FBT3NKLGFBQWMsRUFBNUQsQ0FBVjtBQUNBLGNBQU1DLElBQUl2QixRQUFRd0IsaUJBQVIsQ0FBMkIsR0FBRWhCLE9BQVEsSUFBR3hJLE9BQU95SixhQUFjLEVBQTdELENBQVY7QUFDQUwsVUFBRU0sSUFBRixDQUFPekIsTUFBTTBCLFlBQU4sQ0FBbUIsTUFBbkIsQ0FBUCxFQUNHRCxJQURILENBQ1F6QixNQUFNMkIsWUFBTixDQUFtQixPQUFuQixDQURSLEVBRUdGLElBRkgsQ0FFUXZCLElBQUlTLEtBQUosQ0FBVTtBQUFDaUIsbUJBQVM7QUFBVixTQUFWLENBRlIsRUFHR0gsSUFISCxDQUdRdkIsSUFBSTJCLFNBQUosQ0FDSixDQUFPakosTUFBUCxFQUFla0osUUFBZiw4QkFBNEI7QUFDMUIsY0FBSS9LLE1BQU0sSUFBVixDQUQwQixDQUUxQjs7QUFDQSxjQUFJO0FBQ0Y2QixtQkFBTyxNQUFQLGtCQUF1QndGLGVBQWUyRCxhQUFmLENBQTZCbkosT0FBTyxNQUFQLENBQTdCLENBQXZCO0FBQ0QsV0FGRCxDQUVFLE9BQU9zQyxDQUFQLEVBQVU7QUFDVm5FLGtCQUFNbUUsQ0FBTjtBQUNEOztBQUNENEcsbUJBQVMvSyxHQUFULEVBQWM2QixNQUFkO0FBQ0QsU0FURCxDQURJLENBSFIsRUFlRzZJLElBZkgsQ0FlUXZCLElBQUk3SSxTQUFKLENBQWM7QUFBQzJLLGtCQUFRO0FBQVQsU0FBZCxDQWZSLEVBZ0JHUCxJQWhCSCxDQWdCUXpCLE1BQU0wQixZQUFOLENBQW1CLE9BQW5CLENBaEJSLEVBaUJHRCxJQWpCSCxDQWlCUXpCLE1BQU0yQixZQUFOLENBQW1CLE1BQW5CLENBakJSLEVBa0JHRixJQWxCSCxDQWtCUUgsQ0FsQlI7QUFtQkQsT0F6QkQsQ0FGSSxDQUFOO0FBNkJELEtBakNEO0FBQUEsR0FMYTs7QUF3Q2I7QUFDQTtBQUVBLEdBQVEsR0FBRXpKLEdBQUksVUFBZCxFQUEwQkUsTUFBMUI7QUFBQSxvQ0FBa0M7QUFDaEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osUUFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUVBLGNBQU1OLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBZjtBQUNBLGNBQU11QixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOVSxDQVFWOztBQUNBLGNBQU04RCxTQUFTLElBQUluQyxNQUFKLENBQVcvSCxPQUFPbUssVUFBbEIsQ0FBZixDQVRVLENBV1Y7O0FBQ0EsWUFBSTtBQUNGLHdCQUFNbkMsUUFBUU8sS0FBUixDQUFjdkksT0FBT3dJLE9BQXJCLENBQU47QUFDRCxTQUZELENBRUUsT0FBT3JGLENBQVAsRUFBVSxDQUFFLENBZEosQ0FnQlY7OztBQUNBLGNBQU1xRixVQUFXLEdBQUV4SSxPQUFPd0ksT0FBUSxPQUFsQztBQUNBLHNCQUFNUixRQUFRb0MsTUFBUixDQUFlNUIsT0FBZixDQUFOO0FBQ0Esc0JBQU1SLFFBQVFPLEtBQVIsQ0FBY0MsT0FBZCxDQUFOLEVBbkJVLENBcUJWOztBQUNBLGNBQU02QixZQUFhLEdBQUVySyxPQUFPd0ksT0FBUSxTQUFwQztBQUNBLHNCQUFNUixRQUFRb0MsTUFBUixDQUFlQyxTQUFmLENBQU47QUFDQSxzQkFBTXJDLFFBQVFPLEtBQVIsQ0FBYzhCLFNBQWQsQ0FBTjtBQUVBLFlBQUlDLEtBQUssSUFBVCxDQTFCVSxDQTBCSTs7QUFDZCxZQUFJOUwsV0FBVyxJQUFmLENBM0JVLENBMkJVOztBQUNwQixZQUFJTSxPQUFPLElBQVgsQ0E1QlUsQ0E0Qk07QUFFaEI7O0FBQ0EsWUFBSXlMLFNBQVMsQ0FBQyxNQUFELEVBQVMsTUFBVCxFQUFpQixNQUFqQixFQUF5QixJQUF6QixFQUErQixnQkFBL0IsRUFBaUQsTUFBakQsRUFBeUQsTUFBekQsRUFBaUUsT0FBakUsRUFBMEUsSUFBMUUsRUFBZ0YsUUFBaEYsRUFBMEYsSUFBMUYsRUFBZ0csTUFBaEcsRUFBd0csWUFBeEcsRUFBc0gsWUFBdEgsRUFBb0ksTUFBcEksRUFBNEksV0FBNUksRUFBeUosWUFBekosRUFBdUssT0FBdkssRUFBZ0wsU0FBaEwsRUFBMkwsT0FBM0wsRUFBb00sU0FBcE0sRUFBK00sS0FBL00sRUFBc04sU0FBdE4sRUFBaU8sS0FBak8sRUFBd08sU0FBeE8sRUFBbVAsS0FBblAsRUFBMFAsU0FBMVAsRUFBcVEsS0FBclEsRUFBNFEsU0FBNVEsRUFBdVIsS0FBdlIsRUFBOFIsU0FBOVIsRUFBeVMsS0FBelMsRUFBZ1QsU0FBaFQsRUFBMlQsS0FBM1QsRUFBa1UsU0FBbFUsRUFBNlUsS0FBN1UsRUFBb1YsU0FBcFYsRUFBK1YsS0FBL1YsRUFBc1csU0FBdFcsRUFBaVgsTUFBalgsRUFBeVgsVUFBelgsRUFBcVksTUFBclksRUFBNlksUUFBN1ksRUFBdVosU0FBdlosRUFBa2EsTUFBbGEsRUFBMGEsTUFBMWEsRUFBa2IsVUFBbGIsRUFBOGIsT0FBOWIsRUFBdWMsUUFBdmMsRUFBaWQsUUFBamQsRUFBMmQsV0FBM2QsRUFBd2UsUUFBeGUsRUFBa2YsS0FBbGYsRUFBeWYsY0FBemYsRUFBeWdCLFNBQXpnQixFQUFvaEIsU0FBcGhCLEVBQStoQixZQUEvaEIsRUFBNmlCLGNBQTdpQixFQUE2akIsUUFBN2pCLEVBQXVrQixPQUF2a0IsRUFBZ2xCLFFBQWhsQixFQUEwbEIsVUFBMWxCLEVBQXNtQixtQkFBdG1CLEVBQTJuQixnQkFBM25CLEVBQTZvQixVQUE3b0IsRUFBeXBCLG1CQUF6cEIsRUFBOHFCLGdCQUE5cUIsRUFBZ3NCLFVBQWhzQixFQUE0c0IsbUJBQTVzQixFQUFpdUIsZ0JBQWp1QixFQUFtdkIsVUFBbnZCLEVBQSt2QixtQkFBL3ZCLEVBQW94QixnQkFBcHhCLEVBQXN5QixVQUF0eUIsRUFBa3pCLG1CQUFsekIsRUFBdTBCLGdCQUF2MEIsRUFBeTFCLFVBQXoxQixFQUFxMkIsbUJBQXIyQixFQUEwM0IsZ0JBQTEzQixFQUE0NEIsVUFBNTRCLEVBQXc1QixtQkFBeDVCLEVBQTY2QixnQkFBNzZCLEVBQSs3QixVQUEvN0IsRUFBMjhCLG1CQUEzOEIsRUFBZytCLGdCQUFoK0IsRUFBay9CLFVBQWwvQixFQUE4L0IsbUJBQTkvQixFQUFtaEMsZ0JBQW5oQyxFQUFxaUMsV0FBcmlDLEVBQWtqQyxvQkFBbGpDLEVBQXdrQyxpQkFBeGtDLEVBQTJsQyxNQUEzbEMsRUFBbW1DLFdBQW5tQyxFQUFnbkMsU0FBaG5DLEVBQTJuQyxPQUEzbkMsRUFBb29DLGdCQUFwb0MsQ0FBYjtBQUNBLFlBQUlOLFNBQVNNLE9BQU9DLEdBQVAsQ0FBV3ROLEtBQU0sSUFBR0EsQ0FBRSxHQUF0QixFQUEwQnVOLElBQTFCLENBQStCLEdBQS9CLElBQXNDLElBQW5ELENBaENVLENBa0NWOztBQUNBUCxlQUFPUSxhQUFQLEdBQThCQyxXQUFQLDZCQUF1QjtBQUM1QzdMLGlCQUFPcUssU0FBUyxDQUFDLFVBQVV3QixXQUFYLEVBQXdCQyxLQUF4QixDQUE4QixDQUFDLENBQS9CLENBQWhCO0FBQ0FOLGVBQU0sR0FBRTlCLE9BQVEsSUFBRzFKLElBQUssRUFBeEI7QUFDQU4scUJBQVksR0FBRThMLEVBQUcsSUFBR3RLLE9BQU82SyxXQUFZLEVBQXZDO0FBQ0Esd0JBQU03QyxRQUFRTyxLQUFSLENBQWMrQixFQUFkLENBQU4sRUFKNEMsQ0FLNUM7O0FBQ0Esd0JBQU10QyxRQUFROEMsVUFBUixDQUFtQnRNLFFBQW5CLEVBQTZCeUosTUFBTThDLE1BQU4sQ0FBYWQsTUFBYixFQUFxQixXQUFyQixDQUE3QixDQUFOO0FBQ0QsU0FQc0IsQ0FBdkIsQ0FuQ1UsQ0E0Q1Y7OztBQUNBQyxlQUFPYyxRQUFQLEdBQXlCQyxHQUFQLDZCQUFlO0FBQy9CLGNBQUlDLFFBQVFELElBQUlDLEtBQWhCO0FBQ0EsY0FBSXpFLE9BQU93RSxJQUFJeEUsSUFBZixDQUYrQixDQUcvQjs7QUFDQSxjQUFJNUYsU0FBUzBKLE9BQU9DLEdBQVAsQ0FBV3ROLEtBQUs7QUFBRSxtQkFBT2dPLE1BQU1oTyxDQUFOLElBQVksSUFBR2dPLE1BQU1oTyxDQUFOLENBQVMsR0FBeEIsR0FBNkIsSUFBcEM7QUFBMEMsV0FBNUQsRUFBOER1TixJQUE5RCxDQUFtRSxHQUFuRSxJQUEwRSxJQUF2RjtBQUNBLHdCQUFNekMsUUFBUThDLFVBQVIsQ0FBbUJ0TSxRQUFuQixFQUE2QnlKLE1BQU04QyxNQUFOLENBQWFsSyxNQUFiLEVBQXFCLFdBQXJCLENBQTdCLENBQU4sRUFMK0IsQ0FNL0I7O0FBQ0EsZUFBSyxJQUFJc0ssR0FBVCxJQUFnQjFFLEtBQUsyRSxNQUFyQixFQUE2QjtBQUMzQixnQkFBSUMsU0FBVSxHQUFFckwsT0FBT3JCLFFBQVMsSUFBR3dNLEdBQUksRUFBdkM7QUFDQSxnQkFBSUcsU0FBVSxHQUFFaEIsRUFBRyxJQUFHYSxHQUFJLEVBQTFCOztBQUNBLGdCQUFJO0FBQ0Y7QUFDQSw0QkFBTW5ELFFBQVF1RCxNQUFSLENBQWVELE1BQWYsQ0FBTjtBQUNELGFBSEQsQ0FHRSxPQUFPbkksQ0FBUCxFQUFVO0FBQ1YsNEJBQU02RSxRQUFRd0QsUUFBUixDQUFpQkgsTUFBakIsRUFBeUJDLE1BQXpCLENBQU47QUFDRDtBQUNGO0FBQ0YsU0FqQmlCLENBQWxCLENBN0NVLENBZ0VWOzs7QUFDQXBCLGVBQU91QixXQUFQLEdBQTRCZCxXQUFQLDZCQUF1QjtBQUMxQyxnQkFBTWUsTUFBTXhELFNBQVMsS0FBVCxDQUFaO0FBQ0EsZ0JBQU15RCxVQUFXLEdBQUV0QixTQUFVLElBQUd2TCxJQUFLLE1BQXJDO0FBQ0EsZ0JBQU04TSxTQUFTNUQsUUFBUXdCLGlCQUFSLENBQTBCbUMsT0FBMUIsQ0FBZjtBQUNBRCxjQUFJaEMsSUFBSixDQUFTa0MsTUFBVDtBQUNBRixjQUFJRyxTQUFKLENBQWN2QixFQUFkLEVBQWtCLEtBQWxCO0FBQ0FvQixjQUFJSSxRQUFKO0FBQ0QsU0FQb0IsQ0FBckIsQ0FqRVUsQ0EwRVY7QUFDQTs7O0FBRUEsWUFBSXBMLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFFN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlDLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF3QkgsS0FBS0ksR0FBN0IsQ0FBakIsQ0FBSixDQURpQyxDQUVqQzs7QUFDQSxnQkFBSUYsWUFBWUYsS0FBS00sSUFBTCxDQUFVbUUsS0FBVixDQUFnQmEsV0FBaEMsRUFBNkM7QUFDM0Msa0JBQUliLHNCQUFjN0UsZUFBZTJGLGdCQUFmLENBQWdDaE0sT0FBTy9DLE9BQXZDLEVBQWdEd0osSUFBaEQsQ0FBZCxDQUFKO0FBQ0EsNEJBQU15RCxPQUFPK0IsTUFBUCxDQUFjO0FBQUNmLHVCQUFPQSxLQUFSO0FBQWV6RSxzQkFBTUE7QUFBckIsZUFBZCxDQUFOO0FBQ0Q7QUFDRixXQVBTO0FBRm1CLFNBQWYsQ0FBWixDQUFKO0FBV0F5RCxlQUFPZ0MsS0FBUDtBQUVBLGVBQU94TCxHQUFQO0FBQ0QsT0EzRkQsQ0FGSSxDQUFOO0FBK0ZBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQXBHRDtBQUFBOztBQTNDYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDbEJBL0gsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLCtCQUFSLENBQWI7QUFBdURGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQXZERixPQUFPcVAsTUFBUCxDQUFjO0FBQUNDLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUlDLEtBQUo7QUFBVXZQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ3FQLFFBQU1uUCxDQUFOLEVBQVE7QUFBQ21QLFlBQU1uUCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRXhDLE1BQU1rUCxVQUFVLElBQUlDLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBK0I7QUFBQ0MsZ0JBQWE7QUFBZCxDQUEvQixDQUFoQixDOzs7Ozs7Ozs7OztBQ0ZQelAsT0FBT3FQLE1BQVAsQ0FBYztBQUFDdE0sVUFBTyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSXdNLEtBQUo7QUFBVXZQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ3FQLFFBQU1uUCxDQUFOLEVBQVE7QUFBQ21QLFlBQU1uUCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJc1AsSUFBSjtBQUFTMVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE1BQVIsQ0FBYixFQUE2QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3NQLFdBQUt0UCxDQUFMO0FBQU87O0FBQW5CLENBQTdCLEVBQWtELENBQWxEO0FBQXFELElBQUl1UCxPQUFKO0FBQVkzUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdVAsY0FBUXZQLENBQVI7QUFBVTs7QUFBdEIsQ0FBcEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXdQLFNBQUo7QUFBYzVQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQzBQLFlBQVV4UCxDQUFWLEVBQVk7QUFBQ3dQLGdCQUFVeFAsQ0FBVjtBQUFZOztBQUExQixDQUFqQyxFQUE2RCxDQUE3RDtBQWFuWixNQUFNeVAsVUFBVSxJQUFJTixNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQWdDO0FBQzlDQyxnQkFBYztBQURnQyxDQUFoQyxDQUFoQjs7QUFJTyxNQUFNMU0sTUFBTixTQUFxQjZNLFNBQXJCLENBQStCO0FBRXBDRSxjQUFZQyxRQUFaLEVBQXNCO0FBRXBCLFFBQUkvSCxVQUFVNkgsUUFBUUcsT0FBUixDQUFnQjtBQUM1QmpHLFdBQUtnRztBQUR1QixLQUFoQixDQUFkO0FBSUEsVUFBTS9ILE9BQU47QUFFQSxRQUFJRyxPQUFPLEtBQUs4SCxPQUFMLEVBQVg7O0FBRUEsWUFBUTlILEtBQUsrSCxJQUFiO0FBRUUsV0FBSyxPQUFMO0FBQ0UsYUFBS0MsS0FBTCxHQUFhLElBQUl4TixLQUFKLENBQVV3RixLQUFLMUUsSUFBZixDQUFiOztBQUNBLGFBQUsyTSxNQUFMLEdBQWMsQ0FBUUMsV0FBWXRNLE1BQUQsSUFBVSxDQUFFLENBQS9CLEVBQWlDdU0sVUFBV2pLLENBQUQsSUFBSyxDQUFFLENBQWxELDhCQUF3RDtBQUNwRSxjQUFJckMsTUFBTyxpQkFBZ0JtRSxLQUFLb0ksS0FBTSxFQUF0QztBQUNBLCtCQUFhLEtBQUtKLEtBQUwsQ0FBV0ssY0FBWCxDQUEwQnhNLEdBQTFCLEVBQStCcU0sUUFBL0IsRUFBeUNDLE9BQXpDLENBQWI7QUFDRCxTQUhhLENBQWQ7O0FBSUE7O0FBRUY7QUFDRSxjQUFNLElBQUlHLEtBQUosQ0FBVSx1QkFBVixDQUFOO0FBWEo7QUFjRDtBQUVEOzs7Ozs7QUFJTTVNLFNBQU4sQ0FBYzZNLFlBQVksRUFBMUIsRUFBOEJKLFVBQWlCakssQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBeEM7QUFBQSxvQ0FBeUQ7QUFFdkQsVUFBSTJCLFVBQVUsS0FBSzJJLFVBQUwsRUFBZCxDQUZ1RCxDQUl2RDs7QUFDQTNJLGNBQVE0SSxPQUFSLENBQWdCQyxJQUFoQixDQUFxQjtBQUNuQlgsY0FBTSxNQURhO0FBRW5Cdk0sZUFBTztBQUZZLE9BQXJCO0FBS0EsVUFBSW1OLFFBQVEsRUFBWjs7QUFDQSxXQUFLLElBQUkxTixNQUFULElBQW1CNEUsUUFBUTRJLE9BQTNCLEVBQW9DO0FBQ2xDRSxjQUFNMU4sT0FBTzhNLElBQWIsSUFBcUI7QUFDbkJ2TSxpQkFBT1AsT0FBT08sS0FESztBQUVuQm1OLGlCQUFPO0FBRlksU0FBckI7QUFJRDs7QUFFRCxvQkFBTSxLQUFLVixNQUFMLENBQ0dyTSxNQUFQLDZCQUFnQjtBQUNkLGFBQUssSUFBSVgsTUFBVCxJQUFtQjRFLFFBQVE0SSxPQUEzQixFQUFvQztBQUNsQyxjQUFJak4sUUFBUWdNLFFBQVFvQixRQUFSLENBQWlCM04sT0FBT08sS0FBeEIsQ0FBWjtBQUNBLGNBQUlxTixPQUFPdEIsS0FBTS9MLEtBQU4sQ0FBWDs7QUFDQSxjQUFJcU4sS0FBS2pOLE1BQUwsQ0FBSixFQUFrQjtBQUNoQitNLGtCQUFNMU4sT0FBTzhNLElBQWIsRUFBbUJZLEtBQW5COztBQUNBLGdCQUFJLE9BQU9KLFVBQVV0TixPQUFPOE0sSUFBakIsQ0FBUCxLQUFrQyxXQUF0QyxFQUFrRDtBQUNoRCw0QkFBTVEsVUFBVXROLE9BQU84TSxJQUFqQixFQUF1Qm5NLE1BQXZCLENBQU47QUFDRDs7QUFDRDtBQUNEO0FBQ0Y7QUFDRixPQVpELENBREksRUFjSnVNLE9BZEksQ0FBTixFQWxCdUQsQ0FtQ3ZEOztBQUNBLGFBQU9RLEtBQVA7QUFFRCxLQXRDRDtBQUFBOztBQWhDb0MsQzs7Ozs7Ozs7Ozs7QUNqQnRDOVEsT0FBT3FQLE1BQVAsQ0FBYztBQUFDTyxhQUFVLE1BQUlBLFNBQWY7QUFBeUIvTSxTQUFNLE1BQUlBO0FBQW5DLENBQWQ7QUFBeUQsSUFBSTBNLEtBQUo7QUFBVXZQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ3FQLFFBQU1uUCxDQUFOLEVBQVE7QUFBQ21QLFlBQU1uUCxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQVFuTixNQUFNNlEsU0FBUyxJQUFJMUIsTUFBTUMsVUFBVixDQUFxQixRQUFyQixFQUErQjtBQUM1Q0MsZ0JBQWM7QUFEOEIsQ0FBL0IsQ0FBZjs7QUFJTyxNQUFNRyxTQUFOLENBQWdCO0FBSXJCRSxjQUFZOUgsT0FBWixFQUFxQjtBQUNuQixTQUFLQSxPQUFMLEdBQWVBLE9BQWY7QUFDRDtBQUVEOzs7Ozs7O0FBS0FpSSxZQUFVO0FBQ1IsV0FBTyxLQUFLakksT0FBTCxDQUFha0osWUFBcEI7QUFDRDs7QUFFRFAsZUFBYTtBQUNYLFdBQU8sS0FBSzNJLE9BQVo7QUFDRDs7QUFFRG5FLFVBQVFvSixXQUFrQmxKLE1BQVAsNkJBQWtCLENBQUUsQ0FBcEIsQ0FBbkIsRUFBeUN1TSxVQUFpQmpLLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQW5ELEVBQW9FLENBQUU7O0FBckJqRDs7QUF5QmhCLE1BQU14RCxLQUFOLFNBQW9CK00sU0FBcEIsQ0FBOEI7QUFFbkNFLGNBQVlxQixPQUFaLEVBQXFCO0FBRW5CLFFBQUluSixVQUFVaUosT0FBT2pCLE9BQVAsQ0FBZTtBQUMzQmpHLFdBQUtvSDtBQURzQixLQUFmLENBQWQ7QUFJQSxVQUFNbkosT0FBTjtBQUVBLFFBQUlHLE9BQU8sS0FBSzhILE9BQUwsRUFBWDs7QUFFQSxZQUFROUgsS0FBSytILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSXhOLEtBQUosQ0FBVXdGLEtBQUsxRSxJQUFmLENBQWI7O0FBQ0EsYUFBSzJNLE1BQUwsR0FBcUJ0TyxHQUFQLDZCQUFlO0FBQzNCLGNBQUlrQyxNQUFPLGlCQUFnQm1FLEtBQUtvSSxLQUFNLFlBQVd6TyxJQUFJc1AsR0FBSSxTQUFRdFAsSUFBSTBFLEVBQUcsR0FBeEU7QUFDQSwrQkFBYSxLQUFLMkosS0FBTCxDQUFXeE0sS0FBWCxDQUFpQkssR0FBakIsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFDRjtBQUNFLGNBQU0sSUFBSXlNLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBVEo7QUFZRDtBQUdEOzs7Ozs7QUFJQTVNLFVBQVFvSixXQUFrQmxKLE1BQVAsNkJBQWtCLENBQUUsQ0FBcEIsQ0FBbkIsRUFBeUN1TSxVQUFpQmpLLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQW5ELEVBQW9FO0FBRWxFLFFBQUlnTCxNQUFNSixPQUFPekksSUFBUCxDQUFZO0FBQ3BCMkksZUFBUyxLQUFLbkosT0FBTCxDQUFhK0I7QUFERixLQUFaLEVBRVA7QUFDRDBELGNBQVE7QUFDTjFELGFBQUssQ0FEQztBQUVOdkQsWUFBSSxDQUZFO0FBR040SyxhQUFLO0FBSEM7QUFEUCxLQUZPLENBQVY7QUFVQSxXQUFPLElBQUlFLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFFbkJILFVBQUlJLE9BQUosQ0FDRSxDQUFPM1AsR0FBUCxFQUFZNFAsS0FBWiw4QkFBc0I7QUFDcEIsWUFBSTtBQUNGLGNBQUkzTix1QkFBZSxLQUFLcU0sTUFBTCxDQUFZdE8sR0FBWixDQUFmLENBQUo7QUFDQSx3QkFBTW1MLFNBQVNsSixNQUFULENBQU47QUFDRCxTQUhELENBR0UsT0FBT3NDLENBQVAsRUFBVTtBQUNWaUssa0JBQVFqSyxDQUFSO0FBQ0Q7O0FBQ0QsWUFBSXFMLFFBQVEsQ0FBUixLQUFjTCxJQUFJUCxLQUFKLEVBQWxCLEVBQStCO0FBQzdCUztBQUNEO0FBQ0YsT0FWRCxDQURGO0FBYUQsS0FoQkksRUFpQkxJLEtBakJLLENBa0JKdEwsQ0FBRCxJQUFPO0FBQ0wsWUFBTUEsQ0FBTjtBQUNELEtBcEJJLENBQVA7QUF1QkQ7O0FBbEVrQyxDOzs7Ozs7Ozs7OztBQ3JDckNyRyxPQUFPcVAsTUFBUCxDQUFjO0FBQUM5TyxXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJZ1AsS0FBSjtBQUFVdlAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDcVAsUUFBTW5QLENBQU4sRUFBUTtBQUFDbVAsWUFBTW5QLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFeEMsTUFBTUcsVUFBVSxJQUFJZ1AsTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUErQjtBQUFDQyxnQkFBYTtBQUFkLENBQS9CLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDRlB6UCxPQUFPcVAsTUFBUCxDQUFjO0FBQUNoRyxZQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJMUcsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTs7QUFFMUMsTUFBTWlKLFFBQU4sQ0FBZTtBQUNwQnlHLGNBQWFLLFFBQVEsSUFBSXhOLEtBQUosRUFBckIsRUFBa0M7QUFDaEMsU0FBS2lQLE1BQUwsR0FBY3pCLEtBQWQ7QUFDRDs7QUFFS25HLGFBQU4sQ0FBbUI2SCxjQUFuQixFQUFtQ2hJLFdBQVcsQ0FBOUM7QUFBQSxvQ0FBaUQ7QUFDL0Msb0JBQU0sS0FBSytILE1BQUwsQ0FBWUUsV0FBWixDQUNKLG1CQURJLEVBRUgsc0JBQXFCRCxjQUFlLEVBRmpDLEVBR0osRUFISSxFQUdBO0FBQ0ZFLGVBQU9sSSxRQURMO0FBRUZtSSx5QkFBaUIsQ0FGZjtBQUdGOUwscUJBQWE7QUFIWCxPQUhBLENBQU47QUFVQSxvQkFBTSxLQUFLMEwsTUFBTCxDQUFZRSxXQUFaLENBQ0osbUJBREksRUFFSCxzQkFBcUJELGNBQWUsRUFGakMsRUFHSixFQUhJLEVBR0E7QUFDRkUsZUFBT2xJLFFBREw7QUFFRjNELHFCQUFhO0FBRlgsT0FIQSxDQUFOO0FBUUQsS0FuQkQ7QUFBQTs7QUFxQk02RSxrQkFBTixDQUF3QnZKLElBQXhCO0FBQUEsb0NBQThCO0FBQzVCLFVBQUl5USxZQUFZelEsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVixDQUg0QixDQUs1Qjs7QUFDQSxVQUFJc08sU0FBZ0JsUCxHQUFQLDZCQUFlO0FBQzFCLFlBQUlnQixNQUFPOzsyQkFFVXhDLEtBQUsyUSxVQUFXLGNBQWFuUCxHQUFJO09BRnREO0FBSUFZLFlBQUlpTixJQUFKLGVBQWUsS0FBS2UsTUFBTCxDQUFZak8sS0FBWixDQUFrQkssR0FBbEIsQ0FBZjtBQUNELE9BTlksQ0FBYixDQU40QixDQWM1Qjs7O0FBQ0EsVUFBSW9PLFFBQWVwUCxHQUFQLDZCQUFlO0FBQ3pCO0FBQ0EsWUFBSWdCLE1BQU87OzJCQUVVeEMsS0FBSzJRLFVBQVcsY0FBYW5QLEdBQUk7T0FGdEQ7QUFJQSxZQUFJcVAseUJBQWlCLEtBQUtULE1BQUwsQ0FBWWpPLEtBQVosQ0FBa0JLLEdBQWxCLENBQWpCLENBQUo7QUFDQSxZQUFJcU8sU0FBUyxDQUFULEVBQVksVUFBWixDQUFKLEVBQTZCO0FBRTdCek8sWUFBSWlOLElBQUosZUFDUSxLQUFLZSxNQUFMLENBQVl4TCxXQUFaLENBQ0osaUJBREksRUFFSixFQUZJLEVBR0o7QUFDRStMLHNCQUFZM1EsS0FBSzJRLFVBRG5CO0FBRUVuUCxlQUFLQSxHQUZQO0FBR0V1SCxzQkFBWTBILFNBSGQ7QUFJRWhNLHVCQUFhO0FBSmYsU0FISSxDQURSO0FBV0QsT0FwQlcsQ0FBWjs7QUFzQkEsV0FBSyxJQUFJcU0sTUFBVCxJQUFtQjlRLEtBQUsrUSxJQUF4QixFQUE4QjtBQUM1QixnQkFBUUQsT0FBT0UsR0FBZjtBQUNFLGVBQUssSUFBTDtBQUNFLDBCQUFNSixNQUFNRSxPQUFPdFAsR0FBYixDQUFOO0FBQ0E7O0FBQ0YsZUFBSyxLQUFMO0FBQ0UsMEJBQU1rUCxPQUFPSSxPQUFPdFAsR0FBZCxDQUFOO0FBQ0E7QUFOSjtBQVFEOztBQUVELGFBQU87QUFDTFksYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0FuREQ7QUFBQTs7QUFxRE1pSCxvQkFBTixDQUEwQnJKLElBQTFCO0FBQUEsb0NBQWdDO0FBQzlCLFVBQUlpUixZQUFZalIsS0FBSzJRLFVBQXJCO0FBQ0EsVUFBSTdELFNBQVM5TSxLQUFLOE0sTUFBbEI7QUFDQSxVQUFJMkQsWUFBWXpRLEtBQUsrSSxVQUFyQjtBQUVBLFVBQUkzRyxNQUFNLEVBQVYsQ0FMOEIsQ0FPOUI7O0FBQ0EsVUFBSUksTUFBTyxvREFBbUR5TyxTQUFVLEVBQXhFO0FBQ0E3TyxVQUFJaU4sSUFBSixlQUFlLEtBQUtlLE1BQUwsQ0FBWWpPLEtBQVosQ0FBa0JLLEdBQWxCLENBQWYsR0FUOEIsQ0FXOUI7O0FBQ0EsV0FBSyxJQUFJME8sSUFBSSxDQUFiLEVBQWdCQSxJQUFJcEUsT0FBT3FFLE1BQTNCLEVBQW1DRCxHQUFuQyxFQUF3QztBQUN0QyxzQkFBTSxLQUFLZCxNQUFMLENBQVl4TCxXQUFaLENBQ0osbUJBREksRUFDaUI7QUFDbkIrTCxzQkFBWU0sU0FETztBQUVuQmxJLHNCQUFZMEgsU0FGTztBQUduQlcscUJBQVd0RSxPQUFPb0UsQ0FBUCxDQUhRO0FBSW5CRyxnQkFBTUgsSUFBSTtBQUpTLFNBRGpCLEVBTUQ7QUFDRHpNLHVCQUFhO0FBRFosU0FOQyxDQUFOO0FBVUQ7O0FBRUQsYUFBTztBQUNMckMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0E1QkQ7QUFBQTs7QUE4Qk1rSCxlQUFOLENBQXFCdEosSUFBckI7QUFBQSxvQ0FBMkI7QUFDekIsVUFBSXNSLGFBQWEsRUFBakI7QUFDQSxVQUFJQyxPQUFPLEVBQVgsQ0FGeUIsQ0FJekI7O0FBRUFBLGFBQU8sQ0FDTCxRQURLLEVBRUwsTUFGSyxFQUdMLE1BSEssRUFJTCxrQkFKSyxFQUtMLG9CQUxLLEVBTUwsYUFOSyxFQU9MLFdBUEssQ0FBUDs7QUFTQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJdlIsS0FBS3dSLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCeFIsS0FBS3dSLENBQUwsQ0FBaEI7QUFDZDs7QUFFRCxvQkFBTSxLQUFLcEIsTUFBTCxDQUFZRSxXQUFaLENBQ0osYUFESSxFQUVILGdCQUFldFEsS0FBSzJRLFVBQVcsRUFGNUIsRUFHSlcsVUFISSxFQUdRO0FBQ1Y1TSxxQkFBYTtBQURILE9BSFIsQ0FBTixFQW5CeUIsQ0EyQnpCOztBQUVBNE0sbUJBQWEsRUFBYjtBQUNBQyxhQUFPLENBQ0wsa0JBREssRUFFTCxjQUZLLEVBR0wsWUFISyxFQUlMLFNBSkssRUFLTCxTQUxLLEVBTUwsY0FOSyxDQUFQOztBQVFBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUl2UixLQUFLd1IsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0J4UixLQUFLd1IsQ0FBTCxDQUFoQjtBQUNkOztBQUVELFVBQUlwUCxvQkFBWSxLQUFLZ08sTUFBTCxDQUFZRSxXQUFaLENBQ2QsbUJBRGMsRUFFYixnQkFBZXRRLEtBQUsyUSxVQUFXLEVBRmxCLEVBR2RXLFVBSGMsRUFHRjtBQUNWNU0scUJBQWE7QUFESCxPQUhFLENBQVosQ0FBSjtBQVFBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBckREO0FBQUE7O0FBdURNNkcsZUFBTixDQUFxQmpKLElBQXJCO0FBQUEsb0NBQTJCO0FBQ3pCLFVBQUl5USxZQUFZelEsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVjtBQUVBLFVBQUlrUCxhQUFhLEVBQWpCO0FBQ0EsVUFBSUMsT0FBTyxFQUFYO0FBRUFBLGFBQU8sQ0FDTCxNQURLLEVBRUwsb0JBRkssQ0FBUCxDQVJ5QixDQVl6QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJdlIsS0FBS3dSLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCeFIsS0FBS3dSLENBQUwsQ0FBaEI7QUFDZDs7QUFFRHBQLFVBQUl1TyxVQUFKLGlCQUF1QixLQUFLUCxNQUFMLENBQVl4TCxXQUFaLENBQ3JCLGFBRHFCLEVBRXJCME0sVUFGcUIsRUFFVDtBQUNWdkksb0JBQVkwSCxTQURGO0FBRVYvTixnQkFBUSxDQUZFO0FBR1Y4QixjQUFNLE1BSEk7QUFJVmlOLDBCQUFrQixNQUpSO0FBS1ZDLHFCQUFhLE1BTEg7QUFNVkMsbUJBQVcsTUFORDtBQU9WbE4scUJBQWEsT0FQSDtBQVFWQyxxQkFBYTtBQVJILE9BRlMsQ0FBdkI7QUFjQTRNLG1CQUFhLEVBQWI7QUFDQUMsYUFBTyxDQUNMLGNBREssRUFFTCxpQkFGSyxFQUdMLFNBSEssRUFJTCxTQUpLLEVBS0wsY0FMSyxDQUFQLENBcEN5QixDQTJDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJdlIsS0FBS3dSLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCeFIsS0FBS3dSLENBQUwsQ0FBaEI7QUFDZDs7QUFFRHBQLFVBQUl1RyxnQkFBSixpQkFBNkIsS0FBS3lILE1BQUwsQ0FBWXhMLFdBQVosQ0FDM0IsbUJBRDJCLEVBRTNCME0sVUFGMkIsRUFFZjtBQUNWdkksb0JBQVkwSCxTQURGO0FBRVZFLG9CQUFZdk8sSUFBSXVPLFVBRk47QUFHVkosZUFBTyxDQUhHO0FBSVZDLHlCQUFpQixDQUpQO0FBS1ZvQiw0QkFBb0IsTUFMVjtBQU1WQyw0QkFBb0IsTUFOVjtBQU9WQywwQkFBa0IsTUFQUjtBQVFWQyxvQkFBWSxNQVJGO0FBU1Z0TixxQkFBYSxPQVRIO0FBVVZDLHFCQUFhO0FBVkgsT0FGZSxDQUE3Qjs7QUFnQkEsV0FBSyxJQUFJOE0sQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUl2UixLQUFLd1IsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0J4UixLQUFLd1IsQ0FBTCxDQUFoQjtBQUNkOztBQUVEcFAsVUFBSTRQLGdCQUFKLGlCQUE2QixLQUFLNUIsTUFBTCxDQUFZeEwsV0FBWixDQUMzQixtQkFEMkIsRUFDTixFQURNLEVBQ0Y7QUFDdkIrRCwwQkFBa0J2RyxJQUFJdUcsZ0JBREM7QUFFdkJJLG9CQUFZMEgsU0FGVztBQUd2QkYsZUFBTyxDQUhnQjtBQUl2QjlMLHFCQUFhLE9BSlU7QUFLdkJDLHFCQUFhO0FBTFUsT0FERSxDQUE3QixFQXpFeUIsQ0FtRnpCOztBQUNBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBdkZEO0FBQUE7O0FBcEtvQixDOzs7Ozs7Ozs7OztBQ0Z0QjVELE9BQU9xUCxNQUFQLENBQWM7QUFBQ29FLG1CQUFnQixNQUFJQSxlQUFyQjtBQUFxQ0MsWUFBUyxNQUFJQSxRQUFsRDtBQUEyREMsaUJBQWMsTUFBSUEsYUFBN0U7QUFBMkZ2SyxpQkFBYyxNQUFJQTtBQUE3RyxDQUFkO0FBQTJJLElBQUltRyxLQUFKO0FBQVV2UCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNxUCxRQUFNblAsQ0FBTixFQUFRO0FBQUNtUCxZQUFNblAsQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSXdULFdBQUo7QUFBZ0I1VCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUMwVCxjQUFZeFQsQ0FBWixFQUFjO0FBQUN3VCxrQkFBWXhULENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSXNQLElBQUo7QUFBUzFQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzUCxXQUFLdFAsQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJdVAsT0FBSjtBQUFZM1AsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VQLGNBQVF2UCxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEOztBQVMxZixNQUFNcVQsZUFBTixDQUFzQjtBQUMzQjNELGNBQWEzSCxJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixRQUFJNkwsUUFBSjs7QUFDQSxZQUFRMUwsS0FBSytILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRTJELG1CQUFXLElBQUlGLGFBQUosQ0FBa0J4TCxJQUFsQixFQUF3QkgsT0FBeEIsQ0FBWDtBQUZKOztBQUtBLFdBQU82TCxRQUFQO0FBQ0Q7O0FBVDBCOztBQVl0QixNQUFNSCxRQUFOLENBQWU7QUFDcEI1RCxjQUFhM0gsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsU0FBS0csSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS0gsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7O0FBRUQsU0FBTzhMLE9BQVAsQ0FBZ0IzTCxJQUFoQixFQUFzQkgsT0FBdEIsRUFBK0I7QUFDN0IsWUFBUUcsS0FBSytILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxlQUFPLElBQUl5RCxhQUFKLENBQWtCeEwsSUFBbEIsRUFBd0JILE9BQXhCLENBQVA7O0FBQ0Y7QUFDRSxjQUFNLElBQUl5SSxLQUFKLENBQVUsbUJBQVYsQ0FBTjtBQUpKO0FBTUQ7O0FBRURzRCxhQUFZO0FBQ1YsV0FBTyxLQUFLNUwsSUFBWjtBQUNEOztBQUVENkwsYUFBWTtBQUNWLFdBQU8sS0FBSzdMLElBQUwsQ0FBVTFFLElBQWpCO0FBQ0Q7O0FBRUR3USxnQkFBZTtBQUNiLFdBQU8sS0FBS2pNLE9BQVo7QUFDRDs7QUFFRGtNLHFCQUNFQyxLQUFLLENBQU85RCxXQUFXdE0sVUFBVSxDQUFFLENBQTlCLEVBQWdDdU0sVUFBVWpLLEtBQUssQ0FBRSxDQUFqRCw4QkFBc0QsQ0FBRSxDQUF4RCxDQURQLEVBRUU7QUFDQSxTQUFLK0osTUFBTCxHQUFjK0QsRUFBZDtBQUNEO0FBRUQ7Ozs7Ozs7Ozs7O0FBU010USxTQUFOLENBQWV1USxZQUFZLEVBQTNCO0FBQUEsb0NBQStCO0FBQzdCLFVBQUlwTSxVQUFVLEtBQUtpTSxXQUFMLEVBQWQsQ0FENkIsQ0FHN0I7O0FBQ0FqTSxjQUFRNEksT0FBUixDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkI3TyxjQUFNLE1BRGE7QUFFbkIyQixlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJMFEsVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSUMsQ0FBVCxJQUFjdE0sUUFBUTRJLE9BQXRCLEVBQStCLENBQzlCOztBQUVELFVBQUlBLFVBQVUsRUFBZDs7QUFFQSxXQUFLLElBQUkwRCxDQUFULElBQWN0TSxRQUFRNEksT0FBdEIsRUFBK0I7QUFDN0J5RCxnQkFBUUMsRUFBRXRTLElBQVYsSUFBa0I7QUFDaEIyQixpQkFBTzJRLEVBQUUzUSxLQURPO0FBRWhCNFEsaUJBQU8sT0FBT0QsRUFBRUMsS0FBVCxLQUFtQixXQUFuQixHQUFpQ0QsRUFBRUMsS0FBbkMsR0FBMkMsQ0FGbEM7QUFHaEJ6RCxpQkFBTztBQUhTLFNBQWxCO0FBS0FGLGdCQUFRQyxJQUFSLENBQ0U7QUFDRTdPLGdCQUFNc1MsRUFBRXRTLElBRFY7QUFFRWdQLGdCQUFNdEIsS0FBS0MsUUFBUW9CLFFBQVIsQ0FBaUJ1RCxFQUFFM1EsS0FBbkIsQ0FBTDtBQUZSLFNBREY7QUFNRDs7QUFFRCxvQkFBTSxLQUFLeU0sTUFBTCxDQUNKLENBQU9yTSxNQUFQLEVBQWU2RixPQUFmLDhCQUEyQjtBQUN6QixhQUFLLElBQUkwSyxDQUFULElBQWMxRCxPQUFkLEVBQXVCO0FBQ3JCO0FBQ0EsY0FBSTRELElBQUlILFFBQVFDLEVBQUV0UyxJQUFWLENBQVI7O0FBQ0EsY0FBSXdTLEVBQUVELEtBQU4sRUFBYTtBQUNYLGdCQUFJQyxFQUFFMUQsS0FBRixJQUFXMEQsRUFBRUQsS0FBakIsRUFBd0I7QUFDdEI7QUFDRDtBQUNGOztBQUVELGNBQUlELEVBQUV0RCxJQUFGLENBQU9qTixNQUFQLENBQUosRUFBb0I7QUFDbEI7QUFDQXlRLGNBQUUxRCxLQUFGLEdBRmtCLENBSWxCOztBQUNBLGdCQUFJLE9BQU9zRCxVQUFVRSxFQUFFdFMsSUFBWixDQUFQLEtBQTZCLFdBQWpDLEVBQThDO0FBQzVDLDRCQUFNb1MsVUFBVUUsRUFBRXRTLElBQVosRUFBa0IrQixNQUFsQixFQUEwQjZGLE9BQTFCLENBQU47QUFDRDs7QUFDRDtBQUNEO0FBQ0Y7QUFDRixPQXJCRCxDQURJLENBQU4sRUE3QjZCLENBcUQ3Qjs7QUFDQSxhQUFPeUssT0FBUDtBQUNELEtBdkREO0FBQUE7O0FBMUNvQjs7QUFvR2YsTUFBTVYsYUFBTixTQUE0QkQsUUFBNUIsQ0FBcUM7QUFDMUM1RCxjQUFhM0gsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTUcsSUFBTixFQUFZSCxPQUFaO0FBRUEsUUFBSXZFLE9BQU8sS0FBS3VRLFFBQUwsRUFBWDtBQUVBLFNBQUs3RCxLQUFMLEdBQWEsSUFBSXhOLEtBQUosQ0FBVWMsSUFBVixDQUFiO0FBQ0EsU0FBS3lRLGtCQUFMLENBQXdCLENBQU83RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQsVUFBSXRNLE1BQU8saUJBQWdCbUUsS0FBS29JLEtBQU0sRUFBdEM7QUFDQSxVQUFJM00sb0JBQVksS0FBS3VNLEtBQUwsQ0FBV0ssY0FBWCxDQUEwQnhNLEdBQTFCLEVBQStCcU0sUUFBL0IsRUFBMENoSyxDQUFELElBQU87QUFBRSxjQUFNQSxDQUFOO0FBQVMsT0FBM0QsQ0FBWixDQUFKO0FBQ0EsYUFBT3pDLEdBQVA7QUFDRCxLQUp1QixDQUF4QjtBQUtEOztBQVp5Qzs7QUFtQnJDLE1BQU13RixhQUFOLFNBQTRCc0ssUUFBNUIsQ0FBcUM7QUFDMUM1RCxjQUFhM0gsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTUcsSUFBTixFQUFZSCxPQUFaLEVBRDBCLENBRzFCOztBQUNBLFNBQUtrTSxrQkFBTCxDQUF3QixDQUFPN0QsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBQ25ELFVBQUltRSxNQUFKO0FBQ0FBLDZCQUFlYixZQUFZYyxPQUFaLENBQW9Cdk0sS0FBSzZELEdBQXpCLENBQWYsRUFGbUQsQ0FJbkQ7O0FBQ0EsVUFBSS9ELEtBQUt3TSxPQUFPeE0sRUFBUCxDQUFVRSxLQUFLd00sUUFBZixDQUFUO0FBQ0EsVUFBSXBNLGFBQWFOLEdBQUdNLFVBQUgsQ0FBY0osS0FBS0ksVUFBbkIsQ0FBakI7QUFFQSxVQUFJcUIsVUFBVTtBQUNaNkssZ0JBQVFBLE1BREk7QUFFWmxNLG9CQUFZQSxVQUZBO0FBR1pvTSxrQkFBVTFNO0FBSEUsT0FBZDtBQU1BLFVBQUlvSixNQUFNOUksV0FBV0MsSUFBWCxFQUFWLENBZG1ELENBZ0JuRDs7QUFDQTZJLFVBQUl1RCxhQUFKLENBQWtCLGlCQUFsQixFQUFxQyxJQUFyQyxFQWpCbUQsQ0FtQm5EOztBQUNBLFVBQUk7QUFDRiw2QkFBYXZELElBQUl3RCxPQUFKLEVBQWIsR0FBNEI7QUFDMUIsY0FBSS9TLG9CQUFZdVAsSUFBSXlELElBQUosRUFBWixDQUFKO0FBQ0Esd0JBQU16RSxTQUFTdk8sR0FBVCxFQUFjOEgsT0FBZCxDQUFOO0FBQ0Q7O0FBQUE7QUFDRixPQUxELFNBS1U7QUFDUjtBQUNBLHNCQUFNeUgsSUFBSWpDLEtBQUosRUFBTjtBQUNEO0FBQ0YsS0E3QnVCLENBQXhCO0FBOEJEOztBQW5DeUMsQzs7Ozs7Ozs7Ozs7QUM1STVDcFAsT0FBT3FQLE1BQVAsQ0FBYztBQUFDbFAsV0FBUSxNQUFJd0k7QUFBYixDQUFkO0FBQTRDLElBQUlULGVBQUo7QUFBb0JsSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNnSSxrQkFBZ0I5SCxDQUFoQixFQUFrQjtBQUFDOEgsc0JBQWdCOUgsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXRDLEVBQThFLENBQTlFO0FBQWlGLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBOUMsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSTJVLFFBQUo7QUFBYS9VLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQzZVLFdBQVMzVSxDQUFULEVBQVc7QUFBQzJVLGVBQVMzVSxDQUFUO0FBQVc7O0FBQXhCLENBQTdCLEVBQXVELENBQXZEO0FBQTBELElBQUk0VSxRQUFKO0FBQWFoVixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDNFUsZUFBUzVVLENBQVQ7QUFBVzs7QUFBdkIsQ0FBckMsRUFBOEQsQ0FBOUQ7O0FBVzNTLE1BQU11SSxjQUFOLENBQXFCO0FBQzVCSyxNQUFOLENBQVliLElBQVo7QUFBQSxvQ0FBa0I7QUFDaEIsV0FBSzhNLEtBQUwsaUJBQW1CL00sZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEIsT0FBMUIsQ0FBbkI7QUFDQSxXQUFLK00sUUFBTCxpQkFBc0JoTixnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQixVQUExQixDQUF0QjtBQUNELEtBSEQ7QUFBQTs7QUFLTTJCLFVBQU4sQ0FBZ0JxTCxNQUFoQjtBQUFBLG9DQUF3QjtBQUN0QixVQUFJQyx3QkFBZ0IsS0FBS0gsS0FBTCxDQUFXakYsT0FBWCxDQUFtQjtBQUNyQ2pHLGFBQUtvTDtBQURnQyxPQUFuQixFQUVqQjtBQUNEL00sb0JBQVk7QUFDVixxQkFBVztBQUREO0FBRFgsT0FGaUIsQ0FBaEIsQ0FBSjtBQU9BLFVBQUlpTixjQUFjRCxRQUFRRSxPQUExQixDQVJzQixDQVV0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQUlDLGFBQWEsRUFBakI7O0FBRUEsV0FBSyxJQUFJQyxVQUFULElBQXVCSCxXQUF2QixFQUFvQztBQUNsQyxZQUFJSSxjQUFjLENBQWxCOztBQUVBLGFBQUssSUFBSWhELFNBQVQsSUFBc0IrQyxVQUF0QixFQUFrQztBQUNoQyxjQUFJSix3QkFBZ0IsS0FBS0YsUUFBTCxDQUFjbEYsT0FBZCxDQUFzQjtBQUN4Q2pHLGlCQUFLMEk7QUFEbUMsV0FBdEIsRUFFakI7QUFDRHJLLHdCQUFZO0FBQ1YsdUJBQVM7QUFEQztBQURYLFdBRmlCLENBQWhCLENBQUo7QUFPQSxjQUFJc04sYUFBYU4sUUFBUXJELEtBQXpCLENBUmdDLENBVWhDOztBQUNBLGVBQUssSUFBSUEsS0FBVCxJQUFrQjJELFVBQWxCLEVBQThCO0FBQzVCRCwyQkFBZTFELE1BQU1sSSxRQUFyQjtBQUNEO0FBQ0Y7O0FBRUQwTCxtQkFBVzFFLElBQVgsQ0FBZ0I0RSxXQUFoQjtBQUNELE9BdENxQixDQXdDdEI7OztBQUNBLFVBQUk1TCxXQUFXOEwsS0FBS0MsR0FBTCxDQUFTQyxLQUFULENBQWUsSUFBZixFQUFxQk4sVUFBckIsQ0FBZjtBQUVBLGFBQU8xTCxRQUFQO0FBQ0QsS0E1Q0Q7QUFBQTtBQThDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQk1YLFVBQU4sQ0FBZ0I3SCxRQUFoQixFQUEwQnVILEtBQTFCLEVBQWlDQyxTQUFTLElBQTFDLEVBQWdEQyxTQUFTLElBQXpEO0FBQUEsb0NBQStEO0FBQzdEO0FBQ0EsVUFBSXdGLFNBQVMvTixRQUFRaUksSUFBUixDQUFhO0FBQ3hCbkgsa0JBQVVBO0FBRGMsT0FBYixFQUVWeVUsS0FGVSxHQUVGcEksR0FGRSxDQUVHdE4sQ0FBRCxJQUFPQSxFQUFFNkIsZ0JBRlgsQ0FBYixDQUY2RCxDQU03RDs7QUFDQSxVQUFJbUIsU0FBUyxFQUFiO0FBQ0FBLGFBQU93RixLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQVl6RixPQUFPMlMsWUFBUCxHQUFzQmxOLE1BQXRCO0FBQ1osVUFBSUMsTUFBSixFQUFZMUYsT0FBTzRTLFlBQVAsR0FBc0JsTixNQUF0QjtBQUVaLFVBQUlsRixvQkFBWSxLQUFLcVIsS0FBTCxDQUFXZ0IsVUFBWCxDQUNkN1MsTUFEYyxFQUNOO0FBQ044UyxlQUFPO0FBQ0w1SCxrQkFBUTtBQUNONkgsbUJBQU83SDtBQUREO0FBREg7QUFERCxPQURNLENBQVosQ0FBSixDQVo2RCxDQXNCN0Q7O0FBQ0EsYUFBT0EsTUFBUDtBQUNELEtBeEJEO0FBQUE7QUEwQkE7Ozs7Ozs7Ozs7QUFRTW5GLFlBQU4sQ0FBa0JQLEtBQWxCLEVBQXlCQyxTQUFTLElBQWxDLEVBQXdDQyxTQUFTLElBQWpEO0FBQUEsb0NBQXVEO0FBQ3JEO0FBQ0EsVUFBSTFGLFNBQVMsRUFBYjtBQUNBQSxhQUFPd0YsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFZekYsT0FBTzJTLFlBQVAsR0FBc0JsTixNQUF0QjtBQUNaLFVBQUlDLE1BQUosRUFBWTFGLE9BQU80UyxZQUFQLEdBQXNCbE4sTUFBdEI7QUFFWixVQUFJbEYsb0JBQVksS0FBS3FSLEtBQUwsQ0FBV2dCLFVBQVgsQ0FDZDdTLE1BRGMsRUFDTjtBQUNOdUgsY0FBTTtBQUNKMkQsa0JBQVE7QUFESjtBQURBLE9BRE0sQ0FBWixDQUFKO0FBT0QsS0FkRDtBQUFBO0FBZ0JBOzs7Ozs7Ozs7Ozs7Ozs7O0FBY004SCxjQUFOLENBQW9Cek0sSUFBcEIsRUFBMEJ5TCxPQUExQjtBQUFBLG9DQUFtQztBQUNqQzs7Ozs7Ozs7QUFRQSxVQUFJNUMsTUFBTSxDQUFDO0FBQ1Q2RCxlQUFPLE1BREU7QUFFVEMsaUJBQVMzTSxLQUFLNE0sUUFGTDtBQUdUbkIsaUJBQVM7QUFDUG9CLGlCQUFPO0FBREEsU0FIQTtBQU1UN1MsZUFBTztBQUNMb1Msd0JBQWNwTSxLQUFLb00sWUFEZDtBQUVMQyx3QkFBY3JNLEtBQUtxTTtBQUZkO0FBTkUsT0FBRCxFQVdWO0FBQ0VLLGVBQU8xTSxLQUFLOE0sV0FEZDtBQUVFSCxpQkFBUzNNLEtBQUtvTSxZQUZoQjtBQUdFWCxpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUU3UyxlQUFPO0FBQ0w0UyxvQkFBVTVNLEtBQUs0TSxRQURWO0FBRUxQLHdCQUFjck0sS0FBS3FNO0FBRmQ7QUFOVCxPQVhVLEVBc0JWO0FBQ0VLLGVBQU8xTSxLQUFLK00sV0FEZDtBQUVFSixpQkFBUzNNLEtBQUtxTSxZQUZoQjtBQUdFWixpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUU3UyxlQUFPO0FBQ0w0UyxvQkFBVTVNLEtBQUs0TSxRQURWO0FBRUxSLHdCQUFjcE0sS0FBS29NO0FBRmQ7QUFOVCxPQXRCVSxDQUFWO0FBbUNBLFVBQUlZLFFBQVEsRUFBWjs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY3BFLEdBQWQsRUFBbUI7QUFDakJtRSxjQUFNOUYsSUFBTixDQUFXO0FBQ1RnRyxvQ0FBa0IsS0FBSzVCLEtBQUwsQ0FBV3ZNLFNBQVgsQ0FDaEIsQ0FBQztBQUNDb08sb0JBQVFDLE9BQU9DLE1BQVAsQ0FBY0osRUFBRWpULEtBQWhCLEVBQXVCO0FBQzdCaUYscUJBQU9lLEtBQUtmO0FBRGlCLGFBQXZCO0FBRFQsV0FBRCxFQUtBO0FBQ0VxTyxzQkFBVUYsT0FBT0MsTUFBUCxDQUFjSixFQUFFeEIsT0FBaEIsRUFBeUJBLE9BQXpCO0FBRFosV0FMQSxFQVFBO0FBQ0U4QixtQkFBTztBQUNMbk4sbUJBQUs7QUFEQTtBQURULFdBUkEsQ0FEZ0IsRUFlaEJ0QixPQWZnQixFQUFsQixDQURTO0FBaUJUME8saUJBQU9QO0FBakJFLFNBQVg7QUFtQkQ7O0FBRUQsV0FBSyxJQUFJUSxJQUFULElBQWlCVCxLQUFqQixFQUF3QjtBQUN0QixhQUFLLElBQUl2VyxDQUFULElBQWNnWCxLQUFLUCxVQUFuQixFQUErQjtBQUM3QnpXLFlBQUUyUixLQUFGLGlCQUFnQixLQUFLakksUUFBTCxDQUFjMUosRUFBRTJKLEdBQWhCLENBQWhCO0FBQ0Q7QUFDRjs7QUFFRCxhQUFPNE0sS0FBUDtBQUNELEtBM0VEO0FBQUEsR0F6SWtDLENBc05sQztBQUNBOzs7QUFDTXpKLGVBQU4sQ0FBcUJpQixHQUFyQjtBQUFBLG9DQUEwQjtBQUN4QixVQUFJeEUsSUFBSixDQUR3QixDQUV4Qjs7QUFDQSxVQUFJLE9BQU93RSxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0IsWUFBSWtKLE1BQU0sSUFBSUMsTUFBSixDQUFZLEdBQUVuSixHQUFJLEdBQWxCLENBQVY7QUFDQSxZQUFJa0QsTUFBTSxLQUFLNEQsS0FBTCxDQUFXek0sSUFBWCxDQUFnQixFQUFoQixFQUFvQjtBQUM1Qkosc0JBQVk7QUFDVlEsbUJBQU8sQ0FERztBQUVWbU4sMEJBQWMsQ0FGSjtBQUdWQywwQkFBYztBQUhKO0FBRGdCLFNBQXBCLENBQVY7O0FBUUEsZUFBTyxDQUFQLEVBQVU7QUFDUixjQUFJO0FBQ0ZyTSxpQ0FBYTBILElBQUl5RCxJQUFKLEVBQWI7QUFDQSxnQkFBSXlDLHNCQUFjNU4sS0FBS0ksR0FBTCxDQUFTeU4sV0FBVCxHQUF1QkQsS0FBdkIsQ0FBNkJGLEdBQTdCLENBQWQsQ0FBSjs7QUFDQSxnQkFBSUUsS0FBSixFQUFXO0FBQ1Q7QUFDRDtBQUNGLFdBTkQsQ0FNRSxPQUFPbFIsQ0FBUCxFQUFVO0FBQ1Y7QUFDQWdMLGdCQUFJakMsS0FBSjtBQUNBLG1CQUFPakIsR0FBUDtBQUNEO0FBQ0Y7O0FBQ0RrRCxZQUFJakMsS0FBSjtBQUNELE9BeEJELE1Bd0JPO0FBQ0x6RixlQUFPd0UsR0FBUDtBQUNEOztBQUVELFVBQUlzSixhQUFhLEVBQWpCO0FBQ0EsVUFBSTlOLEtBQUtmLEtBQVQsRUFBZ0I2TyxXQUFXNUcsSUFBWCxDQUFnQmxILEtBQUtmLEtBQXJCO0FBQ2hCLFVBQUllLEtBQUtvTSxZQUFULEVBQXVCMEIsV0FBVzVHLElBQVgsQ0FBZ0JsSCxLQUFLb00sWUFBckI7QUFDdkIsVUFBSXBNLEtBQUtxTSxZQUFULEVBQXVCeUIsV0FBVzVHLElBQVgsQ0FBZ0JsSCxLQUFLcU0sWUFBckI7QUFDdkIsYUFBT3lCLFdBQVc5SixJQUFYLENBQWdCLEdBQWhCLENBQVA7QUFDRCxLQXBDRDtBQUFBOztBQXNDTXJELGtCQUFOLENBQXdCMkgsU0FBeEIsRUFBbUN0SSxJQUFuQztBQUFBLG9DQUF5QztBQUN2QztBQUNBLFVBQUkrTixZQUFhbkIsUUFBRCxJQUFjQSxhQUFhLFFBQWIsR0FBd0IsT0FBeEIsR0FBa0NBLFFBQWhFLENBRnVDLENBSXZDOzs7QUFDQSxVQUFJOUQsWUFBWSxJQUFoQjtBQUNBLFVBQUlnRixhQUFhLEVBQWpCLENBTnVDLENBUXZDO0FBQ0E7O0FBQ0EsVUFBSTlOLEtBQUtmLEtBQVQsRUFBZ0I2TyxXQUFXNUcsSUFBWCxDQUFnQmxILEtBQUtmLEtBQXJCO0FBQ2hCLFVBQUllLEtBQUtvTSxZQUFULEVBQXVCMEIsV0FBVzVHLElBQVgsQ0FBZ0JsSCxLQUFLb00sWUFBckI7QUFDdkIsVUFBSXBNLEtBQUtxTSxZQUFULEVBQXVCeUIsV0FBVzVHLElBQVgsQ0FBZ0JsSCxLQUFLcU0sWUFBckIsRUFaZ0IsQ0FjdkM7O0FBQ0EsVUFBSTJCLGFBQUo7O0FBQ0EsY0FBUWhPLEtBQUs0TSxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VvQiwwQkFBZ0IsQ0FBaEI7QUFDQTs7QUFDRixhQUFLLFFBQUw7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7O0FBQ0Y7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7QUFUSixPQWhCdUMsQ0E0QnZDOzs7QUFDQSxVQUFJcEYsT0FBTyxFQUFYOztBQUNBLGNBQVE1SSxLQUFLNE0sUUFBYjtBQUNFLGFBQUssS0FBTDtBQUNFaEUsZUFBSzFCLElBQUwsQ0FBVTtBQUNSN04saUJBQUssQ0FERztBQUVSd1AsaUJBQUs7QUFGRyxXQUFWLEVBR0c7QUFDRHhQLGlCQUFLLENBREo7QUFFRHdQLGlCQUFLO0FBRkosV0FISDtBQU9BOztBQUNGLGFBQUssUUFBTDtBQUNFRCxlQUFLMUIsSUFBTCxDQUFVO0FBQ1I3TixpQkFBSyxDQURHO0FBRVJ3UCxpQkFBSztBQUZHLFdBQVYsRUFHRztBQUNEeFAsaUJBQUssQ0FESjtBQUVEd1AsaUJBQUs7QUFGSixXQUhIO0FBT0E7QUFsQkosT0E5QnVDLENBbUR2Qzs7O0FBQ0EsVUFBSW9GLGNBQWMsSUFBbEI7O0FBQ0EsY0FBUWpPLEtBQUs0TSxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VxQix3QkFBYyxJQUFkO0FBQ0E7O0FBQ0YsYUFBSyxRQUFMO0FBQ0VBLHdCQUFjLEdBQWQ7QUFDQTtBQU5KLE9BckR1QyxDQThEdkM7QUFDQTtBQUNBOzs7QUFFQSxVQUFJakIsc0JBQWMsS0FBS1AsWUFBTCxDQUFrQnpNLElBQWxCLEVBQXdCO0FBQ3hDd0ksb0JBQVk7QUFENEIsT0FBeEIsQ0FBZCxDQUFKLENBbEV1QyxDQXNFdkM7QUFFQTs7QUFDQXdFLGNBQVFBLE1BQU1qSixHQUFOLENBQ0wwSixJQUFELElBQVU7QUFDUkEsYUFBS0QsS0FBTCxDQUFXYixPQUFYLEdBQXFCb0IsVUFBVU4sS0FBS0QsS0FBTCxDQUFXYixPQUFyQixDQUFyQjtBQUNBYyxhQUFLUCxVQUFMLEdBQWtCTyxLQUFLUCxVQUFMLENBQWdCbkosR0FBaEIsQ0FDZm1LLFNBQUQsSUFBZTtBQUNiQSxvQkFBVXJCLEtBQVYsR0FBa0JrQixVQUFVRyxVQUFVckIsS0FBcEIsQ0FBbEI7QUFDQSxpQkFBT3FCLFNBQVA7QUFDRCxTQUplLENBQWxCO0FBTUEsZUFBT1QsSUFBUDtBQUNELE9BVkssQ0FBUixDQXpFdUMsQ0FzRnZDOztBQUNBLFVBQUlVLGdCQUNGbkIsTUFBTWpKLEdBQU4sQ0FDRzBKLElBQUQsSUFDRSxrQ0FDRCxtQkFEQyxHQUVELGlFQUZDLEdBR0QsV0FBVUEsS0FBS0QsS0FBTCxDQUFXZCxLQUFNLFdBSDFCLEdBSUQsUUFKQyxHQUtGZSxLQUFLUCxVQUFMLENBQWdCbkosR0FBaEIsQ0FDR21LLFNBQUQsSUFBZTtBQUNiLFlBQUlULEtBQUtELEtBQUwsQ0FBV2IsT0FBWCxLQUF1QnVCLFVBQVVyQixLQUFyQyxFQUE0QztBQUMxQztBQUNBLGlCQUFRLHdFQUF1RXFCLFVBQVVyQixLQUFNLG9CQUEvRjtBQUNELFNBSEQsTUFJQSxJQUFJcUIsVUFBVTlGLEtBQVYsR0FBa0IsQ0FBdEIsRUFBeUI7QUFDdkI7QUFDQSxpQkFBUSw2QkFBNEI4RixVQUFVMUYsVUFBVyxrRUFBaUUwRixVQUFVckIsS0FBTSxlQUExSTtBQUNELFNBSEQsTUFHTztBQUNMO0FBQ0EsaUJBQVEsNEhBQTJIcUIsVUFBVXJCLEtBQU0sV0FBbko7QUFDRDtBQUNGLE9BYkgsRUFjRTdJLElBZEYsQ0FjTyxFQWRQLENBTEUsR0FvQkYsUUFwQkUsR0FxQkYsUUF2QkYsRUF3QkVBLElBeEJGLENBd0JPLEVBeEJQLENBREY7QUEyQkEsVUFBSW9LLG9CQUFxQjs7TUFFdkJELGFBQWM7S0FGaEIsQ0FsSHVDLENBdUh2Qzs7QUFDQSxVQUFJdFcsT0FBTztBQUNUMlEsb0JBQVlNLFNBREg7QUFFVGxJLG9CQUFZMEgsU0FGSDtBQUdUalEsY0FBTyxHQUFFeVYsV0FBVzlKLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBcUIsSUFBRytKLFVBQVUvTixLQUFLNE0sUUFBZixDQUF5QixJQUFHNU0sS0FBSzNILElBQUssSUFBRzJILEtBQUtxTyxRQUFTLEVBSC9FO0FBSVRDLDRCQUFvQkYsaUJBSlg7QUFLVDVFLG1CQUFXeEosS0FBS3VPLFdBQUwsR0FBbUIsR0FMckI7QUFNVEMsc0JBQWNWLFdBQVc5SixJQUFYLENBQWdCLEdBQWhCLENBTkw7QUFPVHlLLGlCQUFTek8sS0FBSzBPLFlBUEw7QUFRVEMsaUJBQVMzTyxLQUFLNE8sV0FBTCxHQUFtQixJQVJuQjtBQVF5QjtBQUNsQ2pLLGdCQUFRM0UsS0FBSzJFLE1BVEo7QUFVVGtLLHlCQUFpQmIsYUFWUjtBQVdUcEYsY0FBTUEsSUFYRztBQVlUa0csc0JBQWNiO0FBWkwsT0FBWDtBQWVBYixhQUFPQyxNQUFQLENBQWN4VixJQUFkLEVBQW9CbUksS0FBS00sSUFBTCxDQUFVQyxXQUE5QjtBQUVBLGFBQU8xSSxJQUFQO0FBQ0QsS0ExSUQ7QUFBQSxHQTlQa0MsQ0EwWWxDOzs7QUFDTTBOLGtCQUFOLENBQXdCd0osR0FBeEIsRUFBNkIvTyxJQUE3QjtBQUFBLG9DQUFtQztBQUNqQyxZQUFNZ1AsV0FBVyxFQUFqQjtBQUNBLFlBQU1DLGNBQWMsR0FBcEI7QUFFQSxVQUFJeEssUUFBUSxFQUFaLENBSmlDLENBS2pDOztBQUNBQSxjQUFRN0wsS0FBS3VKLEtBQUwsQ0FBV3ZKLEtBQUtDLFNBQUwsQ0FBZWtXLElBQUkvTyxLQUFLNE0sUUFBVCxDQUFmLENBQVgsQ0FBUixDQU5pQyxDQVFqQzs7QUFDQSxZQUFNc0MsWUFBWSxJQUFsQjs7QUFDQSxXQUFLLElBQUluRyxJQUFJLENBQWIsRUFBZ0JBLElBQUkvSSxLQUFLMkUsTUFBTCxDQUFZcUUsTUFBaEMsRUFBd0NELEdBQXhDLEVBQTZDO0FBQzNDdEUsY0FBTXlLLGFBQWFuRyxJQUFJLENBQWpCLENBQU4sSUFBNkIvSSxLQUFLMkUsTUFBTCxDQUFZb0UsQ0FBWixDQUE3QjtBQUNELE9BWmdDLENBY2pDOzs7QUFDQXRFLFlBQU0sTUFBTixJQUFnQnpFLEtBQUtNLElBQUwsQ0FBVW1FLEtBQVYsQ0FBZ0IwSyxRQUFoQztBQUNBMUssWUFBTSxNQUFOLElBQWdCNEcsU0FBUytELE9BQVQsQ0FBa0IsR0FBRCxjQUFTLEtBQUs3TCxhQUFMLENBQW1CdkQsSUFBbkIsQ0FBVCxDQUFrQyxJQUFHQSxLQUFLNE0sUUFBUyxJQUFHNU0sS0FBSzNILElBQUssRUFBakYsRUFBb0Y0VyxXQUFwRixDQUFoQjtBQUNBeEssWUFBTSxNQUFOLElBQWdCekUsS0FBSzRPLFdBQXJCO0FBQ0FuSyxZQUFNLE1BQU4sSUFBZ0J6RSxLQUFLNE8sV0FBckI7QUFDQW5LLFlBQU0sTUFBTixJQUFnQnpFLEtBQUtJLEdBQUwsQ0FBU3lOLFdBQVQsR0FBdUIxSixLQUF2QixDQUE2QixDQUFDNkssUUFBOUIsQ0FBaEI7QUFDQXZLLFlBQU0sSUFBTixJQUFjekUsS0FBS3VPLFdBQW5CO0FBQ0E5SixZQUFNLGdCQUFOLElBQTBCekUsS0FBS3FPLFFBQS9CO0FBRUEsYUFBTzVKLEtBQVA7QUFDRCxLQXhCRDtBQUFBOztBQTNZa0MsQzs7Ozs7Ozs7Ozs7QUNYcENwTyxPQUFPcVAsTUFBUCxDQUFjO0FBQUNsUCxXQUFRLE1BQUk2WTtBQUFiLENBQWQ7O0FBQWUsTUFBTUEsU0FBTixDQUFnQjtBQUM3QixTQUFPbE4sS0FBUCxDQUFjekYsQ0FBZCxFQUFpQjtBQUNmLFFBQUl6QyxNQUFNLEVBQVY7O0FBRUEsUUFBSXlDLGFBQWFvSyxLQUFqQixFQUF3QjtBQUN0QjdNLFVBQUlxVixPQUFKLEdBQWM1UyxFQUFFNFMsT0FBaEI7QUFDQXJWLFVBQUk1QixJQUFKLEdBQVdxRSxFQUFFckUsSUFBYjtBQUNBNEIsVUFBSXNWLFFBQUosR0FBZTdTLEVBQUU2UyxRQUFqQjtBQUNBdFYsVUFBSXVWLFVBQUosR0FBaUI5UyxFQUFFOFMsVUFBbkI7QUFDQXZWLFVBQUl3VixZQUFKLEdBQW1CL1MsRUFBRStTLFlBQXJCO0FBQ0F4VixVQUFJeVYsS0FBSixHQUFZaFQsRUFBRWdULEtBQWQ7QUFDRCxLQVBELE1BT087QUFDTHpWLFlBQU15QyxDQUFOO0FBQ0Q7O0FBRUQsV0FBT3pDLEdBQVA7QUFDRDs7QUFoQjRCLEM7Ozs7Ozs7Ozs7O0FDQS9CNUQsT0FBT3FQLE1BQVAsQ0FBYztBQUFDbkgsbUJBQWdCLE1BQUlBO0FBQXJCLENBQWQ7QUFBcUQsSUFBSTBMLFdBQUo7QUFBZ0I1VCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUMwVCxjQUFZeFQsQ0FBWixFQUFjO0FBQUN3VCxrQkFBWXhULENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7O0FBRTlELE1BQU04SCxlQUFOLENBQXNCO0FBQzNCLFNBQWFJLEdBQWIsQ0FBa0JILElBQWxCLEVBQXdCSSxVQUF4QjtBQUFBLG9DQUFvQztBQUNsQyxVQUFJa00sdUJBQWViLFlBQVljLE9BQVosQ0FBb0J2TSxLQUFLNkQsR0FBekIsQ0FBZixDQUFKO0FBQ0EsVUFBSS9ELEtBQUt3TSxPQUFPeE0sRUFBUCxDQUFVRSxLQUFLd00sUUFBZixDQUFUO0FBQ0EsYUFBTzFNLEdBQUdNLFVBQUgsQ0FBY0EsVUFBZCxDQUFQO0FBQ0QsS0FKRDtBQUFBOztBQUQyQixDOzs7Ozs7Ozs7OztBQ0Y3QnZJLE9BQU9xUCxNQUFQLENBQWM7QUFBQ2xQLFdBQVEsTUFBSXdDO0FBQWIsQ0FBZDtBQUFtQyxJQUFJd04sS0FBSjtBQUFVblEsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQytQLFlBQU0vUCxDQUFOO0FBQVE7O0FBQXBCLENBQTlCLEVBQW9ELENBQXBEO0FBQXVELElBQUlrWixNQUFKO0FBQVd0WixPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDa1osYUFBT2xaLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7O0FBR2hHLE1BQU11QyxLQUFOLENBQVk7QUFDekJtTixjQUFhOUgsT0FBYixFQUFzQjtBQUNwQjtBQUNBLFNBQUt1UixJQUFMLEdBQVlwSixNQUFNcUosVUFBTixDQUFpQnhSLE9BQWpCLENBQVosQ0FGb0IsQ0FJcEI7O0FBQ0EsUUFBSXlSLGVBQWU7QUFBQ0MsMEJBQW9CO0FBQXJCLEtBQW5CO0FBQ0EzQyxXQUFPQyxNQUFQLENBQWN5QyxZQUFkLEVBQTRCelIsT0FBNUI7QUFDQSxTQUFLMlIsU0FBTCxHQUFpQnhKLE1BQU1xSixVQUFOLENBQWlCQyxZQUFqQixDQUFqQjtBQUNEOztBQUVELFNBQU9HLFVBQVAsQ0FBbUJDLElBQW5CLEVBQXlCO0FBQ3ZCLFdBQU9QLE9BQU9PLElBQVAsRUFBYUMsTUFBYixHQUFzQmpULFNBQXRCLENBQWdDLENBQWhDLEVBQW1DLEVBQW5DLEVBQXVDa1QsT0FBdkMsQ0FBK0MsR0FBL0MsRUFBb0QsR0FBcEQsQ0FBUDtBQUNEO0FBRUQ7Ozs7OztBQUlBcFcsUUFBT0ssR0FBUCxFQUFZO0FBQ1Y7QUFDQTtBQUNBLFdBQU8sS0FBS2dXLE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUk1SSxPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBQ25CO0FBQ0EwSSxZQUFJdlcsS0FBSixDQUFVSyxHQUFWLEVBQWUsQ0FBQ3FDLENBQUQsRUFBSXpDLEdBQUosS0FBWTtBQUN6QjtBQUNBc1csY0FBSUMsT0FBSjs7QUFDQSxjQUFJOVQsQ0FBSixFQUFPO0FBQ0xtTCxtQkFBT25MLENBQVA7QUFDRCxXQUZELE1BRU9rTCxRQUFRM04sR0FBUjtBQUNSLFNBTkQ7QUFPRCxPQVZJLENBQVA7QUFZRCxLQWZFLEVBaUJKK04sS0FqQkksQ0FpQkd0TCxDQUFELElBQU87QUFDWixZQUFNQSxDQUFOO0FBQ0QsS0FuQkksQ0FBUDtBQW9CRDs7QUFFSytULGNBQU4sQ0FBb0JwVyxHQUFwQjtBQUFBLG9DQUF5QjtBQUN2QixVQUFJSixvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT0osSUFBSXlXLFFBQVg7QUFDRCxLQUhEO0FBQUE7QUFLQTs7Ozs7Ozs7QUFNTWpVLGFBQU4sQ0FBbUJtSyxLQUFuQixFQUEwQi9PLE9BQU8sRUFBakMsRUFBcUM4WSxVQUFVLEVBQS9DO0FBQUEsb0NBQW1EO0FBQ2pEO0FBQ0E7QUFFQSxVQUFJdFcsTUFBTyxlQUFjdU0sS0FBTSxHQUEvQjtBQUVBLFVBQUk3QyxNQUFNLElBQUk2TSxHQUFKLEVBQVY7O0FBQ0EsV0FBSyxJQUFJdkgsQ0FBVCxJQUFjK0QsT0FBT2hFLElBQVAsQ0FBWXZSLElBQVosQ0FBZCxFQUFpQztBQUMvQixZQUFJQSxLQUFLd1IsQ0FBTCxNQUFZLElBQWhCLEVBQXNCO0FBQ3BCdEYsY0FBSThFLEdBQUosQ0FBUVEsQ0FBUixFQUFXLE1BQVg7QUFDRCxTQUZELE1BRU8sSUFBSXhSLEtBQUt3UixDQUFMLEVBQVFsRCxXQUFSLENBQW9COU4sSUFBcEIsS0FBNkIsTUFBakMsRUFBeUM7QUFDOUM7QUFDQTBMLGNBQUk4RSxHQUFKLENBQVFRLENBQVIsRUFBWSxJQUFHclEsTUFBTWlYLFVBQU4sQ0FBaUJwWSxLQUFLd1IsQ0FBTCxDQUFqQixDQUEwQixHQUF6QztBQUNELFNBSE0sTUFHQTtBQUNMdEYsY0FBSThFLEdBQUosQ0FBUVEsQ0FBUixFQUFZLEdBQUU3QyxNQUFNcUssTUFBTixDQUFhaFosS0FBS3dSLENBQUwsQ0FBYixDQUFzQixFQUFwQztBQUNEO0FBQ0Y7O0FBQ0QsV0FBSyxJQUFJQSxDQUFULElBQWMrRCxPQUFPaEUsSUFBUCxDQUFZdUgsT0FBWixDQUFkLEVBQW9DO0FBQ2xDNU0sWUFBSThFLEdBQUosQ0FBUVEsQ0FBUixFQUFXc0gsUUFBUXRILENBQVIsTUFBZSxJQUFmLEdBQXNCLE1BQXRCLEdBQStCc0gsUUFBUXRILENBQVIsQ0FBMUM7QUFDRDs7QUFFRGhQLGFBQVEsS0FBSSxDQUFDLEdBQUcwSixJQUFJcUYsSUFBSixFQUFKLEVBQWdCcEYsSUFBaEIsQ0FBcUIsR0FBckIsQ0FBMEIsS0FBdEM7QUFFQTNKLGFBQVEsV0FBVSxDQUFDLEdBQUcwSixJQUFJK00sTUFBSixFQUFKLEVBQWtCOU0sSUFBbEIsQ0FBdUIsR0FBdkIsQ0FBNEIsS0FBOUM7QUFFQSxVQUFJL0osb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9KLElBQUl5VyxRQUFYO0FBQ0QsS0EzQkQ7QUFBQTtBQTZCQTs7Ozs7Ozs7O0FBT012SSxhQUFOLENBQW1CdkIsS0FBbkIsRUFBMEJuTixNQUExQixFQUFrQzVCLElBQWxDLEVBQXdDOFksT0FBeEM7QUFBQSxvQ0FBaUQ7QUFDL0MsVUFBSXRXLE1BQU8sVUFBU3VNLEtBQU0sT0FBMUI7QUFFQSxVQUFJbUssVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSTFILENBQVQsSUFBYytELE9BQU9oRSxJQUFQLENBQVl2UixJQUFaLENBQWQsRUFBaUM7QUFDL0JrWixnQkFBUTdKLElBQVIsQ0FBYyxHQUFFbUMsQ0FBRSxJQUFHN0MsTUFBTXFLLE1BQU4sQ0FBYWhaLEtBQUt3UixDQUFMLENBQWIsQ0FBc0IsRUFBM0M7QUFDRDs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBYytELE9BQU9oRSxJQUFQLENBQVl1SCxPQUFaLENBQWQsRUFBb0M7QUFDbENJLGdCQUFRN0osSUFBUixDQUFjLEdBQUVtQyxDQUFFLElBQUdzSCxRQUFRdEgsQ0FBUixDQUFXLEVBQWhDO0FBQ0Q7O0FBQ0RoUCxhQUFPMFcsUUFBUS9NLElBQVIsQ0FBYSxHQUFiLENBQVA7QUFFQTNKLGFBQVEsVUFBU1osTUFBTyxHQUF4QjtBQUVBLFVBQUlRLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPSixHQUFQO0FBQ0QsS0FoQkQ7QUFBQSxHQTNGeUIsQ0E2R3pCOzs7QUFDTStXLFlBQU4sQ0FBa0IzVyxHQUFsQjtBQUFBLG9DQUF1QjtBQUNyQixVQUFJNFcsV0FBVyxLQUFLckIsSUFBcEI7QUFDQSxXQUFLQSxJQUFMLEdBQVksS0FBS0ksU0FBakI7O0FBQ0EsVUFBSTtBQUNGLFlBQUkvVixvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsZUFBT0osR0FBUDtBQUNELE9BSEQsU0FHVTtBQUNSLGFBQUsyVixJQUFMLEdBQVlxQixRQUFaO0FBQ0Q7QUFDRixLQVREO0FBQUE7O0FBV01DLGtCQUFOO0FBQUEsb0NBQTBCO0FBQ3hCLG9CQUFNLEtBQUtsWCxLQUFMLENBQVksb0JBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJTW1YLFFBQU47QUFBQSxvQ0FBZ0I7QUFDZCxvQkFBTSxLQUFLblgsS0FBTCxDQUFZLFNBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJTW9YLFVBQU47QUFBQSxvQ0FBa0I7QUFDaEIsb0JBQU0sS0FBS3BYLEtBQUwsQ0FBWSxXQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSUE2TSxpQkFBZ0J4TSxHQUFoQixFQUFxQnFNLFdBQVl0TSxNQUFELElBQVksQ0FBRSxDQUE5QyxFQUFnRHVNLFVBQVdqSyxDQUFELElBQU8sQ0FBRSxDQUFuRSxFQUFxRTtBQUNuRSxXQUFPLEtBQUsyVCxNQUFMLEdBQ0pDLElBREksQ0FFRkMsR0FBRCxJQUFTO0FBQ1AsYUFBTyxJQUFJNUksT0FBSixDQUNMLENBQU9DLE9BQVAsRUFBZ0JDLE1BQWhCLDhCQUEyQjtBQUN6QjtBQUNBMEksWUFBSXZXLEtBQUosQ0FBVUssR0FBVixFQUNHZ1gsRUFESCxDQUNNLFFBRE4sRUFFS2pYLE1BQUQsSUFBWTtBQUNWbVcsY0FBSWUsS0FBSjtBQUNBNUssbUJBQVN0TSxNQUFUO0FBQ0FtVyxjQUFJZ0IsTUFBSjtBQUNELFNBTkwsRUFPR0YsRUFQSCxDQU9NLE9BUE4sRUFPZ0IzVSxDQUFELElBQU87QUFDbEJpSyxrQkFBUWpLLENBQVI7QUFDRCxTQVRILEVBVUcyVSxFQVZILENBVU0sS0FWTixFQVVhLE1BQU07QUFDZmQsY0FBSUMsT0FBSjtBQUNBNUk7QUFDRCxTQWJIO0FBY0QsT0FoQkQsQ0FESyxDQUFQO0FBbUJELEtBdEJFLEVBd0JKSSxLQXhCSSxDQXdCR3RMLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQTFCSSxDQUFQO0FBMkJEOztBQUVEMlQsV0FBVTtBQUNSLFdBQU8sSUFBSTFJLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQSxXQUFLK0gsSUFBTCxDQUFVNEIsYUFBVixDQUF3QixDQUFDOVUsQ0FBRCxFQUFJNlQsR0FBSixLQUFZO0FBQ2xDLFlBQUk3VCxDQUFKLEVBQU87QUFDTG1MLGlCQUFPbkwsQ0FBUDtBQUNELFNBRkQsTUFFTztBQUNMa0wsa0JBQVEySSxHQUFSO0FBQ0Q7QUFDRixPQU5EO0FBT0QsS0FWSSxFQVlKdkksS0FaSSxDQWFGdEwsQ0FBRCxJQUFPO0FBQ0wsWUFBTUEsQ0FBTjtBQUNELEtBZkUsQ0FBUDtBQWlCRDs7QUFyTHdCLEM7Ozs7Ozs7Ozs7O0FDSDNCckcsT0FBT3FQLE1BQVAsQ0FBYztBQUFDbFAsV0FBUSxNQUFJOEs7QUFBYixDQUFkOztBQUFlLE1BQU1BLE1BQU4sQ0FBYTtBQUMxQjZFLGNBQWF6QyxVQUFiLEVBQXlCO0FBQ3ZCLFNBQUtBLFVBQUwsR0FBa0JBLFVBQWxCO0FBQ0EsU0FBS08sYUFBTCxHQUFxQixJQUFyQjtBQUNBLFNBQUtNLFFBQUwsR0FBZ0IsSUFBaEI7QUFDQSxTQUFLUyxXQUFMLEdBQW1CLElBQW5CO0FBQ0EsU0FBS21DLEtBQUwsR0FBYSxDQUFiO0FBQ0EsU0FBS2pELFdBQUwsR0FBbUIsQ0FBbkI7QUFDRDs7QUFFS3NCLFFBQU4sQ0FBY2hCLEdBQWQ7QUFBQSxvQ0FBbUI7QUFDakI7QUFDQSxVQUFJLEtBQUsyQyxLQUFMLEdBQWEsS0FBS3pELFVBQWxCLEtBQWlDLENBQXJDLEVBQXdDO0FBQ3RDLFlBQUksS0FBS08sYUFBVCxFQUF3QjtBQUN0Qix3QkFBTSxLQUFLQSxhQUFMLENBQW1CLEtBQUtDLFdBQXhCLENBQU47QUFDRDtBQUNGOztBQUNELFVBQUksS0FBS0ssUUFBVCxFQUFtQjtBQUNqQixzQkFBTSxLQUFLQSxRQUFMLENBQWNDLEdBQWQsQ0FBTjtBQUNEOztBQUNELFdBQUsyQyxLQUFMLEdBVmlCLENBV2pCOztBQUNBLFVBQUksS0FBS0EsS0FBTCxHQUFhLEtBQUt6RCxVQUFsQixLQUFpQyxDQUFyQyxFQUF3QztBQUN0QyxhQUFLK0IsS0FBTDtBQUNBLGFBQUt2QixXQUFMO0FBQ0Q7QUFDRixLQWhCRDtBQUFBOztBQWlCQXVCLFVBQVM7QUFDUCxRQUFJLEtBQUtULFdBQVQsRUFBc0I7QUFDcEIsV0FBS0EsV0FBTCxDQUFpQixLQUFLZCxXQUF0QjtBQUNEO0FBQ0Y7O0FBL0J5QixDOzs7Ozs7Ozs7OztBQ0E1QjdOLE9BQU9xUCxNQUFQLENBQWM7QUFBQ2xQLFdBQVEsTUFBSXlDO0FBQWIsQ0FBZDtBQUFvQyxJQUFJb1csU0FBSjtBQUFjaFosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzRZLGdCQUFVNVksQ0FBVjtBQUFZOztBQUF4QixDQUFoQyxFQUEwRCxDQUExRDtBQUE2RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEOztBQUczRyxNQUFNd0MsTUFBTixDQUFhO0FBQzFCa04sZ0JBQWU7QUFDYixTQUFLL0wsTUFBTCxHQUFjLEVBQWQ7QUFDQSxTQUFLcVEsU0FBTCxHQUFpQixFQUFqQjtBQUNBLFNBQUtnSCxRQUFMLEdBQWdCLElBQWhCO0FBQ0Q7O0FBRURDLGtCQUFpQjtBQUNmLFNBQUtELFFBQUwsR0FBZ0IsSUFBSUUsUUFBSixFQUFoQjtBQUNBLFNBQUtsSCxTQUFMLENBQWV2RCxJQUFmLENBQW9CLEtBQUt1SyxRQUF6QjtBQUNEOztBQUVLMVgsT0FBTixDQUFhMUIsT0FBTyxFQUFwQixFQUF3Qm1TLEtBQUssK0JBQVksQ0FBRSxDQUFkLENBQTdCO0FBQUEsb0NBQTZDO0FBQzNDLFdBQUtrSCxhQUFMO0FBRUEsVUFBSUUsTUFBTSxFQUFWOztBQUVBLFVBQUk7QUFDRixZQUFJM1gsb0JBQVl1USxJQUFaLENBQUo7QUFFQTRDLGVBQU9DLE1BQVAsQ0FBY3VFLEdBQWQsRUFBbUI7QUFDakJyTCxnQkFBTSxTQURXO0FBRWpCeE0saUJBQU8xQixJQUZVO0FBR2pCd1osa0JBQVE1WDtBQUhTLFNBQW5CO0FBS0QsT0FSRCxDQVFFLE9BQU95QyxDQUFQLEVBQVU7QUFDVjBRLGVBQU9DLE1BQVAsQ0FBY3VFLEdBQWQsRUFBbUI7QUFDakJyTCxnQkFBTSxPQURXO0FBRWpCeE0saUJBQU8xQixJQUZVO0FBR2pCd1osa0JBQVF4QyxVQUFVbE4sS0FBVixDQUFnQnpGLENBQWhCO0FBSFMsU0FBbkI7QUFLRCxPQWRELFNBY1U7QUFDUixZQUFJLEtBQUsrVSxRQUFMLENBQWNLLEtBQWxCLEVBQXlCO0FBQ3ZCMUUsaUJBQU9DLE1BQVAsQ0FBY3VFLEdBQWQsRUFBbUI7QUFDakJILHNCQUFVLEtBQUtBO0FBREUsV0FBbkI7QUFHRDs7QUFDRCxhQUFLclgsTUFBTCxDQUFZOE0sSUFBWixDQUFpQjBLLEdBQWpCO0FBQ0Q7QUFDRixLQTNCRDtBQUFBOztBQTZCQTNRLFdBQVU4USxTQUFWLEVBQXFCO0FBQ25CLFNBQUtOLFFBQUwsQ0FBY08sT0FBZCxDQUFzQkQsU0FBdEI7QUFDRDs7QUFFRHBWLFNBQVFvVixTQUFSLEVBQW1CO0FBQ2pCLFNBQUtOLFFBQUwsQ0FBY2paLEtBQWQsQ0FBb0I2VyxVQUFVbE4sS0FBVixDQUFnQjRQLFNBQWhCLENBQXBCO0FBQ0Q7O0FBRURFLGlCQUFnQjtBQUNkLFFBQUlDLFdBQVcsS0FBS3pILFNBQUwsQ0FBZTVMLElBQWYsQ0FBb0JuQyxLQUFLQSxFQUFFdVYsWUFBRixFQUF6QixDQUFmO0FBQ0EsUUFBSUUsV0FBVyxLQUFmOztBQUNBLFNBQUssSUFBSVAsR0FBVCxJQUFnQixLQUFLeFgsTUFBckIsRUFBNkI7QUFDM0IsVUFBSXdYLElBQUlyTCxJQUFKLEtBQWEsT0FBakIsRUFBMEI7QUFDeEI0TCxtQkFBVyxJQUFYO0FBQ0E7QUFDRDtBQUNGOztBQUNELFdBQU9ELFlBQVlDLFFBQW5CO0FBQ0Q7O0FBRUQvVCxZQUFXO0FBQ1QsUUFBSSxLQUFLNlQsWUFBTCxFQUFKLEVBQXlCO0FBQ3ZCLFlBQU0sSUFBSTVhLE9BQU95UCxLQUFYLENBQWlCLEtBQUsxTSxNQUF0QixDQUFOO0FBQ0Q7O0FBQ0QsV0FBTyxLQUFLQSxNQUFaO0FBQ0Q7O0FBbEV5Qjs7QUFxRTVCLE1BQU11WCxRQUFOLENBQWU7QUFDYnhMLGdCQUFlO0FBQ2IsU0FBSzJMLEtBQUwsR0FBYSxDQUFiO0FBQ0EsU0FBS00sS0FBTCxHQUFhO0FBQ1hKLGVBQVM7QUFDUEYsZUFBTyxDQURBO0FBRVBPLGlCQUFTO0FBRkYsT0FERTtBQUtYN1osYUFBTztBQUNMc1osZUFBTyxDQURGO0FBRUxPLGlCQUFTO0FBRko7QUFMSSxLQUFiO0FBVUQ7O0FBRURMLFVBQVNELFNBQVQsRUFBb0I7QUFDbEIsUUFBSUEsU0FBSixFQUFlO0FBQ2IsV0FBS0ssS0FBTCxDQUFXSixPQUFYLENBQW1CSyxPQUFuQixDQUEyQm5MLElBQTNCLENBQWdDNkssU0FBaEM7QUFDRDs7QUFDRCxTQUFLSyxLQUFMLENBQVdKLE9BQVgsQ0FBbUJGLEtBQW5CO0FBQ0EsU0FBS0EsS0FBTDtBQUNEOztBQUNEdFosUUFBT3VaLFNBQVAsRUFBa0I7QUFDaEI7QUFDQSxRQUFJTyxZQUFZLElBQWhCO0FBQ0EsUUFBSXZLLFFBQVEsS0FBS3FLLEtBQUwsQ0FBVzVaLEtBQVgsQ0FBaUI2WixPQUFqQixDQUF5QnJKLE1BQXJDOztBQUNBLFFBQUlqQixLQUFKLEVBQVc7QUFDVHVLLGtCQUFZLEtBQUtGLEtBQUwsQ0FBVzVaLEtBQVgsQ0FBaUI2WixPQUFqQixDQUF5QnRLLFFBQVEsQ0FBakMsQ0FBWjtBQUNELEtBTmUsQ0FRaEI7OztBQUNBLFFBQUluUCxLQUFLQyxTQUFMLENBQWV5WixTQUFmLE1BQThCMVosS0FBS0MsU0FBTCxDQUFla1osU0FBZixDQUFsQyxFQUE2RDtBQUMzRCxVQUFJQSxhQUFhQSxjQUFjLEVBQTNCLElBQWlDQSxjQUFjLEVBQW5ELEVBQXVEO0FBQ3JELGFBQUtLLEtBQUwsQ0FBVzVaLEtBQVgsQ0FBaUI2WixPQUFqQixDQUF5Qm5MLElBQXpCLENBQThCNkssU0FBOUI7QUFDRDtBQUNGOztBQUNELFNBQUtLLEtBQUwsQ0FBVzVaLEtBQVgsQ0FBaUJzWixLQUFqQjtBQUNBLFNBQUtBLEtBQUw7QUFDRDs7QUFFREcsaUJBQWdCO0FBQ2QsV0FBTyxLQUFLRyxLQUFMLENBQVc1WixLQUFYLENBQWlCc1osS0FBeEI7QUFDRDs7QUExQ1ksQzs7Ozs7Ozs7Ozs7QUN4RWZ6YixPQUFPcVAsTUFBUCxDQUFjO0FBQUNsUCxXQUFRLE1BQUk2VTtBQUFiLENBQWQ7O0FBQWUsTUFBTUEsUUFBTixDQUFlO0FBQzVCLFNBQU8rRCxPQUFQLENBQWdCbUQsSUFBaEIsRUFBc0JDLEdBQXRCLEVBQTJCQyxVQUEzQixFQUF1QztBQUNyQyxRQUFJQSxlQUFlQyxTQUFuQixFQUE4QjtBQUFFRCxtQkFBYSxFQUFiO0FBQWlCOztBQUNqRCxRQUFJRSxZQUFZSixLQUFLSyxLQUFMLENBQVcsRUFBWCxDQUFoQjtBQUNBLFFBQUl6TCxRQUFRLENBQVo7QUFDQSxRQUFJMEwsTUFBTSxFQUFWOztBQUNBLFNBQUssSUFBSTlKLElBQUksQ0FBYixFQUFnQkEsSUFBSTRKLFVBQVUzSixNQUE5QixFQUFzQ0QsR0FBdEMsRUFBMkM7QUFDekMsVUFBSStKLElBQUlqQyxPQUFPOEIsVUFBVTVKLENBQVYsQ0FBUCxDQUFSO0FBQ0EsVUFBSStKLEVBQUU5SixNQUFGLEdBQVcsQ0FBZixFQUFrQjdCLFFBQWxCLEtBQ0tBLFNBQVMsQ0FBVDs7QUFDTCxVQUFJQSxRQUFRcUwsR0FBWixFQUFpQjtBQUNmLGVBQU9LLE1BQU1KLFVBQWI7QUFDRDs7QUFDREksYUFBT04sS0FBS1EsTUFBTCxDQUFZaEssQ0FBWixDQUFQO0FBQ0Q7O0FBQ0QsV0FBT3dKLElBQVA7QUFDRDs7QUFoQjJCLEMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcbi8vICAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4vLyAgIHJlcy5lbmQoYEhlbGxvIHdvcmxkIGZyb206ICR7TWV0ZW9yLnJlbGVhc2V9YCk7XHJcbi8vIH0pO1xyXG5cclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnO1xyXG5cclxuLy8gUmVxdWlyZXMgbXVsdGlwYXJ0eSBcclxuaW1wb3J0IG11bHRpcGFydHkgZnJvbSAnY29ubmVjdC1tdWx0aXBhcnR5JztcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL3VwbG9hZHMnO1xyXG5sZXQgbXVsdGlwYXJ0eU1pZGRsZXdhcmUgPSBtdWx0aXBhcnR5KCk7XHJcblxyXG5jb25zdCByb3V0ZSA9ICcvdXBsb2FkL2ltYWdlJztcclxuXHJcbi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgZnVjLnVwbG9hZEZpbGUgKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIG11bHRpcGFydHlNaWRkbGV3YXJlKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIChyZXEsIHJlc3ApID0+IHtcclxuICAvLyBkb24ndCBmb3JnZXQgdG8gZGVsZXRlIGFsbCByZXEuZmlsZXMgd2hlbiBkb25lXHJcblxyXG4gIGNvbnN0IHJlYWRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMucmVhZEZpbGUpO1xyXG4gIGNvbnN0IHdyaXRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMud3JpdGVGaWxlKTtcclxuICBjb25zdCB1cGxvYWRJZCA9IHVuaXFpZCgpO1xyXG5cclxuICBmb3IgKGxldCBmaWxlIG9mIHJlcS5maWxlcy5maWxlKSB7XHJcbiAgICBjb25zdCBkYXRhID0gcmVhZGVyKGZpbGUucGF0aCk7XHJcbiAgICAvLyDjg5XjgqHjgqTjg6vlkI3jga7ph43opIfjgpLpgb/jgZHjgovjgZ/jgoHjgIHkuIDmhI/jga7jg5XjgqHjgqTjg6vlkI3jgpLkvZzmiJDjgZnjgotcclxuICAgIC8vIOalveWkqeOBruODleOCoeOCpOODq+WQjeaWh+Wtl+aVsOWItumZkDIw44Gr5ZCI44KP44Gb44KLXHJcbiAgICBsZXQgZmlsZW5hbWUgPSBgJHt1bmlxaWQoKX0uanBnYFxyXG5cclxuICAgIC8vIHNldCB0aGUgY29ycmVjdCBwYXRoIGZvciB0aGUgZmlsZSBub3QgdGhlIHRlbXBvcmFyeSBvbmUgZnJvbSB0aGUgQVBJOlxyXG4gICAgbGV0IHNhdmVQYXRoID0gcmVxLmJvZHkuaW1hZ2VkaXIgKyAnLycgKyBmaWxlbmFtZTtcclxuXHJcbiAgICAvLyBjb3B5IHRoZSBkYXRhIGZyb20gdGhlIHJlcS5maWxlcy5maWxlLnBhdGggYW5kIHBhc3RlIGl0IHRvIGZpbGUucGF0aFxyXG5cclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiee1kOaenOOCkuiomOmMsuOBmeOCi1xyXG4gICAgbGV0IGRvYyA9IHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgICBjbGllbnRGaWxlTmFtZTogZmlsZS5uYW1lLFxyXG4gICAgICB1cGxvYWRlZEZpbGVOYW1lOiBmaWxlbmFtZVxyXG4gICAgfTtcclxuICAgIFxyXG4gICAgdHJ5e1xyXG4gICAgICB3cml0ZXIoc2F2ZVBhdGgsIGRhdGEpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2goZXJyKXtcclxuICAgICAgZG9jLmVycm9yID0gZXJyO1xyXG4gICAgfVxyXG4gICAgVXBsb2Fkcy5pbnNlcnQoZG9jKTtcclxuXHJcbiAgICBkZWxldGUgZmlsZTtcclxuXHJcbiAgfTtcclxuICByZXNwLndyaXRlSGVhZCgyMDApO1xyXG4gIHJlc3AuZW5kKEpTT04uc3RyaW5naWZ5KHtcclxuICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgIHNhdmVEaXI6IHJlcS5ib2R5LmltYWdlZGlyXHJcbiAgfSkpO1xyXG5cclxufSk7IiwiaW1wb3J0IGNyeXB0byBmcm9tICdjcnlwdG8nXHJcblxyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQgUmVwb3J0IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgR3JvdXAsXHJcbiAgR3JvdXBGYWN0b3J5XHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3VwcydcclxuaW1wb3J0IHtcclxuICBGaWx0ZXJcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycydcclxuXHJcbmxldCB0YWcgPSAnY3ViZW1pZydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ubWlncmF0ZWBdIChjb25maWcpIHtcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICAvLyBzZXR1cCBncm91cFxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IEZpbHRlcihjb25maWcuc3JjRmlsdGVySWQpXHJcbiAgICAvLyBsZXQgcGx1ZyA9IGdyb3VwLmdldFBsdWcoKTtcclxuXHJcbiAgICAvLyBjaGVja2luZyBjb25uZWN0aW9uXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCB0ZXN0UXVlcnkgPSAnU0hPVyBEQVRBQkFTRVMnXHJcblxyXG4gICAgbGV0IGRzdERiID0gbmV3IE15U1FMKGNvbmZpZy5kc3QuY3JlZClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ0Nvbm5lY3QgdG8gRGVzdGluYXRpb24nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgYXdhaXQgZHN0RGIucXVlcnkodGVzdFF1ZXJ5KVxyXG4gICAgICB9KVxyXG5cclxuICAgIC8vIHByb2Nlc3MgZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAgLy9cclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ1NlbGVjdCBsb29wIGluIHNvdXJjZScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgbW9iaWxlTnVsbDogYXN5bmMgKHJlY29yZCkgPT4ge1xyXG4gICAgICAgICAgICAvLyAvLyDlgKTjgpLmlbTnkIZcclxuICAgICAgICAgICAgLy8gZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgLy8gICBpZiAocmVjb3JkW2tleV0gPT09IG51bGwpO1xyXG4gICAgICAgICAgICAvLyAgIGVsc2UgaWYgKHJlY29yZFtrZXldLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgICAgICAvLyAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IE15U1FMLmZvcm1hdERhdGUocmVjb3JkW2tleV0pO1xyXG4gICAgICAgICAgICAvLyAgICAgcmVjb3JkW2tleV0gPSBgXCIke3JlY29yZFtrZXldfVwiYDtcclxuICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lciDjgavkv53lrZhcclxuXHJcbiAgICAgICAgICAgIGxldCBzcWwgPSBgXHJcblxyXG4gICAgICAgICAgICAgICAgSU5TRVJUIGR0Yl9jdXN0b21lclxyXG4gICAgICAgICAgICAgICAgKCBcXGBjdXN0b21lcl9pZFxcYCwgXFxgc3RhdHVzXFxgLCBcXGBzZXhcXGAsIFxcYGpvYlxcYCwgXFxgY291bnRyeV9pZFxcYCwgXFxgcHJlZlxcYCwgXFxgbmFtZTAxXFxgLCBcXGBuYW1lMDJcXGAsIFxcYGthbmEwMVxcYCwgXFxga2FuYTAyXFxgLCBcXGBjb21wYW55X25hbWVcXGAsIFxcYHppcDAxXFxgLCBcXGB6aXAwMlxcYCwgXFxgemlwY29kZVxcYCwgXFxgYWRkcjAxXFxgLCBcXGBhZGRyMDJcXGAsIFxcYGVtYWlsXFxgLCBcXGB0ZWwwMVxcYCwgXFxgdGVsMDJcXGAsIFxcYHRlbDAzXFxgLCBcXGBmYXgwMVxcYCwgXFxgZmF4MDJcXGAsIFxcYGZheDAzXFxgLCBcXGBiaXJ0aFxcYCwgXFxgcGFzc3dvcmRcXGAsIFxcYHNhbHRcXGAsIFxcYHNlY3JldF9rZXlcXGAsIFxcYGZpcnN0X2J1eV9kYXRlXFxgLCBcXGBsYXN0X2J1eV9kYXRlXFxgLCBcXGBidXlfdGltZXNcXGAsIFxcYGJ1eV90b3RhbFxcYCwgXFxgbm90ZVxcYCwgXFxgY3JlYXRlX2RhdGVcXGAsIFxcYHVwZGF0ZV9kYXRlXFxgLCBcXGBkZWxfZmxnXFxgIClcclxuXHJcbiAgICAgICAgICAgICAgICBWQUxVRVMoICR7cmVjb3JkLmN1c3RvbWVyX2lkfSAsICR7cmVjb3JkLnN0YXR1c30gLCAke3JlY29yZC5zZXh9ICwgJHtyZWNvcmQuam9ifSAsICR7cmVjb3JkLmNvdW50cnlfaWR9ICwgJHtyZWNvcmQucHJlZn0gLCAke3JlY29yZC5uYW1lMDF9ICwgJHtyZWNvcmQubmFtZTAyfSAsICR7cmVjb3JkLmthbmEwMX0gLCAke3JlY29yZC5rYW5hMDJ9ICwgJHtyZWNvcmQuY29tcGFueV9uYW1lfSAsICR7cmVjb3JkLnppcDAxfSAsICR7cmVjb3JkLnppcDAyfSAsICR7cmVjb3JkLnppcGNvZGV9ICwgJHtyZWNvcmQuYWRkcjAxfSAsICR7cmVjb3JkLmFkZHIwMn0gLCAke3JlY29yZC5lbWFpbH0gLCAke3JlY29yZC50ZWwwMX0gLCAke3JlY29yZC50ZWwwMn0gLCAke3JlY29yZC50ZWwwM30gLCAke3JlY29yZC5mYXgwMX0gLCAke3JlY29yZC5mYXgwMn0gLCAke3JlY29yZC5mYXgwM30gLCAke3JlY29yZC5iaXJ0aH0gLCAke3JlY29yZC5wYXNzd29yZH0gLCAke3JlY29yZC5zYWx0fSAsICR7cmVjb3JkLnNlY3JldF9rZXl9ICwgJHtyZWNvcmQuZmlyc3RfYnV5X2RhdGV9ICwgJHtyZWNvcmQubGFzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5idXlfdGltZXN9ICwgJHtyZWNvcmQuYnV5X3RvdGFsfSAsICR7cmVjb3JkLm5vdGV9ICwgJHtyZWNvcmQuY3JlYXRlX2RhdGV9ICwgJHtyZWNvcmQudXBkYXRlX2RhdGV9ICwgJHtyZWNvcmQuZGVsX2ZsZ30gKVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBgXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgc3RhdHVzOiByZWNvcmQuc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgICBzZXg6IHJlY29yZC5zZXgsXHJcbiAgICAgICAgICAgICAgICAgIGpvYjogcmVjb3JkLmpvYixcclxuICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICBlbWFpbDogcmVjb3JkLmVtYWlsLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICBiaXJ0aDogcmVjb3JkLmJpcnRoLFxyXG4gICAgICAgICAgICAgICAgICBwYXNzd29yZDogcmVjb3JkLnBhc3N3b3JkLFxyXG4gICAgICAgICAgICAgICAgICBzYWx0OiByZWNvcmQuc2FsdCxcclxuICAgICAgICAgICAgICAgICAgc2VjcmV0X2tleTogcmVjb3JkLnNlY3JldF9rZXksXHJcbiAgICAgICAgICAgICAgICAgIGZpcnN0X2J1eV9kYXRlOiByZWNvcmQuZmlyc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGxhc3RfYnV5X2RhdGU6IHJlY29yZC5sYXN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBidXlfdGltZXM6IHJlY29yZC5idXlfdGltZXMsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90b3RhbDogcmVjb3JkLmJ1eV90b3RhbCxcclxuICAgICAgICAgICAgICAgICAgbm90ZTogcmVjb3JkLm5vdGUsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXJfYWRkcmVzc1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcl9hZGRyZXNzJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9hZGRyZXNzX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjg6Hjg6vjg57jgqzjg5fjg6njgrDjgqTjg7MgcGxnX21haWxtYWdhX2N1c3RvbWVyXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX21haWxtYWdhX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBpZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgbWFpbG1hZ2FfZmxnOiByZWNvcmQubWFpbG1hZ2FfZmxnLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8g44Kv44O844Od44Oz55m66KGM77yIRUNDVUJFMuOBruODneOCpOODs+ODiOmChOWFg++8iVxyXG5cclxuICAgICAgICAgICAgbGV0IGNvdXBvbkNkID0gY3J5cHRvLnJhbmRvbUJ5dGVzKDgpLnRvU3RyaW5nKCdiYXNlNjQnKS5zdWJzdHJpbmcoMCwgMTEpXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uTmFtZSA9IGAke3JlY29yZC5uYW1lMDF9ICR7cmVjb3JkLm5hbWUwMn0g5qeYIOOBlOWEquW+heOCr+ODvOODneODsyDkvJrlk6Hnlarlj7c6JHtyZWNvcmQuY3VzdG9tZXJfaWR9YFxyXG5cclxuICAgICAgICAgICAgbGV0IGRpc2NvdW50UHJpY2UgPSByZWNvcmQucG9pbnQgKyA1MDBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ3BsZ19jb3Vwb24nLCB7XHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2NkOiBjb3Vwb25DZCxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3R5cGU6IDMsIC8vIOWFqOWVhuWTgVxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbmFtZTogY291cG9uTmFtZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfdHlwZTogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3VzZV90aW1lOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fcmVsZWFzZTogMSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcHJpY2U6IGRpc2NvdW50UHJpY2UsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3JhdGU6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGVuYWJsZV9mbGFnOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbWVtYmVyOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbG93ZXJfbGltaXQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV9mcm9tX2RhdGU6ICcyMDE4LTA0LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX3RvX2RhdGU6ICcyMDE5LTA1LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogMFxyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgJ2N1YmVtaWcuc2VydmVyQ2hlY2snIChwcm9maWxlKSB7XHJcbiAgICBsZXQgZGIgPSBuZXcgTXlTUUwocHJvZmlsZSlcclxuICAgIGxldCByZXMgPSBhd2FpdCBkYi5xdWVyeSgnU0hPVyBEQVRBQkFTRVMnKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCB7IE1vbmdvQ29sbGVjdGlvbiB9IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9tb25nbydcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLmNvbGxlY3Rpb24nXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmZpbmRgXSAocGx1ZywgcXVlcnkgPSB7fSwgcHJvamVjdGlvbiA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuZmluZChxdWVyeSwge3Byb2plY3Rpb246IHByb2plY3Rpb259KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5hZ2dyZWdhdGVgXSAocGx1ZywgcXVlcnkgPSB7fSkge1xyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbilcclxuICAgIGxldCByZXMgPSBhd2FpdCBjb2xsLmFnZ3JlZ2F0ZShxdWVyeSkudG9BcnJheSgpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uLy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLml0ZW1zJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvKipcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+OCs+ODrOOCr+OCt+ODp+ODs+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOBvuOBmeOAglxyXG4gICAqIEBwYXJhbVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LnNldEltYWdlYF0gKHBsdWcsIHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpXHJcbiAgICBsZXQgdXBsb2FkZWQgPSBhd2FpdCBpdGVtY29uLnNldEltYWdlKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxLCBjbGFzczIpXHJcbiAgICByZXR1cm4gdXBsb2FkZWRcclxuICB9LFxyXG5cclxuICAvKipcclxuICAgKiDjgqLjgqTjg4bjg6Dmg4XloLHjg4fjg7zjgr/jg5njg7zjgrnjga7nlLvlg4/nmbvpjLLjgpLliYrpmaTjgZnjgovvvIjnlLvlg4/oh6rkvZPjga/liYrpmaTjgZfjgarjgYTvvIlcclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5jbGVhbkltYWdlYF0gKHBsdWcsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGF3YWl0IGl0ZW1jb24uY2xlYW5JbWFnZShtb2RlbCwgY2xhc3MxLCBjbGFzczIpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCB7XHJcbiAgQ3ViZTNBcGlcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvY3ViZTNhcGknXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnY3ViZSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDlnKjluqvmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlU3RvY2tgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgbGV0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKVxyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQilcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICflnKjluqvjga7mm7TmlrAnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVVBEQVRFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgIGF3YWl0IGFwaS51cGRhdGVTdG9jayhpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCwgcXVhbnRpdHkpXHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHnmbvpjLLjgajmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgIGxldCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQilcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpXHJcblxyXG4gICAgbGV0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+OBuOOBruWVhuWTgeeZu+mMsicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ0lOU0VSVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGluc2VydFJlcyA9IGF3YWl0IGFwaS5wcm9kdWN0Q3JlYXRlKGN1YmVJdGVtKVxyXG5cclxuICAgICAgICAgICAgICAvLyBpdGVtIOODh+ODvOOCv+ODmeODvOOCueOBuOOBrueZu+mMslxyXG4gICAgICAgICAgICAgIGF3YWl0IGNvbC51cGRhdGUoe1xyXG4gICAgICAgICAgICAgICAgX2lkOiBpdGVtLl9pZFxyXG4gICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AnOiBpbnNlcnRSZXMucmVzXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+WVhuWTgeaDheWgseOBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RJbWFnZVVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ3Rvb2wnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnRlc3RgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG5cclxuICAgIGNvbnN0IG5ld0xvY2FsID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe30sIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgIHRocm93IGVcclxuICAgIH0pXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg5XjgqPjg6vjgr/jg7zjg4bjgrnjg4gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIG5ld0xvY2FsXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgUGFja2V0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9wYWNrZXQnXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IGljb252IGZyb20gJ2ljb252LWxpdGUnXHJcbmltcG9ydCBhcmNoaXZlciBmcm9tICdhcmNoaXZlcidcclxuaW1wb3J0IGNzdiBmcm9tICdjc3YnXHJcbmltcG9ydCB7IFBhc3NUaHJvdWdoLCBUcmFuc2Zvcm0gfSBmcm9tICdzdHJlYW0nXHJcbmltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QtcHJvbWlzZSdcclxuXHJcbmNvbnN0IHRhZyA9ICd3b3dtYSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQeWVhuWTgeaDheWgseWPluW+l1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5nZXRJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBvcHRpb25zID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShjb25maWcud293bWFBcGkpKVxyXG4gICAgICAgICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hJdGVtSW5mb2BcclxuICAgICAgICAgICAgb3B0aW9ucy5xcy5pdGVtQ29kZSA9IGl0ZW0ubWFsbC53b3dtYS5pdGVtQ29kZVxyXG5cclxuICAgICAgICAgICAgbGV0IHJlcG9zID0gYXdhaXQgcmVxdWVzdChvcHRpb25zKVxyXG4gICAgICAgICAgICBsZXQgZmlsZW5hbWUgPSBgJHt3b3JrZGlyfS8ke2l0ZW0ubW9kZWx9LnhtbGBcclxuXHJcbiAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEud3JpdGVGaWxlKGZpbGVuYW1lLCByZXBvcylcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5zZXREZWxpdmVyeWBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dPV01BISDphY3pgIHmlrnms5XnmbvpjLInLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyBBUEnjgYvjgonlj5blvpfjgZfjgZ/llYblk4Hmg4XloLHjgpLkv53lrZjjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L2l0ZW1zXyR7KG5ldyBEYXRlKCkpLmdldFRpbWUoKX1gXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyDjg6HjgqTjg7Pjg6vjg7zjg5dcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdUQVJHRVQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgb3B0aW9ucyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoY29uZmlnLndvd21hQXBpKSlcclxuICAgICAgICAgICAgb3B0aW9ucy51cmkgPSBgJHtvcHRpb25zLnVyaX0vc2VhcmNoSXRlbUluZm9gXHJcbiAgICAgICAgICAgIG9wdGlvbnMucXMuaXRlbUNvZGUgPSBpdGVtLm1hbGwud293bWEuaXRlbUNvZGVcclxuXHJcbiAgICAgICAgICAgIGxldCByZXBvcyA9IGF3YWl0IHJlcXVlc3Qob3B0aW9ucylcclxuICAgICAgICAgICAgbGV0IGZpbGVuYW1lID0gYCR7d29ya2Rpcn0vJHtpdGVtLm1vZGVsfS54bWxgXHJcblxyXG4gICAgICAgICAgICBhd2FpdCBmc0V4dHJhLndyaXRlRmlsZShmaWxlbmFtZSwgcmVwb3MpXHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgUGFja2V0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9wYWNrZXQnXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IGljb252IGZyb20gJ2ljb252LWxpdGUnXHJcbmltcG9ydCBhcmNoaXZlciBmcm9tICdhcmNoaXZlcidcclxuaW1wb3J0IGNzdiBmcm9tICdjc3YnXHJcbmltcG9ydCB7IFBhc3NUaHJvdWdoLCBUcmFuc2Zvcm0gfSBmcm9tICdzdHJlYW0nXHJcblxyXG5jb25zdCBwcmVmaXggPSAncGFja2V0J1xyXG5jb25zdCB0YWcgPSAneWF1Y3QnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Y+X5rOo44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm9yZGVyYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44Ok44OV44Kq44Kv5Y+X5rOoJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vb3JkZXJgXHJcbiAgICAgICAgY29uc3QgciA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlckxvYWRmaWxlfWApXHJcbiAgICAgICAgY29uc3QgdyA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJTYXZlZmlsZX1gKVxyXG4gICAgICAgIHIucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC5waXBlKGNzdi5wYXJzZSh7Y29sdW1uczogdHJ1ZX0pKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnRyYW5zZm9ybShcclxuICAgICAgICAgICAgYXN5bmMgKHJlY29yZCwgY2FsbGJhY2spID0+IHtcclxuICAgICAgICAgICAgICBsZXQgZXJyID0gbnVsbFxyXG4gICAgICAgICAgICAgIC8vIOeuoeeQhueVquWPt+OCkue9ruOBjeaPm+OBiOOCi1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICByZWNvcmRbJ+euoeeQhueVquWPtyddID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0TW9kZWxDbGFzcyhyZWNvcmRbJ+euoeeQhueVquWPtyddKVxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGVyciA9IGVcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgY2FsbGJhY2soZXJyLCByZWNvcmQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICkpXHJcbiAgICAgICAgICAucGlwZShjc3Yuc3RyaW5naWZ5KHtoZWFkZXI6IHRydWV9KSlcclxuICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLnBpcGUodylcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Ye65ZOB44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliaXRgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lh7rlk4EnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDnubDjgorov5TjgZflh6bnkIbjgpLku7vmhI/jga7vvIhwYWNrZXRTaXpl77yJ44Gn5YiG5YmyXHJcbiAgICAgICAgY29uc3QgcGFja2V0ID0gbmV3IFBhY2tldChjb25maWcucGFja2V0U2l6ZSlcclxuXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44KS5L2c5oiQ44GX55S75YOP44OH44O844K/44KS5Y+O6ZuG44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS93b3JrYFxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEucmVtb3ZlKHdvcmtkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG5cclxuICAgICAgICAvLyBaSVDjg5XjgqHjgqTjg6vjgpLkv53lrZjjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB1cGxvYWRkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vdXBsb2FkYFxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEucmVtb3ZlKHVwbG9hZGRpcilcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHVwbG9hZGRpcilcclxuXHJcbiAgICAgICAgbGV0IGNkID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jjg5Xjgqnjg6vjg4BcclxuICAgICAgICBsZXQgZmlsZW5hbWUgPSBudWxsIC8vIGNzduODleOCoeOCpOODq1xyXG4gICAgICAgIGxldCBuYW1lID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jnlarlj7dcclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kj44O844Or44OJ44KS5a6a576p44GX44CB6aCG55Wq44KS56K65a6a44GZ44KLXHJcbiAgICAgICAgbGV0IGZpZWxkcyA9IFsn566h55CG55Wq5Y+3JywgJ+OCq+ODhuOCtOODqicsICfjgr/jgqTjg4jjg6snLCAn6Kqs5piOJywgJ+OCueODiOOCouWGheWVhuWTgeaknOe0oueUqOOCreODvOODr+ODvOODiScsICfplovlp4vkvqHmoLwnLCAn5Y2z5rG65L6h5qC8JywgJ+WApOS4i+OBkuS6pOa4iScsICflgIvmlbAnLCAn5YWl5pyt5YCL5pWw5Yi26ZmQJywgJ+acn+mWkycsICfntYLkuobmmYLplpMnLCAn5ZWG5ZOB55m66YCB5YWD44Gu6YO96YGT5bqc55yMJywgJ+WVhuWTgeeZuumAgeWFg+OBruW4guWMuueUuuadkScsICfpgIHmlpnosqDmi4UnLCAn5Luj6YeR5YWI5omV44GE44CB5b6M5omV44GEJywgJ+iQveacreODiuODk+axuua4iOaWueazleioreWumicsICfllYblk4Hjga7nirbmhYsnLCAn5ZWG5ZOB44Gu54q25oWL5YKZ6ICDJywgJ+i/lOWTgeOBruWPr+WQpicsICfov5Tlk4Hjga7lj6/lkKblgpnogIMnLCAn55S75YOPMScsICfnlLvlg48x44Kz44Oh44Oz44OIJywgJ+eUu+WDjzInLCAn55S75YOPMuOCs+ODoeODs+ODiCcsICfnlLvlg48zJywgJ+eUu+WDjzPjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNCcsICfnlLvlg48044Kz44Oh44Oz44OIJywgJ+eUu+WDjzUnLCAn55S75YOPNeOCs+ODoeODs+ODiCcsICfnlLvlg482JywgJ+eUu+WDjzbjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNycsICfnlLvlg48344Kz44Oh44Oz44OIJywgJ+eUu+WDjzgnLCAn55S75YOPOOOCs+ODoeODs+ODiCcsICfnlLvlg485JywgJ+eUu+WDjznjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMTAnLCAn55S75YOPMTDjgrPjg6Hjg7Pjg4gnLCAn5pyA5L2O6KmV5L6hJywgJ+aCquipleWJsuWQiOWItumZkCcsICflhaXmnK3ogIXoqo3oqLzliLbpmZAnLCAn6Ieq5YuV5bu26ZW3JywgJ+aXqeacn+e1guS6hicsICfllYblk4Hjga7oh6rli5Xlho3lh7rlk4EnLCAn6Ieq5YuV5YCk5LiL44GSJywgJ+acgOS9juiQveacreS+oeagvCcsICfjg4Hjg6Pjg6rjg4bjgqPjg7wnLCAn5rOo55uu44Gu44Kq44O844Kv44K344On44OzJywgJ+WkquWtl+ODhuOCreOCueODiCcsICfog4zmma/oibInLCAn44K544OI44Ki44Ob44OD44OI44Kq44O844Kv44K344On44OzJywgJ+ebrueri+OBoeOCouOCpOOCs+ODsycsICfotIjnrZTlk4HjgqLjgqTjgrPjg7MnLCAnVOODneOCpOODs+ODiOOCquODl+OCt+ODp+ODsycsICfjgqLjg5XjgqPjg6rjgqjjgqTjg4jjgqrjg5fjgrfjg6fjg7MnLCAn6I2354mp44Gu5aSn44GN44GVJywgJ+iNt+eJqeOBrumHjemHjycsICfjga/jgZNCT09OJywgJ+OBneOBruS7lumFjemAgeaWueazlTEnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTInLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTMnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTQnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTUnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTYnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTcnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTgnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTknLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTEwJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+a1t+WklueZuumAgScsICfphY3pgIHmlrnms5Xjg7vpgIHmlpnoqK3lrponLCAn5Luj5byV5omL5pWw5paZ6Kit5a6aJywgJ+a2iOiyu+eojuioreWumicsICdKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ11cclxuICAgICAgICBsZXQgaGVhZGVyID0gZmllbGRzLm1hcCh2ID0+IGBcIiR7dn1cImApLmpvaW4oJywnKSArICdcXG4nXHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMlumWi+Wni+aZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldFN0YXJ0ID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBuYW1lID0gcHJlZml4ICsgKCcwMDAwMCcgKyBwYWNrZXRDb3VudCkuc2xpY2UoLTUpXHJcbiAgICAgICAgICBjZCA9IGAke3dvcmtkaXJ9LyR7bmFtZX1gXHJcbiAgICAgICAgICBmaWxlbmFtZSA9IGAke2NkfS8ke2NvbmZpZy5jc3ZGaWxlTmFtZX1gXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNkKVxyXG4gICAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44Gr44OV44Kj44O844Or44OJ44KS6Kit5a6a44GZ44KLXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShoZWFkZXIsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMluaZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldCA9IGFzeW5jIChhcmcpID0+IHtcclxuICAgICAgICAgIGxldCB5YXVjdCA9IGFyZy55YXVjdFxyXG4gICAgICAgICAgbGV0IGl0ZW0gPSBhcmcuaXRlbVxyXG4gICAgICAgICAgLy8gY3N244OV44Kh44Kk44Or44Gr44Os44Kz44O844OJ77yI5ZWG5ZOB44OG44Oz44OX44Os44O844OI77yJ44KS6L+95Yqg44GZ44KLXHJcbiAgICAgICAgICBsZXQgcmVjb3JkID0gZmllbGRzLm1hcCh2ID0+IHsgcmV0dXJuIHlhdWN0W3ZdID8gYFwiJHt5YXVjdFt2XX1cImAgOiAnXCJcIicgfSkuam9pbignLCcpICsgJ1xcbidcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKHJlY29yZCwgJ1NoaWZ0X0pJUycpKVxyXG4gICAgICAgICAgLy8g55S75YOP44OV44Kh44Kk44Or44KS44Kz44OU44O8XHJcbiAgICAgICAgICBmb3IgKGxldCBpbWcgb2YgaXRlbS5pbWFnZXMpIHtcclxuICAgICAgICAgICAgbGV0IGltZ1NyYyA9IGAke2NvbmZpZy5pbWFnZWRpcn0vJHtpbWd9YFxyXG4gICAgICAgICAgICBsZXQgaW1nVGd0ID0gYCR7Y2R9LyR7aW1nfWBcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAvLyDlkIzjgZjjg5XjgqHjgqTjg6vjgYzjgYLjgovloLTlkIjjga/jgrPjg5Tjg7zjgZfjgarjgYRcclxuICAgICAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFjY2VzcyhpbWdUZ3QpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBhd2FpdCBmc0V4dHJhLmNvcHlGaWxlKGltZ1NyYywgaW1nVGd0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jntYLkuobmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXRFbmQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHppcCA9IGFyY2hpdmVyKCd6aXAnKVxyXG4gICAgICAgICAgY29uc3QgemlwbmFtZSA9IGAke3VwbG9hZGRpcn0vJHtuYW1lfS56aXBgXHJcbiAgICAgICAgICBjb25zdCBvdXRwdXQgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKHppcG5hbWUpXHJcbiAgICAgICAgICB6aXAucGlwZShvdXRwdXQpXHJcbiAgICAgICAgICB6aXAuZGlyZWN0b3J5KGNkLCBmYWxzZSlcclxuICAgICAgICAgIHppcC5maW5hbGl6ZSgpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg6HjgqTjg7Pjg6vjg7zjg5dcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdUQVJHRVQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgLy8gaXRlbeOBq+Wumue+qeOBleOCjOOBpuOBhOOCi+acgOS9juW/heimgeWcqOW6q+OCiOOCiuWkmuOBhOWVhuWTgeOCkuWHuuWTgeOBmeOCi1xyXG4gICAgICAgICAgICBpZiAocXVhbnRpdHkgPj0gaXRlbS5tYWxsLnlhdWN0Lm1pblF1YW50aXR5KSB7XHJcbiAgICAgICAgICAgICAgbGV0IHlhdWN0ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1ZYXVjdChjb25maWcuZGVmYXVsdCwgaXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBwYWNrZXQuc3VibWl0KHt5YXVjdDogeWF1Y3QsIGl0ZW06IGl0ZW19KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcGFja2V0LmNsb3NlKClcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2NvbGxlY3Rpb24vY29uZmlncydcclxuXHJcbmltcG9ydCAnLi9yb3V0ZS91cGxvYWQvaW1hZ2UnXHJcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuIFxyXG5leHBvcnQgY29uc3QgQ29uZmlncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb25maWdzJyx7aWRHZW5lcmF0aW9uOidNT05HTyd9KTtcclxuXHJcbi8vIE1ldGVvci5tZXRob2RzKHsgXHJcbi8vICAgYXN5bmMgJ215c3FsU2VydmVycy5pbnNlcnQnICggbmV3U2VydmVyICl7XHJcbi8vICAgICByZXR1cm4gYXdhaXQgTXlzcWxTZXJ2ZXJzLmluc2VydChuZXdTZXJ2ZXIpO1xyXG4vLyAgIH1cclxuLy8gfSk7XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0JztcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnO1xyXG5pbXBvcnQgeyBHcm91cEJhc2UgfSBmcm9tICcuL2dyb3Vwcyc7XHJcblxyXG5jb25zdCBGaWx0ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZpbHRlcnMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZpbHRlciBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGZpbHRlcklkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBGaWx0ZXJzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGZpbHRlcklkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcblxyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKCBvblJlc3VsdCA9IChyZWNvcmQpPT57fSwgb25FcnJvciA9IChlKT0+e30gKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGxhdGZvcm0gdHlwZScpO1xyXG5cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7eyBmaWx0ZXJUeXBlOiBhc3luYyAocmVjb3JkICkgPT4ge30gfX0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoKGNhbGxiYWNrcyA9IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGUoKTtcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICB0eXBlOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnQgPSB7fTtcclxuICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgY291bnRbZmlsdGVyLnR5cGVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmaWx0ZXIucXVlcnksXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCk9PntcclxuICAgICAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgICAgICBsZXQgcXVlcnkgPSBtb2JqZWN0LnVuZXNjYXBlKGZpbHRlci5xdWVyeSk7XHJcbiAgICAgICAgICBsZXQgZXhhbSA9IHNpZnQoIHF1ZXJ5ICk7XHJcbiAgICAgICAgICBpZiggZXhhbShyZWNvcmQpICl7XHJcbiAgICAgICAgICAgIGNvdW50W2ZpbHRlci50eXBlXS5jb3VudCsrO1xyXG4gICAgICAgICAgICBpZiggdHlwZW9mIGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFja3NbZmlsdGVyLnR5cGVdKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBvbkVycm9yXHJcbiAgICApO1xyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnQ7XHJcblxyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbmNvbnN0IEdyb3VwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdncm91cHMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwQmFzZSB7XHJcblxyXG4gIHByb2ZpbGU7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb2ZpbGUpIHtcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBnZXRzICdQbHVnJyB3aXRjaCBpcyBhIHNldCBvZiBwcm9wZXJ0aWVzIG5lZWRlZFxyXG4gICAqIHdoZW4gY29ubmVjdCB0byBzb21lIHBsYXRmb3Jtc1xyXG4gICAqIHRvIGdldCBkYXRhcyhNZW1iZXJzIG9mIHRoZSBHcm91cClcclxuICAgKi9cclxuICBnZXRQbHVnKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZS5wbGF0Zm9ybVBsdWc7XHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZTtcclxuICB9XHJcblxyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge307XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXAgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihncm91cElkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBHcm91cHMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZ3JvdXBJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKGRvYykgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX0gV0hFUkUgXFxgJHtkb2Mua2V5fVxcYCA9IFwiJHtkb2MuaWR9XCJgO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBncm91cCB0eXBlJyk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7YXN5bmMgKHJlY29yZCk9PnZvaWR9IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IGN1ciA9IEdyb3Vwcy5maW5kKHtcclxuICAgICAgZ3JvdXBJZDogdGhpcy5wcm9maWxlLl9pZFxyXG4gICAgfSwge1xyXG4gICAgICBmaWVsZHM6IHtcclxuICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAga2V5OiAxXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGN1ci5mb3JFYWNoKFxyXG4gICAgICAgICAgYXN5bmMgKGRvYywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVjb3JkID0gYXdhaXQgdGhpcy5pbXBvcnQoZG9jKTtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFjayhyZWNvcmQpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgb25FcnJvcihlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaW5kZXggKyAxID09PSBjdXIuY291bnQoKSkge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICB9XHJcbiAgICApLmNhdGNoKFxyXG4gICAgICAoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcbn0iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbiBcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2Fkcycse2lkR2VuZXJhdGlvbjonTU9OR08nfSk7XHJcblxyXG4iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5cclxuZXhwb3J0IGNsYXNzIEN1YmUzQXBpIHtcclxuICBjb25zdHJ1Y3RvciAobXlzcWwgPSBuZXcgTXlTUUwoKSkge1xyXG4gICAgdGhpcy5teXNxbF8gPSBteXNxbFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHByb2R1Y3RDbGFzc0lkLCBxdWFudGl0eSA9IDApIHtcclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcclxuICAgICAge30sIHtcclxuICAgICAgICBzdG9jazogcXVhbnRpdHksXHJcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJyxcclxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXHJcbiAgICAgIHt9LCB7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RUYWdVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDliYrpmaTjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvZmYgPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDooajnpLrjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvbiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgLy8g44GZ44Gn44Gr6KGo56S644GV44KM44Gm44GE44KL44K/44Kw44GM44GC44KM44Gw5L2V44KC44GX44Gq44GEXHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIFNFTEVDVCBDT1VOVCgqKSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgbGV0IGNvdW50UmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKVxyXG4gICAgICBpZiAoY291bnRSZXNbMF1bJ0NPVU5UKCopJ10pIHJldHVyblxyXG5cclxuICAgICAgcmVzLnB1c2goXHJcbiAgICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAnZHRiX3Byb2R1Y3RfdGFnJyxcclxuICAgICAgICAgIHt9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBkYXRhLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgICAgIHRhZzogdGFnLFxyXG4gICAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKSlcclxuICAgIH1cclxuXHJcbiAgICBmb3IgKGxldCB0YWdTZXQgb2YgZGF0YS50YWdzKSB7XHJcbiAgICAgIHN3aXRjaCAodGFnU2V0LnNldCkge1xyXG4gICAgICAgIGNhc2UgJ29uJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29uKHRhZ1NldC50YWcpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICAgIGNhc2UgJ29mZic6XHJcbiAgICAgICAgICBhd2FpdCB0YWdvZmYodGFnU2V0LnRhZylcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdEltYWdlVXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgcHJvZHVjdElkID0gZGF0YS5wcm9kdWN0X2lkXHJcbiAgICBsZXQgaW1hZ2VzID0gZGF0YS5pbWFnZXNcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDllYblk4HjgavplqLpgKPjgZnjgovjgZnjgbnjgabjga7nlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgotcclxuICAgIGxldCBzcWwgPSBgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfaW1hZ2UgV0hFUkUgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdElkfWBcclxuICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbCkpXHJcblxyXG4gICAgLy8g5pS544KB44Gm55S75YOP44KS55m76Yyy44GX44Gq44GK44GZXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAnZHRiX3Byb2R1Y3RfaW1hZ2UnLCB7XHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICBmaWxlX25hbWU6IGltYWdlc1tpXSxcclxuICAgICAgICAgIHJhbms6IGkgKyAxXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdFVwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fVxyXG4gICAgbGV0IGtleXMgPSBbXVxyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0XHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3N0YXR1cycsXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ25vdGUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fbGlzdCcsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnLFxyXG4gICAgICAnc2VhcmNoX3dvcmQnLFxyXG4gICAgICAnZnJlZV9hcmVhJ1xyXG4gICAgXVxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RfY2xhc3NcclxuXHJcbiAgICB1cGRhdGVEYXRhID0ge31cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdkZWxpdmVyeV9kYXRlX2lkJyxcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdzYWxlX2xpbWl0JyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RDcmVhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBsZXQga2V5cyA9IFtdXHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJ1xyXG4gICAgXVxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiBpdGVtLm5hbWUsXHJcbiAgICAvLyAgIGRlc2NyaXB0aW9uX2RldGFpbDogaXRlbS5kZXNjcmlwdGlvbixcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgc3RhdHVzOiAxLFxyXG4gICAgICAgIG5vdGU6ICdOVUxMJyxcclxuICAgICAgICBkZXNjcmlwdGlvbl9saXN0OiAnTlVMTCcsXHJcbiAgICAgICAgc2VhcmNoX3dvcmQ6ICdOVUxMJyxcclxuICAgICAgICBmcmVlX2FyZWE6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAncHJvZHVjdF9jb2RlJyxcclxuICAgICAgJ3Byb2R1Y3RfdHlwZV9pZCcsXHJcbiAgICAgICdwcmljZTAxJyxcclxuICAgICAgJ3ByaWNlMDInLFxyXG4gICAgICAnZGVsaXZlcnlfZmVlJ1xyXG4gICAgXVxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBwcm9kdWN0X2NvZGU6IGl0ZW0ubW9kZWwsXHJcbiAgICAvLyAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxyXG4gICAgLy8gICBwcmljZTAyOiBpdGVtLnNhbGVzX3ByaWNlLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfY2xhc3NfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBwcm9kdWN0X2lkOiByZXMucHJvZHVjdF9pZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQxOiAnTlVMTCcsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQyOiAnTlVMTCcsXHJcbiAgICAgICAgZGVsaXZlcnlfZGF0ZV9pZDogJ05VTEwnLFxyXG4gICAgICAgIHNhbGVfbGltaXQ6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X3N0b2NrX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsIHt9LCB7XHJcbiAgICAgICAgcHJvZHVjdF9jbGFzc19pZDogcmVzLnByb2R1Y3RfY2xhc3NfaWQsXHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBmb3IgdGVzdFxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJ1xyXG5pbXBvcnQge01vbmdvQ2xpZW50fSBmcm9tICdtb25nb2RiJ1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCdcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnXHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXJGYWN0b3J5IHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgbGV0IGluc3RhbmNlXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgaW5zdGFuY2UgPSBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBpbnN0YW5jZVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgdGhpcy5wbHVnID0gcGx1Z1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZhY3RvcnkgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICByZXR1cm4gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSlcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGx1ZyB0eXBlJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldFBsdWdfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnBsdWdcclxuICB9XHJcblxyXG4gIGdldENyZWRfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnBsdWcuY3JlZFxyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZV8gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZVxyXG4gIH1cclxuXHJcbiAgc2V0SW1wb3J0RnVuY3Rpb25fIChcclxuICAgIGZuID0gYXN5bmMgKG9uUmVzdWx0ID0gcmVjb3JkID0+IHt9LCBvbkVycm9yID0gZSA9PiB7fSkgPT4ge31cclxuICApIHtcclxuICAgIHRoaXMuaW1wb3J0ID0gZm5cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIHVzZWFnZTpcclxuICAgKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHsgT2JqZWN0IH0gaXRlcmF0b3JzIHsgZmlsdGVyTmFtZTogYXN5bmMgKGRvYyxjb250ZXh0KT0+e30sIC4uLiB9IGl0ZXJhdG9yIGZvciBlYWNoIGZpbHRlcnNcclxuICAgKiBAcGFyYW0geyBhc3luYyBmdW5jdGlvbiB9IG9uRXJyb3IgZXJyb3IgaGFuZGxlciB3aGlsZSBpdGVyYXRpbmdcclxuICAgKiBAcmV0dXJucyB7IE9iamVjdCB9IHsgZmlsdGVyTmFtZTogeyBxdWVyeTogYW55LCBjb3VudDogbnVtYmVyIH0sIC4uLiB9XHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaCAoaXRlcmF0b3JzID0ge30pIHtcclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlXygpXHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgbmFtZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ZXIgPSB7fVxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgZmlsdGVycyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgICAgY291bnRlcltmLm5hbWVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmLnF1ZXJ5LFxyXG4gICAgICAgIGxpbWl0OiB0eXBlb2YgZi5saW1pdCAhPT0gJ3VuZGVmaW5lZCcgPyBmLmxpbWl0IDogMCxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9XHJcbiAgICAgIGZpbHRlcnMucHVzaChcclxuICAgICAgICB7XHJcbiAgICAgICAgICBuYW1lOiBmLm5hbWUsXHJcbiAgICAgICAgICBleGFtOiBzaWZ0KG1vYmplY3QudW5lc2NhcGUoZi5xdWVyeSkpXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQsIGNvbnRleHQpID0+IHtcclxuICAgICAgICBmb3IgKGxldCBmIG9mIGZpbHRlcnMpIHtcclxuICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgbGV0IGMgPSBjb3VudGVyW2YubmFtZV1cclxuICAgICAgICAgIGlmIChjLmxpbWl0KSB7XHJcbiAgICAgICAgICAgIGlmIChjLmNvdW50ID49IGMubGltaXQpIHtcclxuICAgICAgICAgICAgICBjb250aW51ZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKGYuZXhhbShyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgICBjLmNvdW50KytcclxuXHJcbiAgICAgICAgICAgIC8vIGl0ZXJhdG9yXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlcmF0b3JzW2YubmFtZV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgaXRlcmF0b3JzW2YubmFtZV0ocmVjb3JkLCBjb250ZXh0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnRlclxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE15c3FsREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpXHJcblxyXG4gICAgbGV0IGNyZWQgPSB0aGlzLmdldENyZWRfKClcclxuXHJcbiAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKGNyZWQpXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gXHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIChlKSA9PiB7IHRocm93IGUgfSlcclxuICAgICAgcmV0dXJuIHJlc1xyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBNb25nb05hdGl2ZSBmcm9tICdtb25nb2RiJztcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSBNb25nb05hdGl2ZS5Nb25nb0NsaWVudDtcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSByZXF1aXJlKCdtb25nb2RiJykuTW9uZ29DbGllbnQ7XHJcblxyXG5leHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICAvLyBtb25nbyDjgbjmjqXntppcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICBsZXQgY2xpZW50XHJcbiAgICAgIGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpXHJcblxyXG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcclxuICAgICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICAgIGxldCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pXHJcblxyXG4gICAgICBsZXQgY29udGV4dCA9IHtcclxuICAgICAgICBjbGllbnQ6IGNsaWVudCxcclxuICAgICAgICBjb2xsZWN0aW9uOiBjb2xsZWN0aW9uLFxyXG4gICAgICAgIGRhdGFiYXNlOiBkYlxyXG4gICAgICB9XHJcblxyXG4gICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKClcclxuXHJcbiAgICAgIC8vIOOCq+ODvOOCveODq+OBruOCv+OCpOODoOOCouOCpuODiOOCkuino+mZpFxyXG4gICAgICBjdXIuYWRkQ3Vyc29yRmxhZygnbm9DdXJzb3JUaW1lb3V0JywgdHJ1ZSlcclxuXHJcbiAgICAgIC8vIOOBmeOBueOBpuOBruODieOCreODpeODoeODs+ODiOOCkuODq+ODvOODl1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XHJcbiAgICAgICAgICBsZXQgZG9jID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQoZG9jLCBjb250ZXh0KVxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgLy8g44Kr44O844K944Or44KS6ZaL5pS+XHJcbiAgICAgICAgYXdhaXQgY3VyLmNsb3NlKClcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBtb25nb29zZSBmcm9tICdtb25nb29zZSc7XHJcblxyXG4vLyBleHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuLy8gICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbi8vICAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcclxuXHJcbi8vICAgICAvLyBtb25nbyDjgbjmjqXntppcclxuLy8gICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpO1xyXG4vLyAgICAgbGV0IGNvbnVyaSA9IGBtb25nb2RiOi8vJHtjcmVkLmhvc3R9OiR7Y3JlZC5wb3J0fS8ke2NyZWQuZGF0YWJhc2V9YDtcclxuLy8gICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoY29udXJpKTtcclxuXHJcbi8vICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLkvZzjgotcclxuLy8gICAgIGxldCBjb2xsZWN0aW9uID0gbW9uZ29vc2UuY29ubmVjdGlvbi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XHJcblxyXG4vLyAgICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbi8vICAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKTtcclxuXHJcbi8vICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4vLyAgICAgfSk7XHJcbi8vICAgfVxyXG4vLyB9XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29Db2xsZWN0aW9uXHJcbn0gZnJvbSAnLi4vdXRpbC9tb25nbydcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vY29sbGVjdGlvbi91cGxvYWRzJ1xyXG5pbXBvcnQge1xyXG4gIE9iamVjdElEXHJcbn0gZnJvbSAnYnNvbidcclxuaW1wb3J0IFRleHRVdGlsIGZyb20gJy4uL3V0aWwvdGV4dCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEl0ZW1Db250cm9sbGVyIHtcclxuICBhc3luYyBpbml0IChwbHVnKSB7XHJcbiAgICB0aGlzLkl0ZW1zID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCAnaXRlbXMnKVxyXG4gICAgdGhpcy5Qcm9kdWN0cyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ3Byb2R1Y3RzJylcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFN0b2NrIChpdGVtSWQpIHtcclxuICAgIGxldCBwcm9qZWN0ID0gYXdhaXQgdGhpcy5JdGVtcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBpdGVtSWRcclxuICAgIH0sIHtcclxuICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICdwcm9kdWN0JzogMVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgbGV0IHByb2R1Y3RQYWNrID0gcHJvamVjdC5wcm9kdWN0XHJcblxyXG4gICAgLy8gcHJvZHVjdCAqIDwtPiAqIGl0ZW1cclxuICAgIC8vIHByb2R1Y3RbXTog6KSH5pWw44Gu5ZWG5ZOB44KSMeODkeODg+OCseODvOOCuOOBqOOBl+OBpuiyqeWjslxyXG4gICAgLy8gcHJvZHVjdFtbXV06IOeVsOOBquOCi+a1gemAmue1jOi3r+OAgeeVsOOBquOCi+WOn+S+oeODu+S7leWFpeOCjOWApFxyXG4gICAgLy8gaXRlbTog55Ww44Gq44KL44K744O844Or44CB6LKp5aOy5b2i5oWLXHJcbiAgICAvLyDigLsgcHJvZHVjdCDjgYvjgonjga/jgIHosqnlo7Llj6/og73jgarlnKjluqvjgIHliKnnm4roqIjnrpfjga7jgZ/jgoHjga7mg4XloLHjgpLlvpfjgotcclxuXHJcbiAgICBsZXQgcXVhbnRpdGllcyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcHJvZHVjdFNrdSBvZiBwcm9kdWN0UGFjaykge1xyXG4gICAgICBsZXQgcXVhbnRpdHlTa3UgPSAwXHJcblxyXG4gICAgICBmb3IgKGxldCBwcm9kdWN0SWQgb2YgcHJvZHVjdFNrdSkge1xyXG4gICAgICAgIGxldCBwcm9qZWN0ID0gYXdhaXQgdGhpcy5Qcm9kdWN0cy5maW5kT25lKHtcclxuICAgICAgICAgIF9pZDogcHJvZHVjdElkXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgICAnc3RvY2snOiAxXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBsZXQgc3RvY2tBcnJheSA9IHByb2plY3Quc3RvY2tcclxuXHJcbiAgICAgICAgLy8g5Y2Y57SU44Gr44GZ44G544Gm44Gu5Zyo5bqr5ZWG5ZOB44CB55+t5pyf6ZaT5Y+W44KK5a+E44Gb5Y+v6IO95ZWG5ZOB44KS5ZCI566XXHJcbiAgICAgICAgZm9yIChsZXQgc3RvY2sgb2Ygc3RvY2tBcnJheSkge1xyXG4gICAgICAgICAgcXVhbnRpdHlTa3UgKz0gc3RvY2sucXVhbnRpdHlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHF1YW50aXRpZXMucHVzaChxdWFudGl0eVNrdSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDjgrvjg4Pjg4jllYblk4Hjga7loLTlkIjjgIHkuIDnlarlsJHjgarjgYTllYblk4HmlbDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBxdWFudGl0eSA9IE1hdGgubWluLmFwcGx5KG51bGwsIHF1YW50aXRpZXMpXHJcblxyXG4gICAgcmV0dXJuIHF1YW50aXR5XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44KL44CCXHJcbiAgICpcclxuICAgKiDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6vjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcclxuICAgKiBjbGFzczHjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOeJueWumuOBruWxnuaAp++8iOOCq+ODqeODvOOBquOBqe+8ieOBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOBq+WApOOCkuaMh+WumuOBl+OAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqIOOCguOBl2NsYXNzMuOBruOBv+aMh+WumuOBl+OBn+OBhOWgtOWQiOOBr2NsYXNzMeOBq251bGzjgpLmjIflrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS+i++8mkpLLTEwMOOBrkJMQUNL44Gu5ZWG5ZOB55S75YOP44KSXHJcbiAgICog44GZ44G544Gm44Gu44K144Kk44K677yIUyxNLEwsWEwsMlhMLDNYTCw0WEzigKbvvInjgavplqLpgKPku5jjgZHjgovloLTlkIhcclxuICAgKiBzZXRJbWFnZSggdXBsb2FkSWQsICdKSy0xMDAnLCAnQkxBQ0snICk7XHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdXBsb2FkSWQg5LiA5Zue44Gu44Ki44OD44OX44Ot44O844OJ55S75YOP44KS5p2f44Gt44Gm44GE44KLSUTjgIJtZXRlb3Ljg4fjg7zjgr/jg5njg7zjgrnjgIFVcGxvYWRz44Kz44Os44Kv44K344On44Oz5YaF44OJ44Kt44Ol44Oh44Oz44OI44GudXBsb2FkSWTjg5fjg63jg5Hjg4bjgqNcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIHNldEltYWdlICh1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OBruaDheWgseWPluW+l1xyXG4gICAgbGV0IGltYWdlcyA9IFVwbG9hZHMuZmluZCh7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZFxyXG4gICAgfSkuZmV0Y2goKS5tYXAoKHYpID0+IHYudXBsb2FkZWRGaWxlTmFtZSlcclxuXHJcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcclxuICAgIGxldCBmaWx0ZXIgPSB7fVxyXG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWxcclxuICAgIGlmIChjbGFzczEpIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczFcclxuICAgIGlmIChjbGFzczIpIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczJcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxyXG4gICAgICBmaWx0ZXIsIHtcclxuICAgICAgICAkcHVzaDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiB7XHJcbiAgICAgICAgICAgICRlYWNoOiBpbWFnZXNcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyDnmbvpjLLjgZfjgZ/nlLvlg4/jg5XjgqHjgqTjg6vlkI3kuIDopqdcclxuICAgIHJldHVybiBpbWFnZXNcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavnmbvpjLLjgZXjgozjgabjgYTjgovnlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgY2xlYW5JbWFnZSAobW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlciwge1xyXG4gICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgIGltYWdlczogW11cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBruWVhuWTgeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBruWxnuaAp+WIpeOBruWVhuWTgeaDheWgseOCkui/lOOBmeOAglxyXG4gICAqXHJcbiAgICog5byV5pWw44Go44GX44Gm5Y+X44GR5Y+W44KLaXRlbeOBr+S7u+aEj+OBruWVhuWTgeaDheWgseOAglxyXG4gICAqIGl0ZW3jgavplqLpgKPjgZnjgovllYblk4HnvqTjgavjgaTjgYTjgablv4XopoHjgarmg4XloLHjgpLmlbTnkIbjgZfov5TjgZnjgIJcclxuICAgKlxyXG4gICAqIHByb2plY3Tjgavlj4LnhafjgZfjgZ/jgYTllYblk4Hmg4XloLHjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZnjgovjgIJcclxuICAgKiDjg6Hjgr3jg4Pjg4njga7lkbzjgbPlh7rjgZfmmYLjgavlv4XopoHjgavlv5zjgZjjgaZwcm9qZWN044KS6Kit5a6a44GZ44KL44CCXHJcbiAgICpcclxuICAgKiDkvZXjgavms6jnm67jgZfjgabllYblk4Hjga7plqLpgKPmgKfjgpLmpJzlh7rjgZnjgovjgYvjga/jgIHjgZPjga7jg6Hjgr3jg4Pjg4nlhoXjgaflrprnvqnjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBpdGVtXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHByb2plY3RcclxuICAgKi9cclxuICBhc3luYyBnZXRWYXJpYXRpb24gKGl0ZW0sIHByb2plY3QpIHtcclxuICAgIC8qKlxyXG4gICAgICogYWdncmVnYXRpb27oqK3lrppcclxuICAgICAqXHJcbiAgICAgKiBsYWJlbDog5bGe5oCn5ZCN77yI6YWN6YCB5pa55rOV44CB44Kr44Op44O844CB44K144Kk44K644Gq44Gp77yJXHJcbiAgICAgKiBjdXJyZW50OiDmjIflrprjgZXjgozjgZ/jgqLjgqTjg4bjg6DvvIhpdGVt77yJ44GM6Kmy5b2T44GZ44KL6aCF55uuXHJcbiAgICAgKiBwb3JqZWN0OiDjg5Djg6rjgqjjg7zjgrfjg6fjg7PmpJzntKLjga7jgq3jg7zjgajjgarjgotpdGVt5YaF44Gu44OV44Kj44O844Or44OJ5ZCNICRb44OV44Kj44O844Or44OJ5ZCNXeW9ouW8j1xyXG4gICAgICogcXVlcnk6IGFnZ3JlZ2F0aW9u5a++6LGh44Go44GZ44KL44OJ44Kt44Ol44Oh44Oz44OI44Gu5qSc57Si5p2h5Lu2XHJcbiAgICAgKi9cclxuICAgIGxldCBzZXQgPSBbe1xyXG4gICAgICBsYWJlbDogJ+mFjemAgeaWueazlScsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRkZWxpdmVyeSdcclxuICAgICAgfSxcclxuICAgICAgcXVlcnk6IHtcclxuICAgICAgICBjbGFzczFfdmFsdWU6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxyXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MxX25hbWUsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckY2xhc3MxX3ZhbHVlJ1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MyX25hbWUsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MyX3ZhbHVlLFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckY2xhc3MyX3ZhbHVlJ1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgXVxyXG5cclxuICAgIGxldCBhdHRycyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcyBvZiBzZXQpIHtcclxuICAgICAgYXR0cnMucHVzaCh7XHJcbiAgICAgICAgdmFyaWF0aW9uczogYXdhaXQgdGhpcy5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbe1xyXG4gICAgICAgICAgICAkbWF0Y2g6IE9iamVjdC5hc3NpZ24ocy5xdWVyeSwge1xyXG4gICAgICAgICAgICAgIG1vZGVsOiBpdGVtLm1vZGVsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAkcHJvamVjdDogT2JqZWN0LmFzc2lnbihzLnByb2plY3QsIHByb2plY3QpXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAkc29ydDoge1xyXG4gICAgICAgICAgICAgIF9pZDogMVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKS50b0FycmF5KCksXHJcbiAgICAgICAgcHJvcHM6IHNcclxuICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICBmb3IgKGxldCBhdHRyIG9mIGF0dHJzKSB7XHJcbiAgICAgIGZvciAobGV0IHYgb2YgYXR0ci52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgdi5zdG9jayA9IGF3YWl0IHRoaXMuZ2V0U3RvY2sodi5faWQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gYXR0cnNcclxuICB9XHJcblxyXG4gIC8vIOODouODh+ODq+OCr+ODqeOCueW9ouW8j+OCkuS9nOOCi1xyXG4gIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cclxuICBhc3luYyBnZXRNb2RlbENsYXNzIChhcmcpIHtcclxuICAgIGxldCBpdGVtXHJcbiAgICAvLyBpdGVtIOOBjOaWh+Wtl+WIl+OBquOCieOAgWl0ZW3jga/ku7vmhI/jga7jgqrjg5bjgrjjgqfjgq/jg4hJROOBruacq+WwvuOBi+OCieS7u+aEj+OBruahgeaVsOOBrjE26YCy5pWwXHJcbiAgICBpZiAodHlwZW9mIGFyZyA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgbGV0IGV4cCA9IG5ldyBSZWdFeHAoYCR7YXJnfSRgKVxyXG4gICAgICBsZXQgY3VyID0gdGhpcy5JdGVtcy5maW5kKHt9LCB7XHJcbiAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgbW9kZWw6IDEsXHJcbiAgICAgICAgICBjbGFzczFfdmFsdWU6IDEsXHJcbiAgICAgICAgICBjbGFzczJfdmFsdWU6IDFcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICB3aGlsZSAoMSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBpdGVtID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICAgICAgbGV0IG1hdGNoID0gYXdhaXQgaXRlbS5faWQudG9IZXhTdHJpbmcoKS5tYXRjaChleHApXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyDoqbLlvZPjgZnjgotpdGVt44OH44O844K/44GM44Gq44GEXHJcbiAgICAgICAgICBjdXIuY2xvc2UoKVxyXG4gICAgICAgICAgcmV0dXJuIGFyZ1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBjdXIuY2xvc2UoKVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaXRlbSA9IGFyZ1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBtb2RlbENsYXNzID0gW11cclxuICAgIGlmIChpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbClcclxuICAgIGlmIChpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpXHJcbiAgICByZXR1cm4gbW9kZWxDbGFzcy5qb2luKCcvJylcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTMgKGNyZWF0b3JJZCwgaXRlbSkge1xyXG4gICAgLy8g5YCk5aSJ5o+bXHJcbiAgICBsZXQgY29udkRlbGl2ID0gKGRlbGl2ZXJ5KSA9PiBkZWxpdmVyeSA9PT0gJ+OChuOBhuODkeOCseODg+ODiCcgPyAn44Od44K544OI5oqV5Ye9JyA6IGRlbGl2ZXJ5XHJcblxyXG4gICAgLy8gcHJvZHVjdF9pZFxyXG4gICAgbGV0IHByb2R1Y3RJZCA9IG51bGxcclxuICAgIGxldCBtb2RlbENsYXNzID0gW11cclxuXHJcbiAgICAvLyDkuIvoqJjjga7lvaLlvI/jgpLkvZzjgotcclxuICAgIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cclxuICAgIGlmIChpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbClcclxuICAgIGlmIChpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpXHJcblxyXG4gICAgLy8g5ZWG5ZOB56iu5Yil44KS5Ymy44KK5b2T44Gm44KLXHJcbiAgICBsZXQgcHJvZHVjdFR5cGVJZFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDFcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAyXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB44K/44Kw44KS6Kit5a6a44GZ44KLXHJcbiAgICBsZXQgdGFncyA9IFtdXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICB0YWdzLnB1c2goe1xyXG4gICAgICAgICAgdGFnOiA0LFxyXG4gICAgICAgICAgc2V0OiAnb24nXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgdGFnOiA1LFxyXG4gICAgICAgICAgc2V0OiAnb2ZmJ1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICB0YWdzLnB1c2goe1xyXG4gICAgICAgICAgdGFnOiA1LFxyXG4gICAgICAgICAgc2V0OiAnb24nXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgdGFnOiA0LFxyXG4gICAgICAgICAgc2V0OiAnb2ZmJ1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4HliKXpgIHmlpnjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCBkZWxpdmVyeUZlZSA9IG51bGxcclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIGRlbGl2ZXJ5RmVlID0gbnVsbFxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgZGVsaXZlcnlGZWUgPSAyNDBcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vXHJcbiAgICAvLyDpoaflrqLlkJHjgZHjg5Djg6rjgqjjg7zjgrfjg6fjg7PllYblk4Hpgbjmip7mqZ/og73jga7lrp/oo4VcclxuICAgIC8vXHJcblxyXG4gICAgbGV0IGF0dHJzID0gYXdhaXQgdGhpcy5nZXRWYXJpYXRpb24oaXRlbSwge1xyXG4gICAgICBwcm9kdWN0X2lkOiAnJG1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9pZCdcclxuICAgIH0pXHJcblxyXG4gICAgLy8gSFRNTCDjg5Djg6rjgqjjg7zjgrfjg6fjg7PllYblk4HjgZTjgajjga7jg6rjg7Pjgq/ku5jjgY3jg5zjgr/jg7PjgpLooajnpLrjgZnjgotcclxuXHJcbiAgICAvLyDlgKTjga7lpInmj5tcclxuICAgIGF0dHJzID0gYXR0cnMubWFwKFxyXG4gICAgICAoYXR0cikgPT4ge1xyXG4gICAgICAgIGF0dHIucHJvcHMuY3VycmVudCA9IGNvbnZEZWxpdihhdHRyLnByb3BzLmN1cnJlbnQpXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zID0gYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgdmFyaWF0aW9uLnZhbHVlID0gY29udkRlbGl2KHZhcmlhdGlvbi52YWx1ZSlcclxuICAgICAgICAgICAgcmV0dXJuIHZhcmlhdGlvblxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICByZXR1cm4gYXR0clxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gSFRNTOeUn+aIkFxyXG4gICAgbGV0IHZhcmlhdGlvbkh0bWwgPVxyXG4gICAgICBhdHRycy5tYXAoXHJcbiAgICAgICAgKGF0dHIpID0+XHJcbiAgICAgICAgICAnPGRpdiBjbGFzcz1cImNvbnRhaW5lci1mbHVpZFwiPicgK1xyXG4gICAgICAgIGA8ZGl2IGNsYXNzPVwicm93XCI+YCArXHJcbiAgICAgICAgYDxkaXYgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGNsYXNzPVwiYnRuIGJ0bi1pbmZvIGJ0bi1ibG9jayBidG4teHNcIj5gICtcclxuICAgICAgICBgPHN0cm9uZz4ke2F0dHIucHJvcHMubGFiZWx9PC9zdHJvbmc+YCArXHJcbiAgICAgICAgYDwvZGl2PmAgK1xyXG4gICAgICAgIGF0dHIudmFyaWF0aW9ucy5tYXAoXHJcbiAgICAgICAgICAodmFyaWF0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChhdHRyLnByb3BzLmN1cnJlbnQgPT09IHZhcmlhdGlvbi52YWx1ZSkge1xyXG4gICAgICAgICAgICAgIC8vIOihqOekuuS4reOBruWVhuWTgeODnOOCv+ODs1xyXG4gICAgICAgICAgICAgIHJldHVybiBgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc3VjY2VzcyBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+PHN0cm9uZz4ke3ZhcmlhdGlvbi52YWx1ZX08L3N0cm9uZz48L2J1dHRvbj5gXHJcbiAgICAgICAgICAgIH0gZWxzZVxyXG4gICAgICAgICAgICBpZiAodmFyaWF0aW9uLnN0b2NrID4gMCkge1xyXG4gICAgICAgICAgICAgIC8vIOiyqeWjsuWPr+iDveWVhuWTgeOBruODnOOCv+ODs1xyXG4gICAgICAgICAgICAgIHJldHVybiBgPGEgaHJlZj1cIi9wcm9kdWN0cy9kZXRhaWwvJHt2YXJpYXRpb24ucHJvZHVjdF9pZH1cIj48YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj48L2E+YFxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIC8vIOiyqeWjsuS4jeWPr+iDveWVhuWTgeOBruODnOOCv+ODs++8iOWcqOW6q+OBquOBl++8iVxyXG4gICAgICAgICAgICAgIHJldHVybiBgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCIgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGRhdGEtdG9nZ2xlPVwidG9vbHRpcFwiIHRpdGxlPVwi5Zyo5bqr44GM44GU44GW44GE44G+44Gb44KTXCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+YFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKS5qb2luKCcnKSArXHJcbiAgICAgICAgJzwvZGl2PicgK1xyXG4gICAgICAgICc8L2Rpdj4nXHJcbiAgICAgICkuam9pbignJylcclxuXHJcbiAgICBsZXQgZGVzY3JpcHRpb25EZXRhaWwgPSBgXHJcbiAgICA8c21hbGw+4oC7IOmFjemAgeaWueazleODu+OCq+ODqeODvOODu+OCteOCpOOCuuOBr+S4i+iomOOBi+OCieOBiumBuOOBs+OBj+OBoOOBleOBhOOAgjwvc21hbGw+XHJcbiAgICAke3ZhcmlhdGlvbkh0bWx9XHJcbiAgICBgXHJcblxyXG4gICAgLy8g5ZWG5ZOB44OH44O844K/44KS5L2c44KLXHJcbiAgICBsZXQgZGF0YSA9IHtcclxuICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxyXG4gICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgIG5hbWU6IGAke21vZGVsQ2xhc3Muam9pbignLycpfSAke2NvbnZEZWxpdihpdGVtLmRlbGl2ZXJ5KX0gJHtpdGVtLm5hbWV9ICR7aXRlbS5qYW5fY29kZX1gLFxyXG4gICAgICBkZXNjcmlwdGlvbl9kZXRhaWw6IGRlc2NyaXB0aW9uRGV0YWlsLFxyXG4gICAgICBmcmVlX2FyZWE6IGl0ZW0uZGVzY3JpcHRpb24gKyAnICcsXHJcbiAgICAgIHByb2R1Y3RfY29kZTogbW9kZWxDbGFzcy5qb2luKCcvJyksXHJcbiAgICAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxyXG4gICAgICBwcmljZTAyOiBpdGVtLnNhbGVzX3ByaWNlICogMC45NSwgLy8g5qW95aSp5L6h5qC844GL44KJNSXlgKTlvJXjgY1cclxuICAgICAgaW1hZ2VzOiBpdGVtLmltYWdlcyxcclxuICAgICAgcHJvZHVjdF90eXBlX2lkOiBwcm9kdWN0VHlwZUlkLFxyXG4gICAgICB0YWdzOiB0YWdzLFxyXG4gICAgICBkZWxpdmVyeV9mZWU6IGRlbGl2ZXJ5RmVlXHJcbiAgICB9XHJcblxyXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBpdGVtLm1hbGwuc2hhcmFrdVNob3ApXHJcblxyXG4gICAgcmV0dXJuIGRhdGFcclxuICB9XHJcblxyXG4gIC8vIOODpOODleOCquOCr+ODhuODs+ODl+ODrOODvOODiOOBuOOBruWkieaPm1xyXG4gIGFzeW5jIGNvbnZlcnRJdGVtWWF1Y3QgKGRlZiwgaXRlbSkge1xyXG4gICAgY29uc3QgaWRMZW5ndGggPSAyMFxyXG4gICAgY29uc3QgdGl0bGVMZW5ndGggPSAxMzBcclxuXHJcbiAgICBsZXQgeWF1Y3QgPSB7fVxyXG4gICAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44Gu5Yid5pyf5YCk77yI44KG44GG44OR44Kx44OD44OI44O75a6F6YWN5L6/44Gn55Ww44Gq44KL77yJXHJcbiAgICB5YXVjdCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZGVmW2l0ZW0uZGVsaXZlcnldKSlcclxuXHJcbiAgICAvLyDnlLvlg4/jga7oqJjov7BcclxuICAgIGNvbnN0IGltZ1ByZWZpeCA9ICfnlLvlg48nXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZW0uaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHlhdWN0W2ltZ1ByZWZpeCArIChpICsgMSldID0gaXRlbS5pbWFnZXNbaV1cclxuICAgIH1cclxuXHJcbiAgICAvLyDjgr/jgqTjg4jjg6tcclxuICAgIHlhdWN0Wyfjgqvjg4bjgrTjg6onXSA9IGl0ZW0ubWFsbC55YXVjdC5jYXRlZ29yeVxyXG4gICAgeWF1Y3RbJ+OCv+OCpOODiOODqyddID0gVGV4dFV0aWwuc3Vic3RyOChgJHthd2FpdCB0aGlzLmdldE1vZGVsQ2xhc3MoaXRlbSl9ICR7aXRlbS5kZWxpdmVyeX0gJHtpdGVtLm5hbWV9YCwgdGl0bGVMZW5ndGgpXHJcbiAgICB5YXVjdFsn6ZaL5aeL5L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlXHJcbiAgICB5YXVjdFsn5Y2z5rG65L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlXHJcbiAgICB5YXVjdFsn566h55CG55Wq5Y+3J10gPSBpdGVtLl9pZC50b0hleFN0cmluZygpLnNsaWNlKC1pZExlbmd0aClcclxuICAgIHlhdWN0WyfoqqzmmI4nXSA9IGl0ZW0uZGVzY3JpcHRpb25cclxuICAgIHlhdWN0WydKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ10gPSBpdGVtLmphbl9jb2RlXHJcblxyXG4gICAgcmV0dXJuIHlhdWN0XHJcbiAgfVxyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIHV0aWxFcnJvciB7XHJcbiAgc3RhdGljIHBhcnNlIChlKSB7XHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICAgIHJlcy5tZXNzYWdlID0gZS5tZXNzYWdlXHJcbiAgICAgIHJlcy5uYW1lID0gZS5uYW1lXHJcbiAgICAgIHJlcy5maWxlTmFtZSA9IGUuZmlsZU5hbWVcclxuICAgICAgcmVzLmxpbmVOdW1iZXIgPSBlLmxpbmVOdW1iZXJcclxuICAgICAgcmVzLmNvbHVtbk51bWJlciA9IGUuY29sdW1uTnVtYmVyXHJcbiAgICAgIHJlcy5zdGFjayA9IGUuc3RhY2tcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlcyA9IGVcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvQ2xpZW50IH0gZnJvbSAnbW9uZ29kYidcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0NvbGxlY3Rpb24ge1xyXG4gIHN0YXRpYyBhc3luYyBnZXQgKHBsdWcsIGNvbGxlY3Rpb24pIHtcclxuICAgIGxldCBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG4gICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICByZXR1cm4gZGIuY29sbGVjdGlvbihjb2xsZWN0aW9uKVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnXHJcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlTUUwge1xyXG4gIGNvbnN0cnVjdG9yIChwcm9maWxlKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pjg5fjg7zjg6vliJ3mnJ/ljJZcclxuICAgIHRoaXMucG9vbCA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZSlcclxuXHJcbiAgICAvLyDopIfmlbDooYzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jlr77lv5xcclxuICAgIGxldCBwcm9maWxlTXVsdGkgPSB7bXVsdGlwbGVTdGF0ZW1lbnRzOiB0cnVlfVxyXG4gICAgT2JqZWN0LmFzc2lnbihwcm9maWxlTXVsdGksIHByb2ZpbGUpXHJcbiAgICB0aGlzLnBvb2xNdWx0aSA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZU11bHRpKVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZvcm1hdERhdGUgKGRhdGUpIHtcclxuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsIDE5KS5yZXBsYWNlKCdUJywgJyAnKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsXHJcbiAgICovXHJcbiAgcXVlcnkgKHNxbCkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz56K656uLXHJcbiAgICAvLyBsZXQgY29uID0gYXdhaXQgdGhpcy5nZXRDb24oKTtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwsIChlLCByZXMpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+mWi+aUvlxyXG4gICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxyXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXMpXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnRfIChzcWwpIHtcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O844CBbnVsbOOAgWphdmFzY3JpcHQtPm15c3Fs5pel5LuY5aSJ5o+b44Gr44KC5a++5b+cXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnQgKHRhYmxlLCBkYXRhID0ge30sIGRhdGFTcWwgPSB7fSkge1xyXG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgXHJcblxyXG4gICAgbGV0IG1hcCA9IG5ldyBNYXAoKVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCkge1xyXG4gICAgICAgIG1hcC5zZXQoaywgJ05VTEwnKVxyXG4gICAgICB9IGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG1hcC5zZXQoaywgYCR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgbWFwLnNldChrLCBkYXRhU3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YVNxbFtrXSlcclxuICAgIH1cclxuXHJcbiAgICBzcWwgKz0gYCggJHtbLi4ubWFwLmtleXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBzcWwgKz0gYFZBTFVFUyggJHtbLi4ubWFwLnZhbHVlcygpXS5qb2luKCcsJyl9ICkgYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICBhc3luYyBxdWVyeVVwZGF0ZSAodGFibGUsIGZpbHRlciwgZGF0YSwgZGF0YVNxbCkge1xyXG4gICAgbGV0IHNxbCA9IGBVUERBVEUgJHt0YWJsZX0gU0VUIGBcclxuXHJcbiAgICBsZXQgdXBkYXRlcyA9IFtdXHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgfVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhU3FsW2tdfWApXHJcbiAgICB9XHJcbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJylcclxuXHJcbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIC8vIGVuYWJsZSB0byB1c2UgbXVsdGlwbGUgc3RhdGVtZW50c1xyXG4gIGFzeW5jIHF1ZXJ5TXVsdGkgKHNxbCkge1xyXG4gICAgbGV0IHBvb2xTd2FwID0gdGhpcy5wb29sXHJcbiAgICB0aGlzLnBvb2wgPSB0aGlzLnBvb2xNdWx0aVxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3RhcnRUcmFuc2FjdGlvbiAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBTVEFSVCBUUkFOU0FDVElPTjtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29tbWl0ICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYENPTU1JVDtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcm9sbGJhY2sgKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgUk9MTEJBQ0s7YClcclxuICB9XHJcblxyXG4gIHN0cmVhbWluZ1F1ZXJ5IChzcWwsIG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pIHtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwpXHJcbiAgICAgICAgICAgICAgICAub24oJ3Jlc3VsdCcsXHJcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb24ucGF1c2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0KHJlY29yZClcclxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKClcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGVcclxuICAgICAgfSlcclxuICB9XHJcblxyXG4gIGdldENvbiAoKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAvLyDjg5fjg7zjg6vjgYvjgonjga7jgrPjg43jgq/jgrfjg6fjg7PnjbLlvpdcclxuICAgICAgICB0aGlzLnBvb2wuZ2V0Q29ubmVjdGlvbigoZSwgY29uKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICByZWplY3QoZSlcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUoY29uKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLmNhdGNoKFxyXG4gICAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgfTtcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBQYWNrZXQge1xyXG4gIGNvbnN0cnVjdG9yIChwYWNrZXRTaXplKSB7XHJcbiAgICB0aGlzLnBhY2tldFNpemUgPSBwYWNrZXRTaXplXHJcbiAgICB0aGlzLm9uUGFja2V0U3RhcnQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldEVuZCA9IG51bGxcclxuICAgIHRoaXMuY291bnQgPSAwXHJcbiAgICB0aGlzLnBhY2tldENvdW50ID0gMFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0IChhcmcpIHtcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHliJ3mnJ/ljJbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0U3RhcnQpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLm9uUGFja2V0U3RhcnQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMub25QYWNrZXQpIHtcclxuICAgICAgYXdhaXQgdGhpcy5vblBhY2tldChhcmcpXHJcbiAgICB9XHJcbiAgICB0aGlzLmNvdW50KytcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHntYLkuoblh6bnkIbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIHRoaXMuY2xvc2UoKVxyXG4gICAgICB0aGlzLnBhY2tldENvdW50KytcclxuICAgIH1cclxuICB9XHJcbiAgY2xvc2UgKCkge1xyXG4gICAgaWYgKHRoaXMub25QYWNrZXRFbmQpIHtcclxuICAgICAgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdXRpbEVycm9yIGZyb20gJy4vZXJyb3InXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVwb3J0IHtcclxuICBjb25zdHJ1Y3RvciAoKSB7XHJcbiAgICB0aGlzLnJlY29yZCA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9ycyA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgc2V0dXBJdGVyYXRvciAoKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbmV3IEl0ZXJhdG9yKClcclxuICAgIHRoaXMuaXRlcmF0b3JzLnB1c2godGhpcy5pdGVyYXRvcilcclxuICB9XHJcblxyXG4gIGFzeW5jIHBoYXNlIChuYW1lID0gJycsIGZuID0gYXN5bmMgKCkgPT4ge30pIHtcclxuICAgIHRoaXMuc2V0dXBJdGVyYXRvcigpXHJcblxyXG4gICAgbGV0IHJlYyA9IHt9XHJcblxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IGZuKClcclxuXHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogcmVzXHJcbiAgICAgIH0pXHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHV0aWxFcnJvci5wYXJzZShlKVxyXG4gICAgICB9KVxyXG4gICAgfSBmaW5hbGx5IHtcclxuICAgICAgaWYgKHRoaXMuaXRlcmF0b3IudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3JcclxuICAgICAgICB9KVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMucmVjb3JkLnB1c2gocmVjKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgaVN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5zdWNjZXNzKG5ld1JlY29yZClcclxuICB9XHJcblxyXG4gIGlFcnJvciAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLmVycm9yKHV0aWxFcnJvci5wYXJzZShuZXdSZWNvcmQpKVxyXG4gIH1cclxuXHJcbiAgZXJyb3JPY3VycmVkICgpIHtcclxuICAgIGxldCBpdGVFcnJvciA9IHRoaXMuaXRlcmF0b3JzLmZpbmQoZSA9PiBlLmVycm9yT2N1cnJlZCgpKVxyXG4gICAgbGV0IHBoYUVycm9yID0gZmFsc2VcclxuICAgIGZvciAobGV0IHJlYyBvZiB0aGlzLnJlY29yZCkge1xyXG4gICAgICBpZiAocmVjLnR5cGUgPT09ICdlcnJvcicpIHtcclxuICAgICAgICBwaGFFcnJvciA9IHRydWVcclxuICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICByZXR1cm4gaXRlRXJyb3IgfHwgcGhhRXJyb3JcclxuICB9XHJcblxyXG4gIHB1Ymxpc2ggKCkge1xyXG4gICAgaWYgKHRoaXMuZXJyb3JPY3VycmVkKCkpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcih0aGlzLnJlY29yZClcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnJlY29yZFxyXG4gIH1cclxufVxyXG5cclxuY2xhc3MgSXRlcmF0b3Ige1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMudG90YWwgPSAwXHJcbiAgICB0aGlzLnRyYWNlID0ge1xyXG4gICAgICBzdWNjZXNzOiB7XHJcbiAgICAgICAgdG90YWw6IDAsXHJcbiAgICAgICAgcmVjb3JkczogW11cclxuICAgICAgfSxcclxuICAgICAgZXJyb3I6IHtcclxuICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICByZWNvcmRzOiBbXVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBzdWNjZXNzIChuZXdSZWNvcmQpIHtcclxuICAgIGlmIChuZXdSZWNvcmQpIHtcclxuICAgICAgdGhpcy50cmFjZS5zdWNjZXNzLnJlY29yZHMucHVzaChuZXdSZWNvcmQpXHJcbiAgICB9XHJcbiAgICB0aGlzLnRyYWNlLnN1Y2Nlc3MudG90YWwrK1xyXG4gICAgdGhpcy50b3RhbCsrXHJcbiAgfVxyXG4gIGVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIC8vIOebtOWJjeOBruOCqOODqeODvOOCkuWPluW+l1xyXG4gICAgbGV0IGxhc3RFcnJvciA9IG51bGxcclxuICAgIGxldCBpbmRleCA9IHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkcy5sZW5ndGhcclxuICAgIGlmIChpbmRleCkge1xyXG4gICAgICBsYXN0RXJyb3IgPSB0aGlzLnRyYWNlLmVycm9yLnJlY29yZHNbaW5kZXggLSAxXVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOebtOWJjeOBqOWQjOOBmOOCqOODqeODvOOBr+ecgeOBj1xyXG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KGxhc3RFcnJvcikgIT09IEpTT04uc3RyaW5naWZ5KG5ld1JlY29yZCkpIHtcclxuICAgICAgaWYgKG5ld1JlY29yZCAmJiBuZXdSZWNvcmQgIT09IHt9ICYmIG5ld1JlY29yZCAhPT0gJycpIHtcclxuICAgICAgICB0aGlzLnRyYWNlLmVycm9yLnJlY29yZHMucHVzaChuZXdSZWNvcmQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHRoaXMudHJhY2UuZXJyb3IudG90YWwrK1xyXG4gICAgdGhpcy50b3RhbCsrXHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQgKCkge1xyXG4gICAgcmV0dXJuIHRoaXMudHJhY2UuZXJyb3IudG90YWxcclxuICB9XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGV4dFV0aWwge1xyXG4gIHN0YXRpYyBzdWJzdHI4ICh0ZXh0LCBsZW4sIHRydW5jYXRpb24pIHtcclxuICAgIGlmICh0cnVuY2F0aW9uID09PSB1bmRlZmluZWQpIHsgdHJ1bmNhdGlvbiA9ICcnIH1cclxuICAgIHZhciB0ZXh0QXJyYXkgPSB0ZXh0LnNwbGl0KCcnKVxyXG4gICAgdmFyIGNvdW50ID0gMFxyXG4gICAgdmFyIHN0ciA9ICcnXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRleHRBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICB2YXIgbiA9IGVzY2FwZSh0ZXh0QXJyYXlbaV0pXHJcbiAgICAgIGlmIChuLmxlbmd0aCA8IDQpIGNvdW50KytcclxuICAgICAgZWxzZSBjb3VudCArPSAyXHJcbiAgICAgIGlmIChjb3VudCA+IGxlbikge1xyXG4gICAgICAgIHJldHVybiBzdHIgKyB0cnVuY2F0aW9uXHJcbiAgICAgIH1cclxuICAgICAgc3RyICs9IHRleHQuY2hhckF0KGkpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGV4dFxyXG4gIH1cclxufVxyXG4iXX0=
