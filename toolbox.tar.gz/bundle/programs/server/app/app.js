var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/route/upload/image.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

// WebApp.connectHandlers.use('/upload', (req, res, next) => {
//   res.writeHead(200);
//   res.end(`Hello world from: ${Meteor.release}`);
// });

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

// Requires multiparty

var _connectMultiparty = require('connect-multiparty');

var _connectMultiparty2 = _interopRequireDefault(_connectMultiparty);

var _importsCollections = require('../../../imports/collections');

var multipartyMiddleware = (0, _connectMultiparty2['default'])();

var route = '/upload/image';

// WebApp.connectHandlers.use('/upload', fuc.uploadFile );
WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, function (req, resp) {
  // don't forget to delete all req.files when done

  var reader = Meteor.wrapAsync(_fs2['default'].readFile);
  var writer = Meteor.wrapAsync(_fs2['default'].writeFile);
  var uploadId = (0, _uniqid2['default'])();

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = req.files.file[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var file = _step.value;

      var data = reader(file.path);
      // ファイル名の重複を避けるため、一意のファイル名を作成する
      // 楽天のファイル名文字数制限20に合わせる
      var filename = (0, _uniqid2['default'])() + '.jpg';

      // set the correct path for the file not the temporary one from the API:
      var savePath = req.body.imagedir + '/' + filename;

      // copy the data from the req.files.file.path and paste it to file.path

      // アップロード結果を記録する
      var doc = {
        uploadId: uploadId,
        clientFileName: file.name,
        uploadedFileName: filename
      };

      try {
        writer(savePath, data);
      } catch (err) {
        doc.error = err;
      }
      _importsCollections.Uploads.insert(doc);

      delete file;
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator['return']) {
        _iterator['return']();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube/cubemig.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _crypto = require('crypto');

var _crypto2 = _interopRequireDefault(_crypto);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsUtilReport = require('../../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsCollectionGroups = require('../../imports/collection/groups');

var _importsCollectionFilters = require('../../imports/collection/filters');

var tag = 'cubemig';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.migrate', function callee$0$0(config) {
  var report, filter, testQuery, dstDb;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsCollectionFilters.Filter(config.srcFilterId);
        testQuery = 'SHOW DATABASES';
        dstDb = new _importsUtilMysql2['default'](config.dst.cred);
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(report.phase('Connect to Destination', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(dstDb.query(testQuery));

              case 2:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 6:
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(report.phase('Select loop in source', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this2 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  mobileNull: function mobileNull(record) {
                    var sql, couponCd, couponName, discountPrice, _res;

                    return regeneratorRuntime.async(function mobileNull$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          sql = '\n\n                INSERT dtb_customer\n                ( `customer_id`, `status`, `sex`, `job`, `country_id`, `pref`, `name01`, `name02`, `kana01`, `kana02`, `company_name`, `zip01`, `zip02`, `zipcode`, `addr01`, `addr02`, `email`, `tel01`, `tel02`, `tel03`, `fax01`, `fax02`, `fax03`, `birth`, `password`, `salt`, `secret_key`, `first_buy_date`, `last_buy_date`, `buy_times`, `buy_total`, `note`, `create_date`, `update_date`, `del_flg` )\n\n                VALUES( ' + record.customer_id + ' , ' + record.status + ' , ' + record.sex + ' , ' + record.job + ' , ' + record.country_id + ' , ' + record.pref + ' , ' + record.name01 + ' , ' + record.name02 + ' , ' + record.kana01 + ' , ' + record.kana02 + ' , ' + record.company_name + ' , ' + record.zip01 + ' , ' + record.zip02 + ' , ' + record.zipcode + ' , ' + record.addr01 + ' , ' + record.addr02 + ' , ' + record.email + ' , ' + record.tel01 + ' , ' + record.tel02 + ' , ' + record.tel03 + ' , ' + record.fax01 + ' , ' + record.fax02 + ' , ' + record.fax03 + ' , ' + record.birth + ' , ' + record.password + ' , ' + record.salt + ' , ' + record.secret_key + ' , ' + record.first_buy_date + ' , ' + record.last_buy_date + ' , ' + record.buy_times + ' , ' + record.buy_total + ' , ' + record.note + ' , ' + record.create_date + ' , ' + record.update_date + ' , ' + record.del_flg + ' )\n                \n                ';
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer', {
                            customer_id: record.customer_id,
                            status: record.status,
                            sex: record.sex,
                            job: record.job,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            email: record.email,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            birth: record.birth,
                            password: record.password,
                            salt: record.salt,
                            secret_key: record.secret_key,
                            first_buy_date: record.first_buy_date,
                            last_buy_date: record.last_buy_date,
                            buy_times: record.buy_times,
                            buy_total: record.buy_total,
                            note: record.note,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 4:
                          context$3$0.next = 9;
                          break;

                        case 6:
                          context$3$0.prev = 6;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 9:
                          context$3$0.prev = 9;
                          context$3$0.next = 12;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer_address', {
                            customer_address_id: null,
                            customer_id: record.customer_id,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 12:
                          context$3$0.next = 17;
                          break;

                        case 14:
                          context$3$0.prev = 14;
                          context$3$0.t1 = context$3$0['catch'](9);

                          report.iError(context$3$0.t1);

                        case 17:
                          context$3$0.prev = 17;
                          context$3$0.next = 20;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_mailmaga_customer', {
                            id: null,
                            customer_id: record.customer_id,
                            mailmaga_flg: record.mailmaga_flg,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 20:
                          context$3$0.next = 25;
                          break;

                        case 22:
                          context$3$0.prev = 22;
                          context$3$0.t2 = context$3$0['catch'](17);

                          report.iError(context$3$0.t2);

                        case 25:
                          couponCd = _crypto2['default'].randomBytes(8).toString('base64').substring(0, 11);
                          couponName = record.name01 + ' ' + record.name02 + ' 様 ご優待クーポン 会員番号:' + record.customer_id;
                          discountPrice = record.point + 500;
                          context$3$0.prev = 28;
                          context$3$0.next = 31;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_coupon', {
                            coupon_id: null,
                            coupon_cd: couponCd,
                            coupon_type: 3, // 全商品
                            coupon_name: couponName,
                            discount_type: 1,
                            coupon_use_time: 1,
                            coupon_release: 1,
                            discount_price: discountPrice,
                            discount_rate: null,
                            enable_flag: 1,
                            coupon_member: 1,
                            coupon_lower_limit: null,
                            customer_id: record.customer_id,
                            available_from_date: '2018-04-02 00:00:00',
                            available_to_date: '2019-05-02 00:00:00',
                            del_flg: 0
                          }, {
                            create_date: 'NOW()',
                            update_date: 'NOW()'
                          }));

                        case 31:
                          _res = context$3$0.sent;
                          context$3$0.next = 37;
                          break;

                        case 34:
                          context$3$0.prev = 34;
                          context$3$0.t3 = context$3$0['catch'](28);

                          report.iError(context$3$0.t3);

                        case 37:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this2, [[1, 6], [9, 14], [17, 22], [28, 34]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        report.iError(e);

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this2);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 8:
        return context$1$0.abrupt('return', report.publish());

      case 9:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, 'cubemig.serverCheck', function cubemigServerCheck(profile) {
  var db, res;
  return regeneratorRuntime.async(function cubemigServerCheck$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        db = new _importsUtilMysql2['default'](profile);
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(db.query('SHOW DATABASES'));

      case 3:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// setup group
//

// let plug = group.getPlug();

// checking connection
//

// process for each members
//

// // 値を整理
// for (let key of Object.keys(record)) {
//   if (record[key] === null);
//   else if (record[key].constructor.name === 'Date') {
//     // 日付を変換
//     record[key] = MySQL.formatDate(record[key]);
//     record[key] = `"${record[key]}"`;
//   }
// }

// dtb_customer に保存

// dtb_customer_address

// メルマガプラグイン plg_mailmaga_customer

// クーポン発行（ECCUBE2のポイント還元）
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/collection.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilMongo = require('../../imports/util/mongo');

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.collection';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.find', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var projection = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.find(query, { projection: projection }).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.aggregate', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.aggregate(query).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/items.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _meteorMeteor = require('meteor/meteor');

var _importsServiceItems = require('../../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var tag = 'jline.items';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.setImage', function callee$0$0(plug, uploadId, model) {
  var class1 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var class2 = arguments.length <= 4 || arguments[4] === undefined ? null : arguments[4];
  var itemcon, uploaded;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.setImage(uploadId, model, class1, class2));

      case 5:
        uploaded = context$1$0.sent;
        return context$1$0.abrupt('return', uploaded);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.cleanImage', function callee$0$0(plug, model) {
  var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
  var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var itemcon;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.cleanImage(model, class1, class2));

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

/**
 * 指定された条件に一致するitemsコレクション内のドキュメントに、
 * アップロード済み画像を関連付けます。
 * @param
 */

/**
 * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceCube3api = require('../imports/service/cube3api');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var tag = 'cube';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.category', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('商品カテゴリの更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  UPDATE: function UPDATE(item, context) {
                    var results;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          if (!_lodash2['default'].isArray(item.mall.sharakuShop.categories)) {
                            context$3$0.next = 11;
                            break;
                          }

                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(api.modifyCategory(item.mall.sharakuShop.product_id, item.mall.sharakuShop.categories));

                        case 4:
                          results = context$3$0.sent;

                          // SQLクエリ結果を記録
                          report.iSuccess(results);
                          context$3$0.next = 11;
                          break;

                        case 8:
                          context$3$0.prev = 8;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 11:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this, [[1, 8]]);
                  }
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('在庫の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({

                  UPDATE: function UPDATE(item, context) {
                    var quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;
                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 5:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  }
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibItem', function callee$0$0(config) {
  var filter, targetDB, api, itemController, report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this6 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 6:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3への商品登録', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  INSERT: function INSERT(item, context) {
                    var col, cubeItem, insertRes;
                    return regeneratorRuntime.async(function INSERT$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.updateItem, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productCreate(cubeItem));

                        case 7:
                          insertRes = context$3$0.sent;
                          context$3$0.next = 10;
                          return regeneratorRuntime.awrap(col.updateOne({
                            _id: item._id
                          }, {
                            $set: {
                              'mall.sharakuShop.product_id': insertRes.res.product_id,
                              'mall.sharakuShop.product_class_id': insertRes.res.product_class_id,
                              'mall.sharakuShop.product_stock_id': insertRes.res.product_stock_id
                            }
                          }));

                        case 10:

                          report.iSuccess();
                          context$3$0.next = 16;
                          break;

                        case 13:
                          context$3$0.prev = 13;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 16:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this5, [[1, 13]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 9:
        context$1$0.next = 11;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3商品情報の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this7 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  UPDATE: function UPDATE(item, context) {
                    var col, cubeItem, quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.updateItem, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productImageUpdate(cubeItem));

                        case 7:
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(api.productUpdate(cubeItem));

                        case 9:
                          context$3$0.next = 11;
                          return regeneratorRuntime.awrap(api.productTagUpdate(cubeItem));

                        case 11:
                          context$3$0.next = 13;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 13:
                          quantity = context$3$0.sent;
                          context$3$0.next = 16;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 16:

                          report.iSuccess();
                          context$3$0.next = 22;
                          break;

                        case 19:
                          context$3$0.prev = 19;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 22:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this7, [[1, 19]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this7);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 11:
        return context$1$0.abrupt('return', report.publish());

      case 12:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// カテゴリ更新

// クライアントが参照するための処理結果作成オブジェクト

// 商品にカテゴリーデータが記録されていれば処理する

// 商品情報データベースに記録された商品カテゴリー情報を、モールに適用する

//
// 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 商品情報登録と更新

// クライアントが参照するための処理結果作成オブジェクト

// item データベースへの登録
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/robotin.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var _fibers = require('fibers');

var _fibers2 = _interopRequireDefault(_fibers);

var _importsServiceRobotin = require('../imports/service/robotin');

var _importsServiceRobotin2 = _interopRequireDefault(_importsServiceRobotin);

var tag = 'robotin';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order.export', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 受注CSV 出力', function callee$1$0() {
          var workdir, workdirExport, orderCsvExport, itemS;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.order.workdir;
                workdirExport = workdir + '/' + config.order.workdirExport;
                orderCsvExport = config.order.ordercsvExport + '.csv';
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirExport));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 27:

                // 受注CSVを出力する
                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _importsServiceRobotin2['default'].createReadableOrder().on('error', function (err) {
                    mcb(err);
                  });

                  var transform = new _stream.Transform({
                    writableObjectMode: true,
                    readableObjectMode: true,
                    transform: function transform(chunk, enc, cb) {
                      cb(null, chunk.robotin);
                    }
                  });

                  var write = _fsExtra2['default'].createWriteStream(workdirExport + '/' + orderCsvExport).on('error', function (err) {
                    mcb(err);
                  }).on('finish', function () {
                    mcb();
                  });

                  read.pipe(transform).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(write);
                })();

              case 28:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this, [[3, 8], [10, 15], [17, 22]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.order.import', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this3 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 受注CSV 取込み', function callee$1$0() {
          var workdir, workdirImport, orderCsv, itemS;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.order.workdir;
                workdirImport = workdir + '/' + config.order.workdirImport;
                orderCsv = config.order.ordercsv + '.csv';
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirImport));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 27:

                // 受注CSVを読み込む
                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _fsExtra2['default'].createReadStream(workdirImport + '/' + orderCsv).on('error', function (err) {
                    mcb(err);
                  });
                  var write = new _stream.Writable({
                    objectMode: true,
                    write: function write(chunk, encoding, callback) {
                      var _this2 = this;

                      (0, _fibers2['default'])(function callee$4$0() {
                        return regeneratorRuntime.async(function callee$4$0$(context$5$0) {
                          while (1) switch (context$5$0.prev = context$5$0.next) {
                            case 0:
                              context$5$0.prev = 0;
                              context$5$0.next = 3;
                              return regeneratorRuntime.awrap(_importsServiceRobotin2['default'].importOrder(chunk, itemS));

                            case 3:
                              report.iSuccess();
                              context$5$0.next = 9;
                              break;

                            case 6:
                              context$5$0.prev = 6;
                              context$5$0.t0 = context$5$0['catch'](0);

                              callback(context$5$0.t0);

                            case 9:
                              callback();

                            case 10:
                            case 'end':
                              return context$5$0.stop();
                          }
                        }, null, _this2, [[0, 6]]);
                      }).run();
                    },
                    final: function final(callback) {
                      callback();
                      mcb();
                    }
                  }).on('error', function (err) {
                    return report.iError(err);
                  });

                  read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(write);
                })();

              case 28:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this3, [[3, 8], [10, 15], [17, 22]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.postlabel', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 送り状発行', function callee$1$0() {
          var workdir, workdirRead, workdirWrite, itemS, robo;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.postlabel.workdir;
                workdirRead = workdir + '/' + config.postlabel.workdirRead;
                workdirWrite = workdir + '/' + config.postlabel.workdirWrite;
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirRead));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                context$2$0.prev = 24;
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirWrite));

              case 27:
                context$2$0.next = 31;
                break;

              case 29:
                context$2$0.prev = 29;
                context$2$0.t3 = context$2$0['catch'](24);

              case 31:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 34;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 34:
                robo = new _importsServiceRobotin2['default']();

                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _fsExtra2['default'].createReadStream(workdirRead + '/' + config.postlabel.ordercsv + '.csv').on('error', function (err) {
                    mcb(err);
                  });
                  var write = new _stream.Writable({
                    objectMode: true,
                    write: function write(chunk, encoding, callback) {
                      robo.importOrderTemp(chunk, itemS);
                      callback();
                    },
                    final: function final(callback) {
                      callback();
                      mcb();
                    }
                  });

                  read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(write);
                })();

                // 送り状種別ごとに繰り返す
                config.postlabel.labeltypes.forEach(function (labelOption) {
                  try {
                    _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                      var read = _fsExtra2['default'].createReadStream(workdirRead + '/' + labelOption.readcsv + '.csv').on('error', function () {
                        mcb();
                      }); // ファイルがない場合は無視
                      var transform = new _stream.Transform({
                        readableObjectMode: true,
                        writableObjectMode: true,
                        transform: function transform(chunk, encoding, callback) {
                          var record = undefined;
                          try {
                            (0, _fibers2['default'])(function () {
                              record = robo[labelOption.method](chunk, labelOption);
                              callback(null, record);
                            }).run();
                          } catch (error) {
                            mcb(error);
                          }
                        }
                      });
                      var write = _fsExtra2['default'].createWriteStream(workdirWrite + '/' + labelOption.writecsv + '.csv').on('finish', function () {
                        report.iSuccess();
                        mcb();
                      }).on('error', function (error) {
                        mcb(error);
                      });

                      read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: labelOption.columns === true ? true : null })).pipe(transform).pipe(_csv2['default'].stringify({ header: labelOption.columns })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(write);
                    })();
                  } catch (error) {
                    report.iError(error);
                  }
                });

              case 37:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[3, 8], [10, 15], [17, 22], [24, 29]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.itemcode', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this5 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 外部連携商品番号', function callee$1$0() {
          var workdir, itemController, read, writeCsv;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.itemcode.workdir;
                context$2$0.prev = 1;
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 4:
                context$2$0.next = 8;
                break;

              case 6:
                context$2$0.prev = 6;
                context$2$0.t0 = context$2$0['catch'](1);

              case 8:
                context$2$0.prev = 8;
                context$2$0.next = 11;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 11:
                context$2$0.next = 22;
                break;

              case 13:
                context$2$0.prev = 13;
                context$2$0.t1 = context$2$0['catch'](8);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 18;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 18:
                read = itemController.Items.find({ model: { $ne: '' } }).stream();

                writeCsv = function writeCsv(read, tf, filename) {
                  var robotin = new _stream.Transform({
                    readableObjectMode: true,
                    writableObjectMode: true,
                    transform: function transform(chunk, encoding, callback) {
                      (0, _fibers2['default'])(function () {
                        var data = tf(chunk);
                        callback(null, data);
                      }).run();
                    }
                  });
                  var count = 0;
                  var clearnum = new _stream.Transform({
                    encoding: 'utf8',
                    transform: function transform(chunk, encoding, callback) {
                      var str = chunk.toString();
                      if (count === 0) {
                        str = str.replace(/_\d+?/g, '');
                      }
                      count++;
                      callback(null, str);
                    }
                  });
                  var writecsv = _fsExtra2['default'].createWriteStream(filename + '.csv');
                  writecsv.on('error', function (e) {
                    throw _meteorMeteor.Meteor.Error('CSVファイル書き込みエラー');
                  });

                  read.pipe(robotin).pipe(_csv2['default'].stringify({ header: true })).pipe(clearnum).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(writecsv);
                };

                writeCsv(read, _importsServiceItems2['default'].convertItemRobotinItem, workdir + '/' + config.itemcode.csvNameItem);

                writeCsv(read, _importsServiceItems2['default'].convertItemRobotinSelect, workdir + '/' + config.itemcode.csvNameSelect);

              case 22:
                throw new _meteorMeteor.Meteor.Error('正しい作業ディレクトリが用意されていませんでした。\n[' + workdir + ']');

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this5, [[1, 6], [8, 13]]);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 商品データベースへの接続準備

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 商品データベースへの接続準備

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 書き込みフォルダ

// workdir が準備されていたら実行する

// 受注CSVを読み込む

//
// Robot-in
// 外部連携商品番号

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// workdir が準備されていたら実行する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/tooltest.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _meteorMeteor = require('meteor/meteor');

var tag = 'tool';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.test', function callee$0$0(config) {
  var report, filter, newLocal;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        context$1$0.next = 4;
        return regeneratorRuntime.awrap(filter.foreach({}, function callee$1$0(e) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                throw e;

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 4:
        newLocal = context$1$0.sent;
        context$1$0.next = 7;
        return regeneratorRuntime.awrap(report.phase('フィルターテスト', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                return context$2$0.abrupt('return', newLocal);

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 7:
        return context$1$0.abrupt('return', report.publish());

      case 8:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// 商品情報更新

// クライアントが参照するための処理結果作成オブジェクト
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowma.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _importsServiceWowmaApi = require('../imports/service/wowmaApi');

var _importsServiceWowmaApi2 = _interopRequireDefault(_importsServiceWowmaApi);

var _importsUtilError = require('../imports/util/error');

var _importsUtilError2 = _interopRequireDefault(_importsUtilError);

var tag = 'wowma';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateItem.info', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品情報を更新する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     },
                    //     {
                    //       'mall.wowma.itemCode': '10004942' // JK-120
                    //     }
                    // {
                    //   'mall.wowma.itemCode': '10005402'
                    // },
                    // {
                    //   'mall.wowma.itemCode': '10004743'
                    // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        Object.assign(item, config.itemInfo['default']);
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 4:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 8:
                        context$3$0.prev = 8;
                        context$3$0.t0 = context$3$0['catch'](1);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 8]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.deliveryMethod', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品の配送方法を設定する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     },
                    //     {
                    //       'mall.wowma.itemCode': '10004942' // JK-120
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        context$3$0.t0 = Object;
                        context$3$0.t1 = item;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.convertItemWowmaCreateDeliveryMethod(item.itemCode));

                      case 4:
                        context$3$0.t2 = context$3$0.sent;
                        context$3$0.t0.assign.call(context$3$0.t0, context$3$0.t1, context$3$0.t2);
                        context$3$0.prev = 6;
                        context$3$0.next = 9;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 9:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 13:
                        context$3$0.prev = 13;
                        context$3$0.t3 = context$3$0['catch'](6);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t3));

                      case 16:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[6, 13]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.open', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this6 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品データベース上の商品を公開する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        item.saleStatus = 1;
                        item.limitedPasswd = 'NULL';
                        context$3$0.prev = 2;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 5:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 9:
                        context$3$0.prev = 9;
                        context$3$0.t0 = context$3$0['catch'](2);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 12:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5, [[2, 9]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this7 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 在庫更新', function callee$1$0() {
          var itemController, cur, item, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, e, api, res;

          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    //   ,{
                    //     $or: [
                    //       {
                    //         'mall.wowma.itemCode': '10005402'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': 'gk-163'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': '10004743'
                    //       }
                    //     ]
                    //   }
                    ]
                  }
                }, {
                  // 配送方法の違いを省く
                  $group: {
                    _id: {
                      itemCode: '$mall.wowma.itemCode',
                      choicesStockHorizontalCode: '$mall.wowma.HChoiceName',
                      choicesStockVerticalCode: '$mall.wowma.VChoiceName'
                    },
                    item: {
                      $first: '$_id'
                    }
                  }
                }, {
                  // 商品ページごと（商品コード）にグループ化する
                  $group: {
                    _id: '$_id.itemCode',
                    variations: {
                      $push: {
                        _id: '$item',
                        choicesStockHorizontalCode: '$_id.choicesStockHorizontalCode',
                        choicesStockVerticalCode: '$_id.choicesStockVerticalCode'
                      }
                    }
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id',
                    variations: '$variations'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;

              case 6:
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(cur.hasNext());

              case 8:
                if (!context$2$0.sent) {
                  context$2$0.next = 53;
                  break;
                }

                context$2$0.next = 11;
                return regeneratorRuntime.awrap(cur.next());

              case 11:
                item = context$2$0.sent;
                _iteratorNormalCompletion = true;
                _didIteratorError = false;
                _iteratorError = undefined;
                context$2$0.prev = 15;
                _iterator = item.variations[Symbol.iterator]();

              case 17:
                if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                  context$2$0.next = 26;
                  break;
                }

                e = _step.value;
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(itemController.getStock(e._id));

              case 21:
                e.stock = context$2$0.sent;

                delete e._id;

              case 23:
                _iteratorNormalCompletion = true;
                context$2$0.next = 17;
                break;

              case 26:
                context$2$0.next = 32;
                break;

              case 28:
                context$2$0.prev = 28;
                context$2$0.t0 = context$2$0['catch'](15);
                _didIteratorError = true;
                _iteratorError = context$2$0.t0;

              case 32:
                context$2$0.prev = 32;
                context$2$0.prev = 33;

                if (!_iteratorNormalCompletion && _iterator['return']) {
                  _iterator['return']();
                }

              case 35:
                context$2$0.prev = 35;

                if (!_didIteratorError) {
                  context$2$0.next = 38;
                  break;
                }

                throw _iteratorError;

              case 38:
                return context$2$0.finish(35);

              case 39:
                return context$2$0.finish(32);

              case 40:
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.prev = 41;
                context$2$0.next = 44;
                return regeneratorRuntime.awrap(api.updateStock([item]));

              case 44:
                res = context$2$0.sent;

                report.iSuccess(res);
                context$2$0.next = 51;
                break;

              case 48:
                context$2$0.prev = 48;
                context$2$0.t1 = context$2$0['catch'](41);

                report.iError(context$2$0.t1);

              case 51:
                context$2$0.next = 6;
                break;

              case 53:
                cur.close();

              case 54:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this7, [[15, 28, 32, 40], [33,, 35, 39], [41, 48]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.searchItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this9 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, workdir, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this8 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.prev = 4;
                context$2$0.next = 7;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 7:
                context$2$0.next = 11;
                break;

              case 9:
                context$2$0.prev = 9;
                context$2$0.t0 = context$2$0['catch'](4);

              case 11:
                workdir = config.workdir + '/items_' + new Date().getTime();
                context$2$0.prev = 12;
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 15:
                context$2$0.next = 19;
                break;

              case 17:
                context$2$0.prev = 17;
                context$2$0.t1 = context$2$0['catch'](12);

              case 19:
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var options, repos, filename;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          options = JSON.parse(JSON.stringify(config.wowmaApi));

                          options.uri = options.uri + '/searchItemInfo';
                          options.qs.itemCode = item.mall.wowma.itemCode;

                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

                        case 5:
                          repos = context$3$0.sent;
                          filename = workdir + '/' + item.model + '.xml';
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(_fsExtra2['default'].writeFile(filename, repos));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this8);
                  } }));

              case 21:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this9, [[4, 9], [12, 17]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// WOWMA 商品情報の変更

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品の配送方法を設定する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品データベース上の商品を公開する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 在庫情報の作成

// let resMongo = await cur.toArray()
// return resMongo

// リクエストボディ

// 在庫を設定する

//
// 在庫更新リクエスト

//
// WOWMA 商品検索

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 作業フォルダを作成する

// APIから取得した商品情報を保存する場所

// 作業フォルダを作成する

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowmaApi.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'wowmaApi';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.getItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.WowmaApiItemFilter(config.wowmaApi, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          report.iSuccess(item);

                        case 1:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 6:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 8:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// WOWMA商品情報取得

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(config.workdir)
// } catch (e) {}

// // APIから取得した商品情報を保存する場所
// const workdir = `${config.workdir}/items_${(new Date()).getTime()}`
// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(workdir)
// } catch (e) {}

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/yauct.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var _importsUtilPacket = require('../imports/util/packet');

var _importsUtilPacket2 = _interopRequireDefault(_importsUtilPacket);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var prefix = 'packet';
var tag = 'yauct';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク受注', function callee$1$0() {
          var itemController, workdir, r, w;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                workdir = config.workdir + '/order';
                r = _fsExtra2['default'].createReadStream(workdir + '/' + config.orderLoadfile);
                w = _fsExtra2['default'].createWriteStream(workdir + '/' + config.orderSavefile);

                r.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(_csv2['default'].transform(function callee$2$0(record, callback) {
                  var err;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        err = null;
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.getModelClass(record['管理番号']));

                      case 4:
                        record['管理番号'] = context$3$0.sent;
                        context$3$0.next = 10;
                        break;

                      case 7:
                        context$3$0.prev = 7;
                        context$3$0.t0 = context$3$0['catch'](1);

                        err = context$3$0.t0;

                      case 10:
                        callback(err, record);

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 7]]);
                })).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(w);

              case 7:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibit', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク出品', function callee$1$0() {
          var filter, itemController, packet, workdir, uploaddir, cd, filename, name, fields, header, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                packet = new _importsUtilPacket2['default'](config.packetSize);
                context$2$0.prev = 5;
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 8:
                context$2$0.next = 12;
                break;

              case 10:
                context$2$0.prev = 10;
                context$2$0.t0 = context$2$0['catch'](5);

              case 12:
                workdir = config.workdir + '/work';
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(workdir));

              case 15:
                context$2$0.next = 17;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 17:
                uploaddir = config.workdir + '/upload';
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(uploaddir));

              case 20:
                context$2$0.next = 22;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(uploaddir));

              case 22:
                cd = null;
                filename = null;
                name = null;
                fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
                header = fields.map(function (v) {
                  return '"' + v + '"';
                }).join(',') + '\n';

                // パケット化開始時
                packet.onPacketStart = function callee$2$0(packetCount) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        name = prefix + ('00000' + packetCount).slice(-5);
                        cd = workdir + '/' + name;
                        filename = cd + '/' + config.csvFileName;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(cd));

                      case 5:
                        context$3$0.next = 7;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(header, 'Shift_JIS')));

                      case 7:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // パケット化時
                packet.onPacket = function callee$2$0(arg) {
                  var yauct, item, record, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, img, imgSrc, imgTgt;

                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        yauct = arg.yauct;
                        item = arg.item;
                        record = fields.map(function (v) {
                          return yauct[v] ? '"' + yauct[v] + '"' : '""';
                        }).join(',') + '\n';
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(record, 'Shift_JIS')));

                      case 5:
                        _iteratorNormalCompletion = true;
                        _didIteratorError = false;
                        _iteratorError = undefined;
                        context$3$0.prev = 8;
                        _iterator = item.images[Symbol.iterator]();

                      case 10:
                        if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                          context$3$0.next = 26;
                          break;
                        }

                        img = _step.value;
                        imgSrc = config.imagedir + '/' + img;
                        imgTgt = cd + '/' + img;
                        context$3$0.prev = 14;
                        context$3$0.next = 17;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].access(imgTgt));

                      case 17:
                        context$3$0.next = 23;
                        break;

                      case 19:
                        context$3$0.prev = 19;
                        context$3$0.t0 = context$3$0['catch'](14);
                        context$3$0.next = 23;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].copyFile(imgSrc, imgTgt));

                      case 23:
                        _iteratorNormalCompletion = true;
                        context$3$0.next = 10;
                        break;

                      case 26:
                        context$3$0.next = 32;
                        break;

                      case 28:
                        context$3$0.prev = 28;
                        context$3$0.t1 = context$3$0['catch'](8);
                        _didIteratorError = true;
                        _iteratorError = context$3$0.t1;

                      case 32:
                        context$3$0.prev = 32;
                        context$3$0.prev = 33;

                        if (!_iteratorNormalCompletion && _iterator['return']) {
                          _iterator['return']();
                        }

                      case 35:
                        context$3$0.prev = 35;

                        if (!_didIteratorError) {
                          context$3$0.next = 38;
                          break;
                        }

                        throw _iteratorError;

                      case 38:
                        return context$3$0.finish(35);

                      case 39:
                        return context$3$0.finish(32);

                      case 40:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[8, 28, 32, 40], [14, 19], [33,, 35, 39]]);
                };

                // パケット終了時
                packet.onPacketEnd = function callee$2$0(packetCount) {
                  var zip, zipname, output;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        zip = (0, _archiver2['default'])('zip');
                        zipname = uploaddir + '/' + name + '.zip';
                        output = _fsExtra2['default'].createWriteStream(zipname);

                        zip.pipe(output);
                        zip.directory(cd, false);
                        zip.finalize();

                      case 6:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // メインループ
                //

                context$2$0.next = 32;
                return regeneratorRuntime.awrap(filter.foreach({

                  TARGET: function TARGET(item, context) {
                    var quantity, yauct;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;

                          if (!(quantity >= item.mall.yauct.minQuantity)) {
                            context$3$0.next = 9;
                            break;
                          }

                          context$3$0.next = 6;
                          return regeneratorRuntime.awrap(itemController.convertItemYauct(config['default'], item));

                        case 6:
                          yauct = context$3$0.sent;
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(packet.submit({ yauct: yauct, item: item }));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  }
                }));

              case 32:
                res = context$2$0.sent;

                packet.close();

                return context$2$0.abrupt('return', res);

              case 35:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[5, 10]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// ヤフオク受注ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 管理番号を置き換える

//
// ヤフオク出品ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 繰り返し処理を任意の（packetSize）で分割

// 作業フォルダを作成する

// CSVファイルを作成し画像データを収集する場所

// ZIPファイルを保存する場所
// パケットフォルダ
// csvファイル
// パケット番号

// CSVフィールドを定義し、順番を確定する

// CSVファイルにフィールドを設定する

// csvファイルにレコード（商品テンプレート）を追加する

// 画像ファイルをコピー

// 同じファイルがある場合はコピーしない

// itemに定義されている最低必要在庫より多い商品を出品する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
require('../imports/collections');

require('./route/upload/image');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"filters.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/filters.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _groups = require('./groups');

var Filters = new _meteorMongo.Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

var Filter = (function (_GroupBase) {
  _inherits(Filter, _GroupBase);

  function Filter(filterId) {
    var _this = this;

    _classCallCheck(this, Filter);

    var profile = Filters.findOne({
      _id: filterId
    });

    _get(Object.getPrototypeOf(Filter.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {

      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0() {
          var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
          var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table;
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, onError));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this);
        };
        break;

      default:
        throw new Error('invalid platform type');

    }
  }

  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */

  _createClass(Filter, [{
    key: 'foreach',
    value: function foreach() {
      var _this2 = this;

      var callbacks = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this2);
      } : arguments[1];

      var profile, count, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, filter;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this3 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              type: 'misc',
              query: {}
            });

            count = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              filter = _step.value;

              count[filter.type] = {
                query: filter.query,
                count: 0
              };
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record) {
              var _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, filter, query, exam;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion2 = true;
                    _didIteratorError2 = false;
                    _iteratorError2 = undefined;
                    context$3$0.prev = 3;
                    _iterator2 = profile.filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
                      context$3$0.next = 18;
                      break;
                    }

                    filter = _step2.value;
                    query = _mongoobject2['default'].unescape(filter.query);
                    exam = (0, _sift2['default'])(query);

                    if (!exam(record)) {
                      context$3$0.next = 15;
                      break;
                    }

                    count[filter.type].count++;

                    if (!(typeof callbacks[filter.type] !== 'undefined')) {
                      context$3$0.next = 14;
                      break;
                    }

                    context$3$0.next = 14;
                    return regeneratorRuntime.awrap(callbacks[filter.type](record));

                  case 14:
                    return context$3$0.abrupt('break', 18);

                  case 15:
                    _iteratorNormalCompletion2 = true;
                    context$3$0.next = 5;
                    break;

                  case 18:
                    context$3$0.next = 24;
                    break;

                  case 20:
                    context$3$0.prev = 20;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError2 = true;
                    _iteratorError2 = context$3$0.t0;

                  case 24:
                    context$3$0.prev = 24;
                    context$3$0.prev = 25;

                    if (!_iteratorNormalCompletion2 && _iterator2['return']) {
                      _iterator2['return']();
                    }

                  case 27:
                    context$3$0.prev = 27;

                    if (!_didIteratorError2) {
                      context$3$0.next = 30;
                      break;
                    }

                    throw _iteratorError2;

                  case 30:
                    return context$3$0.finish(27);

                  case 31:
                    return context$3$0.finish(24);

                  case 32:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this3, [[3, 20, 24, 32], [25,, 27, 31]]);
            }, onError));

          case 24:
            return context$2$0.abrupt('return', count);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21]]);
    }
  }]);

  return Filter;
})(_groups.GroupBase);

exports.Filter = Filter;

// return result of filtering
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/groups.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

var Groups = new _meteorMongo.Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

var GroupBase = (function () {
  function GroupBase(profile) {
    _classCallCheck(this, GroupBase);

    this.profile = profile;
  }

  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */

  _createClass(GroupBase, [{
    key: 'getPlug',
    value: function getPlug() {
      return this.profile.platformPlug;
    }
  }, {
    key: 'getProfile',
    value: function getProfile() {
      return this.profile;
    }
  }, {
    key: 'foreach',
    value: function foreach() {
      var _this = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
    }
  }]);

  return GroupBase;
})();

exports.GroupBase = GroupBase;

var Group = (function (_GroupBase) {
  _inherits(Group, _GroupBase);

  function Group(groupId) {
    var _this2 = this;

    _classCallCheck(this, Group);

    var profile = Groups.findOne({
      _id: groupId
    });

    _get(Object.getPrototypeOf(Group.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0(doc) {
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table + ' WHERE `' + doc.key + '` = "' + doc.id + '"';
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.query(sql));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this2);
        };
        break;
      default:
        throw new Error('invalid group type');
    }
  }

  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */

  _createClass(Group, [{
    key: 'foreach',
    value: function foreach() {
      var _this3 = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[1];

      var cur = Groups.find({
        groupId: this.profile._id
      }, {
        fields: {
          _id: 0,
          id: 1,
          key: 1
        }
      });

      return new Promise(function (resolve, reject) {

        cur.forEach(function callee$3$0(doc, index) {
          var record;
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                context$4$0.prev = 0;
                context$4$0.next = 3;
                return regeneratorRuntime.awrap(this['import'](doc));

              case 3:
                record = context$4$0.sent;
                context$4$0.next = 6;
                return regeneratorRuntime.awrap(callback(record));

              case 6:
                context$4$0.next = 11;
                break;

              case 8:
                context$4$0.prev = 8;
                context$4$0.t0 = context$4$0['catch'](0);

                onError(context$4$0.t0);

              case 11:
                if (index + 1 === cur.count()) {
                  resolve();
                }

              case 12:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this3, [[0, 8]]);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }]);

  return Group;
})(GroupBase);

exports.Group = Group;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/cube3api.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _utilSyncObject = require('../util/syncObject');

var _utilSyncObject2 = _interopRequireDefault(_utilSyncObject);

var Cube3Api = (function () {
  /**
   *
   * @param {MySQL} mysql
   */

  function Cube3Api(mysql) {
    _classCallCheck(this, Cube3Api);

    this.mysql = mysql;
  }

  _createClass(Cube3Api, [{
    key: 'modifyCategory',
    value: function modifyCategory(productId, categoryIdArray) {
      var tableCategory, colSrc, sql, colDst, results;
      return regeneratorRuntime.async(function modifyCategory$(context$2$0) {
        var _this = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            tableCategory = 'dtb_product_category';
            colSrc = [];

            categoryIdArray.forEach(function (elem) {
              colSrc.push({
                product_id: productId,
                category_id: elem
              });
            });

            // モールデータベースから現在の商品カテゴリー情報を取得
            sql = '\n    SELECT product_id, category_id\n    FROM ' + tableCategory + '\n    WHERE product_id = ' + productId + '\n    ';
            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.mysql.querySelect(tableCategory, 'product_id = ' + productId, 'product_id, category_id'));

          case 6:
            colDst = context$2$0.sent;
            results = [];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap((0, _utilSyncObject2['default'])(colSrc, colDst, null, function callee$2$0(id, object) {
              var res;
              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    context$3$0.next = 2;
                    return regeneratorRuntime.awrap(this.mysql.queryInsert(tableCategory, {}, Object.assign({ rank: 1 }, object)));

                  case 2:
                    res = context$3$0.sent;

                    results.push(res);

                  case 4:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            }, function callee$2$0(id, object) {
              var res;
              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    context$3$0.next = 2;
                    return regeneratorRuntime.awrap(this.mysql.query('\n          DELETE FROM ' + tableCategory + '\n          WHERE product_id = ' + object.product_id + '\n            AND category_id = ' + object.category_id + '\n          '));

                  case 2:
                    res = context$3$0.sent;

                    results.push(res);

                  case 4:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            }));

          case 10:
            return context$2$0.abrupt('return', results);

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(productClassId) {
      var quantity = arguments.length <= 1 || arguments[1] === undefined ? 0 : arguments[1];
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_class', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              stock_unlimited: 0,
              update_date: 'NOW()'
            }));

          case 2:
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_stock', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              update_date: 'NOW()'
            }));

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productTagUpdate',
    value: function productTagUpdate(data) {
      var creatorId, res, tagoff, tagon, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, tagSet;

      return regeneratorRuntime.async(function productTagUpdate$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = [];

            tagoff = function tagoff(tag) {
              var sql;
              return regeneratorRuntime.async(function tagoff$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      DELETE FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.t0 = res;
                    context$3$0.next = 4;
                    return regeneratorRuntime.awrap(this.mysql.query(sql));

                  case 4:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 6:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2);
            };

            tagon = function tagon(tag) {
              var sql, countRes;
              return regeneratorRuntime.async(function tagon$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      SELECT COUNT(*) FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.next = 3;
                    return regeneratorRuntime.awrap(this.mysql.query(sql));

                  case 3:
                    countRes = context$3$0.sent;

                    if (!countRes[0]['COUNT(*)']) {
                      context$3$0.next = 6;
                      break;
                    }

                    return context$3$0.abrupt('return');

                  case 6:
                    context$3$0.t0 = res;
                    context$3$0.next = 9;
                    return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_tag', {}, {
                      product_id: data.product_id,
                      tag: tag,
                      creator_id: creatorId,
                      create_date: 'NOW()'
                    }));

                  case 9:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 11:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2);
            };

            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 7;
            _iterator = data.tags[Symbol.iterator]();

          case 9:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 23;
              break;
            }

            tagSet = _step.value;
            context$2$0.t0 = tagSet.set;
            context$2$0.next = context$2$0.t0 === 'on' ? 14 : context$2$0.t0 === 'off' ? 17 : 20;
            break;

          case 14:
            context$2$0.next = 16;
            return regeneratorRuntime.awrap(tagon(tagSet.tag));

          case 16:
            return context$2$0.abrupt('break', 20);

          case 17:
            context$2$0.next = 19;
            return regeneratorRuntime.awrap(tagoff(tagSet.tag));

          case 19:
            return context$2$0.abrupt('break', 20);

          case 20:
            _iteratorNormalCompletion = true;
            context$2$0.next = 9;
            break;

          case 23:
            context$2$0.next = 29;
            break;

          case 25:
            context$2$0.prev = 25;
            context$2$0.t1 = context$2$0['catch'](7);
            _didIteratorError = true;
            _iteratorError = context$2$0.t1;

          case 29:
            context$2$0.prev = 29;
            context$2$0.prev = 30;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 32:
            context$2$0.prev = 32;

            if (!_didIteratorError) {
              context$2$0.next = 35;
              break;
            }

            throw _iteratorError;

          case 35:
            return context$2$0.finish(32);

          case 36:
            return context$2$0.finish(29);

          case 37:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 38:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[7, 25, 29, 37], [30,, 32, 36]]);
    }
  }, {
    key: 'productImageUpdate',
    value: function productImageUpdate(data) {
      var productId, images, creatorId, res, sql, i;
      return regeneratorRuntime.async(function productImageUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productId = data.product_id;
            images = data.images;
            creatorId = data.creator_id;
            res = [];
            sql = 'DELETE FROM dtb_product_image WHERE product_id = ' + productId;
            context$2$0.t0 = res;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(this.mysql.query(sql));

          case 8:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t1);
            i = 0;

          case 11:
            if (!(i < images.length)) {
              context$2$0.next = 17;
              break;
            }

            context$2$0.next = 14;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_image', {
              product_id: productId,
              creator_id: creatorId,
              file_name: images[i],
              rank: i + 1
            }, {
              create_date: 'NOW()'
            }));

          case 14:
            i++;
            context$2$0.next = 11;
            break;

          case 17:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productUpdate',
    value: function productUpdate(data) {
      var updateData, keys, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, k, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, res;

      return regeneratorRuntime.async(function productUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            updateData = {};
            keys = [];

            // dtb_product

            keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 6;
            for (_iterator2 = keys[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              if (data[k]) {
                updateData[k] = data[k];
              }
            }

            // [
            //   'status',
            //   'name',
            //   'note',
            //   'description_list',
            //   'description_detail',
            //   'search_word',
            //   'free_area',
            // ].forEach(
            //   (v) => {
            //     if (data[v]) {
            //       updateData[v] = data[v];
            //     }
            //   },
            // );

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError2) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError2;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 24:

            // dtb_product_class

            updateData = {};
            keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 29;
            for (_iterator3 = keys[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 37;
            break;

          case 33:
            context$2$0.prev = 33;
            context$2$0.t1 = context$2$0['catch'](29);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t1;

          case 37:
            context$2$0.prev = 37;
            context$2$0.prev = 38;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 40:
            context$2$0.prev = 40;

            if (!_didIteratorError3) {
              context$2$0.next = 43;
              break;
            }

            throw _iteratorError3;

          case 43:
            return context$2$0.finish(40);

          case 44:
            return context$2$0.finish(37);

          case 45:
            context$2$0.next = 47;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_class', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 47:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 49:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [29, 33, 37, 45], [38,, 40, 44]]);
    }
  }, {
    key: 'productCreate',
    value: function productCreate(data) {
      var creatorId, res, updateData, keys, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, k, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6;

      return regeneratorRuntime.async(function productCreate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = {};
            updateData = {};
            keys = [];

            keys = ['name', 'description_detail'];
            // {
            //   name: item.name,
            //   description_detail: item.description,
            // },

            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 8;
            for (_iterator4 = keys[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 16;
            break;

          case 12:
            context$2$0.prev = 12;
            context$2$0.t0 = context$2$0['catch'](8);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t0;

          case 16:
            context$2$0.prev = 16;
            context$2$0.prev = 17;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 19:
            context$2$0.prev = 19;

            if (!_didIteratorError4) {
              context$2$0.next = 22;
              break;
            }

            throw _iteratorError4;

          case 22:
            return context$2$0.finish(19);

          case 23:
            return context$2$0.finish(16);

          case 24:
            context$2$0.next = 26;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product', updateData, {
              creator_id: creatorId,
              status: 1,
              note: 'NULL',
              description_list: 'NULL',
              search_word: 'NULL',
              free_area: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 26:
            res.product_id = context$2$0.sent;

            updateData = {};
            keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee'];
            // {
            //   product_code: item.model,
            //   price01: item.retail_price,
            //   price02: item.sales_price,
            // },

            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 32;
            for (_iterator5 = keys[Symbol.iterator](); !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
              k = _step5.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 40;
            break;

          case 36:
            context$2$0.prev = 36;
            context$2$0.t1 = context$2$0['catch'](32);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t1;

          case 40:
            context$2$0.prev = 40;
            context$2$0.prev = 41;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 43:
            context$2$0.prev = 43;

            if (!_didIteratorError5) {
              context$2$0.next = 46;
              break;
            }

            throw _iteratorError5;

          case 46:
            return context$2$0.finish(43);

          case 47:
            return context$2$0.finish(40);

          case 48:
            context$2$0.next = 50;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_class', updateData, {
              creator_id: creatorId,
              product_id: res.product_id,
              stock: 0,
              stock_unlimited: 0,
              class_category_id1: 'NULL',
              class_category_id2: 'NULL',
              delivery_date_id: 'NULL',
              sale_limit: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 50:
            res.product_class_id = context$2$0.sent;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 54;

            for (_iterator6 = keys[Symbol.iterator](); !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
              k = _step6.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 62;
            break;

          case 58:
            context$2$0.prev = 58;
            context$2$0.t2 = context$2$0['catch'](54);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t2;

          case 62:
            context$2$0.prev = 62;
            context$2$0.prev = 63;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 65:
            context$2$0.prev = 65;

            if (!_didIteratorError6) {
              context$2$0.next = 68;
              break;
            }

            throw _iteratorError6;

          case 68:
            return context$2$0.finish(65);

          case 69:
            return context$2$0.finish(62);

          case 70:
            context$2$0.next = 72;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_stock', {}, {
              product_class_id: res.product_class_id,
              creator_id: creatorId,
              stock: 0,
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 72:
            res.product_stock_id = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res:

              // for test
              res
            });

          case 74:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 12, 16, 24], [17,, 19, 23], [32, 36, 40, 48], [41,, 43, 47], [54, 58, 62, 70], [63,, 65, 69]]);
    }
  }]);

  return Cube3Api;
})();

exports.Cube3Api = Cube3Api;

// 商品情報データベースに記録された商品カテゴリー情報

// const colDst = JSON.parse(JSON.stringify(await this.mysql.query(sql)));

// 各SQLクエリの結果すべてを記録する

// 削除するタグ

// 表示するタグ

// すでに表示されているタグがあれば何もしない

// 商品に関連するすべての画像情報を削除する

// 改めて画像を登録しなおす
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/dbfilter.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _xmlJs = require('xml-js');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var DBFilterFactory = function DBFilterFactory(plug, profile) {
  _classCallCheck(this, DBFilterFactory);

  var instance = undefined;
  switch (plug.type) {
    case 'mysql':
      instance = new MysqlDBFilter(plug, profile);
  }

  return instance;
};

exports.DBFilterFactory = DBFilterFactory;

var DBFilter = (function () {
  function DBFilter(plug, profile) {
    _classCallCheck(this, DBFilter);

    this.plug = plug;
    this.profile = profile;
  }

  _createClass(DBFilter, [{
    key: 'getPlug_',
    value: function getPlug_() {
      return this.plug;
    }
  }, {
    key: 'getCred_',
    value: function getCred_() {
      return this.plug.cred;
    }
  }, {
    key: 'getProfile_',
    value: function getProfile_() {
      return this.profile;
    }
  }, {
    key: 'setImportFunction_',
    value: function setImportFunction_() {
      var _this = this;

      var fn = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0() {
        var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
        var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];

      this['import'] = fn;
    }

    /**
     * traces members of the group
     * useage:
     *
     *
     * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
     * @param { async function } onError error handler while iterating
     * @returns { Object } { filterName: { query: any, count: number }, ... }
     */
  }, {
    key: 'foreach',
    value: function foreach() {
      var iterators = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      var profile, counter, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, f, filters, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile_();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              name: 'misc',
              query: {}
            });

            counter = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              f = _step.value;
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            filters = [];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 26;

            for (_iterator2 = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              f = _step2.value;

              counter[f.name] = {
                query: f.query,
                limit: typeof f.limit !== 'undefined' ? f.limit : 0,
                count: 0
              };
              filters.push({
                name: f.name,
                exam: (0, _sift2['default'])(_mongoobject2['default'].unescape(f.query))
              });
            }

            context$2$0.next = 34;
            break;

          case 30:
            context$2$0.prev = 30;
            context$2$0.t1 = context$2$0['catch'](26);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 34:
            context$2$0.prev = 34;
            context$2$0.prev = 35;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 37:
            context$2$0.prev = 37;

            if (!_didIteratorError2) {
              context$2$0.next = 40;
              break;
            }

            throw _iteratorError2;

          case 40:
            return context$2$0.finish(37);

          case 41:
            return context$2$0.finish(34);

          case 42:
            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record, context) {
              var _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, f, c;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion3 = true;
                    _didIteratorError3 = false;
                    _iteratorError3 = undefined;
                    context$3$0.prev = 3;
                    _iterator3 = filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
                      context$3$0.next = 20;
                      break;
                    }

                    f = _step3.value;
                    c = counter[f.name];

                    if (!c.limit) {
                      context$3$0.next = 11;
                      break;
                    }

                    if (!(c.count >= c.limit)) {
                      context$3$0.next = 11;
                      break;
                    }

                    return context$3$0.abrupt('continue', 17);

                  case 11:
                    if (!f.exam(record)) {
                      context$3$0.next = 17;
                      break;
                    }

                    // counter limiter
                    c.count++;

                    // iterator

                    if (!(typeof iterators[f.name] !== 'undefined')) {
                      context$3$0.next = 16;
                      break;
                    }

                    context$3$0.next = 16;
                    return regeneratorRuntime.awrap(iterators[f.name](record, context));

                  case 16:
                    return context$3$0.abrupt('break', 20);

                  case 17:
                    _iteratorNormalCompletion3 = true;
                    context$3$0.next = 5;
                    break;

                  case 20:
                    context$3$0.next = 26;
                    break;

                  case 22:
                    context$3$0.prev = 22;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError3 = true;
                    _iteratorError3 = context$3$0.t0;

                  case 26:
                    context$3$0.prev = 26;
                    context$3$0.prev = 27;

                    if (!_iteratorNormalCompletion3 && _iterator3['return']) {
                      _iterator3['return']();
                    }

                  case 29:
                    context$3$0.prev = 29;

                    if (!_didIteratorError3) {
                      context$3$0.next = 32;
                      break;
                    }

                    throw _iteratorError3;

                  case 32:
                    return context$3$0.finish(29);

                  case 33:
                    return context$3$0.finish(26);

                  case 34:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2, [[3, 22, 26, 34], [27,, 29, 33]]);
            }));

          case 44:
            return context$2$0.abrupt('return', counter);

          case 45:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [26, 30, 34, 42], [35,, 37, 41]]);
    }
  }], [{
    key: 'factory',
    value: function factory(plug, profile) {
      switch (plug.type) {
        case 'mysql':
          return new MysqlDBFilter(plug, profile);
        default:
          throw new Error('invalid plug type');
      }
    }
  }]);

  return DBFilter;
})();

exports.DBFilter = DBFilter;

var MysqlDBFilter = (function (_DBFilter) {
  _inherits(MysqlDBFilter, _DBFilter);

  function MysqlDBFilter(plug, profile) {
    var _this3 = this;

    _classCallCheck(this, MysqlDBFilter);

    _get(Object.getPrototypeOf(MysqlDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    var cred = this.getCred_();

    this.mysql = new _utilMysql2['default'](cred);
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var sql, res;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            sql = 'SELECT * FROM ' + plug.table;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, function (e) {
              throw e;
            }));

          case 3:
            res = context$3$0.sent;
            return context$3$0.abrupt('return', res);

          case 5:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this3);
    });
  }

  // import MongoNative from 'mongodb';
  // const MongoClient = MongoNative.MongoClient;
  // const MongoClient = require('mongodb').MongoClient;

  return MysqlDBFilter;
})(DBFilter);

exports.MysqlDBFilter = MysqlDBFilter;

var MongoDBFilter = (function (_DBFilter2) {
  _inherits(MongoDBFilter, _DBFilter2);

  function MongoDBFilter(plug, profile) {
    var _this4 = this;

    _classCallCheck(this, MongoDBFilter);

    _get(Object.getPrototypeOf(MongoDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    // mongo へ接続
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var client, db, collection, context, cur, doc;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            client = undefined;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri, { useNewUrlParser: true }));

          case 3:
            client = context$3$0.sent;
            db = client.db(plug.database);
            collection = db.collection(plug.collection);
            context = {
              client: client,
              collection: collection,
              database: db
            };
            cur = collection.find();

            // カーソルのタイムアウトを解除
            cur.addCursorFlag('noCursorTimeout', true);

            // すべてのドキュメントをループ
            context$3$0.prev = 9;

          case 10:
            context$3$0.next = 12;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 12:
            if (!context$3$0.sent) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 15;
            return regeneratorRuntime.awrap(cur.next());

          case 15:
            doc = context$3$0.sent;
            context$3$0.next = 18;
            return regeneratorRuntime.awrap(onResult(doc, context));

          case 18:
            context$3$0.next = 10;
            break;

          case 20:
            context$3$0.prev = 20;
            context$3$0.next = 23;
            return regeneratorRuntime.awrap(cur.close());

          case 23:
            return context$3$0.finish(20);

          case 24:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this4, [[9,, 20, 24]]);
    });
  }

  return MongoDBFilter;
})(DBFilter);

exports.MongoDBFilter = MongoDBFilter;

var WowmaApiItemFilter = (function (_DBFilter3) {
  _inherits(WowmaApiItemFilter, _DBFilter3);

  function WowmaApiItemFilter(plug, profile) {
    var _this5 = this;

    _classCallCheck(this, WowmaApiItemFilter);

    _get(Object.getPrototypeOf(WowmaApiItemFilter.prototype), 'constructor', this).call(this, plug, profile);

    // 商品情報の取得ループを定義
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var options, context, res, maxCount, resultCount, startCount, resultStocks, i, next;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            options = JSON.parse(JSON.stringify(plug));

            options.uri = options.uri + '/searchStocks';
            context = {
              options: options
            };

          case 3:
            if (!1) {
              context$3$0.next = 30;
              break;
            }

            context$3$0.next = 6;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

          case 6:
            res = context$3$0.sent;

            res = (0, _xmlJs.xml2js)(res, { compact: true });

            maxCount = Number(res.response.searchResult.maxCount._text);
            resultCount = Number(res.response.searchResult.resultCount._text);
            startCount = Number(res.response.searchResult.startCount._text);
            resultStocks = res.response.searchResult.resultStocks;

            if (!(resultStocks instanceof Array)) {
              context$3$0.next = 22;
              break;
            }

            i = 0;

          case 14:
            if (!(i < resultCount)) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 17;
            return regeneratorRuntime.awrap(onResult(resultStocks[i], context));

          case 17:
            i++;
            context$3$0.next = 14;
            break;

          case 20:
            context$3$0.next = 24;
            break;

          case 22:
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(onResult(resultStocks, context));

          case 24:
            next = startCount + resultCount;

            if (!(next > maxCount)) {
              context$3$0.next = 27;
              break;
            }

            return context$3$0.abrupt('break', 30);

          case 27:
            options.qs.startCount = next;
            context$3$0.next = 3;
            break;

          case 30:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this5);
    });
  }

  // import mongoose from 'mongoose';

  // export class MongoDBFilter extends DBFilter {
  //   constructor(plug, profile) {
  //     super(plug, profile);

  //     // mongo へ接続
  //     let cred = this.getCred_();
  //     let conuri = `mongodb://${cred.host}:${cred.port}/${cred.database}`;
  //     await mongoose.connect(conuri);

  //     // コレクションを作る
  //     let collection = mongoose.connection.collection(plug.collection);

  //     this.setImportFunction_(async (onResult, onError) => {
  //       let cur = collection.find();

  //       return await this.mysql.streamingQuery(sql, onResult, onError);
  //     });
  //   }
  // }
  return WowmaApiItemFilter;
})(DBFilter);

exports.WowmaApiItemFilter = WowmaApiItemFilter;

// counter limiter

// return result of filtering

// コレクションを取得

// カーソルを開放

// コレクションを取得

// Wowma Api から商品情報を取得

// 取得した商品情報をカスタムプロセスに渡す

// 取得したデータが複数商品の場合

// 取得したデータが単数商品の場合
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/items.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMongo = require('../util/mongo');

var _collections = require('../collections');

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var ItemController = (function () {
  function ItemController() {
    _classCallCheck(this, ItemController);
  }

  _createClass(ItemController, [{
    key: 'init',

    /**
     *
     * @param {{uri:string, database:string, collection:string}} plug
     */
    value: function init(plug) {
      return regeneratorRuntime.async(function init$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'items'));

          case 2:
            this.Items = context$2$0.sent;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'products'));

          case 5:
            this.Products = context$2$0.sent;

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'getStock',
    value: function getStock(itemId) {
      var item, productSet, quantities, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, productRef, prdQuantity, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, id, product, stockArray, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, stock, quantity;

      return regeneratorRuntime.async(function getStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.Items.findOne({
              _id: itemId
            }, {
              projection: {
                product: 1
              }
            }));

          case 2:
            item = context$2$0.sent;
            productSet = item.product;
            quantities = [];
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 8;
            _iterator = productSet[Symbol.iterator]();

          case 10:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 64;
              break;
            }

            productRef = _step.value;
            prdQuantity = 0;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 16;
            _iterator2 = productRef.ids[Symbol.iterator]();

          case 18:
            if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
              context$2$0.next = 46;
              break;
            }

            id = _step2.value;
            context$2$0.next = 22;
            return regeneratorRuntime.awrap(this.Products.findOne({
              _id: id
            }, {
              projection: {
                stock: 1
              }
            }));

          case 22:
            product = context$2$0.sent;
            stockArray = product.stock;
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 27;

            // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算
            for (_iterator3 = stockArray[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              stock = _step3.value;
              prdQuantity += stock.quantity;
            }context$2$0.next = 35;
            break;

          case 31:
            context$2$0.prev = 31;
            context$2$0.t0 = context$2$0['catch'](27);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 35:
            context$2$0.prev = 35;
            context$2$0.prev = 36;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 38:
            context$2$0.prev = 38;

            if (!_didIteratorError3) {
              context$2$0.next = 41;
              break;
            }

            throw _iteratorError3;

          case 41:
            return context$2$0.finish(38);

          case 42:
            return context$2$0.finish(35);

          case 43:
            _iteratorNormalCompletion2 = true;
            context$2$0.next = 18;
            break;

          case 46:
            context$2$0.next = 52;
            break;

          case 48:
            context$2$0.prev = 48;
            context$2$0.t1 = context$2$0['catch'](16);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 52:
            context$2$0.prev = 52;
            context$2$0.prev = 53;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 55:
            context$2$0.prev = 55;

            if (!_didIteratorError2) {
              context$2$0.next = 58;
              break;
            }

            throw _iteratorError2;

          case 58:
            return context$2$0.finish(55);

          case 59:
            return context$2$0.finish(52);

          case 60:

            // 商品(item)の在庫数 = 製品在庫数(prdQuantity) / 必要セット数(productRef.set)
            quantities.push(Math.floor(prdQuantity / productRef.set));

          case 61:
            _iteratorNormalCompletion = true;
            context$2$0.next = 10;
            break;

          case 64:
            context$2$0.next = 70;
            break;

          case 66:
            context$2$0.prev = 66;
            context$2$0.t2 = context$2$0['catch'](8);
            _didIteratorError = true;
            _iteratorError = context$2$0.t2;

          case 70:
            context$2$0.prev = 70;
            context$2$0.prev = 71;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 73:
            context$2$0.prev = 73;

            if (!_didIteratorError) {
              context$2$0.next = 76;
              break;
            }

            throw _iteratorError;

          case 76:
            return context$2$0.finish(73);

          case 77:
            return context$2$0.finish(70);

          case 78:
            quantity = Math.min.apply(null, quantities);
            return context$2$0.abrupt('return', quantity);

          case 80:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 66, 70, 78], [16, 48, 52, 60], [27, 31, 35, 43], [36,, 38, 42], [53,, 55, 59], [71,, 73, 77]]);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに、
     * アップロード済み画像を関連付ける。
     *
     * メーカーモデルに共通の画像を一括で関連付けたい場合、
     * class1、class2引数を指定せずに実行する。
     *
     * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
     * class1に値を指定し、class2引数を指定せずに実行する。
     * もしclass2のみ指定したい場合はclass1にnullを指定する。
     *
     * 例：JK-100のBLACKの商品画像を
     * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
     * setImage( uploadId, 'JK-100', 'BLACK' );
     *
     * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'setImage',
    value: function setImage(uploadId, model) {
      var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
      var images, filter, res;
      return regeneratorRuntime.async(function setImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            images = _collections.Uploads.find({
              uploadId: uploadId
            }).fetch().map(function (v) {
              return v.uploadedFileName;
            });
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $push: {
                images: {
                  $each: images
                }
              }
            }));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', images);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
     *
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'cleanImage',
    value: function cleanImage(model) {
      var class1 = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
      var class2 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var filter, res;
      return regeneratorRuntime.async(function cleanImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $set: {
                images: []
              }
            }));

          case 6:
            res = context$2$0.sent;

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * 指定の商品に関連する商品群の属性別の商品情報を返す。
     *
     * 引数として受け取るitemは任意の商品情報。
     * itemに関連する商品群について必要な情報を整理し返す。
     *
     * projectに参照したい商品情報フィールドを定義する。
     * メソッドの呼び出し時に必要に応じてprojectを設定する。
     *
     * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
     *
     * @param {Object} item
     * @param {Object} project
     */
  }, {
    key: 'getVariation',
    value: function getVariation(item, project) {
      var set, attrs, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, s, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, attr, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6, v;

      return regeneratorRuntime.async(function getVariation$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            set = [{
              label: '配送方法',
              current: item.delivery,
              project: {
                value: '$delivery'
              },
              query: {
                class1_value: item.class1_value,
                class2_value: item.class2_value
              }
            }, {
              label: item.class1_name,
              current: item.class1_value,
              project: {
                value: '$class1_value'
              },
              query: {
                delivery: item.delivery,
                class2_value: item.class2_value
              }
            }, {
              label: item.class2_name,
              current: item.class2_value,
              project: {
                value: '$class2_value'
              },
              query: {
                delivery: item.delivery,
                class1_value: item.class1_value
              }
            }];
            attrs = [];
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 5;
            _iterator4 = set[Symbol.iterator]();

          case 7:
            if (_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done) {
              context$2$0.next = 19;
              break;
            }

            s = _step4.value;
            context$2$0.t0 = attrs;
            context$2$0.next = 12;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: Object.assign(s.query, {
                model: item.model
              })
            }, {
              $project: Object.assign(s.project, project)
            }, {
              $sort: {
                _id: 1
              }
            }]).toArray());

          case 12:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = s;
            context$2$0.t3 = {
              variations: context$2$0.t1,
              props: context$2$0.t2
            };
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t3);

          case 16:
            _iteratorNormalCompletion4 = true;
            context$2$0.next = 7;
            break;

          case 19:
            context$2$0.next = 25;
            break;

          case 21:
            context$2$0.prev = 21;
            context$2$0.t4 = context$2$0['catch'](5);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t4;

          case 25:
            context$2$0.prev = 25;
            context$2$0.prev = 26;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 28:
            context$2$0.prev = 28;

            if (!_didIteratorError4) {
              context$2$0.next = 31;
              break;
            }

            throw _iteratorError4;

          case 31:
            return context$2$0.finish(28);

          case 32:
            return context$2$0.finish(25);

          case 33:
            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 36;
            _iterator5 = attrs[Symbol.iterator]();

          case 38:
            if (_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done) {
              context$2$0.next = 70;
              break;
            }

            attr = _step5.value;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 43;
            _iterator6 = attr.variations[Symbol.iterator]();

          case 45:
            if (_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done) {
              context$2$0.next = 53;
              break;
            }

            v = _step6.value;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.getStock(v._id));

          case 49:
            v.stock = context$2$0.sent;

          case 50:
            _iteratorNormalCompletion6 = true;
            context$2$0.next = 45;
            break;

          case 53:
            context$2$0.next = 59;
            break;

          case 55:
            context$2$0.prev = 55;
            context$2$0.t5 = context$2$0['catch'](43);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t5;

          case 59:
            context$2$0.prev = 59;
            context$2$0.prev = 60;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 62:
            context$2$0.prev = 62;

            if (!_didIteratorError6) {
              context$2$0.next = 65;
              break;
            }

            throw _iteratorError6;

          case 65:
            return context$2$0.finish(62);

          case 66:
            return context$2$0.finish(59);

          case 67:
            _iteratorNormalCompletion5 = true;
            context$2$0.next = 38;
            break;

          case 70:
            context$2$0.next = 76;
            break;

          case 72:
            context$2$0.prev = 72;
            context$2$0.t6 = context$2$0['catch'](36);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t6;

          case 76:
            context$2$0.prev = 76;
            context$2$0.prev = 77;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 79:
            context$2$0.prev = 79;

            if (!_didIteratorError5) {
              context$2$0.next = 82;
              break;
            }

            throw _iteratorError5;

          case 82:
            return context$2$0.finish(79);

          case 83:
            return context$2$0.finish(76);

          case 84:
            return context$2$0.abrupt('return', attrs);

          case 85:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 21, 25, 33], [26,, 28, 32], [36, 72, 76, 84], [43, 55, 59, 67], [60,, 62, 66], [77,, 79, 83]]);
    }

    // モデルクラス形式を作る
    // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
  }, {
    key: 'getModelClass',
    value: function getModelClass(arg) {
      var item, exp, cur, match, modelClass;
      return regeneratorRuntime.async(function getModelClass$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            item = undefined;

            if (!(typeof arg === 'string')) {
              context$2$0.next = 25;
              break;
            }

            exp = new RegExp(arg + '$');
            cur = this.Items.find({}, {
              projection: {
                model: 1,
                class1_value: 1,
                class2_value: 1
              }
            });

          case 4:
            if (!1) {
              context$2$0.next = 22;
              break;
            }

            context$2$0.prev = 5;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(cur.next());

          case 8:
            item = context$2$0.sent;
            context$2$0.next = 11;
            return regeneratorRuntime.awrap(item._id.toHexString().match(exp));

          case 11:
            match = context$2$0.sent;

            if (!match) {
              context$2$0.next = 14;
              break;
            }

            return context$2$0.abrupt('break', 22);

          case 14:
            context$2$0.next = 20;
            break;

          case 16:
            context$2$0.prev = 16;
            context$2$0.t0 = context$2$0['catch'](5);

            // 該当するitemデータがない
            cur.close();
            return context$2$0.abrupt('return', arg);

          case 20:
            context$2$0.next = 4;
            break;

          case 22:
            cur.close();
            context$2$0.next = 26;
            break;

          case 25:
            item = arg;

          case 26:
            modelClass = [];

            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);
            return context$2$0.abrupt('return', modelClass.join('/'));

          case 31:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 16]]);
    }
  }, {
    key: 'convertItemCube3',
    value: function convertItemCube3(configUploadItem, item) {
      var convDeliv, productId, modelClass, productTypeId, tags, deliveryFee, attrs, variationHtml, descriptionDetail, data;
      return regeneratorRuntime.async(function convertItemCube3$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            convDeliv = function convDeliv(delivery) {
              return delivery === 'ゆうパケット' ? 'ポスト投函' : delivery;
            };

            productId = null;
            modelClass = [];

            // 下記の形式を作る
            // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);

            // 商品種別を割り当てる
            productTypeId = undefined;
            context$2$0.t0 = item.delivery;
            context$2$0.next = context$2$0.t0 === '宅配便' ? 10 : context$2$0.t0 === 'ゆうパケット' ? 12 : context$2$0.t0 === '宅急便コンパクト' ? 14 : context$2$0.t0 === '宅配便送料無料' ? 16 : 18;
            break;

          case 10:
            productTypeId = 1;
            return context$2$0.abrupt('break', 20);

          case 12:
            productTypeId = 2;
            return context$2$0.abrupt('break', 20);

          case 14:
            productTypeId = 3;
            return context$2$0.abrupt('break', 20);

          case 16:
            productTypeId = 4;
            return context$2$0.abrupt('break', 20);

          case 18:
            productTypeId = 1;
            return context$2$0.abrupt('break', 20);

          case 20:
            tags = [{ tag: 4, set: 'off' }, { tag: 5, set: 'off' }, { tag: 6, set: 'off' }, { tag: 7, set: 'off' }];
            context$2$0.t1 = item.delivery;
            context$2$0.next = context$2$0.t1 === '宅配便' ? 24 : context$2$0.t1 === 'ゆうパケット' ? 26 : context$2$0.t1 === '宅急便コンパクト' ? 28 : context$2$0.t1 === '宅配便送料無料' ? 30 : 32;
            break;

          case 24:
            tags.find(function (e) {
              return e.tag === 4;
            }).set = 'on';
            return context$2$0.abrupt('break', 33);

          case 26:
            tags.find(function (e) {
              return e.tag === 5;
            }).set = 'on';
            return context$2$0.abrupt('break', 33);

          case 28:
            tags.find(function (e) {
              return e.tag === 6;
            }).set = 'on';
            return context$2$0.abrupt('break', 33);

          case 30:
            tags.find(function (e) {
              return e.tag === 7;
            }).set = 'on';
            return context$2$0.abrupt('break', 33);

          case 32:
            return context$2$0.abrupt('break', 33);

          case 33:
            deliveryFee = null;
            context$2$0.t2 = item.delivery;
            context$2$0.next = context$2$0.t2 === 'ゆうパケット' ? 37 : 39;
            break;

          case 37:
            deliveryFee = configUploadItem.mailboxFee;
            return context$2$0.abrupt('break', 41);

          case 39:
            deliveryFee = null;
            return context$2$0.abrupt('break', 41);

          case 41:
            context$2$0.next = 43;
            return regeneratorRuntime.awrap(this.getVariation(item, {
              product_id: '$mall.sharakuShop.product_id'
            }));

          case 43:
            attrs = context$2$0.sent;

            // HTML バリエーション商品ごとのリンク付きボタンを表示する

            // 値の変換
            attrs = attrs.map(function (attr) {
              attr.props.current = convDeliv(attr.props.current);
              attr.variations = attr.variations.map(function (variation) {
                variation.value = convDeliv(variation.value);
                return variation;
              });
              return attr;
            });

            // HTML生成
            variationHtml = attrs.map(function (attr) {
              return '' + ('<div class="container-fluid">' + '<div class="row">' + '<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">' + ('<strong>' + attr.props.label + '</strong>') + '</div>') + attr.variations.map(function (variation) {
                if (attr.props.current === variation.value) {
                  // 表示中の商品ボタン
                  return '<button class="btn btn-success btn-sm btn-item-class-select"><strong>' + variation.value + '</strong></button>';
                }if (variation.stock > 0) {
                  // 販売可能商品のボタン
                  return '<a href="/products/detail/' + variation.product_id + '"><button class="btn btn-default btn-sm btn-item-class-select">' + variation.value + '</button></a>';
                }
                // 販売不可能商品のボタン（在庫なし）
                return '<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">' + variation.value + '</button>';
              }).join('') + '</div>' + '</div>';
            }).join('');
            descriptionDetail = '\n    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>\n    ' + variationHtml + '\n    ';
            data = {
              product_id: productId,
              creator_id: configUploadItem.creator_id,
              name: modelClass.join('/') + ' ' + convDeliv(item.delivery) + ' ' + item.name + (item.jan_code ? ' ' + item.jan_code : ''),
              description_detail: descriptionDetail,
              // free_area: await this.convertItemCube3createFreeArea(item),
              product_code: modelClass.join('/'),
              price01: item.retail_price,
              // price02: await this.convertItemCube3createPrice02(item),
              // images: await this.convertItemCube3createImages(item),
              product_type_id: productTypeId,
              tags: tags,
              delivery_fee: deliveryFee
            };
            context$2$0.t3 = Object;
            context$2$0.t4 = data;
            context$2$0.next = 52;
            return regeneratorRuntime.awrap(this.convertItemCube3createFreeArea(configUploadItem, item));

          case 52:
            context$2$0.t5 = context$2$0.sent;
            context$2$0.t3.assign.call(context$2$0.t3, context$2$0.t4, context$2$0.t5);
            context$2$0.t6 = Object;
            context$2$0.t7 = data;
            context$2$0.next = 58;
            return regeneratorRuntime.awrap(this.convertItemCube3createPrice02(configUploadItem, item));

          case 58:
            context$2$0.t8 = context$2$0.sent;
            context$2$0.t6.assign.call(context$2$0.t6, context$2$0.t7, context$2$0.t8);
            context$2$0.t9 = Object;
            context$2$0.t10 = data;
            context$2$0.next = 64;
            return regeneratorRuntime.awrap(this.convertItemCube3createImages(configUploadItem, item));

          case 64:
            context$2$0.t11 = context$2$0.sent;
            context$2$0.t9.assign.call(context$2$0.t9, context$2$0.t10, context$2$0.t11);

            Object.assign(data, item.mall.sharakuShop);

            return context$2$0.abrupt('return', data);

          case 68:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createFreeArea',
    value: function convertItemCube3createFreeArea(configUploadItem, item) {
      var freeArea, i;
      return regeneratorRuntime.async(function convertItemCube3createFreeArea$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            freeArea = '';

            // 商品情報テキストを記載する
            freeArea += item.description + '<br>';
            // 2番目以降の画像をフリーエリアに記載する
            for (i = 1; i < item.images.length; i++) {
              freeArea += '<img src="/upload/save_image/' + item.images[i] + '"><br>';
            }return context$2$0.abrupt('return', { free_area: freeArea });

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createPrice02',
    value: function convertItemCube3createPrice02(configUploadItem, item) {
      return regeneratorRuntime.async(function convertItemCube3createPrice02$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            return context$2$0.abrupt('return', { price02: item.mall.sharakuShop.price });

          case 1:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createImages',
    value: function convertItemCube3createImages(configUploadItem, item) {
      var arr;
      return regeneratorRuntime.async(function convertItemCube3createImages$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            arr = typeof item.images[0] === 'undefined' ? [] : [item.images[0]];
            return context$2$0.abrupt('return', { images: arr });

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct1',
    value: function convertItemYauct1(config, item) {
      var res;
      return regeneratorRuntime.async(function convertItemYauct1$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.convertItemYauct(config['default'], item));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct',
    value: function convertItemYauct(def, item) {
      var idLength, titleLength, yauct, imgPrefix, i;
      return regeneratorRuntime.async(function convertItemYauct$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            idLength = 20;
            titleLength = 130;
            yauct = {};

            // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）
            yauct = JSON.parse(JSON.stringify(def[item.delivery]));

            // 画像の記述
            imgPrefix = '画像';

            for (i = 0; i < item.images.length; i++) {
              yauct[imgPrefix + (i + 1)] = item.images[i];
            } // タイトル
            yauct['カテゴリ'] = item.mall.yauct.category;
            context$2$0.t0 = _utilText2['default'];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap(this.getModelClass(item));

          case 10:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = context$2$0.t1 + ' ';
            context$2$0.t3 = item.delivery;
            context$2$0.t4 = context$2$0.t2 + context$2$0.t3;
            context$2$0.t5 = context$2$0.t4 + ' ';
            context$2$0.t6 = item.name;
            context$2$0.t7 = context$2$0.t5 + context$2$0.t6;
            context$2$0.t8 = titleLength;
            yauct['タイトル'] = context$2$0.t0.substr8.call(context$2$0.t0, context$2$0.t7, context$2$0.t8);

            yauct['開始価格'] = item.sales_price;
            yauct['即決価格'] = item.sales_price;
            yauct['管理番号'] = item._id.toHexString().slice(-idLength);
            if (typeof yauct['説明'] === 'string') yauct['説明'] = item.description + '<br><br>' + yauct['説明'];else yauct['説明'] = item.description;

            yauct['JANコード・ISBNコード'] = item.jan_code;

            return context$2$0.abrupt('return', yauct);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemWowmaCreateDeliveryMethod',
    value: function convertItemWowmaCreateDeliveryMethod(itemCode) {
      var id, set, metrics, aggr, acceptDeliv, _iteratorNormalCompletion7, _didIteratorError7, _iteratorError7, _iterator7, _step7, del, deliveryMethod, i, _id;

      return regeneratorRuntime.async(function convertItemWowmaCreateDeliveryMethod$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            id = 'mall.wowma.itemCode';
            set = 'delivery';
            metrics = {
              ゆうパケット: ['Post'],
              宅配便: ['YU-Pack', 'Kangaroo']
            };
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: _defineProperty({}, id, itemCode)
            }, {
              $group: _defineProperty({
                _id: '$' + id
              }, set, { $addToSet: '$' + set })
            }, {
              $project: _defineProperty({
                _id: 0,
                itemCode: '$_id'
              }, set, '$' + set)
            }]).toArray());

          case 5:
            aggr = context$2$0.sent;
            acceptDeliv = [];
            _iteratorNormalCompletion7 = true;
            _didIteratorError7 = false;
            _iteratorError7 = undefined;
            context$2$0.prev = 10;

            for (_iterator7 = aggr[0].delivery[Symbol.iterator](); !(_iteratorNormalCompletion7 = (_step7 = _iterator7.next()).done); _iteratorNormalCompletion7 = true) {
              del = _step7.value;
              acceptDeliv = acceptDeliv.concat(metrics['' + del]);
            }context$2$0.next = 18;
            break;

          case 14:
            context$2$0.prev = 14;
            context$2$0.t0 = context$2$0['catch'](10);
            _didIteratorError7 = true;
            _iteratorError7 = context$2$0.t0;

          case 18:
            context$2$0.prev = 18;
            context$2$0.prev = 19;

            if (!_iteratorNormalCompletion7 && _iterator7['return']) {
              _iterator7['return']();
            }

          case 21:
            context$2$0.prev = 21;

            if (!_didIteratorError7) {
              context$2$0.next = 24;
              break;
            }

            throw _iteratorError7;

          case 24:
            return context$2$0.finish(21);

          case 25:
            return context$2$0.finish(18);

          case 26:
            deliveryMethod = new Array(5);

            for (i = 0; i < deliveryMethod.length; i++) {
              _id = typeof acceptDeliv[i] === 'undefined' ? 'NULL' : acceptDeliv[i];

              deliveryMethod[i] = { deliveryMethodSeq: i + 1, deliveryMethodId: _id };
            }

            return context$2$0.abrupt('return', { deliveryMethod: deliveryMethod });

          case 29:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[10, 14, 18, 26], [19,, 21, 25]]);
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その1 item.csv

  }], [{
    key: 'convertItemRobotinItem',
    value: function convertItemRobotinItem(item) {
      return {
        コントロールカラム: 'n',
        新規登録ID: item._id.toHexString(),
        商品ID: null,
        商品名: '' + item.model + (item.class1_value === '' ? '' : '/' + item.class1_value) + (item.class2_value === '' ? '' : '/' + item.class2_value),
        規格: 'なし'
      };
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その2 select.csv

  }, {
    key: 'convertItemRobotinSelect',
    value: function convertItemRobotinSelect(item) {
      var select = {
        コントロールカラム: 'n',
        新規登録ID: item._id.toHexString(),
        商品ID: null,
        外部連携ID: null,
        外部連携商品番号: item._id.toHexString()
      };

      var shops = _collections.RobotinShop.find();

      shops.forEach(function (doc, index) {
        var model = undefined;
        var class1 = undefined;
        var class2 = undefined;
        try {
          // モールの商品番号を特定する
          model = item.mall['' + doc.name]['' + doc.modelPath];
          model = typeof model === 'undefined' ? '' : model;
          class1 = item.mall['' + doc.name]['' + doc.class1Path];
          class1 = typeof class1 === 'undefined' ? '' : class1;
          class2 = item.mall['' + doc.name]['' + doc.class2Path];
          class2 = typeof class2 === 'undefined' ? '' : class2;
        } catch (e) {
          // 商品のモール情報の取得に失敗した（データが設定されていないなど）
          // model = item.model
          // class1 = item.class1_value
          // class2 = item.class2_value
          return;
        }

        select['受注商品ID_' + index] = null;
        select['店舗ID_' + index] = doc['店舗ID'];
        select['店舗名_' + index] = doc.name;
        select['受注商品番号_' + index] = '' + model + class1 + class2;
        select['有効フラグ_' + index] = '有効';
      });

      return select;
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その3 selectShop.csv

  }, {
    key: 'convertItemRobotinSelectShop',
    value: function convertItemRobotinSelectShop(shop, item) {
      var model = item.mall['' + shop.name]['' + shop.modelPath];
      var class1 = item.mall['' + shop.name]['' + shop.class1Path];
      var class2 = item.mall['' + shop.name]['' + shop.class2Path];

      return {
        コントロールカラム: 'u',
        新規登録ID: item._id.toHexString(),
        受注商品ID: null,
        店舗ID: shop['店舗ID'],
        店舗名: null,
        受注商品番号: '' + model + class1 + class2,
        有効フラグ: '有効'
      };
    }
  }]);

  return ItemController;
})();

exports['default'] = ItemController;
module.exports = exports['default'];

// product * <-> * item
// product[]: 複数の商品を1パッケージとして販売
// product[{ids:[<ObjectId>],set:<Number>}]: 異なる流通経路、異なる原価・仕入れ値
// item: 異なるセール、販売形態
// ※ product からは、販売可能な在庫、利益計算のための情報を得る

// セット商品の場合、一番少ない商品数に合わせる

// アップロード済み画像の情報取得

// 検索条件の組み立て

// 登録した画像ファイル名一覧

// 検索条件の組み立て

/**
 * aggregation設定
 *
 * label: 属性名（配送方法、カラー、サイズなど）
 * current: 指定されたアイテム（item）が該当する項目
 * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
 * query: aggregation対象とするドキュメントの検索条件
 */

// item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

// 値変換

// product_id

// 商品タグを設定する

// 商品別送料を設定する

//
// 顧客向けバリエーション商品選択機能の実装
//

// 商品データを作る

// 価格を返す

// 画像リストのうち1つめだけを返す

// deliveryMethodSeq
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/robotin.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _bson = require('bson');

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var _items = require('./items');

var _items2 = _interopRequireDefault(_items);

var _collections = require('../collections');

var Robotin = (function () {
  function Robotin() {
    _classCallCheck(this, Robotin);

    // importOrderTemp に関連
    // 受発注システムでは処理できない例外的受注処理に対して
    // 個別の送り状発行などを行う
    this.Order = new _meteorMongo.Mongo.Collection(null);
  }

  _createClass(Robotin, [{
    key: 'importOrderTemp',

    /**
     *
     * @param {*} docOrder
     * @param {ItemController} itemS
     */
    value: function importOrderTemp(docOrder, itemS) {
      // 受注データをデータベースに保存
      this.Order.insert({ robotin: docOrder });
    }

    /**
     *
     * @param {*} docOrder
     * @param {ItemController} itemCon
     */
  }, {
    key: 'transformLabelSeino',

    /**
     *
     * @param {*} docLabel
     * @param {Array} writeItemCodeTo
     */
    value: function transformLabelSeino(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      //

      // 受注番号を抽出
      var orderNumber = docLabel[32]; // 33番目の項目「記事１」

      // // 受注CSVから店舗名と受注番号をキーに商品コード一覧を取得する
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel[11], // 12番目の項目「荷送人名称」
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });

      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel[11], // 12番目の項目「荷送人名称」
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      // // 送り状レコードに該当する受注レコードが見つからない場合
      // if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');

      // // 送り状の発送商品コード一覧を配列にする
      // const items = cur.fetch();

      // docLabel : 入力送り状データ
      // conLabel : 出力用送り状データ
      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // writeItemCodeTo （一つの送り状に記載できる商品コードの最大数）の総数より、受注データの商品数が多い場合はエラー
      var writeItemCodeTo = labelOptions.writeItemCodeTo;
      if (writeItemCodeTo.length < items.length) throw new Error('送り状データに記載できる商品数は' + writeItemCodeTo.length + '個までです');

      // 定数の埋め込み
      labelOptions['const'].forEach(function (e) {
        conLabel[e.column] = e.value;
      });

      // 送り状データに商品コードを記録する
      writeItemCodeTo.forEach(function (e, i) {
        if (items[i]) {
          conLabel[e] = items[i];
        } else {
          // 送り状の商品コード欄はすべて埋める
          // これにより列の欠落を防ぐ
          conLabel[e] = '';
        }
      });

      // 住所文字列の分割を修正する
      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      // TextUtil.splitlenb(conLabel, [12, 13], 40); // 項目13「荷送人住所１」、項目14「荷送人住所２」
      // TextUtil.splitlenb(conLabel, [21, 22], 60); // 項目22「お届け先住所１」、項目23「お届け先住所２」

      return conLabel;
    }

    /**
     *
     * @param {*} docLabel
     * @param {Array} writeItemCodeTo
     */
  }, {
    key: 'transformLabelYupack',
    value: function transformLabelYupack(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      //

      // 受注番号を抽出
      var orderNumber = docLabel['記事名１'].replace('受注番号：', '');

      // // 受注CSVから店舗名と受注番号をキーに商品コード一覧を取得する
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel['ご依頼主 名称1'],
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });

      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel['ご依頼主 名称1'],
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      // docLabel : 入力送り状データ
      // conLabel : 出力用送り状データ
      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // writeItemCodeTo （一つの送り状に記載できる商品コードの最大数）の総数より、受注データの商品数が多い場合はエラー
      var writeItemCodeTo = labelOptions.writeItemCodeTo;
      if (writeItemCodeTo.length < items.length) throw new Error('送り状データに記載できる商品数は' + writeItemCodeTo.length + '個までです');

      // 送り状データに商品コードを記録する
      writeItemCodeTo.forEach(function (e, i) {
        if (items[i]) {
          conLabel[e] = items[i];
        } else {
          // 送り状の商品コード欄はすべて埋める
          // これにより列の欠落を防ぐ
          conLabel[e] = '';
        }
      });

      // 送り状種別を設定
      conLabel['送り状種別'] = labelOptions.labelId;

      // 住所文字列の分割を修正する
      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // // length（バイト長）を超える文字列は、半角スペースで分割する
      // TextUtil.splitlenb(conLabel, ['ご依頼主 住所1', 'ご依頼主 住所2', 'ご依頼主 住所3'], 50);
      // TextUtil.splitlenb(conLabel, ['お届け先 住所1', 'お届け先 住所2', 'お届け先 住所3'], 50);
      return conLabel;
    }
  }, {
    key: 'transformLabelYupacket',
    value: function transformLabelYupacket(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      var orderNumber = docLabel['記事名１'].replace('受注番号：', '');
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel['ご依頼主 名称1'],
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });
      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel['ご依頼主 名称1'],
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // 送り状種別を設定
      conLabel['送り状種別'] = labelOptions.labelId;

      conLabel['記事名１'] = items[0];
      conLabel['フリー項目０１'] = items[1];
      conLabel['フリー項目０５'] = items[2];

      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      // TextUtil.splitlenb(conLabel, ['ご依頼主 住所1', 'ご依頼主 住所2', 'ご依頼主 住所3'], 50);
      // TextUtil.splitlenb(conLabel, ['お届け先 住所1', 'お届け先 住所2', 'お届け先 住所3'], 50);
      return conLabel;
    }
  }], [{
    key: 'createReadableOrder',
    value: function createReadableOrder() {
      var query = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      return _collections.RobotinOrders.rawCollection().find(query, { _id: 0, robotin: 1 }).stream();
    }
  }, {
    key: 'importOrder',
    value: function importOrder(docOrder, itemCon) {
      var insertDoc;
      return regeneratorRuntime.async(function importOrder$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            insertDoc = {
              robotin: docOrder
            };

            // すでに受注が取り込まれていた場合は、docOrderの内容に更新する
            // 取り込まれていない受注の場合は新規登録する
            _collections.RobotinOrders.update({
              'robotin.受注ID': docOrder['受注ID'],
              'robotin.明細ID': docOrder['明細ID']
            }, {
              $set: {
                robotin: docOrder
              }
            }, {
              upsert: true
            });

            // 発注ステータスが設定されていないドキュメント（新規登録受注）
            // 発注ステータスの初期値を設定する
            _collections.RobotinOrders.update({
              vendor: { $exists: 0 }
            }, {
              $set: {
                vendor: { // 発注ステータスの初期値
                  orderto: '', // 発注先
                  orderDate: null, // 発注日
                  promise: null }
              }
            });

          case 3:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'listItemCodeForLabel',
    // 発送予定日
    value: function listItemCodeForLabel(query) {
      var collection = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      collection = collection === null ? _collections.RobotinOrders : collection;

      // 検索条件に該当する受注を調べる
      var cur = collection.find(query, {
        fields: {
          _id: 0,
          'robotin.商品コード': 1,
          'robotin.数量': 1
        }
      });
      // 送り状レコードに該当する受注レコードが見つからない場合
      if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');
      // 商品リストを作成する
      var list = [];
      cur.forEach(function (doc) {
        var q = doc.robotin.数量 == 1 ? '' : '[' + doc.robotin.数量 + 'EA]';
        list.push(doc.robotin.商品コード + ' ' + q);
      });
      // 商品リストを返す
      return list;
    }
  }]);

  return Robotin;
})();

exports['default'] = Robotin;
module.exports = exports['default'];

// 商品番号をmongoIdとして検索し、該当するitemがあれば書き換える
// if (ObjectID.isValid(docOrder['商品コード'])) {
//   const item = await itemCon.Items.findOne({ _id: new ObjectID(docOrder['商品コード']) });
//   if (item) docOrder['商品コード'] = await itemCon.getModelClass(item);
// }

// 受注データをデータベースに保存
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/wowmaApi.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _xmlJs = require('xml-js');

var _utilError = require('../util/error');

var _utilError2 = _interopRequireDefault(_utilError);

var BASE_URI = 'https://api.manager.wowma.jp/wmshopapi';

var WowmaApi = (function () {
  function WowmaApi(plug, shopId) {
    _classCallCheck(this, WowmaApi);

    this.plug = plug;
    this.shopId = shopId;
  }

  // 商品情報更新

  _createClass(WowmaApi, [{
    key: 'updateItem',
    value: function updateItem(_updateItem) {
      var request, res;
      return regeneratorRuntime.async(function updateItem$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            request = '<request><shopId>' + this.shopId + '</shopId><updateItem>' + (0, _xmlJs.json2xml)(_updateItem, { compact: true }) + '</updateItem></request>';
            context$2$0.prev = 1;
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.requestPost('updateItemInfo', request));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', { response: res, requestXML: request });

          case 8:
            context$2$0.prev = 8;
            context$2$0.t0 = context$2$0['catch'](1);
            throw Object.assign(_utilError2['default'].parse(context$2$0.t0), { requestXML: request });

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[1, 8]]);
    }
  }, {
    key: 'requestPost',
    value: function requestPost(method, body) {
      var apiRequest, res;
      return regeneratorRuntime.async(function requestPost$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/' + method,
              body: body
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            // リクエスト発行
            context$2$0.next = 4;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(stockUpdateItem) {
      var apiRequest, res;
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/updateStock'
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.updateStockCreateRequestBody(stockUpdateItem));

          case 4:
            apiRequest.body = context$2$0.sent;
            context$2$0.next = 7;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStockCreateRequestBody',
    value: function updateStockCreateRequestBody(stockUpdateItem) {
      var stockUpdateItemXML, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, item, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, e, var0, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, variation, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, key, apiRequestBody;

      return regeneratorRuntime.async(function updateStockCreateRequestBody$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            stockUpdateItemXML = '';
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 4;
            _iterator = stockUpdateItem[Symbol.iterator]();

          case 6:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 87;
              break;
            }

            item = _step.value;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 11;

            // 値のチェック
            for (_iterator2 = item.variations[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              e = _step2.value;

              // 在庫数の上限100
              if (e.stock > 100) e.stock = 100;
            }

            context$2$0.next = 19;
            break;

          case 15:
            context$2$0.prev = 15;
            context$2$0.t0 = context$2$0['catch'](11);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 19:
            context$2$0.prev = 19;
            context$2$0.prev = 20;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 22:
            context$2$0.prev = 22;

            if (!_didIteratorError2) {
              context$2$0.next = 25;
              break;
            }

            throw _iteratorError2;

          case 25:
            return context$2$0.finish(22);

          case 26:
            return context$2$0.finish(19);

          case 27:
            stockUpdateItemXML += '<stockUpdateItem>';
            stockUpdateItemXML += '<itemCode>' + item.itemCode + '</itemCode>';

            // 商品在庫種別を振り分け
            // 1 -> 通常商品
            // 2 -> 選択肢別在庫

            var0 = item.variations[0];

            if (!(var0.choicesStockHorizontalCode === '' && var0.choicesStockVerticalCode === '')) {
              context$2$0.next = 35;
              break;
            }

            // 通常商品
            stockUpdateItemXML += '<stockSegment>1</stockSegment>';
            stockUpdateItemXML += '<stockCount>' + var0.stock + '</stockCount>';
            context$2$0.next = 83;
            break;

          case 35:
            // 選択肢別在庫
            stockUpdateItemXML += '<stockSegment>2</stockSegment>';

            // リクエストボディを作成する
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 39;
            _iterator3 = item.variations[Symbol.iterator]();

          case 41:
            if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
              context$2$0.next = 69;
              break;
            }

            variation = _step3.value;

            // 在庫設定タグの名前を差し替える
            variation.choicesStockCount = variation.stock;
            delete variation.stock;

            // xmlを構成する
            stockUpdateItemXML += '<choicesStocks>';
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 49;
            for (_iterator4 = Object.keys(variation)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              key = _step4.value;

              stockUpdateItemXML += '<' + key + '>' + variation[key] + '</' + key + '>';
            }
            context$2$0.next = 57;
            break;

          case 53:
            context$2$0.prev = 53;
            context$2$0.t1 = context$2$0['catch'](49);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 57:
            context$2$0.prev = 57;
            context$2$0.prev = 58;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 60:
            context$2$0.prev = 60;

            if (!_didIteratorError4) {
              context$2$0.next = 63;
              break;
            }

            throw _iteratorError4;

          case 63:
            return context$2$0.finish(60);

          case 64:
            return context$2$0.finish(57);

          case 65:
            stockUpdateItemXML += '</choicesStocks>';

          case 66:
            _iteratorNormalCompletion3 = true;
            context$2$0.next = 41;
            break;

          case 69:
            context$2$0.next = 75;
            break;

          case 71:
            context$2$0.prev = 71;
            context$2$0.t2 = context$2$0['catch'](39);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t2;

          case 75:
            context$2$0.prev = 75;
            context$2$0.prev = 76;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 78:
            context$2$0.prev = 78;

            if (!_didIteratorError3) {
              context$2$0.next = 81;
              break;
            }

            throw _iteratorError3;

          case 81:
            return context$2$0.finish(78);

          case 82:
            return context$2$0.finish(75);

          case 83:

            stockUpdateItemXML += '</stockUpdateItem>';

          case 84:
            _iteratorNormalCompletion = true;
            context$2$0.next = 6;
            break;

          case 87:
            context$2$0.next = 93;
            break;

          case 89:
            context$2$0.prev = 89;
            context$2$0.t3 = context$2$0['catch'](4);
            _didIteratorError = true;
            _iteratorError = context$2$0.t3;

          case 93:
            context$2$0.prev = 93;
            context$2$0.prev = 94;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 96:
            context$2$0.prev = 96;

            if (!_didIteratorError) {
              context$2$0.next = 99;
              break;
            }

            throw _iteratorError;

          case 99:
            return context$2$0.finish(96);

          case 100:
            return context$2$0.finish(93);

          case 101:
            apiRequestBody = '\n    <request>\n    <shopId>' + this.shopId + '</shopId>\n    ' + stockUpdateItemXML + '\n    </request>\n    ';
            return context$2$0.abrupt('return', apiRequestBody);

          case 103:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[4, 89, 93, 101], [11, 15, 19, 27], [20,, 22, 26], [39, 71, 75, 83], [49, 53, 57, 65], [58,, 60, 64], [76,, 78, 82], [94,, 96, 100]]);
    }
  }]);

  return WowmaApi;
})();

exports['default'] = WowmaApi;
module.exports = exports['default'];

// 接続オプションの作成

// 接続オプションの作成

// リクエスト発行

//
// stockUpdateItem =
// [
//   {
//     itemCode: <String>,
//     variations: [
//        {
//          choicesStockHorizontalCode: <String>,
//          choicesStockVerticalCode: <String>,
//          stock: <Number>
//        }
//     ]
//   }
// ]

// リクエストボディの作成

// リクエストボディを返す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/error.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var utilError = (function () {
  function utilError() {
    _classCallCheck(this, utilError);
  }

  _createClass(utilError, null, [{
    key: "parse",
    value: function parse(e) {
      var res = {};

      if (e instanceof Error) {
        res.message = e.message;
        res.name = e.name;
        res.fileName = e.fileName;
        res.lineNumber = e.lineNumber;
        res.columnNumber = e.columnNumber;
        res.stack = e.stack;
      } else {
        res = e;
      }

      return res;
    }
  }]);

  return utilError;
})();

exports["default"] = utilError;
module.exports = exports["default"];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mongo.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var MongoCollection = (function () {
  function MongoCollection() {
    _classCallCheck(this, MongoCollection);
  }

  _createClass(MongoCollection, null, [{
    key: 'get',
    value: function get(plug, collection) {
      var client, db;
      return regeneratorRuntime.async(function get$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri, { useNewUrlParser: true }));

          case 2:
            client = context$2$0.sent;
            db = client.db(plug.database);
            return context$2$0.abrupt('return', db.collection(collection));

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }]);

  return MongoCollection;
})();

exports.MongoCollection = MongoCollection;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mysql.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mysql = require('mysql');

var _mysql2 = _interopRequireDefault(_mysql);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var MySQL = (function () {
  function MySQL(profile) {
    _classCallCheck(this, MySQL);

    // コネクションプール初期化
    this.pool = _mysql2['default'].createPool(profile);

    // 複数行ステートメント対応
    var profileMulti = { multipleStatements: true };
    Object.assign(profileMulti, profile);
    this.poolMulti = _mysql2['default'].createPool(profileMulti);
  }

  _createClass(MySQL, [{
    key: 'querySelect',
    value: function querySelect(table, condition) {
      var product = arguments.length <= 2 || arguments[2] === undefined ? '*' : arguments[2];
      var productPart, tablePart, conditionPart, res;
      return regeneratorRuntime.async(function querySelect$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productPart = product;
            tablePart = 'FROM ' + table;
            conditionPart = condition ? 'WHERE ' + condition : '';
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query('SELECT ' + productPart + ' ' + tablePart + ' ' + conditionPart));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', JSON.parse(JSON.stringify(res)));

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'query',

    /**
     *
     * @param {String} sql
     */
    value: function query(sql) {
      // コネクション確立
      // let con = await this.getCon();
      return this.getCon().then(function (con) {
        return new Promise(function (resolve, reject) {
          // クエリ送信
          con.query(sql, function (e, res) {
            // コネクション開放
            con.release();
            if (e) {
              reject(e);
            } else resolve(res);
          });
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'queryInsert_',
    value: function queryInsert_(sql) {
      var res;
      return regeneratorRuntime.async(function queryInsert_$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query(sql));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * @param {String} table
     * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryInsert',
    value: function queryInsert(table) {
      var data = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
      var dataSql = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

      var sql, map, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, k, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, res;

      return regeneratorRuntime.async(function queryInsert$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'INSERT INTO ' + table + ' ';
            map = new Map();
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 5;

            for (_iterator = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              k = _step.value;

              if (data[k] === null) {
                map.set(k, 'NULL');
              } else if (data[k].constructor.name === 'Date') {
                // 日付を変換
                map.set(k, '"' + MySQL.formatDate(data[k]) + '"');
              } else {
                map.set(k, '' + _mysql2['default'].escape(data[k]));
              }
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 24;
            for (_iterator2 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
            }

            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError2) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError2;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += '( ' + [].concat(_toConsumableArray(map.keys())).join(',') + ' ) ';

            sql += 'VALUES( ' + [].concat(_toConsumableArray(map.values())).join(',') + ' ) ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    /**
     *
     * @param {String} table
     * @param {String} filter SQL UPDATEステートメントのWHERE句
     * @param {Object} data 文字列のパラメーター
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryUpdate',
    value: function queryUpdate(table, filter, data, dataSql) {
      var sql, updates, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, k, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, res;

      return regeneratorRuntime.async(function queryUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'UPDATE ' + table + ' SET ';
            updates = [];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 5;

            for (_iterator3 = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              updates.push(k + '=' + _mysql2['default'].escape(data[k]));
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError3) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError3;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 24;
            for (_iterator4 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              updates.push(k + '=' + dataSql[k]);
            }
            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError4) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError4;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += updates.join(',');

            sql += ' WHERE ' + filter + ' ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    // enable to use multiple statements
  }, {
    key: 'queryMulti',
    value: function queryMulti(sql) {
      var poolSwap, res;
      return regeneratorRuntime.async(function queryMulti$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            poolSwap = this.pool;

            this.pool = this.poolMulti;
            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query(sql));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 7:
            context$2$0.prev = 7;

            this.pool = poolSwap;
            return context$2$0.finish(7);

          case 10:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2,, 7, 10]]);
    }
  }, {
    key: 'startTransaction',
    value: function startTransaction() {
      return regeneratorRuntime.async(function startTransaction$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('START TRANSACTION;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'commit',
    value: function commit() {
      return regeneratorRuntime.async(function commit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('COMMIT;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'rollback',
    value: function rollback() {
      return regeneratorRuntime.async(function rollback$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('ROLLBACK;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'streamingQuery',
    value: function streamingQuery(sql) {
      var _this = this;

      var onResult = arguments.length <= 1 || arguments[1] === undefined ? function (record) {} : arguments[1];
      var onError = arguments.length <= 2 || arguments[2] === undefined ? function (e) {} : arguments[2];

      return this.getCon().then(function (con) {
        return new Promise(function callee$3$0(resolve, reject) {
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                // クエリ送信
                con.query(sql).on('result', function (record) {
                  con.pause();
                  onResult(record);
                  con.resume();
                }).on('error', function (e) {
                  onError(e);
                }).on('end', function () {
                  con.release();
                  resolve();
                });

              case 1:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'getCon',
    value: function getCon() {
      var _this2 = this;

      return new Promise(function (resolve, reject) {
        // プールからのコネクション獲得
        _this2.pool.getConnection(function (e, con) {
          if (e) {
            reject(e);
          } else {
            resolve(con);
          }
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }], [{
    key: 'formatDate',
    value: function formatDate(date) {
      return (0, _moment2['default'])(date).format().substring(0, 19).replace('T', ' ');
    }
  }]);

  return MySQL;
})();

exports['default'] = MySQL;
module.exports = exports['default'];

// SELECTの結果はディープコピーすることで rowdatapacket を外す

// let res = await this.query(sql);
// return res.insertId;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/packet.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Packet = (function () {
  function Packet(packetSize) {
    _classCallCheck(this, Packet);

    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  _createClass(Packet, [{
    key: "submit",
    value: function submit(arg) {
      return regeneratorRuntime.async(function submit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            if (!(this.count % this.packetSize === 0)) {
              context$2$0.next = 4;
              break;
            }

            if (!this.onPacketStart) {
              context$2$0.next = 4;
              break;
            }

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.onPacketStart(this.packetCount));

          case 4:
            if (!this.onPacket) {
              context$2$0.next = 7;
              break;
            }

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.onPacket(arg));

          case 7:
            this.count++;
            // packetSizeの回数ごとに、終了処理を呼び出す
            if (this.count % this.packetSize === 0) {
              this.close();
              this.packetCount++;
            }

          case 9:
          case "end":
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: "close",
    value: function close() {
      if (this.onPacketEnd) {
        this.onPacketEnd(this.packetCount);
      }
    }
  }]);

  return Packet;
})();

exports["default"] = Packet;
module.exports = exports["default"];

// packetSizeの回数ごとに、初期化を呼び出す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/report.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _error = require('./error');

var _error2 = _interopRequireDefault(_error);

var _meteorMeteor = require('meteor/meteor');

var _collections = require('../collections');

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

var Report = (function () {
  function Report() {
    _classCallCheck(this, Report);

    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  // private

  _createClass(Report, [{
    key: 'setupIterator',
    value: function setupIterator(phaseId) {
      this.iterator = new Iterator(phaseId);
      this.iterators.push(this.iterator);
    }
  }, {
    key: 'phase',
    value: function phase() {
      var _this = this;

      var name = arguments.length <= 0 || arguments[0] === undefined ? '' : arguments[0];
      var fn = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0() {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
      var rec, res;
      return regeneratorRuntime.async(function phase$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            rec = {
              phaseId: (0, _uniqid2['default'])()
            };

            this.setupIterator(rec.phaseId);

            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(fn());

          case 5:
            res = context$2$0.sent;

            Object.assign(rec, {
              type: 'success',
              phase: name,
              result: res
            });
            context$2$0.next = 12;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](2);

            Object.assign(rec, {
              type: 'error',
              phase: name,
              result: _error2['default'].parse(context$2$0.t0)
            });

          case 12:
            context$2$0.prev = 12;

            // ループ処理のレポートを作成
            if (this.iterator.metric.total) {
              Object.assign(rec, {
                iterator: this.iterator.metric
              });
            }
            // タイムスタンプ
            rec.timeStamp = new Date();
            // レポートをデータベースに記録
            _collections.Logs.insert(rec);

            // 呼び出し元用レポートに追加
            this.record.push(rec);
            return context$2$0.finish(12);

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2, 9, 12, 18]]);
    }

    // カーソルをループし、与えられた関数を実行
    // 呼び出す関数の引数にはカーソルから得られたドキュメントを渡す
  }, {
    key: 'forEachOnCursor',
    value: function forEachOnCursor(cur, fn) {
      var doc, res;
      return regeneratorRuntime.async(function forEachOnCursor$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 2:
            if (!context$2$0.sent) {
              context$2$0.next = 18;
              break;
            }

            context$2$0.next = 5;
            return regeneratorRuntime.awrap(cur.next());

          case 5:
            doc = context$2$0.sent;
            context$2$0.prev = 6;
            context$2$0.next = 9;
            return regeneratorRuntime.awrap(fn(doc));

          case 9:
            res = context$2$0.sent;

            this.iSuccess(res);
            context$2$0.next = 16;
            break;

          case 13:
            context$2$0.prev = 13;
            context$2$0.t0 = context$2$0['catch'](6);

            this.iError(context$2$0.t0);

          case 16:
            context$2$0.next = 0;
            break;

          case 18:
            cur.close();

          case 19:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 13]]);
    }
  }, {
    key: 'iSuccess',
    value: function iSuccess(newRecord) {
      this.iterator.success(newRecord);
    }
  }, {
    key: 'iError',
    value: function iError(newRecord) {
      this.iterator.error(_error2['default'].parse(newRecord));
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      var iteError = this.iterators.find(function (e) {
        return e.errorOcurred();
      });
      var phaError = false;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.record[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var rec = _step.value;

          if (rec.type === 'error') {
            phaError = true;
            break;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return iteError || phaError;
    }
  }, {
    key: 'publish',
    value: function publish() {
      // 呼び出し元へレポート
      if (this.errorOcurred()) {
        throw new _meteorMeteor.Meteor.Error(this.record);
      }
      return this.record;
    }
  }]);

  return Report;
})();

exports['default'] = Report;

var Iterator = (function () {
  function Iterator(phaseId) {
    _classCallCheck(this, Iterator);

    this.metric = {
      total: 0,
      success: 0,
      error: 0,
      phaseId: phaseId
    };
    this.lastError = null;
  }

  _createClass(Iterator, [{
    key: 'success',
    value: function success(newRecord) {
      if (newRecord) {
        this.log(newRecord, true);
      }
      this.metric.success++;
      this.metric.total++;
    }
  }, {
    key: 'error',
    value: function error(newRecord) {
      // 直前と同じエラーは省く
      if (JSON.stringify(this.lastError) !== JSON.stringify(newRecord)) {
        if (newRecord && newRecord !== {} && newRecord !== '') {
          this.log(newRecord, false);
          this.lastError = newRecord;
        }
      }
      this.metric.error++;
      this.metric.total++;
    }
  }, {
    key: 'log',
    value: function log(newRecord, isSuccess /* true => success or false => error */) {
      var rec = {
        success: isSuccess,
        phaseId: this.metric.phaseId,
        message: newRecord,
        timeStamp: new Date()
      };
      _collections.Logs.insert(rec);
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      return this.metric.error;
    }
  }]);

  return Iterator;
})();

module.exports = exports['default'];

// リクエスト発行
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"syncObject.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/syncObject.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

/**
 *
 * @param {[Object]} src
 * @param {[Object]} dst
 * @param {string} idkey
 * @param {function(any, Object)} create
 * @param {function(any, Object)} remove
 */

exports['default'] = function syncObject(src, dst, idkey, addFunc, remFunc) {
  if (idkey === undefined) idkey = null;
  var srcContainer, dstContainer, idDeletedClone;
  return regeneratorRuntime.async(function syncObject$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        srcContainer = [];
        dstContainer = [];

        idDeletedClone = function idDeletedClone(elem, idkeyAP) {
          var elemSave = _lodash2['default'].cloneDeep(elem);
          // id を比較対象から外す
          if (_lodash2['default'].isUndefined(elemSave[idkeyAP]) === false) {
            delete elemSave[idkeyAP];
          }
          // ディープクローンしたオブジェクトを返す
          return elemSave;
        };

        // オブジェクト比較の前準備
        src.forEach(function (elem) {
          srcContainer.push({
            object: idDeletedClone(elem, idkey),
            id: elem[idkey],
            state: {
              /**
               * true 何もしない
               * false 新規に作成
               */
              find: false
            }
          });
        });

        dst.forEach(function (elem) {
          dstContainer.push({
            object: idDeletedClone(elem, idkey),
            id: elem[idkey],
            state: {
              /**
               * true 何もしない
               * false 削除する
               */
              find: false
            }
          });
        });

        // オブジェクトを比較
        srcContainer.forEach(function (srcElem) {
          dstContainer.forEach(function (dstElem) {
            if (_lodash2['default'].isEqual(srcElem.object, dstElem.object)) {
              // 同じオブジェクトが見つかった場合
              srcElem.state.find = true;
              dstElem.state.find = true;
            }
          });
        });

        // データの挿入
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(Promise.all(srcContainer.map(function callee$1$0(elem) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                if (!(elem.state.find === false)) {
                  context$2$0.next = 3;
                  break;
                }

                context$2$0.next = 3;
                return regeneratorRuntime.awrap(addFunc(elem.id, elem.object));

              case 3:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        })));

      case 8:
        context$1$0.next = 10;
        return regeneratorRuntime.awrap(Promise.all(dstContainer.map(function callee$1$0(elem) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                if (!(elem.state.find === false)) {
                  context$2$0.next = 3;
                  break;
                }

                context$2$0.next = 3;
                return regeneratorRuntime.awrap(remFunc(elem.id, elem.object));

              case 3:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        })));

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
};

module.exports = exports['default'];

// データの削除
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/text.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var TextUtil = (function () {
  function TextUtil() {
    _classCallCheck(this, TextUtil);
  }

  _createClass(TextUtil, null, [{
    key: 'substr8',

    // 8ビットで文字列切り取る
    value: function substr8(text, len, truncation) {
      if (truncation === undefined) {
        truncation = '';
      }
      var textArray = text.split('');
      var count = 0;
      var str = '';
      for (var i = 0; i < textArray.length; i++) {
        var n = escape(textArray[i]);
        if (n.length < 4) count++;else count += 2;
        if (count > len) {
          return str + truncation;
        }
        str += text.charAt(i);
      }
      return text;
    }

    // 文字列のバイト数を数える
  }, {
    key: 'lenb',
    value: function lenb(text) {
      return encodeURIComponent(text).replace(/%..%..%../g, 'xx').length;
    }
  }, {
    key: 'splitlenb',
    value: function splitlenb(target, keyS, length) {
      var sep = ' ';
      // keyS で指定された target 内の要素の値をすべて結合した文字列を作る
      var strEntire = keyS.reduce(function (prev, current) {
        return prev + target[current];
      }, '');
      // 結合した文字列を半角スペースで分割する
      var arrEntire = strEntire.split(sep);
      var arrRes = [];
      var last = '';
      // バイト長がlengthを超えない限り前後の分割文字列を結合していく
      // バイト長がlengthを超えたら、ひとつまえの結合文字列を配列登録する
      try {
        arrEntire.reduce(function (prev, current) {
          // length を超えるバイト長の分割文字列がある場合は何もしない
          if (TextUtil.lenb(current) > length) throw new Error('文字列超過');
          var exam = (prev !== '' ? prev + sep : '') + current;
          if (TextUtil.lenb(exam) > length) {
            arrRes.push(prev);
            last = current; // 最後の文字列
            return '';
          } else {
            last = exam; // 最後の文字列
            return exam;
          }
        }, '');
      } catch (e) {
        // length を超えるバイト長の分割文字列がある場合は何もしない
        if (e.message === '文字列超過') return;
      }

      arrRes.push(last); // 最後の文字列を配列登録する
      // keyS で指定された target 内の要素の値を修正する
      for (var i = 0; i < keyS.length; i++) {
        target[keyS[i]] = arrRes[i] ? arrRes[i] : '';
      }
    }
  }]);

  return TextUtil;
})();

exports['default'] = TextUtil;
module.exports = exports['default'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _this = this;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _meteorMeteor = require('meteor/meteor');

var _meteorMongo = require('meteor/mongo');

var Logs = new _meteorMongo.Mongo.Collection('logs', { idGeneration: 'MONGO' });
exports.Logs = Logs;
var Uploads = new _meteorMongo.Mongo.Collection('uploads', { idGeneration: 'MONGO' });

exports.Uploads = Uploads;
var RobotinShop = new _meteorMongo.Mongo.Collection('robotinShop', { idGeneration: 'MONGO' });
exports.RobotinShop = RobotinShop;
var RobotinOrders = new _meteorMongo.Mongo.Collection('robotinOrders', { idGeneration: 'MONGO' });

exports.RobotinOrders = RobotinOrders;
var Configs = new _meteorMongo.Mongo.Collection('configs', { idGeneration: 'MONGO' });

exports.Configs = Configs;
if (_meteorMeteor.Meteor.isServer) {
  _meteorMeteor.Meteor.publish('configs', function () {
    return Configs.find();
  });
  _meteorMeteor.Meteor.methods(_defineProperty({}, 'robotinOrderGroups', function robotinOrderGroups() {
    var res;
    return regeneratorRuntime.async(function robotinOrderGroups$(context$1$0) {
      while (1) switch (context$1$0.prev = context$1$0.next) {
        case 0:
          context$1$0.next = 2;
          return regeneratorRuntime.awrap(RobotinOrders.rawCollection().aggregate([{
            // 受注IDごとにグループ化
            $group: {
              _id: {
                受注ID: '$robotin.受注ID',
                受注日時: '$robotin.受注日時',
                店舗名: '$robotin.店舗名',
                受注番号: '$robotin.受注番号'
              },
              items: { $push: { 商品コード: '$robotin.商品コード', 数量: '$robotin.数量' } }
            }
          }, {
            $project: {
              _id: 0,
              受注ID: '$_id.受注ID',
              受注日時: '$_id.受注日時',
              店舗名: '$_id.店舗名',
              受注番号: '$_id.受注番号',
              items: '$items'
            }
          }]).toArray());

        case 2:
          res = context$1$0.sent;
          return context$1$0.abrupt('return', res);

        case 4:
        case 'end':
          return context$1$0.stop();
      }
    }, null, this);
  }));

  _meteorMeteor.Meteor.publish('robotinOrderItems', function callee$0$0() {
    return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
      while (1) switch (context$1$0.prev = context$1$0.next) {
        case 0:
          return context$1$0.abrupt('return', RobotinOrders.find());

        case 1:
        case 'end':
          return context$1$0.stop();
      }
    }, null, _this);
  });
}

if (_meteorMeteor.Meteor.isClient) {
  _meteorMeteor.Meteor.subscribe('configs');
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/robotin.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/wowmaApi.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yb2JvdGluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdG9vbHRlc3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci93b3dtYS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIveWF1Y3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3Vwcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL3JvYm90aW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS93b3dtYUFwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3N5bmNPYmplY3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC90ZXh0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb25zLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztrQkFLZSxJQUFJOzs7O3NCQUNBLFFBQVE7Ozs7OztpQ0FHSixvQkFBb0I7Ozs7a0NBR3BDLDhCQUE4Qjs7QUFDckMsSUFBSSxvQkFBb0IsR0FBRyxxQ0FBWSxDQUFDOztBQUV4QyxJQUFNLEtBQUssR0FBRyxlQUFlLENBQUM7OztBQUc5QixNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztBQUN4RCxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBQyxHQUFHLEVBQUUsSUFBSSxFQUFLOzs7QUFHL0MsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxnQkFBRyxRQUFRLENBQUMsQ0FBQztBQUM3QyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLGdCQUFHLFNBQVMsQ0FBQyxDQUFDO0FBQzlDLE1BQU0sUUFBUSxHQUFHLDBCQUFRLENBQUM7Ozs7Ozs7QUFFMUIseUJBQWlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSw4SEFBRTtVQUF4QixJQUFJOztBQUNYLFVBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7OztBQUcvQixVQUFJLFFBQVEsR0FBTSwwQkFBUSxTQUFNOzs7QUFHaEMsVUFBSSxRQUFRLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQzs7Ozs7QUFLbEQsVUFBSSxHQUFHLEdBQUc7QUFDUixnQkFBUSxFQUFFLFFBQVE7QUFDbEIsc0JBQWMsRUFBRSxJQUFJLENBQUMsSUFBSTtBQUN6Qix3QkFBZ0IsRUFBRSxRQUFRO09BQzNCLENBQUM7O0FBRUYsVUFBRztBQUNELGNBQU0sQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7T0FDeEIsQ0FDRCxPQUFNLEdBQUcsRUFBQztBQUNSLFdBQUcsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO09BQ2pCO0FBQ0Qsa0NBQVEsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDOztBQUVwQixhQUFPLElBQUksQ0FBQztLQUViOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsR0FBQztBQUNGLE1BQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDcEIsTUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO0FBQ3RCLFlBQVEsRUFBRSxRQUFRO0FBQ2xCLFdBQU8sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVE7R0FDM0IsQ0FBQyxDQUFDLENBQUM7Q0FFTCxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7O3NCQzdEaUIsUUFBUTs7Ozs0QkFFSixlQUFlOztnQ0FDcEIsMEJBQTBCOzs7O2lDQUN6QiwyQkFBMkI7Ozs7dUNBSXZDLGlDQUFpQzs7d0NBR2pDLGtDQUFrQzs7QUFFekMsSUFBSSxHQUFHLEdBQUcsU0FBUzs7QUFFbkIscUJBQU8sT0FBTyx5REFFRixHQUFHLGVBQVksb0JBQUMsTUFBTTtNQUMxQixNQUFNLEVBS04sTUFBTSxFQU1OLFNBQVMsRUFFVCxLQUFLOzs7Ozs7QUFiTCxjQUFNLEdBQUcsb0NBQVk7QUFLckIsY0FBTSxHQUFHLHFDQUFXLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFNdkMsaUJBQVMsR0FBRyxnQkFBZ0I7QUFFNUIsYUFBSyxHQUFHLGtDQUFVLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDOzt3Q0FFaEMsTUFBTSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsRUFDekM7Ozs7O2dEQUNRLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDOzs7Ozs7O1NBQzdCLENBQUM7Ozs7d0NBS0UsTUFBTSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsRUFDeEM7Y0FDTSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDN0IsNEJBQVUsRUFBRSxvQkFBTyxNQUFNO3dCQWFuQixHQUFHLEVBd0dILFFBQVEsRUFFUixVQUFVLEVBRVYsYUFBYSxFQUdYLElBQUc7Ozs7O0FBL0dMLDZCQUFHLDZkQUtPLE1BQU0sQ0FBQyxXQUFXLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsR0FBRyxXQUFNLE1BQU0sQ0FBQyxHQUFHLFdBQU0sTUFBTSxDQUFDLFVBQVUsV0FBTSxNQUFNLENBQUMsSUFBSSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLFlBQVksV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLE9BQU8sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxRQUFRLFdBQU0sTUFBTSxDQUFDLElBQUksV0FBTSxNQUFNLENBQUMsVUFBVSxXQUFNLE1BQU0sQ0FBQyxjQUFjLFdBQU0sTUFBTSxDQUFDLGFBQWEsV0FBTSxNQUFNLENBQUMsU0FBUyxXQUFNLE1BQU0sQ0FBQyxTQUFTLFdBQU0sTUFBTSxDQUFDLElBQUksV0FBTSxNQUFNLENBQUMsV0FBVyxXQUFNLE1BQU0sQ0FBQyxXQUFXLFdBQU0sTUFBTSxDQUFDLE9BQU87OzswREFLenJCLEtBQUssQ0FBQyxXQUFXLENBQ3JCLGNBQWMsRUFBRTtBQUNkLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0Isa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQiwrQkFBRyxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQ2YsK0JBQUcsRUFBRSxNQUFNLENBQUMsR0FBRztBQUNmLHNDQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDN0IsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLHdDQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7QUFDakMsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87QUFDdkIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixvQ0FBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ3pCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsc0NBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtBQUM3QiwwQ0FBYyxFQUFFLE1BQU0sQ0FBQyxjQUFjO0FBQ3JDLHlDQUFhLEVBQUUsTUFBTSxDQUFDLGFBQWE7QUFDbkMscUNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztBQUMzQixxQ0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO0FBQzNCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87MkJBQ3hCLENBQ0Y7Ozs7Ozs7Ozs7QUFFRCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7OzBEQUtWLEtBQUssQ0FBQyxXQUFXLENBQ3JCLHNCQUFzQixFQUFFO0FBQ3RCLCtDQUFtQixFQUFFLElBQUk7QUFDekIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixzQ0FBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO0FBQzdCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQix3Q0FBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO0FBQ2pDLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO0FBQ3ZCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTzsyQkFDeEIsQ0FDRjs7Ozs7Ozs7OztBQUVELGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7MERBS1YsS0FBSyxDQUFDLFdBQVcsQ0FDckIsdUJBQXVCLEVBQUU7QUFDdkIsOEJBQUUsRUFBRSxJQUFJO0FBQ1IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix3Q0FBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO0FBQ2pDLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPOzJCQUN4QixDQUNGOzs7Ozs7Ozs7O0FBRUQsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7QUFLZCxrQ0FBUSxHQUFHLG9CQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7QUFFcEUsb0NBQVUsR0FBTSxNQUFNLENBQUMsTUFBTSxTQUFJLE1BQU0sQ0FBQyxNQUFNLHdCQUFtQixNQUFNLENBQUMsV0FBVztBQUVuRix1Q0FBYSxHQUFHLE1BQU0sQ0FBQyxLQUFLLEdBQUcsR0FBRzs7OzBEQUdwQixLQUFLLENBQUMsV0FBVyxDQUMvQixZQUFZLEVBQUU7QUFDWixxQ0FBUyxFQUFFLElBQUk7QUFDZixxQ0FBUyxFQUFFLFFBQVE7QUFDbkIsdUNBQVcsRUFBRSxDQUFDO0FBQ2QsdUNBQVcsRUFBRSxVQUFVO0FBQ3ZCLHlDQUFhLEVBQUUsQ0FBQztBQUNoQiwyQ0FBZSxFQUFFLENBQUM7QUFDbEIsMENBQWMsRUFBRSxDQUFDO0FBQ2pCLDBDQUFjLEVBQUUsYUFBYTtBQUM3Qix5Q0FBYSxFQUFFLElBQUk7QUFDbkIsdUNBQVcsRUFBRSxDQUFDO0FBQ2QseUNBQWEsRUFBRSxDQUFDO0FBQ2hCLDhDQUFrQixFQUFFLElBQUk7QUFDeEIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQiwrQ0FBbUIsRUFBRSxxQkFBcUI7QUFDMUMsNkNBQWlCLEVBQUUscUJBQXFCO0FBQ3hDLG1DQUFPLEVBQUUsQ0FBQzsyQkFDWCxFQUFFO0FBQ0QsdUNBQVcsRUFBRSxPQUFPO0FBQ3BCLHVDQUFXLEVBQUUsT0FBTzsyQkFDckIsQ0FDRjs7O0FBdEJHLDhCQUFHOzs7Ozs7OztBQXdCUCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7Ozs7bUJBRW5CO2lCQUNGLEVBQ0Qsb0JBQU8sQ0FBQzs7OztBQUNOLDhCQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzs7Ozs7OztpQkFDakIsQ0FDQTs7O0FBNUpHLG1CQUFHO29EQThKQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBRUsscUJBQXFCLEVBQUMsNEJBQUMsT0FBTztNQUM5QixFQUFFLEVBQ0YsR0FBRzs7OztBQURILFVBQUUsR0FBRyxrQ0FBVSxPQUFPLENBQUM7O3dDQUNYLEVBQUUsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7OztBQUF0QyxXQUFHOzRDQUNBLEdBQUc7Ozs7Ozs7Q0FDWCxvQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0NDck44QiwwQkFBMEI7OzRCQUNyQyxlQUFlOztBQUVwQyxJQUFJLEdBQUcsR0FBRyxrQkFBa0I7O0FBRTVCLHFCQUFPLE9BQU8seURBRUYsR0FBRyxZQUFTLG9CQUFDLElBQUk7TUFBRSxLQUFLLHlEQUFHLEVBQUU7TUFBRSxVQUFVLHlEQUFHLEVBQUU7TUFDbEQsSUFBSSxFQUNKLEdBQUc7Ozs7O3dDQURVLGtDQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUM7OztBQUF2RCxZQUFJOzt3Q0FDUSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRTs7O0FBQWhFLFdBQUc7NENBQ0EsR0FBRzs7Ozs7OztDQUNYLG9DQUVTLEdBQUcsaUJBQWMsb0JBQUMsSUFBSTtNQUFFLEtBQUsseURBQUcsRUFBRTtNQUN0QyxJQUFJLEVBQ0osR0FBRzs7Ozs7d0NBRFUsa0NBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQzs7O0FBQXZELFlBQUk7O3dDQUNRLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxFQUFFOzs7QUFBM0MsV0FBRzs0Q0FDQSxHQUFHOzs7Ozs7O0NBQ1gsb0JBRUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7NEJDbkJxQixlQUFlOzttQ0FDWCw2QkFBNkI7Ozs7QUFFeEQsSUFBTSxHQUFHLEdBQUcsYUFBYSxDQUFDOztBQUUxQixxQkFBTyxPQUFPLHlEQU9GLEdBQUcsZ0JBQWEsb0JBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxLQUFLO01BQUUsTUFBTSx5REFBRyxJQUFJO01BQUUsTUFBTSx5REFBRyxJQUFJO01BQ3RFLE9BQU8sRUFFUCxRQUFROzs7O0FBRlIsZUFBTyxHQUFHLHNDQUFvQjs7d0NBQzlCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDOzs7O3dDQUNELE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDOzs7QUFBbEUsZ0JBQVE7NENBQ1AsUUFBUTs7Ozs7OztDQUNoQixvQ0FLUyxHQUFHLGtCQUFlLG9CQUFDLElBQUksRUFBRSxLQUFLO01BQUUsTUFBTSx5REFBRyxJQUFJO01BQUUsTUFBTSx5REFBRyxJQUFJO01BQzlELE9BQU87Ozs7QUFBUCxlQUFPLEdBQUcsc0NBQW9COzt3Q0FDOUIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7Ozs7d0NBQ2xCLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7Ozs7Ozs7Q0FDaEQsb0JBRUQsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3NCQzVCVyxRQUFROzs7OzRCQUNDLGVBQWU7O2lDQUNuQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7c0NBRzdCLDZCQUE2Qjs7Z0NBQ2xCLHVCQUF1Qjs7OzttQ0FDZCwwQkFBMEI7Ozs7QUFHckQsSUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDOztBQUVuQixxQkFBTyxPQUFPLHlEQUtGLEdBQUcsZ0JBQWEsb0JBQUMsTUFBTTtNQUV6QixNQUFNLEVBRU4sTUFBTSxFQUNOLGNBQWMsRUFHZCxRQUFRLEVBQ1IsR0FBRzs7Ozs7O0FBUEgsY0FBTSxHQUFHLG9DQUFZO0FBRXJCLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFFbkMsZ0JBQVEsR0FBRyxrQ0FBVSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ3BDLFdBQUcsR0FBRyxxQ0FBYSxRQUFRLENBQUM7O3dDQUU1QixNQUFNLENBQUMsS0FBSyxDQUNoQixXQUFXLEVBQ1g7Y0FDUSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDL0Isd0JBQU0sRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFLaEIsT0FBTzs7OzsrQkFIYixvQkFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDOzs7Ozs7OzBEQUdyQixHQUFHLENBQUMsY0FBYyxDQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FDakM7OztBQUhLLGlDQUFPOzs7QUFNYixnQ0FBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQzs7Ozs7Ozs7QUFFekIsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHLENBQUM7Ozs7Ozs7bUJBR3RCO2lCQUNGLENBQUM7OztBQWxCSSxtQkFBRztvREFvQkYsR0FBRzs7Ozs7OztTQUNYLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUtTLEdBQUcsbUJBQWdCLG9CQUFDLE1BQU07TUFFNUIsTUFBTSxFQUVOLE1BQU0sRUFDTixjQUFjLEVBR2QsUUFBUSxFQUNSLEdBQUc7Ozs7OztBQVBILGNBQU0sR0FBRyxvQ0FBWTtBQUVyQixjQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCxzQkFBYyxHQUFHLHNDQUFvQjs7d0NBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBRW5DLGdCQUFRLEdBQUcsa0NBQVUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNwQyxXQUFHLEdBQUcscUNBQWEsUUFBUSxDQUFDOzt3Q0FFNUIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsT0FBTyxFQUNQO2NBQ1EsR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDOztBQUUvQix3QkFBTSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPO3dCQUNwQixRQUFROzs7OzswREFBUyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUFsRCxrQ0FBUTs7MERBQ1IsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLENBQUM7Ozs7Ozs7bUJBQ3hFO2lCQUNGLENBQUM7OztBQU5JLG1CQUFHO29EQVFGLEdBQUc7Ozs7Ozs7U0FDWCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGlCQUFjLG9CQUFDLE1BQU07TUFDMUIsTUFBTSxFQUNOLFFBQVEsRUFDUixHQUFHLEVBRUgsY0FBYyxFQUlkLE1BQU07Ozs7OztBQVJOLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELGdCQUFRLEdBQUcsa0NBQVUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNwQyxXQUFHLEdBQUcscUNBQWEsUUFBUSxDQUFDO0FBRTVCLHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFHbkMsY0FBTSxHQUFHLG9DQUFZOzt3Q0FFckIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBQ1EsR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQy9CLHdCQUFNLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3BCLEdBQUcsRUFHRCxRQUFRLEVBRVIsU0FBUzs7OztBQUxYLDZCQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVU7OzswREFHTCxjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7OztBQUF6RSxrQ0FBUTs7MERBRVUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7OztBQUE3QyxtQ0FBUzs7MERBR1QsR0FBRyxDQUFDLFNBQVMsQ0FBQztBQUNsQiwrQkFBRyxFQUFFLElBQUksQ0FBQyxHQUFHOzJCQUNkLEVBQUU7QUFDRCxnQ0FBSSxFQUFFO0FBQ0osMkRBQTZCLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVO0FBQ3ZELGlFQUFtQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCO0FBQ25FLGlFQUFtQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCOzZCQUNwRTsyQkFDRixDQUFDOzs7O0FBRUYsZ0NBQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQzs7Ozs7Ozs7QUFFbEIsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHLENBQUM7Ozs7Ozs7bUJBRXBCO2lCQUNGLEVBQ0Qsb0JBQU8sQ0FBQzs7Ozs4QkFDQSxDQUFDOzs7Ozs7O2lCQUNSLENBQUM7OztBQTVCSSxtQkFBRztvREE4QkYsR0FBRzs7Ozs7OztTQUNYLENBQ0Y7Ozs7d0NBRUssTUFBTSxDQUFDLEtBQUssQ0FDaEIsZ0JBQWdCLEVBQ2hCO2NBQ1EsR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQy9CLHdCQUFNLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3BCLEdBQUcsRUFHRCxRQUFRLEVBTVIsUUFBUTs7OztBQVRWLDZCQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVU7OzswREFHTCxjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7OztBQUF6RSxrQ0FBUTs7MERBRVIsR0FBRyxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQzs7OzswREFDaEMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7Ozs7MERBQzNCLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUM7Ozs7MERBRWIsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOzs7QUFBbEQsa0NBQVE7OzBEQUNSLEdBQUcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsUUFBUSxDQUFDOzs7O0FBRXZFLGdDQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7Ozs7Ozs7O0FBRWxCLGdDQUFNLENBQUMsTUFBTSxnQkFBRyxDQUFDOzs7Ozs7O21CQUVwQjtpQkFDRixFQUNELG9CQUFPLENBQUM7Ozs7OEJBQ0EsQ0FBQzs7Ozs7OztpQkFDUixDQUFDOzs7QUF0QkksbUJBQUc7b0RBd0JGLEdBQUc7Ozs7Ozs7U0FDWCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQkFFRCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0NsTGdCLHdCQUF3Qjs7OzttQ0FDaEIsMEJBQTBCOzs7OzRCQUM5QixlQUFlOzt1QkFDbEIsVUFBVTs7Ozt5QkFDWixZQUFZOzs7O21CQUNkLEtBQUs7Ozs7c0JBQ2UsUUFBUTs7c0JBRTFCLFFBQVE7Ozs7cUNBQ04sNEJBQTRCOzs7O0FBRWhELElBQU0sR0FBRyxHQUFHLFNBQVM7O0FBRXJCLHFCQUFPLE9BQU8seURBRUYsR0FBRyxvQkFBaUIsb0JBQUMsTUFBTTtNQUUvQixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixtQkFBbUIsRUFDbkI7Y0FDUSxPQUFPLEVBQ1AsYUFBYSxFQUNiLGNBQWMsRUFlZCxLQUFLOzs7O0FBakJMLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU87QUFDbkQsNkJBQWEsR0FBTSxPQUFPLFNBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhO0FBQ3hELDhCQUFjLEdBQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxjQUFjOzs7Z0RBSTdDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUc3QixxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUl0QixxQkFBUSxLQUFLLENBQUMsYUFBYSxDQUFDOzs7Ozs7Ozs7OztBQUk5QixxQkFBSyxHQUFHLHNDQUFvQjs7Z0RBQzVCLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7QUFHaEMscUNBQU8sU0FBUyxDQUFDLGFBQUcsRUFBSTtBQUN0QixzQkFBTSxJQUFJLEdBQUcsbUNBQVEsbUJBQW1CLEVBQUUsQ0FDdkMsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDOztBQUVuQyxzQkFBTSxTQUFTLEdBQUcsc0JBQWM7QUFDOUIsc0NBQWtCLEVBQUUsSUFBSTtBQUN4QixzQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLDZCQUFTLEVBQUUsbUJBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUc7QUFDM0Isd0JBQUUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3FCQUN6QjttQkFDRixDQUFDLENBQUM7O0FBRUgsc0JBQU0sS0FBSyxHQUFHLHFCQUFRLGlCQUFpQixDQUFJLGFBQWEsU0FBSSxjQUFjLENBQUcsQ0FDMUUsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDLENBQ2hDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBSTtBQUNoQix1QkFBRyxFQUFFO21CQUNOLENBQUM7O0FBRUosc0JBQUksQ0FDRCxJQUFJLENBQUMsU0FBUyxDQUFDLENBQ2YsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FBQyxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ25DLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUNmLENBQUMsRUFBRTs7Ozs7OztTQUVMLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUVTLEdBQUcsb0JBQWlCLG9CQUFDLE1BQU07TUFFL0IsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsb0JBQW9CLEVBQ3BCO2NBQ1EsT0FBTyxFQUNQLGFBQWEsRUFDYixRQUFRLEVBZVIsS0FBSzs7OztBQWpCTCx1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPLFNBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPO0FBQ25ELDZCQUFhLEdBQU0sT0FBTyxTQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYTtBQUN4RCx3QkFBUSxHQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUTs7O2dEQUlqQyxxQkFBUSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFHN0IscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFJdEIscUJBQVEsS0FBSyxDQUFDLGFBQWEsQ0FBQzs7Ozs7Ozs7Ozs7QUFJOUIscUJBQUssR0FBRyxzQ0FBb0I7O2dEQUM1QixLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7O0FBR2hDLHFDQUFPLFNBQVMsQ0FBQyxhQUFHLEVBQUk7QUFDdEIsc0JBQU0sSUFBSSxHQUFHLHFCQUFRLGdCQUFnQixDQUFJLGFBQWEsU0FBSSxRQUFRLENBQUcsQ0FDbEUsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDO0FBQ25DLHNCQUFNLEtBQUssR0FBRyxxQkFBYTtBQUN6Qiw4QkFBVSxFQUFFLElBQUk7QUFDaEIseUJBQUssRUFBQyxlQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFOzs7QUFDaEMsK0NBQU07Ozs7Ozs4REFFSSxtQ0FBUSxXQUFXLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQzs7O0FBQ3ZDLG9DQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7Ozs7Ozs7O0FBR2xCLHNDQUFRLGdCQUFLOzs7QUFFZixzQ0FBUSxFQUFFOzs7Ozs7O3VCQUNYLENBQUMsQ0FBQyxHQUFHLEVBQUU7cUJBQ1Q7QUFDRCx5QkFBSyxFQUFDLGVBQUMsUUFBUSxFQUFFO0FBQ2YsOEJBQVEsRUFBRTtBQUNWLHlCQUFHLEVBQUU7cUJBQ047bUJBQ0YsQ0FBQyxDQUNDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsYUFBRzsyQkFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzttQkFBQSxDQUFDOztBQUV6QyxzQkFBSSxDQUFDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDbEMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsaUJBQUksS0FBSyxDQUFDLEVBQUMsT0FBTyxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLEtBQUssQ0FBQztpQkFDZixDQUFDLEVBQUU7Ozs7Ozs7U0FFTCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FFUyxHQUFHLGlCQUFjLG9CQUFDLE1BQU07TUFFNUIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZ0JBQWdCLEVBQ2hCO2NBQ1EsT0FBTyxFQUNQLFdBQVcsRUFDWCxZQUFZLEVBa0JaLEtBQUssRUFJTCxJQUFJOzs7O0FBeEJKLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsU0FBUyxDQUFDLE9BQU87QUFDdkQsMkJBQVcsR0FBTSxPQUFPLFNBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXO0FBQ3hELDRCQUFZLEdBQU0sT0FBTyxTQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsWUFBWTs7O2dEQUd4RCxxQkFBUSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFHN0IscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFJdEIscUJBQVEsS0FBSyxDQUFDLFdBQVcsQ0FBQzs7Ozs7Ozs7Ozs7OztnREFJMUIscUJBQVEsS0FBSyxDQUFDLFlBQVksQ0FBQzs7Ozs7Ozs7Ozs7QUFJN0IscUJBQUssR0FBRyxzQ0FBb0I7O2dEQUM1QixLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUcxQixvQkFBSSxHQUFHLHdDQUFhOztBQUMxQixxQ0FBTyxTQUFTLENBQUMsYUFBRyxFQUFJO0FBQ3RCLHNCQUFNLElBQUksR0FBRyxxQkFBUSxnQkFBZ0IsQ0FBSSxXQUFXLFNBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLFVBQU8sQ0FDckYsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDO0FBQ25DLHNCQUFNLEtBQUssR0FBRyxxQkFBYTtBQUN6Qiw4QkFBVSxFQUFFLElBQUk7QUFDaEIseUJBQUssRUFBQyxlQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFO0FBQ2hDLDBCQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUM7QUFDbEMsOEJBQVEsRUFBRTtxQkFDWDtBQUNELHlCQUFLLEVBQUMsZUFBQyxRQUFRLEVBQUU7QUFDZiw4QkFBUSxFQUFFO0FBQ1YseUJBQUcsRUFBRTtxQkFDTjttQkFDRixDQUFDOztBQUVGLHNCQUFJLENBQUMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNsQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyxpQkFBSSxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUNmLENBQUMsRUFBRTs7O0FBR0osc0JBQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxxQkFBVyxFQUFJO0FBQ2pELHNCQUFJO0FBQ0YseUNBQU8sU0FBUyxDQUFDLGFBQUcsRUFBSTtBQUN0QiwwQkFBTSxJQUFJLEdBQUcscUJBQVEsZ0JBQWdCLENBQUksV0FBVyxTQUFJLFdBQVcsQ0FBQyxPQUFPLFVBQU8sQ0FDL0UsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFNO0FBQUUsMkJBQUcsRUFBRTt1QkFBRSxDQUFDO0FBQy9CLDBCQUFNLFNBQVMsR0FBRyxzQkFBYztBQUM5QiwwQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLDBDQUFrQixFQUFFLElBQUk7QUFDeEIsaUNBQVMsRUFBRSxtQkFBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBSztBQUN4Qyw4QkFBSSxNQUFNO0FBQ1YsOEJBQUk7QUFDRixxREFBTSxZQUFNO0FBQ1Ysb0NBQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUM7QUFDckQsc0NBQVEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDOzZCQUN2QixDQUFDLENBQUMsR0FBRyxFQUFFOzJCQUNULENBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCwrQkFBRyxDQUFDLEtBQUssQ0FBQzsyQkFDWDt5QkFDRjt1QkFDRixDQUFDO0FBQ0YsMEJBQU0sS0FBSyxHQUFHLHFCQUFRLGlCQUFpQixDQUFJLFlBQVksU0FBSSxXQUFXLENBQUMsUUFBUSxVQUFPLENBQ25GLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBTTtBQUNsQiw4QkFBTSxDQUFDLFFBQVEsRUFBRTtBQUNqQiwyQkFBRyxFQUFFO3VCQUNOLENBQUMsQ0FDRCxFQUFFLENBQUMsT0FBTyxFQUFFLGVBQUssRUFBSTtBQUFFLDJCQUFHLENBQUMsS0FBSyxDQUFDO3VCQUFFLENBQUM7O0FBRXZDLDBCQUFJLENBQ0QsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyxpQkFBSSxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLE9BQU8sS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDdEUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUNmLElBQUksQ0FBQyxpQkFBSSxTQUFTLENBQUMsRUFBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUMsQ0FDbEQsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUM7cUJBQ2YsQ0FBQyxFQUFFO21CQUNMLENBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCwwQkFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7bUJBQ3JCO2lCQUNGLENBQUM7Ozs7Ozs7U0FDSCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FNUyxHQUFHLGdCQUFhLG9CQUFDLE1BQU07TUFFM0IsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsbUJBQW1CLEVBQ25CO2NBQ1EsT0FBTyxFQVNMLGNBQWMsRUFHZCxJQUFJLEVBRUosUUFBUTs7OztBQWRWLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU87OztnREFHcEQscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7Z0RBRzdCLHFCQUFRLEtBQUssQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7OztBQUd0Qiw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBRW5DLG9CQUFJLEdBQUcsY0FBYyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxHQUFHLEVBQUUsRUFBRSxFQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRTs7QUFFN0Qsd0JBQVEsR0FBRyxTQUFYLFFBQVEsQ0FBSSxJQUFJLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBSztBQUN2QyxzQkFBTSxPQUFPLEdBQUcsc0JBQWM7QUFDNUIsc0NBQWtCLEVBQUUsSUFBSTtBQUN4QixzQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLDZCQUFTLEVBQUMsbUJBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUU7QUFDcEMsK0NBQU0sWUFBTTtBQUNWLDRCQUFNLElBQUksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQ3RCLGdDQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQzt1QkFDckIsQ0FBQyxDQUFDLEdBQUcsRUFBRTtxQkFDVDttQkFDRixDQUFDO0FBQ0Ysc0JBQUksS0FBSyxHQUFHLENBQUM7QUFDYixzQkFBTSxRQUFRLEdBQUcsc0JBQWM7QUFDN0IsNEJBQVEsRUFBRSxNQUFNO0FBQ2hCLDZCQUFTLEVBQUUsbUJBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUs7QUFDeEMsMEJBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDMUIsMEJBQUksS0FBSyxLQUFLLENBQUMsRUFBRTtBQUNmLDJCQUFHLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO3VCQUNoQztBQUNELDJCQUFLLEVBQUU7QUFDUCw4QkFBUSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUM7cUJBQ3BCO21CQUNGLENBQUM7QUFDRixzQkFBTSxRQUFRLEdBQUcscUJBQVEsaUJBQWlCLENBQUksUUFBUSxVQUFPO0FBQzdELDBCQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxXQUFDLEVBQUk7QUFBRSwwQkFBTSxxQkFBTyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7bUJBQUUsQ0FBQzs7QUFFbkUsc0JBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQ2YsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FBQyxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ25DLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FDZCxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLFFBQVEsQ0FBQztpQkFDbEI7O0FBRUQsd0JBQVEsQ0FDTixJQUFJLEVBQ0osaUNBQWUsc0JBQXNCLEVBQ2xDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FDMUM7O0FBRUQsd0JBQVEsQ0FDTixJQUFJLEVBQ0osaUNBQWUsd0JBQXdCLEVBQ3BDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FDNUM7OztzQkFHRyxJQUFJLHFCQUFPLEtBQUssa0NBQWdDLE9BQU8sT0FBSTs7Ozs7OztTQUNsRSxDQUNGOzs7Ozs7O0NBQ0Ysb0JBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQzVUaUIsd0JBQXdCOzs7O3NDQUdwQyw2QkFBNkI7O2dDQUNsQix1QkFBdUI7Ozs7NEJBQ3BCLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLE1BQU07O0FBRWhCLHFCQUFPLE9BQU8scUJBS0YsR0FBRyxZQUFTLG9CQUFDLE1BQU07TUFFdkIsTUFBTSxFQUVOLE1BQU0sRUFFSixRQUFROzs7Ozs7QUFKVixjQUFNLEdBQUcsb0NBQVk7QUFFckIsY0FBTSxHQUFHLDBDQUFrQixNQUFNLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7O3dDQUV2QyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxvQkFBTyxDQUFDOzs7O3NCQUMxQyxDQUFDOzs7Ozs7O1NBQ1IsQ0FBQzs7O0FBRkksZ0JBQVE7O3dDQUdSLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLFVBQVUsRUFDVjs7OztvREFDUyxRQUFROzs7Ozs7O1NBQ2hCLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLEVBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDaENpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7bUNBQ1QsMEJBQTBCOzs7OzRCQUVoQyxlQUFlOzt1QkFDaEIsVUFBVTs7Ozs4QkFFVixpQkFBaUI7Ozs7c0NBQ2hCLDZCQUE2Qjs7OztnQ0FDNUIsdUJBQXVCOzs7O0FBRTdDLElBQU0sR0FBRyxHQUFHLE9BQU87O0FBRW5CLHFCQUFPLE9BQU8seURBS0YsR0FBRyx1QkFBb0Isb0JBQUMsTUFBTTtNQUVsQyxNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixrQkFBa0IsRUFDbEI7Y0FHUSxjQUFjLEVBS2hCLEdBQUcsRUE0Q0gsR0FBRzs7Ozs7O0FBakRELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUl6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7cUJBa0JGO21CQUNGO2lCQUNGLEVBQ0Q7O0FBRUUsd0JBQU0sRUFBRTtBQUNOLHVCQUFHLEVBQUUsc0JBQXNCO21CQUM1QjtpQkFDRixFQUNEO0FBQ0UsMEJBQVEsRUFBRTtBQUNSLHVCQUFHLEVBQUUsQ0FBQztBQUNOLDRCQUFRLEVBQUUsTUFBTTttQkFDakI7aUJBQ0YsQ0FDRixDQUNGOzs7QUF6Q0csbUJBQUc7QUE0Q0gsbUJBQUcsR0FBRyx3Q0FBYSxNQUFNLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7O2dEQUNwRCxNQUFNLENBQUMsZUFBZSxDQUMxQixHQUFHLEVBQ0gsb0JBQU0sSUFBSTtzQkFHRixHQUFHOzs7O0FBRlQsOEJBQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxRQUFRLFdBQVEsQ0FBQzs7O3dEQUUxQixHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQzs7O0FBQWhDLDJCQUFHOzREQUNBLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFDOzs7Ozs4QkFFbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUMsRUFBRSw4QkFBVSxLQUFLLGdCQUFHLENBQUM7Ozs7Ozs7aUJBRS9ELENBQ0Y7Ozs7Ozs7U0FDRixDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGlDQUE4QixvQkFBQyxNQUFNO01BRTVDLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLHFCQUFxQixFQUNyQjtjQUdRLGNBQWMsRUFLaEIsR0FBRyxFQTRDSCxHQUFHOzs7Ozs7QUFqREQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBSXpCLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUM1QyxDQUNFO0FBQ0Usd0JBQU0sRUFBRTtBQUNOLHdCQUFJLEVBQUUsQ0FDSjtBQUNFLDJDQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtxQkFDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFrQkY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRSxzQkFBc0I7bUJBQzVCO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO21CQUNqQjtpQkFDRixDQUNGLENBQ0Y7OztBQXpDRyxtQkFBRztBQTRDSCxtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Z0RBQ3BELE1BQU0sQ0FBQyxlQUFlLENBQzFCLEdBQUcsRUFDSCxvQkFBTSxJQUFJO3NCQUdGLEdBQUc7Ozs7eUNBRlQsTUFBTTt5Q0FBUSxJQUFJOzt3REFBUSxjQUFjLENBQUMsb0NBQW9DLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQzs7Ozt1Q0FBckYsTUFBTTs7O3dEQUVLLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDOzs7QUFBaEMsMkJBQUc7NERBQ0EsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUM7Ozs7OzhCQUVuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBQyxFQUFFLDhCQUFVLEtBQUssZ0JBQUcsQ0FBQzs7Ozs7OztpQkFFL0QsQ0FDRjs7Ozs7OztTQUNGLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUtTLEdBQUcsdUJBQW9CLG9CQUFDLE1BQU07TUFFbEMsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsMEJBQTBCLEVBQzFCO2NBR1EsY0FBYyxFQUtoQixHQUFHLEVBeUNILEdBQUc7Ozs7OztBQTlDRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFJekIsY0FBYyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQzVDLENBQ0U7QUFDRSx3QkFBTSxFQUFFO0FBQ04sd0JBQUksRUFBRSxDQUNKO0FBQ0UsMkNBQXFCLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFO3FCQUN0Qzs7Ozs7Ozs7Ozs7Ozs7O3FCQWVGO21CQUNGO2lCQUNGLEVBQ0Q7O0FBRUUsd0JBQU0sRUFBRTtBQUNOLHVCQUFHLEVBQUUsc0JBQXNCO21CQUM1QjtpQkFDRixFQUNEO0FBQ0UsMEJBQVEsRUFBRTtBQUNSLHVCQUFHLEVBQUUsQ0FBQztBQUNOLDRCQUFRLEVBQUUsTUFBTTttQkFDakI7aUJBQ0YsQ0FDRixDQUNGOzs7QUF0Q0csbUJBQUc7QUF5Q0gsbUJBQUcsR0FBRyx3Q0FBYSxNQUFNLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7O2dEQUNwRCxNQUFNLENBQUMsZUFBZSxDQUMxQixHQUFHLEVBQ0gsb0JBQU0sSUFBSTtzQkFJRixHQUFHOzs7O0FBSFQsNEJBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQztBQUNuQiw0QkFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNOzs7d0RBRVQsR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7OztBQUFoQywyQkFBRzs0REFDQSxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBQzs7Ozs7OEJBRW5DLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFDLEVBQUUsOEJBQVUsS0FBSyxnQkFBRyxDQUFDOzs7Ozs7O2lCQUUvRCxDQUNGOzs7Ozs7O1NBQ0YsQ0FDRjs7OzRDQUVNLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBS1MsR0FBRyxtQkFBZ0Isb0JBQUMsTUFBTTtNQUU5QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixhQUFhLEVBQ2I7Y0FHUSxjQUFjLEVBR2hCLEdBQUcsRUFrRUQsSUFBSSxrRkFHQyxDQUFDLEVBT04sR0FBRyxFQUVELEdBQUc7Ozs7O0FBakZMLDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUV6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7cUJBZUY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRTtBQUNILDhCQUFRLEVBQUUsc0JBQXNCO0FBQ2hDLGdEQUEwQixFQUFFLHlCQUF5QjtBQUNyRCw4Q0FBd0IsRUFBRSx5QkFBeUI7cUJBQ3BEO0FBQ0Qsd0JBQUksRUFBRTtBQUNKLDRCQUFNLEVBQUUsTUFBTTtxQkFDZjttQkFDRjtpQkFDRixFQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFLGVBQWU7QUFDcEIsOEJBQVUsRUFBRTtBQUNWLDJCQUFLLEVBQUU7QUFDTCwyQkFBRyxFQUFFLE9BQU87QUFDWixrREFBMEIsRUFBRSxpQ0FBaUM7QUFDN0QsZ0RBQXdCLEVBQUUsK0JBQStCO3VCQUMxRDtxQkFDRjttQkFDRjtpQkFDRixFQUNEO0FBQ0UsMEJBQVEsRUFBRTtBQUNSLHVCQUFHLEVBQUUsQ0FBQztBQUNOLDRCQUFRLEVBQUUsTUFBTTtBQUNoQiw4QkFBVSxFQUFFLGFBQWE7bUJBQzFCO2lCQUNGLENBQ0YsQ0FDRjs7O0FBM0RHLG1CQUFHOzs7O2dEQWlFTSxHQUFHLENBQUMsT0FBTyxFQUFFOzs7Ozs7Ozs7Z0RBQ1AsR0FBRyxDQUFDLElBQUksRUFBRTs7O0FBQXZCLG9CQUFJOzs7Ozs0QkFHTSxJQUFJLENBQUMsVUFBVTs7Ozs7Ozs7QUFBcEIsaUJBQUM7O2dEQUNRLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTlDLGlCQUFDLENBQUMsS0FBSzs7QUFDUCx1QkFBTyxDQUFDLENBQUMsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS1YsbUJBQUcsR0FBRyx3Q0FBYSxNQUFNLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7OztnREFFeEMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDOzs7QUFBbkMsbUJBQUc7O0FBQ1Asc0JBQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDOzs7Ozs7OztBQUVwQixzQkFBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7Ozs7QUFHcEIsbUJBQUcsQ0FBQyxLQUFLLEVBQUU7Ozs7Ozs7U0FDWixDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGtCQUFlLG9CQUFDLE1BQU07TUFFN0IsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBSVEsTUFBTSxFQUNOLGNBQWMsRUFTZCxPQUFPLEVBU1QsR0FBRzs7Ozs7O0FBbkJELHNCQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Z0RBSWpDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7OztBQUkvQix1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPLGVBQVcsSUFBSSxJQUFJLEVBQUUsQ0FBRSxPQUFPLEVBQUU7OztnREFHekQscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7O2dEQU1kLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3hCLE9BQU8sRUFJUCxLQUFLLEVBQ0wsUUFBUTs7OztBQUxSLGlDQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQzs7QUFDekQsaUNBQU8sQ0FBQyxHQUFHLEdBQU0sT0FBTyxDQUFDLEdBQUcsb0JBQWlCO0FBQzdDLGlDQUFPLENBQUMsRUFBRSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFROzs7MERBRTVCLGlDQUFRLE9BQU8sQ0FBQzs7O0FBQTlCLCtCQUFLO0FBQ0wsa0NBQVEsR0FBTSxPQUFPLFNBQUksSUFBSSxDQUFDLEtBQUs7OzBEQUVqQyxxQkFBUSxTQUFTLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQzs7Ozs7OzttQkFDekMsRUFBQyxDQUFDOzs7QUFYRCxtQkFBRztvREFhQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0JBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQzFaaUIsd0JBQXdCOzs7O3NDQUdwQyw2QkFBNkI7O21DQUNULDBCQUEwQjs7Ozs0QkFFaEMsZUFBZTs7QUFFcEMsSUFBTSxHQUFHLEdBQUcsVUFBVTs7QUFFdEIscUJBQU8sT0FBTyxxQkFLRixHQUFHLGVBQVksb0JBQUMsTUFBTTtNQUUxQixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixlQUFlLEVBQ2Y7Y0FJUSxNQUFNLEVBQ04sY0FBYyxFQWtCaEIsR0FBRzs7Ozs7O0FBbkJELHNCQUFNLEdBQUcsK0NBQXVCLE1BQU0sQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNoRSw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFpQnpCLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87Ozs7QUFDNUIsZ0NBQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDOzs7Ozs7O21CQUN0QixFQUFDLENBQUM7OztBQUpELG1CQUFHO29EQU1BLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixFQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRCQ3ZEcUIsZUFBZTs7dUJBQ2xCLFVBQVU7Ozs7eUJBRVosWUFBWTs7Ozt3QkFDVCxVQUFVOzs7O21CQUNmLEtBQUs7Ozs7c0JBQ2tCLFFBQVE7O2lDQUM1Qix3QkFBd0I7Ozs7bUNBQ2hCLDBCQUEwQjs7OztzQ0FHOUMsNkJBQTZCOztpQ0FDakIsd0JBQXdCOzs7O0FBRTNDLElBQU0sTUFBTSxHQUFHLFFBQVEsQ0FBQztBQUN4QixJQUFNLEdBQUcsR0FBRyxPQUFPLENBQUM7O0FBRXBCLHFCQUFPLE9BQU8seURBS0YsR0FBRyxhQUFVLG9CQUFDLE1BQU07TUFFdEIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFckIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsUUFBUSxFQUNSO2NBQ1EsY0FBYyxFQUVkLE9BQU8sRUFDUCxDQUFDLEVBQ0QsQ0FBQzs7Ozs7O0FBSkQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUNuQyx1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPO0FBQzNCLGlCQUFDLEdBQUcscUJBQVEsZ0JBQWdCLENBQUksT0FBTyxTQUFJLE1BQU0sQ0FBQyxhQUFhLENBQUc7QUFDbEUsaUJBQUMsR0FBRyxxQkFBUSxpQkFBaUIsQ0FBSSxPQUFPLFNBQUksTUFBTSxDQUFDLGFBQWEsQ0FBRzs7QUFDekUsaUJBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQy9CLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLGlCQUFJLEtBQUssQ0FBQyxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQ2xDLElBQUksQ0FBQyxpQkFBSSxTQUFTLENBQ2pCLG9CQUFPLE1BQU0sRUFBRSxRQUFRO3NCQUNqQixHQUFHOzs7O0FBQUgsMkJBQUcsR0FBRyxJQUFJOzs7d0RBR1csY0FBYyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7OztBQUFuRSw4QkFBTSxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7QUFFZCwyQkFBRyxpQkFBSSxDQUFDOzs7QUFFVixnQ0FBUSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUMsQ0FBQzs7Ozs7OztpQkFDdkIsQ0FDRixDQUFDLENBQ0QsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQ3JDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7U0FDWixDQUNGOzs7Ozs7O0NBQ0Ysb0NBS1MsR0FBRyxlQUFZLG9CQUFDLE1BQU07TUFFeEIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFckIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsUUFBUSxFQUNSO2NBSVEsTUFBTSxFQUNOLGNBQWMsRUFJZCxNQUFNLEVBUU4sT0FBTyxFQUtQLFNBQVMsRUFJWCxFQUFFLEVBQ0YsUUFBUSxFQUNSLElBQUksRUFHRixNQUFNLEVBQ04sTUFBTSxFQTZDTixHQUFHOzs7Ozs7QUF6RUgsc0JBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFHbkMsc0JBQU0sR0FBRyxtQ0FBVyxNQUFNLENBQUMsVUFBVSxDQUFDOzs7Z0RBSXBDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7OztBQUkvQix1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPOztnREFDM0IscUJBQVEsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFDdkIscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7O0FBR3RCLHlCQUFTLEdBQU0sTUFBTSxDQUFDLE9BQU87O2dEQUM3QixxQkFBUSxNQUFNLENBQUMsU0FBUyxDQUFDOzs7O2dEQUN6QixxQkFBUSxLQUFLLENBQUMsU0FBUyxDQUFDOzs7QUFFMUIsa0JBQUUsR0FBRyxJQUFJO0FBQ1Qsd0JBQVEsR0FBRyxJQUFJO0FBQ2Ysb0JBQUksR0FBRyxJQUFJO0FBR1Qsc0JBQU0sR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFdBQVcsRUFBRSxvQkFBb0IsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsZ0JBQWdCLENBQUM7QUFDOXBDLHNCQUFNLEdBQU0sTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFDOytCQUFRLENBQUM7aUJBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUdyRCxzQkFBTSxDQUFDLGFBQWEsR0FBRyxvQkFBTyxXQUFXOzs7O0FBQ3ZDLDRCQUFJLEdBQUcsTUFBTSxHQUFHLFdBQVMsV0FBVyxFQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2xELDBCQUFFLEdBQU0sT0FBTyxTQUFJLElBQU0sQ0FBQztBQUMxQixnQ0FBUSxHQUFNLEVBQUUsU0FBSSxNQUFNLENBQUMsV0FBYSxDQUFDOzt3REFDbkMscUJBQVEsS0FBSyxDQUFDLEVBQUUsQ0FBQzs7Ozt3REFFakIscUJBQVEsVUFBVSxDQUFDLFFBQVEsRUFBRSx1QkFBTSxNQUFNLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDOzs7Ozs7O2lCQUN0RSxDQUFDOzs7QUFHRixzQkFBTSxDQUFDLFFBQVEsR0FBRyxvQkFBTyxHQUFHO3NCQUNwQixLQUFLLEVBQ0wsSUFBSSxFQUVKLE1BQU0sa0ZBR0QsR0FBRyxFQUNOLE1BQU0sRUFDTixNQUFNOzs7OztBQVJSLDZCQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUs7QUFDakIsNEJBQUksR0FBRyxHQUFHLENBQUMsSUFBSTtBQUVmLDhCQUFNLEdBQU0sTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFDO2lDQUFLLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQU0sSUFBSTt5QkFBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7d0RBQzFFLHFCQUFRLFVBQVUsQ0FBQyxRQUFRLEVBQUUsdUJBQU0sTUFBTSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQzs7Ozs7OztvQ0FFbkQsSUFBSSxDQUFDLE1BQU07Ozs7Ozs7O0FBQWxCLDJCQUFHO0FBQ04sOEJBQU0sR0FBTSxNQUFNLENBQUMsUUFBUSxTQUFJLEdBQUc7QUFDbEMsOEJBQU0sR0FBTSxFQUFFLFNBQUksR0FBRzs7O3dEQUduQixxQkFBUSxNQUFNLENBQUMsTUFBTSxDQUFDOzs7Ozs7Ozs7O3dEQUV0QixxQkFBUSxRQUFRLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQkFHM0MsQ0FBQzs7O0FBR0Ysc0JBQU0sQ0FBQyxXQUFXLEdBQUcsb0JBQU8sV0FBVztzQkFDL0IsR0FBRyxFQUNILE9BQU8sRUFDUCxNQUFNOzs7O0FBRk4sMkJBQUcsR0FBRywyQkFBUyxLQUFLLENBQUM7QUFDckIsK0JBQU8sR0FBTSxTQUFTLFNBQUksSUFBSTtBQUM5Qiw4QkFBTSxHQUFHLHFCQUFRLGlCQUFpQixDQUFDLE9BQU8sQ0FBQzs7QUFDakQsMkJBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDakIsMkJBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQyxDQUFDO0FBQ3pCLDJCQUFHLENBQUMsUUFBUSxFQUFFLENBQUM7Ozs7Ozs7aUJBQ2hCLENBQUM7Ozs7OztnREFLZ0IsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7QUFFL0Isd0JBQU0sRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDcEIsUUFBUSxFQUdOLEtBQUs7Ozs7OzBEQUhVLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7O0FBQWxELGtDQUFROztnQ0FFVixRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVzs7Ozs7OzBEQUNyQixjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxXQUFRLEVBQUUsSUFBSSxDQUFDOzs7QUFBbkUsK0JBQUs7OzBEQUNMLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBRSxLQUFLLEVBQUwsS0FBSyxFQUFFLElBQUksRUFBSixJQUFJLEVBQUUsQ0FBQzs7Ozs7OzttQkFFdkM7aUJBQ0YsQ0FBQzs7O0FBVkksbUJBQUc7O0FBWVQsc0JBQU0sQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7b0RBRVIsR0FBRzs7Ozs7OztTQUNYLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9CQUVELENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7UUNyS0ksd0JBQXdCOztRQUN4QixzQkFBc0IsRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkNDdEIsY0FBYzs7eUJBQ0gsZUFBZTs7Ozs0QkFHMUIsZUFBZTs7OztvQkFHTCxNQUFNOzs7OzJCQUNILGFBQWE7Ozs7c0JBQ1AsVUFBVTs7QUFFcEMsSUFBTSxPQUFPLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsU0FBUyxFQUFFO0FBQzlDLGNBQVksRUFBRSxPQUFPO0NBQ3RCLENBQUMsQ0FBQzs7SUFFVSxNQUFNO1lBQU4sTUFBTTs7QUFFTixXQUZBLE1BQU0sQ0FFTCxRQUFRLEVBQUU7OzswQkFGWCxNQUFNOztBQUlmLFFBQUksT0FBTyxHQUFHLE9BQU8sQ0FBQyxPQUFPLENBQUM7QUFDNUIsU0FBRyxFQUFFLFFBQVE7S0FDZCxDQUFDLENBQUM7O0FBRUgsK0JBUlMsTUFBTSw2Q0FRVCxPQUFPLEVBQUU7O0FBRWYsUUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDOztBQUUxQixZQUFRLElBQUksQ0FBQyxJQUFJOztBQUVmLFdBQUssT0FBTztBQUNWLFlBQUksQ0FBQyxLQUFLLEdBQUcsMkJBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xDLFlBQUksVUFBTyxHQUFHO2NBQVEsUUFBUSx5REFBRyxVQUFDLE1BQU0sRUFBRyxFQUFFO2NBQUUsT0FBTyx5REFBRyxVQUFDLENBQUMsRUFBRyxFQUFFO2NBQzFELEdBQUc7Ozs7QUFBSCxtQkFBRyxzQkFBb0IsSUFBSSxDQUFDLEtBQUs7O2dEQUN4QixJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsUUFBUSxFQUFFLE9BQU8sQ0FBQzs7Ozs7Ozs7OztTQUMvRCxDQUFDO0FBQ0YsY0FBTTs7QUFFUjtBQUNFLGNBQU0sSUFBSSxLQUFLLENBQUMsdUJBQXVCLENBQUMsQ0FBQzs7QUFBQSxLQUU1QztHQUNGOzs7Ozs7O2VBMUJVLE1BQU07O1dBZ0NKOzs7VUFBQyxTQUFTLHlEQUFHLEVBQUU7VUFBRSxPQUFPLHlEQUFHLG9CQUFPLENBQUM7Ozs7Ozs7O09BQU87O1VBRWpELE9BQU8sRUFRUCxLQUFLLGtGQUNBLE1BQU07Ozs7Ozs7QUFUWCxtQkFBTyxHQUFHLElBQUksQ0FBQyxVQUFVLEVBQUU7OztBQUcvQixtQkFBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDbkIsa0JBQUksRUFBRSxNQUFNO0FBQ1osbUJBQUssRUFBRSxFQUFFO2FBQ1YsQ0FBQzs7QUFFRSxpQkFBSyxHQUFHLEVBQUU7Ozs7OztBQUNkLDZCQUFtQixPQUFPLENBQUMsT0FBTyx1SEFBRTtBQUEzQixvQkFBTTs7QUFDYixtQkFBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRztBQUNuQixxQkFBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLHFCQUFLLEVBQUUsQ0FBQztlQUNULENBQUM7YUFDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFSyxJQUFJLFVBQU8sQ0FDZixvQkFBTyxNQUFNO3VHQUNGLE1BQU0sRUFDVCxLQUFLLEVBQ0wsSUFBSTs7Ozs7Ozs7O2lDQUZTLE9BQU8sQ0FBQyxPQUFPOzs7Ozs7OztBQUF6QiwwQkFBTTtBQUNULHlCQUFLLEdBQUcseUJBQVEsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7QUFDdEMsd0JBQUksR0FBRyx1QkFBTSxLQUFLLENBQUU7O3lCQUNwQixJQUFJLENBQUMsTUFBTSxDQUFDOzs7OztBQUNkLHlCQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDOzswQkFDdkIsT0FBTyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLFdBQVc7Ozs7OztvREFDekMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7YUFLM0MsRUFDRCxPQUFPLENBQ1I7OztnREFHTSxLQUFLOzs7Ozs7O0tBRWI7OztTQXRFVSxNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MkJDZlosY0FBYzs7eUJBQ0gsZUFBZTs7Ozs0QkFHMUIsZUFBZTs7QUFFdEIsSUFBTSxNQUFNLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsUUFBUSxFQUFFO0FBQzVDLGNBQVksRUFBRSxPQUFPO0NBQ3RCLENBQUMsQ0FBQzs7SUFFVSxTQUFTO0FBSVQsV0FKQSxTQUFTLENBSVIsT0FBTyxFQUFFOzBCQUpWLFNBQVM7O0FBS2xCLFFBQUksQ0FBQyxPQUFPLEdBQUcsT0FBTyxDQUFDO0dBQ3hCOzs7Ozs7OztlQU5VLFNBQVM7O1dBYWIsbUJBQUc7QUFDUixhQUFPLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO0tBQ2xDOzs7V0FFUyxzQkFBRztBQUNYLGFBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztLQUNyQjs7O1dBRU0sbUJBQTZEOzs7VUFBNUQsUUFBUSx5REFBRyxvQkFBTyxNQUFNOzs7Ozs7OztPQUFPO1VBQUUsT0FBTyx5REFBRyxvQkFBTyxDQUFDOzs7Ozs7OztPQUFPO0tBQUk7OztTQXJCM0QsU0FBUzs7Ozs7SUF5QlQsS0FBSztZQUFMLEtBQUs7O0FBRUwsV0FGQSxLQUFLLENBRUosT0FBTyxFQUFFOzs7MEJBRlYsS0FBSzs7QUFJZCxRQUFJLE9BQU8sR0FBRyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzNCLFNBQUcsRUFBRSxPQUFPO0tBQ2IsQ0FBQyxDQUFDOztBQUVILCtCQVJTLEtBQUssNkNBUVIsT0FBTyxFQUFFOztBQUVmLFFBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs7QUFFMUIsWUFBUSxJQUFJLENBQUMsSUFBSTtBQUNmLFdBQUssT0FBTztBQUNWLFlBQUksQ0FBQyxLQUFLLEdBQUcsMkJBQVUsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDO0FBQ2xDLFlBQUksVUFBTyxHQUFHLG9CQUFPLEdBQUc7Y0FDbEIsR0FBRzs7OztBQUFILG1CQUFHLHNCQUFvQixJQUFJLENBQUMsS0FBSyxnQkFBWSxHQUFHLENBQUMsR0FBRyxhQUFTLEdBQUcsQ0FBQyxFQUFFOztnREFDMUQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7Ozs7Ozs7O1NBQ25DLENBQUM7QUFDRixjQUFNO0FBQ1I7QUFDRSxjQUFNLElBQUksS0FBSyxDQUFDLG9CQUFvQixDQUFDLENBQUM7QUFBQSxLQUN6QztHQUVGOzs7Ozs7O2VBeEJVLEtBQUs7O1dBK0JULG1CQUE2RDs7O1VBQTVELFFBQVEseURBQUcsb0JBQU8sTUFBTTs7Ozs7Ozs7T0FBTztVQUFFLE9BQU8seURBQUcsb0JBQU8sQ0FBQzs7Ozs7Ozs7T0FBTzs7QUFFaEUsVUFBSSxHQUFHLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQztBQUNwQixlQUFPLEVBQUUsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHO09BQzFCLEVBQUU7QUFDRCxjQUFNLEVBQUU7QUFDTixhQUFHLEVBQUUsQ0FBQztBQUNOLFlBQUUsRUFBRSxDQUFDO0FBQ0wsYUFBRyxFQUFFLENBQUM7U0FDUDtPQUNGLENBQUMsQ0FBQzs7QUFFSCxhQUFPLElBQUksT0FBTyxDQUNoQixVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUs7O0FBRW5CLFdBQUcsQ0FBQyxPQUFPLENBQ1Qsb0JBQU8sR0FBRyxFQUFFLEtBQUs7Y0FFVCxNQUFNOzs7Ozs7Z0RBQVMsSUFBSSxVQUFPLENBQUMsR0FBRyxDQUFDOzs7QUFBL0Isc0JBQU07O2dEQUNKLFFBQVEsQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7Ozs7QUFFdEIsdUJBQU8sZ0JBQUcsQ0FBQzs7O0FBRWIsb0JBQUksS0FBSyxHQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUU7QUFDN0IseUJBQU8sRUFBRSxDQUFDO2lCQUNYOzs7Ozs7O1NBQ0YsQ0FBQyxDQUFDO09BRU4sQ0FDRixTQUFNLENBQ0wsVUFBQyxDQUFDLEVBQUs7QUFDTCxjQUFNLENBQUMsQ0FBQztPQUNULENBQ0YsQ0FBQztLQUVIOzs7U0FsRVUsS0FBSztHQUFTLFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQ3JDbEIsZUFBZTs7Ozs4QkFDVixvQkFBb0I7Ozs7SUFFOUIsUUFBUTs7Ozs7O0FBS1IsV0FMQSxRQUFRLENBS1AsS0FBSyxFQUFFOzBCQUxSLFFBQVE7O0FBTWpCLFFBQUksQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO0dBQ3BCOztlQVBVLFFBQVE7O1dBU0Msd0JBQUMsU0FBUyxFQUFFLGVBQWU7VUFDdkMsYUFBYSxFQUdiLE1BQU0sRUFTTixHQUFHLEVBT0gsTUFBTSxFQU9OLE9BQU87Ozs7OztBQTFCUCx5QkFBYSxHQUFHLHNCQUFzQjtBQUd0QyxrQkFBTSxHQUFHLEVBQUU7O0FBQ2pCLDJCQUFlLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFLO0FBQ2hDLG9CQUFNLENBQUMsSUFBSSxDQUFDO0FBQ1YsMEJBQVUsRUFBRSxTQUFTO0FBQ3JCLDJCQUFXLEVBQUUsSUFBSTtlQUNsQixDQUFDLENBQUM7YUFDSixDQUFDLENBQUM7OztBQUdHLGVBQUcsdURBRUYsYUFBYSxpQ0FDQyxTQUFTOzs0Q0FJVCxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDekMsYUFBYSxvQkFDRyxTQUFTLEVBQ3pCLHlCQUF5QixDQUMxQjs7O0FBSkssa0JBQU07QUFPTixtQkFBTyxHQUFHLEVBQUU7OzRDQUVaLGlDQUNKLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUNwQixvQkFBTyxFQUFFLEVBQUUsTUFBTTtrQkFDVCxHQUFHOzs7OztvREFBUyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDdEMsYUFBYSxFQUNiLEVBQUUsRUFDRixNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLENBQUMsRUFBRSxFQUFFLE1BQU0sQ0FBQyxDQUNuQzs7O0FBSkssdUJBQUc7O0FBS1QsMkJBQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Ozs7Ozs7YUFDbkIsRUFDRCxvQkFBTyxFQUFFLEVBQUUsTUFBTTtrQkFDVCxHQUFHOzs7OztvREFBUyxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssOEJBRWxCLGFBQWEsdUNBQ04sTUFBTSxDQUFDLFVBQVUsd0NBQ2hCLE1BQU0sQ0FBQyxXQUFXLGtCQUV6Qzs7O0FBTkssdUJBQUc7O0FBT1QsMkJBQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUM7Ozs7Ozs7YUFDbkIsQ0FDRjs7O2dEQUVNLE9BQU87Ozs7Ozs7S0FDZjs7O1dBRWdCLHFCQUFDLGNBQWM7VUFBRSxRQUFRLHlEQUFHLENBQUM7Ozs7OzRDQUN0QyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDMUIsbUJBQW1CLDBCQUNHLGNBQWMsRUFDcEMsRUFBRSxFQUFFO0FBQ0YsbUJBQUssRUFBRSxRQUFRO0FBQ2YsNkJBQWUsRUFBRSxDQUFDO0FBQ2xCLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7OzRDQUVLLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUMxQixtQkFBbUIsMEJBQ0csY0FBYyxFQUNwQyxFQUFFLEVBQUU7QUFDRixtQkFBSyxFQUFFLFFBQVE7QUFDZix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs7OztLQUNGOzs7V0FFcUIsMEJBQUMsSUFBSTtVQUNuQixTQUFTLEVBRVQsR0FBRyxFQUdILE1BQU0sRUFTTixLQUFLLGtGQXVCQSxNQUFNOzs7Ozs7O0FBckNYLHFCQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVU7QUFFM0IsZUFBRyxHQUFHLEVBQUU7O0FBR1Isa0JBQU0sR0FBRyxTQUFULE1BQU0sQ0FBVSxHQUFHO2tCQUNqQixHQUFHOzs7O0FBQUgsdUJBQUcsdUVBRVksSUFBSSxDQUFDLFVBQVUsbUJBQWMsR0FBRztxQ0FFckQsR0FBRzs7b0RBQVksSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7O21DQUFoQyxJQUFJOzs7Ozs7O2FBQ1Q7O0FBR0ssaUJBQUssR0FBRyxTQUFSLEtBQUssQ0FBVSxHQUFHO2tCQUVoQixHQUFHLEVBSUgsUUFBUTs7OztBQUpSLHVCQUFHLGdGQUVZLElBQUksQ0FBQyxVQUFVLG1CQUFjLEdBQUc7O29EQUU5QixJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUF0Qyw0QkFBUTs7eUJBQ1YsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQzs7Ozs7Ozs7cUNBRTNCLEdBQUc7O29EQUNLLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUMxQixpQkFBaUIsRUFDakIsRUFBRSxFQUNGO0FBQ0UsZ0NBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtBQUMzQix5QkFBRyxFQUFILEdBQUc7QUFDSCxnQ0FBVSxFQUFFLFNBQVM7QUFDckIsaUNBQVcsRUFBRSxPQUFPO3FCQUNyQixDQUNGOzs7O21DQVZDLElBQUk7Ozs7Ozs7YUFZVDs7Ozs7O3dCQUVvQixJQUFJLENBQUMsSUFBSTs7Ozs7Ozs7QUFBbkIsa0JBQU07NkJBQ1AsTUFBTSxDQUFDLEdBQUc7a0RBQ1gsSUFBSSwyQkFHSixLQUFLOzs7Ozs0Q0FGRixLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs0Q0FHakIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnREFLdkI7QUFDTCxpQkFBRyxFQUFILEdBQUc7YUFDSjs7Ozs7OztLQUNGOzs7V0FFdUIsNEJBQUMsSUFBSTtVQUNyQixTQUFTLEVBQ1QsTUFBTSxFQUNOLFNBQVMsRUFFVCxHQUFHLEVBR0gsR0FBRyxFQUdBLENBQUM7Ozs7QUFWSixxQkFBUyxHQUFHLElBQUksQ0FBQyxVQUFVO0FBQzNCLGtCQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU07QUFDcEIscUJBQVMsR0FBRyxJQUFJLENBQUMsVUFBVTtBQUUzQixlQUFHLEdBQUcsRUFBRTtBQUdSLGVBQUcseURBQXVELFNBQVM7NkJBQ3pFLEdBQUc7OzRDQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7OzsyQkFBaEMsSUFBSTtBQUVDLGFBQUMsR0FBRyxDQUFDOzs7a0JBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNOzs7Ozs7NENBQ3pCLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUMxQixtQkFBbUIsRUFBRTtBQUNuQix3QkFBVSxFQUFFLFNBQVM7QUFDckIsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHVCQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQixrQkFBSSxFQUFFLENBQUMsR0FBRyxDQUFDO2FBQ1osRUFBRTtBQUNELHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFWZ0MsYUFBQyxFQUFFOzs7OztnREFhL0I7QUFDTCxpQkFBRyxFQUFILEdBQUc7YUFDSjs7Ozs7OztLQUNGOzs7V0FFa0IsdUJBQUMsSUFBSTtVQUNsQixVQUFVLEVBQ1YsSUFBSSx1RkFzREcsQ0FBQyx1RkFHTixHQUFHOzs7OztBQTFETCxzQkFBVSxHQUFHLEVBQUU7QUFDZixnQkFBSSxHQUFHLEVBQUU7Ozs7QUFJYixnQkFBSSxHQUFHLENBQ0wsUUFBUSxFQUNSLE1BQU0sRUFDTixNQUFNLEVBQ04sa0JBQWtCLEVBQ2xCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2IsV0FBVyxDQUNaLENBQUM7Ozs7O0FBQ0YsOEJBQWdCLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNWLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNYLDBCQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2VBQ3pCO2FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQWtCSyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDMUIsYUFBYSxvQkFDRyxJQUFJLENBQUMsVUFBVSxFQUMvQixVQUFVLEVBQUU7QUFDVix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs7O0FBSUQsc0JBQVUsR0FBRyxFQUFFLENBQUM7QUFDaEIsZ0JBQUksR0FBRyxDQUNMLGtCQUFrQixFQUNsQixjQUFjLEVBQ2QsWUFBWSxFQUNaLFNBQVMsRUFDVCxTQUFTLEVBQ1QsY0FBYyxDQUNmLENBQUM7Ozs7O0FBQ0YsOEJBQWdCLElBQUksMkhBQUU7QUFBWCxlQUFDO0FBQVksa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FHN0MsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ3RDLG1CQUFtQixvQkFDSCxJQUFJLENBQUMsVUFBVSxFQUMvQixVQUFVLEVBQUU7QUFDVix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBTkssZUFBRztnREFRRjtBQUNMLGlCQUFHLEVBQUgsR0FBRzthQUNKOzs7Ozs7O0tBQ0Y7OztXQUVrQix1QkFBQyxJQUFJO1VBQ2hCLFNBQVMsRUFFVCxHQUFHLEVBRUwsVUFBVSxFQUNWLElBQUksdUZBNkRHLENBQUM7Ozs7O0FBbEVOLHFCQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVU7QUFFM0IsZUFBRyxHQUFHLEVBQUU7QUFFVixzQkFBVSxHQUFHLEVBQUU7QUFDZixnQkFBSSxHQUFHLEVBQUU7O0FBRWIsZ0JBQUksR0FBRyxDQUNMLE1BQU0sRUFDTixvQkFBb0IsQ0FDckIsQ0FBQzs7Ozs7Ozs7OztBQU1GLDhCQUFnQixJQUFJLDJIQUFFO0FBQVgsZUFBQztBQUFZLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBR3hDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUMzQyxhQUFhLEVBQ2IsVUFBVSxFQUFFO0FBQ1Ysd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLG9CQUFNLEVBQUUsQ0FBQztBQUNULGtCQUFJLEVBQUUsTUFBTTtBQUNaLDhCQUFnQixFQUFFLE1BQU07QUFDeEIseUJBQVcsRUFBRSxNQUFNO0FBQ25CLHVCQUFTLEVBQUUsTUFBTTtBQUNqQix5QkFBVyxFQUFFLE9BQU87QUFDcEIseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQVpELGVBQUcsQ0FBQyxVQUFVOztBQWNkLHNCQUFVLEdBQUcsRUFBRSxDQUFDO0FBQ2hCLGdCQUFJLEdBQUcsQ0FDTCxjQUFjLEVBQ2QsaUJBQWlCLEVBQ2pCLFNBQVMsRUFDVCxTQUFTLEVBQ1QsY0FBYyxDQUNmLENBQUM7Ozs7Ozs7Ozs7O0FBT0YsOEJBQWdCLElBQUksMkhBQUU7QUFBWCxlQUFDO0FBQVksa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FHbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ2pELG1CQUFtQixFQUNuQixVQUFVLEVBQUU7QUFDVix3QkFBVSxFQUFFLFNBQVM7QUFDckIsd0JBQVUsRUFBRSxHQUFHLENBQUMsVUFBVTtBQUMxQixtQkFBSyxFQUFFLENBQUM7QUFDUiw2QkFBZSxFQUFFLENBQUM7QUFDbEIsZ0NBQWtCLEVBQUUsTUFBTTtBQUMxQixnQ0FBa0IsRUFBRSxNQUFNO0FBQzFCLDhCQUFnQixFQUFFLE1BQU07QUFDeEIsd0JBQVUsRUFBRSxNQUFNO0FBQ2xCLHlCQUFXLEVBQUUsT0FBTztBQUNwQix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBZEQsZUFBRyxDQUFDLGdCQUFnQjs7Ozs7O0FBZ0JwQiw4QkFBZ0IsSUFBSSwySEFBRTtBQUFYLGVBQUM7QUFBWSxrQkFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUdsQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDakQsbUJBQW1CLEVBQUUsRUFBRSxFQUFFO0FBQ3ZCLDhCQUFnQixFQUFFLEdBQUcsQ0FBQyxnQkFBZ0I7QUFDdEMsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLG1CQUFLLEVBQUUsQ0FBQztBQUNSLHlCQUFXLEVBQUUsT0FBTztBQUNwQix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBUkQsZUFBRyxDQUFDLGdCQUFnQjtnREFXYjtBQUNMLGlCQUFHOzs7QUFBSCxpQkFBRzthQUNKOzs7Ozs7O0tBQ0Y7OztTQW5VVSxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkNISyxTQUFTOzs4QkFDZixpQkFBaUI7Ozs7OztvQkFHcEIsTUFBTTs7OzsyQkFDSCxhQUFhOzs7O3FCQUNWLFFBQVE7O3lCQUNiLGVBQWU7Ozs7SUFFcEIsZUFBZSxHQUNkLFNBREQsZUFBZSxDQUNiLElBQUksRUFBRSxPQUFPLEVBQUU7d0JBRGpCLGVBQWU7O0FBRXhCLE1BQUksUUFBUSxhQUFDO0FBQ2IsVUFBUSxJQUFJLENBQUMsSUFBSTtBQUNmLFNBQUssT0FBTztBQUNWLGNBQVEsR0FBRyxJQUFJLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFBQSxHQUMvQzs7QUFFRCxTQUFPLFFBQVEsQ0FBQztDQUNqQjs7OztJQUdVLFFBQVE7QUFDUCxXQURELFFBQVEsQ0FDTixJQUFJLEVBQUUsT0FBTyxFQUFFOzBCQURqQixRQUFROztBQUVqQixRQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztBQUNqQixRQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztHQUN4Qjs7ZUFKVSxRQUFROztXQWVWLG9CQUFHO0FBQ1YsYUFBTyxJQUFJLENBQUMsSUFBSSxDQUFDO0tBQ2xCOzs7V0FFUSxvQkFBRztBQUNWLGFBQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7S0FDdkI7OztXQUVXLHVCQUFHO0FBQ2IsYUFBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0tBQ3JCOzs7V0FFa0IsOEJBRWpCOzs7VUFEQSxFQUFFLHlEQUFHO1lBQU8sUUFBUSx5REFBRyxVQUFDLE1BQU0sRUFBSyxFQUFFO1lBQUUsT0FBTyx5REFBRyxVQUFDLENBQUMsRUFBSyxFQUFFOzs7Ozs7OztPQUFPOztBQUVqRSxVQUFJLFVBQU8sR0FBRyxFQUFFLENBQUM7S0FDbEI7Ozs7Ozs7Ozs7Ozs7V0FXYTtVQUFDLFNBQVMseURBQUcsRUFBRTs7VUFDckIsT0FBTyxFQVFQLE9BQU8sa0ZBTUYsQ0FBQyxFQUZOLE9BQU87Ozs7Ozs7QUFaUCxtQkFBTyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUU7OztBQUdsQyxtQkFBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDbkIsa0JBQUksRUFBRSxNQUFNO0FBQ1osbUJBQUssRUFBRSxFQUFFO2FBQ1YsQ0FBQyxDQUFDOztBQUVHLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBQ2xCLDZCQUFnQixPQUFPLENBQUMsT0FBTyx1SEFBRTtBQUF0QixlQUFDO2FBQ1g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVLLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBRWxCLDhCQUFnQixPQUFPLENBQUMsT0FBTywySEFBRTtBQUF0QixlQUFDOztBQUNWLHFCQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHO0FBQ2hCLHFCQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUs7QUFDZCxxQkFBSyxFQUFFLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxXQUFXLEdBQUcsQ0FBQyxDQUFDLEtBQUssR0FBRyxDQUFDO0FBQ25ELHFCQUFLLEVBQUUsQ0FBQztlQUNULENBQUM7QUFDRixxQkFBTyxDQUFDLElBQUksQ0FDVjtBQUNFLG9CQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7QUFDWixvQkFBSSxFQUFFLHVCQUFLLHlCQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7ZUFDdEMsQ0FDRixDQUFDO2FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBRUssSUFBSSxVQUFPLENBQ2Ysb0JBQU8sTUFBTSxFQUFFLE9BQU87dUdBQ1QsQ0FBQyxFQUVKLENBQUM7Ozs7Ozs7OztpQ0FGTyxPQUFPOzs7Ozs7OztBQUFaLHFCQUFDO0FBRUoscUJBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzs7eUJBQ3JCLENBQUMsQ0FBQyxLQUFLOzs7OzswQkFDTCxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFLOzs7Ozs7Ozt5QkFLcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Ozs7OztBQUVoQixxQkFBQyxDQUFDLEtBQUssRUFBRSxDQUFDOzs7OzBCQUdOLE9BQU8sU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXOzs7Ozs7b0RBQ3BDLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzthQUsvQyxDQUNOOzs7Z0RBR1UsT0FBTzs7Ozs7OztLQUNmOzs7V0E1RmMsaUJBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRTtBQUM3QixjQUFRLElBQUksQ0FBQyxJQUFJO0FBQ2YsYUFBSyxPQUFPO0FBQ1YsaUJBQU8sSUFBSSxhQUFhLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQzFDO0FBQ0UsZ0JBQU0sSUFBSSxLQUFLLENBQUMsbUJBQW1CLENBQUMsQ0FBQztBQUFBLE9BQ3hDO0tBQ0Y7OztTQWJVLFFBQVE7Ozs7O0lBcUdSLGFBQWE7WUFBYixhQUFhOztBQUNaLFdBREQsYUFBYSxDQUNYLElBQUksRUFBRSxPQUFPLEVBQUU7OzswQkFEakIsYUFBYTs7QUFFdEIsK0JBRlMsYUFBYSw2Q0FFaEIsSUFBSSxFQUFFLE9BQU8sRUFBRTs7QUFFckIsUUFBTSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRSxDQUFDOztBQUU3QixRQUFJLENBQUMsS0FBSyxHQUFHLDJCQUFVLElBQUksQ0FBQyxDQUFDO0FBQzdCLFFBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBTyxRQUFRLEVBQUUsT0FBTztVQUN4QyxHQUFHLEVBQ0gsR0FBRzs7OztBQURILGVBQUcsc0JBQW9CLElBQUksQ0FBQyxLQUFLOzs0Q0FDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxVQUFDLENBQUMsRUFBSztBQUFFLG9CQUFNLENBQUMsQ0FBQzthQUFFLENBQUM7OztBQUF6RSxlQUFHO2dEQUNGLEdBQUc7Ozs7Ozs7S0FDWCxDQUFDLENBQUM7R0FDSjs7Ozs7O1NBWlUsYUFBYTtHQUFTLFFBQVE7Ozs7SUFtQjlCLGFBQWE7WUFBYixhQUFhOztBQUNaLFdBREQsYUFBYSxDQUNYLElBQUksRUFBRSxPQUFPLEVBQUU7OzswQkFEakIsYUFBYTs7QUFFdEIsK0JBRlMsYUFBYSw2Q0FFaEIsSUFBSSxFQUFFLE9BQU8sRUFBRTs7O0FBR3JCLFFBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBTyxRQUFRLEVBQUUsT0FBTztVQUMxQyxNQUFNLEVBSUosRUFBRSxFQUNGLFVBQVUsRUFFVixPQUFPLEVBTVAsR0FBRyxFQVFDLEdBQUc7Ozs7QUFyQlQsa0JBQU07OzRDQUNLLHFCQUFZLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxDQUFDOzs7QUFBdkUsa0JBQU07QUFHQSxjQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0FBQzdCLHNCQUFVLEdBQUcsRUFBRSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsVUFBVSxDQUFDO0FBRTNDLG1CQUFPLEdBQUc7QUFDZCxvQkFBTSxFQUFOLE1BQU07QUFDTix3QkFBVSxFQUFWLFVBQVU7QUFDVixzQkFBUSxFQUFFLEVBQUU7YUFDYjtBQUVLLGVBQUcsR0FBRyxVQUFVLENBQUMsSUFBSSxFQUFFOzs7QUFHN0IsZUFBRyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUMsQ0FBQzs7Ozs7Ozs0Q0FJNUIsR0FBRyxDQUFDLE9BQU8sRUFBRTs7Ozs7Ozs7OzRDQUNOLEdBQUcsQ0FBQyxJQUFJLEVBQUU7OztBQUF0QixlQUFHOzs0Q0FDSCxRQUFRLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQzs7Ozs7Ozs7OzRDQUl4QixHQUFHLENBQUMsS0FBSyxFQUFFOzs7Ozs7Ozs7O0tBRXBCLENBQUMsQ0FBQztHQUNKOztTQW5DVSxhQUFhO0dBQVMsUUFBUTs7OztJQXNDOUIsa0JBQWtCO1lBQWxCLGtCQUFrQjs7QUFDakIsV0FERCxrQkFBa0IsQ0FDaEIsSUFBSSxFQUFFLE9BQU8sRUFBRTs7OzBCQURqQixrQkFBa0I7O0FBRTNCLCtCQUZTLGtCQUFrQiw2Q0FFckIsSUFBSSxFQUFFLE9BQU8sRUFBRTs7O0FBR3JCLFFBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBTyxRQUFRLEVBQUUsT0FBTztVQUV4QyxPQUFPLEVBRVAsT0FBTyxFQU1QLEdBQUcsRUFHRCxRQUFRLEVBQ1IsV0FBVyxFQUNYLFVBQVUsRUFDVixZQUFZLEVBS1AsQ0FBQyxFQVFOLElBQUk7Ozs7QUEzQk4sbUJBQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7O0FBQ2hELG1CQUFPLENBQUMsR0FBRyxHQUFNLE9BQU8sQ0FBQyxHQUFHLGtCQUFlLENBQUM7QUFDdEMsbUJBQU8sR0FBRztBQUNkLHFCQUFPLEVBQVAsT0FBTzthQUNSOzs7aUJBRU0sQ0FBQzs7Ozs7OzRDQUVVLGlDQUFRLE9BQU8sQ0FBQzs7O0FBQTVCLGVBQUc7O0FBQ1AsZUFBRyxHQUFHLG1CQUFPLEdBQUcsRUFBRSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDOztBQUUvQixvQkFBUSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO0FBQzNELHVCQUFXLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFdBQVcsQ0FBQyxLQUFLLENBQUM7QUFDakUsc0JBQVUsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsVUFBVSxDQUFDLEtBQUssQ0FBQztBQUMvRCx3QkFBWSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFlBQVk7O2tCQUd2RCxZQUFZLFlBQVksS0FBSzs7Ozs7QUFFdEIsYUFBQyxHQUFHLENBQUM7OztrQkFBRSxDQUFDLEdBQUcsV0FBVzs7Ozs7OzRDQUN2QixRQUFRLENBQUMsWUFBWSxDQUFDLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQzs7O0FBRFQsYUFBQyxFQUFFOzs7Ozs7Ozs7OzRDQUs5QixRQUFRLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQzs7O0FBR2pDLGdCQUFJLEdBQUcsVUFBVSxHQUFHLFdBQVc7O2tCQUVqQyxJQUFJLEdBQUcsUUFBUTs7Ozs7Ozs7QUFDbkIsbUJBQU8sQ0FBQyxFQUFFLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQzs7Ozs7Ozs7O0tBRWhDLENBQUMsQ0FBQztHQUNKOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztTQXhDVSxrQkFBa0I7R0FBUyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQ25MaEIsZUFBZTs7MkJBQ1YsZ0JBQWdCOzt3QkFDaEMsY0FBYzs7OztJQUVkLGNBQWM7V0FBZCxjQUFjOzBCQUFkLGNBQWM7OztlQUFkLGNBQWM7Ozs7Ozs7V0FLdkIsY0FBQyxJQUFJOzs7Ozs0Q0FDTSwyQkFBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7OztBQUFyRCxnQkFBSSxDQUFDLEtBQUs7OzRDQUNZLDJCQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQzs7O0FBQTNELGdCQUFJLENBQUMsUUFBUTs7Ozs7OztLQUNkOzs7V0FFYSxrQkFBQyxNQUFNO1VBQ2IsSUFBSSxFQU9KLFVBQVUsRUFRVixVQUFVLGtGQUVMLFVBQVUsRUFDZixXQUFXLHVGQUVKLEVBQUUsRUFDTCxPQUFPLEVBT1AsVUFBVSx1RkFHTCxLQUFLLEVBUWQsUUFBUTs7Ozs7OzRDQXZDSyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNwQyxpQkFBRyxFQUFFLE1BQU07YUFDWixFQUFFO0FBQ0Qsd0JBQVUsRUFBRTtBQUNWLHVCQUFPLEVBQUUsQ0FBQztlQUNYO2FBQ0YsQ0FBQzs7O0FBTkksZ0JBQUk7QUFPSixzQkFBVSxHQUFHLElBQUksQ0FBQyxPQUFPO0FBUXpCLHNCQUFVLEdBQUcsRUFBRTs7Ozs7d0JBRUksVUFBVTs7Ozs7Ozs7QUFBeEIsc0JBQVU7QUFDZix1QkFBVyxHQUFHLENBQUM7Ozs7O3lCQUVGLFVBQVUsQ0FBQyxHQUFHOzs7Ozs7OztBQUFwQixjQUFFOzs0Q0FDVyxJQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQztBQUMxQyxpQkFBRyxFQUFFLEVBQUU7YUFDUixFQUFFO0FBQ0Qsd0JBQVUsRUFBRTtBQUNWLHFCQUFLLEVBQUUsQ0FBQztlQUNUO2FBQ0YsQ0FBQzs7O0FBTkksbUJBQU87QUFPUCxzQkFBVSxHQUFHLE9BQU8sQ0FBQyxLQUFLOzs7Ozs7O0FBR2hDLDhCQUFvQixVQUFVO0FBQW5CLG1CQUFLO0FBQWdCLHlCQUFXLElBQUksS0FBSyxDQUFDLFFBQVEsQ0FBQzthQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJaEUsc0JBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUl0RCxvQkFBUSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUM7Z0RBRTFDLFFBQVE7Ozs7Ozs7S0FDaEI7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7V0F1QmEsa0JBQUMsUUFBUSxFQUFFLEtBQUs7VUFBRSxNQUFNLHlEQUFHLElBQUk7VUFBRSxNQUFNLHlEQUFHLElBQUk7VUFFcEQsTUFBTSxFQUtOLE1BQU0sRUFLTixHQUFHOzs7O0FBVkgsa0JBQU0sR0FBRyxxQkFBUSxJQUFJLENBQUM7QUFDMUIsc0JBQVEsRUFBUixRQUFRO2FBQ1QsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxXQUFDO3FCQUFJLENBQUMsQ0FBQyxnQkFBZ0I7YUFBQSxDQUFDO0FBR2pDLGtCQUFNLEdBQUcsRUFBRTs7QUFDakIsa0JBQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQ3JCLGdCQUFJLE1BQU0sRUFBRSxNQUFNLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQztBQUN6QyxnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7Ozs0Q0FFdkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQ3JDLE1BQU0sRUFBRTtBQUNOLG1CQUFLLEVBQUU7QUFDTCxzQkFBTSxFQUFFO0FBQ04sdUJBQUssRUFBRSxNQUFNO2lCQUNkO2VBQ0Y7YUFDRixDQUNGOzs7QUFSSyxlQUFHO2dEQVdGLE1BQU07Ozs7Ozs7S0FDZDs7Ozs7Ozs7Ozs7O1dBVWUsb0JBQUMsS0FBSztVQUFFLE1BQU0seURBQUcsSUFBSTtVQUFFLE1BQU0seURBQUcsSUFBSTtVQUU1QyxNQUFNLEVBS04sR0FBRzs7OztBQUxILGtCQUFNLEdBQUcsRUFBRTs7QUFDakIsa0JBQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSyxDQUFDO0FBQ3JCLGdCQUFJLE1BQU0sRUFBRSxNQUFNLENBQUMsWUFBWSxHQUFHLE1BQU0sQ0FBQztBQUN6QyxnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7Ozs0Q0FFdkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQ3JDLE1BQU0sRUFBRTtBQUNOLGtCQUFJLEVBQUU7QUFDSixzQkFBTSxFQUFFLEVBQUU7ZUFDWDthQUNGLENBQ0Y7OztBQU5LLGVBQUc7Ozs7Ozs7S0FPVjs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBZ0JpQixzQkFBQyxJQUFJLEVBQUUsT0FBTztVQVN4QixHQUFHLEVBbUNILEtBQUssdUZBRUEsQ0FBQyx1RkFzQkQsSUFBSSx1RkFBc0IsQ0FBQzs7Ozs7QUEzRGhDLGVBQUcsR0FBRyxDQUFDO0FBQ1gsbUJBQUssRUFBRSxNQUFNO0FBQ2IscUJBQU8sRUFBRSxJQUFJLENBQUMsUUFBUTtBQUN0QixxQkFBTyxFQUFFO0FBQ1AscUJBQUssRUFBRSxXQUFXO2VBQ25CO0FBQ0QsbUJBQUssRUFBRTtBQUNMLDRCQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7QUFDL0IsNEJBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtlQUNoQzthQUNGLEVBQ0Q7QUFDRSxtQkFBSyxFQUFFLElBQUksQ0FBQyxXQUFXO0FBQ3ZCLHFCQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVk7QUFDMUIscUJBQU8sRUFBRTtBQUNQLHFCQUFLLEVBQUUsZUFBZTtlQUN2QjtBQUNELG1CQUFLLEVBQUU7QUFDTCx3QkFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO0FBQ3ZCLDRCQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7ZUFDaEM7YUFDRixFQUNEO0FBQ0UsbUJBQUssRUFBRSxJQUFJLENBQUMsV0FBVztBQUN2QixxQkFBTyxFQUFFLElBQUksQ0FBQyxZQUFZO0FBQzFCLHFCQUFPLEVBQUU7QUFDUCxxQkFBSyxFQUFFLGVBQWU7ZUFDdkI7QUFDRCxtQkFBSyxFQUFFO0FBQ0wsd0JBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtBQUN2Qiw0QkFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO2VBQ2hDO2FBQ0YsQ0FDQTtBQUVLLGlCQUFLLEdBQUcsRUFBRTs7Ozs7eUJBRUEsR0FBRzs7Ozs7Ozs7QUFBUixhQUFDOzZCQUNWLEtBQUs7OzRDQUNlLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUNwQyxDQUFDO0FBQ0Msb0JBQU0sRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxLQUFLLEVBQUU7QUFDN0IscUJBQUssRUFBRSxJQUFJLENBQUMsS0FBSztlQUNsQixDQUFDO2FBQ0gsRUFDRDtBQUNFLHNCQUFRLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsT0FBTyxFQUFFLE9BQU8sQ0FBQzthQUM1QyxFQUNEO0FBQ0UsbUJBQUssRUFBRTtBQUNMLG1CQUFHLEVBQUUsQ0FBQztlQUNQO2FBQ0YsQ0FDQSxDQUNGLENBQUMsT0FBTyxFQUFFOzs7OzZCQUNKLENBQUM7O0FBaEJSLHdCQUFVO0FBZ0JWLG1CQUFLOzsyQkFqQkQsSUFBSTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkFxQk8sS0FBSzs7Ozs7Ozs7QUFBYixnQkFBSTs7Ozs7eUJBQTJCLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUFwQixhQUFDOzs0Q0FBcUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDOzs7QUFBcEMsYUFBQyxDQUFDLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnREFHM0QsS0FBSzs7Ozs7OztLQUNiOzs7Ozs7V0FJa0IsdUJBQUMsR0FBRztVQUNqQixJQUFJLEVBR0EsR0FBRyxFQUNILEdBQUcsRUFXQyxLQUFLLEVBYVgsVUFBVTs7OztBQTVCWixnQkFBSTs7a0JBRUosT0FBTyxHQUFHLEtBQUssUUFBUTs7Ozs7QUFDbkIsZUFBRyxHQUFHLElBQUksTUFBTSxDQUFJLEdBQUcsT0FBSTtBQUMzQixlQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFO0FBQzlCLHdCQUFVLEVBQUU7QUFDVixxQkFBSyxFQUFFLENBQUM7QUFDUiw0QkFBWSxFQUFFLENBQUM7QUFDZiw0QkFBWSxFQUFFLENBQUM7ZUFDaEI7YUFDRixDQUFDOzs7aUJBRUssQ0FBQzs7Ozs7Ozs0Q0FFUyxHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdkIsZ0JBQUk7OzRDQUNnQixJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEvQyxpQkFBSzs7aUJBQ1AsS0FBSzs7Ozs7Ozs7Ozs7Ozs7OztBQUdULGVBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQztnREFDTCxHQUFHOzs7Ozs7O0FBR2QsZUFBRyxDQUFDLEtBQUssRUFBRSxDQUFDOzs7OztBQUVaLGdCQUFJLEdBQUcsR0FBRyxDQUFDOzs7QUFHUCxzQkFBVSxHQUFHLEVBQUU7O0FBQ3JCLGdCQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDNUMsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztBQUMxRCxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO2dEQUNuRCxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7Ozs7OztLQUM1Qjs7O1dBRXFCLDBCQUFDLGdCQUFnQixFQUFFLElBQUk7VUFFckMsU0FBUyxFQUdULFNBQVMsRUFDVCxVQUFVLEVBU1osYUFBYSxFQW9CWCxJQUFJLEVBNkJOLFdBQVcsRUFjWCxLQUFLLEVBcUJILGFBQWEsRUF1QmIsaUJBQWlCLEVBTWpCLElBQUk7Ozs7QUE5SEoscUJBQVMsR0FBRyxTQUFaLFNBQVMsQ0FBRyxRQUFRO3FCQUFLLFFBQVEsS0FBSyxRQUFRLEdBQUcsT0FBTyxHQUFHLFFBQVE7YUFBQzs7QUFHcEUscUJBQVMsR0FBRyxJQUFJO0FBQ2hCLHNCQUFVLEdBQUcsRUFBRTs7OztBQUlyQixnQkFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzVDLGdCQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDMUQsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQzs7O0FBR3RELHlCQUFhOzZCQUNULElBQUksQ0FBQyxRQUFRO2tEQUNkLEtBQUssMkJBR0wsUUFBUSwyQkFHUixVQUFVLDJCQUdWLFNBQVM7Ozs7QUFSWix5QkFBYSxHQUFHLENBQUMsQ0FBQzs7OztBQUdsQix5QkFBYSxHQUFHLENBQUMsQ0FBQzs7OztBQUdsQix5QkFBYSxHQUFHLENBQUMsQ0FBQzs7OztBQUdsQix5QkFBYSxHQUFHLENBQUMsQ0FBQzs7OztBQUdsQix5QkFBYSxHQUFHLENBQUMsQ0FBQzs7OztBQUtoQixnQkFBSSxHQUFHLENBQ1gsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFDdEIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFDdEIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsRUFDdEIsRUFBRSxHQUFHLEVBQUUsQ0FBQyxFQUFFLEdBQUcsRUFBRSxLQUFLLEVBQUUsQ0FDdkI7NkJBRU8sSUFBSSxDQUFDLFFBQVE7a0RBQ2QsS0FBSywyQkFJTCxRQUFRLDJCQUlSLFVBQVUsMkJBSVYsU0FBUzs7OztBQVhaLGdCQUFJLENBQUMsSUFBSSxDQUFDLFdBQUM7cUJBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDO2FBQUEsQ0FBQyxDQUN4QixHQUFHLEdBQUcsSUFBSSxDQUFDOzs7O0FBR2QsZ0JBQUksQ0FBQyxJQUFJLENBQUMsV0FBQztxQkFBSSxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUM7YUFBQSxDQUFDLENBQ3hCLEdBQUcsR0FBRyxJQUFJLENBQUM7Ozs7QUFHZCxnQkFBSSxDQUFDLElBQUksQ0FBQyxXQUFDO3FCQUFJLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQzthQUFBLENBQUMsQ0FDeEIsR0FBRyxHQUFHLElBQUksQ0FBQzs7OztBQUdkLGdCQUFJLENBQUMsSUFBSSxDQUFDLFdBQUM7cUJBQUksQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDO2FBQUEsQ0FBQyxDQUN4QixHQUFHLEdBQUcsSUFBSSxDQUFDOzs7Ozs7O0FBT2QsdUJBQVcsR0FBRyxJQUFJOzZCQUNkLElBQUksQ0FBQyxRQUFRO2tEQUNkLFFBQVE7Ozs7QUFDWCx1QkFBVyxHQUFHLGdCQUFnQixDQUFDLFVBQVUsQ0FBQzs7OztBQUcxQyx1QkFBVyxHQUFHLElBQUksQ0FBQzs7Ozs7NENBUUwsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUU7QUFDeEMsd0JBQVUsRUFBRSw4QkFBOEI7YUFDM0MsQ0FBQzs7O0FBRkUsaUJBQUs7Ozs7O0FBT1QsaUJBQUssR0FBRyxLQUFLLENBQUMsR0FBRyxDQUNmLFVBQUMsSUFBSSxFQUFLO0FBQ1Isa0JBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO0FBQ25ELGtCQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUNuQyxVQUFDLFNBQVMsRUFBSztBQUNiLHlCQUFTLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUM7QUFDN0MsdUJBQU8sU0FBUyxDQUFDO2VBQ2xCLENBQ0YsQ0FBQztBQUNGLHFCQUFPLElBQUksQ0FBQzthQUNiLENBQ0YsQ0FBQzs7O0FBR0kseUJBQWEsR0FBRyxLQUFLLENBQUMsR0FBRyxDQUM3QixjQUFJO3FCQUFJLE1BQUcsK0JBQStCLEdBQ3RDLG1CQUFtQixHQUNuQixpRUFBaUUsaUJBQ3RELElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxlQUFXLEdBQ3RDLFFBQVEsSUFDVixJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FDakIsVUFBQyxTQUFTLEVBQUs7QUFDYixvQkFBSSxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sS0FBSyxTQUFTLENBQUMsS0FBSyxFQUFFOztBQUUxQyxtR0FBK0UsU0FBUyxDQUFDLEtBQUssd0JBQXFCO2lCQUNuSCxJQUFJLFNBQVMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFFOztBQUV6Qix3REFBb0MsU0FBUyxDQUFDLFVBQVUsdUVBQWtFLFNBQVMsQ0FBQyxLQUFLLG1CQUFnQjtpQkFDMUo7O0FBRUQscUpBQW1JLFNBQVMsQ0FBQyxLQUFLLGVBQVk7ZUFDL0osQ0FDRixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsY0FFUixRQUFRO2FBQUEsQ0FDYixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFFSiw2QkFBaUIsOERBRXJCLGFBQWE7QUFJVCxnQkFBSSxHQUFHO0FBQ1gsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHdCQUFVLEVBQUUsZ0JBQWdCLENBQUMsVUFBVTtBQUN2QyxrQkFBSSxFQUFLLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBSSxJQUFJLENBQUMsSUFBSSxJQUFHLElBQUksQ0FBQyxRQUFRLFNBQU8sSUFBSSxDQUFDLFFBQVEsR0FBSyxFQUFFLENBQUU7QUFDbkgsZ0NBQWtCLEVBQUUsaUJBQWlCOztBQUVyQywwQkFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ2xDLHFCQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVk7OztBQUcxQiw2QkFBZSxFQUFFLGFBQWE7QUFDOUIsa0JBQUksRUFBSixJQUFJO0FBQ0osMEJBQVksRUFBRSxXQUFXO2FBQzFCOzZCQUVELE1BQU07NkJBQVEsSUFBSTs7NENBQVEsSUFBSSxDQUFDLDhCQUE4QixDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQzs7OzsyQkFBOUUsTUFBTTs2QkFDYixNQUFNOzZCQUFRLElBQUk7OzRDQUFRLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUM7Ozs7MkJBQTdFLE1BQU07NkJBQ2IsTUFBTTs4QkFBUSxJQUFJOzs0Q0FBUSxJQUFJLENBQUMsNEJBQTRCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDOzs7OzJCQUE1RSxNQUFNOztBQUViLGtCQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxDQUFDOztnREFFcEMsSUFBSTs7Ozs7OztLQUNaOzs7V0FFbUMsd0NBQUMsZ0JBQWdCLEVBQUUsSUFBSTtVQUNyRCxRQUFRLEVBSUgsQ0FBQzs7OztBQUpOLG9CQUFRLEdBQUcsRUFBRTs7O0FBRWpCLG9CQUFRLElBQU8sSUFBSSxDQUFDLFdBQVcsU0FBTSxDQUFDOztBQUV0QyxpQkFBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7QUFBRSxzQkFBUSxzQ0FBb0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBUSxDQUFDO2FBQUEsb0NBRXpHLEVBQUUsU0FBUyxFQUFFLFFBQVEsRUFBRTs7Ozs7OztLQUMvQjs7O1dBRWtDLHVDQUFDLGdCQUFnQixFQUFFLElBQUk7Ozs7Z0RBRWpELEVBQUUsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRTs7Ozs7OztLQUNoRDs7O1dBRWlDLHNDQUFDLGdCQUFnQixFQUFFLElBQUk7VUFFakQsR0FBRzs7OztBQUFILGVBQUcsR0FBRyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxHQUFHLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7Z0RBQ2xFLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRTs7Ozs7OztLQUN2Qjs7Ozs7V0FHc0IsMkJBQUMsTUFBTSxFQUFFLElBQUk7VUFDNUIsR0FBRzs7Ozs7NENBQVMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sV0FBUSxFQUFFLElBQUksQ0FBQzs7O0FBQXZELGVBQUc7Z0RBQ0YsR0FBRzs7Ozs7OztLQUNYOzs7OztXQUdxQiwwQkFBQyxHQUFHLEVBQUUsSUFBSTtVQUN4QixRQUFRLEVBQ1IsV0FBVyxFQUViLEtBQUssRUFLSCxTQUFTLEVBQ04sQ0FBQzs7OztBQVRKLG9CQUFRLEdBQUcsRUFBRTtBQUNiLHVCQUFXLEdBQUcsR0FBRztBQUVuQixpQkFBSyxHQUFHLEVBQUU7OztBQUVkLGlCQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7QUFHakQscUJBQVMsR0FBRyxJQUFJOztBQUN0QixpQkFBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7QUFBRSxtQkFBSyxDQUFDLFNBQVMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQUE7QUFJekYsaUJBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFRLENBQUM7Ozs0Q0FDQyxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQzs7Ozs7NkJBQUksSUFBSSxDQUFDLFFBQVE7Ozs2QkFBSSxJQUFJLENBQUMsSUFBSTs7NkJBQUksV0FBVztBQUEvRyxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxrQkFBWSxPQUFPOztBQUNoQyxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7QUFDakMsaUJBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDO0FBQ2pDLGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsQ0FBQyxRQUFRLENBQUMsQ0FBQztBQUN4RCxnQkFBSSxPQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsS0FBSyxRQUFRLEVBQUUsS0FBSyxDQUFDLElBQUksQ0FBQyxHQUFNLElBQUksQ0FBQyxXQUFXLGdCQUFXLEtBQUssQ0FBQyxJQUFJLENBQUcsQ0FBQyxLQUMxRixLQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQzs7QUFFcEMsaUJBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUM7O2dEQUVqQyxLQUFLOzs7Ozs7O0tBQ2I7OztXQUV5Qyw4Q0FBQyxRQUFRO1VBQzNDLEVBQUUsRUFDRixHQUFHLEVBQ0gsT0FBTyxFQU1QLElBQUksRUF1Qk4sV0FBVyx1RkFDSixHQUFHLEVBR1IsY0FBYyxFQUNYLENBQUMsRUFDRixHQUFFOzs7OztBQXJDSixjQUFFLEdBQUcscUJBQXFCO0FBQzFCLGVBQUcsR0FBRyxVQUFVO0FBQ2hCLG1CQUFPLEdBQUc7QUFDZCxvQkFBTSxFQUFFLENBQUMsTUFBTSxDQUFDO0FBQ2hCLGlCQUFHLEVBQUUsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDO2FBQzdCOzs0Q0FHa0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQ3JDLENBQ0U7QUFDRSxvQkFBTSxzQkFDSCxFQUFFLEVBQUcsUUFBUSxDQUNmO2FBQ0YsRUFDRDtBQUNFLG9CQUFNO0FBQ0osbUJBQUcsUUFBTSxFQUFJO2lCQUNaLEdBQUcsRUFBRyxFQUFFLFNBQVMsUUFBTSxHQUFLLEVBQUUsQ0FDaEM7YUFDRixFQUNEO0FBQ0Usc0JBQVE7QUFDTixtQkFBRyxFQUFFLENBQUM7QUFDTix3QkFBUSxFQUFFLE1BQU07aUJBQ2YsR0FBRyxRQUFPLEdBQUcsQ0FDZjthQUNGLENBQ0YsQ0FDRixDQUFDLE9BQU8sRUFBRTs7O0FBckJMLGdCQUFJO0FBdUJOLHVCQUFXLEdBQUcsRUFBRTs7Ozs7O0FBQ3BCLDhCQUFrQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUTtBQUF2QixpQkFBRztBQUFzQix5QkFBVyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxNQUFJLEdBQUcsQ0FBRyxDQUFDLENBQUM7YUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUdsRiwwQkFBYyxHQUFHLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs7QUFDbkMsaUJBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsY0FBYyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUN4QyxpQkFBRSxHQUFHLE9BQU8sV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsR0FBRyxNQUFNLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQzs7QUFDMUUsNEJBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLGlCQUFpQixFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRSxFQUFFLENBQUM7YUFDeEU7O2dEQUVNLEVBQUUsY0FBYyxFQUFkLGNBQWMsRUFBRTs7Ozs7OztLQUMxQjs7Ozs7Ozs7V0FNNEIsZ0NBQUMsSUFBSSxFQUFFO0FBQ2xDLGFBQU87QUFDTCxpQkFBUyxFQUFFLEdBQUc7QUFDZCxjQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7QUFDOUIsWUFBSSxFQUFFLElBQUk7QUFDVixXQUFHLE9BQUssSUFBSSxDQUFDLEtBQUssSUFBRyxJQUFJLENBQUMsWUFBWSxLQUFLLEVBQUUsR0FBRyxFQUFFLFNBQU8sSUFBSSxDQUFDLFlBQVksQ0FBRSxJQUFHLElBQUksQ0FBQyxZQUFZLEtBQUssRUFBRSxHQUFHLEVBQUUsU0FBTyxJQUFJLENBQUMsWUFBWSxDQUFJO0FBQ3hJLFVBQUUsRUFBRSxJQUFJO09BQ1QsQ0FBQztLQUNIOzs7Ozs7OztXQU04QixrQ0FBQyxJQUFJLEVBQUU7QUFDcEMsVUFBTSxNQUFNLEdBQUc7QUFDYixpQkFBUyxFQUFFLEdBQUc7QUFDZCxjQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7QUFDOUIsWUFBSSxFQUFFLElBQUk7QUFDVixjQUFNLEVBQUUsSUFBSTtBQUNaLGdCQUFRLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7T0FDakMsQ0FBQzs7QUFFRixVQUFNLEtBQUssR0FBRyx5QkFBWSxJQUFJLEVBQUUsQ0FBQzs7QUFFakMsV0FBSyxDQUFDLE9BQU8sQ0FDWCxVQUFDLEdBQUcsRUFBRSxLQUFLLEVBQUs7QUFDZCxZQUFJLEtBQUssYUFBQztBQUNWLFlBQUksTUFBTSxhQUFDO0FBQ1gsWUFBSSxNQUFNLGFBQUM7QUFDWCxZQUFJOztBQUVGLGVBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUcsTUFBSSxHQUFHLENBQUMsU0FBUyxDQUFHLENBQUM7QUFDckQsZUFBSyxHQUFHLE9BQU8sS0FBSyxLQUFLLFdBQVcsR0FBRyxFQUFFLEdBQUcsS0FBSyxDQUFDO0FBQ2xELGdCQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBSSxHQUFHLENBQUMsSUFBSSxDQUFHLE1BQUksR0FBRyxDQUFDLFVBQVUsQ0FBRyxDQUFDO0FBQ3ZELGdCQUFNLEdBQUcsT0FBTyxNQUFNLEtBQUssV0FBVyxHQUFHLEVBQUUsR0FBRyxNQUFNLENBQUM7QUFDckQsZ0JBQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUcsTUFBSSxHQUFHLENBQUMsVUFBVSxDQUFHLENBQUM7QUFDdkQsZ0JBQU0sR0FBRyxPQUFPLE1BQU0sS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHLE1BQU0sQ0FBQztTQUN0RCxDQUFDLE9BQU8sQ0FBQyxFQUFFOzs7OztBQUtWLGlCQUFPO1NBQ1I7O0FBRUQsY0FBTSxhQUFXLEtBQUssQ0FBRyxHQUFHLElBQUksQ0FBQztBQUNqQyxjQUFNLFdBQVMsS0FBSyxDQUFHLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFDO0FBQ3RDLGNBQU0sVUFBUSxLQUFLLENBQUcsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDO0FBQ2xDLGNBQU0sYUFBVyxLQUFLLENBQUcsUUFBTSxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQVEsQ0FBQztBQUN6RCxjQUFNLFlBQVUsS0FBSyxDQUFHLEdBQUcsSUFBSSxDQUFDO09BQ2pDLENBQ0YsQ0FBQzs7QUFFRixhQUFPLE1BQU0sQ0FBQztLQUNmOzs7Ozs7OztXQU1rQyxzQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO0FBQzlDLFVBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksSUFBSSxDQUFDLElBQUksQ0FBRyxNQUFJLElBQUksQ0FBQyxTQUFTLENBQUcsQ0FBQztBQUM3RCxVQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsVUFBVSxDQUFHLENBQUM7QUFDL0QsVUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBSSxJQUFJLENBQUMsSUFBSSxDQUFHLE1BQUksSUFBSSxDQUFDLFVBQVUsQ0FBRyxDQUFDOztBQUUvRCxhQUFPO0FBQ0wsaUJBQVMsRUFBRSxHQUFHO0FBQ2QsY0FBTSxFQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFO0FBQzlCLGNBQU0sRUFBRSxJQUFJO0FBQ1osWUFBSSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDbEIsV0FBRyxFQUFFLElBQUk7QUFDVCxjQUFNLE9BQUssS0FBSyxHQUFHLE1BQU0sR0FBRyxNQUFRO0FBQ3BDLGFBQUssRUFBRSxJQUFJO09BQ1osQ0FBQztLQUNIOzs7U0F2a0JrQixjQUFjOzs7cUJBQWQsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQ0Y1QixjQUFjOztvQkFHZCxNQUFNOzt3QkFDUSxjQUFjOzs7O3FCQUNSLFNBQVM7Ozs7MkJBRzdCLGdCQUFnQjs7SUFFRixPQUFPO0FBQ2QsV0FETyxPQUFPLEdBQ1g7MEJBREksT0FBTzs7Ozs7QUFLeEIsUUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQztHQUN6Qzs7ZUFOa0IsT0FBTzs7Ozs7Ozs7V0FpQlYseUJBQUMsUUFBUSxFQUFFLEtBQUssRUFBRTs7QUFFaEMsVUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLENBQUMsQ0FBQztLQUMxQzs7Ozs7Ozs7Ozs7Ozs7O1dBOEVrQiw2QkFBQyxRQUFRLEVBQUUsWUFBWSxFQUFFOzs7OztBQUsxQyxVQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7Ozs7Ozs7Ozs7Ozs7O0FBY2pDLFVBQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxvQkFBb0IsQ0FDeEM7QUFDRSxxQkFBYSxFQUFFLFFBQVEsQ0FBQyxFQUFFLENBQUM7O0FBRTNCLHNCQUFjLEVBQUU7QUFDZCxhQUFHLEVBQUUsQ0FBQyxXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFDO1NBQ3hDO09BQ0Y7O0FBRUQsYUFBTyxJQUFJLENBQUMsS0FBSyxLQUFLLFdBQVcsR0FBRyxJQUFJLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FDdEQsQ0FBQzs7Ozs7Ozs7OztBQVVGLFVBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDOzs7QUFHdEQsVUFBTSxlQUFlLEdBQUcsWUFBWSxDQUFDLGVBQWUsQ0FBQztBQUNyRCxVQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRSxNQUFNLElBQUksS0FBSyxzQkFBb0IsZUFBZSxDQUFDLE1BQU0sV0FBUSxDQUFDOzs7QUFHN0csa0JBQVksU0FBTSxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsRUFBSztBQUNoQyxnQkFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSyxDQUFDO09BQzlCLENBQUMsQ0FBQzs7O0FBR0gscUJBQWUsQ0FBQyxPQUFPLENBQUMsVUFBQyxDQUFDLEVBQUUsQ0FBQyxFQUFLO0FBQ2hDLFlBQUksS0FBSyxDQUFDLENBQUMsQ0FBQyxFQUFFO0FBQ1osa0JBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDeEIsTUFBTTs7O0FBR0wsa0JBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFLENBQUM7U0FDbEI7T0FDRixDQUFDLENBQUM7Ozs7Ozs7O0FBUUgsYUFBTyxRQUFRLENBQUM7S0FDakI7Ozs7Ozs7OztXQU9tQiw4QkFBQyxRQUFRLEVBQUUsWUFBWSxFQUFFOzs7OztBQUszQyxVQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7QUFjMUQsVUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUN4QztBQUNFLHFCQUFhLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQzs7QUFFbkMsc0JBQWMsRUFBRTtBQUNkLGFBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDeEM7T0FDRjs7QUFFRCxhQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUN0RCxDQUFDOzs7O0FBSUYsVUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7OztBQUd0RCxVQUFNLGVBQWUsR0FBRyxZQUFZLENBQUMsZUFBZSxDQUFDO0FBQ3JELFVBQUksZUFBZSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sSUFBSSxLQUFLLHNCQUFvQixlQUFlLENBQUMsTUFBTSxXQUFRLENBQUM7OztBQUk3RyxxQkFBZSxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDLEVBQUs7QUFDaEMsWUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDWixrQkFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4QixNQUFNOzs7QUFHTCxrQkFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztTQUNsQjtPQUNGLENBQUMsQ0FBQzs7O0FBR0gsY0FBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7QUFPekMsYUFBTyxRQUFRLENBQUM7S0FDakI7OztXQUVxQixnQ0FBQyxRQUFRLEVBQUUsWUFBWSxFQUFFOztBQUU3QyxVQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7QUFXMUQsVUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUN4QztBQUNFLHFCQUFhLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQzs7QUFFbkMsc0JBQWMsRUFBRTtBQUNkLGFBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDeEM7T0FDRjs7QUFFRCxhQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUN0RCxDQUFDOztBQUVGLFVBQU0sUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDOzs7QUFHdEQsY0FBUSxDQUFDLE9BQU8sQ0FBQyxHQUFHLFlBQVksQ0FBQyxPQUFPLENBQUM7O0FBRXpDLGNBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsY0FBUSxDQUFDLFNBQVMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUMvQixjQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDOzs7Ozs7QUFNL0IsYUFBTyxRQUFRLENBQUM7S0FDakI7OztXQTFReUIsK0JBQWE7VUFBWixLQUFLLHlEQUFHLEVBQUU7O0FBQ25DLGFBQU8sMkJBQWMsYUFBYSxFQUFFLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFFLEdBQUcsRUFBRSxDQUFDLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUM7S0FDbkY7OztXQWlCdUIscUJBQUMsUUFBUSxFQUFFLE9BQU87VUFRbEMsU0FBUzs7OztBQUFULHFCQUFTLEdBQUc7QUFDaEIscUJBQU8sRUFBRSxRQUFRO2FBQ2xCOzs7O0FBSUQsdUNBQWMsTUFBTSxDQUFDO0FBQ25CLDRCQUFjLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQztBQUNoQyw0QkFBYyxFQUFFLFFBQVEsQ0FBQyxNQUFNLENBQUM7YUFDakMsRUFBRTtBQUNELGtCQUFJLEVBQUU7QUFDSix1QkFBTyxFQUFFLFFBQVE7ZUFDbEI7YUFDRixFQUFFO0FBQ0Qsb0JBQU0sRUFBRSxJQUFJO2FBQ2IsQ0FBQyxDQUFDOzs7O0FBSUgsdUNBQWMsTUFBTSxDQUFDO0FBQ25CLG9CQUFNLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFO2FBQ3ZCLEVBQUU7QUFDRCxrQkFBSSxFQUFFO0FBQ0osc0JBQU0sRUFBRTtBQUNOLHlCQUFPLEVBQUUsRUFBRTtBQUNYLDJCQUFTLEVBQUUsSUFBSTtBQUNmLHlCQUFPLEVBQUUsSUFBSSxFQUNkO2VBQ0Y7YUFDRixDQUFDLENBQUM7Ozs7Ozs7S0FDSjs7OztXQUUwQiw4QkFBQyxLQUFLLEVBQXFCO1VBQW5CLFVBQVUseURBQUcsSUFBSTs7O0FBRWxELGdCQUFVLEdBQUcsVUFBVSxLQUFLLElBQUksZ0NBQW1CLFVBQVUsQ0FBQzs7O0FBRzlELFVBQU0sR0FBRyxHQUFHLFVBQVUsQ0FBQyxJQUFJLENBQ3pCLEtBQUssRUFBRTtBQUNMLGNBQU0sRUFBRTtBQUNOLGFBQUcsRUFBRSxDQUFDO0FBQ04seUJBQWUsRUFBRSxDQUFDO0FBQ2xCLHNCQUFZLEVBQUUsQ0FBQztTQUNoQjtPQUNGLENBQ0YsQ0FBQzs7QUFFRixVQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsc0NBQXNDLENBQUMsQ0FBQzs7QUFFMUUsVUFBTSxJQUFJLEdBQUcsRUFBRSxDQUFDO0FBQ2hCLFNBQUcsQ0FBQyxPQUFPLENBQUMsVUFBQyxHQUFHLEVBQUs7QUFDbkIsWUFBTSxDQUFDLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxFQUFFLElBQUksQ0FBQyxHQUFHLEVBQUUsU0FBTyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsUUFBSyxDQUFDO0FBQzdELFlBQUksQ0FBQyxJQUFJLENBQUksR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLFNBQUksQ0FBQyxDQUFHLENBQUM7T0FDeEMsQ0FBQyxDQUFDOztBQUVILGFBQU8sSUFBSSxDQUFDO0tBQ2I7OztTQTNGa0IsT0FBTzs7O3FCQUFQLE9BQU87Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs4QkNaUixpQkFBaUI7Ozs7cUJBQ1osUUFBUTs7eUJBQ1gsZUFBZTs7OztBQUVyQyxJQUFNLFFBQVEsR0FBRyx3Q0FBd0M7O0lBRXBDLFFBQVE7QUFDZixXQURPLFFBQVEsQ0FDZCxJQUFJLEVBQUUsTUFBTSxFQUFFOzBCQURSLFFBQVE7O0FBRXpCLFFBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSTtBQUNoQixRQUFJLENBQUMsTUFBTSxHQUFHLE1BQU07R0FDckI7Ozs7ZUFKa0IsUUFBUTs7V0FPVixvQkFBQyxXQUFVO1VBQ3RCLE9BQU8sRUFFTCxHQUFHOzs7O0FBRkwsbUJBQU8seUJBQXVCLElBQUksQ0FBQyxNQUFNLDZCQUF3QixxQkFBUyxXQUFVLEVBQUUsRUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUM7Ozs0Q0FFeEYsSUFBSSxDQUFDLFdBQVcsQ0FDOUIsZ0JBQWdCLEVBQ2hCLE9BQU8sQ0FDUjs7O0FBSEcsZUFBRztnREFJQSxFQUFDLFFBQVEsRUFBRSxHQUFHLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBQzs7Ozs7a0JBRXJDLE1BQU0sQ0FBQyxNQUFNLENBQUMsdUJBQVUsS0FBSyxnQkFBRyxFQUFFLEVBQUMsVUFBVSxFQUFFLE9BQU8sRUFBQyxDQUFDOzs7Ozs7O0tBRWpFOzs7V0FFaUIscUJBQUMsTUFBTSxFQUFFLElBQUk7VUFFekIsVUFBVSxFQVNWLEdBQUc7Ozs7QUFUSCxzQkFBVSxHQUFHO0FBQ2Ysb0JBQU0sRUFBRSxNQUFNO0FBQ2QsaUJBQUcsRUFBSyxRQUFRLFNBQUksTUFBUTtBQUM1QixrQkFBSSxFQUFFLElBQUk7YUFDWDs7O0FBRUQsa0JBQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7Ozs7NENBR3BCLGlDQUFRLFVBQVUsQ0FBQzs7O0FBQS9CLGVBQUc7Z0RBRUEsR0FBRzs7Ozs7OztLQUNYOzs7V0FFaUIscUJBQUMsZUFBZTtVQUU1QixVQUFVLEVBVVYsR0FBRzs7OztBQVZILHNCQUFVLEdBQUc7QUFDZixvQkFBTSxFQUFFLE1BQU07QUFDZCxpQkFBRyxFQUFLLFFBQVEsaUJBQWM7YUFDL0I7OztBQUVELGtCQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDOzs7NENBRVosSUFBSSxDQUFDLDRCQUE0QixDQUFDLGVBQWUsQ0FBQzs7O0FBQTFFLHNCQUFVLENBQUMsSUFBSTs7NENBR0MsaUNBQVEsVUFBVSxDQUFDOzs7QUFBL0IsZUFBRztnREFFQSxHQUFHOzs7Ozs7O0tBQ1g7OztXQUVrQyxzQ0FBQyxlQUFlO1VBZ0I3QyxrQkFBa0Isa0ZBRWIsSUFBSSx1RkFFRixDQUFDLEVBWU4sSUFBSSx1RkFVRyxTQUFTLHVGQU9QLEdBQUcsRUFXZCxjQUFjOzs7OztBQTVDZCw4QkFBa0IsR0FBRyxFQUFFOzs7Ozt3QkFFVixlQUFlOzs7Ozs7OztBQUF2QixnQkFBSTs7Ozs7OztBQUVYLDhCQUFjLElBQUksQ0FBQyxVQUFVLDJIQUFFO0FBQXRCLGVBQUM7OztBQUVSLGtCQUFJLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRyxFQUFFLENBQUMsQ0FBQyxLQUFLLEdBQUcsR0FBRzthQUNqQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUQsOEJBQWtCLElBQUksbUJBQW1CO0FBQ3pDLDhCQUFrQixtQkFBaUIsSUFBSSxDQUFDLFFBQVEsZ0JBQWE7Ozs7OztBQU16RCxnQkFBSSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsQ0FBQyxDQUFDOztrQkFDekIsSUFBSSxDQUFDLDBCQUEwQixLQUFLLEVBQUUsSUFBSSxJQUFJLENBQUMsd0JBQXdCLEtBQUssRUFBRTs7Ozs7O0FBRWhGLDhCQUFrQixJQUFJLGdDQUFnQztBQUN0RCw4QkFBa0IscUJBQW1CLElBQUksQ0FBQyxLQUFLLGtCQUFlOzs7Ozs7QUFHOUQsOEJBQWtCLElBQUksZ0NBQWdDOzs7Ozs7O3lCQUdoQyxJQUFJLENBQUMsVUFBVTs7Ozs7Ozs7QUFBNUIscUJBQVM7OztBQUVoQixxQkFBUyxDQUFDLGlCQUFpQixHQUFHLFNBQVMsQ0FBQyxLQUFLO0FBQzdDLG1CQUFPLFNBQVMsQ0FBQyxLQUFLOzs7QUFHdEIsOEJBQWtCLElBQUksaUJBQWlCOzs7OztBQUN2Qyw4QkFBZ0IsTUFBTSxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsMkhBQUU7QUFBL0IsaUJBQUc7O0FBQ1YsZ0NBQWtCLFVBQVEsR0FBRyxTQUFJLFNBQVMsQ0FBQyxHQUFHLENBQUMsVUFBSyxHQUFHLE1BQUc7YUFDM0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0QsOEJBQWtCLElBQUksa0JBQWtCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSTVDLDhCQUFrQixJQUFJLG9CQUFvQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSXhDLDBCQUFjLHFDQUVSLElBQUksQ0FBQyxNQUFNLHVCQUNuQixrQkFBa0I7Z0RBS2IsY0FBYzs7Ozs7OztLQUN0Qjs7O1NBMUhrQixRQUFROzs7cUJBQVIsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDTlIsU0FBUztXQUFULFNBQVM7MEJBQVQsU0FBUzs7O2VBQVQsU0FBUzs7V0FDZixlQUFDLENBQUMsRUFBRTtBQUNmLFVBQUksR0FBRyxHQUFHLEVBQUU7O0FBRVosVUFBSSxDQUFDLFlBQVksS0FBSyxFQUFFO0FBQ3RCLFdBQUcsQ0FBQyxPQUFPLEdBQUcsQ0FBQyxDQUFDLE9BQU87QUFDdkIsV0FBRyxDQUFDLElBQUksR0FBRyxDQUFDLENBQUMsSUFBSTtBQUNqQixXQUFHLENBQUMsUUFBUSxHQUFHLENBQUMsQ0FBQyxRQUFRO0FBQ3pCLFdBQUcsQ0FBQyxVQUFVLEdBQUcsQ0FBQyxDQUFDLFVBQVU7QUFDN0IsV0FBRyxDQUFDLFlBQVksR0FBRyxDQUFDLENBQUMsWUFBWTtBQUNqQyxXQUFHLENBQUMsS0FBSyxHQUFHLENBQUMsQ0FBQyxLQUFLO09BQ3BCLE1BQU07QUFDTCxXQUFHLEdBQUcsQ0FBQztPQUNSOztBQUVELGFBQU8sR0FBRztLQUNYOzs7U0FoQmtCLFNBQVM7OztxQkFBVCxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt1QkNBRixTQUFTOztJQUV4QixlQUFlO1dBQWYsZUFBZTswQkFBZixlQUFlOzs7ZUFBZixlQUFlOztXQUNULGFBQUMsSUFBSSxFQUFFLFVBQVU7VUFDMUIsTUFBTSxFQUNOLEVBQUU7Ozs7OzRDQURhLHFCQUFZLE9BQU8sQ0FBQyxJQUFJLENBQUMsR0FBRyxFQUFFLEVBQUUsZUFBZSxFQUFFLElBQUksRUFBRSxDQUFDOzs7QUFBdkUsa0JBQU07QUFDTixjQUFFLEdBQUcsTUFBTSxDQUFDLEVBQUUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO2dEQUM1QixFQUFFLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQzs7Ozs7OztLQUNqQzs7O1NBTFUsZUFBZTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7cUJDRlYsT0FBTzs7OztzQkFDTixRQUFROzs7O0lBRU4sS0FBSztBQUNaLFdBRE8sS0FBSyxDQUNYLE9BQU8sRUFBRTswQkFESCxLQUFLOzs7QUFHdEIsUUFBSSxDQUFDLElBQUksR0FBRyxtQkFBTSxVQUFVLENBQUMsT0FBTyxDQUFDLENBQUM7OztBQUd0QyxRQUFNLFlBQVksR0FBRyxFQUFFLGtCQUFrQixFQUFFLElBQUksRUFBRSxDQUFDO0FBQ2xELFVBQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQ3JDLFFBQUksQ0FBQyxTQUFTLEdBQUcsbUJBQU0sVUFBVSxDQUFDLFlBQVksQ0FBQyxDQUFDO0dBQ2pEOztlQVRrQixLQUFLOztXQVdQLHFCQUFDLEtBQUssRUFBRSxTQUFTO1VBQUUsT0FBTyx5REFBRyxHQUFHO1VBRXpDLFdBQVcsRUFDWCxTQUFTLEVBQ1QsYUFBYSxFQUViLEdBQUc7Ozs7QUFKSCx1QkFBVyxHQUFHLE9BQU87QUFDckIscUJBQVMsYUFBVyxLQUFLO0FBQ3pCLHlCQUFhLEdBQUcsU0FBUyxjQUFZLFNBQVMsR0FBSyxFQUFFOzs0Q0FFekMsSUFBSSxDQUFDLEtBQUssYUFBVyxXQUFXLFNBQUksU0FBUyxTQUFJLGFBQWEsQ0FBRzs7O0FBQTdFLGVBQUc7Z0RBR0YsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7Ozs7O0tBQ3ZDOzs7Ozs7OztXQVVLLGVBQUMsR0FBRyxFQUFFOzs7QUFHVixhQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FDakIsSUFBSSxDQUNILFVBQUMsR0FBRztlQUFLLElBQUksT0FBTyxDQUNoQixVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUs7O0FBRW5CLGFBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxFQUFFLFVBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBSzs7QUFFekIsZUFBRyxDQUFDLE9BQU8sRUFBRTtBQUNiLGdCQUFJLENBQUMsRUFBRTtBQUNMLG9CQUFNLENBQUMsQ0FBQyxDQUFDO2FBQ1YsTUFBTSxPQUFPLENBQUMsR0FBRyxDQUFDO1dBQ3BCLENBQUM7U0FDSCxDQUNGO09BQUEsQ0FDSixTQUNLLENBQUMsVUFBQyxDQUFDLEVBQUs7QUFDWixjQUFNLENBQUMsQ0FBQztPQUNULENBQUMsQ0FBQztLQUNOOzs7V0FFa0Isc0JBQUMsR0FBRztVQUNmLEdBQUc7Ozs7OzRDQUFTLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBM0IsZUFBRztnREFDRixHQUFHLENBQUMsUUFBUTs7Ozs7OztLQUNwQjs7Ozs7Ozs7OztXQVFpQixxQkFBQyxLQUFLO1VBQUUsSUFBSSx5REFBRyxFQUFFO1VBQUUsT0FBTyx5REFBRyxFQUFFOztVQUkzQyxHQUFHLEVBRUQsR0FBRyxrRkFXRSxDQUFDLHVGQVFOLEdBQUc7Ozs7O0FBckJMLGVBQUcsb0JBQWtCLEtBQUs7QUFFeEIsZUFBRyxHQUFHLElBQUksR0FBRyxFQUFFOzs7Ozs7QUFDckIsNkJBQWdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLHVIQUFFO0FBQXhCLGVBQUM7O0FBQ1Ysa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRTtBQUNwQixtQkFBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7ZUFDcEIsTUFBTSxJQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxXQUFXLENBQUMsSUFBSSxLQUFLLE1BQU0sRUFBRTs7QUFFOUMsbUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxRQUFNLEtBQUssQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLE9BQUksQ0FBQztlQUM5QyxNQUFNO0FBQ0wsbUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFLLG1CQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRyxDQUFDO2VBQ3hDO2FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELDhCQUFnQixNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQywySEFBRTtBQUEzQixlQUFDOztBQUNWLGlCQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN2RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUQsZUFBRyxXQUFTLDZCQUFJLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQUssQ0FBQzs7QUFFM0MsZUFBRyxpQkFBZSw2QkFBSSxHQUFHLENBQUMsTUFBTSxFQUFFLEdBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFLLENBQUM7Ozs0Q0FFakMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNGLEdBQUcsQ0FBQyxRQUFROzs7Ozs7O0tBQ3BCOzs7Ozs7Ozs7OztXQVNpQixxQkFBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPO1VBQ3pDLEdBQUcsRUFFRCxPQUFPLHVGQUlGLENBQUMsdUZBT04sR0FBRzs7Ozs7QUFiTCxlQUFHLGVBQWEsS0FBSztBQUVuQixtQkFBTyxHQUFHLEVBQUU7Ozs7OztBQUNsQiw4QkFBZ0IsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsMkhBQUU7QUFBeEIsZUFBQzs7QUFDVixxQkFBTyxDQUFDLElBQUksQ0FBSSxDQUFDLFNBQUksbUJBQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFHLENBQUM7YUFDL0M7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELDhCQUFnQixNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQywySEFBRTtBQUEzQixlQUFDOztBQUNWLHFCQUFPLENBQUMsSUFBSSxDQUFJLENBQUMsU0FBSSxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUcsQ0FBQzthQUNwQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCxlQUFHLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQzs7QUFFekIsZUFBRyxnQkFBYyxNQUFNLE1BQUcsQ0FBQzs7OzRDQUVULElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBM0IsZUFBRztnREFDRixHQUFHOzs7Ozs7O0tBQ1g7Ozs7O1dBR2dCLG9CQUFDLEdBQUc7VUFDYixRQUFRLEVBR04sR0FBRzs7OztBQUhMLG9CQUFRLEdBQUcsSUFBSSxDQUFDLElBQUk7O0FBQzFCLGdCQUFJLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUM7Ozs0Q0FFUCxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0YsR0FBRzs7Ozs7QUFFVixnQkFBSSxDQUFDLElBQUksR0FBRyxRQUFRLENBQUM7Ozs7Ozs7O0tBRXhCOzs7V0FFc0I7Ozs7OzRDQUNmLElBQUksQ0FBQyxLQUFLLENBQUMsb0JBQW9CLENBQUM7Ozs7Ozs7S0FDdkM7OztXQUVZOzs7Ozs0Q0FDTCxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQzs7Ozs7OztLQUM1Qjs7O1dBRWM7Ozs7OzRDQUNQLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUFDOzs7Ozs7O0tBQzlCOzs7V0FFYyx3QkFBQyxHQUFHLEVBQWtEOzs7VUFBaEQsUUFBUSx5REFBRyxVQUFDLE1BQU0sRUFBSyxFQUFFO1VBQUUsT0FBTyx5REFBRyxVQUFDLENBQUMsRUFBSyxFQUFFOztBQUNqRSxhQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FDakIsSUFBSSxDQUNILFVBQUMsR0FBRztlQUFLLElBQUksT0FBTyxDQUNoQixvQkFBTyxPQUFPLEVBQUUsTUFBTTs7Ozs7QUFFcEIsbUJBQUcsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDLENBQ1gsRUFBRSxDQUFDLFFBQVEsRUFDVixVQUFDLE1BQU0sRUFBSztBQUNWLHFCQUFHLENBQUMsS0FBSyxFQUFFO0FBQ1gsMEJBQVEsQ0FBQyxNQUFNLENBQUM7QUFDaEIscUJBQUcsQ0FBQyxNQUFNLEVBQUU7aUJBQ2IsQ0FBQyxDQUNILEVBQUUsQ0FBQyxPQUFPLEVBQUUsVUFBQyxDQUFDLEVBQUs7QUFDbEIseUJBQU8sQ0FBQyxDQUFDLENBQUM7aUJBQ1gsQ0FBQyxDQUNELEVBQUUsQ0FBQyxLQUFLLEVBQUUsWUFBTTtBQUNmLHFCQUFHLENBQUMsT0FBTyxFQUFFO0FBQ2IseUJBQU8sRUFBRTtpQkFDVixDQUFDOzs7Ozs7O1NBQ0wsQ0FDRjtPQUFBLENBQ0osU0FDSyxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQ1osY0FBTSxDQUFDLENBQUM7T0FDVCxDQUFDLENBQUM7S0FDTjs7O1dBRU0sa0JBQUc7OztBQUNSLGFBQU8sSUFBSSxPQUFPLENBQ2hCLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSzs7QUFFbkIsZUFBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBSztBQUNsQyxjQUFJLENBQUMsRUFBRTtBQUNMLGtCQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7V0FDWCxNQUFNO0FBQ0wsbUJBQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQztXQUNkO1NBQ0YsQ0FBQyxDQUFDO09BQ0osQ0FDRixTQUNPLENBQ0osVUFBQyxDQUFDLEVBQUs7QUFDTCxjQUFNLENBQUMsQ0FBQztPQUNULENBQ0YsQ0FBQztLQUNMOzs7V0F0S2lCLG9CQUFDLElBQUksRUFBRTtBQUN2QixhQUFPLHlCQUFPLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsQ0FBQztLQUNqRTs7O1NBekJrQixLQUFLOzs7cUJBQUwsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQ0hMLE1BQU07QUFDYixXQURPLE1BQU0sQ0FDWixVQUFVLEVBQUU7MEJBRE4sTUFBTTs7QUFFdkIsUUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVO0FBQzVCLFFBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSTtBQUN6QixRQUFJLENBQUMsUUFBUSxHQUFHLElBQUk7QUFDcEIsUUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJO0FBQ3ZCLFFBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQztBQUNkLFFBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQztHQUNyQjs7ZUFSa0IsTUFBTTs7V0FVWixnQkFBQyxHQUFHOzs7O2tCQUVYLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDOzs7OztpQkFDaEMsSUFBSSxDQUFDLGFBQWE7Ozs7Ozs0Q0FDZCxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7OztpQkFHMUMsSUFBSSxDQUFDLFFBQVE7Ozs7Ozs0Q0FDVCxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQzs7O0FBRTFCLGdCQUFJLENBQUMsS0FBSyxFQUFFOztBQUVaLGdCQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDLEVBQUU7QUFDdEMsa0JBQUksQ0FBQyxLQUFLLEVBQUU7QUFDWixrQkFBSSxDQUFDLFdBQVcsRUFBRTthQUNuQjs7Ozs7OztLQUNGOzs7V0FDSyxpQkFBRztBQUNQLFVBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtBQUNwQixZQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7T0FDbkM7S0FDRjs7O1NBL0JrQixNQUFNOzs7cUJBQU4sTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQ0FMLFNBQVM7Ozs7NEJBQ1YsZUFBZTs7MkJBQ2YsZ0JBQWdCOztzQkFDbEIsUUFBUTs7OztJQUVOLE1BQU07QUFDYixXQURPLE1BQU0sR0FDVjswQkFESSxNQUFNOztBQUV2QixRQUFJLENBQUMsTUFBTSxHQUFHLEVBQUU7QUFDaEIsUUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFO0FBQ25CLFFBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSTtHQUNyQjs7OztlQUxrQixNQUFNOztXQVFYLHVCQUFDLE9BQU8sRUFBRTtBQUN0QixVQUFJLENBQUMsUUFBUSxHQUFHLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQztBQUNyQyxVQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0tBQ25DOzs7V0FFVzs7O1VBQUMsSUFBSSx5REFBRyxFQUFFO1VBQUUsRUFBRSx5REFBRzs7Ozs7Ozs7T0FBYztVQUNyQyxHQUFHLEVBT0QsR0FBRzs7OztBQVBMLGVBQUcsR0FBRztBQUNSLHFCQUFPLEVBQUUsMEJBQVE7YUFDbEI7O0FBRUQsZ0JBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQzs7Ozs0Q0FHYixFQUFFLEVBQUU7OztBQUFoQixlQUFHOztBQUVQLGtCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUNqQixrQkFBSSxFQUFFLFNBQVM7QUFDZixtQkFBSyxFQUFFLElBQUk7QUFDWCxvQkFBTSxFQUFFLEdBQUc7YUFDWixDQUFDOzs7Ozs7OztBQUVGLGtCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUNqQixrQkFBSSxFQUFFLE9BQU87QUFDYixtQkFBSyxFQUFFLElBQUk7QUFDWCxvQkFBTSxFQUFFLG1CQUFVLEtBQUssZ0JBQUc7YUFDM0IsQ0FBQzs7Ozs7O0FBR0YsZ0JBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0FBQzlCLG9CQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUNqQix3QkFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTTtlQUMvQixDQUFDO2FBQ0g7O0FBRUQsZUFBRyxDQUFDLFNBQVMsR0FBRyxJQUFJLElBQUksRUFBRTs7QUFFMUIsOEJBQUssTUFBTSxDQUFDLEdBQUcsQ0FBQzs7O0FBR2hCLGdCQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7O0tBRXhCOzs7Ozs7V0FJcUIseUJBQUMsR0FBRyxFQUFFLEVBQUU7VUFFdEIsR0FBRyxFQUdELEdBQUc7Ozs7OzRDQUpFLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Ozs0Q0FDUixHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdEIsZUFBRzs7OzRDQUdXLEVBQUUsQ0FBQyxHQUFHLENBQUM7OztBQUFuQixlQUFHOztBQUNQLGdCQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs7QUFFbEIsZ0JBQUksQ0FBQyxNQUFNLGdCQUFHOzs7Ozs7O0FBR2xCLGVBQUcsQ0FBQyxLQUFLLEVBQUU7Ozs7Ozs7S0FDWjs7O1dBRVEsa0JBQUMsU0FBUyxFQUFFO0FBQ25CLFVBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztLQUNqQzs7O1dBRU0sZ0JBQUMsU0FBUyxFQUFFO0FBQ2pCLFVBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLG1CQUFVLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUNoRDs7O1dBRVksd0JBQUc7QUFDZCxVQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFDO2VBQUksQ0FBQyxDQUFDLFlBQVksRUFBRTtPQUFBLENBQUM7QUFDekQsVUFBSSxRQUFRLEdBQUcsS0FBSzs7Ozs7O0FBQ3BCLDZCQUFnQixJQUFJLENBQUMsTUFBTSw4SEFBRTtjQUFwQixHQUFHOztBQUNWLGNBQUksR0FBRyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7QUFDeEIsb0JBQVEsR0FBRyxJQUFJO0FBQ2Ysa0JBQUs7V0FDTjtTQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0FBQ0QsYUFBTyxRQUFRLElBQUksUUFBUTtLQUM1Qjs7O1dBRU8sbUJBQUc7O0FBRVQsVUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUU7QUFDdkIsY0FBTSxJQUFJLHFCQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO09BQ3BDO0FBQ0QsYUFBTyxJQUFJLENBQUMsTUFBTTtLQUNuQjs7O1NBN0ZrQixNQUFNOzs7cUJBQU4sTUFBTTs7SUFnR3JCLFFBQVE7QUFDQSxXQURSLFFBQVEsQ0FDQyxPQUFPLEVBQUU7MEJBRGxCLFFBQVE7O0FBRVYsUUFBSSxDQUFDLE1BQU0sR0FBRztBQUNaLFdBQUssRUFBRSxDQUFDO0FBQ1IsYUFBTyxFQUFFLENBQUM7QUFDVixXQUFLLEVBQUUsQ0FBQztBQUNSLGFBQU8sRUFBRSxPQUFPO0tBQ2pCO0FBQ0QsUUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJO0dBQ3RCOztlQVRHLFFBQVE7O1dBV0osaUJBQUMsU0FBUyxFQUFFO0FBQ2xCLFVBQUksU0FBUyxFQUFFO0FBQ2IsWUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDO09BQzFCO0FBQ0QsVUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7QUFDckIsVUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7S0FDcEI7OztXQUVLLGVBQUMsU0FBUyxFQUFFOztBQUVoQixVQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEVBQUU7QUFDaEUsWUFBSSxTQUFTLElBQUksU0FBUyxLQUFLLEVBQUUsSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO0FBQ3JELGNBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQztBQUMxQixjQUFJLENBQUMsU0FBUyxHQUFHLFNBQVM7U0FDM0I7T0FDRjtBQUNELFVBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0FBQ25CLFVBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0tBQ3BCOzs7V0FFRyxhQUFDLFNBQVMsRUFBRSxTQUFTLDBDQUEwQztBQUNqRSxVQUFJLEdBQUcsR0FBRztBQUNSLGVBQU8sRUFBRSxTQUFTO0FBQ2xCLGVBQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87QUFDNUIsZUFBTyxFQUFFLFNBQVM7QUFDbEIsaUJBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtPQUN0QjtBQUNELHdCQUFLLE1BQU0sQ0FBQyxHQUFHLENBQUM7S0FDakI7OztXQUVZLHdCQUFHO0FBQ2QsYUFBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7S0FDekI7OztTQTNDRyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3NCQ3JHQSxRQUFROzs7Ozs7Ozs7Ozs7O3FCQVVQLFNBQWUsVUFBVSxDQUN0QyxHQUFHLEVBQUUsR0FBRyxFQUFFLEtBQUssRUFBUyxPQUFPLEVBQUUsT0FBTztNQUE5QixLQUFLLGdCQUFMLEtBQUssR0FBRyxJQUFJO01BRWhCLFlBQVksRUFDWixZQUFZLEVBRVosY0FBYzs7Ozs7O0FBSGQsb0JBQVksR0FBRyxFQUFFO0FBQ2pCLG9CQUFZLEdBQUcsRUFBRTs7QUFFakIsc0JBQWMsR0FBRyxTQUFqQixjQUFjLENBQUksSUFBSSxFQUFFLE9BQU8sRUFBSztBQUN4QyxjQUFNLFFBQVEsR0FBRyxvQkFBRSxTQUFTLENBQUMsSUFBSSxDQUFDLENBQUM7O0FBRW5DLGNBQUksb0JBQUUsV0FBVyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssRUFBRTtBQUM5QyxtQkFBTyxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUM7V0FDMUI7O0FBRUQsaUJBQU8sUUFBUSxDQUFDO1NBQ2pCOzs7QUFHRCxXQUFHLENBQUMsT0FBTyxDQUFDLFVBQUMsSUFBSSxFQUFLO0FBQ3BCLHNCQUFZLENBQUMsSUFBSSxDQUFDO0FBQ2hCLGtCQUFNLEVBQUUsY0FBYyxDQUFDLElBQUksRUFBRSxLQUFLLENBQUM7QUFDbkMsY0FBRSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDZixpQkFBSyxFQUFFOzs7OztBQUtMLGtCQUFJLEVBQUUsS0FBSzthQUNaO1dBQ0YsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDOztBQUVILFdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBQyxJQUFJLEVBQUs7QUFDcEIsc0JBQVksQ0FBQyxJQUFJLENBQUM7QUFDaEIsa0JBQU0sRUFBRSxjQUFjLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQztBQUNuQyxjQUFFLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUNmLGlCQUFLLEVBQUU7Ozs7O0FBS0wsa0JBQUksRUFBRSxLQUFLO2FBQ1o7V0FDRixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7OztBQUdILG9CQUFZLENBQUMsT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFLO0FBQ2hDLHNCQUFZLENBQUMsT0FBTyxDQUFDLFVBQUMsT0FBTyxFQUFLO0FBQ2hDLGdCQUFJLG9CQUFFLE9BQU8sQ0FBQyxPQUFPLENBQUMsTUFBTSxFQUFFLE9BQU8sQ0FBQyxNQUFNLENBQUMsRUFBRTs7QUFFN0MscUJBQU8sQ0FBQyxLQUFLLENBQUMsSUFBSSxHQUFHLElBQUksQ0FBQztBQUMxQixxQkFBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO2FBQzNCO1dBQ0YsQ0FBQyxDQUFDO1NBQ0osQ0FBQyxDQUFDOzs7O3dDQUdHLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxvQkFBTyxJQUFJOzs7O3NCQUN4QyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLOzs7Ozs7Z0RBQ3JCLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7U0FFdEMsQ0FBQyxDQUFDOzs7O3dDQUdHLE9BQU8sQ0FBQyxHQUFHLENBQUMsWUFBWSxDQUFDLEdBQUcsQ0FBQyxvQkFBTyxJQUFJOzs7O3NCQUN4QyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksS0FBSyxLQUFLOzs7Ozs7Z0RBQ3JCLE9BQU8sQ0FBQyxJQUFJLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7U0FFdEMsQ0FBQyxDQUFDOzs7Ozs7O0NBQ0o7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDL0VvQixRQUFRO1dBQVIsUUFBUTswQkFBUixRQUFROzs7ZUFBUixRQUFROzs7O1dBRVosaUJBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUU7QUFDckMsVUFBSSxVQUFVLEtBQUssU0FBUyxFQUFFO0FBQUUsa0JBQVUsR0FBRyxFQUFFO09BQUU7QUFDakQsVUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7QUFDOUIsVUFBSSxLQUFLLEdBQUcsQ0FBQztBQUNiLFVBQUksR0FBRyxHQUFHLEVBQUU7QUFDWixXQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUN6QyxZQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLFlBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQ3BCLEtBQUssSUFBSSxDQUFDO0FBQ2YsWUFBSSxLQUFLLEdBQUcsR0FBRyxFQUFFO0FBQ2YsaUJBQU8sR0FBRyxHQUFHLFVBQVU7U0FDeEI7QUFDRCxXQUFHLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7T0FDdEI7QUFDRCxhQUFPLElBQUk7S0FDWjs7Ozs7V0FHVyxjQUFDLElBQUksRUFBRTtBQUNqQixhQUFPLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDLE9BQU8sQ0FBQyxZQUFZLEVBQUUsSUFBSSxDQUFDLENBQUMsTUFBTTtLQUNuRTs7O1dBRWdCLG1CQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFO0FBQ3RDLFVBQU0sR0FBRyxHQUFHLEdBQUc7O0FBRWYsVUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxVQUFDLElBQUksRUFBRSxPQUFPO2VBQUssSUFBSSxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7T0FBQSxFQUFFLEVBQUUsQ0FBQzs7QUFFNUUsVUFBTSxTQUFTLEdBQUcsU0FBUyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7QUFDdEMsVUFBSSxNQUFNLEdBQUcsRUFBRTtBQUNmLFVBQUksSUFBSSxHQUFHLEVBQUU7OztBQUdiLFVBQUk7QUFDRixpQkFBUyxDQUFDLE1BQU0sQ0FBQyxVQUFDLElBQUksRUFBRSxPQUFPLEVBQUs7O0FBRWxDLGNBQUksUUFBUSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRyxNQUFNLEVBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDN0QsY0FBTSxJQUFJLEdBQUcsQ0FBQyxJQUFJLEtBQUssRUFBRSxHQUFHLElBQUksR0FBRyxHQUFHLEdBQUcsRUFBRSxJQUFJLE9BQU87QUFDdEQsY0FBSSxRQUFRLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxHQUFHLE1BQU0sRUFBRTtBQUNoQyxrQkFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7QUFDakIsZ0JBQUksR0FBRyxPQUFPO0FBQ2QsbUJBQU8sRUFBRTtXQUNWLE1BQU07QUFDTCxnQkFBSSxHQUFHLElBQUk7QUFDWCxtQkFBTyxJQUFJO1dBQ1o7U0FDRixFQUFFLEVBQUUsQ0FBQztPQUNQLENBQUMsT0FBTyxDQUFDLEVBQUU7O0FBRVYsWUFBSSxDQUFDLENBQUMsT0FBTyxLQUFLLE9BQU8sRUFBRSxPQUFNO09BQ2xDOztBQUVELFlBQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDOztBQUVqQixXQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUNwQyxjQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFFO09BQzdDO0tBQ0Y7OztTQTFEa0IsUUFBUTs7O3FCQUFSLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRCQ0FOLGVBQWU7OzJCQUNoQixjQUFjOztBQUU3QixJQUFNLElBQUksR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUM7O0FBQ2xFLElBQU0sT0FBTyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFNBQVMsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7O0FBRXhFLElBQU0sV0FBVyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLGFBQWEsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7QUFDaEYsSUFBTSxhQUFhLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsZUFBZSxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOzs7QUFFcEYsSUFBTSxPQUFPLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsU0FBUyxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOzs7QUFFL0UsSUFBSSxxQkFBTyxRQUFRLEVBQUU7QUFDbkIsdUJBQU8sT0FBTyxDQUFDLFNBQVMsRUFBRSxZQUFNO0FBQzlCLFdBQU8sT0FBTyxDQUFDLElBQUksRUFBRTtHQUN0QixDQUFDLENBQUM7QUFDSCx1QkFBTyxPQUFPLHFCQUNMLG9CQUFvQixFQUFDO1FBQ3BCLEdBQUc7Ozs7OzBDQUFTLGFBQWEsQ0FBQyxhQUFhLEVBQUUsQ0FBQyxTQUFTLENBQUMsQ0FDeEQ7O0FBRUUsa0JBQU0sRUFBRTtBQUNOLGlCQUFHLEVBQUU7QUFDSCxvQkFBSSxFQUFDLGVBQWU7QUFDcEIsb0JBQUksRUFBQyxlQUFlO0FBQ3BCLG1CQUFHLEVBQUUsY0FBYztBQUNuQixvQkFBSSxFQUFFLGVBQWU7ZUFDdEI7QUFDRCxtQkFBSyxFQUFFLEVBQUMsS0FBSyxFQUFFLEVBQUMsS0FBSyxFQUFFLGdCQUFnQixFQUFFLEVBQUUsRUFBRSxhQUFhLEVBQUMsRUFBQzthQUM3RDtXQUNGLEVBQ0Q7QUFDRSxvQkFBUSxFQUFFO0FBQ1IsaUJBQUcsRUFBQyxDQUFDO0FBQ0wsa0JBQUksRUFBQyxXQUFXO0FBQ2hCLGtCQUFJLEVBQUMsV0FBVztBQUNoQixpQkFBRyxFQUFFLFVBQVU7QUFDZixrQkFBSSxFQUFFLFdBQVc7QUFDakIsbUJBQUssRUFBRSxRQUFRO2FBQ2hCO1dBQ0YsQ0FDRixDQUFDLENBQUMsT0FBTyxFQUFFOzs7QUF2Qk4sYUFBRzs4Q0F3QkYsR0FBRzs7Ozs7OztHQUNYLEVBQ0QsQ0FBQzs7QUFFSCx1QkFBTyxPQUFPLENBQUMsbUJBQW1CLEVBQUU7Ozs7OENBQzNCLGFBQWEsQ0FBQyxJQUFJLEVBQUU7Ozs7Ozs7R0FDNUIsQ0FBQyxDQUFDO0NBQ0o7O0FBRUQsSUFBSSxxQkFBTyxRQUFRLEVBQUU7QUFDbkIsdUJBQU8sU0FBUyxDQUFDLFNBQVMsQ0FBQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCAocmVxLCByZXMsIG5leHQpID0+IHtcclxuLy8gICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbi8vICAgcmVzLmVuZChgSGVsbG8gd29ybGQgZnJvbTogJHtNZXRlb3IucmVsZWFzZX1gKTtcclxuLy8gfSk7XHJcblxyXG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xyXG5pbXBvcnQgdW5pcWlkIGZyb20gJ3VuaXFpZCc7XHJcblxyXG4vLyBSZXF1aXJlcyBtdWx0aXBhcnR5IFxyXG5pbXBvcnQgbXVsdGlwYXJ0eSBmcm9tICdjb25uZWN0LW11bHRpcGFydHknO1xyXG5pbXBvcnQge1xyXG4gIFVwbG9hZHNcclxufSBmcm9tICcuLi8uLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb25zJztcclxubGV0IG11bHRpcGFydHlNaWRkbGV3YXJlID0gbXVsdGlwYXJ0eSgpO1xyXG5cclxuY29uc3Qgcm91dGUgPSAnL3VwbG9hZC9pbWFnZSc7XHJcblxyXG4vLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIGZ1Yy51cGxvYWRGaWxlICk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCBtdWx0aXBhcnR5TWlkZGxld2FyZSk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCAocmVxLCByZXNwKSA9PiB7XHJcbiAgLy8gZG9uJ3QgZm9yZ2V0IHRvIGRlbGV0ZSBhbGwgcmVxLmZpbGVzIHdoZW4gZG9uZVxyXG5cclxuICBjb25zdCByZWFkZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLnJlYWRGaWxlKTtcclxuICBjb25zdCB3cml0ZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLndyaXRlRmlsZSk7XHJcbiAgY29uc3QgdXBsb2FkSWQgPSB1bmlxaWQoKTtcclxuXHJcbiAgZm9yIChsZXQgZmlsZSBvZiByZXEuZmlsZXMuZmlsZSkge1xyXG4gICAgY29uc3QgZGF0YSA9IHJlYWRlcihmaWxlLnBhdGgpO1xyXG4gICAgLy8g44OV44Kh44Kk44Or5ZCN44Gu6YeN6KSH44KS6YG/44GR44KL44Gf44KB44CB5LiA5oSP44Gu44OV44Kh44Kk44Or5ZCN44KS5L2c5oiQ44GZ44KLXHJcbiAgICAvLyDmpb3lpKnjga7jg5XjgqHjgqTjg6vlkI3mloflrZfmlbDliLbpmZAyMOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IGZpbGVuYW1lID0gYCR7dW5pcWlkKCl9LmpwZ2BcclxuXHJcbiAgICAvLyBzZXQgdGhlIGNvcnJlY3QgcGF0aCBmb3IgdGhlIGZpbGUgbm90IHRoZSB0ZW1wb3Jhcnkgb25lIGZyb20gdGhlIEFQSTpcclxuICAgIGxldCBzYXZlUGF0aCA9IHJlcS5ib2R5LmltYWdlZGlyICsgJy8nICsgZmlsZW5hbWU7XHJcblxyXG4gICAgLy8gY29weSB0aGUgZGF0YSBmcm9tIHRoZSByZXEuZmlsZXMuZmlsZS5wYXRoIGFuZCBwYXN0ZSBpdCB0byBmaWxlLnBhdGhcclxuXHJcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nntZDmnpzjgpLoqJjpjLLjgZnjgotcclxuICAgIGxldCBkb2MgPSB7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgICAgY2xpZW50RmlsZU5hbWU6IGZpbGUubmFtZSxcclxuICAgICAgdXBsb2FkZWRGaWxlTmFtZTogZmlsZW5hbWVcclxuICAgIH07XHJcbiAgICBcclxuICAgIHRyeXtcclxuICAgICAgd3JpdGVyKHNhdmVQYXRoLCBkYXRhKTtcclxuICAgIH1cclxuICAgIGNhdGNoKGVycil7XHJcbiAgICAgIGRvYy5lcnJvciA9IGVycjtcclxuICAgIH1cclxuICAgIFVwbG9hZHMuaW5zZXJ0KGRvYyk7XHJcblxyXG4gICAgZGVsZXRlIGZpbGU7XHJcblxyXG4gIH07XHJcbiAgcmVzcC53cml0ZUhlYWQoMjAwKTtcclxuICByZXNwLmVuZChKU09OLnN0cmluZ2lmeSh7XHJcbiAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICBzYXZlRGlyOiByZXEuYm9keS5pbWFnZWRpclxyXG4gIH0pKTtcclxuXHJcbn0pOyIsImltcG9ydCBjcnlwdG8gZnJvbSAnY3J5cHRvJ1xyXG5cclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IFJlcG9ydCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIEdyb3VwLFxyXG4gIEdyb3VwRmFjdG9yeVxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9ncm91cHMnXHJcbmltcG9ydCB7XHJcbiAgRmlsdGVyXHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2ZpbHRlcnMnXHJcblxyXG5sZXQgdGFnID0gJ2N1YmVtaWcnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm1pZ3JhdGVgXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgLy8gc2V0dXAgZ3JvdXBcclxuICAgIC8vXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBGaWx0ZXIoY29uZmlnLnNyY0ZpbHRlcklkKVxyXG4gICAgLy8gbGV0IHBsdWcgPSBncm91cC5nZXRQbHVnKCk7XHJcblxyXG4gICAgLy8gY2hlY2tpbmcgY29ubmVjdGlvblxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgdGVzdFF1ZXJ5ID0gJ1NIT1cgREFUQUJBU0VTJ1xyXG5cclxuICAgIGxldCBkc3REYiA9IG5ldyBNeVNRTChjb25maWcuZHN0LmNyZWQpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKCdDb25uZWN0IHRvIERlc3RpbmF0aW9uJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5KHRlc3RRdWVyeSlcclxuICAgICAgfSlcclxuXHJcbiAgICAvLyBwcm9jZXNzIGZvciBlYWNoIG1lbWJlcnNcclxuICAgIC8vXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKCdTZWxlY3QgbG9vcCBpbiBzb3VyY2UnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgIG1vYmlsZU51bGw6IGFzeW5jIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgLy8gLy8g5YCk44KS5pW055CGXHJcbiAgICAgICAgICAgIC8vIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgIC8vICAgaWYgKHJlY29yZFtrZXldID09PSBudWxsKTtcclxuICAgICAgICAgICAgLy8gICBlbHNlIGlmIChyZWNvcmRba2V5XS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnRGF0ZScpIHtcclxuICAgICAgICAgICAgLy8gICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgICAgICAvLyAgICAgcmVjb3JkW2tleV0gPSBNeVNRTC5mb3JtYXREYXRlKHJlY29yZFtrZXldKTtcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gYFwiJHtyZWNvcmRba2V5XX1cImA7XHJcbiAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXIg44Gr5L+d5a2YXHJcblxyXG4gICAgICAgICAgICBsZXQgc3FsID0gYFxyXG5cclxuICAgICAgICAgICAgICAgIElOU0VSVCBkdGJfY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICggXFxgY3VzdG9tZXJfaWRcXGAsIFxcYHN0YXR1c1xcYCwgXFxgc2V4XFxgLCBcXGBqb2JcXGAsIFxcYGNvdW50cnlfaWRcXGAsIFxcYHByZWZcXGAsIFxcYG5hbWUwMVxcYCwgXFxgbmFtZTAyXFxgLCBcXGBrYW5hMDFcXGAsIFxcYGthbmEwMlxcYCwgXFxgY29tcGFueV9uYW1lXFxgLCBcXGB6aXAwMVxcYCwgXFxgemlwMDJcXGAsIFxcYHppcGNvZGVcXGAsIFxcYGFkZHIwMVxcYCwgXFxgYWRkcjAyXFxgLCBcXGBlbWFpbFxcYCwgXFxgdGVsMDFcXGAsIFxcYHRlbDAyXFxgLCBcXGB0ZWwwM1xcYCwgXFxgZmF4MDFcXGAsIFxcYGZheDAyXFxgLCBcXGBmYXgwM1xcYCwgXFxgYmlydGhcXGAsIFxcYHBhc3N3b3JkXFxgLCBcXGBzYWx0XFxgLCBcXGBzZWNyZXRfa2V5XFxgLCBcXGBmaXJzdF9idXlfZGF0ZVxcYCwgXFxgbGFzdF9idXlfZGF0ZVxcYCwgXFxgYnV5X3RpbWVzXFxgLCBcXGBidXlfdG90YWxcXGAsIFxcYG5vdGVcXGAsIFxcYGNyZWF0ZV9kYXRlXFxgLCBcXGB1cGRhdGVfZGF0ZVxcYCwgXFxgZGVsX2ZsZ1xcYCApXHJcblxyXG4gICAgICAgICAgICAgICAgVkFMVUVTKCAke3JlY29yZC5jdXN0b21lcl9pZH0gLCAke3JlY29yZC5zdGF0dXN9ICwgJHtyZWNvcmQuc2V4fSAsICR7cmVjb3JkLmpvYn0gLCAke3JlY29yZC5jb3VudHJ5X2lkfSAsICR7cmVjb3JkLnByZWZ9ICwgJHtyZWNvcmQubmFtZTAxfSAsICR7cmVjb3JkLm5hbWUwMn0gLCAke3JlY29yZC5rYW5hMDF9ICwgJHtyZWNvcmQua2FuYTAyfSAsICR7cmVjb3JkLmNvbXBhbnlfbmFtZX0gLCAke3JlY29yZC56aXAwMX0gLCAke3JlY29yZC56aXAwMn0gLCAke3JlY29yZC56aXBjb2RlfSAsICR7cmVjb3JkLmFkZHIwMX0gLCAke3JlY29yZC5hZGRyMDJ9ICwgJHtyZWNvcmQuZW1haWx9ICwgJHtyZWNvcmQudGVsMDF9ICwgJHtyZWNvcmQudGVsMDJ9ICwgJHtyZWNvcmQudGVsMDN9ICwgJHtyZWNvcmQuZmF4MDF9ICwgJHtyZWNvcmQuZmF4MDJ9ICwgJHtyZWNvcmQuZmF4MDN9ICwgJHtyZWNvcmQuYmlydGh9ICwgJHtyZWNvcmQucGFzc3dvcmR9ICwgJHtyZWNvcmQuc2FsdH0gLCAke3JlY29yZC5zZWNyZXRfa2V5fSAsICR7cmVjb3JkLmZpcnN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmxhc3RfYnV5X2RhdGV9ICwgJHtyZWNvcmQuYnV5X3RpbWVzfSAsICR7cmVjb3JkLmJ1eV90b3RhbH0gLCAke3JlY29yZC5ub3RlfSAsICR7cmVjb3JkLmNyZWF0ZV9kYXRlfSAsICR7cmVjb3JkLnVwZGF0ZV9kYXRlfSAsICR7cmVjb3JkLmRlbF9mbGd9IClcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgYFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdkdGJfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVjb3JkLnN0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgc2V4OiByZWNvcmQuc2V4LFxyXG4gICAgICAgICAgICAgICAgICBqb2I6IHJlY29yZC5qb2IsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgZW1haWw6IHJlY29yZC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgYmlydGg6IHJlY29yZC5iaXJ0aCxcclxuICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHJlY29yZC5wYXNzd29yZCxcclxuICAgICAgICAgICAgICAgICAgc2FsdDogcmVjb3JkLnNhbHQsXHJcbiAgICAgICAgICAgICAgICAgIHNlY3JldF9rZXk6IHJlY29yZC5zZWNyZXRfa2V5LFxyXG4gICAgICAgICAgICAgICAgICBmaXJzdF9idXlfZGF0ZTogcmVjb3JkLmZpcnN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBsYXN0X2J1eV9kYXRlOiByZWNvcmQubGFzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RpbWVzOiByZWNvcmQuYnV5X3RpbWVzLFxyXG4gICAgICAgICAgICAgICAgICBidXlfdG90YWw6IHJlY29yZC5idXlfdG90YWwsXHJcbiAgICAgICAgICAgICAgICAgIG5vdGU6IHJlY29yZC5ub3RlLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyX2FkZHJlc3NcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdkdGJfY3VzdG9tZXJfYWRkcmVzcycsIHtcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfYWRkcmVzc19pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8g44Oh44Or44Oe44Ks44OX44Op44Kw44Kk44OzIHBsZ19tYWlsbWFnYV9jdXN0b21lclxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ3BsZ19tYWlsbWFnYV9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIG1haWxtYWdhX2ZsZzogcmVjb3JkLm1haWxtYWdhX2ZsZyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOOCr+ODvOODneODs+eZuuihjO+8iEVDQ1VCRTLjga7jg53jgqTjg7Pjg4jpgoTlhYPvvIlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25DZCA9IGNyeXB0by5yYW5kb21CeXRlcyg4KS50b1N0cmluZygnYmFzZTY0Jykuc3Vic3RyaW5nKDAsIDExKVxyXG5cclxuICAgICAgICAgICAgbGV0IGNvdXBvbk5hbWUgPSBgJHtyZWNvcmQubmFtZTAxfSAke3JlY29yZC5uYW1lMDJ9IOanmCDjgZTlhKrlvoXjgq/jg7zjg53jg7Mg5Lya5ZOh55Wq5Y+3OiR7cmVjb3JkLmN1c3RvbWVyX2lkfWBcclxuXHJcbiAgICAgICAgICAgIGxldCBkaXNjb3VudFByaWNlID0gcmVjb3JkLnBvaW50ICsgNTAwXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfY291cG9uJywge1xyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25faWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9jZDogY291cG9uQ2QsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl90eXBlOiAzLCAvLyDlhajllYblk4FcclxuICAgICAgICAgICAgICAgICAgY291cG9uX25hbWU6IGNvdXBvbk5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3R5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl91c2VfdGltZTogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3JlbGVhc2U6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3ByaWNlOiBkaXNjb3VudFByaWNlLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9yYXRlOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBlbmFibGVfZmxhZzogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX21lbWJlcjogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2xvd2VyX2xpbWl0OiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfZnJvbV9kYXRlOiAnMjAxOC0wNC0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV90b19kYXRlOiAnMjAxOS0wNS0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IDBcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIGFzeW5jICdjdWJlbWlnLnNlcnZlckNoZWNrJyAocHJvZmlsZSkge1xyXG4gICAgbGV0IGRiID0gbmV3IE15U1FMKHByb2ZpbGUpXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgZGIucXVlcnkoJ1NIT1cgREFUQUJBU0VTJylcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgeyBNb25nb0NvbGxlY3Rpb24gfSBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbW9uZ28nXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdqbGluZS5jb2xsZWN0aW9uJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5maW5kYF0gKHBsdWcsIHF1ZXJ5ID0ge30sIHByb2plY3Rpb24gPSB7fSkge1xyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbilcclxuICAgIGxldCByZXMgPSBhd2FpdCBjb2xsLmZpbmQocXVlcnksIHtwcm9qZWN0aW9uOiBwcm9qZWN0aW9ufSkudG9BcnJheSgpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uYWdncmVnYXRlYF0gKHBsdWcsIHF1ZXJ5ID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5hZ2dyZWdhdGUocXVlcnkpLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uLy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcyc7XG5cbmNvbnN0IHRhZyA9ICdqbGluZS5pdGVtcyc7XG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAvKipcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44G+44GZ44CCXG4gICAqIEBwYXJhbVxuICAgKi9cbiAgYXN5bmMgW2Ake3RhZ30uc2V0SW1hZ2VgXSAocGx1ZywgdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XG4gICAgY29uc3QgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKTtcbiAgICBjb25zdCB1cGxvYWRlZCA9IGF3YWl0IGl0ZW1jb24uc2V0SW1hZ2UodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEsIGNsYXNzMik7XG4gICAgcmV0dXJuIHVwbG9hZGVkO1xuICB9LFxuXG4gIC8qKlxuICAgKiDjgqLjgqTjg4bjg6Dmg4XloLHjg4fjg7zjgr/jg5njg7zjgrnjga7nlLvlg4/nmbvpjLLjgpLliYrpmaTjgZnjgovvvIjnlLvlg4/oh6rkvZPjga/liYrpmaTjgZfjgarjgYTvvIlcbiAgICovXG4gIGFzeW5jIFtgJHt0YWd9LmNsZWFuSW1hZ2VgXSAocGx1ZywgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcbiAgICBjb25zdCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKCk7XG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpO1xuICAgIGF3YWl0IGl0ZW1jb24uY2xlYW5JbWFnZShtb2RlbCwgY2xhc3MxLCBjbGFzczIpO1xuICB9LFxuXG59KTtcbiIsImltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcbmltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCc7XG5pbXBvcnQge1xuICBNb25nb0RCRmlsdGVyLFxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInO1xuaW1wb3J0IHtcbiAgQ3ViZTNBcGksXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9jdWJlM2FwaSc7XG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJztcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnO1xuXG5cbmNvbnN0IHRhZyA9ICdjdWJlJztcblxuTWV0ZW9yLm1ldGhvZHMoe1xuXG4gIC8vXG4gIC8vIOOCq+ODhuOCtOODquabtOaWsFxuXG4gIGFzeW5jIFtgJHt0YWd9LmNhdGVnb3J5YF0gKGNvbmZpZykge1xuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxuICAgIGNvbnN0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKTtcblxuICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSk7XG4gICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKTtcbiAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKTtcblxuICAgIGNvbnN0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKTtcbiAgICBjb25zdCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpO1xuXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxuICAgICAgJ+WVhuWTgeOCq+ODhuOCtOODquOBruabtOaWsCcsXG4gICAgICBhc3luYyAoKSA9PiB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcbiAgICAgICAgICBVUERBVEU6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XG4gICAgICAgICAgICAvLyDllYblk4Hjgavjgqvjg4bjgrTjg6rjg7zjg4fjg7zjgr/jgYzoqJjpjLLjgZXjgozjgabjgYTjgozjgbDlh6bnkIbjgZnjgotcbiAgICAgICAgICAgIGlmIChfLmlzQXJyYXkoaXRlbS5tYWxsLnNoYXJha3VTaG9wLmNhdGVnb3JpZXMpKSB7XG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgLy8g5ZWG5ZOB5oOF5aCx44OH44O844K/44OZ44O844K544Gr6KiY6Yyy44GV44KM44Gf5ZWG5ZOB44Kr44OG44K044Oq44O85oOF5aCx44KS44CB44Oi44O844Or44Gr6YGp55So44GZ44KLXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IGFwaS5tb2RpZnlDYXRlZ29yeShcbiAgICAgICAgICAgICAgICAgIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkLFxuICAgICAgICAgICAgICAgICAgaXRlbS5tYWxsLnNoYXJha3VTaG9wLmNhdGVnb3JpZXMsXG4gICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgIC8vIFNRTOOCr+OCqOODque1kOaenOOCkuiomOmMslxuICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhyZXN1bHRzKTtcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XG4gICAgICAgICAgICAgIH1cbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XG4gIH0sXG5cbiAgLy9cbiAgLy8g5Zyo5bqr5pu05pawXG5cbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlU3RvY2tgXSAoY29uZmlnKSB7XG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXG4gICAgY29uc3QgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xuXG4gICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKTtcbiAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpO1xuXG4gICAgY29uc3QgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xuICAgIGNvbnN0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XG5cbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXG4gICAgICAn5Zyo5bqr44Gu5pu05pawJyxcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xuXG4gICAgICAgICAgVVBEQVRFOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZCk7XG4gICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XG4gIH0sXG5cbiAgLy9cbiAgLy8g5ZWG5ZOB5oOF5aCx55m76Yyy44Go5pu05pawXG5cbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJJdGVtYF0gKGNvbmZpZykge1xuICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSk7XG4gICAgY29uc3QgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xuICAgIGNvbnN0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XG5cbiAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpO1xuXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXG4gICAgY29uc3QgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xuXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxuICAgICAgJ0VDQ1VCRTPjgbjjga7llYblk4HnmbvpjLInLFxuICAgICAgYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XG4gICAgICAgICAgSU5TRVJUOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgY29sID0gY29udGV4dC5jb2xsZWN0aW9uO1xuXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBjb25zdCBjdWJlSXRlbSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnLnVwZGF0ZUl0ZW0sIGl0ZW0pO1xuXG4gICAgICAgICAgICAgIGNvbnN0IGluc2VydFJlcyA9IGF3YWl0IGFwaS5wcm9kdWN0Q3JlYXRlKGN1YmVJdGVtKTtcblxuICAgICAgICAgICAgICAvLyBpdGVtIOODh+ODvOOCv+ODmeODvOOCueOBuOOBrueZu+mMslxuICAgICAgICAgICAgICBhd2FpdCBjb2wudXBkYXRlT25lKHtcbiAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkLFxuICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9pZCc6IGluc2VydFJlcy5yZXMucHJvZHVjdF9pZCxcbiAgICAgICAgICAgICAgICAgICdtYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQnOiBpbnNlcnRSZXMucmVzLnByb2R1Y3RfY2xhc3NfaWQsXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X3N0b2NrX2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X3N0b2NrX2lkLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XG4gICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcbiAgICAgICdFQ0NVQkUz5ZWG5ZOB5oOF5aCx44Gu5pu05pawJyxcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xuICAgICAgICAgIFVQREFURTogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvbjtcblxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgY29uc3QgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy51cGRhdGVJdGVtLCBpdGVtKTtcblxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdEltYWdlVXBkYXRlKGN1YmVJdGVtKTtcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RVcGRhdGUoY3ViZUl0ZW0pO1xuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSk7XG5cbiAgICAgICAgICAgICAgY29uc3QgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZCk7XG4gICAgICAgICAgICAgIGF3YWl0IGFwaS51cGRhdGVTdG9jayhpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCwgcXVhbnRpdHkpO1xuXG4gICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XG4gICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpO1xuICB9LFxuXG59KTtcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgY3N2IGZyb20gJ2NzdidcclxuaW1wb3J0IHsgVHJhbnNmb3JtLCBXcml0YWJsZSB9IGZyb20gJ3N0cmVhbSdcclxuXHJcbmltcG9ydCBGaWJlciBmcm9tICdmaWJlcnMnXHJcbmltcG9ydCBSb2JvdGluIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9yb2JvdGluJ1xyXG5cclxuY29uc3QgdGFnID0gJ3JvYm90aW4nXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm9yZGVyLmV4cG9ydGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1JvYm90LWluIOWPl+azqENTViDlh7rlipsnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS8ke2NvbmZpZy5vcmRlci53b3JrZGlyfWA7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpckV4cG9ydCA9IGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyLndvcmtkaXJFeHBvcnR9YDtcclxuICAgICAgICBjb25zdCBvcmRlckNzdkV4cG9ydCA9IGAke2NvbmZpZy5vcmRlci5vcmRlcmNzdkV4cG9ydH0uY3N2YDtcclxuICAgICAgICBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgLy8g6Kqt44G/5Y+W44KK44OV44Kp44Or44OAXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXJFeHBvcnQpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aa5rqW5YKZXHJcbiAgICAgICAgY29uc3QgaXRlbVMgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1TLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOWPl+azqENTVuOCkuWHuuWKm+OBmeOCi1xyXG4gICAgICAgIE1ldGVvci53cmFwQXN5bmMobWNiID0+IHtcclxuICAgICAgICAgIGNvbnN0IHJlYWQgPSBSb2JvdGluLmNyZWF0ZVJlYWRhYmxlT3JkZXIoKVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHsgbWNiKGVycikgfSlcclxuXHJcbiAgICAgICAgICBjb25zdCB0cmFuc2Zvcm0gPSBuZXcgVHJhbnNmb3JtKHtcclxuICAgICAgICAgICAgd3JpdGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICByZWFkYWJsZU9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogKGNodW5rLCBlbmMsIGNiKT0+e1xyXG4gICAgICAgICAgICAgIGNiKG51bGwsIGNodW5rLnJvYm90aW4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICBjb25zdCB3cml0ZSA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2RpckV4cG9ydH0vJHtvcmRlckNzdkV4cG9ydH1gKVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHsgbWNiKGVycikgfSlcclxuICAgICAgICAgICAgLm9uKCdmaW5pc2gnLCAoKT0+e1xyXG4gICAgICAgICAgICAgIG1jYigpXHJcbiAgICAgICAgICAgIH0pXHJcblxyXG4gICAgICAgICAgcmVhZFxyXG4gICAgICAgICAgICAucGlwZSh0cmFuc2Zvcm0pXHJcbiAgICAgICAgICAgIC5waXBlKGNzdi5zdHJpbmdpZnkoe2hlYWRlcjogdHJ1ZX0pKVxyXG4gICAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgICAucGlwZSh3cml0ZSlcclxuICAgICAgICB9KSgpXHJcblxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5vcmRlci5pbXBvcnRgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdSb2JvdC1pbiDlj5fms6hDU1Yg5Y+W6L6844G/JyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vJHtjb25maWcub3JkZXIud29ya2Rpcn1gO1xyXG4gICAgICAgIGNvbnN0IHdvcmtkaXJJbXBvcnQgPSBgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlci53b3JrZGlySW1wb3J0fWA7XHJcbiAgICAgICAgY29uc3Qgb3JkZXJDc3YgPSBgJHtjb25maWcub3JkZXIub3JkZXJjc3Z9LmNzdmA7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIC8vIOiqreOBv+WPluOCiuODleOCqeODq+ODgFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlySW1wb3J0KVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mua6luWCmVxyXG4gICAgICAgIGNvbnN0IGl0ZW1TID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtUy5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDlj5fms6hDU1bjgpLoqq3jgb/ovrzjgoBcclxuICAgICAgICBNZXRlb3Iud3JhcEFzeW5jKG1jYiA9PiB7XHJcbiAgICAgICAgICBjb25zdCByZWFkID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJJbXBvcnR9LyR7b3JkZXJDc3Z9YClcclxuICAgICAgICAgICAgLm9uKCdlcnJvcicsIGVyciA9PiB7IG1jYihlcnIpIH0pXHJcbiAgICAgICAgICBjb25zdCB3cml0ZSA9IG5ldyBXcml0YWJsZSh7XHJcbiAgICAgICAgICAgIG9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHdyaXRlIChjaHVuaywgZW5jb2RpbmcsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgICAgICAgRmliZXIoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgYXdhaXQgUm9ib3Rpbi5pbXBvcnRPcmRlcihjaHVuaywgaXRlbVMpXHJcbiAgICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2F0Y2goZXJyKXtcclxuICAgICAgICAgICAgICAgICAgY2FsbGJhY2soZXJyKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2soKVxyXG4gICAgICAgICAgICAgIH0pLnJ1bigpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGZpbmFsIChjYWxsYmFjaykge1xyXG4gICAgICAgICAgICAgIGNhbGxiYWNrKClcclxuICAgICAgICAgICAgICBtY2IoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHJlcG9ydC5pRXJyb3IoZXJyKSlcclxuXHJcbiAgICAgICAgICByZWFkLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAgIC5waXBlKHdyaXRlKVxyXG4gICAgICAgIH0pKClcclxuXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnBvc3RsYWJlbGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1JvYm90LWluIOmAgeOCiueKtueZuuihjCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9LyR7Y29uZmlnLnBvc3RsYWJlbC53b3JrZGlyfWBcclxuICAgICAgICBjb25zdCB3b3JrZGlyUmVhZCA9IGAke3dvcmtkaXJ9LyR7Y29uZmlnLnBvc3RsYWJlbC53b3JrZGlyUmVhZH1gXHJcbiAgICAgICAgY29uc3Qgd29ya2RpcldyaXRlID0gYCR7d29ya2Rpcn0vJHtjb25maWcucG9zdGxhYmVsLndvcmtkaXJXcml0ZX1gXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIC8vIOiqreOBv+WPluOCiuODleOCqeODq+ODgFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyUmVhZClcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAvLyDmm7jjgY3ovrzjgb/jg5Xjgqnjg6vjg4BcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcldyaXRlKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIHdvcmtkaXIg44GM5rqW5YKZ44GV44KM44Gm44GE44Gf44KJ5a6f6KGM44GZ44KLXHJcbiAgICAgICAgY29uc3QgaXRlbVMgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1TLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOWPl+azqENTVuOCkuiqreOBv+i+vOOCgFxyXG4gICAgICAgIGNvbnN0IHJvYm8gPSBuZXcgUm9ib3RpbigpXHJcbiAgICAgICAgTWV0ZW9yLndyYXBBc3luYyhtY2IgPT4ge1xyXG4gICAgICAgICAgY29uc3QgcmVhZCA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyUmVhZH0vJHtjb25maWcucG9zdGxhYmVsLm9yZGVyY3N2fS5jc3ZgKVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHsgbWNiKGVycikgfSlcclxuICAgICAgICAgIGNvbnN0IHdyaXRlID0gbmV3IFdyaXRhYmxlKHtcclxuICAgICAgICAgICAgb2JqZWN0TW9kZTogdHJ1ZSxcclxuICAgICAgICAgICAgd3JpdGUgKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgICByb2JvLmltcG9ydE9yZGVyVGVtcChjaHVuaywgaXRlbVMpXHJcbiAgICAgICAgICAgICAgY2FsbGJhY2soKVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBmaW5hbCAoY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgICBjYWxsYmFjaygpXHJcbiAgICAgICAgICAgICAgbWNiKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICByZWFkLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAgIC5waXBlKHdyaXRlKVxyXG4gICAgICAgIH0pKClcclxuXHJcbiAgICAgICAgLy8g6YCB44KK54q256iu5Yil44GU44Go44Gr57mw44KK6L+U44GZXHJcbiAgICAgICAgY29uZmlnLnBvc3RsYWJlbC5sYWJlbHR5cGVzLmZvckVhY2gobGFiZWxPcHRpb24gPT4ge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgTWV0ZW9yLndyYXBBc3luYyhtY2IgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IHJlYWQgPSBmc0V4dHJhLmNyZWF0ZVJlYWRTdHJlYW0oYCR7d29ya2RpclJlYWR9LyR7bGFiZWxPcHRpb24ucmVhZGNzdn0uY3N2YClcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoKSA9PiB7IG1jYigpIH0pIC8vIOODleOCoeOCpOODq+OBjOOBquOBhOWgtOWQiOOBr+eEoeimllxyXG4gICAgICAgICAgICAgIGNvbnN0IHRyYW5zZm9ybSA9IG5ldyBUcmFuc2Zvcm0oe1xyXG4gICAgICAgICAgICAgICAgcmVhZGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgd3JpdGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiAoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBsZXQgcmVjb3JkXHJcbiAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgRmliZXIoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmVjb3JkID0gcm9ib1tsYWJlbE9wdGlvbi5tZXRob2RdKGNodW5rLCBsYWJlbE9wdGlvbilcclxuICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHJlY29yZClcclxuICAgICAgICAgICAgICAgICAgICB9KS5ydW4oKVxyXG4gICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIG1jYihlcnJvcilcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgY29uc3Qgd3JpdGUgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke3dvcmtkaXJXcml0ZX0vJHtsYWJlbE9wdGlvbi53cml0ZWNzdn0uY3N2YClcclxuICAgICAgICAgICAgICAgIC5vbignZmluaXNoJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKVxyXG4gICAgICAgICAgICAgICAgICBtY2IoKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCBlcnJvciA9PiB7IG1jYihlcnJvcikgfSlcclxuXHJcbiAgICAgICAgICAgICAgcmVhZFxyXG4gICAgICAgICAgICAgICAgLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAgICAgICAucGlwZShjc3YucGFyc2Uoe2NvbHVtbnM6IGxhYmVsT3B0aW9uLmNvbHVtbnMgPT09IHRydWUgPyB0cnVlIDogbnVsbH0pKVxyXG4gICAgICAgICAgICAgICAgLnBpcGUodHJhbnNmb3JtKVxyXG4gICAgICAgICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiBsYWJlbE9wdGlvbi5jb2x1bW5zfSkpXHJcbiAgICAgICAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKHdyaXRlKVxyXG4gICAgICAgICAgICB9KSgpXHJcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICByZXBvcnQuaUVycm9yKGVycm9yKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gUm9ib3QtaW5cclxuICAvLyDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7dcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uaXRlbWNvZGVgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdSb2JvdC1pbiDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7cnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS8ke2NvbmZpZy5pdGVtY29kZS53b3JrZGlyfWBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgLy8gd29ya2RpciDjgYzmupblgpnjgZXjgozjgabjgYTjgZ/jgonlrp/ooYzjgZnjgotcclxuICAgICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgICAgY29uc3QgcmVhZCA9IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmZpbmQoe21vZGVsOiB7JG5lOiAnJ319KS5zdHJlYW0oKVxyXG5cclxuICAgICAgICAgIGNvbnN0IHdyaXRlQ3N2ID0gKHJlYWQsIHRmLCBmaWxlbmFtZSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCByb2JvdGluID0gbmV3IFRyYW5zZm9ybSh7XHJcbiAgICAgICAgICAgICAgcmVhZGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgIHdyaXRhYmxlT2JqZWN0TW9kZTogdHJ1ZSxcclxuICAgICAgICAgICAgICB0cmFuc2Zvcm0gKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgICAgIEZpYmVyKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgZGF0YSA9IHRmKGNodW5rKVxyXG4gICAgICAgICAgICAgICAgICBjYWxsYmFjayhudWxsLCBkYXRhKVxyXG4gICAgICAgICAgICAgICAgfSkucnVuKClcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIGxldCBjb3VudCA9IDBcclxuICAgICAgICAgICAgY29uc3QgY2xlYXJudW0gPSBuZXcgVHJhbnNmb3JtKHtcclxuICAgICAgICAgICAgICBlbmNvZGluZzogJ3V0ZjgnLFxyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBzdHIgPSBjaHVuay50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICBpZiAoY291bnQgPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgc3RyID0gc3RyLnJlcGxhY2UoL19cXGQrPy9nLCAnJylcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvdW50KytcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHN0cilcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIGNvbnN0IHdyaXRlY3N2ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbShgJHtmaWxlbmFtZX0uY3N2YClcclxuICAgICAgICAgICAgd3JpdGVjc3Yub24oJ2Vycm9yJywgZSA9PiB7IHRocm93IE1ldGVvci5FcnJvcignQ1NW44OV44Kh44Kk44Or5pu444GN6L6844G/44Ko44Op44O8JykgfSlcclxuXHJcbiAgICAgICAgICAgIHJlYWQucGlwZShyb2JvdGluKVxyXG4gICAgICAgICAgICAgIC5waXBlKGNzdi5zdHJpbmdpZnkoe2hlYWRlcjogdHJ1ZX0pKVxyXG4gICAgICAgICAgICAgIC5waXBlKGNsZWFybnVtKVxyXG4gICAgICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgICAucGlwZSh3cml0ZWNzdilcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICB3cml0ZUNzdihcclxuICAgICAgICAgICAgcmVhZCxcclxuICAgICAgICAgICAgSXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1Sb2JvdGluSXRlbSxcclxuICAgICAgICAgICAgYCR7d29ya2Rpcn0vJHtjb25maWcuaXRlbWNvZGUuY3N2TmFtZUl0ZW19YFxyXG4gICAgICAgICAgKVxyXG5cclxuICAgICAgICAgIHdyaXRlQ3N2KFxyXG4gICAgICAgICAgICByZWFkLFxyXG4gICAgICAgICAgICBJdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVJvYm90aW5TZWxlY3QsXHJcbiAgICAgICAgICAgIGAke3dvcmtkaXJ9LyR7Y29uZmlnLml0ZW1jb2RlLmNzdk5hbWVTZWxlY3R9YFxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihg5q2j44GX44GE5L2c5qWt44OH44Kj44Os44Kv44OI44Oq44GM55So5oSP44GV44KM44Gm44GE44G+44Gb44KT44Gn44GX44Gf44CCXFxuWyR7d29ya2Rpcn1dYClcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICd0b29sJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS50ZXN0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuXHJcbiAgICBjb25zdCBuZXdMb2NhbCA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHt9LCBhc3luYyAoZSkgPT4ge1xyXG4gICAgICB0aHJvdyBlXHJcbiAgICB9KVxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44OV44Kj44Or44K/44O844OG44K544OIJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBuZXdMb2NhbFxyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcblxyXG5pbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0LXByb21pc2UnXHJcbmltcG9ydCBXb3dtYUFwaSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2Uvd293bWFBcGknXHJcbmltcG9ydCB1dGlsRXJyb3IgZnJvbSAnLi4vaW1wb3J0cy91dGlsL2Vycm9yJ1xyXG5cclxuY29uc3QgdGFnID0gJ3dvd21hJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeaDheWgseOBruWkieabtFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVJdGVtLmluZm9gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB5oOF5aCx44KS5pu05paw44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDk0MicgLy8gSkstMTIwXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNTQwMidcclxuICAgICAgICAgICAgICAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA0NzQzJ1xyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihpdGVtLCBjb25maWcuaXRlbUluZm8uZGVmYXVsdClcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZUl0ZW0oaXRlbSlcclxuICAgICAgICAgICAgICByZXR1cm4ge3JlcXVlc3RCb2R5OiBpdGVtLCByZXNwb25zZTogcmVzfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih7cmVxdWVzdEJvZHk6IGl0ZW19LCB1dGlsRXJyb3IucGFyc2UoZSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB44Gu6YWN6YCB5pa55rOV44KS6Kit5a6a44GZ44KLXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZUl0ZW0uZGVsaXZlcnlNZXRob2RgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB44Gu6YWN6YCB5pa55rOV44KS6Kit5a6a44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDk0MicgLy8gSkstMTIwXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihpdGVtLCBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVdvd21hQ3JlYXRlRGVsaXZlcnlNZXRob2QoaXRlbS5pdGVtQ29kZSkpXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS51cGRhdGVJdGVtKGl0ZW0pXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtyZXF1ZXN0Qm9keTogaXRlbSwgcmVzcG9uc2U6IHJlc31cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHRocm93IE9iamVjdC5hc3NpZ24oe3JlcXVlc3RCb2R5OiBpdGVtfSwgdXRpbEVycm9yLnBhcnNlKGUpKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueS4iuOBruWVhuWTgeOCkuWFrOmWi+OBmeOCi1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVJdGVtLm9wZW5gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB44OH44O844K/44OZ44O844K55LiK44Gu5ZWG5ZOB44KS5YWs6ZaL44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgaXRlbS5zYWxlU3RhdHVzID0gMVxyXG4gICAgICAgICAgICBpdGVtLmxpbWl0ZWRQYXNzd2QgPSAnTlVMTCdcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZUl0ZW0oaXRlbSlcclxuICAgICAgICAgICAgICByZXR1cm4ge3JlcXVlc3RCb2R5OiBpdGVtLCByZXNwb25zZTogcmVzfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih7cmVxdWVzdEJvZHk6IGl0ZW19LCB1dGlsRXJyb3IucGFyc2UoZSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5Zyo5bqr5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZVN0b2NrYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWcqOW6q+abtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWcqOW6q+aDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICBsZXQgY3VyID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgICAgICAkYW5kOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6IHsgJGV4aXN0czogMSB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8g44OG44K544OI5qSc57Si5p2h5Lu26Kit5a6aXHJcbiAgICAgICAgICAgICAgICAvLyAgICx7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnZ2stMTYzJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgXVxyXG4gICAgICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g6YWN6YCB5pa55rOV44Gu6YGV44GE44KS55yB44GPXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IHtcclxuICAgICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckbWFsbC53b3dtYS5pdGVtQ29kZScsXHJcbiAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlOiAnJG1hbGwud293bWEuSENob2ljZU5hbWUnLFxyXG4gICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6ICckbWFsbC53b3dtYS5WQ2hvaWNlTmFtZSdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBpdGVtOiB7XHJcbiAgICAgICAgICAgICAgICAgICRmaXJzdDogJyRfaWQnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Oa44O844K444GU44Go77yI5ZWG5ZOB44Kz44O844OJ77yJ44Gr44Kw44Or44O844OX5YyW44GZ44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckX2lkLml0ZW1Db2RlJyxcclxuICAgICAgICAgICAgICAgIHZhcmlhdGlvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgJHB1c2g6IHtcclxuICAgICAgICAgICAgICAgICAgICBfaWQ6ICckaXRlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGU6ICckX2lkLmNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlJyxcclxuICAgICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6ICckX2lkLmNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZSdcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnLFxyXG4gICAgICAgICAgICAgICAgdmFyaWF0aW9uczogJyR2YXJpYXRpb25zJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8gbGV0IHJlc01vbmdvID0gYXdhaXQgY3VyLnRvQXJyYXkoKVxyXG4gICAgICAgIC8vIHJldHVybiByZXNNb25nb1xyXG5cclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqNcclxuICAgICAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICAgICAgbGV0IGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpXHJcblxyXG4gICAgICAgICAgLy8g5Zyo5bqr44KS6Kit5a6a44GZ44KLXHJcbiAgICAgICAgICBmb3IgKGxldCBlIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgICAgICBlLnN0b2NrID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soZS5faWQpXHJcbiAgICAgICAgICAgIGRlbGV0ZSBlLl9pZFxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC8vXHJcbiAgICAgICAgICAvLyDlnKjluqvmm7TmlrDjg6rjgq/jgqjjgrnjg4hcclxuICAgICAgICAgIGxldCBhcGkgPSBuZXcgV293bWFBcGkoY29uZmlnLndvd21hQXBpUG9zdCwgY29uZmlnLnNob3BJZClcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlU3RvY2soW2l0ZW1dKVxyXG4gICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeaknOe0olxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5zZWFyY2hJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBvcHRpb25zID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShjb25maWcud293bWFBcGkpKVxyXG4gICAgICAgICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hJdGVtSW5mb2BcclxuICAgICAgICAgICAgb3B0aW9ucy5xcy5pdGVtQ29kZSA9IGl0ZW0ubWFsbC53b3dtYS5pdGVtQ29kZVxyXG5cclxuICAgICAgICAgICAgbGV0IHJlcG9zID0gYXdhaXQgcmVxdWVzdChvcHRpb25zKVxyXG4gICAgICAgICAgICBsZXQgZmlsZW5hbWUgPSBgJHt3b3JrZGlyfS8ke2l0ZW0ubW9kZWx9LnhtbGBcclxuXHJcbiAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEud3JpdGVGaWxlKGZpbGVuYW1lLCByZXBvcylcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBXb3dtYUFwaUl0ZW1GaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmNvbnN0IHRhZyA9ICd3b3dtYUFwaSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQeWVhuWTgeaDheWgseWPluW+l1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5nZXRJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgV293bWFBcGlJdGVtRmlsdGVyKGNvbmZpZy53b3dtYUFwaSwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIC8vIHRyeSB7XHJcbiAgICAgICAgLy8gICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIC8vIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIC8vIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICAvLyB0cnkge1xyXG4gICAgICAgIC8vICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIC8vIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhpdGVtKVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsIlxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSc7XG5cbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJztcbmltcG9ydCBhcmNoaXZlciBmcm9tICdhcmNoaXZlcic7XG5pbXBvcnQgY3N2IGZyb20gJ2Nzdic7XG5pbXBvcnQgeyBQYXNzVGhyb3VnaCwgVHJhbnNmb3JtIH0gZnJvbSAnc3RyZWFtJztcbmltcG9ydCBQYWNrZXQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3BhY2tldCc7XG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJztcbmltcG9ydCB7XG4gIE1vbmdvREJGaWx0ZXIsXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcic7XG5pbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnO1xuXG5jb25zdCBwcmVmaXggPSAncGFja2V0JztcbmNvbnN0IHRhZyA9ICd5YXVjdCc7XG5cbk1ldGVvci5tZXRob2RzKHtcblxuICAvL1xuICAvLyDjg6Tjg5Xjgqrjgq/lj5fms6jjg5XjgqHjgqTjg6tcblxuICBhc3luYyBbYCR7dGFnfS5vcmRlcmBdIChjb25maWcpIHtcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcbiAgICBjb25zdCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XG5cbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXG4gICAgICAn44Ok44OV44Kq44Kv5Y+X5rOoJyxcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKTtcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQik7XG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vb3JkZXJgO1xuICAgICAgICBjb25zdCByID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyTG9hZGZpbGV9YCk7XG4gICAgICAgIGNvbnN0IHcgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyU2F2ZWZpbGV9YCk7XG4gICAgICAgIHIucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1VURi04JykpXG4gICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHsgY29sdW1uczogdHJ1ZSB9KSlcbiAgICAgICAgICAucGlwZShjc3YudHJhbnNmb3JtKFxuICAgICAgICAgICAgYXN5bmMgKHJlY29yZCwgY2FsbGJhY2spID0+IHtcbiAgICAgICAgICAgICAgbGV0IGVyciA9IG51bGw7XG4gICAgICAgICAgICAgIC8vIOeuoeeQhueVquWPt+OCkue9ruOBjeaPm+OBiOOCi1xuICAgICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAgIHJlY29yZFsn566h55CG55Wq5Y+3J10gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRNb2RlbENsYXNzKHJlY29yZFsn566h55CG55Wq5Y+3J10pO1xuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgICAgICAgZXJyID0gZTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjYWxsYmFjayhlcnIsIHJlY29yZCk7XG4gICAgICAgICAgICB9LFxuICAgICAgICAgICkpXG4gICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7IGhlYWRlcjogdHJ1ZSB9KSlcbiAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdTSklTJykpXG4gICAgICAgICAgLnBpcGUodyk7XG4gICAgICB9LFxuICAgICk7XG4gIH0sXG5cbiAgLy9cbiAgLy8g44Ok44OV44Kq44Kv5Ye65ZOB44OV44Kh44Kk44OrXG5cbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJpdGBdIChjb25maWcpIHtcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcbiAgICBjb25zdCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XG5cbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXG4gICAgICAn44Ok44OV44Kq44Kv5Ye65ZOBJyxcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXG4gICAgICAgIC8vXG5cbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKTtcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKTtcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQik7XG5cbiAgICAgICAgLy8g57mw44KK6L+U44GX5Yem55CG44KS5Lu75oSP44Gu77yIcGFja2V0U2l6Ze+8ieOBp+WIhuWJslxuICAgICAgICBjb25zdCBwYWNrZXQgPSBuZXcgUGFja2V0KGNvbmZpZy5wYWNrZXRTaXplKTtcblxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKTtcbiAgICAgICAgfSBjYXRjaCAoZSkge31cblxuICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgpLkvZzmiJDjgZfnlLvlg4/jg4fjg7zjgr/jgpLlj47pm4bjgZnjgovloLTmiYBcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS93b3JrYDtcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUod29ya2Rpcik7XG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2Rpcik7XG5cbiAgICAgICAgLy8gWklQ44OV44Kh44Kk44Or44KS5L+d5a2Y44GZ44KL5aC05omAXG4gICAgICAgIGNvbnN0IHVwbG9hZGRpciA9IGAke2NvbmZpZy53b3JrZGlyfS91cGxvYWRgO1xuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh1cGxvYWRkaXIpO1xuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHVwbG9hZGRpcik7XG5cbiAgICAgICAgbGV0IGNkID0gbnVsbDsgLy8g44OR44Kx44OD44OI44OV44Kp44Or44OAXG4gICAgICAgIGxldCBmaWxlbmFtZSA9IG51bGw7IC8vIGNzduODleOCoeOCpOODq1xuICAgICAgICBsZXQgbmFtZSA9IG51bGw7IC8vIOODkeOCseODg+ODiOeVquWPt1xuXG4gICAgICAgIC8vIENTVuODleOCo+ODvOODq+ODieOCkuWumue+qeOBl+OAgemghueVquOCkueiuuWumuOBmeOCi1xuICAgICAgICBjb25zdCBmaWVsZHMgPSBbJ+euoeeQhueVquWPtycsICfjgqvjg4bjgrTjg6onLCAn44K/44Kk44OI44OrJywgJ+iqrOaYjicsICfjgrnjg4jjgqLlhoXllYblk4HmpJzntKLnlKjjgq3jg7zjg6/jg7zjg4knLCAn6ZaL5aeL5L6h5qC8JywgJ+WNs+axuuS+oeagvCcsICflgKTkuIvjgZLkuqTmuIknLCAn5YCL5pWwJywgJ+WFpeacreWAi+aVsOWItumZkCcsICfmnJ/plpMnLCAn57WC5LqG5pmC6ZaTJywgJ+WVhuWTgeeZuumAgeWFg+OBrumDvemBk+W6nOecjCcsICfllYblk4HnmbrpgIHlhYPjga7luILljLrnlLrmnZEnLCAn6YCB5paZ6LKg5ouFJywgJ+S7o+mHkeWFiOaJleOBhOOAgeW+jOaJleOBhCcsICfokL3mnK3jg4rjg5PmsbrmuIjmlrnms5XoqK3lrponLCAn5ZWG5ZOB44Gu54q25oWLJywgJ+WVhuWTgeOBrueKtuaFi+WCmeiAgycsICfov5Tlk4Hjga7lj6/lkKYnLCAn6L+U5ZOB44Gu5Y+v5ZCm5YKZ6ICDJywgJ+eUu+WDjzEnLCAn55S75YOPMeOCs+ODoeODs+ODiCcsICfnlLvlg48yJywgJ+eUu+WDjzLjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMycsICfnlLvlg48z44Kz44Oh44Oz44OIJywgJ+eUu+WDjzQnLCAn55S75YOPNOOCs+ODoeODs+ODiCcsICfnlLvlg481JywgJ+eUu+WDjzXjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNicsICfnlLvlg48244Kz44Oh44Oz44OIJywgJ+eUu+WDjzcnLCAn55S75YOPN+OCs+ODoeODs+ODiCcsICfnlLvlg484JywgJ+eUu+WDjzjjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOScsICfnlLvlg48544Kz44Oh44Oz44OIJywgJ+eUu+WDjzEwJywgJ+eUu+WDjzEw44Kz44Oh44Oz44OIJywgJ+acgOS9juipleS+oScsICfmgqroqZXlibLlkIjliLbpmZAnLCAn5YWl5pyt6ICF6KqN6Ki85Yi26ZmQJywgJ+iHquWLleW7tumVtycsICfml6nmnJ/ntYLkuoYnLCAn5ZWG5ZOB44Gu6Ieq5YuV5YaN5Ye65ZOBJywgJ+iHquWLleWApOS4i+OBkicsICfmnIDkvY7okL3mnK3kvqHmoLwnLCAn44OB44Oj44Oq44OG44Kj44O8JywgJ+azqOebruOBruOCquODvOOCr+OCt+ODp+ODsycsICflpKrlrZfjg4bjgq3jgrnjg4gnLCAn6IOM5pmv6ImyJywgJ+OCueODiOOCouODm+ODg+ODiOOCquODvOOCr+OCt+ODp+ODsycsICfnm67nq4vjgaHjgqLjgqTjgrPjg7MnLCAn6LSI562U5ZOB44Ki44Kk44Kz44OzJywgJ1Tjg53jgqTjg7Pjg4jjgqrjg5fjgrfjg6fjg7MnLCAn44Ki44OV44Kj44Oq44Ko44Kk44OI44Kq44OX44K344On44OzJywgJ+iNt+eJqeOBruWkp+OBjeOBlScsICfojbfnianjga7ph43ph48nLCAn44Gv44GTQk9PTicsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxJywgJ+OBneOBruS7lumFjemAgeaWueazlTHmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UyJywgJ+OBneOBruS7lumFjemAgeaWueazlTLmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UzJywgJ+OBneOBruS7lumFjemAgeaWueazlTPmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U0JywgJ+OBneOBruS7lumFjemAgeaWueazlTTmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U1JywgJ+OBneOBruS7lumFjemAgeaWueazlTXmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U2JywgJ+OBneOBruS7lumFjemAgeaWueazlTbmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U3JywgJ+OBneOBruS7lumFjemAgeaWueazlTfmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U4JywgJ+OBneOBruS7lumFjemAgeaWueazlTjmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U5JywgJ+OBneOBruS7lumFjemAgeaWueazlTnmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOWFqOWbveS4gOW+i+S+oeagvCcsICfmtbflpJbnmbrpgIEnLCAn6YWN6YCB5pa55rOV44O76YCB5paZ6Kit5a6aJywgJ+S7o+W8leaJi+aVsOaWmeioreWumicsICfmtojosrvnqI7oqK3lrponLCAnSkFO44Kz44O844OJ44O7SVNCTuOCs+ODvOODiSddO1xuICAgICAgICBjb25zdCBoZWFkZXIgPSBgJHtmaWVsZHMubWFwKHYgPT4gYFwiJHt2fVwiYCkuam9pbignLCcpfVxcbmA7XG5cbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW6ZaL5aeL5pmCXG4gICAgICAgIHBhY2tldC5vblBhY2tldFN0YXJ0ID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XG4gICAgICAgICAgbmFtZSA9IHByZWZpeCArIChgMDAwMDAke3BhY2tldENvdW50fWApLnNsaWNlKC01KTtcbiAgICAgICAgICBjZCA9IGAke3dvcmtkaXJ9LyR7bmFtZX1gO1xuICAgICAgICAgIGZpbGVuYW1lID0gYCR7Y2R9LyR7Y29uZmlnLmNzdkZpbGVOYW1lfWA7XG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2RpcihjZCk7XG4gICAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44Gr44OV44Kj44O844Or44OJ44KS6Kit5a6a44GZ44KLXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUoaGVhZGVyLCAnU2hpZnRfSklTJykpO1xuICAgICAgICB9O1xuXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMluaZglxuICAgICAgICBwYWNrZXQub25QYWNrZXQgPSBhc3luYyAoYXJnKSA9PiB7XG4gICAgICAgICAgY29uc3QgeWF1Y3QgPSBhcmcueWF1Y3Q7XG4gICAgICAgICAgY29uc3QgaXRlbSA9IGFyZy5pdGVtO1xuICAgICAgICAgIC8vIGNzduODleOCoeOCpOODq+OBq+ODrOOCs+ODvOODie+8iOWVhuWTgeODhuODs+ODl+ODrOODvOODiO+8ieOCkui/veWKoOOBmeOCi1xuICAgICAgICAgIGNvbnN0IHJlY29yZCA9IGAke2ZpZWxkcy5tYXAodiA9PiAoeWF1Y3Rbdl0gPyBgXCIke3lhdWN0W3ZdfVwiYCA6ICdcIlwiJykpLmpvaW4oJywnKX1cXG5gO1xuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKHJlY29yZCwgJ1NoaWZ0X0pJUycpKTtcbiAgICAgICAgICAvLyDnlLvlg4/jg5XjgqHjgqTjg6vjgpLjgrPjg5Tjg7xcbiAgICAgICAgICBmb3IgKGNvbnN0IGltZyBvZiBpdGVtLmltYWdlcykge1xuICAgICAgICAgICAgY29uc3QgaW1nU3JjID0gYCR7Y29uZmlnLmltYWdlZGlyfS8ke2ltZ31gO1xuICAgICAgICAgICAgY29uc3QgaW1nVGd0ID0gYCR7Y2R9LyR7aW1nfWA7XG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICAvLyDlkIzjgZjjg5XjgqHjgqTjg6vjgYzjgYLjgovloLTlkIjjga/jgrPjg5Tjg7zjgZfjgarjgYRcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5hY2Nlc3MoaW1nVGd0KTtcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5jb3B5RmlsZShpbWdTcmMsIGltZ1RndCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuICAgICAgICB9O1xuXG4gICAgICAgIC8vIOODkeOCseODg+ODiOe1guS6huaZglxuICAgICAgICBwYWNrZXQub25QYWNrZXRFbmQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcbiAgICAgICAgICBjb25zdCB6aXAgPSBhcmNoaXZlcignemlwJyk7XG4gICAgICAgICAgY29uc3QgemlwbmFtZSA9IGAke3VwbG9hZGRpcn0vJHtuYW1lfS56aXBgO1xuICAgICAgICAgIGNvbnN0IG91dHB1dCA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oemlwbmFtZSk7XG4gICAgICAgICAgemlwLnBpcGUob3V0cHV0KTtcbiAgICAgICAgICB6aXAuZGlyZWN0b3J5KGNkLCBmYWxzZSk7XG4gICAgICAgICAgemlwLmZpbmFsaXplKCk7XG4gICAgICAgIH07XG5cbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXG4gICAgICAgIC8vXG5cbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xuXG4gICAgICAgICAgVEFSR0VUOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZCk7XG4gICAgICAgICAgICAvLyBpdGVt44Gr5a6a576p44GV44KM44Gm44GE44KL5pyA5L2O5b+F6KaB5Zyo5bqr44KI44KK5aSa44GE5ZWG5ZOB44KS5Ye65ZOB44GZ44KLXG4gICAgICAgICAgICBpZiAocXVhbnRpdHkgPj0gaXRlbS5tYWxsLnlhdWN0Lm1pblF1YW50aXR5KSB7XG4gICAgICAgICAgICAgIGNvbnN0IHlhdWN0ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1ZYXVjdChjb25maWcuZGVmYXVsdCwgaXRlbSk7XG4gICAgICAgICAgICAgIGF3YWl0IHBhY2tldC5zdWJtaXQoeyB5YXVjdCwgaXRlbSB9KTtcbiAgICAgICAgICAgIH1cbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcblxuICAgICAgICBwYWNrZXQuY2xvc2UoKTtcblxuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XG4gIH0sXG5cbn0pO1xuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2NvbGxlY3Rpb25zJ1xyXG5pbXBvcnQgJy4vcm91dGUvdXBsb2FkL2ltYWdlJ1xyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCc7XHJcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0JztcclxuaW1wb3J0IHsgR3JvdXBCYXNlIH0gZnJvbSAnLi9ncm91cHMnO1xyXG5cclxuY29uc3QgRmlsdGVycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdmaWx0ZXJzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBGaWx0ZXIgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcihmaWx0ZXJJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gRmlsdGVycy5maW5kT25lKHtcclxuICAgICAgX2lkOiBmaWx0ZXJJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG5cclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jICggb25SZXN1bHQgPSAocmVjb3JkKT0+e30sIG9uRXJyb3IgPSAoZSk9Pnt9ICkgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgb25FcnJvcik7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsYXRmb3JtIHR5cGUnKTtcclxuXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge3sgZmlsdGVyVHlwZTogYXN5bmMgKHJlY29yZCApID0+IHt9IH19IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaChjYWxsYmFja3MgPSB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlKCk7XHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgdHlwZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ID0ge307XHJcbiAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgIGNvdW50W2ZpbHRlci50eXBlXSA9IHtcclxuICAgICAgICBxdWVyeTogZmlsdGVyLnF1ZXJ5LFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQpPT57XHJcbiAgICAgICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICAgICAgbGV0IHF1ZXJ5ID0gbW9iamVjdC51bmVzY2FwZShmaWx0ZXIucXVlcnkpO1xyXG4gICAgICAgICAgbGV0IGV4YW0gPSBzaWZ0KCBxdWVyeSApO1xyXG4gICAgICAgICAgaWYoIGV4YW0ocmVjb3JkKSApe1xyXG4gICAgICAgICAgICBjb3VudFtmaWx0ZXIudHlwZV0uY291bnQrKztcclxuICAgICAgICAgICAgaWYoIHR5cGVvZiBjYWxsYmFja3NbZmlsdGVyLnR5cGVdICE9PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2tzW2ZpbHRlci50eXBlXShyZWNvcmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgb25FcnJvclxyXG4gICAgKTtcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50O1xyXG5cclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG5jb25zdCBHcm91cHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZ3JvdXBzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cEJhc2Uge1xyXG5cclxuICBwcm9maWxlO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9maWxlKSB7XHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogZ2V0cyAnUGx1Zycgd2l0Y2ggaXMgYSBzZXQgb2YgcHJvcGVydGllcyBuZWVkZWRcclxuICAgKiB3aGVuIGNvbm5lY3QgdG8gc29tZSBwbGF0Zm9ybXNcclxuICAgKiB0byBnZXQgZGF0YXMoTWVtYmVycyBvZiB0aGUgR3JvdXApXHJcbiAgICovXHJcbiAgZ2V0UGx1ZygpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGUucGxhdGZvcm1QbHVnO1xyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZSgpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHt9O1xyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZ3JvdXBJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gR3JvdXBzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGdyb3VwSWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jIChkb2MpID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9IFdIRVJFIFxcYCR7ZG9jLmtleX1cXGAgPSBcIiR7ZG9jLmlkfVwiYDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgZ3JvdXAgdHlwZScpO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge2FzeW5jIChyZWNvcmQpPT52b2lkfSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBjdXIgPSBHcm91cHMuZmluZCh7XHJcbiAgICAgIGdyb3VwSWQ6IHRoaXMucHJvZmlsZS5faWRcclxuICAgIH0sIHtcclxuICAgICAgZmllbGRzOiB7XHJcbiAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgIGlkOiAxLFxyXG4gICAgICAgIGtleTogMVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBcclxuICAgICAgICBjdXIuZm9yRWFjaChcclxuICAgICAgICAgIGFzeW5jIChkb2MsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlY29yZCA9IGF3YWl0IHRoaXMuaW1wb3J0KGRvYyk7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2socmVjb3JkKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIG9uRXJyb3IoZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGluZGV4ICsgMSA9PT0gY3VyLmNvdW50KCkpIHtcclxuICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgfVxyXG4gICAgKS5jYXRjaChcclxuICAgICAgKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICB9XHJcblxyXG59IiwiaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xuaW1wb3J0IHN5bmNPYmplY3QgZnJvbSAnLi4vdXRpbC9zeW5jT2JqZWN0JztcblxuZXhwb3J0IGNsYXNzIEN1YmUzQXBpIHtcbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7TXlTUUx9IG15c3FsXG4gICAqL1xuICBjb25zdHJ1Y3RvcihteXNxbCkge1xuICAgIHRoaXMubXlzcWwgPSBteXNxbDtcbiAgfVxuXG4gIGFzeW5jIG1vZGlmeUNhdGVnb3J5KHByb2R1Y3RJZCwgY2F0ZWdvcnlJZEFycmF5KSB7XG4gICAgY29uc3QgdGFibGVDYXRlZ29yeSA9ICdkdGJfcHJvZHVjdF9jYXRlZ29yeSc7XG5cbiAgICAvLyDllYblk4Hmg4XloLHjg4fjg7zjgr/jg5njg7zjgrnjgavoqJjpjLLjgZXjgozjgZ/llYblk4Hjgqvjg4bjgrTjg6rjg7zmg4XloLFcbiAgICBjb25zdCBjb2xTcmMgPSBbXTtcbiAgICBjYXRlZ29yeUlkQXJyYXkuZm9yRWFjaCgoZWxlbSkgPT4ge1xuICAgICAgY29sU3JjLnB1c2goe1xuICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXG4gICAgICAgIGNhdGVnb3J5X2lkOiBlbGVtLFxuICAgICAgfSk7XG4gICAgfSk7XG5cbiAgICAvLyDjg6Ljg7zjg6vjg4fjg7zjgr/jg5njg7zjgrnjgYvjgonnj77lnKjjga7llYblk4Hjgqvjg4bjgrTjg6rjg7zmg4XloLHjgpLlj5blvpdcbiAgICBjb25zdCBzcWwgPSBgXG4gICAgU0VMRUNUIHByb2R1Y3RfaWQsIGNhdGVnb3J5X2lkXG4gICAgRlJPTSAke3RhYmxlQ2F0ZWdvcnl9XG4gICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdElkfVxuICAgIGA7XG5cbiAgICAvLyBjb25zdCBjb2xEc3QgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKSkpO1xuICAgIGNvbnN0IGNvbERzdCA9IGF3YWl0IHRoaXMubXlzcWwucXVlcnlTZWxlY3QoXG4gICAgICB0YWJsZUNhdGVnb3J5LFxuICAgICAgYHByb2R1Y3RfaWQgPSAke3Byb2R1Y3RJZH1gLFxuICAgICAgJ3Byb2R1Y3RfaWQsIGNhdGVnb3J5X2lkJyxcbiAgICApO1xuXG4gICAgLy8g5ZCEU1FM44Kv44Ko44Oq44Gu57WQ5p6c44GZ44G544Gm44KS6KiY6Yyy44GZ44KLXG4gICAgY29uc3QgcmVzdWx0cyA9IFtdO1xuXG4gICAgYXdhaXQgc3luY09iamVjdChcbiAgICAgIGNvbFNyYywgY29sRHN0LCBudWxsLFxuICAgICAgYXN5bmMgKGlkLCBvYmplY3QpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5teXNxbC5xdWVyeUluc2VydChcbiAgICAgICAgICB0YWJsZUNhdGVnb3J5LFxuICAgICAgICAgIHt9LFxuICAgICAgICAgIE9iamVjdC5hc3NpZ24oeyByYW5rOiAxIH0sIG9iamVjdCksXG4gICAgICAgICk7XG4gICAgICAgIHJlc3VsdHMucHVzaChyZXMpO1xuICAgICAgfSxcbiAgICAgIGFzeW5jIChpZCwgb2JqZWN0KSA9PiB7XG4gICAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWwucXVlcnkoXG4gICAgICAgICAgYFxuICAgICAgICAgIERFTEVURSBGUk9NICR7dGFibGVDYXRlZ29yeX1cbiAgICAgICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtvYmplY3QucHJvZHVjdF9pZH1cbiAgICAgICAgICAgIEFORCBjYXRlZ29yeV9pZCA9ICR7b2JqZWN0LmNhdGVnb3J5X2lkfVxuICAgICAgICAgIGAsXG4gICAgICAgICk7XG4gICAgICAgIHJlc3VsdHMucHVzaChyZXMpO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHJlc3VsdHM7XG4gIH1cblxuICBhc3luYyB1cGRhdGVTdG9jayhwcm9kdWN0Q2xhc3NJZCwgcXVhbnRpdHkgPSAwKSB7XG4gICAgYXdhaXQgdGhpcy5teXNxbC5xdWVyeVVwZGF0ZShcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcbiAgICAgIHt9LCB7XG4gICAgICAgIHN0b2NrOiBxdWFudGl0eSxcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIGF3YWl0IHRoaXMubXlzcWwucXVlcnlVcGRhdGUoXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLFxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXG4gICAgICB7fSwge1xuICAgICAgICBzdG9jazogcXVhbnRpdHksXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgfSxcbiAgICApO1xuICB9XG5cbiAgYXN5bmMgcHJvZHVjdFRhZ1VwZGF0ZShkYXRhKSB7XG4gICAgY29uc3QgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkO1xuXG4gICAgY29uc3QgcmVzID0gW107XG5cbiAgICAvLyDliYrpmaTjgZnjgovjgr/jgrBcbiAgICBjb25zdCB0YWdvZmYgPSBhc3luYyAodGFnKSA9PiB7XG4gICAgICBjb25zdCBzcWwgPSBgXG4gICAgICBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF90YWcgXG4gICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9IEFORCB0YWcgPSAke3RhZ31cbiAgICAgIGA7XG4gICAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCkpO1xuICAgIH07XG5cbiAgICAvLyDooajnpLrjgZnjgovjgr/jgrBcbiAgICBjb25zdCB0YWdvbiA9IGFzeW5jICh0YWcpID0+IHtcbiAgICAgIC8vIOOBmeOBp+OBq+ihqOekuuOBleOCjOOBpuOBhOOCi+OCv+OCsOOBjOOBguOCjOOBsOS9leOCguOBl+OBquOBhFxuICAgICAgY29uc3Qgc3FsID0gYFxuICAgICAgU0VMRUNUIENPVU5UKCopIEZST00gZHRiX3Byb2R1Y3RfdGFnIFxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XG4gICAgICBgO1xuICAgICAgY29uc3QgY291bnRSZXMgPSBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCk7XG4gICAgICBpZiAoY291bnRSZXNbMF1bJ0NPVU5UKCopJ10pIHJldHVybjtcblxuICAgICAgcmVzLnB1c2goXG4gICAgICAgIGF3YWl0IHRoaXMubXlzcWwucXVlcnlJbnNlcnQoXG4gICAgICAgICAgJ2R0Yl9wcm9kdWN0X3RhZycsXG4gICAgICAgICAge30sXG4gICAgICAgICAge1xuICAgICAgICAgICAgcHJvZHVjdF9pZDogZGF0YS5wcm9kdWN0X2lkLFxuICAgICAgICAgICAgdGFnLFxuICAgICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxuICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICAgICAgfSxcbiAgICAgICAgKSxcbiAgICAgICk7XG4gICAgfTtcblxuICAgIGZvciAoY29uc3QgdGFnU2V0IG9mIGRhdGEudGFncykge1xuICAgICAgc3dpdGNoICh0YWdTZXQuc2V0KSB7XG4gICAgICAgIGNhc2UgJ29uJzpcbiAgICAgICAgICBhd2FpdCB0YWdvbih0YWdTZXQudGFnKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgICAgY2FzZSAnb2ZmJzpcbiAgICAgICAgICBhd2FpdCB0YWdvZmYodGFnU2V0LnRhZyk7XG4gICAgICAgICAgYnJlYWs7XG4gICAgICB9XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHJlcyxcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgcHJvZHVjdEltYWdlVXBkYXRlKGRhdGEpIHtcbiAgICBjb25zdCBwcm9kdWN0SWQgPSBkYXRhLnByb2R1Y3RfaWQ7XG4gICAgY29uc3QgaW1hZ2VzID0gZGF0YS5pbWFnZXM7XG4gICAgY29uc3QgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkO1xuXG4gICAgY29uc3QgcmVzID0gW107XG5cbiAgICAvLyDllYblk4HjgavplqLpgKPjgZnjgovjgZnjgbnjgabjga7nlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgotcbiAgICBjb25zdCBzcWwgPSBgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfaW1hZ2UgV0hFUkUgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdElkfWA7XG4gICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpKTtcbiAgICAvLyDmlLnjgoHjgabnlLvlg4/jgpLnmbvpjLLjgZfjgarjgYrjgZlcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGltYWdlcy5sZW5ndGg7IGkrKykge1xuICAgICAgYXdhaXQgdGhpcy5teXNxbC5xdWVyeUluc2VydChcbiAgICAgICAgJ2R0Yl9wcm9kdWN0X2ltYWdlJywge1xuICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXG4gICAgICAgICAgZmlsZV9uYW1lOiBpbWFnZXNbaV0sXG4gICAgICAgICAgcmFuazogaSArIDEsXG4gICAgICAgIH0sIHtcbiAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgICAgfSxcbiAgICAgICk7XG4gICAgfVxuXG4gICAgcmV0dXJuIHtcbiAgICAgIHJlcyxcbiAgICB9O1xuICB9XG5cbiAgYXN5bmMgcHJvZHVjdFVwZGF0ZShkYXRhKSB7XG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fTtcbiAgICBsZXQga2V5cyA9IFtdO1xuXG4gICAgLy8gZHRiX3Byb2R1Y3RcblxuICAgIGtleXMgPSBbXG4gICAgICAnc3RhdHVzJyxcbiAgICAgICduYW1lJyxcbiAgICAgICdub3RlJyxcbiAgICAgICdkZXNjcmlwdGlvbl9saXN0JyxcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnLFxuICAgICAgJ3NlYXJjaF93b3JkJyxcbiAgICAgICdmcmVlX2FyZWEnLFxuICAgIF07XG4gICAgZm9yIChjb25zdCBrIG9mIGtleXMpIHtcbiAgICAgIGlmIChkYXRhW2tdKSB7XG4gICAgICAgIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdO1xuICAgICAgfVxuICAgIH1cblxuICAgIC8vIFtcbiAgICAvLyAgICdzdGF0dXMnLFxuICAgIC8vICAgJ25hbWUnLFxuICAgIC8vICAgJ25vdGUnLFxuICAgIC8vICAgJ2Rlc2NyaXB0aW9uX2xpc3QnLFxuICAgIC8vICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXG4gICAgLy8gICAnc2VhcmNoX3dvcmQnLFxuICAgIC8vICAgJ2ZyZWVfYXJlYScsXG4gICAgLy8gXS5mb3JFYWNoKFxuICAgIC8vICAgKHYpID0+IHtcbiAgICAvLyAgICAgaWYgKGRhdGFbdl0pIHtcbiAgICAvLyAgICAgICB1cGRhdGVEYXRhW3ZdID0gZGF0YVt2XTtcbiAgICAvLyAgICAgfVxuICAgIC8vICAgfSxcbiAgICAvLyApO1xuXG4gICAgYXdhaXQgdGhpcy5teXNxbC5xdWVyeVVwZGF0ZShcbiAgICAgICdkdGJfcHJvZHVjdCcsXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXG4gICAgICB1cGRhdGVEYXRhLCB7XG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgfSxcbiAgICApO1xuXG4gICAgLy8gZHRiX3Byb2R1Y3RfY2xhc3NcblxuICAgIHVwZGF0ZURhdGEgPSB7fTtcbiAgICBrZXlzID0gW1xuICAgICAgJ2RlbGl2ZXJ5X2RhdGVfaWQnLFxuICAgICAgJ3Byb2R1Y3RfY29kZScsXG4gICAgICAnc2FsZV9saW1pdCcsXG4gICAgICAncHJpY2UwMScsXG4gICAgICAncHJpY2UwMicsXG4gICAgICAnZGVsaXZlcnlfZmVlJyxcbiAgICBdO1xuICAgIGZvciAoY29uc3QgayBvZiBrZXlzKSB7IGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXTsgfVxuXG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5VXBkYXRlKFxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcbiAgICAgIHVwZGF0ZURhdGEsIHtcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICB9LFxuICAgICk7XG5cbiAgICByZXR1cm4ge1xuICAgICAgcmVzLFxuICAgIH07XG4gIH1cblxuICBhc3luYyBwcm9kdWN0Q3JlYXRlKGRhdGEpIHtcbiAgICBjb25zdCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWQ7XG5cbiAgICBjb25zdCByZXMgPSB7fTtcblxuICAgIGxldCB1cGRhdGVEYXRhID0ge307XG4gICAgbGV0IGtleXMgPSBbXTtcblxuICAgIGtleXMgPSBbXG4gICAgICAnbmFtZScsXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJyxcbiAgICBdO1xuICAgIC8vIHtcbiAgICAvLyAgIG5hbWU6IGl0ZW0ubmFtZSxcbiAgICAvLyAgIGRlc2NyaXB0aW9uX2RldGFpbDogaXRlbS5kZXNjcmlwdGlvbixcbiAgICAvLyB9LFxuXG4gICAgZm9yIChjb25zdCBrIG9mIGtleXMpIHsgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdOyB9XG5cblxuICAgIHJlcy5wcm9kdWN0X2lkID0gYXdhaXQgdGhpcy5teXNxbC5xdWVyeUluc2VydChcbiAgICAgICdkdGJfcHJvZHVjdCcsXG4gICAgICB1cGRhdGVEYXRhLCB7XG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcbiAgICAgICAgc3RhdHVzOiAxLFxuICAgICAgICBub3RlOiAnTlVMTCcsXG4gICAgICAgIGRlc2NyaXB0aW9uX2xpc3Q6ICdOVUxMJyxcbiAgICAgICAgc2VhcmNoX3dvcmQ6ICdOVUxMJyxcbiAgICAgICAgZnJlZV9hcmVhOiAnTlVMTCcsXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIHVwZGF0ZURhdGEgPSB7fTtcbiAgICBrZXlzID0gW1xuICAgICAgJ3Byb2R1Y3RfY29kZScsXG4gICAgICAncHJvZHVjdF90eXBlX2lkJyxcbiAgICAgICdwcmljZTAxJyxcbiAgICAgICdwcmljZTAyJyxcbiAgICAgICdkZWxpdmVyeV9mZWUnLFxuICAgIF07XG4gICAgLy8ge1xuICAgIC8vICAgcHJvZHVjdF9jb2RlOiBpdGVtLm1vZGVsLFxuICAgIC8vICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXG4gICAgLy8gICBwcmljZTAyOiBpdGVtLnNhbGVzX3ByaWNlLFxuICAgIC8vIH0sXG5cbiAgICBmb3IgKGNvbnN0IGsgb2Yga2V5cykgeyBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba107IH1cblxuXG4gICAgcmVzLnByb2R1Y3RfY2xhc3NfaWQgPSBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5SW5zZXJ0KFxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcbiAgICAgIHVwZGF0ZURhdGEsIHtcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxuICAgICAgICBwcm9kdWN0X2lkOiByZXMucHJvZHVjdF9pZCxcbiAgICAgICAgc3RvY2s6IDAsXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQxOiAnTlVMTCcsXG4gICAgICAgIGNsYXNzX2NhdGVnb3J5X2lkMjogJ05VTEwnLFxuICAgICAgICBkZWxpdmVyeV9kYXRlX2lkOiAnTlVMTCcsXG4gICAgICAgIHNhbGVfbGltaXQ6ICdOVUxMJyxcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgfSxcbiAgICApO1xuXG4gICAgZm9yIChjb25zdCBrIG9mIGtleXMpIHsgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdOyB9XG5cblxuICAgIHJlcy5wcm9kdWN0X3N0b2NrX2lkID0gYXdhaXQgdGhpcy5teXNxbC5xdWVyeUluc2VydChcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsIHt9LCB7XG4gICAgICAgIHByb2R1Y3RfY2xhc3NfaWQ6IHJlcy5wcm9kdWN0X2NsYXNzX2lkLFxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXG4gICAgICAgIHN0b2NrOiAwLFxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICB9LFxuICAgICk7XG5cbiAgICAvLyBmb3IgdGVzdFxuICAgIHJldHVybiB7XG4gICAgICByZXMsXG4gICAgfTtcbiAgfVxufVxuIiwiaW1wb3J0IHtNb25nb0NsaWVudH0gZnJvbSAnbW9uZ29kYidcbmltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QtcHJvbWlzZSdcblxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnXG5pbXBvcnQgbW9iamVjdCBmcm9tICdtb25nb29iamVjdCdcbmltcG9ydCB7IHhtbDJqcyB9IGZyb20gJ3htbC1qcydcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJ1xuXG5leHBvcnQgY2xhc3MgREJGaWx0ZXJGYWN0b3J5IHtcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcbiAgICBsZXQgaW5zdGFuY2U7XG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcbiAgICAgIGNhc2UgJ215c3FsJzpcbiAgICAgICAgaW5zdGFuY2UgPSBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKTtcbiAgICB9XG5cbiAgICByZXR1cm4gaW5zdGFuY2U7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIERCRmlsdGVyIHtcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcbiAgICB0aGlzLnBsdWcgPSBwbHVnO1xuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGU7XG4gIH1cblxuICBzdGF0aWMgZmFjdG9yeSAocGx1ZywgcHJvZmlsZSkge1xuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XG4gICAgICBjYXNlICdteXNxbCc6XG4gICAgICAgIHJldHVybiBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKTtcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbHVnIHR5cGUnKTtcbiAgICB9XG4gIH1cblxuICBnZXRQbHVnXyAoKSB7XG4gICAgcmV0dXJuIHRoaXMucGx1ZztcbiAgfVxuXG4gIGdldENyZWRfICgpIHtcbiAgICByZXR1cm4gdGhpcy5wbHVnLmNyZWQ7XG4gIH1cblxuICBnZXRQcm9maWxlXyAoKSB7XG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZTtcbiAgfVxuXG4gIHNldEltcG9ydEZ1bmN0aW9uXyAoXG4gICAgZm4gPSBhc3luYyAob25SZXN1bHQgPSAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IChlKSA9PiB7fSkgPT4ge30sXG4gICkge1xuICAgIHRoaXMuaW1wb3J0ID0gZm47XG4gIH1cblxuICAvKipcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXG4gICAqIHVzZWFnZTpcbiAgICpcbiAgICpcbiAgICogQHBhcmFtIHsgT2JqZWN0IH0gaXRlcmF0b3JzIHsgZmlsdGVyTmFtZTogYXN5bmMgKGRvYyxjb250ZXh0KT0+e30sIC4uLiB9IGl0ZXJhdG9yIGZvciBlYWNoIGZpbHRlcnNcbiAgICogQHBhcmFtIHsgYXN5bmMgZnVuY3Rpb24gfSBvbkVycm9yIGVycm9yIGhhbmRsZXIgd2hpbGUgaXRlcmF0aW5nXG4gICAqIEByZXR1cm5zIHsgT2JqZWN0IH0geyBmaWx0ZXJOYW1lOiB7IHF1ZXJ5OiBhbnksIGNvdW50OiBudW1iZXIgfSwgLi4uIH1cbiAgICovXG4gIGFzeW5jIGZvcmVhY2ggKGl0ZXJhdG9ycyA9IHt9KSB7XG4gICAgY29uc3QgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZV8oKTtcblxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xuICAgICAgbmFtZTogJ21pc2MnLFxuICAgICAgcXVlcnk6IHt9LFxuICAgIH0pO1xuXG4gICAgY29uc3QgY291bnRlciA9IHt9O1xuICAgIGZvciAoY29uc3QgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcbiAgICB9XG5cbiAgICBjb25zdCBmaWx0ZXJzID0gW107XG5cbiAgICBmb3IgKGNvbnN0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XG4gICAgICBjb3VudGVyW2YubmFtZV0gPSB7XG4gICAgICAgIHF1ZXJ5OiBmLnF1ZXJ5LFxuICAgICAgICBsaW1pdDogdHlwZW9mIGYubGltaXQgIT09ICd1bmRlZmluZWQnID8gZi5saW1pdCA6IDAsXG4gICAgICAgIGNvdW50OiAwLFxuICAgICAgfTtcbiAgICAgIGZpbHRlcnMucHVzaChcbiAgICAgICAge1xuICAgICAgICAgIG5hbWU6IGYubmFtZSxcbiAgICAgICAgICBleGFtOiBzaWZ0KG1vYmplY3QudW5lc2NhcGUoZi5xdWVyeSkpLFxuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9XG5cbiAgICBhd2FpdCB0aGlzLmltcG9ydChcbiAgICAgIGFzeW5jIChyZWNvcmQsIGNvbnRleHQpID0+IHtcbiAgICAgICAgZm9yIChjb25zdCBmIG9mIGZpbHRlcnMpIHtcbiAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcbiAgICAgICAgICBjb25zdCBjID0gY291bnRlcltmLm5hbWVdO1xuICAgICAgICAgIGlmIChjLmxpbWl0KSB7XG4gICAgICAgICAgICBpZiAoYy5jb3VudCA+PSBjLmxpbWl0KSB7XG4gICAgICAgICAgICAgIGNvbnRpbnVlO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH1cblxuICAgICAgICAgIGlmIChmLmV4YW0ocmVjb3JkKSkge1xuICAgICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXG4gICAgICAgICAgICBjLmNvdW50Kys7XG5cbiAgICAgICAgICAgIC8vIGl0ZXJhdG9yXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZXJhdG9yc1tmLm5hbWVdICE9PSAndW5kZWZpbmVkJykge1xuICAgICAgICAgICAgICBhd2FpdCBpdGVyYXRvcnNbZi5uYW1lXShyZWNvcmQsIGNvbnRleHQpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgICAgYnJlYWs7XG4gICAgICAgICAgfVxuICAgICAgICB9XG4gICAgICB9XG4pO1xuXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcbiAgICByZXR1cm4gY291bnRlcjtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgTXlzcWxEQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcblxuICAgIGNvbnN0IGNyZWQgPSB0aGlzLmdldENyZWRfKCk7XG5cbiAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKGNyZWQpO1xuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xuICAgICAgY29uc3Qgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWA7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIChlKSA9PiB7IHRocm93IGU7IH0pO1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9KTtcbiAgfVxufVxuXG4vLyBpbXBvcnQgTW9uZ29OYXRpdmUgZnJvbSAnbW9uZ29kYic7XG4vLyBjb25zdCBNb25nb0NsaWVudCA9IE1vbmdvTmF0aXZlLk1vbmdvQ2xpZW50O1xuLy8gY29uc3QgTW9uZ29DbGllbnQgPSByZXF1aXJlKCdtb25nb2RiJykuTW9uZ29DbGllbnQ7XG5cbmV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xuXG4gICAgLy8gbW9uZ28g44G45o6l57aaXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XG4gICAgICBsZXQgY2xpZW50O1xuICAgICAgY2xpZW50ID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSwgeyB1c2VOZXdVcmxQYXJzZXI6IHRydWUgfSk7XG5cbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xuICAgICAgY29uc3QgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSk7XG4gICAgICBjb25zdCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xuXG4gICAgICBjb25zdCBjb250ZXh0ID0ge1xuICAgICAgICBjbGllbnQsXG4gICAgICAgIGNvbGxlY3Rpb24sXG4gICAgICAgIGRhdGFiYXNlOiBkYixcbiAgICAgIH07XG5cbiAgICAgIGNvbnN0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpO1xuXG4gICAgICAvLyDjgqvjg7zjgr3jg6vjga7jgr/jgqTjg6DjgqLjgqbjg4jjgpLop6PpmaRcbiAgICAgIGN1ci5hZGRDdXJzb3JGbGFnKCdub0N1cnNvclRpbWVvdXQnLCB0cnVlKTtcblxuICAgICAgLy8g44GZ44G544Gm44Gu44OJ44Kt44Ol44Oh44Oz44OI44KS44Or44O844OXXG4gICAgICB0cnkge1xuICAgICAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xuICAgICAgICAgIGNvbnN0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KCk7XG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQoZG9jLCBjb250ZXh0KTtcbiAgICAgICAgfVxuICAgICAgfSBmaW5hbGx5IHtcbiAgICAgICAgLy8g44Kr44O844K944Or44KS6ZaL5pS+XG4gICAgICAgIGF3YWl0IGN1ci5jbG9zZSgpO1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBXb3dtYUFwaUl0ZW1GaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XG5cbiAgICAvLyDllYblk4Hmg4XloLHjga7lj5blvpfjg6vjg7zjg5fjgpLlrprnvqlcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xuICAgICAgY29uc3Qgb3B0aW9ucyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocGx1ZykpO1xuICAgICAgb3B0aW9ucy51cmkgPSBgJHtvcHRpb25zLnVyaX0vc2VhcmNoU3RvY2tzYDtcbiAgICAgIGNvbnN0IGNvbnRleHQgPSB7XG4gICAgICAgIG9wdGlvbnMsXG4gICAgICB9O1xuXG4gICAgICB3aGlsZSAoMSkge1xuICAgICAgICAvLyBXb3dtYSBBcGkg44GL44KJ5ZWG5ZOB5oOF5aCx44KS5Y+W5b6XXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCByZXF1ZXN0KG9wdGlvbnMpO1xuICAgICAgICByZXMgPSB4bWwyanMocmVzLCB7IGNvbXBhY3Q6IHRydWUgfSk7XG5cbiAgICAgICAgY29uc3QgbWF4Q291bnQgPSBOdW1iZXIocmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5tYXhDb3VudC5fdGV4dCk7XG4gICAgICAgIGNvbnN0IHJlc3VsdENvdW50ID0gTnVtYmVyKHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQucmVzdWx0Q291bnQuX3RleHQpO1xuICAgICAgICBjb25zdCBzdGFydENvdW50ID0gTnVtYmVyKHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQuc3RhcnRDb3VudC5fdGV4dCk7XG4gICAgICAgIGNvbnN0IHJlc3VsdFN0b2NrcyA9IHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQucmVzdWx0U3RvY2tzO1xuXG4gICAgICAgIC8vIOWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuOCq+OCueOCv+ODoOODl+ODreOCu+OCueOBq+a4oeOBmVxuICAgICAgICBpZiAocmVzdWx0U3RvY2tzIGluc3RhbmNlb2YgQXJyYXkpIHtcbiAgICAgICAgICAvLyDlj5blvpfjgZfjgZ/jg4fjg7zjgr/jgYzopIfmlbDllYblk4Hjga7loLTlkIhcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlc3VsdENvdW50OyBpKyspIHtcbiAgICAgICAgICAgIGF3YWl0IG9uUmVzdWx0KHJlc3VsdFN0b2Nrc1tpXSwgY29udGV4dCk7XG4gICAgICAgICAgfVxuICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgIC8vIOWPluW+l+OBl+OBn+ODh+ODvOOCv+OBjOWNmOaVsOWVhuWTgeOBruWgtOWQiFxuICAgICAgICAgIGF3YWl0IG9uUmVzdWx0KHJlc3VsdFN0b2NrcywgY29udGV4dCk7XG4gICAgICAgIH1cblxuICAgICAgICBjb25zdCBuZXh0ID0gc3RhcnRDb3VudCArIHJlc3VsdENvdW50O1xuXG4gICAgICAgIGlmIChuZXh0ID4gbWF4Q291bnQpIGJyZWFrO1xuICAgICAgICBvcHRpb25zLnFzLnN0YXJ0Q291bnQgPSBuZXh0O1xuICAgICAgfVxuICAgIH0pO1xuICB9XG59XG5cbi8vIGltcG9ydCBtb25nb29zZSBmcm9tICdtb25nb29zZSc7XG5cbi8vIGV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xuLy8gICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XG4vLyAgICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XG5cbi8vICAgICAvLyBtb25nbyDjgbjmjqXntppcbi8vICAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcbi8vICAgICBsZXQgY29udXJpID0gYG1vbmdvZGI6Ly8ke2NyZWQuaG9zdH06JHtjcmVkLnBvcnR9LyR7Y3JlZC5kYXRhYmFzZX1gO1xuLy8gICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoY29udXJpKTtcblxuLy8gICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuS9nOOCi1xuLy8gICAgIGxldCBjb2xsZWN0aW9uID0gbW9uZ29vc2UuY29ubmVjdGlvbi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XG5cbi8vICAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcbi8vICAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKTtcblxuLy8gICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgb25FcnJvcik7XG4vLyAgICAgfSk7XG4vLyAgIH1cbi8vIH1cbiIsImltcG9ydCB7IE1vbmdvQ29sbGVjdGlvbiB9IGZyb20gJy4uL3V0aWwvbW9uZ28nO1xuaW1wb3J0IHsgVXBsb2FkcywgUm9ib3RpblNob3AgfSBmcm9tICcuLi9jb2xsZWN0aW9ucyc7XG5pbXBvcnQgVGV4dFV0aWwgZnJvbSAnLi4vdXRpbC90ZXh0JztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSXRlbUNvbnRyb2xsZXIge1xuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHt7dXJpOnN0cmluZywgZGF0YWJhc2U6c3RyaW5nLCBjb2xsZWN0aW9uOnN0cmluZ319IHBsdWdcbiAgICovXG4gIGFzeW5jIGluaXQocGx1Zykge1xuICAgIHRoaXMuSXRlbXMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdpdGVtcycpO1xuICAgIHRoaXMuUHJvZHVjdHMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdwcm9kdWN0cycpO1xuICB9XG5cbiAgYXN5bmMgZ2V0U3RvY2soaXRlbUlkKSB7XG4gICAgY29uc3QgaXRlbSA9IGF3YWl0IHRoaXMuSXRlbXMuZmluZE9uZSh7XG4gICAgICBfaWQ6IGl0ZW1JZCxcbiAgICB9LCB7XG4gICAgICBwcm9qZWN0aW9uOiB7XG4gICAgICAgIHByb2R1Y3Q6IDEsXG4gICAgICB9LFxuICAgIH0pO1xuICAgIGNvbnN0IHByb2R1Y3RTZXQgPSBpdGVtLnByb2R1Y3Q7XG5cbiAgICAvLyBwcm9kdWN0ICogPC0+ICogaXRlbVxuICAgIC8vIHByb2R1Y3RbXTog6KSH5pWw44Gu5ZWG5ZOB44KSMeODkeODg+OCseODvOOCuOOBqOOBl+OBpuiyqeWjslxuICAgIC8vIHByb2R1Y3Rbe2lkczpbPE9iamVjdElkPl0sc2V0OjxOdW1iZXI+fV06IOeVsOOBquOCi+a1gemAmue1jOi3r+OAgeeVsOOBquOCi+WOn+S+oeODu+S7leWFpeOCjOWApFxuICAgIC8vIGl0ZW06IOeVsOOBquOCi+OCu+ODvOODq+OAgeiyqeWjsuW9ouaFi1xuICAgIC8vIOKAuyBwcm9kdWN0IOOBi+OCieOBr+OAgeiyqeWjsuWPr+iDveOBquWcqOW6q+OAgeWIqeebiuioiOeul+OBruOBn+OCgeOBruaDheWgseOCkuW+l+OCi1xuXG4gICAgY29uc3QgcXVhbnRpdGllcyA9IFtdO1xuXG4gICAgZm9yIChjb25zdCBwcm9kdWN0UmVmIG9mIHByb2R1Y3RTZXQpIHtcbiAgICAgIGxldCBwcmRRdWFudGl0eSA9IDA7XG5cbiAgICAgIGZvciAoY29uc3QgaWQgb2YgcHJvZHVjdFJlZi5pZHMpIHtcbiAgICAgICAgY29uc3QgcHJvZHVjdCA9IGF3YWl0IHRoaXMuUHJvZHVjdHMuZmluZE9uZSh7XG4gICAgICAgICAgX2lkOiBpZCxcbiAgICAgICAgfSwge1xuICAgICAgICAgIHByb2plY3Rpb246IHtcbiAgICAgICAgICAgIHN0b2NrOiAxLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0pO1xuICAgICAgICBjb25zdCBzdG9ja0FycmF5ID0gcHJvZHVjdC5zdG9jaztcblxuICAgICAgICAvLyDljZjntJTjgavjgZnjgbnjgabjga7lnKjluqvllYblk4HjgIHnn63mnJ/plpPlj5bjgorlr4TjgZvlj6/og73llYblk4HjgpLlkIjnrpdcbiAgICAgICAgZm9yIChjb25zdCBzdG9jayBvZiBzdG9ja0FycmF5KSBwcmRRdWFudGl0eSArPSBzdG9jay5xdWFudGl0eTtcbiAgICAgIH1cblxuICAgICAgLy8g5ZWG5ZOBKGl0ZW0p44Gu5Zyo5bqr5pWwID0g6KO95ZOB5Zyo5bqr5pWwKHByZFF1YW50aXR5KSAvIOW/heimgeOCu+ODg+ODiOaVsChwcm9kdWN0UmVmLnNldClcbiAgICAgIHF1YW50aXRpZXMucHVzaChNYXRoLmZsb29yKHByZFF1YW50aXR5IC8gcHJvZHVjdFJlZi5zZXQpKTtcbiAgICB9XG5cbiAgICAvLyDjgrvjg4Pjg4jllYblk4Hjga7loLTlkIjjgIHkuIDnlarlsJHjgarjgYTllYblk4HmlbDjgavlkIjjgo/jgZvjgotcbiAgICBjb25zdCBxdWFudGl0eSA9IE1hdGgubWluLmFwcGx5KG51bGwsIHF1YW50aXRpZXMpO1xuXG4gICAgcmV0dXJuIHF1YW50aXR5O1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOCi+OAglxuICAgKlxuICAgKiDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6vjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcbiAgICogY2xhc3Mx44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXG4gICAqXG4gICAqIOeJueWumuOBruWxnuaAp++8iOOCq+ODqeODvOOBquOBqe+8ieOBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxuICAgKiBjbGFzczHjgavlgKTjgpLmjIflrprjgZfjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcbiAgICog44KC44GXY2xhc3My44Gu44G/5oyH5a6a44GX44Gf44GE5aC05ZCI44GvY2xhc3Mx44GrbnVsbOOCkuaMh+WumuOBmeOCi+OAglxuICAgKlxuICAgKiDkvovvvJpKSy0xMDDjga5CTEFDS+OBruWVhuWTgeeUu+WDj+OCklxuICAgKiDjgZnjgbnjgabjga7jgrXjgqTjgrrvvIhTLE0sTCxYTCwyWEwsM1hMLDRYTOKApu+8ieOBq+mWoumAo+S7mOOBkeOCi+WgtOWQiFxuICAgKiBzZXRJbWFnZSggdXBsb2FkSWQsICdKSy0xMDAnLCAnQkxBQ0snICk7XG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB1cGxvYWRJZCDkuIDlm57jga7jgqLjg4Pjg5fjg63jg7zjg4nnlLvlg4/jgpLmnZ/jga3jgabjgYTjgotJROOAgm1ldGVvcuODh+ODvOOCv+ODmeODvOOCueOAgVVwbG9hZHPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjg4njgq3jg6Xjg6Hjg7Pjg4jjga51cGxvYWRJZOODl+ODreODkeODhuOCo1xuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXG4gICAqL1xuICBhc3luYyBzZXRJbWFnZSh1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jga7mg4XloLHlj5blvpdcbiAgICBjb25zdCBpbWFnZXMgPSBVcGxvYWRzLmZpbmQoe1xuICAgICAgdXBsb2FkSWQsXG4gICAgfSkuZmV0Y2goKS5tYXAodiA9PiB2LnVwbG9hZGVkRmlsZU5hbWUpO1xuXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXG4gICAgY29uc3QgZmlsdGVyID0ge307XG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWw7XG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMTtcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyO1xuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxuICAgICAgZmlsdGVyLCB7XG4gICAgICAgICRwdXNoOiB7XG4gICAgICAgICAgaW1hZ2VzOiB7XG4gICAgICAgICAgICAkZWFjaDogaW1hZ2VzLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICk7XG5cbiAgICAvLyDnmbvpjLLjgZfjgZ/nlLvlg4/jg5XjgqHjgqTjg6vlkI3kuIDopqdcbiAgICByZXR1cm4gaW1hZ2VzO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr55m76Yyy44GV44KM44Gm44GE44KL55S75YOP5oOF5aCx44KS5YmK6Zmk44GZ44KL44CCXG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcbiAgICovXG4gIGFzeW5jIGNsZWFuSW1hZ2UobW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcbiAgICBjb25zdCBmaWx0ZXIgPSB7fTtcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbDtcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxO1xuICAgIGlmIChjbGFzczIpIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczI7XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXG4gICAgICBmaWx0ZXIsIHtcbiAgICAgICAgJHNldDoge1xuICAgICAgICAgIGltYWdlczogW10sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICk7XG4gIH1cblxuICAvKipcbiAgICog5oyH5a6a44Gu5ZWG5ZOB44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gu5bGe5oCn5Yil44Gu5ZWG5ZOB5oOF5aCx44KS6L+U44GZ44CCXG4gICAqXG4gICAqIOW8leaVsOOBqOOBl+OBpuWPl+OBkeWPluOCi2l0ZW3jga/ku7vmhI/jga7llYblk4Hmg4XloLHjgIJcbiAgICogaXRlbeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBq+OBpOOBhOOBpuW/heimgeOBquaDheWgseOCkuaVtOeQhuOBl+i/lOOBmeOAglxuICAgKlxuICAgKiBwcm9qZWN044Gr5Y+C54Wn44GX44Gf44GE5ZWG5ZOB5oOF5aCx44OV44Kj44O844Or44OJ44KS5a6a576p44GZ44KL44CCXG4gICAqIOODoeOCveODg+ODieOBruWRvOOBs+WHuuOBl+aZguOBq+W/heimgeOBq+W/nOOBmOOBpnByb2plY3TjgpLoqK3lrprjgZnjgovjgIJcbiAgICpcbiAgICog5L2V44Gr5rOo55uu44GX44Gm5ZWG5ZOB44Gu6Zai6YCj5oCn44KS5qSc5Ye644GZ44KL44GL44Gv44CB44GT44Gu44Oh44K944OD44OJ5YaF44Gn5a6a576p44GZ44KL44CCXG4gICAqXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBpdGVtXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBwcm9qZWN0XG4gICAqL1xuICBhc3luYyBnZXRWYXJpYXRpb24oaXRlbSwgcHJvamVjdCkge1xuICAgIC8qKlxuICAgICAqIGFnZ3JlZ2F0aW9u6Kit5a6aXG4gICAgICpcbiAgICAgKiBsYWJlbDog5bGe5oCn5ZCN77yI6YWN6YCB5pa55rOV44CB44Kr44Op44O844CB44K144Kk44K644Gq44Gp77yJXG4gICAgICogY3VycmVudDog5oyH5a6a44GV44KM44Gf44Ki44Kk44OG44Og77yIaXRlbe+8ieOBjOipsuW9k+OBmeOCi+mgheebrlxuICAgICAqIHBvcmplY3Q6IOODkOODquOCqOODvOOCt+ODp+ODs+aknOe0ouOBruOCreODvOOBqOOBquOCi2l0ZW3lhoXjga7jg5XjgqPjg7zjg6vjg4nlkI0gJFvjg5XjgqPjg7zjg6vjg4nlkI1d5b2i5byPXG4gICAgICogcXVlcnk6IGFnZ3JlZ2F0aW9u5a++6LGh44Go44GZ44KL44OJ44Kt44Ol44Oh44Oz44OI44Gu5qSc57Si5p2h5Lu2XG4gICAgICovXG4gICAgY29uc3Qgc2V0ID0gW3tcbiAgICAgIGxhYmVsOiAn6YWN6YCB5pa55rOVJyxcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uZGVsaXZlcnksXG4gICAgICBwcm9qZWN0OiB7XG4gICAgICAgIHZhbHVlOiAnJGRlbGl2ZXJ5JyxcbiAgICAgIH0sXG4gICAgICBxdWVyeToge1xuICAgICAgICBjbGFzczFfdmFsdWU6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxuICAgICAgICBjbGFzczJfdmFsdWU6IGl0ZW0uY2xhc3MyX3ZhbHVlLFxuICAgICAgfSxcbiAgICB9LFxuICAgIHtcbiAgICAgIGxhYmVsOiBpdGVtLmNsYXNzMV9uYW1lLFxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczFfdmFsdWUsXG4gICAgICBwcm9qZWN0OiB7XG4gICAgICAgIHZhbHVlOiAnJGNsYXNzMV92YWx1ZScsXG4gICAgICB9LFxuICAgICAgcXVlcnk6IHtcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWUsXG4gICAgICB9LFxuICAgIH0sXG4gICAge1xuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MyX25hbWUsXG4gICAgICBjdXJyZW50OiBpdGVtLmNsYXNzMl92YWx1ZSxcbiAgICAgIHByb2plY3Q6IHtcbiAgICAgICAgdmFsdWU6ICckY2xhc3MyX3ZhbHVlJyxcbiAgICAgIH0sXG4gICAgICBxdWVyeToge1xuICAgICAgICBkZWxpdmVyeTogaXRlbS5kZWxpdmVyeSxcbiAgICAgICAgY2xhc3MxX3ZhbHVlOiBpdGVtLmNsYXNzMV92YWx1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICBdO1xuXG4gICAgY29uc3QgYXR0cnMgPSBbXTtcblxuICAgIGZvciAoY29uc3QgcyBvZiBzZXQpIHtcbiAgICAgIGF0dHJzLnB1c2goe1xuICAgICAgICB2YXJpYXRpb25zOiBhd2FpdCB0aGlzLkl0ZW1zLmFnZ3JlZ2F0ZShcbiAgICAgICAgICBbe1xuICAgICAgICAgICAgJG1hdGNoOiBPYmplY3QuYXNzaWduKHMucXVlcnksIHtcbiAgICAgICAgICAgICAgbW9kZWw6IGl0ZW0ubW9kZWwsXG4gICAgICAgICAgICB9KSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgICRwcm9qZWN0OiBPYmplY3QuYXNzaWduKHMucHJvamVjdCwgcHJvamVjdCksXG4gICAgICAgICAgfSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICAkc29ydDoge1xuICAgICAgICAgICAgICBfaWQ6IDEsXG4gICAgICAgICAgICB9LFxuICAgICAgICAgIH0sXG4gICAgICAgICAgXSxcbiAgICAgICAgKS50b0FycmF5KCksXG4gICAgICAgIHByb3BzOiBzLFxuICAgICAgfSk7XG4gICAgfVxuXG4gICAgZm9yIChjb25zdCBhdHRyIG9mIGF0dHJzKSBmb3IgKGNvbnN0IHYgb2YgYXR0ci52YXJpYXRpb25zKSB2LnN0b2NrID0gYXdhaXQgdGhpcy5nZXRTdG9jayh2Ll9pZCk7XG5cblxuICAgIHJldHVybiBhdHRycztcbiAgfVxuXG4gIC8vIOODouODh+ODq+OCr+ODqeOCueW9ouW8j+OCkuS9nOOCi1xuICAvLyBb44Oh44O844Kr44O844Kz44O844OJXS9b5bGe5oCnMe+8iOOCq+ODqeODvOOBquOBqe+8iV0vW+WxnuaApzLvvIjjgrXjgqTjgrrjgarjganvvIldXG4gIGFzeW5jIGdldE1vZGVsQ2xhc3MoYXJnKSB7XG4gICAgbGV0IGl0ZW07XG4gICAgLy8gaXRlbSDjgYzmloflrZfliJfjgarjgonjgIFpdGVt44Gv5Lu75oSP44Gu44Kq44OW44K444Kn44Kv44OISUTjga7mnKvlsL7jgYvjgonku7vmhI/jga7moYHmlbDjga4xNumAsuaVsFxuICAgIGlmICh0eXBlb2YgYXJnID09PSAnc3RyaW5nJykge1xuICAgICAgY29uc3QgZXhwID0gbmV3IFJlZ0V4cChgJHthcmd9JGApO1xuICAgICAgY29uc3QgY3VyID0gdGhpcy5JdGVtcy5maW5kKHt9LCB7XG4gICAgICAgIHByb2plY3Rpb246IHtcbiAgICAgICAgICBtb2RlbDogMSxcbiAgICAgICAgICBjbGFzczFfdmFsdWU6IDEsXG4gICAgICAgICAgY2xhc3MyX3ZhbHVlOiAxLFxuICAgICAgICB9LFxuICAgICAgfSk7XG5cbiAgICAgIHdoaWxlICgxKSB7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgaXRlbSA9IGF3YWl0IGN1ci5uZXh0KCk7XG4gICAgICAgICAgY29uc3QgbWF0Y2ggPSBhd2FpdCBpdGVtLl9pZC50b0hleFN0cmluZygpLm1hdGNoKGV4cCk7XG4gICAgICAgICAgaWYgKG1hdGNoKSBicmVhaztcbiAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgIC8vIOipsuW9k+OBmeOCi2l0ZW3jg4fjg7zjgr/jgYzjgarjgYRcbiAgICAgICAgICBjdXIuY2xvc2UoKTtcbiAgICAgICAgICByZXR1cm4gYXJnO1xuICAgICAgICB9XG4gICAgICB9XG4gICAgICBjdXIuY2xvc2UoKTtcbiAgICB9IGVsc2Uge1xuICAgICAgaXRlbSA9IGFyZztcbiAgICB9XG5cbiAgICBjb25zdCBtb2RlbENsYXNzID0gW107XG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKTtcbiAgICBpZiAoaXRlbS5jbGFzczFfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMV92YWx1ZSk7XG4gICAgaWYgKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpO1xuICAgIHJldHVybiBtb2RlbENsYXNzLmpvaW4oJy8nKTtcbiAgfVxuXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkge1xuICAgIC8vIOWApOWkieaPm1xuICAgIGNvbnN0IGNvbnZEZWxpdiA9IGRlbGl2ZXJ5ID0+IChkZWxpdmVyeSA9PT0gJ+OChuOBhuODkeOCseODg+ODiCcgPyAn44Od44K544OI5oqV5Ye9JyA6IGRlbGl2ZXJ5KTtcblxuICAgIC8vIHByb2R1Y3RfaWRcbiAgICBjb25zdCBwcm9kdWN0SWQgPSBudWxsO1xuICAgIGNvbnN0IG1vZGVsQ2xhc3MgPSBbXTtcblxuICAgIC8vIOS4i+iomOOBruW9ouW8j+OCkuS9nOOCi1xuICAgIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cbiAgICBpZiAoaXRlbS5tb2RlbCkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0ubW9kZWwpO1xuICAgIGlmIChpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKTtcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSk7XG5cbiAgICAvLyDllYblk4HnqK7liKXjgpLlibLjgorlvZPjgabjgotcbiAgICBsZXQgcHJvZHVjdFR5cGVJZDtcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAyO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ+WuheaApeS+v+OCs+ODs+ODkeOCr+ODiCc6XG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAzO1xuICAgICAgICBicmVhaztcbiAgICAgIGNhc2UgJ+WuhemFjeS+v+mAgeaWmeeEoeaWmSc6XG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSA0O1xuICAgICAgICBicmVhaztcbiAgICAgIGRlZmF1bHQ6XG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxO1xuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcbiAgICBjb25zdCB0YWdzID0gW1xuICAgICAgeyB0YWc6IDQsIHNldDogJ29mZicgfSxcbiAgICAgIHsgdGFnOiA1LCBzZXQ6ICdvZmYnIH0sXG4gICAgICB7IHRhZzogNiwgc2V0OiAnb2ZmJyB9LFxuICAgICAgeyB0YWc6IDcsIHNldDogJ29mZicgfSxcbiAgICBdO1xuXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XG4gICAgICBjYXNlICflroXphY3kvr8nOlxuICAgICAgICB0YWdzLmZpbmQoZSA9PiBlLnRhZyA9PT0gNClcbiAgICAgICAgICAuc2V0ID0gJ29uJztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxuICAgICAgICB0YWdzLmZpbmQoZSA9PiBlLnRhZyA9PT0gNSlcbiAgICAgICAgICAuc2V0ID0gJ29uJztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICflroXmgKXkvr/jgrPjg7Pjg5Hjgq/jg4gnOlxuICAgICAgICB0YWdzLmZpbmQoZSA9PiBlLnRhZyA9PT0gNilcbiAgICAgICAgICAuc2V0ID0gJ29uJztcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICflroXphY3kvr/pgIHmlpnnhKHmlpknOlxuICAgICAgICB0YWdzLmZpbmQoZSA9PiBlLnRhZyA9PT0gNylcbiAgICAgICAgICAuc2V0ID0gJ29uJztcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICAvLyDllYblk4HliKXpgIHmlpnjgpLoqK3lrprjgZnjgotcbiAgICBsZXQgZGVsaXZlcnlGZWUgPSBudWxsO1xuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBjb25maWdVcGxvYWRJdGVtLm1haWxib3hGZWU7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBudWxsO1xuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICAvL1xuICAgIC8vIOmhp+WuouWQkeOBkeODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgemBuOaKnuapn+iDveOBruWun+ijhVxuICAgIC8vXG5cbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7XG4gICAgICBwcm9kdWN0X2lkOiAnJG1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9pZCcsXG4gICAgfSk7XG5cbiAgICAvLyBIVE1MIOODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgeOBlOOBqOOBruODquODs+OCr+S7mOOBjeODnOOCv+ODs+OCkuihqOekuuOBmeOCi1xuXG4gICAgLy8g5YCk44Gu5aSJ5o+bXG4gICAgYXR0cnMgPSBhdHRycy5tYXAoXG4gICAgICAoYXR0cikgPT4ge1xuICAgICAgICBhdHRyLnByb3BzLmN1cnJlbnQgPSBjb252RGVsaXYoYXR0ci5wcm9wcy5jdXJyZW50KTtcbiAgICAgICAgYXR0ci52YXJpYXRpb25zID0gYXR0ci52YXJpYXRpb25zLm1hcChcbiAgICAgICAgICAodmFyaWF0aW9uKSA9PiB7XG4gICAgICAgICAgICB2YXJpYXRpb24udmFsdWUgPSBjb252RGVsaXYodmFyaWF0aW9uLnZhbHVlKTtcbiAgICAgICAgICAgIHJldHVybiB2YXJpYXRpb247XG4gICAgICAgICAgfSxcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIGF0dHI7XG4gICAgICB9LFxuICAgICk7XG5cbiAgICAvLyBIVE1M55Sf5oiQXG4gICAgY29uc3QgdmFyaWF0aW9uSHRtbCA9IGF0dHJzLm1hcChcbiAgICAgIGF0dHIgPT4gYCR7JzxkaXYgY2xhc3M9XCJjb250YWluZXItZmx1aWRcIj4nXG4gICAgICAgICsgJzxkaXYgY2xhc3M9XCJyb3dcIj4nXG4gICAgICAgICsgJzxkaXYgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGNsYXNzPVwiYnRuIGJ0bi1pbmZvIGJ0bi1ibG9jayBidG4teHNcIj4nXG4gICAgICAgICsgYDxzdHJvbmc+JHthdHRyLnByb3BzLmxhYmVsfTwvc3Ryb25nPmBcbiAgICAgICAgKyAnPC9kaXY+J30ke1xuICAgICAgICBhdHRyLnZhcmlhdGlvbnMubWFwKFxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcbiAgICAgICAgICAgIGlmIChhdHRyLnByb3BzLmN1cnJlbnQgPT09IHZhcmlhdGlvbi52YWx1ZSkge1xuICAgICAgICAgICAgICAvLyDooajnpLrkuK3jga7llYblk4Hjg5zjgr/jg7NcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zdWNjZXNzIGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj48c3Ryb25nPiR7dmFyaWF0aW9uLnZhbHVlfTwvc3Ryb25nPjwvYnV0dG9uPmA7XG4gICAgICAgICAgICB9IGlmICh2YXJpYXRpb24uc3RvY2sgPiAwKSB7XG4gICAgICAgICAgICAgIC8vIOiyqeWjsuWPr+iDveWVhuWTgeOBruODnOOCv+ODs1xuICAgICAgICAgICAgICByZXR1cm4gYDxhIGhyZWY9XCIvcHJvZHVjdHMvZGV0YWlsLyR7dmFyaWF0aW9uLnByb2R1Y3RfaWR9XCI+PGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+PC9hPmA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyDosqnlo7LkuI3lj6/og73llYblk4Hjga7jg5zjgr/jg7PvvIjlnKjluqvjgarjgZfvvIlcbiAgICAgICAgICAgIHJldHVybiBgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCIgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGRhdGEtdG9nZ2xlPVwidG9vbHRpcFwiIHRpdGxlPVwi5Zyo5bqr44GM44GU44GW44GE44G+44Gb44KTXCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+YDtcbiAgICAgICAgICB9LFxuICAgICAgICApLmpvaW4oJycpXG4gICAgICB9PC9kaXY+YFxuICAgICAgICArICc8L2Rpdj4nLFxuICAgICkuam9pbignJyk7XG5cbiAgICBjb25zdCBkZXNjcmlwdGlvbkRldGFpbCA9IGBcbiAgICA8c21hbGw+4oC7IOmFjemAgeaWueazleODu+OCq+ODqeODvOODu+OCteOCpOOCuuOBr+S4i+iomOOBi+OCieOBiumBuOOBs+OBj+OBoOOBleOBhOOAgjwvc21hbGw+XG4gICAgJHt2YXJpYXRpb25IdG1sfVxuICAgIGA7XG5cbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcbiAgICBjb25zdCBkYXRhID0ge1xuICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxuICAgICAgY3JlYXRvcl9pZDogY29uZmlnVXBsb2FkSXRlbS5jcmVhdG9yX2lkLFxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7Y29udkRlbGl2KGl0ZW0uZGVsaXZlcnkpfSAke2l0ZW0ubmFtZX0ke2l0ZW0uamFuX2NvZGUgPyBgICR7aXRlbS5qYW5fY29kZX1gIDogJyd9YCxcbiAgICAgIGRlc2NyaXB0aW9uX2RldGFpbDogZGVzY3JpcHRpb25EZXRhaWwsXG4gICAgICAvLyBmcmVlX2FyZWE6IGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZUZyZWVBcmVhKGl0ZW0pLFxuICAgICAgcHJvZHVjdF9jb2RlOiBtb2RlbENsYXNzLmpvaW4oJy8nKSxcbiAgICAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxuICAgICAgLy8gcHJpY2UwMjogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlUHJpY2UwMihpdGVtKSxcbiAgICAgIC8vIGltYWdlczogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlSW1hZ2VzKGl0ZW0pLFxuICAgICAgcHJvZHVjdF90eXBlX2lkOiBwcm9kdWN0VHlwZUlkLFxuICAgICAgdGFncyxcbiAgICAgIGRlbGl2ZXJ5X2ZlZTogZGVsaXZlcnlGZWUsXG4gICAgfTtcblxuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlRnJlZUFyZWEoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkpO1xuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlUHJpY2UwMihjb25maWdVcGxvYWRJdGVtLCBpdGVtKSk7XG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVJbWFnZXMoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkpO1xuXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBpdGVtLm1hbGwuc2hhcmFrdVNob3ApO1xuXG4gICAgcmV0dXJuIGRhdGE7XG4gIH1cblxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzY3JlYXRlRnJlZUFyZWEoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkge1xuICAgIGxldCBmcmVlQXJlYSA9ICcnO1xuICAgIC8vIOWVhuWTgeaDheWgseODhuOCreOCueODiOOCkuiomOi8ieOBmeOCi1xuICAgIGZyZWVBcmVhICs9IGAke2l0ZW0uZGVzY3JpcHRpb259PGJyPmA7XG4gICAgLy8gMueVquebruS7pemZjeOBrueUu+WDj+OCkuODleODquODvOOCqOODquOCouOBq+iomOi8ieOBmeOCi1xuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIGZyZWVBcmVhICs9IGA8aW1nIHNyYz1cIi91cGxvYWQvc2F2ZV9pbWFnZS8ke2l0ZW0uaW1hZ2VzW2ldfVwiPjxicj5gO1xuXG4gICAgcmV0dXJuIHsgZnJlZV9hcmVhOiBmcmVlQXJlYSB9O1xuICB9XG5cbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlM2NyZWF0ZVByaWNlMDIoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkge1xuICAgIC8vIOS+oeagvOOCkui/lOOBmVxuICAgIHJldHVybiB7IHByaWNlMDI6IGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcmljZSB9O1xuICB9XG5cbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlM2NyZWF0ZUltYWdlcyhjb25maWdVcGxvYWRJdGVtLCBpdGVtKSB7XG4gICAgLy8g55S75YOP44Oq44K544OI44Gu44GG44GhMeOBpOOCgeOBoOOBkeOCkui/lOOBmVxuICAgIGNvbnN0IGFyciA9IHR5cGVvZiBpdGVtLmltYWdlc1swXSA9PT0gJ3VuZGVmaW5lZCcgPyBbXSA6IFtpdGVtLmltYWdlc1swXV07XG4gICAgcmV0dXJuIHsgaW1hZ2VzOiBhcnIgfTtcbiAgfVxuXG4gIC8vIOODpOODleOCquOCr+ODhuODs+ODl+ODrOODvOODiOOBuOOBruWkieaPm1xuICBhc3luYyBjb252ZXJ0SXRlbVlhdWN0MShjb25maWcsIGl0ZW0pIHtcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtWWF1Y3QoY29uZmlnLmRlZmF1bHQsIGl0ZW0pO1xuICAgIHJldHVybiByZXM7XG4gIH1cblxuICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjgbjjga7lpInmj5tcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdChkZWYsIGl0ZW0pIHtcbiAgICBjb25zdCBpZExlbmd0aCA9IDIwO1xuICAgIGNvbnN0IHRpdGxlTGVuZ3RoID0gMTMwO1xuXG4gICAgbGV0IHlhdWN0ID0ge307XG4gICAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44Gu5Yid5pyf5YCk77yI44KG44GG44OR44Kx44OD44OI44O75a6F6YWN5L6/44Gn55Ww44Gq44KL77yJXG4gICAgeWF1Y3QgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGRlZltpdGVtLmRlbGl2ZXJ5XSkpO1xuXG4gICAgLy8g55S75YOP44Gu6KiY6L+wXG4gICAgY29uc3QgaW1nUHJlZml4ID0gJ+eUu+WDjyc7XG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtLmltYWdlcy5sZW5ndGg7IGkrKykgeWF1Y3RbaW1nUHJlZml4ICsgKGkgKyAxKV0gPSBpdGVtLmltYWdlc1tpXTtcblxuXG4gICAgLy8g44K/44Kk44OI44OrXG4gICAgeWF1Y3RbJ+OCq+ODhuOCtOODqiddID0gaXRlbS5tYWxsLnlhdWN0LmNhdGVnb3J5O1xuICAgIHlhdWN0Wyfjgr/jgqTjg4jjg6snXSA9IFRleHRVdGlsLnN1YnN0cjgoYCR7YXdhaXQgdGhpcy5nZXRNb2RlbENsYXNzKGl0ZW0pfSAke2l0ZW0uZGVsaXZlcnl9ICR7aXRlbS5uYW1lfWAsIHRpdGxlTGVuZ3RoKTtcbiAgICB5YXVjdFsn6ZaL5aeL5L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlO1xuICAgIHlhdWN0WyfljbPmsbrkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2U7XG4gICAgeWF1Y3RbJ+euoeeQhueVquWPtyddID0gaXRlbS5faWQudG9IZXhTdHJpbmcoKS5zbGljZSgtaWRMZW5ndGgpO1xuICAgIGlmICh0eXBlb2YgeWF1Y3RbJ+iqrOaYjiddID09PSAnc3RyaW5nJykgeWF1Y3RbJ+iqrOaYjiddID0gYCR7aXRlbS5kZXNjcmlwdGlvbn08YnI+PGJyPiR7eWF1Y3RbJ+iqrOaYjiddfWA7XG4gICAgZWxzZSB5YXVjdFsn6Kqs5piOJ10gPSBpdGVtLmRlc2NyaXB0aW9uO1xuXG4gICAgeWF1Y3RbJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXSA9IGl0ZW0uamFuX2NvZGU7XG5cbiAgICByZXR1cm4geWF1Y3Q7XG4gIH1cblxuICBhc3luYyBjb252ZXJ0SXRlbVdvd21hQ3JlYXRlRGVsaXZlcnlNZXRob2QoaXRlbUNvZGUpIHtcbiAgICBjb25zdCBpZCA9ICdtYWxsLndvd21hLml0ZW1Db2RlJztcbiAgICBjb25zdCBzZXQgPSAnZGVsaXZlcnknO1xuICAgIGNvbnN0IG1ldHJpY3MgPSB7XG4gICAgICDjgobjgYbjg5HjgrHjg4Pjg4g6IFsnUG9zdCddLFxuICAgICAg5a6F6YWN5L6/OiBbJ1lVLVBhY2snLCAnS2FuZ2Fyb28nXSxcbiAgICB9O1xuICAgIC8vIGRlbGl2ZXJ5TWV0aG9kU2VxXG5cbiAgICBjb25zdCBhZ2dyID0gYXdhaXQgdGhpcy5JdGVtcy5hZ2dyZWdhdGUoXG4gICAgICBbXG4gICAgICAgIHtcbiAgICAgICAgICAkbWF0Y2g6IHtcbiAgICAgICAgICAgIFtpZF06IGl0ZW1Db2RlLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAkZ3JvdXA6IHtcbiAgICAgICAgICAgIF9pZDogYCQke2lkfWAsXG4gICAgICAgICAgICBbc2V0XTogeyAkYWRkVG9TZXQ6IGAkJHtzZXR9YCB9LFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIHtcbiAgICAgICAgICAkcHJvamVjdDoge1xuICAgICAgICAgICAgX2lkOiAwLFxuICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJyxcbiAgICAgICAgICAgIFtzZXRdOiBgJCR7c2V0fWAsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIF0sXG4gICAgKS50b0FycmF5KCk7XG5cbiAgICBsZXQgYWNjZXB0RGVsaXYgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGRlbCBvZiBhZ2dyWzBdLmRlbGl2ZXJ5KSBhY2NlcHREZWxpdiA9IGFjY2VwdERlbGl2LmNvbmNhdChtZXRyaWNzW2Ake2RlbH1gXSk7XG5cblxuICAgIGNvbnN0IGRlbGl2ZXJ5TWV0aG9kID0gbmV3IEFycmF5KDUpO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGVsaXZlcnlNZXRob2QubGVuZ3RoOyBpKyspIHtcbiAgICAgIGNvbnN0IGlkID0gdHlwZW9mIGFjY2VwdERlbGl2W2ldID09PSAndW5kZWZpbmVkJyA/ICdOVUxMJyA6IGFjY2VwdERlbGl2W2ldO1xuICAgICAgZGVsaXZlcnlNZXRob2RbaV0gPSB7IGRlbGl2ZXJ5TWV0aG9kU2VxOiBpICsgMSwgZGVsaXZlcnlNZXRob2RJZDogaWQgfTtcbiAgICB9XG5cbiAgICByZXR1cm4geyBkZWxpdmVyeU1ldGhvZCB9O1xuICB9XG5cbiAgLy9cbiAgLy8gUm9ib3QtaW4g5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+344Gu55m76Yyy44Gu44Gf44KB44Gu44OH44O844K/44KS5L2c44KLXG4gIC8vIOOBneOBrjEgaXRlbS5jc3ZcblxuICBzdGF0aWMgY29udmVydEl0ZW1Sb2JvdGluSXRlbShpdGVtKSB7XG4gICAgcmV0dXJuIHtcbiAgICAgIOOCs+ODs+ODiOODreODvOODq+OCq+ODqeODoDogJ24nLFxuICAgICAg5paw6KaP55m76YyySUQ6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXG4gICAgICDllYblk4FJRDogbnVsbCxcbiAgICAgIOWVhuWTgeWQjTogYCR7aXRlbS5tb2RlbH0ke2l0ZW0uY2xhc3MxX3ZhbHVlID09PSAnJyA/ICcnIDogYC8ke2l0ZW0uY2xhc3MxX3ZhbHVlfWB9JHtpdGVtLmNsYXNzMl92YWx1ZSA9PT0gJycgPyAnJyA6IGAvJHtpdGVtLmNsYXNzMl92YWx1ZX1gfWAsXG4gICAgICDopo/moLw6ICfjgarjgZcnLFxuICAgIH07XG4gIH1cblxuICAvL1xuICAvLyBSb2JvdC1pbiDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7fjga7nmbvpjLLjga7jgZ/jgoHjga7jg4fjg7zjgr/jgpLkvZzjgotcbiAgLy8g44Gd44GuMiBzZWxlY3QuY3N2XG5cbiAgc3RhdGljIGNvbnZlcnRJdGVtUm9ib3RpblNlbGVjdChpdGVtKSB7XG4gICAgY29uc3Qgc2VsZWN0ID0ge1xuICAgICAg44Kz44Oz44OI44Ot44O844Or44Kr44Op44OgOiAnbicsXG4gICAgICDmlrDopo/nmbvpjLJJRDogaXRlbS5faWQudG9IZXhTdHJpbmcoKSxcbiAgICAgIOWVhuWTgUlEOiBudWxsLFxuICAgICAg5aSW6YOo6YCj5pC6SUQ6IG51bGwsXG4gICAgICDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7c6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXG4gICAgfTtcblxuICAgIGNvbnN0IHNob3BzID0gUm9ib3RpblNob3AuZmluZCgpO1xuXG4gICAgc2hvcHMuZm9yRWFjaChcbiAgICAgIChkb2MsIGluZGV4KSA9PiB7XG4gICAgICAgIGxldCBtb2RlbDtcbiAgICAgICAgbGV0IGNsYXNzMTtcbiAgICAgICAgbGV0IGNsYXNzMjtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICAvLyDjg6Ljg7zjg6vjga7llYblk4Hnlarlj7fjgpLnibnlrprjgZnjgotcbiAgICAgICAgICBtb2RlbCA9IGl0ZW0ubWFsbFtgJHtkb2MubmFtZX1gXVtgJHtkb2MubW9kZWxQYXRofWBdO1xuICAgICAgICAgIG1vZGVsID0gdHlwZW9mIG1vZGVsID09PSAndW5kZWZpbmVkJyA/ICcnIDogbW9kZWw7XG4gICAgICAgICAgY2xhc3MxID0gaXRlbS5tYWxsW2Ake2RvYy5uYW1lfWBdW2Ake2RvYy5jbGFzczFQYXRofWBdO1xuICAgICAgICAgIGNsYXNzMSA9IHR5cGVvZiBjbGFzczEgPT09ICd1bmRlZmluZWQnID8gJycgOiBjbGFzczE7XG4gICAgICAgICAgY2xhc3MyID0gaXRlbS5tYWxsW2Ake2RvYy5uYW1lfWBdW2Ake2RvYy5jbGFzczJQYXRofWBdO1xuICAgICAgICAgIGNsYXNzMiA9IHR5cGVvZiBjbGFzczIgPT09ICd1bmRlZmluZWQnID8gJycgOiBjbGFzczI7XG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcbiAgICAgICAgICAvLyDllYblk4Hjga7jg6Ljg7zjg6vmg4XloLHjga7lj5blvpfjgavlpLHmlZfjgZfjgZ/vvIjjg4fjg7zjgr/jgYzoqK3lrprjgZXjgozjgabjgYTjgarjgYTjgarjganvvIlcbiAgICAgICAgICAvLyBtb2RlbCA9IGl0ZW0ubW9kZWxcbiAgICAgICAgICAvLyBjbGFzczEgPSBpdGVtLmNsYXNzMV92YWx1ZVxuICAgICAgICAgIC8vIGNsYXNzMiA9IGl0ZW0uY2xhc3MyX3ZhbHVlXG4gICAgICAgICAgcmV0dXJuO1xuICAgICAgICB9XG5cbiAgICAgICAgc2VsZWN0W2Dlj5fms6jllYblk4FJRF8ke2luZGV4fWBdID0gbnVsbDtcbiAgICAgICAgc2VsZWN0W2DlupfoiJdJRF8ke2luZGV4fWBdID0gZG9jWyflupfoiJdJRCddO1xuICAgICAgICBzZWxlY3RbYOW6l+iIl+WQjV8ke2luZGV4fWBdID0gZG9jLm5hbWU7XG4gICAgICAgIHNlbGVjdFtg5Y+X5rOo5ZWG5ZOB55Wq5Y+3XyR7aW5kZXh9YF0gPSBgJHttb2RlbH0ke2NsYXNzMX0ke2NsYXNzMn1gO1xuICAgICAgICBzZWxlY3RbYOacieWKueODleODqeOCsF8ke2luZGV4fWBdID0gJ+acieWKuSc7XG4gICAgICB9LFxuICAgICk7XG5cbiAgICByZXR1cm4gc2VsZWN0O1xuICB9XG5cbiAgLy9cbiAgLy8gUm9ib3QtaW4g5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+344Gu55m76Yyy44Gu44Gf44KB44Gu44OH44O844K/44KS5L2c44KLXG4gIC8vIOOBneOBrjMgc2VsZWN0U2hvcC5jc3ZcblxuICBzdGF0aWMgY29udmVydEl0ZW1Sb2JvdGluU2VsZWN0U2hvcChzaG9wLCBpdGVtKSB7XG4gICAgY29uc3QgbW9kZWwgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AubW9kZWxQYXRofWBdO1xuICAgIGNvbnN0IGNsYXNzMSA9IGl0ZW0ubWFsbFtgJHtzaG9wLm5hbWV9YF1bYCR7c2hvcC5jbGFzczFQYXRofWBdO1xuICAgIGNvbnN0IGNsYXNzMiA9IGl0ZW0ubWFsbFtgJHtzaG9wLm5hbWV9YF1bYCR7c2hvcC5jbGFzczJQYXRofWBdO1xuXG4gICAgcmV0dXJuIHtcbiAgICAgIOOCs+ODs+ODiOODreODvOODq+OCq+ODqeODoDogJ3UnLFxuICAgICAg5paw6KaP55m76YyySUQ6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXG4gICAgICDlj5fms6jllYblk4FJRDogbnVsbCxcbiAgICAgIOW6l+iIl0lEOiBzaG9wWyflupfoiJdJRCddLFxuICAgICAg5bqX6IiX5ZCNOiBudWxsLFxuICAgICAg5Y+X5rOo5ZWG5ZOB55Wq5Y+3OiBgJHttb2RlbH0ke2NsYXNzMX0ke2NsYXNzMn1gLFxuICAgICAg5pyJ5Yq544OV44Op44KwOiAn5pyJ5Yq5JyxcbiAgICB9O1xuICB9XG59XG4iLCJpbXBvcnQge1xuICBNb25nbyxcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcbmltcG9ydCB7XG4gIE9iamVjdElELFxufSBmcm9tICdic29uJztcbmltcG9ydCBUZXh0VXRpbCBmcm9tICcuLi91dGlsL3RleHQnO1xuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4vaXRlbXMnO1xuaW1wb3J0IHtcbiAgUm9ib3Rpbk9yZGVycyxcbn0gZnJvbSAnLi4vY29sbGVjdGlvbnMnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSb2JvdGluIHtcbiAgY29uc3RydWN0b3IgKCkge1xuICAgIC8vIGltcG9ydE9yZGVyVGVtcCDjgavplqLpgKNcbiAgICAvLyDlj5fnmbrms6jjgrfjgrnjg4bjg6Djgafjga/lh6bnkIbjgafjgY3jgarjgYTkvovlpJbnmoTlj5fms6jlh6bnkIbjgavlr77jgZfjgaZcbiAgICAvLyDlgIvliKXjga7pgIHjgornirbnmbrooYzjgarjganjgpLooYzjgYZcbiAgICB0aGlzLk9yZGVyID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24obnVsbCk7XG4gIH1cblxuICBzdGF0aWMgY3JlYXRlUmVhZGFibGVPcmRlcihxdWVyeSA9IHt9KSB7XG4gICAgcmV0dXJuIFJvYm90aW5PcmRlcnMucmF3Q29sbGVjdGlvbigpLmZpbmQocXVlcnksIHsgX2lkOiAwLCByb2JvdGluOiAxIH0pLnN0cmVhbSgpO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7Kn0gZG9jT3JkZXJcbiAgICogQHBhcmFtIHtJdGVtQ29udHJvbGxlcn0gaXRlbVNcbiAgICovXG4gIGltcG9ydE9yZGVyVGVtcCAoZG9jT3JkZXIsIGl0ZW1TKSB7XG4gICAgLy8g5Y+X5rOo44OH44O844K/44KS44OH44O844K/44OZ44O844K544Gr5L+d5a2YXG4gICAgdGhpcy5PcmRlci5pbnNlcnQoeyByb2JvdGluOiBkb2NPcmRlciB9KTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0geyp9IGRvY09yZGVyXG4gICAqIEBwYXJhbSB7SXRlbUNvbnRyb2xsZXJ9IGl0ZW1Db25cbiAgICovXG4gIHN0YXRpYyBhc3luYyBpbXBvcnRPcmRlcihkb2NPcmRlciwgaXRlbUNvbikge1xuICAgIC8vIOWVhuWTgeeVquWPt+OCkm1vbmdvSWTjgajjgZfjgabmpJzntKLjgZfjgIHoqbLlvZPjgZnjgotpdGVt44GM44GC44KM44Gw5pu444GN5o+b44GI44KLXG4gICAgLy8gaWYgKE9iamVjdElELmlzVmFsaWQoZG9jT3JkZXJbJ+WVhuWTgeOCs+ODvOODiSddKSkge1xuICAgIC8vICAgY29uc3QgaXRlbSA9IGF3YWl0IGl0ZW1Db24uSXRlbXMuZmluZE9uZSh7IF9pZDogbmV3IE9iamVjdElEKGRvY09yZGVyWyfllYblk4HjgrPjg7zjg4knXSkgfSk7XG4gICAgLy8gICBpZiAoaXRlbSkgZG9jT3JkZXJbJ+WVhuWTgeOCs+ODvOODiSddID0gYXdhaXQgaXRlbUNvbi5nZXRNb2RlbENsYXNzKGl0ZW0pO1xuICAgIC8vIH1cblxuICAgIC8vIOWPl+azqOODh+ODvOOCv+OCkuODh+ODvOOCv+ODmeODvOOCueOBq+S/neWtmFxuICAgIGNvbnN0IGluc2VydERvYyA9IHtcbiAgICAgIHJvYm90aW46IGRvY09yZGVyLFxuICAgIH07XG5cbiAgICAvLyDjgZnjgafjgavlj5fms6jjgYzlj5bjgorovrzjgb7jgozjgabjgYTjgZ/loLTlkIjjga/jgIFkb2NPcmRlcuOBruWGheWuueOBq+abtOaWsOOBmeOCi1xuICAgIC8vIOWPluOCiui+vOOBvuOCjOOBpuOBhOOBquOBhOWPl+azqOOBruWgtOWQiOOBr+aWsOimj+eZu+mMsuOBmeOCi1xuICAgIFJvYm90aW5PcmRlcnMudXBkYXRlKHtcbiAgICAgICdyb2JvdGluLuWPl+azqElEJzogZG9jT3JkZXJbJ+WPl+azqElEJ10sXG4gICAgICAncm9ib3Rpbi7mmI7ntLBJRCc6IGRvY09yZGVyWyfmmI7ntLBJRCddLFxuICAgIH0sIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgcm9ib3RpbjogZG9jT3JkZXIsXG4gICAgICB9LFxuICAgIH0sIHtcbiAgICAgIHVwc2VydDogdHJ1ZSxcbiAgICB9KTtcblxuICAgIC8vIOeZuuazqOOCueODhuODvOOCv+OCueOBjOioreWumuOBleOCjOOBpuOBhOOBquOBhOODieOCreODpeODoeODs+ODiO+8iOaWsOimj+eZu+mMsuWPl+azqO+8iVxuICAgIC8vIOeZuuazqOOCueODhuODvOOCv+OCueOBruWIneacn+WApOOCkuioreWumuOBmeOCi1xuICAgIFJvYm90aW5PcmRlcnMudXBkYXRlKHtcbiAgICAgIHZlbmRvcjogeyAkZXhpc3RzOiAwIH0sXG4gICAgfSwge1xuICAgICAgJHNldDoge1xuICAgICAgICB2ZW5kb3I6IHsgLy8g55m65rOo44K544OG44O844K/44K544Gu5Yid5pyf5YCkXG4gICAgICAgICAgb3JkZXJ0bzogJycsIC8vIOeZuuazqOWFiFxuICAgICAgICAgIG9yZGVyRGF0ZTogbnVsbCwgLy8g55m65rOo5pelXG4gICAgICAgICAgcHJvbWlzZTogbnVsbCwgLy8g55m66YCB5LqI5a6a5pelXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgIH0pO1xuICB9XG5cbiAgc3RhdGljIGxpc3RJdGVtQ29kZUZvckxhYmVsKHF1ZXJ5LCBjb2xsZWN0aW9uID0gbnVsbCkge1xuICAgIC8vIOWPl+azqOOCt+OCueODhuODoOS+i+WkluOBruWgtOWQiOOAgeS7u+aEj+OBruOCs+ODrOOCr+OCt+ODp+ODs++8iG1pbmltb25nb+OBruS4gOaZguODh+ODvOOCv+ODmeODvOOCue+8ieOBjOmBuOaKnuOBp+OBjeOCi1xuICAgIGNvbGxlY3Rpb24gPSBjb2xsZWN0aW9uID09PSBudWxsID8gUm9ib3Rpbk9yZGVycyA6IGNvbGxlY3Rpb247XG5cbiAgICAvLyDmpJzntKLmnaHku7bjgavoqbLlvZPjgZnjgovlj5fms6jjgpLoqr/jgbnjgotcbiAgICBjb25zdCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoXG4gICAgICBxdWVyeSwge1xuICAgICAgICBmaWVsZHM6IHtcbiAgICAgICAgICBfaWQ6IDAsXG4gICAgICAgICAgJ3JvYm90aW4u5ZWG5ZOB44Kz44O844OJJzogMSxcbiAgICAgICAgICAncm9ib3Rpbi7mlbDph48nOiAxLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICApO1xuICAgIC8vIOmAgeOCiueKtuODrOOCs+ODvOODieOBq+ipsuW9k+OBmeOCi+WPl+azqOODrOOCs+ODvOODieOBjOimi+OBpOOBi+OCieOBquOBhOWgtOWQiFxuICAgIGlmICghY3VyLmNvdW50KCkpIHRocm93IG5ldyBFcnJvcign6YCB44KK54q244Gr5a++5b+c44GZ44KL5Y+X5rOo44GM6KaL44Gk44GL44KK44G+44Gb44KT44CCQ1NW44OV44Kh44Kk44Or44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJyk7XG4gICAgLy8g5ZWG5ZOB44Oq44K544OI44KS5L2c5oiQ44GZ44KLXG4gICAgY29uc3QgbGlzdCA9IFtdO1xuICAgIGN1ci5mb3JFYWNoKChkb2MpID0+IHtcbiAgICAgIGNvbnN0IHEgPSBkb2Mucm9ib3Rpbi7mlbDph48gPT0gMSA/ICcnIDogYFske2RvYy5yb2JvdGluLuaVsOmHj31FQV1gO1xuICAgICAgbGlzdC5wdXNoKGAke2RvYy5yb2JvdGluLuWVhuWTgeOCs+ODvOODiX0gJHtxfWApO1xuICAgIH0pO1xuICAgIC8vIOWVhuWTgeODquOCueODiOOCkui/lOOBmVxuICAgIHJldHVybiBsaXN0O1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7Kn0gZG9jTGFiZWxcbiAgICogQHBhcmFtIHtBcnJheX0gd3JpdGVJdGVtQ29kZVRvXG4gICAqL1xuICB0cmFuc2Zvcm1MYWJlbFNlaW5vKGRvY0xhYmVsLCBsYWJlbE9wdGlvbnMpIHtcbiAgICAvLyDllYblk4HjgrPjg7zjg4njgpLpgIHjgornirZDU1bjgavln4vjgoHovrzjgoBcbiAgICAvL1xuXG4gICAgLy8g5Y+X5rOo55Wq5Y+344KS5oq95Ye6XG4gICAgY29uc3Qgb3JkZXJOdW1iZXIgPSBkb2NMYWJlbFszMl07IC8vIDMz55Wq55uu44Gu6aCF55uu44CM6KiY5LqL77yR44CNXG5cbiAgICAvLyAvLyDlj5fms6hDU1bjgYvjgonlupfoiJflkI3jgajlj5fms6jnlarlj7fjgpLjgq3jg7zjgavllYblk4HjgrPjg7zjg4nkuIDopqfjgpLlj5blvpfjgZnjgotcbiAgICAvLyBjb25zdCBjdXIgPSBSb2JvdGluT3JkZXJzLmZpbmQoe1xuICAgIC8vICAg5bqX6IiX5ZCNOiBkb2NMYWJlbFsxMV0sIC8vIDEy55Wq55uu44Gu6aCF55uu44CM6I236YCB5Lq65ZCN56ew44CNXG4gICAgLy8gICAvLyDlj5fms6hDU1blh7rlipvjgZXjgozjgabjgYTjgovlj5fms6jnlarlj7fjgYzmloflrZfliJflvaLlvI/jgafjgoLmlbDlgKTlvaLlvI/jgafjgoLlvJXjgaPjgYvjgYvjgovjgojjgYbjgavjgZnjgovvvIgkaW7vvIlcbiAgICAvLyAgIOWPl+azqOeVquWPtzogeyAkaW46IFtvcmRlck51bWJlciwgTnVtYmVyKG9yZGVyTnVtYmVyKV0gfVxuICAgIC8vIH0sIHtcbiAgICAvLyAgIGZpZWxkczoge1xuICAgIC8vICAgICBfaWQ6IDAsXG4gICAgLy8gICAgIOWVhuWTgeOCs+ODvOODiTogMVxuICAgIC8vICAgfVxuICAgIC8vIH0pO1xuXG4gICAgY29uc3QgaXRlbXMgPSBSb2JvdGluLmxpc3RJdGVtQ29kZUZvckxhYmVsKFxuICAgICAge1xuICAgICAgICAncm9ib3Rpbi7lupfoiJflkI0nOiBkb2NMYWJlbFsxMV0sIC8vIDEy55Wq55uu44Gu6aCF55uu44CM6I236YCB5Lq65ZCN56ew44CNXG4gICAgICAgIC8vIOWPl+azqENTVuWHuuWKm+OBleOCjOOBpuOBhOOCi+WPl+azqOeVquWPt+OBjOaWh+Wtl+WIl+W9ouW8j+OBp+OCguaVsOWApOW9ouW8j+OBp+OCguW8leOBo+OBi+OBi+OCi+OCiOOBhuOBq+OBmeOCi++8iCRpbu+8iVxuICAgICAgICAncm9ib3Rpbi7lj5fms6jnlarlj7cnOiB7XG4gICAgICAgICAgJGluOiBbb3JkZXJOdW1iZXIsIE51bWJlcihvcmRlck51bWJlcildLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIC8vIOWPl+azqOOCt+OCueODhuODoOS+i+WkluOBruWgtOWQiOOAgeS7u+aEj+OBruOCs+ODrOOCr+OCt+ODp+ODs++8iG1pbmltb25nb+OBruS4gOaZguODh+ODvOOCv+ODmeODvOOCue+8ieOBjOmBuOaKnuOBp+OBjeOCi1xuICAgICAgdHlwZW9mIHRoaXMuT3JkZXIgPT09ICd1bmRlZmluZWQnID8gbnVsbCA6IHRoaXMuT3JkZXIsXG4gICAgKTtcblxuICAgIC8vIC8vIOmAgeOCiueKtuODrOOCs+ODvOODieOBq+ipsuW9k+OBmeOCi+WPl+azqOODrOOCs+ODvOODieOBjOimi+OBpOOBi+OCieOBquOBhOWgtOWQiFxuICAgIC8vIGlmICghY3VyLmNvdW50KCkpIHRocm93IG5ldyBFcnJvcign6YCB44KK54q244Gr5a++5b+c44GZ44KL5Y+X5rOo44GM6KaL44Gk44GL44KK44G+44Gb44KT44CCQ1NW44OV44Kh44Kk44Or44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJyk7XG5cbiAgICAvLyAvLyDpgIHjgornirbjga7nmbrpgIHllYblk4HjgrPjg7zjg4nkuIDopqfjgpLphY3liJfjgavjgZnjgotcbiAgICAvLyBjb25zdCBpdGVtcyA9IGN1ci5mZXRjaCgpO1xuXG4gICAgLy8gZG9jTGFiZWwgOiDlhaXlipvpgIHjgornirbjg4fjg7zjgr9cbiAgICAvLyBjb25MYWJlbCA6IOWHuuWKm+eUqOmAgeOCiueKtuODh+ODvOOCv1xuICAgIGNvbnN0IGNvbkxhYmVsID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkb2NMYWJlbCkpO1xuXG4gICAgLy8gd3JpdGVJdGVtQ29kZVRvIO+8iOS4gOOBpOOBrumAgeOCiueKtuOBq+iomOi8ieOBp+OBjeOCi+WVhuWTgeOCs+ODvOODieOBruacgOWkp+aVsO+8ieOBrue3j+aVsOOCiOOCiuOAgeWPl+azqOODh+ODvOOCv+OBruWVhuWTgeaVsOOBjOWkmuOBhOWgtOWQiOOBr+OCqOODqeODvFxuICAgIGNvbnN0IHdyaXRlSXRlbUNvZGVUbyA9IGxhYmVsT3B0aW9ucy53cml0ZUl0ZW1Db2RlVG87XG4gICAgaWYgKHdyaXRlSXRlbUNvZGVUby5sZW5ndGggPCBpdGVtcy5sZW5ndGgpIHRocm93IG5ldyBFcnJvcihg6YCB44KK54q244OH44O844K/44Gr6KiY6LyJ44Gn44GN44KL5ZWG5ZOB5pWw44GvJHt3cml0ZUl0ZW1Db2RlVG8ubGVuZ3RofeWAi+OBvuOBp+OBp+OBmWApO1xuXG4gICAgLy8g5a6a5pWw44Gu5Z+L44KB6L6844G/XG4gICAgbGFiZWxPcHRpb25zLmNvbnN0LmZvckVhY2goKGUpID0+IHtcbiAgICAgIGNvbkxhYmVsW2UuY29sdW1uXSA9IGUudmFsdWU7XG4gICAgfSk7XG5cbiAgICAvLyDpgIHjgornirbjg4fjg7zjgr/jgavllYblk4HjgrPjg7zjg4njgpLoqJjpjLLjgZnjgotcbiAgICB3cml0ZUl0ZW1Db2RlVG8uZm9yRWFjaCgoZSwgaSkgPT4ge1xuICAgICAgaWYgKGl0ZW1zW2ldKSB7XG4gICAgICAgIGNvbkxhYmVsW2VdID0gaXRlbXNbaV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyDpgIHjgornirbjga7llYblk4HjgrPjg7zjg4nmrITjga/jgZnjgbnjgabln4vjgoHjgotcbiAgICAgICAgLy8g44GT44KM44Gr44KI44KK5YiX44Gu5qyg6JC944KS6Ziy44GQXG4gICAgICAgIGNvbkxhYmVsW2VdID0gJyc7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyDkvY/miYDmloflrZfliJfjga7liIblibLjgpLkv67mraPjgZnjgotcbiAgICAvLyBrZXlTIOOBp+aMh+WumuOBleOCjOOBnyB0YXJnZXQg5YaF44Gu6KaB57Sg44Gu5YCk44KS44CBbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44Gn5YiG5Ymy44GX5YaN5qeL56+J44GZ44KLXG4gICAgLy8gbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44KS6LaF44GI44KL5paH5a2X5YiX44Gv44CB5Y2K6KeS44K544Oa44O844K544Gn5YiG5Ymy44GZ44KLXG4gICAgLy8gVGV4dFV0aWwuc3BsaXRsZW5iKGNvbkxhYmVsLCBbMTIsIDEzXSwgNDApOyAvLyDpoIXnm64xM+OAjOiNt+mAgeS6uuS9j+aJgO+8keOAjeOAgemgheebrjE044CM6I236YCB5Lq65L2P5omA77yS44CNXG4gICAgLy8gVGV4dFV0aWwuc3BsaXRsZW5iKGNvbkxhYmVsLCBbMjEsIDIyXSwgNjApOyAvLyDpoIXnm64yMuOAjOOBiuWxiuOBkeWFiOS9j+aJgO+8keOAjeOAgemgheebrjIz44CM44GK5bGK44GR5YWI5L2P5omA77yS44CNXG5cbiAgICByZXR1cm4gY29uTGFiZWw7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHsqfSBkb2NMYWJlbFxuICAgKiBAcGFyYW0ge0FycmF5fSB3cml0ZUl0ZW1Db2RlVG9cbiAgICovXG4gIHRyYW5zZm9ybUxhYmVsWXVwYWNrKGRvY0xhYmVsLCBsYWJlbE9wdGlvbnMpIHtcbiAgICAvLyDllYblk4HjgrPjg7zjg4njgpLpgIHjgornirZDU1bjgavln4vjgoHovrzjgoBcbiAgICAvL1xuXG4gICAgLy8g5Y+X5rOo55Wq5Y+344KS5oq95Ye6XG4gICAgY29uc3Qgb3JkZXJOdW1iZXIgPSBkb2NMYWJlbFsn6KiY5LqL5ZCN77yRJ10ucmVwbGFjZSgn5Y+X5rOo55Wq5Y+377yaJywgJycpO1xuXG4gICAgLy8gLy8g5Y+X5rOoQ1NW44GL44KJ5bqX6IiX5ZCN44Go5Y+X5rOo55Wq5Y+344KS44Kt44O844Gr5ZWG5ZOB44Kz44O844OJ5LiA6Kan44KS5Y+W5b6X44GZ44KLXG4gICAgLy8gY29uc3QgY3VyID0gUm9ib3Rpbk9yZGVycy5maW5kKHtcbiAgICAvLyAgIOW6l+iIl+WQjTogZG9jTGFiZWxbJ+OBlOS+nemgvOS4uyDlkI3np7AxJ10sXG4gICAgLy8gICAvLyDlj5fms6hDU1blh7rlipvjgZXjgozjgabjgYTjgovlj5fms6jnlarlj7fjgYzmloflrZfliJflvaLlvI/jgafjgoLmlbDlgKTlvaLlvI/jgafjgoLlvJXjgaPjgYvjgYvjgovjgojjgYbjgavjgZnjgovvvIgkaW7vvIlcbiAgICAvLyAgIOWPl+azqOeVquWPtzogeyAkaW46IFtvcmRlck51bWJlciwgTnVtYmVyKG9yZGVyTnVtYmVyKV0gfVxuICAgIC8vIH0sIHtcbiAgICAvLyAgIGZpZWxkczoge1xuICAgIC8vICAgICBfaWQ6IDAsXG4gICAgLy8gICAgIOWVhuWTgeOCs+ODvOODiTogMVxuICAgIC8vICAgfVxuICAgIC8vIH0pO1xuXG4gICAgY29uc3QgaXRlbXMgPSBSb2JvdGluLmxpc3RJdGVtQ29kZUZvckxhYmVsKFxuICAgICAge1xuICAgICAgICAncm9ib3Rpbi7lupfoiJflkI0nOiBkb2NMYWJlbFsn44GU5L6d6aC85Li7IOWQjeensDEnXSxcbiAgICAgICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXG4gICAgICAgICdyb2JvdGluLuWPl+azqOeVquWPtyc6IHtcbiAgICAgICAgICAkaW46IFtvcmRlck51bWJlciwgTnVtYmVyKG9yZGVyTnVtYmVyKV0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgLy8g5Y+X5rOo44K344K544OG44Og5L6L5aSW44Gu5aC05ZCI44CB5Lu75oSP44Gu44Kz44Os44Kv44K344On44Oz77yIbWluaW1vbmdv44Gu5LiA5pmC44OH44O844K/44OZ44O844K577yJ44GM6YG45oqe44Gn44GN44KLXG4gICAgICB0eXBlb2YgdGhpcy5PcmRlciA9PT0gJ3VuZGVmaW5lZCcgPyBudWxsIDogdGhpcy5PcmRlcixcbiAgICApO1xuXG4gICAgLy8gZG9jTGFiZWwgOiDlhaXlipvpgIHjgornirbjg4fjg7zjgr9cbiAgICAvLyBjb25MYWJlbCA6IOWHuuWKm+eUqOmAgeOCiueKtuODh+ODvOOCv1xuICAgIGNvbnN0IGNvbkxhYmVsID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkb2NMYWJlbCkpO1xuXG4gICAgLy8gd3JpdGVJdGVtQ29kZVRvIO+8iOS4gOOBpOOBrumAgeOCiueKtuOBq+iomOi8ieOBp+OBjeOCi+WVhuWTgeOCs+ODvOODieOBruacgOWkp+aVsO+8ieOBrue3j+aVsOOCiOOCiuOAgeWPl+azqOODh+ODvOOCv+OBruWVhuWTgeaVsOOBjOWkmuOBhOWgtOWQiOOBr+OCqOODqeODvFxuICAgIGNvbnN0IHdyaXRlSXRlbUNvZGVUbyA9IGxhYmVsT3B0aW9ucy53cml0ZUl0ZW1Db2RlVG87XG4gICAgaWYgKHdyaXRlSXRlbUNvZGVUby5sZW5ndGggPCBpdGVtcy5sZW5ndGgpIHRocm93IG5ldyBFcnJvcihg6YCB44KK54q244OH44O844K/44Gr6KiY6LyJ44Gn44GN44KL5ZWG5ZOB5pWw44GvJHt3cml0ZUl0ZW1Db2RlVG8ubGVuZ3RofeWAi+OBvuOBp+OBp+OBmWApO1xuXG5cbiAgICAvLyDpgIHjgornirbjg4fjg7zjgr/jgavllYblk4HjgrPjg7zjg4njgpLoqJjpjLLjgZnjgotcbiAgICB3cml0ZUl0ZW1Db2RlVG8uZm9yRWFjaCgoZSwgaSkgPT4ge1xuICAgICAgaWYgKGl0ZW1zW2ldKSB7XG4gICAgICAgIGNvbkxhYmVsW2VdID0gaXRlbXNbaV07XG4gICAgICB9IGVsc2Uge1xuICAgICAgICAvLyDpgIHjgornirbjga7llYblk4HjgrPjg7zjg4nmrITjga/jgZnjgbnjgabln4vjgoHjgotcbiAgICAgICAgLy8g44GT44KM44Gr44KI44KK5YiX44Gu5qyg6JC944KS6Ziy44GQXG4gICAgICAgIGNvbkxhYmVsW2VdID0gJyc7XG4gICAgICB9XG4gICAgfSk7XG5cbiAgICAvLyDpgIHjgornirbnqK7liKXjgpLoqK3lrppcbiAgICBjb25MYWJlbFsn6YCB44KK54q256iu5YilJ10gPSBsYWJlbE9wdGlvbnMubGFiZWxJZDtcblxuICAgIC8vIOS9j+aJgOaWh+Wtl+WIl+OBruWIhuWJsuOCkuS/ruato+OBmeOCi1xuICAgIC8vIGtleVMg44Gn5oyH5a6a44GV44KM44GfIHRhcmdldCDlhoXjga7opoHntKDjga7lgKTjgpLjgIFsZW5ndGjvvIjjg5DjgqTjg4jplbfvvInjgafliIblibLjgZflho3mp4vnr4njgZnjgotcbiAgICAvLyAvLyBsZW5ndGjvvIjjg5DjgqTjg4jplbfvvInjgpLotoXjgYjjgovmloflrZfliJfjga/jgIHljYrop5Ljgrnjg5rjg7zjgrnjgafliIblibLjgZnjgotcbiAgICAvLyBUZXh0VXRpbC5zcGxpdGxlbmIoY29uTGFiZWwsIFsn44GU5L6d6aC85Li7IOS9j+aJgDEnLCAn44GU5L6d6aC85Li7IOS9j+aJgDInLCAn44GU5L6d6aC85Li7IOS9j+aJgDMnXSwgNTApO1xuICAgIC8vIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWyfjgYrlsYrjgZHlhYgg5L2P5omAMScsICfjgYrlsYrjgZHlhYgg5L2P5omAMicsICfjgYrlsYrjgZHlhYgg5L2P5omAMyddLCA1MCk7XG4gICAgcmV0dXJuIGNvbkxhYmVsO1xuICB9XG5cbiAgdHJhbnNmb3JtTGFiZWxZdXBhY2tldChkb2NMYWJlbCwgbGFiZWxPcHRpb25zKSB7XG4gICAgLy8g5ZWG5ZOB44Kz44O844OJ44KS6YCB44KK54q2Q1NW44Gr5Z+L44KB6L6844KAXG4gICAgY29uc3Qgb3JkZXJOdW1iZXIgPSBkb2NMYWJlbFsn6KiY5LqL5ZCN77yRJ10ucmVwbGFjZSgn5Y+X5rOo55Wq5Y+377yaJywgJycpO1xuICAgIC8vIGNvbnN0IGN1ciA9IFJvYm90aW5PcmRlcnMuZmluZCh7XG4gICAgLy8gICDlupfoiJflkI06IGRvY0xhYmVsWyfjgZTkvp3poLzkuLsg5ZCN56ewMSddLFxuICAgIC8vICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXG4gICAgLy8gICDlj5fms6jnlarlj7c6IHsgJGluOiBbb3JkZXJOdW1iZXIsIE51bWJlcihvcmRlck51bWJlcildIH1cbiAgICAvLyB9LCB7XG4gICAgLy8gICBmaWVsZHM6IHtcbiAgICAvLyAgICAgX2lkOiAwLFxuICAgIC8vICAgICDllYblk4HjgrPjg7zjg4k6IDFcbiAgICAvLyAgIH1cbiAgICAvLyB9KTtcbiAgICBjb25zdCBpdGVtcyA9IFJvYm90aW4ubGlzdEl0ZW1Db2RlRm9yTGFiZWwoXG4gICAgICB7XG4gICAgICAgICdyb2JvdGluLuW6l+iIl+WQjSc6IGRvY0xhYmVsWyfjgZTkvp3poLzkuLsg5ZCN56ewMSddLFxuICAgICAgICAvLyDlj5fms6hDU1blh7rlipvjgZXjgozjgabjgYTjgovlj5fms6jnlarlj7fjgYzmloflrZfliJflvaLlvI/jgafjgoLmlbDlgKTlvaLlvI/jgafjgoLlvJXjgaPjgYvjgYvjgovjgojjgYbjgavjgZnjgovvvIgkaW7vvIlcbiAgICAgICAgJ3JvYm90aW4u5Y+X5rOo55Wq5Y+3Jzoge1xuICAgICAgICAgICRpbjogW29yZGVyTnVtYmVyLCBOdW1iZXIob3JkZXJOdW1iZXIpXSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICAvLyDlj5fms6jjgrfjgrnjg4bjg6DkvovlpJbjga7loLTlkIjjgIHku7vmhI/jga7jgrPjg6zjgq/jgrfjg6fjg7PvvIhtaW5pbW9uZ2/jga7kuIDmmYLjg4fjg7zjgr/jg5njg7zjgrnvvInjgYzpgbjmip7jgafjgY3jgotcbiAgICAgIHR5cGVvZiB0aGlzLk9yZGVyID09PSAndW5kZWZpbmVkJyA/IG51bGwgOiB0aGlzLk9yZGVyLFxuICAgICk7XG5cbiAgICBjb25zdCBjb25MYWJlbCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZG9jTGFiZWwpKTtcblxuICAgIC8vIOmAgeOCiueKtueoruWIpeOCkuioreWumlxuICAgIGNvbkxhYmVsWyfpgIHjgornirbnqK7liKUnXSA9IGxhYmVsT3B0aW9ucy5sYWJlbElkO1xuXG4gICAgY29uTGFiZWxbJ+iomOS6i+WQje+8kSddID0gaXRlbXNbMF07XG4gICAgY29uTGFiZWxbJ+ODleODquODvOmgheebru+8kO+8kSddID0gaXRlbXNbMV07XG4gICAgY29uTGFiZWxbJ+ODleODquODvOmgheebru+8kO+8lSddID0gaXRlbXNbMl07XG5cbiAgICAvLyBrZXlTIOOBp+aMh+WumuOBleOCjOOBnyB0YXJnZXQg5YaF44Gu6KaB57Sg44Gu5YCk44KS44CBbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44Gn5YiG5Ymy44GX5YaN5qeL56+J44GZ44KLXG4gICAgLy8gbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44KS6LaF44GI44KL5paH5a2X5YiX44Gv44CB5Y2K6KeS44K544Oa44O844K544Gn5YiG5Ymy44GZ44KLXG4gICAgLy8gVGV4dFV0aWwuc3BsaXRsZW5iKGNvbkxhYmVsLCBbJ+OBlOS+nemgvOS4uyDkvY/miYAxJywgJ+OBlOS+nemgvOS4uyDkvY/miYAyJywgJ+OBlOS+nemgvOS4uyDkvY/miYAzJ10sIDUwKTtcbiAgICAvLyBUZXh0VXRpbC5zcGxpdGxlbmIoY29uTGFiZWwsIFsn44GK5bGK44GR5YWIIOS9j+aJgDEnLCAn44GK5bGK44GR5YWIIOS9j+aJgDInLCAn44GK5bGK44GR5YWIIOS9j+aJgDMnXSwgNTApO1xuICAgIHJldHVybiBjb25MYWJlbDtcbiAgfVxufVxuIiwiaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5pbXBvcnQgeyBqc29uMnhtbCB9IGZyb20gJ3htbC1qcydcclxuaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuLi91dGlsL2Vycm9yJ1xyXG5cclxuY29uc3QgQkFTRV9VUkkgPSAnaHR0cHM6Ly9hcGkubWFuYWdlci53b3dtYS5qcC93bXNob3BhcGknXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBXb3dtYUFwaSB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHNob3BJZCkge1xyXG4gICAgdGhpcy5wbHVnID0gcGx1Z1xyXG4gICAgdGhpcy5zaG9wSWQgPSBzaG9wSWRcclxuICB9XHJcblxyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG4gIGFzeW5jIHVwZGF0ZUl0ZW0gKHVwZGF0ZUl0ZW0pIHtcclxuICAgIGxldCByZXF1ZXN0ID0gYDxyZXF1ZXN0PjxzaG9wSWQ+JHt0aGlzLnNob3BJZH08L3Nob3BJZD48dXBkYXRlSXRlbT4ke2pzb24yeG1sKHVwZGF0ZUl0ZW0sIHtjb21wYWN0OiB0cnVlfSl9PC91cGRhdGVJdGVtPjwvcmVxdWVzdD5gXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5yZXF1ZXN0UG9zdChcclxuICAgICAgICAndXBkYXRlSXRlbUluZm8nLFxyXG4gICAgICAgIHJlcXVlc3RcclxuICAgICAgKVxyXG4gICAgICByZXR1cm4ge3Jlc3BvbnNlOiByZXMsIHJlcXVlc3RYTUw6IHJlcXVlc3R9XHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIHRocm93IE9iamVjdC5hc3NpZ24odXRpbEVycm9yLnBhcnNlKGUpLCB7cmVxdWVzdFhNTDogcmVxdWVzdH0pXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyByZXF1ZXN0UG9zdCAobWV0aG9kLCBib2R5KSB7XHJcbiAgICAvLyDmjqXntprjgqrjg5fjgrfjg6fjg7Pjga7kvZzmiJBcclxuICAgIGxldCBhcGlSZXF1ZXN0ID0ge1xyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgdXJpOiBgJHtCQVNFX1VSSX0vJHttZXRob2R9YCxcclxuICAgICAgYm9keTogYm9keVxyXG4gICAgfVxyXG4gICAgLy8g5YWx6YCa44Gu5o6l57aa6Kit5a6a44Go57WQ5ZCI44GZ44KLXHJcbiAgICBPYmplY3QuYXNzaWduKGFwaVJlcXVlc3QsIHRoaXMucGx1ZylcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgIGxldCByZXMgPSBhd2FpdCByZXF1ZXN0KGFwaVJlcXVlc3QpXHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHN0b2NrVXBkYXRlSXRlbSkge1xyXG4gICAgLy8g5o6l57aa44Kq44OX44K344On44Oz44Gu5L2c5oiQXHJcbiAgICBsZXQgYXBpUmVxdWVzdCA9IHtcclxuICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgIHVyaTogYCR7QkFTRV9VUkl9L3VwZGF0ZVN0b2NrYFxyXG4gICAgfVxyXG4gICAgLy8g5YWx6YCa44Gu5o6l57aa6Kit5a6a44Go57WQ5ZCI44GZ44KLXHJcbiAgICBPYmplY3QuYXNzaWduKGFwaVJlcXVlc3QsIHRoaXMucGx1ZylcclxuXHJcbiAgICBhcGlSZXF1ZXN0LmJvZHkgPSBhd2FpdCB0aGlzLnVwZGF0ZVN0b2NrQ3JlYXRlUmVxdWVzdEJvZHkoc3RvY2tVcGRhdGVJdGVtKVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3QoYXBpUmVxdWVzdClcclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9ja0NyZWF0ZVJlcXVlc3RCb2R5IChzdG9ja1VwZGF0ZUl0ZW0pIHtcclxuICAgIC8vXHJcbiAgICAvLyBzdG9ja1VwZGF0ZUl0ZW0gPVxyXG4gICAgLy8gW1xyXG4gICAgLy8gICB7XHJcbiAgICAvLyAgICAgaXRlbUNvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgIHZhcmlhdGlvbnM6IFtcclxuICAgIC8vICAgICAgICB7XHJcbiAgICAvLyAgICAgICAgICBjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgICAgICAgc3RvY2s6IDxOdW1iZXI+XHJcbiAgICAvLyAgICAgICAgfVxyXG4gICAgLy8gICAgIF1cclxuICAgIC8vICAgfVxyXG4gICAgLy8gXVxyXG5cclxuICAgIGxldCBzdG9ja1VwZGF0ZUl0ZW1YTUwgPSAnJ1xyXG5cclxuICAgIGZvciAobGV0IGl0ZW0gb2Ygc3RvY2tVcGRhdGVJdGVtKSB7XHJcbiAgICAgIC8vIOWApOOBruODgeOCp+ODg+OCr1xyXG4gICAgICBmb3IgKGxldCBlIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgIC8vIOWcqOW6q+aVsOOBruS4iumZkDEwMFxyXG4gICAgICAgIGlmIChlLnN0b2NrID4gMTAwKSBlLnN0b2NrID0gMTAwXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrVXBkYXRlSXRlbT4nXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPGl0ZW1Db2RlPiR7aXRlbS5pdGVtQ29kZX08L2l0ZW1Db2RlPmBcclxuXHJcbiAgICAgIC8vIOWVhuWTgeWcqOW6q+eoruWIpeOCkuaMr+OCiuWIhuOBkVxyXG4gICAgICAvLyAxIC0+IOmAmuW4uOWVhuWTgVxyXG4gICAgICAvLyAyIC0+IOmBuOaKnuiCouWIpeWcqOW6q1xyXG5cclxuICAgICAgbGV0IHZhcjAgPSBpdGVtLnZhcmlhdGlvbnNbMF1cclxuICAgICAgaWYgKHZhcjAuY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGUgPT09ICcnICYmIHZhcjAuY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlID09PSAnJykge1xyXG4gICAgICAgIC8vIOmAmuW4uOWVhuWTgVxyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrU2VnbWVudD4xPC9zdG9ja1NlZ21lbnQ+J1xyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPHN0b2NrQ291bnQ+JHt2YXIwLnN0b2NrfTwvc3RvY2tDb3VudD5gXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgLy8g6YG45oqe6IKi5Yil5Zyo5bqrXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tTZWdtZW50PjI8L3N0b2NrU2VnbWVudD4nXHJcblxyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIGZvciAobGV0IHZhcmlhdGlvbiBvZiBpdGVtLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICAgIC8vIOWcqOW6q+ioreWumuOCv+OCsOOBruWQjeWJjeOCkuW3ruOBl+abv+OBiOOCi1xyXG4gICAgICAgICAgdmFyaWF0aW9uLmNob2ljZXNTdG9ja0NvdW50ID0gdmFyaWF0aW9uLnN0b2NrXHJcbiAgICAgICAgICBkZWxldGUgdmFyaWF0aW9uLnN0b2NrXHJcblxyXG4gICAgICAgICAgLy8geG1s44KS5qeL5oiQ44GZ44KLXHJcbiAgICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxjaG9pY2VzU3RvY2tzPidcclxuICAgICAgICAgIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyh2YXJpYXRpb24pKSB7XHJcbiAgICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSBgPCR7a2V5fT4ke3ZhcmlhdGlvbltrZXldfTwvJHtrZXl9PmBcclxuICAgICAgICAgIH1cclxuICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPC9jaG9pY2VzU3RvY2tzPidcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPC9zdG9ja1VwZGF0ZUl0ZW0+J1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OBruS9nOaIkFxyXG4gICAgbGV0IGFwaVJlcXVlc3RCb2R5ID0gYFxyXG4gICAgPHJlcXVlc3Q+XHJcbiAgICA8c2hvcElkPiR7dGhpcy5zaG9wSWR9PC9zaG9wSWQ+XHJcbiAgICAke3N0b2NrVXBkYXRlSXRlbVhNTH1cclxuICAgIDwvcmVxdWVzdD5cclxuICAgIGBcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqPjgpLov5TjgZlcclxuICAgIHJldHVybiBhcGlSZXF1ZXN0Qm9keVxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyB1dGlsRXJyb3Ige1xyXG4gIHN0YXRpYyBwYXJzZSAoZSkge1xyXG4gICAgbGV0IHJlcyA9IHt9XHJcblxyXG4gICAgaWYgKGUgaW5zdGFuY2VvZiBFcnJvcikge1xyXG4gICAgICByZXMubWVzc2FnZSA9IGUubWVzc2FnZVxyXG4gICAgICByZXMubmFtZSA9IGUubmFtZVxyXG4gICAgICByZXMuZmlsZU5hbWUgPSBlLmZpbGVOYW1lXHJcbiAgICAgIHJlcy5saW5lTnVtYmVyID0gZS5saW5lTnVtYmVyXHJcbiAgICAgIHJlcy5jb2x1bW5OdW1iZXIgPSBlLmNvbHVtbk51bWJlclxyXG4gICAgICByZXMuc3RhY2sgPSBlLnN0YWNrXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICByZXMgPSBlXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNb25nb0NsaWVudCB9IGZyb20gJ21vbmdvZGInO1xuXG5leHBvcnQgY2xhc3MgTW9uZ29Db2xsZWN0aW9uIHtcbiAgc3RhdGljIGFzeW5jIGdldCAocGx1ZywgY29sbGVjdGlvbikge1xuICAgIGNvbnN0IGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmksIHsgdXNlTmV3VXJsUGFyc2VyOiB0cnVlIH0pO1xuICAgIGNvbnN0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpO1xuICAgIHJldHVybiBkYi5jb2xsZWN0aW9uKGNvbGxlY3Rpb24pO1xuICB9XG59XG4iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnO1xuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNeVNRTCB7XG4gIGNvbnN0cnVjdG9yIChwcm9maWxlKSB7XG4gICAgLy8g44Kz44ON44Kv44K344On44Oz44OX44O844Or5Yid5pyf5YyWXG4gICAgdGhpcy5wb29sID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlKTtcblxuICAgIC8vIOikh+aVsOihjOOCueODhuODvOODiOODoeODs+ODiOWvvuW/nFxuICAgIGNvbnN0IHByb2ZpbGVNdWx0aSA9IHsgbXVsdGlwbGVTdGF0ZW1lbnRzOiB0cnVlIH07XG4gICAgT2JqZWN0LmFzc2lnbihwcm9maWxlTXVsdGksIHByb2ZpbGUpO1xuICAgIHRoaXMucG9vbE11bHRpID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlTXVsdGkpO1xuICB9XG5cbiAgYXN5bmMgcXVlcnlTZWxlY3QodGFibGUsIGNvbmRpdGlvbiwgcHJvZHVjdCA9ICcqJykge1xuXG4gICAgY29uc3QgcHJvZHVjdFBhcnQgPSBwcm9kdWN0O1xuICAgIGNvbnN0IHRhYmxlUGFydCA9IGBGUk9NICR7dGFibGV9YDtcbiAgICBjb25zdCBjb25kaXRpb25QYXJ0ID0gY29uZGl0aW9uID8gYFdIRVJFICR7Y29uZGl0aW9ufWAgOiAnJztcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoYFNFTEVDVCAke3Byb2R1Y3RQYXJ0fSAke3RhYmxlUGFydH0gJHtjb25kaXRpb25QYXJ0fWApO1xuXG4gICAgLy8gU0VMRUNU44Gu57WQ5p6c44Gv44OH44Kj44O844OX44Kz44OU44O844GZ44KL44GT44Go44GnIHJvd2RhdGFwYWNrZXQg44KS5aSW44GZXG4gICAgcmV0dXJuIEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocmVzKSk7XG4gIH1cblxuICBzdGF0aWMgZm9ybWF0RGF0ZSAoZGF0ZSkge1xuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsIDE5KS5yZXBsYWNlKCdUJywgJyAnKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsXG4gICAqL1xuICBxdWVyeSAoc3FsKSB7XG4gICAgLy8g44Kz44ON44Kv44K344On44Oz56K656uLXG4gICAgLy8gbGV0IGNvbiA9IGF3YWl0IHRoaXMuZ2V0Q29uKCk7XG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcbiAgICAgIC50aGVuKFxuICAgICAgICAoY29uKSA9PiBuZXcgUHJvbWlzZShcbiAgICAgICAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwsIChlLCByZXMpID0+IHtcbiAgICAgICAgICAgICAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7PplovmlL5cbiAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcbiAgICAgICAgICAgICAgICAgIHJlamVjdChlKVxuICAgICAgICAgICAgICAgIH0gZWxzZSByZXNvbHZlKHJlcylcbiAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgIH1cbiAgICAgICAgICApLFxuICAgICAgKVxuICAgICAgLmNhdGNoKChlKSA9PiB7XG4gICAgICAgIHRocm93IGU7XG4gICAgICB9KTtcbiAgfVxuXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0XyAoc3FsKSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xuICAgIHJldHVybiByZXMuaW5zZXJ0SWQ7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvOOAgW51bGzjgIFqYXZhc2NyaXB0LT5teXNxbOaXpeS7mOWkieaPm+OBq+OCguWvvuW/nFxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cbiAgICovXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0ICh0YWJsZSwgZGF0YSA9IHt9LCBkYXRhU3FsID0ge30pIHtcbiAgICAvLyBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XG5cbiAgICBsZXQgc3FsID0gYElOU0VSVCBJTlRPICR7dGFibGV9IGA7XG5cbiAgICBjb25zdCBtYXAgPSBuZXcgTWFwKCk7XG4gICAgZm9yIChjb25zdCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCkge1xuICAgICAgICBtYXAuc2V0KGssICdOVUxMJyk7XG4gICAgICB9IGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XG4gICAgICAgIC8vIOaXpeS7mOOCkuWkieaPm1xuICAgICAgICBtYXAuc2V0KGssIGBcIiR7TXlTUUwuZm9ybWF0RGF0ZShkYXRhW2tdKX1cImApO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgbWFwLnNldChrLCBgJHtteXNxbC5lc2NhcGUoZGF0YVtrXSl9YCk7XG4gICAgICB9XG4gICAgfVxuICAgIGZvciAoY29uc3QgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xuICAgICAgbWFwLnNldChrLCBkYXRhU3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YVNxbFtrXSk7XG4gICAgfVxuXG4gICAgc3FsICs9IGAoICR7Wy4uLm1hcC5rZXlzKCldLmpvaW4oJywnKX0gKSBgO1xuXG4gICAgc3FsICs9IGBWQUxVRVMoICR7Wy4uLm1hcC52YWx1ZXMoKV0uam9pbignLCcpfSApIGA7XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZDtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0ge1N0cmluZ30gdGFibGVcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O8XG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhU3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xuICAgKi9cbiAgYXN5bmMgcXVlcnlVcGRhdGUgKHRhYmxlLCBmaWx0ZXIsIGRhdGEsIGRhdGFTcWwpIHtcbiAgICBsZXQgc3FsID0gYFVQREFURSAke3RhYmxlfSBTRVQgYDtcblxuICAgIGNvbnN0IHVwZGF0ZXMgPSBbXTtcbiAgICBmb3IgKGNvbnN0IGsgb2YgT2JqZWN0LmtleXMoZGF0YSkpIHtcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKTtcbiAgICB9XG4gICAgZm9yIChjb25zdCBrIG9mIE9iamVjdC5rZXlzKGRhdGFTcWwpKSB7XG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhU3FsW2tdfWApO1xuICAgIH1cbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJyk7XG5cbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYDtcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcbiAgICByZXR1cm4gcmVzO1xuICB9XG5cbiAgLy8gZW5hYmxlIHRvIHVzZSBtdWx0aXBsZSBzdGF0ZW1lbnRzXG4gIGFzeW5jIHF1ZXJ5TXVsdGkgKHNxbCkge1xuICAgIGNvbnN0IHBvb2xTd2FwID0gdGhpcy5wb29sO1xuICAgIHRoaXMucG9vbCA9IHRoaXMucG9vbE11bHRpO1xuICAgIHRyeSB7XG4gICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XG4gICAgICByZXR1cm4gcmVzO1xuICAgIH0gZmluYWxseSB7XG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcDtcbiAgICB9XG4gIH1cblxuICBhc3luYyBzdGFydFRyYW5zYWN0aW9uICgpIHtcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KCdTVEFSVCBUUkFOU0FDVElPTjsnKTtcbiAgfVxuXG4gIGFzeW5jIGNvbW1pdCAoKSB7XG4gICAgYXdhaXQgdGhpcy5xdWVyeSgnQ09NTUlUOycpO1xuICB9XG5cbiAgYXN5bmMgcm9sbGJhY2sgKCkge1xuICAgIGF3YWl0IHRoaXMucXVlcnkoJ1JPTExCQUNLOycpO1xuICB9XG5cbiAgc3RyZWFtaW5nUXVlcnkgKHNxbCwgb25SZXN1bHQgPSAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IChlKSA9PiB7fSkge1xuICAgIHJldHVybiB0aGlzLmdldENvbigpXG4gICAgICAudGhlbihcbiAgICAgICAgKGNvbikgPT4gbmV3IFByb21pc2UoXG4gICAgICAgICAgICBhc3luYyAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsKVxuICAgICAgICAgICAgICAgIC5vbigncmVzdWx0JyxcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcbiAgICAgICAgICAgICAgICAgICAgY29uLnBhdXNlKClcbiAgICAgICAgICAgICAgICAgICAgb25SZXN1bHQocmVjb3JkKVxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKClcbiAgICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLm9uKCdlcnJvcicsIChlKSA9PiB7XG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpXG4gICAgICAgICAgICAgICAgfSlcbiAgICAgICAgICAgICAgICAub24oJ2VuZCcsICgpID0+IHtcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcbiAgICAgICAgICAgICAgICAgIHJlc29sdmUoKVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKSxcbiAgICAgIClcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfSk7XG4gIH1cblxuICBnZXRDb24gKCkge1xuICAgIHJldHVybiBuZXcgUHJvbWlzZShcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcbiAgICAgICAgLy8g44OX44O844Or44GL44KJ44Gu44Kz44ON44Kv44K344On44Oz542y5b6XXG4gICAgICAgIHRoaXMucG9vbC5nZXRDb25uZWN0aW9uKChlLCBjb24pID0+IHtcbiAgICAgICAgICBpZiAoZSkge1xuICAgICAgICAgICAgcmVqZWN0KGUpO1xuICAgICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgICByZXNvbHZlKGNvbik7XG4gICAgICAgICAgfVxuICAgICAgICB9KTtcbiAgICAgIH0sXG4gICAgKVxuICAgICAgLmNhdGNoKFxuICAgICAgICAoZSkgPT4ge1xuICAgICAgICAgIHRocm93IGU7XG4gICAgICAgIH0sXG4gICAgICApO1xuICB9XG59XG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBQYWNrZXQge1xyXG4gIGNvbnN0cnVjdG9yIChwYWNrZXRTaXplKSB7XHJcbiAgICB0aGlzLnBhY2tldFNpemUgPSBwYWNrZXRTaXplXHJcbiAgICB0aGlzLm9uUGFja2V0U3RhcnQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldEVuZCA9IG51bGxcclxuICAgIHRoaXMuY291bnQgPSAwXHJcbiAgICB0aGlzLnBhY2tldENvdW50ID0gMFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0IChhcmcpIHtcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHliJ3mnJ/ljJbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0U3RhcnQpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLm9uUGFja2V0U3RhcnQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMub25QYWNrZXQpIHtcclxuICAgICAgYXdhaXQgdGhpcy5vblBhY2tldChhcmcpXHJcbiAgICB9XHJcbiAgICB0aGlzLmNvdW50KytcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHntYLkuoblh6bnkIbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIHRoaXMuY2xvc2UoKVxyXG4gICAgICB0aGlzLnBhY2tldENvdW50KytcclxuICAgIH1cclxuICB9XHJcbiAgY2xvc2UgKCkge1xyXG4gICAgaWYgKHRoaXMub25QYWNrZXRFbmQpIHtcclxuICAgICAgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdXRpbEVycm9yIGZyb20gJy4vZXJyb3InXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgeyBMb2dzIH0gZnJvbSAnLi4vY29sbGVjdGlvbnMnXHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVwb3J0IHtcclxuICBjb25zdHJ1Y3RvciAoKSB7XHJcbiAgICB0aGlzLnJlY29yZCA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9ycyA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgLy8gcHJpdmF0ZVxyXG4gIHNldHVwSXRlcmF0b3IgKHBoYXNlSWQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IocGhhc2VJZClcclxuICAgIHRoaXMuaXRlcmF0b3JzLnB1c2godGhpcy5pdGVyYXRvcilcclxuICB9XHJcblxyXG4gIGFzeW5jIHBoYXNlIChuYW1lID0gJycsIGZuID0gYXN5bmMgKCkgPT4ge30pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHBoYXNlSWQ6IHVuaXFpZCgpXHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKHJlYy5waGFzZUlkKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCBmbigpXHJcblxyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdzdWNjZXNzJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHJlc1xyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiB1dGlsRXJyb3IucGFyc2UoZSlcclxuICAgICAgfSlcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIC8vIOODq+ODvOODl+WHpueQhuOBruODrOODneODvOODiOOCkuS9nOaIkFxyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci5tZXRyaWMudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3IubWV0cmljXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICAvLyDjgr/jgqTjg6Djgrnjgr/jg7Pjg5dcclxuICAgICAgcmVjLnRpbWVTdGFtcCA9IG5ldyBEYXRlKClcclxuICAgICAgLy8g44Os44Od44O844OI44KS44OH44O844K/44OZ44O844K544Gr6KiY6YyyXHJcbiAgICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuXHJcbiAgICAgIC8vIOWRvOOBs+WHuuOBl+WFg+eUqOODrOODneODvOODiOOBq+i/veWKoFxyXG4gICAgICB0aGlzLnJlY29yZC5wdXNoKHJlYylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIOOCq+ODvOOCveODq+OCkuODq+ODvOODl+OBl+OAgeS4juOBiOOCieOCjOOBn+mWouaVsOOCkuWun+ihjFxyXG4gIC8vIOWRvOOBs+WHuuOBmemWouaVsOOBruW8leaVsOOBq+OBr+OCq+ODvOOCveODq+OBi+OCieW+l+OCieOCjOOBn+ODieOCreODpeODoeODs+ODiOOCkua4oeOBmVxyXG4gIGFzeW5jIGZvckVhY2hPbkN1cnNvciAoY3VyLCBmbikge1xyXG4gICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgbGV0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZm4oZG9jKVxyXG4gICAgICAgIHRoaXMuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgdGhpcy5pRXJyb3IoZSlcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgY3VyLmNsb3NlKClcclxuICB9XHJcblxyXG4gIGlTdWNjZXNzIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3Iuc3VjY2VzcyhuZXdSZWNvcmQpXHJcbiAgfVxyXG5cclxuICBpRXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5lcnJvcih1dGlsRXJyb3IucGFyc2UobmV3UmVjb3JkKSlcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICBsZXQgaXRlRXJyb3IgPSB0aGlzLml0ZXJhdG9ycy5maW5kKGUgPT4gZS5lcnJvck9jdXJyZWQoKSlcclxuICAgIGxldCBwaGFFcnJvciA9IGZhbHNlXHJcbiAgICBmb3IgKGxldCByZWMgb2YgdGhpcy5yZWNvcmQpIHtcclxuICAgICAgaWYgKHJlYy50eXBlID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgcGhhRXJyb3IgPSB0cnVlXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGl0ZUVycm9yIHx8IHBoYUVycm9yXHJcbiAgfVxyXG5cclxuICBwdWJsaXNoICgpIHtcclxuICAgIC8vIOWRvOOBs+WHuuOBl+WFg+OBuOODrOODneODvOODiFxyXG4gICAgaWYgKHRoaXMuZXJyb3JPY3VycmVkKCkpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcih0aGlzLnJlY29yZClcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnJlY29yZFxyXG4gIH1cclxufVxyXG5cclxuY2xhc3MgSXRlcmF0b3Ige1xyXG4gIGNvbnN0cnVjdG9yIChwaGFzZUlkKSB7XHJcbiAgICB0aGlzLm1ldHJpYyA9IHtcclxuICAgICAgdG90YWw6IDAsXHJcbiAgICAgIHN1Y2Nlc3M6IDAsXHJcbiAgICAgIGVycm9yOiAwLFxyXG4gICAgICBwaGFzZUlkOiBwaGFzZUlkXHJcbiAgICB9XHJcbiAgICB0aGlzLmxhc3RFcnJvciA9IG51bGxcclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLmxvZyhuZXdSZWNvcmQsIHRydWUpXHJcbiAgICB9XHJcbiAgICB0aGlzLm1ldHJpYy5zdWNjZXNzKytcclxuICAgIHRoaXMubWV0cmljLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIC8vIOebtOWJjeOBqOWQjOOBmOOCqOODqeODvOOBr+ecgeOBj1xyXG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KHRoaXMubGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMubG9nKG5ld1JlY29yZCwgZmFsc2UpXHJcbiAgICAgICAgdGhpcy5sYXN0RXJyb3IgPSBuZXdSZWNvcmRcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy5tZXRyaWMuZXJyb3IrK1xyXG4gICAgdGhpcy5tZXRyaWMudG90YWwrK1xyXG4gIH1cclxuXHJcbiAgbG9nIChuZXdSZWNvcmQsIGlzU3VjY2VzcyAvKiB0cnVlID0+IHN1Y2Nlc3Mgb3IgZmFsc2UgPT4gZXJyb3IgKi8pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IGlzU3VjY2VzcyxcclxuICAgICAgcGhhc2VJZDogdGhpcy5tZXRyaWMucGhhc2VJZCxcclxuICAgICAgbWVzc2FnZTogbmV3UmVjb3JkLFxyXG4gICAgICB0aW1lU3RhbXA6IG5ldyBEYXRlKClcclxuICAgIH1cclxuICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMuZXJyb3JcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcblxuLyoqXG4gKlxuICogQHBhcmFtIHtbT2JqZWN0XX0gc3JjXG4gKiBAcGFyYW0ge1tPYmplY3RdfSBkc3RcbiAqIEBwYXJhbSB7c3RyaW5nfSBpZGtleVxuICogQHBhcmFtIHtmdW5jdGlvbihhbnksIE9iamVjdCl9IGNyZWF0ZVxuICogQHBhcmFtIHtmdW5jdGlvbihhbnksIE9iamVjdCl9IHJlbW92ZVxuICovXG5leHBvcnQgZGVmYXVsdCBhc3luYyBmdW5jdGlvbiBzeW5jT2JqZWN0KFxuICBzcmMsIGRzdCwgaWRrZXkgPSBudWxsLCBhZGRGdW5jLCByZW1GdW5jLFxuKSB7XG4gIGNvbnN0IHNyY0NvbnRhaW5lciA9IFtdO1xuICBjb25zdCBkc3RDb250YWluZXIgPSBbXTtcblxuICBjb25zdCBpZERlbGV0ZWRDbG9uZSA9IChlbGVtLCBpZGtleUFQKSA9PiB7XG4gICAgY29uc3QgZWxlbVNhdmUgPSBfLmNsb25lRGVlcChlbGVtKTtcbiAgICAvLyBpZCDjgpLmr5TovIPlr77osaHjgYvjgonlpJbjgZlcbiAgICBpZiAoXy5pc1VuZGVmaW5lZChlbGVtU2F2ZVtpZGtleUFQXSkgPT09IGZhbHNlKSB7XG4gICAgICBkZWxldGUgZWxlbVNhdmVbaWRrZXlBUF07XG4gICAgfVxuICAgIC8vIOODh+OCo+ODvOODl+OCr+ODreODvOODs+OBl+OBn+OCquODluOCuOOCp+OCr+ODiOOCkui/lOOBmVxuICAgIHJldHVybiBlbGVtU2F2ZTtcbiAgfTtcblxuICAvLyDjgqrjg5bjgrjjgqfjgq/jg4jmr5TovIPjga7liY3mupblgplcbiAgc3JjLmZvckVhY2goKGVsZW0pID0+IHtcbiAgICBzcmNDb250YWluZXIucHVzaCh7XG4gICAgICBvYmplY3Q6IGlkRGVsZXRlZENsb25lKGVsZW0sIGlka2V5KSxcbiAgICAgIGlkOiBlbGVtW2lka2V5XSxcbiAgICAgIHN0YXRlOiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB0cnVlIOS9leOCguOBl+OBquOBhFxuICAgICAgICAgKiBmYWxzZSDmlrDopo/jgavkvZzmiJBcbiAgICAgICAgICovXG4gICAgICAgIGZpbmQ6IGZhbHNlLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfSk7XG5cbiAgZHN0LmZvckVhY2goKGVsZW0pID0+IHtcbiAgICBkc3RDb250YWluZXIucHVzaCh7XG4gICAgICBvYmplY3Q6IGlkRGVsZXRlZENsb25lKGVsZW0sIGlka2V5KSxcbiAgICAgIGlkOiBlbGVtW2lka2V5XSxcbiAgICAgIHN0YXRlOiB7XG4gICAgICAgIC8qKlxuICAgICAgICAgKiB0cnVlIOS9leOCguOBl+OBquOBhFxuICAgICAgICAgKiBmYWxzZSDliYrpmaTjgZnjgotcbiAgICAgICAgICovXG4gICAgICAgIGZpbmQ6IGZhbHNlLFxuICAgICAgfSxcbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8g44Kq44OW44K444Kn44Kv44OI44KS5q+U6LyDXG4gIHNyY0NvbnRhaW5lci5mb3JFYWNoKChzcmNFbGVtKSA9PiB7XG4gICAgZHN0Q29udGFpbmVyLmZvckVhY2goKGRzdEVsZW0pID0+IHtcbiAgICAgIGlmIChfLmlzRXF1YWwoc3JjRWxlbS5vYmplY3QsIGRzdEVsZW0ub2JqZWN0KSkge1xuICAgICAgICAvLyDlkIzjgZjjgqrjg5bjgrjjgqfjgq/jg4jjgYzopovjgaTjgYvjgaPjgZ/loLTlkIhcbiAgICAgICAgc3JjRWxlbS5zdGF0ZS5maW5kID0gdHJ1ZTtcbiAgICAgICAgZHN0RWxlbS5zdGF0ZS5maW5kID0gdHJ1ZTtcbiAgICAgIH1cbiAgICB9KTtcbiAgfSk7XG5cbiAgLy8g44OH44O844K/44Gu5oy/5YWlXG4gIGF3YWl0IFByb21pc2UuYWxsKHNyY0NvbnRhaW5lci5tYXAoYXN5bmMgKGVsZW0pID0+IHtcbiAgICBpZiAoZWxlbS5zdGF0ZS5maW5kID09PSBmYWxzZSkge1xuICAgICAgYXdhaXQgYWRkRnVuYyhlbGVtLmlkLCBlbGVtLm9iamVjdCk7XG4gICAgfVxuICB9KSk7XG5cbiAgLy8g44OH44O844K/44Gu5YmK6ZmkXG4gIGF3YWl0IFByb21pc2UuYWxsKGRzdENvbnRhaW5lci5tYXAoYXN5bmMgKGVsZW0pID0+IHtcbiAgICBpZiAoZWxlbS5zdGF0ZS5maW5kID09PSBmYWxzZSkge1xuICAgICAgYXdhaXQgcmVtRnVuYyhlbGVtLmlkLCBlbGVtLm9iamVjdCk7XG4gICAgfVxuICB9KSk7XG59XG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBUZXh0VXRpbCB7XHJcbiAgLy8gOOODk+ODg+ODiOOBp+aWh+Wtl+WIl+WIh+OCiuWPluOCi1xyXG4gIHN0YXRpYyBzdWJzdHI4ICh0ZXh0LCBsZW4sIHRydW5jYXRpb24pIHtcclxuICAgIGlmICh0cnVuY2F0aW9uID09PSB1bmRlZmluZWQpIHsgdHJ1bmNhdGlvbiA9ICcnIH1cclxuICAgIHZhciB0ZXh0QXJyYXkgPSB0ZXh0LnNwbGl0KCcnKVxyXG4gICAgdmFyIGNvdW50ID0gMFxyXG4gICAgdmFyIHN0ciA9ICcnXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRleHRBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICB2YXIgbiA9IGVzY2FwZSh0ZXh0QXJyYXlbaV0pXHJcbiAgICAgIGlmIChuLmxlbmd0aCA8IDQpIGNvdW50KytcclxuICAgICAgZWxzZSBjb3VudCArPSAyXHJcbiAgICAgIGlmIChjb3VudCA+IGxlbikge1xyXG4gICAgICAgIHJldHVybiBzdHIgKyB0cnVuY2F0aW9uXHJcbiAgICAgIH1cclxuICAgICAgc3RyICs9IHRleHQuY2hhckF0KGkpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGV4dFxyXG4gIH1cclxuXHJcbiAgLy8g5paH5a2X5YiX44Gu44OQ44Kk44OI5pWw44KS5pWw44GI44KLXHJcbiAgc3RhdGljIGxlbmIgKHRleHQpIHtcclxuICAgIHJldHVybiBlbmNvZGVVUklDb21wb25lbnQodGV4dCkucmVwbGFjZSgvJS4uJS4uJS4uL2csICd4eCcpLmxlbmd0aFxyXG4gIH1cclxuXHJcbiAgc3RhdGljIHNwbGl0bGVuYiAodGFyZ2V0LCBrZXlTLCBsZW5ndGgpIHtcclxuICAgIGNvbnN0IHNlcCA9ICcgJ1xyXG4gICAgLy8ga2V5UyDjgafmjIflrprjgZXjgozjgZ8gdGFyZ2V0IOWGheOBruimgee0oOOBruWApOOCkuOBmeOBueOBpue1kOWQiOOBl+OBn+aWh+Wtl+WIl+OCkuS9nOOCi1xyXG4gICAgY29uc3Qgc3RyRW50aXJlID0ga2V5Uy5yZWR1Y2UoKHByZXYsIGN1cnJlbnQpID0+IHByZXYgKyB0YXJnZXRbY3VycmVudF0sICcnKVxyXG4gICAgLy8g57WQ5ZCI44GX44Gf5paH5a2X5YiX44KS5Y2K6KeS44K544Oa44O844K544Gn5YiG5Ymy44GZ44KLXHJcbiAgICBjb25zdCBhcnJFbnRpcmUgPSBzdHJFbnRpcmUuc3BsaXQoc2VwKVxyXG4gICAgbGV0IGFyclJlcyA9IFtdXHJcbiAgICBsZXQgbGFzdCA9ICcnXHJcbiAgICAvLyDjg5DjgqTjg4jplbfjgYxsZW5ndGjjgpLotoXjgYjjgarjgYTpmZDjgorliY3lvozjga7liIblibLmloflrZfliJfjgpLntZDlkIjjgZfjgabjgYTjgY9cclxuICAgIC8vIOODkOOCpOODiOmVt+OBjGxlbmd0aOOCkui2heOBiOOBn+OCieOAgeOBsuOBqOOBpOOBvuOBiOOBrue1kOWQiOaWh+Wtl+WIl+OCkumFjeWIl+eZu+mMsuOBmeOCi1xyXG4gICAgdHJ5IHtcclxuICAgICAgYXJyRW50aXJlLnJlZHVjZSgocHJldiwgY3VycmVudCkgPT4ge1xyXG4gICAgICAgIC8vIGxlbmd0aCDjgpLotoXjgYjjgovjg5DjgqTjg4jplbfjga7liIblibLmloflrZfliJfjgYzjgYLjgovloLTlkIjjga/kvZXjgoLjgZfjgarjgYRcclxuICAgICAgICBpZiAoVGV4dFV0aWwubGVuYihjdXJyZW50KSA+IGxlbmd0aCkgdGhyb3cgbmV3IEVycm9yKCfmloflrZfliJfotoXpgY4nKVxyXG4gICAgICAgIGNvbnN0IGV4YW0gPSAocHJldiAhPT0gJycgPyBwcmV2ICsgc2VwIDogJycpICsgY3VycmVudFxyXG4gICAgICAgIGlmIChUZXh0VXRpbC5sZW5iKGV4YW0pID4gbGVuZ3RoKSB7XHJcbiAgICAgICAgICBhcnJSZXMucHVzaChwcmV2KVxyXG4gICAgICAgICAgbGFzdCA9IGN1cnJlbnQgLy8g5pyA5b6M44Gu5paH5a2X5YiXXHJcbiAgICAgICAgICByZXR1cm4gJydcclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgbGFzdCA9IGV4YW0gLy8g5pyA5b6M44Gu5paH5a2X5YiXXHJcbiAgICAgICAgICByZXR1cm4gZXhhbVxyXG4gICAgICAgIH1cclxuICAgICAgfSwgJycpXHJcbiAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgIC8vIGxlbmd0aCDjgpLotoXjgYjjgovjg5DjgqTjg4jplbfjga7liIblibLmloflrZfliJfjgYzjgYLjgovloLTlkIjjga/kvZXjgoLjgZfjgarjgYRcclxuICAgICAgaWYgKGUubWVzc2FnZSA9PT0gJ+aWh+Wtl+WIl+i2hemBjicpIHJldHVyblxyXG4gICAgfVxyXG5cclxuICAgIGFyclJlcy5wdXNoKGxhc3QpIC8vIOacgOW+jOOBruaWh+Wtl+WIl+OCkumFjeWIl+eZu+mMsuOBmeOCi1xyXG4gICAgLy8ga2V5UyDjgafmjIflrprjgZXjgozjgZ8gdGFyZ2V0IOWGheOBruimgee0oOOBruWApOOCkuS/ruato+OBmeOCi1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBrZXlTLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHRhcmdldFtrZXlTW2ldXSA9IGFyclJlc1tpXSA/IGFyclJlc1tpXSA6ICcnXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xyXG5cclxuZXhwb3J0IGNvbnN0IExvZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignbG9ncycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5leHBvcnQgY29uc3QgVXBsb2FkcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1cGxvYWRzJywge2lkR2VuZXJhdGlvbjogJ01PTkdPJ30pXHJcblxyXG5leHBvcnQgY29uc3QgUm9ib3RpblNob3AgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncm9ib3RpblNob3AnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuZXhwb3J0IGNvbnN0IFJvYm90aW5PcmRlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncm9ib3Rpbk9yZGVycycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5cclxuZXhwb3J0IGNvbnN0IENvbmZpZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29uZmlncycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5cclxuaWYgKE1ldGVvci5pc1NlcnZlcikge1xyXG4gIE1ldGVvci5wdWJsaXNoKCdjb25maWdzJywgKCkgPT4ge1xyXG4gICAgcmV0dXJuIENvbmZpZ3MuZmluZCgpXHJcbiAgfSk7XHJcbiAgTWV0ZW9yLm1ldGhvZHMoe1xyXG4gICAgYXN5bmMgWydyb2JvdGluT3JkZXJHcm91cHMnXSgpIHtcclxuICAgICAgY29uc3QgcmVzID0gYXdhaXQgUm9ib3Rpbk9yZGVycy5yYXdDb2xsZWN0aW9uKCkuYWdncmVnYXRlKFtcclxuICAgICAgICB7XHJcbiAgICAgICAgICAvLyDlj5fms6hJROOBlOOBqOOBq+OCsOODq+ODvOODl+WMllxyXG4gICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgIF9pZDoge1xyXG4gICAgICAgICAgICAgIOWPl+azqElEOickcm9ib3Rpbi7lj5fms6hJRCcsXHJcbiAgICAgICAgICAgICAg5Y+X5rOo5pel5pmCOickcm9ib3Rpbi7lj5fms6jml6XmmYInLFxyXG4gICAgICAgICAgICAgIOW6l+iIl+WQjTogJyRyb2JvdGluLuW6l+iIl+WQjScsXHJcbiAgICAgICAgICAgICAg5Y+X5rOo55Wq5Y+3OiAnJHJvYm90aW4u5Y+X5rOo55Wq5Y+3J1xyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBpdGVtczogeyRwdXNoOiB75ZWG5ZOB44Kz44O844OJOiAnJHJvYm90aW4u5ZWG5ZOB44Kz44O844OJJywg5pWw6YePOiAnJHJvYm90aW4u5pWw6YePJ319XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICBfaWQ6MCxcclxuICAgICAgICAgICAg5Y+X5rOoSUQ6JyRfaWQu5Y+X5rOoSUQnLFxyXG4gICAgICAgICAgICDlj5fms6jml6XmmYI6JyRfaWQu5Y+X5rOo5pel5pmCJyxcclxuICAgICAgICAgICAg5bqX6IiX5ZCNOiAnJF9pZC7lupfoiJflkI0nLFxyXG4gICAgICAgICAgICDlj5fms6jnlarlj7c6ICckX2lkLuWPl+azqOeVquWPtycsXHJcbiAgICAgICAgICAgIGl0ZW1zOiAnJGl0ZW1zJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgXSkudG9BcnJheSgpO1xyXG4gICAgICByZXR1cm4gcmVzO1xyXG4gICAgfVxyXG4gIH0pO1xyXG5cclxuICBNZXRlb3IucHVibGlzaCgncm9ib3Rpbk9yZGVySXRlbXMnLCBhc3luYyAoKT0+e1xyXG4gICAgcmV0dXJuIFJvYm90aW5PcmRlcnMuZmluZCgpO1xyXG4gIH0pO1xyXG59XHJcblxyXG5pZiAoTWV0ZW9yLmlzQ2xpZW50KSB7XHJcbiAgTWV0ZW9yLnN1YnNjcmliZSgnY29uZmlncycpXHJcbn1cclxuIl19
