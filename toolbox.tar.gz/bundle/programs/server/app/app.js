var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/route/upload/image.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

// WebApp.connectHandlers.use('/upload', (req, res, next) => {
//   res.writeHead(200);
//   res.end(`Hello world from: ${Meteor.release}`);
// });

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

// Requires multiparty

var _connectMultiparty = require('connect-multiparty');

var _connectMultiparty2 = _interopRequireDefault(_connectMultiparty);

var _importsCollections = require('../../../imports/collections');

var multipartyMiddleware = (0, _connectMultiparty2['default'])();

var route = '/upload/image';

// WebApp.connectHandlers.use('/upload', fuc.uploadFile );
WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, function (req, resp) {
  // don't forget to delete all req.files when done

  var reader = Meteor.wrapAsync(_fs2['default'].readFile);
  var writer = Meteor.wrapAsync(_fs2['default'].writeFile);
  var uploadId = (0, _uniqid2['default'])();

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = req.files.file[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var file = _step.value;

      var data = reader(file.path);
      // ファイル名の重複を避けるため、一意のファイル名を作成する
      // 楽天のファイル名文字数制限20に合わせる
      var filename = (0, _uniqid2['default'])() + '.jpg';

      // set the correct path for the file not the temporary one from the API:
      var savePath = req.body.imagedir + '/' + filename;

      // copy the data from the req.files.file.path and paste it to file.path

      // アップロード結果を記録する
      var doc = {
        uploadId: uploadId,
        clientFileName: file.name,
        uploadedFileName: filename
      };

      try {
        writer(savePath, data);
      } catch (err) {
        doc.error = err;
      }
      _importsCollections.Uploads.insert(doc);

      delete file;
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator['return']) {
        _iterator['return']();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube/cubemig.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _crypto = require('crypto');

var _crypto2 = _interopRequireDefault(_crypto);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsUtilReport = require('../../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsCollectionGroups = require('../../imports/collection/groups');

var _importsCollectionFilters = require('../../imports/collection/filters');

var tag = 'cubemig';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.migrate', function callee$0$0(config) {
  var report, filter, testQuery, dstDb;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsCollectionFilters.Filter(config.srcFilterId);
        testQuery = 'SHOW DATABASES';
        dstDb = new _importsUtilMysql2['default'](config.dst.cred);
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(report.phase('Connect to Destination', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(dstDb.query(testQuery));

              case 2:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 6:
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(report.phase('Select loop in source', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this2 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  mobileNull: function mobileNull(record) {
                    var sql, couponCd, couponName, discountPrice, _res;

                    return regeneratorRuntime.async(function mobileNull$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          sql = '\n\n                INSERT dtb_customer\n                ( `customer_id`, `status`, `sex`, `job`, `country_id`, `pref`, `name01`, `name02`, `kana01`, `kana02`, `company_name`, `zip01`, `zip02`, `zipcode`, `addr01`, `addr02`, `email`, `tel01`, `tel02`, `tel03`, `fax01`, `fax02`, `fax03`, `birth`, `password`, `salt`, `secret_key`, `first_buy_date`, `last_buy_date`, `buy_times`, `buy_total`, `note`, `create_date`, `update_date`, `del_flg` )\n\n                VALUES( ' + record.customer_id + ' , ' + record.status + ' , ' + record.sex + ' , ' + record.job + ' , ' + record.country_id + ' , ' + record.pref + ' , ' + record.name01 + ' , ' + record.name02 + ' , ' + record.kana01 + ' , ' + record.kana02 + ' , ' + record.company_name + ' , ' + record.zip01 + ' , ' + record.zip02 + ' , ' + record.zipcode + ' , ' + record.addr01 + ' , ' + record.addr02 + ' , ' + record.email + ' , ' + record.tel01 + ' , ' + record.tel02 + ' , ' + record.tel03 + ' , ' + record.fax01 + ' , ' + record.fax02 + ' , ' + record.fax03 + ' , ' + record.birth + ' , ' + record.password + ' , ' + record.salt + ' , ' + record.secret_key + ' , ' + record.first_buy_date + ' , ' + record.last_buy_date + ' , ' + record.buy_times + ' , ' + record.buy_total + ' , ' + record.note + ' , ' + record.create_date + ' , ' + record.update_date + ' , ' + record.del_flg + ' )\n                \n                ';
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer', {
                            customer_id: record.customer_id,
                            status: record.status,
                            sex: record.sex,
                            job: record.job,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            email: record.email,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            birth: record.birth,
                            password: record.password,
                            salt: record.salt,
                            secret_key: record.secret_key,
                            first_buy_date: record.first_buy_date,
                            last_buy_date: record.last_buy_date,
                            buy_times: record.buy_times,
                            buy_total: record.buy_total,
                            note: record.note,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 4:
                          context$3$0.next = 9;
                          break;

                        case 6:
                          context$3$0.prev = 6;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 9:
                          context$3$0.prev = 9;
                          context$3$0.next = 12;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer_address', {
                            customer_address_id: null,
                            customer_id: record.customer_id,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 12:
                          context$3$0.next = 17;
                          break;

                        case 14:
                          context$3$0.prev = 14;
                          context$3$0.t1 = context$3$0['catch'](9);

                          report.iError(context$3$0.t1);

                        case 17:
                          context$3$0.prev = 17;
                          context$3$0.next = 20;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_mailmaga_customer', {
                            id: null,
                            customer_id: record.customer_id,
                            mailmaga_flg: record.mailmaga_flg,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 20:
                          context$3$0.next = 25;
                          break;

                        case 22:
                          context$3$0.prev = 22;
                          context$3$0.t2 = context$3$0['catch'](17);

                          report.iError(context$3$0.t2);

                        case 25:
                          couponCd = _crypto2['default'].randomBytes(8).toString('base64').substring(0, 11);
                          couponName = record.name01 + ' ' + record.name02 + ' 様 ご優待クーポン 会員番号:' + record.customer_id;
                          discountPrice = record.point + 500;
                          context$3$0.prev = 28;
                          context$3$0.next = 31;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_coupon', {
                            coupon_id: null,
                            coupon_cd: couponCd,
                            coupon_type: 3, // 全商品
                            coupon_name: couponName,
                            discount_type: 1,
                            coupon_use_time: 1,
                            coupon_release: 1,
                            discount_price: discountPrice,
                            discount_rate: null,
                            enable_flag: 1,
                            coupon_member: 1,
                            coupon_lower_limit: null,
                            customer_id: record.customer_id,
                            available_from_date: '2018-04-02 00:00:00',
                            available_to_date: '2019-05-02 00:00:00',
                            del_flg: 0
                          }, {
                            create_date: 'NOW()',
                            update_date: 'NOW()'
                          }));

                        case 31:
                          _res = context$3$0.sent;
                          context$3$0.next = 37;
                          break;

                        case 34:
                          context$3$0.prev = 34;
                          context$3$0.t3 = context$3$0['catch'](28);

                          report.iError(context$3$0.t3);

                        case 37:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this2, [[1, 6], [9, 14], [17, 22], [28, 34]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        report.iError(e);

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this2);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 8:
        return context$1$0.abrupt('return', report.publish());

      case 9:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, 'cubemig.serverCheck', function cubemigServerCheck(profile) {
  var db, res;
  return regeneratorRuntime.async(function cubemigServerCheck$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        db = new _importsUtilMysql2['default'](profile);
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(db.query('SHOW DATABASES'));

      case 3:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// setup group
//

// let plug = group.getPlug();

// checking connection
//

// process for each members
//

// // 値を整理
// for (let key of Object.keys(record)) {
//   if (record[key] === null);
//   else if (record[key].constructor.name === 'Date') {
//     // 日付を変換
//     record[key] = MySQL.formatDate(record[key]);
//     record[key] = `"${record[key]}"`;
//   }
// }

// dtb_customer に保存

// dtb_customer_address

// メルマガプラグイン plg_mailmaga_customer

// クーポン発行（ECCUBE2のポイント還元）
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/collection.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilMongo = require('../../imports/util/mongo');

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.collection';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.find', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var projection = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.find(query, { projection: projection }).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.aggregate', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.aggregate(query).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/items.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsServiceItems = require('../../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.items';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.setImage', function callee$0$0(plug, uploadId, model) {
  var class1 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var class2 = arguments.length <= 4 || arguments[4] === undefined ? null : arguments[4];
  var itemcon, uploaded;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.setImage(uploadId, model, class1, class2));

      case 5:
        uploaded = context$1$0.sent;
        return context$1$0.abrupt('return', uploaded);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.cleanImage', function callee$0$0(plug, model) {
  var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
  var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var itemcon;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.cleanImage(model, class1, class2));

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

/**
 * 指定された条件に一致するitemsコレクション内のドキュメントに、
 * アップロード済み画像を関連付けます。
 * @param
 */

/**
 * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceCube3api = require('../imports/service/cube3api');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'cube';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('在庫の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({

                  'UPDATE': function UPDATE(item, context) {
                    var quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;
                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 5:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibItem', function callee$0$0(config) {
  var filter, targetDB, api, itemController, report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 6:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3への商品登録', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  'INSERT': function INSERT(item, context) {
                    var col, cubeItem, insertRes;
                    return regeneratorRuntime.async(function INSERT$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.creator_id, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productCreate(cubeItem));

                        case 7:
                          insertRes = context$3$0.sent;
                          context$3$0.next = 10;
                          return regeneratorRuntime.awrap(col.update({
                            _id: item._id
                          }, {
                            $set: {
                              'mall.sharakuShop.product_id': insertRes.res.product_id,
                              'mall.sharakuShop.product_class_id': insertRes.res.product_class_id,
                              'mall.sharakuShop.product_stock_id': insertRes.res.product_stock_id
                            }
                          }));

                        case 10:

                          report.iSuccess();
                          context$3$0.next = 16;
                          break;

                        case 13:
                          context$3$0.prev = 13;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 16:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3, [[1, 13]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 9:
        context$1$0.next = 11;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3商品情報の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  'UPDATE': function UPDATE(item, context) {
                    var col, cubeItem, quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.creator_id, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productImageUpdate(cubeItem));

                        case 7:
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(api.productUpdate(cubeItem));

                        case 9:
                          context$3$0.next = 11;
                          return regeneratorRuntime.awrap(api.productTagUpdate(cubeItem));

                        case 11:
                          context$3$0.next = 13;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 13:
                          quantity = context$3$0.sent;
                          context$3$0.next = 16;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 16:

                          report.iSuccess();
                          context$3$0.next = 22;
                          break;

                        case 19:
                          context$3$0.prev = 19;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 22:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this5, [[1, 19]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 11:
        return context$1$0.abrupt('return', report.publish());

      case 12:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 商品情報登録と更新

// クライアントが参照するための処理結果作成オブジェクト

// item データベースへの登録
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/robotin.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilPacket = require('../imports/util/packet');

var _importsUtilPacket2 = _interopRequireDefault(_importsUtilPacket);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var tag = 'robotinPostlabel';

var ORDER_NO_PREFIX = '受注番号：';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.addItemCode', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 送り状に商品コードを記載', function callee$1$0() {
          var workdir, orderCsv;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/postlabel';
                context$2$0.prev = 1;
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 4:
                context$2$0.next = 8;
                break;

              case 6:
                context$2$0.prev = 6;
                context$2$0.t0 = context$2$0['catch'](1);

              case 8:
                context$2$0.prev = 8;
                context$2$0.next = 11;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 11:
                context$2$0.next = 26;
                break;

              case 13:
                context$2$0.prev = 13;
                context$2$0.t1 = context$2$0['catch'](8);
                context$2$0.next = 17;
                return regeneratorRuntime.awrap(_fsExtra2['default'].readFile(workdir + '/' + config.orderCsvPrefix + '.csv'));

              case 17:
                orderCsv = context$2$0.sent;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_iconvLite2['default'].decode(orderCsv, 'SJIS'));

              case 20:
                orderCsv = context$2$0.sent;
                context$2$0.next = 23;
                return regeneratorRuntime.awrap(_iconvLite2['default'].encode(orderCsv, 'UTF-8'));

              case 23:
                orderCsv = context$2$0.sent;
                context$2$0.next = 26;
                return regeneratorRuntime.awrap(config.postages.forEach(function callee$3$0(e) {
                  var postCSV;
                  return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
                    while (1) switch (context$4$0.prev = context$4$0.next) {
                      case 0:
                        console.log('csvPrefix: ' + e.csvPrefix);
                        // await e.id.forEach(
                        //   async id => {
                        //     console.log(`${id.order}: ${recOrder[id.order]}`)
                        //   }
                        // )
                        // console.log(`${config.itemCodeColumn}: ${recOrder[config.itemCodeColumn]}`)

                        // 送り状CSVを開き、配送ごとに商品コードを記載する
                        postCSV = _fsExtra2['default'].createReadStream(workdir + '/' + e.csvPrefix + '.csv');

                        postCSV.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({
                          columns: true
                        }));

                      case 3:
                      case 'end':
                        return context$4$0.stop();
                    }
                  }, null, _this);
                }));

              case 26:
                throw new _meteorMeteor.Meteor.Error('正しい作業ディレクトリが用意されていませんでした。下記のフォルダへ受注CSV、送り状CSVをコピーしてください。\n[' + workdir + ']');

              case 27:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2, [[1, 6], [8, 13]]);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// Robot-in
// 送り状に商品コードを記載

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// workdir が準備されていたら実行する

// const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`)

// orderCsv.pipe(iconv.decodeStream('SJIS'))
//   .pipe(iconv.encodeStream('UTF-8'))
//   .pipe(csv.parse({
//     columns: true
//   }))
//   .pipe(csv.transform(
//     async (recOrder, callback) => {
//       let err = null
//       try {
// 送り状の種類ごとに繰り返す

//       } catch (e) {
//         err = e
//       }
//       callback(err, recOrder)
//     }
//   ))
// .pipe(csv.stringify({header: true}))
// .pipe(iconv.decodeStream('UTF-8'))
// .pipe(iconv.encodeStream('SJIS'))
// .pipe(w)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/tooltest.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _meteorMeteor = require('meteor/meteor');

var tag = 'tool';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.test', function callee$0$0(config) {
  var report, filter, newLocal;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        context$1$0.next = 4;
        return regeneratorRuntime.awrap(filter.foreach({}, function callee$1$0(e) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                throw e;

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 4:
        newLocal = context$1$0.sent;
        context$1$0.next = 7;
        return regeneratorRuntime.awrap(report.phase('フィルターテスト', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                return context$2$0.abrupt('return', newLocal);

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 7:
        return context$1$0.abrupt('return', report.publish());

      case 8:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// 商品情報更新

// クライアントが参照するための処理結果作成オブジェクト
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowma.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _importsServiceWowmaApi = require('../imports/service/wowmaApi');

var _importsServiceWowmaApi2 = _interopRequireDefault(_importsServiceWowmaApi);

var _importsUtilError = require('../imports/util/error');

var _importsUtilError2 = _interopRequireDefault(_importsUtilError);

var tag = 'wowma';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateItem.deliveryMethod', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品の配送方法を設定する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }]
                  }
                },
                // テスト検索条件設定
                // {
                //   $or: [
                //     {
                //       'mall.wowma.itemCode': 'gk-163'
                //     },
                //     {
                //       'mall.wowma.itemCode': '10004942' // JK-120
                //     }
                //     // {
                //     //   'mall.wowma.itemCode': '10005402'
                //     // },
                //     // {
                //     //   'mall.wowma.itemCode': '10004743'
                //     // }
                //   ]
                // }
                {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        context$3$0.t0 = Object;
                        context$3$0.t1 = item;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.convertItemWowmaCreateDeliveryMethod(item.itemCode));

                      case 4:
                        context$3$0.t2 = context$3$0.sent;
                        context$3$0.t0.assign.call(context$3$0.t0, context$3$0.t1, context$3$0.t2);
                        context$3$0.prev = 6;
                        context$3$0.next = 9;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 9:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 13:
                        context$3$0.prev = 13;
                        context$3$0.t3 = context$3$0['catch'](6);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t3));

                      case 16:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[6, 13]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.open', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品データベース上の商品を公開する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        item.saleStatus = 1;
                        item.limitedPasswd = 'NULL';
                        context$3$0.prev = 2;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 5:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 9:
                        context$3$0.prev = 9;
                        context$3$0.t0 = context$3$0['catch'](2);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 12:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[2, 9]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this5 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 在庫更新', function callee$1$0() {
          var itemController, cur, item, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, e, api, res;

          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    //   ,{
                    //     $or: [
                    //       {
                    //         'mall.wowma.itemCode': '10005402'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': 'gk-163'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': '10004743'
                    //       }
                    //     ]
                    //   }
                    ]
                  }
                }, {
                  // 配送方法の違いを省く
                  $group: {
                    _id: {
                      itemCode: '$mall.wowma.itemCode',
                      choicesStockHorizontalCode: '$mall.wowma.HChoiceName',
                      choicesStockVerticalCode: '$mall.wowma.VChoiceName'
                    },
                    item: {
                      $first: '$_id'
                    }
                  }
                }, {
                  // 商品ページごと（商品コード）にグループ化する
                  $group: {
                    _id: '$_id.itemCode',
                    variations: {
                      $push: {
                        _id: '$item',
                        choicesStockHorizontalCode: '$_id.choicesStockHorizontalCode',
                        choicesStockVerticalCode: '$_id.choicesStockVerticalCode'
                      }
                    }
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id',
                    variations: '$variations'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;

              case 6:
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(cur.hasNext());

              case 8:
                if (!context$2$0.sent) {
                  context$2$0.next = 53;
                  break;
                }

                context$2$0.next = 11;
                return regeneratorRuntime.awrap(cur.next());

              case 11:
                item = context$2$0.sent;
                _iteratorNormalCompletion = true;
                _didIteratorError = false;
                _iteratorError = undefined;
                context$2$0.prev = 15;
                _iterator = item.variations[Symbol.iterator]();

              case 17:
                if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                  context$2$0.next = 26;
                  break;
                }

                e = _step.value;
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(itemController.getStock(e._id));

              case 21:
                e.stock = context$2$0.sent;

                delete e._id;

              case 23:
                _iteratorNormalCompletion = true;
                context$2$0.next = 17;
                break;

              case 26:
                context$2$0.next = 32;
                break;

              case 28:
                context$2$0.prev = 28;
                context$2$0.t0 = context$2$0['catch'](15);
                _didIteratorError = true;
                _iteratorError = context$2$0.t0;

              case 32:
                context$2$0.prev = 32;
                context$2$0.prev = 33;

                if (!_iteratorNormalCompletion && _iterator['return']) {
                  _iterator['return']();
                }

              case 35:
                context$2$0.prev = 35;

                if (!_didIteratorError) {
                  context$2$0.next = 38;
                  break;
                }

                throw _iteratorError;

              case 38:
                return context$2$0.finish(35);

              case 39:
                return context$2$0.finish(32);

              case 40:
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.prev = 41;
                context$2$0.next = 44;
                return regeneratorRuntime.awrap(api.updateStock([item]));

              case 44:
                res = context$2$0.sent;

                report.iSuccess(res);
                context$2$0.next = 51;
                break;

              case 48:
                context$2$0.prev = 48;
                context$2$0.t1 = context$2$0['catch'](41);

                report.iError(context$2$0.t1);

              case 51:
                context$2$0.next = 6;
                break;

              case 53:
                cur.close();

              case 54:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this5, [[15, 28, 32, 40], [33,, 35, 39], [41, 48]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.searchItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this7 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, workdir, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this6 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.prev = 4;
                context$2$0.next = 7;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 7:
                context$2$0.next = 11;
                break;

              case 9:
                context$2$0.prev = 9;
                context$2$0.t0 = context$2$0['catch'](4);

              case 11:
                workdir = config.workdir + '/items_' + new Date().getTime();
                context$2$0.prev = 12;
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 15:
                context$2$0.next = 19;
                break;

              case 17:
                context$2$0.prev = 17;
                context$2$0.t1 = context$2$0['catch'](12);

              case 19:
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var options, repos, filename;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          options = JSON.parse(JSON.stringify(config.wowmaApi));

                          options.uri = options.uri + '/searchItemInfo';
                          options.qs.itemCode = item.mall.wowma.itemCode;

                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

                        case 5:
                          repos = context$3$0.sent;
                          filename = workdir + '/' + item.model + '.xml';
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(_fsExtra2['default'].writeFile(filename, repos));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this6);
                  } }));

              case 21:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this7, [[4, 9], [12, 17]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// WOWMA 商品の配送方法を設定する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品データベース上の商品を公開する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 在庫情報の作成

// let resMongo = await cur.toArray()
// return resMongo

// リクエストボディ

// 在庫を設定する

//
// 在庫更新リクエスト

//
// WOWMA 商品検索

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 作業フォルダを作成する

// APIから取得した商品情報を保存する場所

// 作業フォルダを作成する

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowmaApi.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'wowmaApi';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.getItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.WowmaApiItemFilter(config.wowmaApi, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          report.iSuccess(item);

                        case 1:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 6:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 8:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// WOWMA商品情報取得

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(config.workdir)
// } catch (e) {}

// // APIから取得した商品情報を保存する場所
// const workdir = `${config.workdir}/items_${(new Date()).getTime()}`
// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(workdir)
// } catch (e) {}

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/yauct.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilPacket = require('../imports/util/packet');

var _importsUtilPacket2 = _interopRequireDefault(_importsUtilPacket);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var prefix = 'packet';
var tag = 'yauct';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク受注', function callee$1$0() {
          var itemController, workdir, r, w;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                workdir = config.workdir + '/order';
                r = _fsExtra2['default'].createReadStream(workdir + '/' + config.orderLoadfile);
                w = _fsExtra2['default'].createWriteStream(workdir + '/' + config.orderSavefile);

                r.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(_csv2['default'].transform(function callee$2$0(record, callback) {
                  var err;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        err = null;
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.getModelClass(record['管理番号']));

                      case 4:
                        record['管理番号'] = context$3$0.sent;
                        context$3$0.next = 10;
                        break;

                      case 7:
                        context$3$0.prev = 7;
                        context$3$0.t0 = context$3$0['catch'](1);

                        err = context$3$0.t0;

                      case 10:
                        callback(err, record);

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 7]]);
                })).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(w);

              case 7:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibit', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク出品', function callee$1$0() {
          var filter, itemController, packet, workdir, uploaddir, cd, filename, name, fields, header, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                packet = new _importsUtilPacket2['default'](config.packetSize);
                context$2$0.prev = 5;
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 8:
                context$2$0.next = 12;
                break;

              case 10:
                context$2$0.prev = 10;
                context$2$0.t0 = context$2$0['catch'](5);

              case 12:
                workdir = config.workdir + '/work';
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(workdir));

              case 15:
                context$2$0.next = 17;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 17:
                uploaddir = config.workdir + '/upload';
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(uploaddir));

              case 20:
                context$2$0.next = 22;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(uploaddir));

              case 22:
                cd = null;
                filename = null;
                name = null;
                fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
                header = fields.map(function (v) {
                  return '"' + v + '"';
                }).join(',') + '\n';

                // パケット化開始時
                packet.onPacketStart = function callee$2$0(packetCount) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        name = prefix + ('00000' + packetCount).slice(-5);
                        cd = workdir + '/' + name;
                        filename = cd + '/' + config.csvFileName;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(cd));

                      case 5:
                        context$3$0.next = 7;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(header, 'Shift_JIS')));

                      case 7:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // パケット化時
                packet.onPacket = function callee$2$0(arg) {
                  var yauct, item, record, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, img, imgSrc, imgTgt;

                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        yauct = arg.yauct;
                        item = arg.item;
                        record = fields.map(function (v) {
                          return yauct[v] ? '"' + yauct[v] + '"' : '""';
                        }).join(',') + '\n';
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(record, 'Shift_JIS')));

                      case 5:
                        _iteratorNormalCompletion = true;
                        _didIteratorError = false;
                        _iteratorError = undefined;
                        context$3$0.prev = 8;
                        _iterator = item.images[Symbol.iterator]();

                      case 10:
                        if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                          context$3$0.next = 26;
                          break;
                        }

                        img = _step.value;
                        imgSrc = config.imagedir + '/' + img;
                        imgTgt = cd + '/' + img;
                        context$3$0.prev = 14;
                        context$3$0.next = 17;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].access(imgTgt));

                      case 17:
                        context$3$0.next = 23;
                        break;

                      case 19:
                        context$3$0.prev = 19;
                        context$3$0.t0 = context$3$0['catch'](14);
                        context$3$0.next = 23;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].copyFile(imgSrc, imgTgt));

                      case 23:
                        _iteratorNormalCompletion = true;
                        context$3$0.next = 10;
                        break;

                      case 26:
                        context$3$0.next = 32;
                        break;

                      case 28:
                        context$3$0.prev = 28;
                        context$3$0.t1 = context$3$0['catch'](8);
                        _didIteratorError = true;
                        _iteratorError = context$3$0.t1;

                      case 32:
                        context$3$0.prev = 32;
                        context$3$0.prev = 33;

                        if (!_iteratorNormalCompletion && _iterator['return']) {
                          _iterator['return']();
                        }

                      case 35:
                        context$3$0.prev = 35;

                        if (!_didIteratorError) {
                          context$3$0.next = 38;
                          break;
                        }

                        throw _iteratorError;

                      case 38:
                        return context$3$0.finish(35);

                      case 39:
                        return context$3$0.finish(32);

                      case 40:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[8, 28, 32, 40], [14, 19], [33,, 35, 39]]);
                };

                // パケット終了時
                packet.onPacketEnd = function callee$2$0(packetCount) {
                  var zip, zipname, output;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        zip = (0, _archiver2['default'])('zip');
                        zipname = uploaddir + '/' + name + '.zip';
                        output = _fsExtra2['default'].createWriteStream(zipname);

                        zip.pipe(output);
                        zip.directory(cd, false);
                        zip.finalize();

                      case 6:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // メインループ
                //

                context$2$0.next = 32;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var quantity, yauct;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;

                          if (!(quantity >= item.mall.yauct.minQuantity)) {
                            context$3$0.next = 9;
                            break;
                          }

                          context$3$0.next = 6;
                          return regeneratorRuntime.awrap(itemController.convertItemYauct(config['default'], item));

                        case 6:
                          yauct = context$3$0.sent;
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(packet.submit({ yauct: yauct, item: item }));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  } }));

              case 32:
                res = context$2$0.sent;

                packet.close();

                return context$2$0.abrupt('return', res);

              case 35:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[5, 10]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// ヤフオク受注ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 管理番号を置き換える

//
// ヤフオク出品ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 繰り返し処理を任意の（packetSize）で分割

// 作業フォルダを作成する

// CSVファイルを作成し画像データを収集する場所

// ZIPファイルを保存する場所
// パケットフォルダ
// csvファイル
// パケット番号

// CSVフィールドを定義し、順番を確定する

// CSVファイルにフィールドを設定する

// csvファイルにレコード（商品テンプレート）を追加する

// 画像ファイルをコピー

// 同じファイルがある場合はコピーしない

// itemに定義されている最低必要在庫より多い商品を出品する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
require('../imports/collection/configs');

require('./route/upload/image');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/configs.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _meteorMongo = require('meteor/mongo');

var Configs = new _meteorMongo.Mongo.Collection('configs', { idGeneration: 'MONGO' });

exports.Configs = Configs;
// Meteor.methods({
//   async 'mysqlServers.insert' ( newServer ){
//     return await MysqlServers.insert(newServer);
//   }
// });
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/filters.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _groups = require('./groups');

var Filters = new _meteorMongo.Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

var Filter = (function (_GroupBase) {
  _inherits(Filter, _GroupBase);

  function Filter(filterId) {
    var _this = this;

    _classCallCheck(this, Filter);

    var profile = Filters.findOne({
      _id: filterId
    });

    _get(Object.getPrototypeOf(Filter.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {

      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0() {
          var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
          var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table;
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, onError));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this);
        };
        break;

      default:
        throw new Error('invalid platform type');

    }
  }

  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */

  _createClass(Filter, [{
    key: 'foreach',
    value: function foreach() {
      var _this2 = this;

      var callbacks = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this2);
      } : arguments[1];

      var profile, count, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, filter;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this3 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              type: 'misc',
              query: {}
            });

            count = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              filter = _step.value;

              count[filter.type] = {
                query: filter.query,
                count: 0
              };
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record) {
              var _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, filter, query, exam;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion2 = true;
                    _didIteratorError2 = false;
                    _iteratorError2 = undefined;
                    context$3$0.prev = 3;
                    _iterator2 = profile.filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
                      context$3$0.next = 18;
                      break;
                    }

                    filter = _step2.value;
                    query = _mongoobject2['default'].unescape(filter.query);
                    exam = (0, _sift2['default'])(query);

                    if (!exam(record)) {
                      context$3$0.next = 15;
                      break;
                    }

                    count[filter.type].count++;

                    if (!(typeof callbacks[filter.type] !== 'undefined')) {
                      context$3$0.next = 14;
                      break;
                    }

                    context$3$0.next = 14;
                    return regeneratorRuntime.awrap(callbacks[filter.type](record));

                  case 14:
                    return context$3$0.abrupt('break', 18);

                  case 15:
                    _iteratorNormalCompletion2 = true;
                    context$3$0.next = 5;
                    break;

                  case 18:
                    context$3$0.next = 24;
                    break;

                  case 20:
                    context$3$0.prev = 20;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError2 = true;
                    _iteratorError2 = context$3$0.t0;

                  case 24:
                    context$3$0.prev = 24;
                    context$3$0.prev = 25;

                    if (!_iteratorNormalCompletion2 && _iterator2['return']) {
                      _iterator2['return']();
                    }

                  case 27:
                    context$3$0.prev = 27;

                    if (!_didIteratorError2) {
                      context$3$0.next = 30;
                      break;
                    }

                    throw _iteratorError2;

                  case 30:
                    return context$3$0.finish(27);

                  case 31:
                    return context$3$0.finish(24);

                  case 32:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this3, [[3, 20, 24, 32], [25,, 27, 31]]);
            }, onError));

          case 24:
            return context$2$0.abrupt('return', count);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21]]);
    }
  }]);

  return Filter;
})(_groups.GroupBase);

exports.Filter = Filter;

// return result of filtering
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/groups.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

var Groups = new _meteorMongo.Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

var GroupBase = (function () {
  function GroupBase(profile) {
    _classCallCheck(this, GroupBase);

    this.profile = profile;
  }

  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */

  _createClass(GroupBase, [{
    key: 'getPlug',
    value: function getPlug() {
      return this.profile.platformPlug;
    }
  }, {
    key: 'getProfile',
    value: function getProfile() {
      return this.profile;
    }
  }, {
    key: 'foreach',
    value: function foreach() {
      var _this = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
    }
  }]);

  return GroupBase;
})();

exports.GroupBase = GroupBase;

var Group = (function (_GroupBase) {
  _inherits(Group, _GroupBase);

  function Group(groupId) {
    var _this2 = this;

    _classCallCheck(this, Group);

    var profile = Groups.findOne({
      _id: groupId
    });

    _get(Object.getPrototypeOf(Group.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0(doc) {
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table + ' WHERE `' + doc.key + '` = "' + doc.id + '"';
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.query(sql));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this2);
        };
        break;
      default:
        throw new Error('invalid group type');
    }
  }

  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */

  _createClass(Group, [{
    key: 'foreach',
    value: function foreach() {
      var _this3 = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[1];

      var cur = Groups.find({
        groupId: this.profile._id
      }, {
        fields: {
          _id: 0,
          id: 1,
          key: 1
        }
      });

      return new Promise(function (resolve, reject) {

        cur.forEach(function callee$3$0(doc, index) {
          var record;
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                context$4$0.prev = 0;
                context$4$0.next = 3;
                return regeneratorRuntime.awrap(this['import'](doc));

              case 3:
                record = context$4$0.sent;
                context$4$0.next = 6;
                return regeneratorRuntime.awrap(callback(record));

              case 6:
                context$4$0.next = 11;
                break;

              case 8:
                context$4$0.prev = 8;
                context$4$0.t0 = context$4$0['catch'](0);

                onError(context$4$0.t0);

              case 11:
                if (index + 1 === cur.count()) {
                  resolve();
                }

              case 12:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this3, [[0, 8]]);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }]);

  return Group;
})(GroupBase);

exports.Group = Group;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/cube3api.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var Cube3Api = (function () {
  /**
   *
   * @param {MySQL} mysql
   */

  function Cube3Api(mysql) {
    _classCallCheck(this, Cube3Api);

    this.mysql_ = mysql;
  }

  _createClass(Cube3Api, [{
    key: 'updateStock',
    value: function updateStock(productClassId) {
      var quantity = arguments.length <= 1 || arguments[1] === undefined ? 0 : arguments[1];
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_class', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              stock_unlimited: 0,
              update_date: 'NOW()'
            }));

          case 2:
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_stock', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              update_date: 'NOW()'
            }));

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productTagUpdate',
    value: function productTagUpdate(data) {
      var creatorId, res, tagoff, tagon, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, tagSet;

      return regeneratorRuntime.async(function productTagUpdate$(context$2$0) {
        var _this = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = [];

            tagoff = function tagoff(tag) {
              var sql;
              return regeneratorRuntime.async(function tagoff$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      DELETE FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.t0 = res;
                    context$3$0.next = 4;
                    return regeneratorRuntime.awrap(this.mysql_.query(sql));

                  case 4:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 6:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            };

            tagon = function tagon(tag) {
              var sql, countRes;
              return regeneratorRuntime.async(function tagon$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      SELECT COUNT(*) FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.next = 3;
                    return regeneratorRuntime.awrap(this.mysql_.query(sql));

                  case 3:
                    countRes = context$3$0.sent;

                    if (!countRes[0]['COUNT(*)']) {
                      context$3$0.next = 6;
                      break;
                    }

                    return context$3$0.abrupt('return');

                  case 6:
                    context$3$0.t0 = res;
                    context$3$0.next = 9;
                    return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_tag', {}, {
                      product_id: data.product_id,
                      tag: tag,
                      creator_id: creatorId,
                      create_date: 'NOW()'
                    }));

                  case 9:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 11:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            };

            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 7;
            _iterator = data.tags[Symbol.iterator]();

          case 9:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 23;
              break;
            }

            tagSet = _step.value;
            context$2$0.t0 = tagSet.set;
            context$2$0.next = context$2$0.t0 === 'on' ? 14 : context$2$0.t0 === 'off' ? 17 : 20;
            break;

          case 14:
            context$2$0.next = 16;
            return regeneratorRuntime.awrap(tagon(tagSet.tag));

          case 16:
            return context$2$0.abrupt('break', 20);

          case 17:
            context$2$0.next = 19;
            return regeneratorRuntime.awrap(tagoff(tagSet.tag));

          case 19:
            return context$2$0.abrupt('break', 20);

          case 20:
            _iteratorNormalCompletion = true;
            context$2$0.next = 9;
            break;

          case 23:
            context$2$0.next = 29;
            break;

          case 25:
            context$2$0.prev = 25;
            context$2$0.t1 = context$2$0['catch'](7);
            _didIteratorError = true;
            _iteratorError = context$2$0.t1;

          case 29:
            context$2$0.prev = 29;
            context$2$0.prev = 30;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 32:
            context$2$0.prev = 32;

            if (!_didIteratorError) {
              context$2$0.next = 35;
              break;
            }

            throw _iteratorError;

          case 35:
            return context$2$0.finish(32);

          case 36:
            return context$2$0.finish(29);

          case 37:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 38:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[7, 25, 29, 37], [30,, 32, 36]]);
    }
  }, {
    key: 'productImageUpdate',
    value: function productImageUpdate(data) {
      var productId, images, creatorId, res, sql, i;
      return regeneratorRuntime.async(function productImageUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productId = data.product_id;
            images = data.images;
            creatorId = data.creator_id;
            res = [];
            sql = 'DELETE FROM dtb_product_image WHERE product_id = ' + productId;
            context$2$0.t0 = res;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(this.mysql_.query(sql));

          case 8:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t1);
            i = 0;

          case 11:
            if (!(i < images.length)) {
              context$2$0.next = 17;
              break;
            }

            context$2$0.next = 14;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_image', {
              product_id: productId,
              creator_id: creatorId,
              file_name: images[i],
              rank: i + 1
            }, {
              create_date: 'NOW()'
            }));

          case 14:
            i++;
            context$2$0.next = 11;
            break;

          case 17:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productUpdate',
    value: function productUpdate(data) {
      var updateData, keys, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, k, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, res;

      return regeneratorRuntime.async(function productUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            updateData = {};
            keys = [];

            // dtb_product

            keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 6;
            for (_iterator2 = keys[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError2) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError2;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 24:

            // dtb_product_class

            updateData = {};
            keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 29;
            for (_iterator3 = keys[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 37;
            break;

          case 33:
            context$2$0.prev = 33;
            context$2$0.t1 = context$2$0['catch'](29);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t1;

          case 37:
            context$2$0.prev = 37;
            context$2$0.prev = 38;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 40:
            context$2$0.prev = 40;

            if (!_didIteratorError3) {
              context$2$0.next = 43;
              break;
            }

            throw _iteratorError3;

          case 43:
            return context$2$0.finish(40);

          case 44:
            return context$2$0.finish(37);

          case 45:
            context$2$0.next = 47;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_class', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 47:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 49:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [29, 33, 37, 45], [38,, 40, 44]]);
    }
  }, {
    key: 'productCreate',
    value: function productCreate(data) {
      var creatorId, res, updateData, keys, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, k, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6;

      return regeneratorRuntime.async(function productCreate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = {};
            updateData = {};
            keys = [];

            keys = ['name', 'description_detail'];
            // {
            //   name: item.name,
            //   description_detail: item.description,
            // },

            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 8;
            for (_iterator4 = keys[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 16;
            break;

          case 12:
            context$2$0.prev = 12;
            context$2$0.t0 = context$2$0['catch'](8);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t0;

          case 16:
            context$2$0.prev = 16;
            context$2$0.prev = 17;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 19:
            context$2$0.prev = 19;

            if (!_didIteratorError4) {
              context$2$0.next = 22;
              break;
            }

            throw _iteratorError4;

          case 22:
            return context$2$0.finish(19);

          case 23:
            return context$2$0.finish(16);

          case 24:
            context$2$0.next = 26;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product', updateData, {
              creator_id: creatorId,
              status: 1,
              note: 'NULL',
              description_list: 'NULL',
              search_word: 'NULL',
              free_area: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 26:
            res.product_id = context$2$0.sent;

            updateData = {};
            keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee'];
            // {
            //   product_code: item.model,
            //   price01: item.retail_price,
            //   price02: item.sales_price,
            // },

            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 32;
            for (_iterator5 = keys[Symbol.iterator](); !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
              k = _step5.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 40;
            break;

          case 36:
            context$2$0.prev = 36;
            context$2$0.t1 = context$2$0['catch'](32);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t1;

          case 40:
            context$2$0.prev = 40;
            context$2$0.prev = 41;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 43:
            context$2$0.prev = 43;

            if (!_didIteratorError5) {
              context$2$0.next = 46;
              break;
            }

            throw _iteratorError5;

          case 46:
            return context$2$0.finish(43);

          case 47:
            return context$2$0.finish(40);

          case 48:
            context$2$0.next = 50;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_class', updateData, {
              creator_id: creatorId,
              product_id: res.product_id,
              stock: 0,
              stock_unlimited: 0,
              class_category_id1: 'NULL',
              class_category_id2: 'NULL',
              delivery_date_id: 'NULL',
              sale_limit: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 50:
            res.product_class_id = context$2$0.sent;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 54;

            for (_iterator6 = keys[Symbol.iterator](); !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
              k = _step6.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 62;
            break;

          case 58:
            context$2$0.prev = 58;
            context$2$0.t2 = context$2$0['catch'](54);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t2;

          case 62:
            context$2$0.prev = 62;
            context$2$0.prev = 63;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 65:
            context$2$0.prev = 65;

            if (!_didIteratorError6) {
              context$2$0.next = 68;
              break;
            }

            throw _iteratorError6;

          case 68:
            return context$2$0.finish(65);

          case 69:
            return context$2$0.finish(62);

          case 70:
            context$2$0.next = 72;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_stock', {}, {
              product_class_id: res.product_class_id,
              creator_id: creatorId,
              stock: 0,
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 72:
            res.product_stock_id = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 74:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 12, 16, 24], [17,, 19, 23], [32, 36, 40, 48], [41,, 43, 47], [54, 58, 62, 70], [63,, 65, 69]]);
    }
  }]);

  return Cube3Api;
})();

exports.Cube3Api = Cube3Api;

// 削除するタグ

// 表示するタグ

// すでに表示されているタグがあれば何もしない

// 商品に関連するすべての画像情報を削除する

// 改めて画像を登録しなおす

// for test
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/dbfilter.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _mongodb = require('mongodb');

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _xmlJs = require('xml-js');

var DBFilterFactory = function DBFilterFactory(plug, profile) {
  _classCallCheck(this, DBFilterFactory);

  var instance = undefined;
  switch (plug.type) {
    case 'mysql':
      instance = new MysqlDBFilter(plug, profile);
  }

  return instance;
};

exports.DBFilterFactory = DBFilterFactory;

var DBFilter = (function () {
  function DBFilter(plug, profile) {
    _classCallCheck(this, DBFilter);

    this.plug = plug;
    this.profile = profile;
  }

  _createClass(DBFilter, [{
    key: 'getPlug_',
    value: function getPlug_() {
      return this.plug;
    }
  }, {
    key: 'getCred_',
    value: function getCred_() {
      return this.plug.cred;
    }
  }, {
    key: 'getProfile_',
    value: function getProfile_() {
      return this.profile;
    }
  }, {
    key: 'setImportFunction_',
    value: function setImportFunction_() {
      var _this = this;

      var fn = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0() {
        var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
        var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];

      this['import'] = fn;
    }

    /**
     * traces members of the group
     * useage:
     *
     *
     * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
     * @param { async function } onError error handler while iterating
     * @returns { Object } { filterName: { query: any, count: number }, ... }
     */
  }, {
    key: 'foreach',
    value: function foreach() {
      var iterators = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      var profile, counter, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, f, filters, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile_();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              name: 'misc',
              query: {}
            });

            counter = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              f = _step.value;
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            filters = [];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 26;

            for (_iterator2 = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              f = _step2.value;

              counter[f.name] = {
                query: f.query,
                limit: typeof f.limit !== 'undefined' ? f.limit : 0,
                count: 0
              };
              filters.push({
                name: f.name,
                exam: (0, _sift2['default'])(_mongoobject2['default'].unescape(f.query))
              });
            }

            context$2$0.next = 34;
            break;

          case 30:
            context$2$0.prev = 30;
            context$2$0.t1 = context$2$0['catch'](26);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 34:
            context$2$0.prev = 34;
            context$2$0.prev = 35;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 37:
            context$2$0.prev = 37;

            if (!_didIteratorError2) {
              context$2$0.next = 40;
              break;
            }

            throw _iteratorError2;

          case 40:
            return context$2$0.finish(37);

          case 41:
            return context$2$0.finish(34);

          case 42:
            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record, context) {
              var _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, f, c;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion3 = true;
                    _didIteratorError3 = false;
                    _iteratorError3 = undefined;
                    context$3$0.prev = 3;
                    _iterator3 = filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
                      context$3$0.next = 20;
                      break;
                    }

                    f = _step3.value;
                    c = counter[f.name];

                    if (!c.limit) {
                      context$3$0.next = 11;
                      break;
                    }

                    if (!(c.count >= c.limit)) {
                      context$3$0.next = 11;
                      break;
                    }

                    return context$3$0.abrupt('continue', 17);

                  case 11:
                    if (!f.exam(record)) {
                      context$3$0.next = 17;
                      break;
                    }

                    // counter limiter
                    c.count++;

                    // iterator

                    if (!(typeof iterators[f.name] !== 'undefined')) {
                      context$3$0.next = 16;
                      break;
                    }

                    context$3$0.next = 16;
                    return regeneratorRuntime.awrap(iterators[f.name](record, context));

                  case 16:
                    return context$3$0.abrupt('break', 20);

                  case 17:
                    _iteratorNormalCompletion3 = true;
                    context$3$0.next = 5;
                    break;

                  case 20:
                    context$3$0.next = 26;
                    break;

                  case 22:
                    context$3$0.prev = 22;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError3 = true;
                    _iteratorError3 = context$3$0.t0;

                  case 26:
                    context$3$0.prev = 26;
                    context$3$0.prev = 27;

                    if (!_iteratorNormalCompletion3 && _iterator3['return']) {
                      _iterator3['return']();
                    }

                  case 29:
                    context$3$0.prev = 29;

                    if (!_didIteratorError3) {
                      context$3$0.next = 32;
                      break;
                    }

                    throw _iteratorError3;

                  case 32:
                    return context$3$0.finish(29);

                  case 33:
                    return context$3$0.finish(26);

                  case 34:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2, [[3, 22, 26, 34], [27,, 29, 33]]);
            }));

          case 44:
            return context$2$0.abrupt('return', counter);

          case 45:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [26, 30, 34, 42], [35,, 37, 41]]);
    }
  }], [{
    key: 'factory',
    value: function factory(plug, profile) {
      switch (plug.type) {
        case 'mysql':
          return new MysqlDBFilter(plug, profile);
        default:
          throw new Error('invalid plug type');
      }
    }
  }]);

  return DBFilter;
})();

exports.DBFilter = DBFilter;

var MysqlDBFilter = (function (_DBFilter) {
  _inherits(MysqlDBFilter, _DBFilter);

  function MysqlDBFilter(plug, profile) {
    var _this3 = this;

    _classCallCheck(this, MysqlDBFilter);

    _get(Object.getPrototypeOf(MysqlDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    var cred = this.getCred_();

    this.mysql = new _utilMysql2['default'](cred);
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var sql, res;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            sql = 'SELECT * FROM ' + plug.table;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, function (e) {
              throw e;
            }));

          case 3:
            res = context$3$0.sent;
            return context$3$0.abrupt('return', res);

          case 5:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this3);
    });
  }

  // import MongoNative from 'mongodb';
  // const MongoClient = MongoNative.MongoClient;
  // const MongoClient = require('mongodb').MongoClient;

  return MysqlDBFilter;
})(DBFilter);

exports.MysqlDBFilter = MysqlDBFilter;

var MongoDBFilter = (function (_DBFilter2) {
  _inherits(MongoDBFilter, _DBFilter2);

  function MongoDBFilter(plug, profile) {
    var _this4 = this;

    _classCallCheck(this, MongoDBFilter);

    _get(Object.getPrototypeOf(MongoDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    // mongo へ接続
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var client, db, collection, context, cur, doc;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            client = undefined;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri));

          case 3:
            client = context$3$0.sent;
            db = client.db(plug.database);
            collection = db.collection(plug.collection);
            context = {
              client: client,
              collection: collection,
              database: db
            };
            cur = collection.find();

            // カーソルのタイムアウトを解除
            cur.addCursorFlag('noCursorTimeout', true);

            // すべてのドキュメントをループ
            context$3$0.prev = 9;

          case 10:
            context$3$0.next = 12;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 12:
            if (!context$3$0.sent) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 15;
            return regeneratorRuntime.awrap(cur.next());

          case 15:
            doc = context$3$0.sent;
            context$3$0.next = 18;
            return regeneratorRuntime.awrap(onResult(doc, context));

          case 18:
            context$3$0.next = 10;
            break;

          case 20:
            ;

          case 21:
            context$3$0.prev = 21;
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(cur.close());

          case 24:
            return context$3$0.finish(21);

          case 25:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this4, [[9,, 21, 25]]);
    });
  }

  return MongoDBFilter;
})(DBFilter);

exports.MongoDBFilter = MongoDBFilter;

var WowmaApiItemFilter = (function (_DBFilter3) {
  _inherits(WowmaApiItemFilter, _DBFilter3);

  function WowmaApiItemFilter(plug, profile) {
    var _this5 = this;

    _classCallCheck(this, WowmaApiItemFilter);

    _get(Object.getPrototypeOf(WowmaApiItemFilter.prototype), 'constructor', this).call(this, plug, profile);

    // 商品情報の取得ループを定義
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var options, context, res, maxCount, resultCount, startCount, resultStocks, i, next;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            options = JSON.parse(JSON.stringify(plug));

            options.uri = options.uri + '/searchStocks';
            context = {
              options: options
            };

          case 3:
            if (!1) {
              context$3$0.next = 30;
              break;
            }

            context$3$0.next = 6;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

          case 6:
            res = context$3$0.sent;

            res = (0, _xmlJs.xml2js)(res, { compact: true });

            maxCount = Number(res.response.searchResult.maxCount._text);
            resultCount = Number(res.response.searchResult.resultCount._text);
            startCount = Number(res.response.searchResult.startCount._text);
            resultStocks = res.response.searchResult.resultStocks;

            if (!(resultStocks instanceof Array)) {
              context$3$0.next = 22;
              break;
            }

            i = 0;

          case 14:
            if (!(i < resultCount)) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 17;
            return regeneratorRuntime.awrap(onResult(resultStocks[i], context));

          case 17:
            i++;
            context$3$0.next = 14;
            break;

          case 20:
            context$3$0.next = 24;
            break;

          case 22:
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(onResult(resultStocks, context));

          case 24:
            next = startCount + resultCount;

            if (!(next > maxCount)) {
              context$3$0.next = 27;
              break;
            }

            return context$3$0.abrupt('break', 30);

          case 27:
            options.qs.startCount = next;
            context$3$0.next = 3;
            break;

          case 30:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this5);
    });
  }

  // import mongoose from 'mongoose';

  // export class MongoDBFilter extends DBFilter {
  //   constructor(plug, profile) {
  //     super(plug, profile);

  //     // mongo へ接続
  //     let cred = this.getCred_();
  //     let conuri = `mongodb://${cred.host}:${cred.port}/${cred.database}`;
  //     await mongoose.connect(conuri);

  //     // コレクションを作る
  //     let collection = mongoose.connection.collection(plug.collection);

  //     this.setImportFunction_(async (onResult, onError) => {
  //       let cur = collection.find();

  //       return await this.mysql.streamingQuery(sql, onResult, onError);
  //     });
  //   }
  // }
  return WowmaApiItemFilter;
})(DBFilter);

exports.WowmaApiItemFilter = WowmaApiItemFilter;

// counter limiter

// return result of filtering

// コレクションを取得

// カーソルを開放

// コレクションを取得

// Wowma Api から商品情報を取得

// 取得した商品情報をカスタムプロセスに渡す

// 取得したデータが複数商品の場合

// 取得したデータが単数商品の場合
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/items.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMongo = require('../util/mongo');

var _collections = require('../collections');

var _bson = require('bson');

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var ItemController = (function () {
  function ItemController() {
    _classCallCheck(this, ItemController);
  }

  _createClass(ItemController, [{
    key: 'init',
    value: function init(plug) {
      return regeneratorRuntime.async(function init$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'items'));

          case 2:
            this.Items = context$2$0.sent;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'products'));

          case 5:
            this.Products = context$2$0.sent;

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'getStock',
    value: function getStock(itemId) {
      var item, productSet, quantities, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, productRef, prdQuantity, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, id, product, stockArray, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, stock, quantity;

      return regeneratorRuntime.async(function getStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.Items.findOne({
              _id: itemId
            }, {
              projection: {
                'product': 1
              }
            }));

          case 2:
            item = context$2$0.sent;
            productSet = item.product;
            quantities = [];
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 8;
            _iterator = productSet[Symbol.iterator]();

          case 10:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 64;
              break;
            }

            productRef = _step.value;
            prdQuantity = 0;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 16;
            _iterator2 = productRef.ids[Symbol.iterator]();

          case 18:
            if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
              context$2$0.next = 46;
              break;
            }

            id = _step2.value;
            context$2$0.next = 22;
            return regeneratorRuntime.awrap(this.Products.findOne({
              _id: id
            }, {
              projection: {
                'stock': 1
              }
            }));

          case 22:
            product = context$2$0.sent;
            stockArray = product.stock;
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 27;

            // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算
            for (_iterator3 = stockArray[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              stock = _step3.value;

              prdQuantity += stock.quantity;
            }
            context$2$0.next = 35;
            break;

          case 31:
            context$2$0.prev = 31;
            context$2$0.t0 = context$2$0['catch'](27);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 35:
            context$2$0.prev = 35;
            context$2$0.prev = 36;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 38:
            context$2$0.prev = 38;

            if (!_didIteratorError3) {
              context$2$0.next = 41;
              break;
            }

            throw _iteratorError3;

          case 41:
            return context$2$0.finish(38);

          case 42:
            return context$2$0.finish(35);

          case 43:
            _iteratorNormalCompletion2 = true;
            context$2$0.next = 18;
            break;

          case 46:
            context$2$0.next = 52;
            break;

          case 48:
            context$2$0.prev = 48;
            context$2$0.t1 = context$2$0['catch'](16);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 52:
            context$2$0.prev = 52;
            context$2$0.prev = 53;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 55:
            context$2$0.prev = 55;

            if (!_didIteratorError2) {
              context$2$0.next = 58;
              break;
            }

            throw _iteratorError2;

          case 58:
            return context$2$0.finish(55);

          case 59:
            return context$2$0.finish(52);

          case 60:

            // 商品(item)の在庫数 = 製品在庫数(prdQuantity) / 必要セット数(productRef.set)
            quantities.push(Math.floor(prdQuantity / productRef.set));

          case 61:
            _iteratorNormalCompletion = true;
            context$2$0.next = 10;
            break;

          case 64:
            context$2$0.next = 70;
            break;

          case 66:
            context$2$0.prev = 66;
            context$2$0.t2 = context$2$0['catch'](8);
            _didIteratorError = true;
            _iteratorError = context$2$0.t2;

          case 70:
            context$2$0.prev = 70;
            context$2$0.prev = 71;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 73:
            context$2$0.prev = 73;

            if (!_didIteratorError) {
              context$2$0.next = 76;
              break;
            }

            throw _iteratorError;

          case 76:
            return context$2$0.finish(73);

          case 77:
            return context$2$0.finish(70);

          case 78:
            quantity = Math.min.apply(null, quantities);
            return context$2$0.abrupt('return', quantity);

          case 80:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 66, 70, 78], [16, 48, 52, 60], [27, 31, 35, 43], [36,, 38, 42], [53,, 55, 59], [71,, 73, 77]]);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに、
     * アップロード済み画像を関連付ける。
     *
     * メーカーモデルに共通の画像を一括で関連付けたい場合、
     * class1、class2引数を指定せずに実行する。
     *
     * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
     * class1に値を指定し、class2引数を指定せずに実行する。
     * もしclass2のみ指定したい場合はclass1にnullを指定する。
     *
     * 例：JK-100のBLACKの商品画像を
     * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
     * setImage( uploadId, 'JK-100', 'BLACK' );
     *
     * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'setImage',
    value: function setImage(uploadId, model) {
      var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
      var images, filter, res;
      return regeneratorRuntime.async(function setImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            images = _collections.Uploads.find({
              uploadId: uploadId
            }).fetch().map(function (v) {
              return v.uploadedFileName;
            });
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $push: {
                images: {
                  $each: images
                }
              }
            }));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', images);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
     *
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'cleanImage',
    value: function cleanImage(model) {
      var class1 = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
      var class2 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var filter, res;
      return regeneratorRuntime.async(function cleanImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $set: {
                images: []
              }
            }));

          case 6:
            res = context$2$0.sent;

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * 指定の商品に関連する商品群の属性別の商品情報を返す。
     *
     * 引数として受け取るitemは任意の商品情報。
     * itemに関連する商品群について必要な情報を整理し返す。
     *
     * projectに参照したい商品情報フィールドを定義する。
     * メソッドの呼び出し時に必要に応じてprojectを設定する。
     *
     * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
     *
     * @param {Object} item
     * @param {Object} project
     */
  }, {
    key: 'getVariation',
    value: function getVariation(item, project) {
      var set, attrs, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, s, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, attr, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6, v;

      return regeneratorRuntime.async(function getVariation$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            set = [{
              label: '配送方法',
              current: item.delivery,
              project: {
                value: '$delivery'
              },
              query: {
                class1_value: item.class1_value,
                class2_value: item.class2_value
              }
            }, {
              label: item.class1_name,
              current: item.class1_value,
              project: {
                value: '$class1_value'
              },
              query: {
                delivery: item.delivery,
                class2_value: item.class2_value
              }
            }, {
              label: item.class2_name,
              current: item.class2_value,
              project: {
                value: '$class2_value'
              },
              query: {
                delivery: item.delivery,
                class1_value: item.class1_value
              }
            }];
            attrs = [];
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 5;
            _iterator4 = set[Symbol.iterator]();

          case 7:
            if (_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done) {
              context$2$0.next = 19;
              break;
            }

            s = _step4.value;
            context$2$0.t0 = attrs;
            context$2$0.next = 12;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: Object.assign(s.query, {
                model: item.model
              })
            }, {
              $project: Object.assign(s.project, project)
            }, {
              $sort: {
                _id: 1
              }
            }]).toArray());

          case 12:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = s;
            context$2$0.t3 = {
              variations: context$2$0.t1,
              props: context$2$0.t2
            };
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t3);

          case 16:
            _iteratorNormalCompletion4 = true;
            context$2$0.next = 7;
            break;

          case 19:
            context$2$0.next = 25;
            break;

          case 21:
            context$2$0.prev = 21;
            context$2$0.t4 = context$2$0['catch'](5);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t4;

          case 25:
            context$2$0.prev = 25;
            context$2$0.prev = 26;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 28:
            context$2$0.prev = 28;

            if (!_didIteratorError4) {
              context$2$0.next = 31;
              break;
            }

            throw _iteratorError4;

          case 31:
            return context$2$0.finish(28);

          case 32:
            return context$2$0.finish(25);

          case 33:
            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 36;
            _iterator5 = attrs[Symbol.iterator]();

          case 38:
            if (_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done) {
              context$2$0.next = 70;
              break;
            }

            attr = _step5.value;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 43;
            _iterator6 = attr.variations[Symbol.iterator]();

          case 45:
            if (_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done) {
              context$2$0.next = 53;
              break;
            }

            v = _step6.value;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.getStock(v._id));

          case 49:
            v.stock = context$2$0.sent;

          case 50:
            _iteratorNormalCompletion6 = true;
            context$2$0.next = 45;
            break;

          case 53:
            context$2$0.next = 59;
            break;

          case 55:
            context$2$0.prev = 55;
            context$2$0.t5 = context$2$0['catch'](43);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t5;

          case 59:
            context$2$0.prev = 59;
            context$2$0.prev = 60;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 62:
            context$2$0.prev = 62;

            if (!_didIteratorError6) {
              context$2$0.next = 65;
              break;
            }

            throw _iteratorError6;

          case 65:
            return context$2$0.finish(62);

          case 66:
            return context$2$0.finish(59);

          case 67:
            _iteratorNormalCompletion5 = true;
            context$2$0.next = 38;
            break;

          case 70:
            context$2$0.next = 76;
            break;

          case 72:
            context$2$0.prev = 72;
            context$2$0.t6 = context$2$0['catch'](36);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t6;

          case 76:
            context$2$0.prev = 76;
            context$2$0.prev = 77;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 79:
            context$2$0.prev = 79;

            if (!_didIteratorError5) {
              context$2$0.next = 82;
              break;
            }

            throw _iteratorError5;

          case 82:
            return context$2$0.finish(79);

          case 83:
            return context$2$0.finish(76);

          case 84:
            return context$2$0.abrupt('return', attrs);

          case 85:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 21, 25, 33], [26,, 28, 32], [36, 72, 76, 84], [43, 55, 59, 67], [60,, 62, 66], [77,, 79, 83]]);
    }

    // モデルクラス形式を作る
    // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
  }, {
    key: 'getModelClass',
    value: function getModelClass(arg) {
      var item, exp, cur, match, modelClass;
      return regeneratorRuntime.async(function getModelClass$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            item = undefined;

            if (!(typeof arg === 'string')) {
              context$2$0.next = 25;
              break;
            }

            exp = new RegExp(arg + '$');
            cur = this.Items.find({}, {
              projection: {
                model: 1,
                class1_value: 1,
                class2_value: 1
              }
            });

          case 4:
            if (!1) {
              context$2$0.next = 22;
              break;
            }

            context$2$0.prev = 5;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(cur.next());

          case 8:
            item = context$2$0.sent;
            context$2$0.next = 11;
            return regeneratorRuntime.awrap(item._id.toHexString().match(exp));

          case 11:
            match = context$2$0.sent;

            if (!match) {
              context$2$0.next = 14;
              break;
            }

            return context$2$0.abrupt('break', 22);

          case 14:
            context$2$0.next = 20;
            break;

          case 16:
            context$2$0.prev = 16;
            context$2$0.t0 = context$2$0['catch'](5);

            // 該当するitemデータがない
            cur.close();
            return context$2$0.abrupt('return', arg);

          case 20:
            context$2$0.next = 4;
            break;

          case 22:
            cur.close();
            context$2$0.next = 26;
            break;

          case 25:
            item = arg;

          case 26:
            modelClass = [];

            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);
            return context$2$0.abrupt('return', modelClass.join('/'));

          case 31:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 16]]);
    }
  }, {
    key: 'convertItemCube3',
    value: function convertItemCube3(creatorId, item) {
      var convDeliv, productId, modelClass, productTypeId, tags, deliveryFee, attrs, variationHtml, descriptionDetail, data;
      return regeneratorRuntime.async(function convertItemCube3$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            convDeliv = function convDeliv(delivery) {
              return delivery === 'ゆうパケット' ? 'ポスト投函' : delivery;
            };

            productId = null;
            modelClass = [];

            // 下記の形式を作る
            // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);

            // 商品種別を割り当てる
            productTypeId = undefined;
            context$2$0.t0 = item.delivery;
            context$2$0.next = context$2$0.t0 === '宅配便' ? 10 : context$2$0.t0 === 'ゆうパケット' ? 12 : 14;
            break;

          case 10:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 12:
            productTypeId = 2;
            return context$2$0.abrupt('break', 16);

          case 14:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 16:
            tags = [];
            context$2$0.t1 = item.delivery;
            context$2$0.next = context$2$0.t1 === '宅配便' ? 20 : context$2$0.t1 === 'ゆうパケット' ? 22 : 24;
            break;

          case 20:
            tags.push({
              tag: 4,
              set: 'on'
            }, {
              tag: 5,
              set: 'off'
            });
            return context$2$0.abrupt('break', 24);

          case 22:
            tags.push({
              tag: 5,
              set: 'on'
            }, {
              tag: 4,
              set: 'off'
            });
            return context$2$0.abrupt('break', 24);

          case 24:
            deliveryFee = null;
            context$2$0.t2 = item.delivery;
            context$2$0.next = context$2$0.t2 === '宅配便' ? 28 : context$2$0.t2 === 'ゆうパケット' ? 30 : 32;
            break;

          case 28:
            deliveryFee = null;
            return context$2$0.abrupt('break', 32);

          case 30:
            deliveryFee = 240;
            return context$2$0.abrupt('break', 32);

          case 32:
            context$2$0.next = 34;
            return regeneratorRuntime.awrap(this.getVariation(item, {
              product_id: '$mall.sharakuShop.product_id'
            }));

          case 34:
            attrs = context$2$0.sent;

            // HTML バリエーション商品ごとのリンク付きボタンを表示する

            // 値の変換
            attrs = attrs.map(function (attr) {
              attr.props.current = convDeliv(attr.props.current);
              attr.variations = attr.variations.map(function (variation) {
                variation.value = convDeliv(variation.value);
                return variation;
              });
              return attr;
            });

            // HTML生成
            variationHtml = attrs.map(function (attr) {
              return '<div class="container-fluid">' + '<div class="row">' + '<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">' + ('<strong>' + attr.props.label + '</strong>') + '</div>' + attr.variations.map(function (variation) {
                if (attr.props.current === variation.value) {
                  // 表示中の商品ボタン
                  return '<button class="btn btn-success btn-sm btn-item-class-select"><strong>' + variation.value + '</strong></button>';
                } else if (variation.stock > 0) {
                  // 販売可能商品のボタン
                  return '<a href="/products/detail/' + variation.product_id + '"><button class="btn btn-default btn-sm btn-item-class-select">' + variation.value + '</button></a>';
                } else {
                  // 販売不可能商品のボタン（在庫なし）
                  return '<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">' + variation.value + '</button>';
                }
              }).join('') + '</div>' + '</div>';
            }).join('');
            descriptionDetail = '\n    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>\n    ' + variationHtml + '\n    ';
            data = {
              product_id: productId,
              creator_id: creatorId,
              name: modelClass.join('/') + ' ' + convDeliv(item.delivery) + ' ' + item.name + (item.jan_code ? ' ' + item.jan_code : ''),
              description_detail: descriptionDetail,
              // free_area: await this.convertItemCube3createFreeArea(item),
              product_code: modelClass.join('/'),
              price01: item.retail_price,
              // price02: await this.convertItemCube3createPrice02(item),
              // images: await this.convertItemCube3createImages(item),
              product_type_id: productTypeId,
              tags: tags,
              delivery_fee: deliveryFee
            };
            context$2$0.t3 = Object;
            context$2$0.t4 = data;
            context$2$0.next = 43;
            return regeneratorRuntime.awrap(this.convertItemCube3createFreeArea(item));

          case 43:
            context$2$0.t5 = context$2$0.sent;
            context$2$0.t3.assign.call(context$2$0.t3, context$2$0.t4, context$2$0.t5);
            context$2$0.t6 = Object;
            context$2$0.t7 = data;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.convertItemCube3createPrice02(item));

          case 49:
            context$2$0.t8 = context$2$0.sent;
            context$2$0.t6.assign.call(context$2$0.t6, context$2$0.t7, context$2$0.t8);
            context$2$0.t9 = Object;
            context$2$0.t10 = data;
            context$2$0.next = 55;
            return regeneratorRuntime.awrap(this.convertItemCube3createImages(item));

          case 55:
            context$2$0.t11 = context$2$0.sent;
            context$2$0.t9.assign.call(context$2$0.t9, context$2$0.t10, context$2$0.t11);

            Object.assign(data, item.mall.sharakuShop);

            return context$2$0.abrupt('return', data);

          case 59:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createFreeArea',
    value: function convertItemCube3createFreeArea(item) {
      var freeArea, i;
      return regeneratorRuntime.async(function convertItemCube3createFreeArea$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            freeArea = '';

            // 商品情報テキストを記載する
            freeArea += item.description;
            // 2番目以降の画像をフリーエリアに記載する
            for (i = 1; i < item.images.length; i++) {
              freeArea += '<img src="/upload/save_image/' + item.images[i] + '"><br>';
            }
            // 情報のクリア
            freeArea += ' ';
            return context$2$0.abrupt('return', { free_area: freeArea });

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createPrice02',
    value: function convertItemCube3createPrice02(item) {
      return regeneratorRuntime.async(function convertItemCube3createPrice02$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            return context$2$0.abrupt('return', { price02: item.mall.sharakuShop.price });

          case 1:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createImages',
    value: function convertItemCube3createImages(item) {
      var arr;
      return regeneratorRuntime.async(function convertItemCube3createImages$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            arr = typeof item.images[0] === 'undefined' ? [] : [item.images[0]];
            return context$2$0.abrupt('return', { images: arr });

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct',
    value: function convertItemYauct(def, item) {
      var idLength, titleLength, yauct, imgPrefix, i;
      return regeneratorRuntime.async(function convertItemYauct$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            idLength = 20;
            titleLength = 130;
            yauct = {};

            // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）
            yauct = JSON.parse(JSON.stringify(def[item.delivery]));

            // 画像の記述
            imgPrefix = '画像';

            for (i = 0; i < item.images.length; i++) {
              yauct[imgPrefix + (i + 1)] = item.images[i];
            }

            // タイトル
            yauct['カテゴリ'] = item.mall.yauct.category;
            context$2$0.t0 = _utilText2['default'];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap(this.getModelClass(item));

          case 10:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = context$2$0.t1 + ' ';
            context$2$0.t3 = item.delivery;
            context$2$0.t4 = context$2$0.t2 + context$2$0.t3;
            context$2$0.t5 = context$2$0.t4 + ' ';
            context$2$0.t6 = item.name;
            context$2$0.t7 = context$2$0.t5 + context$2$0.t6;
            context$2$0.t8 = titleLength;
            yauct['タイトル'] = context$2$0.t0.substr8.call(context$2$0.t0, context$2$0.t7, context$2$0.t8);

            yauct['開始価格'] = item.sales_price;
            yauct['即決価格'] = item.sales_price;
            yauct['管理番号'] = item._id.toHexString().slice(-idLength);
            yauct['説明'] = item.description;
            yauct['JANコード・ISBNコード'] = item.jan_code;

            return context$2$0.abrupt('return', yauct);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemWowmaCreateDeliveryMethod',
    value: function convertItemWowmaCreateDeliveryMethod(itemCode) {
      var id, set, metrics, aggr, acceptDeliv, _iteratorNormalCompletion7, _didIteratorError7, _iteratorError7, _iterator7, _step7, del, deliveryMethod, i, _id;

      return regeneratorRuntime.async(function convertItemWowmaCreateDeliveryMethod$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            id = 'mall.wowma.itemCode';
            set = 'delivery';
            metrics = {
              'ゆうパケット': ['Post'],
              '宅配便': ['YU-Pack', 'Kangaroo']
            };
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: _defineProperty({}, id, itemCode)
            }, {
              $group: _defineProperty({
                _id: '$' + id
              }, set, { $addToSet: '$' + set })
            }, {
              $project: _defineProperty({
                _id: 0,
                itemCode: '$_id'
              }, set, '$' + set)
            }]).toArray());

          case 5:
            aggr = context$2$0.sent;
            acceptDeliv = [];
            _iteratorNormalCompletion7 = true;
            _didIteratorError7 = false;
            _iteratorError7 = undefined;
            context$2$0.prev = 10;

            for (_iterator7 = aggr[0].delivery[Symbol.iterator](); !(_iteratorNormalCompletion7 = (_step7 = _iterator7.next()).done); _iteratorNormalCompletion7 = true) {
              del = _step7.value;

              acceptDeliv = acceptDeliv.concat(metrics['' + del]);
            }
            context$2$0.next = 18;
            break;

          case 14:
            context$2$0.prev = 14;
            context$2$0.t0 = context$2$0['catch'](10);
            _didIteratorError7 = true;
            _iteratorError7 = context$2$0.t0;

          case 18:
            context$2$0.prev = 18;
            context$2$0.prev = 19;

            if (!_iteratorNormalCompletion7 && _iterator7['return']) {
              _iterator7['return']();
            }

          case 21:
            context$2$0.prev = 21;

            if (!_didIteratorError7) {
              context$2$0.next = 24;
              break;
            }

            throw _iteratorError7;

          case 24:
            return context$2$0.finish(21);

          case 25:
            return context$2$0.finish(18);

          case 26:
            deliveryMethod = new Array(5);

            for (i = 0; i < deliveryMethod.length; i++) {
              _id = typeof acceptDeliv[i] === 'undefined' ? 'NULL' : acceptDeliv[i];

              deliveryMethod[i] = { deliveryMethodSeq: i + 1, deliveryMethodId: _id };
            }

            return context$2$0.abrupt('return', { deliveryMethod: deliveryMethod });

          case 29:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[10, 14, 18, 26], [19,, 21, 25]]);
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る

  }], [{
    key: 'convertItemRobotin',
    value: function convertItemRobotin(item) {
      var robotinItem, shopS;
      return regeneratorRuntime.async(function convertItemRobotin$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            robotinItem = {
              item: {
                'コントロールカラム': 'n',
                '新規登録ID': item._id.toHexString(),
                '商品ID': null,
                '商品名': item.name,
                '規格': 'なし'
              },
              select: {
                'コントロールカラム': 'n',
                '新規登録ID': item._id.toHexString(),
                '商品ID': null,
                '外部連携ID': null,
                '外部連携商品番号': item.model + '/' + item.class1_name + '/' + item.class2_name
              },
              shopS: []
            };
            shopS = _collections.RobotinShop.find().fetch();

            shopS.forEach(function (shop) {
              var model = item.mall['' + shop.name]['' + shop.modelPath];
              var class1 = item.mall['' + shop.name]['' + shop.class1Path];
              var class2 = item.mall['' + shop.name]['' + shop.class2Path];

              robotinItem.shopS.push({
                '受注商品ID': null,
                '店舗ID': shop['店舗ID'],
                '店舗名': null,
                '受注商品番号': model + '/' + class1 + '/' + class2,
                '有効フラグ': '有効'
              });
            });

            return context$2$0.abrupt('return', robotinItem);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }]);

  return ItemController;
})();

exports['default'] = ItemController;
module.exports = exports['default'];

// product * <-> * item
// product[]: 複数の商品を1パッケージとして販売
// product[{ids:[<ObjectId>],set:<Number>}]: 異なる流通経路、異なる原価・仕入れ値
// item: 異なるセール、販売形態
// ※ product からは、販売可能な在庫、利益計算のための情報を得る

// セット商品の場合、一番少ない商品数に合わせる

// アップロード済み画像の情報取得

// 検索条件の組み立て

// 登録した画像ファイル名一覧

// 検索条件の組み立て

/**
 * aggregation設定
 *
 * label: 属性名（配送方法、カラー、サイズなど）
 * current: 指定されたアイテム（item）が該当する項目
 * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
 * query: aggregation対象とするドキュメントの検索条件
 */

// item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

// 値変換

// product_id

// 商品タグを設定する

// 商品別送料を設定する

//
// 顧客向けバリエーション商品選択機能の実装
//

// 商品データを作る

// 価格を返す

// 画像リストのうち1つめだけを返す

// deliveryMethodSeq
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/wowmaApi.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _xmlJs = require('xml-js');

var _utilError = require('../util/error');

var _utilError2 = _interopRequireDefault(_utilError);

var BASE_URI = 'https://api.manager.wowma.jp/wmshopapi';

var WowmaApi = (function () {
  function WowmaApi(plug, shopId) {
    _classCallCheck(this, WowmaApi);

    this.plug = plug;
    this.shopId = shopId;
  }

  // 商品情報更新

  _createClass(WowmaApi, [{
    key: 'updateItem',
    value: function updateItem(_updateItem) {
      var request, res;
      return regeneratorRuntime.async(function updateItem$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            request = '<request><shopId>' + this.shopId + '</shopId><updateItem>' + (0, _xmlJs.json2xml)(_updateItem, { compact: true }) + '</updateItem></request>';
            context$2$0.prev = 1;
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.requestPost('updateItemInfo', request));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', { response: res, requestXML: request });

          case 8:
            context$2$0.prev = 8;
            context$2$0.t0 = context$2$0['catch'](1);
            throw Object.assign(_utilError2['default'].parse(context$2$0.t0), { requestXML: request });

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[1, 8]]);
    }
  }, {
    key: 'requestPost',
    value: function requestPost(method, body) {
      var apiRequest, res;
      return regeneratorRuntime.async(function requestPost$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/' + method,
              body: body
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            // リクエスト発行
            context$2$0.next = 4;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(stockUpdateItem) {
      var apiRequest, res;
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/updateStock'
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.updateStockCreateRequestBody(stockUpdateItem));

          case 4:
            apiRequest.body = context$2$0.sent;
            context$2$0.next = 7;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStockCreateRequestBody',
    value: function updateStockCreateRequestBody(stockUpdateItem) {
      var stockUpdateItemXML, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, item, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, e, var0, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, variation, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, key, apiRequestBody;

      return regeneratorRuntime.async(function updateStockCreateRequestBody$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            stockUpdateItemXML = '';
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 4;
            _iterator = stockUpdateItem[Symbol.iterator]();

          case 6:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 87;
              break;
            }

            item = _step.value;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 11;

            // 値のチェック
            for (_iterator2 = item.variations[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              e = _step2.value;

              // 在庫数の上限100
              if (e.stock > 100) e.stock = 100;
            }

            context$2$0.next = 19;
            break;

          case 15:
            context$2$0.prev = 15;
            context$2$0.t0 = context$2$0['catch'](11);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 19:
            context$2$0.prev = 19;
            context$2$0.prev = 20;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 22:
            context$2$0.prev = 22;

            if (!_didIteratorError2) {
              context$2$0.next = 25;
              break;
            }

            throw _iteratorError2;

          case 25:
            return context$2$0.finish(22);

          case 26:
            return context$2$0.finish(19);

          case 27:
            stockUpdateItemXML += '<stockUpdateItem>';
            stockUpdateItemXML += '<itemCode>' + item.itemCode + '</itemCode>';

            // 商品在庫種別を振り分け
            // 1 -> 通常商品
            // 2 -> 選択肢別在庫

            var0 = item.variations[0];

            if (!(var0.choicesStockHorizontalCode === '' && var0.choicesStockVerticalCode === '')) {
              context$2$0.next = 35;
              break;
            }

            // 通常商品
            stockUpdateItemXML += '<stockSegment>1</stockSegment>';
            stockUpdateItemXML += '<stockCount>' + var0.stock + '</stockCount>';
            context$2$0.next = 83;
            break;

          case 35:
            // 選択肢別在庫
            stockUpdateItemXML += '<stockSegment>2</stockSegment>';

            // リクエストボディを作成する
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 39;
            _iterator3 = item.variations[Symbol.iterator]();

          case 41:
            if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
              context$2$0.next = 69;
              break;
            }

            variation = _step3.value;

            // 在庫設定タグの名前を差し替える
            variation.choicesStockCount = variation.stock;
            delete variation.stock;

            // xmlを構成する
            stockUpdateItemXML += '<choicesStocks>';
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 49;
            for (_iterator4 = Object.keys(variation)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              key = _step4.value;

              stockUpdateItemXML += '<' + key + '>' + variation[key] + '</' + key + '>';
            }
            context$2$0.next = 57;
            break;

          case 53:
            context$2$0.prev = 53;
            context$2$0.t1 = context$2$0['catch'](49);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 57:
            context$2$0.prev = 57;
            context$2$0.prev = 58;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 60:
            context$2$0.prev = 60;

            if (!_didIteratorError4) {
              context$2$0.next = 63;
              break;
            }

            throw _iteratorError4;

          case 63:
            return context$2$0.finish(60);

          case 64:
            return context$2$0.finish(57);

          case 65:
            stockUpdateItemXML += '</choicesStocks>';

          case 66:
            _iteratorNormalCompletion3 = true;
            context$2$0.next = 41;
            break;

          case 69:
            context$2$0.next = 75;
            break;

          case 71:
            context$2$0.prev = 71;
            context$2$0.t2 = context$2$0['catch'](39);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t2;

          case 75:
            context$2$0.prev = 75;
            context$2$0.prev = 76;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 78:
            context$2$0.prev = 78;

            if (!_didIteratorError3) {
              context$2$0.next = 81;
              break;
            }

            throw _iteratorError3;

          case 81:
            return context$2$0.finish(78);

          case 82:
            return context$2$0.finish(75);

          case 83:

            stockUpdateItemXML += '</stockUpdateItem>';

          case 84:
            _iteratorNormalCompletion = true;
            context$2$0.next = 6;
            break;

          case 87:
            context$2$0.next = 93;
            break;

          case 89:
            context$2$0.prev = 89;
            context$2$0.t3 = context$2$0['catch'](4);
            _didIteratorError = true;
            _iteratorError = context$2$0.t3;

          case 93:
            context$2$0.prev = 93;
            context$2$0.prev = 94;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 96:
            context$2$0.prev = 96;

            if (!_didIteratorError) {
              context$2$0.next = 99;
              break;
            }

            throw _iteratorError;

          case 99:
            return context$2$0.finish(96);

          case 100:
            return context$2$0.finish(93);

          case 101:
            apiRequestBody = '\n    <request>\n    <shopId>' + this.shopId + '</shopId>\n    ' + stockUpdateItemXML + '\n    </request>\n    ';
            return context$2$0.abrupt('return', apiRequestBody);

          case 103:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[4, 89, 93, 101], [11, 15, 19, 27], [20,, 22, 26], [39, 71, 75, 83], [49, 53, 57, 65], [58,, 60, 64], [76,, 78, 82], [94,, 96, 100]]);
    }
  }]);

  return WowmaApi;
})();

exports['default'] = WowmaApi;
module.exports = exports['default'];

// 接続オプションの作成

// 接続オプションの作成

// リクエスト発行

//
// stockUpdateItem =
// [
//   {
//     itemCode: <String>,
//     variations: [
//        {
//          choicesStockHorizontalCode: <String>,
//          choicesStockVerticalCode: <String>,
//          stock: <Number>
//        }
//     ]
//   }
// ]

// リクエストボディの作成

// リクエストボディを返す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/error.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var utilError = (function () {
  function utilError() {
    _classCallCheck(this, utilError);
  }

  _createClass(utilError, null, [{
    key: "parse",
    value: function parse(e) {
      var res = {};

      if (e instanceof Error) {
        res.message = e.message;
        res.name = e.name;
        res.fileName = e.fileName;
        res.lineNumber = e.lineNumber;
        res.columnNumber = e.columnNumber;
        res.stack = e.stack;
      } else {
        res = e;
      }

      return res;
    }
  }]);

  return utilError;
})();

exports["default"] = utilError;
module.exports = exports["default"];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mongo.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var MongoCollection = (function () {
  function MongoCollection() {
    _classCallCheck(this, MongoCollection);
  }

  _createClass(MongoCollection, null, [{
    key: 'get',
    value: function get(plug, collection) {
      var client, db;
      return regeneratorRuntime.async(function get$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri));

          case 2:
            client = context$2$0.sent;
            db = client.db(plug.database);
            return context$2$0.abrupt('return', db.collection(collection));

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }]);

  return MongoCollection;
})();

exports.MongoCollection = MongoCollection;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mysql.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mysql = require('mysql');

var _mysql2 = _interopRequireDefault(_mysql);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var MySQL = (function () {
  function MySQL(profile) {
    _classCallCheck(this, MySQL);

    // コネクションプール初期化
    this.pool = _mysql2['default'].createPool(profile);

    // 複数行ステートメント対応
    var profileMulti = { multipleStatements: true };
    Object.assign(profileMulti, profile);
    this.poolMulti = _mysql2['default'].createPool(profileMulti);
  }

  _createClass(MySQL, [{
    key: 'query',

    /**
     *
     * @param {String} sql
     */
    value: function query(sql) {
      // コネクション確立
      // let con = await this.getCon();
      return this.getCon().then(function (con) {
        return new Promise(function (resolve, reject) {
          // クエリ送信
          con.query(sql, function (e, res) {
            // コネクション開放
            con.release();
            if (e) {
              reject(e);
            } else resolve(res);
          });
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'queryInsert_',
    value: function queryInsert_(sql) {
      var res;
      return regeneratorRuntime.async(function queryInsert_$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query(sql));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * @param {String} table
     * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryInsert',
    value: function queryInsert(table) {
      var data = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
      var dataSql = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

      var sql, map, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, k, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, res;

      return regeneratorRuntime.async(function queryInsert$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'INSERT INTO ' + table + ' ';
            map = new Map();
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 5;

            for (_iterator = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              k = _step.value;

              if (data[k] === null) {
                map.set(k, 'NULL');
              } else if (data[k].constructor.name === 'Date') {
                // 日付を変換
                map.set(k, '"' + MySQL.formatDate(data[k]) + '"');
              } else {
                map.set(k, '' + _mysql2['default'].escape(data[k]));
              }
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 24;
            for (_iterator2 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
            }

            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError2) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError2;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += '( ' + [].concat(_toConsumableArray(map.keys())).join(',') + ' ) ';

            sql += 'VALUES( ' + [].concat(_toConsumableArray(map.values())).join(',') + ' ) ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    /**
     *
     * @param {String} table
     * @param {String} filter SQL UPDATEステートメントのWHERE句
     * @param {Object} data 文字列のパラメーター
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryUpdate',
    value: function queryUpdate(table, filter, data, dataSql) {
      var sql, updates, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, k, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, res;

      return regeneratorRuntime.async(function queryUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'UPDATE ' + table + ' SET ';
            updates = [];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 5;

            for (_iterator3 = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              updates.push(k + '=' + _mysql2['default'].escape(data[k]));
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError3) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError3;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 24;
            for (_iterator4 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              updates.push(k + '=' + dataSql[k]);
            }
            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError4) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError4;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += updates.join(',');

            sql += ' WHERE ' + filter + ' ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    // enable to use multiple statements
  }, {
    key: 'queryMulti',
    value: function queryMulti(sql) {
      var poolSwap, res;
      return regeneratorRuntime.async(function queryMulti$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            poolSwap = this.pool;

            this.pool = this.poolMulti;
            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query(sql));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 7:
            context$2$0.prev = 7;

            this.pool = poolSwap;
            return context$2$0.finish(7);

          case 10:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2,, 7, 10]]);
    }
  }, {
    key: 'startTransaction',
    value: function startTransaction() {
      return regeneratorRuntime.async(function startTransaction$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('START TRANSACTION;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'commit',
    value: function commit() {
      return regeneratorRuntime.async(function commit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('COMMIT;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'rollback',
    value: function rollback() {
      return regeneratorRuntime.async(function rollback$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('ROLLBACK;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'streamingQuery',
    value: function streamingQuery(sql) {
      var _this = this;

      var onResult = arguments.length <= 1 || arguments[1] === undefined ? function (record) {} : arguments[1];
      var onError = arguments.length <= 2 || arguments[2] === undefined ? function (e) {} : arguments[2];

      return this.getCon().then(function (con) {
        return new Promise(function callee$3$0(resolve, reject) {
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                // クエリ送信
                con.query(sql).on('result', function (record) {
                  con.pause();
                  onResult(record);
                  con.resume();
                }).on('error', function (e) {
                  onError(e);
                }).on('end', function () {
                  con.release();
                  resolve();
                });

              case 1:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'getCon',
    value: function getCon() {
      var _this2 = this;

      return new Promise(function (resolve, reject) {
        // プールからのコネクション獲得
        _this2.pool.getConnection(function (e, con) {
          if (e) {
            reject(e);
          } else {
            resolve(con);
          }
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }], [{
    key: 'formatDate',
    value: function formatDate(date) {
      return (0, _moment2['default'])(date).format().substring(0, 19).replace('T', ' ');
    }
  }]);

  return MySQL;
})();

exports['default'] = MySQL;
module.exports = exports['default'];

// let res = await this.query(sql);
// return res.insertId;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/packet.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Packet = (function () {
  function Packet(packetSize) {
    _classCallCheck(this, Packet);

    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  _createClass(Packet, [{
    key: "submit",
    value: function submit(arg) {
      return regeneratorRuntime.async(function submit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            if (!(this.count % this.packetSize === 0)) {
              context$2$0.next = 4;
              break;
            }

            if (!this.onPacketStart) {
              context$2$0.next = 4;
              break;
            }

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.onPacketStart(this.packetCount));

          case 4:
            if (!this.onPacket) {
              context$2$0.next = 7;
              break;
            }

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.onPacket(arg));

          case 7:
            this.count++;
            // packetSizeの回数ごとに、終了処理を呼び出す
            if (this.count % this.packetSize === 0) {
              this.close();
              this.packetCount++;
            }

          case 9:
          case "end":
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: "close",
    value: function close() {
      if (this.onPacketEnd) {
        this.onPacketEnd(this.packetCount);
      }
    }
  }]);

  return Packet;
})();

exports["default"] = Packet;
module.exports = exports["default"];

// packetSizeの回数ごとに、初期化を呼び出す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/report.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _error = require('./error');

var _error2 = _interopRequireDefault(_error);

var _meteorMeteor = require('meteor/meteor');

var _collections = require('../collections');

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

var Report = (function () {
  function Report() {
    _classCallCheck(this, Report);

    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  // private

  _createClass(Report, [{
    key: 'setupIterator',
    value: function setupIterator(phaseId) {
      this.iterator = new Iterator(phaseId);
      this.iterators.push(this.iterator);
    }
  }, {
    key: 'phase',
    value: function phase() {
      var _this = this;

      var name = arguments.length <= 0 || arguments[0] === undefined ? '' : arguments[0];
      var fn = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0() {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
      var rec, res;
      return regeneratorRuntime.async(function phase$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            rec = {
              phaseId: (0, _uniqid2['default'])()
            };

            this.setupIterator(rec.phaseId);

            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(fn());

          case 5:
            res = context$2$0.sent;

            Object.assign(rec, {
              type: 'success',
              phase: name,
              result: res
            });
            context$2$0.next = 12;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](2);

            Object.assign(rec, {
              type: 'error',
              phase: name,
              result: _error2['default'].parse(context$2$0.t0)
            });

          case 12:
            context$2$0.prev = 12;

            // ループ処理のレポートを作成
            if (this.iterator.metric.total) {
              Object.assign(rec, {
                iterator: this.iterator.metric
              });
            }
            // タイムスタンプ
            rec.timeStamp = new Date();
            // レポートをデータベースに記録
            _collections.Logs.insert(rec);

            // 呼び出し元用レポートに追加
            this.record.push(rec);
            return context$2$0.finish(12);

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2, 9, 12, 18]]);
    }

    // カーソルをループし、与えられた関数を実行
    // 呼び出す関数の引数にはカーソルから得られたドキュメントを渡す
  }, {
    key: 'forEachOnCursor',
    value: function forEachOnCursor(cur, fn) {
      var doc, res;
      return regeneratorRuntime.async(function forEachOnCursor$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 2:
            if (!context$2$0.sent) {
              context$2$0.next = 18;
              break;
            }

            context$2$0.next = 5;
            return regeneratorRuntime.awrap(cur.next());

          case 5:
            doc = context$2$0.sent;
            context$2$0.prev = 6;
            context$2$0.next = 9;
            return regeneratorRuntime.awrap(fn(doc));

          case 9:
            res = context$2$0.sent;

            this.iSuccess(res);
            context$2$0.next = 16;
            break;

          case 13:
            context$2$0.prev = 13;
            context$2$0.t0 = context$2$0['catch'](6);

            this.iError(context$2$0.t0);

          case 16:
            context$2$0.next = 0;
            break;

          case 18:
            cur.close();

          case 19:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 13]]);
    }
  }, {
    key: 'iSuccess',
    value: function iSuccess(newRecord) {
      this.iterator.success(newRecord);
    }
  }, {
    key: 'iError',
    value: function iError(newRecord) {
      this.iterator.error(_error2['default'].parse(newRecord));
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      var iteError = this.iterators.find(function (e) {
        return e.errorOcurred();
      });
      var phaError = false;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.record[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var rec = _step.value;

          if (rec.type === 'error') {
            phaError = true;
            break;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return iteError || phaError;
    }
  }, {
    key: 'publish',
    value: function publish() {
      // 呼び出し元へレポート
      if (this.errorOcurred()) {
        throw new _meteorMeteor.Meteor.Error(this.record);
      }
      return this.record;
    }
  }]);

  return Report;
})();

exports['default'] = Report;

var Iterator = (function () {
  function Iterator(phaseId) {
    _classCallCheck(this, Iterator);

    this.metric = {
      total: 0,
      success: 0,
      error: 0,
      phaseId: phaseId
    };
    this.lastError = null;
  }

  _createClass(Iterator, [{
    key: 'success',
    value: function success(newRecord) {
      if (newRecord) {
        this.log(newRecord, true);
      }
      this.metric.success++;
      this.metric.total++;
    }
  }, {
    key: 'error',
    value: function error(newRecord) {
      // 直前と同じエラーは省く
      if (JSON.stringify(this.lastError) !== JSON.stringify(newRecord)) {
        if (newRecord && newRecord !== {} && newRecord !== '') {
          this.log(newRecord, false);
          this.lastError = newRecord;
        }
      }
      this.metric.error++;
      this.metric.total++;
    }
  }, {
    key: 'log',
    value: function log(newRecord, isSuccess /* true => success or false => error */) {
      var rec = {
        success: isSuccess,
        phaseId: this.metric.phaseId,
        message: newRecord,
        timeStamp: new Date()
      };
      _collections.Logs.insert(rec);
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      return this.metric.error;
    }
  }]);

  return Iterator;
})();

module.exports = exports['default'];

// リクエスト発行
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/text.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var TextUtil = (function () {
  function TextUtil() {
    _classCallCheck(this, TextUtil);
  }

  _createClass(TextUtil, null, [{
    key: 'substr8',
    value: function substr8(text, len, truncation) {
      if (truncation === undefined) {
        truncation = '';
      }
      var textArray = text.split('');
      var count = 0;
      var str = '';
      for (var i = 0; i < textArray.length; i++) {
        var n = escape(textArray[i]);
        if (n.length < 4) count++;else count += 2;
        if (count > len) {
          return str + truncation;
        }
        str += text.charAt(i);
      }
      return text;
    }
  }]);

  return TextUtil;
})();

exports['default'] = TextUtil;
module.exports = exports['default'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _meteorMongo = require('meteor/mongo');

var Logs = new _meteorMongo.Mongo.Collection('logs', { idGeneration: 'MONGO' });
exports.Logs = Logs;
var Uploads = new _meteorMongo.Mongo.Collection('uploads', { idGeneration: 'MONGO' });
exports.Uploads = Uploads;
var RobotinShop = new _meteorMongo.Mongo.Collection('robotinShop', { idGeneration: 'MONGO' });
exports.RobotinShop = RobotinShop;
var ItemsTest = new _meteorMongo.Mongo.Collection('itemsTest', { idGeneration: 'MONGO' });
exports.ItemsTest = ItemsTest;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/robotin.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/wowmaApi.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yb2JvdGluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdG9vbHRlc3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci93b3dtYS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIveWF1Y3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vY29uZmlncy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2ZpbHRlcnMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9ncm91cHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9jdWJlM2FwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvaXRlbXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS93b3dtYUFwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3RleHQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbnMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O2tCQUtlLElBQUk7Ozs7c0JBQ0EsUUFBUTs7Ozs7O2lDQUdKLG9CQUFvQjs7OztrQ0FHcEMsOEJBQThCOztBQUNyQyxJQUFJLG9CQUFvQixHQUFHLHFDQUFZLENBQUM7O0FBRXhDLElBQU0sS0FBSyxHQUFHLGVBQWUsQ0FBQzs7O0FBRzlCLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO0FBQ3hELE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxVQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUs7OztBQUcvQyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLGdCQUFHLFFBQVEsQ0FBQyxDQUFDO0FBQzdDLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsZ0JBQUcsU0FBUyxDQUFDLENBQUM7QUFDOUMsTUFBTSxRQUFRLEdBQUcsMEJBQVEsQ0FBQzs7Ozs7OztBQUUxQix5QkFBaUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLDhIQUFFO1VBQXhCLElBQUk7O0FBQ1gsVUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzs7O0FBRy9CLFVBQUksUUFBUSxHQUFNLDBCQUFRLFNBQU07OztBQUdoQyxVQUFJLFFBQVEsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDOzs7OztBQUtsRCxVQUFJLEdBQUcsR0FBRztBQUNSLGdCQUFRLEVBQUUsUUFBUTtBQUNsQixzQkFBYyxFQUFFLElBQUksQ0FBQyxJQUFJO0FBQ3pCLHdCQUFnQixFQUFFLFFBQVE7T0FDM0IsQ0FBQzs7QUFFRixVQUFHO0FBQ0QsY0FBTSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztPQUN4QixDQUNELE9BQU0sR0FBRyxFQUFDO0FBQ1IsV0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7T0FDakI7QUFDRCxrQ0FBUSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7O0FBRXBCLGFBQU8sSUFBSSxDQUFDO0tBRWI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxHQUFDO0FBQ0YsTUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNwQixNQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7QUFDdEIsWUFBUSxFQUFFLFFBQVE7QUFDbEIsV0FBTyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUTtHQUMzQixDQUFDLENBQUMsQ0FBQztDQUVMLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7c0JDN0RpQixRQUFROzs7OzRCQUVKLGVBQWU7O2dDQUNwQiwwQkFBMEI7Ozs7aUNBQ3pCLDJCQUEyQjs7Ozt1Q0FJdkMsaUNBQWlDOzt3Q0FHakMsa0NBQWtDOztBQUV6QyxJQUFJLEdBQUcsR0FBRyxTQUFTOztBQUVuQixxQkFBTyxPQUFPLHlEQUVGLEdBQUcsZUFBWSxvQkFBQyxNQUFNO01BQzFCLE1BQU0sRUFLTixNQUFNLEVBTU4sU0FBUyxFQUVULEtBQUs7Ozs7OztBQWJMLGNBQU0sR0FBRyxvQ0FBWTtBQUtyQixjQUFNLEdBQUcscUNBQVcsTUFBTSxDQUFDLFdBQVcsQ0FBQztBQU12QyxpQkFBUyxHQUFHLGdCQUFnQjtBQUU1QixhQUFLLEdBQUcsa0NBQVUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7O3dDQUVoQyxNQUFNLENBQUMsS0FBSyxDQUFDLHdCQUF3QixFQUN6Qzs7Ozs7Z0RBQ1EsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7Ozs7Ozs7U0FDN0IsQ0FBQzs7Ozt3Q0FLRSxNQUFNLENBQUMsS0FBSyxDQUFDLHVCQUF1QixFQUN4QztjQUNNLEdBQUc7Ozs7Ozs7Z0RBQVMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUM3Qiw0QkFBVSxFQUFFLG9CQUFPLE1BQU07d0JBYW5CLEdBQUcsRUF3R0gsUUFBUSxFQUVSLFVBQVUsRUFFVixhQUFhLEVBR1gsSUFBRzs7Ozs7QUEvR0wsNkJBQUcsNmRBS08sTUFBTSxDQUFDLFdBQVcsV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxHQUFHLFdBQU0sTUFBTSxDQUFDLEdBQUcsV0FBTSxNQUFNLENBQUMsVUFBVSxXQUFNLE1BQU0sQ0FBQyxJQUFJLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsWUFBWSxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsT0FBTyxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLFFBQVEsV0FBTSxNQUFNLENBQUMsSUFBSSxXQUFNLE1BQU0sQ0FBQyxVQUFVLFdBQU0sTUFBTSxDQUFDLGNBQWMsV0FBTSxNQUFNLENBQUMsYUFBYSxXQUFNLE1BQU0sQ0FBQyxTQUFTLFdBQU0sTUFBTSxDQUFDLFNBQVMsV0FBTSxNQUFNLENBQUMsSUFBSSxXQUFNLE1BQU0sQ0FBQyxXQUFXLFdBQU0sTUFBTSxDQUFDLFdBQVcsV0FBTSxNQUFNLENBQUMsT0FBTzs7OzBEQUt6ckIsS0FBSyxDQUFDLFdBQVcsQ0FDckIsY0FBYyxFQUFFO0FBQ2QsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLCtCQUFHLEVBQUUsTUFBTSxDQUFDLEdBQUc7QUFDZiwrQkFBRyxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQ2Ysc0NBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtBQUM3QixnQ0FBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO0FBQ2pCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsd0NBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtBQUNqQyxpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTztBQUN2QixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLG9DQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDekIsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQixzQ0FBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO0FBQzdCLDBDQUFjLEVBQUUsTUFBTSxDQUFDLGNBQWM7QUFDckMseUNBQWEsRUFBRSxNQUFNLENBQUMsYUFBYTtBQUNuQyxxQ0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO0FBQzNCLHFDQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7QUFDM0IsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTzsyQkFDeEIsQ0FDRjs7Ozs7Ozs7OztBQUVELGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7MERBS1YsS0FBSyxDQUFDLFdBQVcsQ0FDckIsc0JBQXNCLEVBQUU7QUFDdEIsK0NBQW1CLEVBQUUsSUFBSTtBQUN6Qix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHNDQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDN0IsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLHdDQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7QUFDakMsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87QUFDdkIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPOzJCQUN4QixDQUNGOzs7Ozs7Ozs7O0FBRUQsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7OzswREFLVixLQUFLLENBQUMsV0FBVyxDQUNyQix1QkFBdUIsRUFBRTtBQUN2Qiw4QkFBRSxFQUFFLElBQUk7QUFDUix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHdDQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7QUFDakMsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87MkJBQ3hCLENBQ0Y7Ozs7Ozs7Ozs7QUFFRCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7OztBQUtkLGtDQUFRLEdBQUcsb0JBQU8sV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUVwRSxvQ0FBVSxHQUFNLE1BQU0sQ0FBQyxNQUFNLFNBQUksTUFBTSxDQUFDLE1BQU0sd0JBQW1CLE1BQU0sQ0FBQyxXQUFXO0FBRW5GLHVDQUFhLEdBQUcsTUFBTSxDQUFDLEtBQUssR0FBRyxHQUFHOzs7MERBR3BCLEtBQUssQ0FBQyxXQUFXLENBQy9CLFlBQVksRUFBRTtBQUNaLHFDQUFTLEVBQUUsSUFBSTtBQUNmLHFDQUFTLEVBQUUsUUFBUTtBQUNuQix1Q0FBVyxFQUFFLENBQUM7QUFDZCx1Q0FBVyxFQUFFLFVBQVU7QUFDdkIseUNBQWEsRUFBRSxDQUFDO0FBQ2hCLDJDQUFlLEVBQUUsQ0FBQztBQUNsQiwwQ0FBYyxFQUFFLENBQUM7QUFDakIsMENBQWMsRUFBRSxhQUFhO0FBQzdCLHlDQUFhLEVBQUUsSUFBSTtBQUNuQix1Q0FBVyxFQUFFLENBQUM7QUFDZCx5Q0FBYSxFQUFFLENBQUM7QUFDaEIsOENBQWtCLEVBQUUsSUFBSTtBQUN4Qix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLCtDQUFtQixFQUFFLHFCQUFxQjtBQUMxQyw2Q0FBaUIsRUFBRSxxQkFBcUI7QUFDeEMsbUNBQU8sRUFBRSxDQUFDOzJCQUNYLEVBQUU7QUFDRCx1Q0FBVyxFQUFFLE9BQU87QUFDcEIsdUNBQVcsRUFBRSxPQUFPOzJCQUNyQixDQUNGOzs7QUF0QkcsOEJBQUc7Ozs7Ozs7O0FBd0JQLGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OzttQkFFbkI7aUJBQ0YsRUFDRCxvQkFBTyxDQUFDOzs7O0FBQ04sOEJBQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDOzs7Ozs7O2lCQUNqQixDQUNBOzs7QUE1SkcsbUJBQUc7b0RBOEpBLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FFSyxxQkFBcUIsRUFBQyw0QkFBQyxPQUFPO01BQzlCLEVBQUUsRUFDRixHQUFHOzs7O0FBREgsVUFBRSxHQUFHLGtDQUFVLE9BQU8sQ0FBQzs7d0NBQ1gsRUFBRSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQzs7O0FBQXRDLFdBQUc7NENBQ0EsR0FBRzs7Ozs7OztDQUNYLG9CQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQ0NyTjhCLDBCQUEwQjs7NEJBQ3JDLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLGtCQUFrQjs7QUFFNUIscUJBQU8sT0FBTyx5REFFRixHQUFHLFlBQVMsb0JBQUMsSUFBSTtNQUFFLEtBQUsseURBQUcsRUFBRTtNQUFFLFVBQVUseURBQUcsRUFBRTtNQUNsRCxJQUFJLEVBQ0osR0FBRzs7Ozs7d0NBRFUsa0NBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQzs7O0FBQXZELFlBQUk7O3dDQUNRLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUMsVUFBVSxFQUFFLFVBQVUsRUFBQyxDQUFDLENBQUMsT0FBTyxFQUFFOzs7QUFBaEUsV0FBRzs0Q0FDQSxHQUFHOzs7Ozs7O0NBQ1gsb0NBRVMsR0FBRyxpQkFBYyxvQkFBQyxJQUFJO01BQUUsS0FBSyx5REFBRyxFQUFFO01BQ3RDLElBQUksRUFDSixHQUFHOzs7Ozt3Q0FEVSxrQ0FBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDOzs7QUFBdkQsWUFBSTs7d0NBQ1EsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLEVBQUU7OztBQUEzQyxXQUFHOzRDQUNBLEdBQUc7Ozs7Ozs7Q0FDWCxvQkFFRCxDOzs7Ozs7Ozs7Ozs7Ozs7OzttQ0NuQnlCLDZCQUE2Qjs7Ozs0QkFDbkMsZUFBZTs7QUFFcEMsSUFBSSxHQUFHLEdBQUcsYUFBYTs7QUFFdkIscUJBQU8sT0FBTyx5REFPRixHQUFHLGdCQUFhLG9CQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsS0FBSztNQUFFLE1BQU0seURBQUcsSUFBSTtNQUFFLE1BQU0seURBQUcsSUFBSTtNQUN4RSxPQUFPLEVBRVAsUUFBUTs7OztBQUZSLGVBQU8sR0FBRyxzQ0FBb0I7O3dDQUM1QixPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs7Ozt3Q0FDSCxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQzs7O0FBQWxFLGdCQUFROzRDQUNMLFFBQVE7Ozs7Ozs7Q0FDaEIsb0NBS1MsR0FBRyxrQkFBZSxvQkFBQyxJQUFJLEVBQUUsS0FBSztNQUFFLE1BQU0seURBQUcsSUFBSTtNQUFFLE1BQU0seURBQUcsSUFBSTtNQUNoRSxPQUFPOzs7O0FBQVAsZUFBTyxHQUFHLHNDQUFvQjs7d0NBQzVCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDOzs7O3dDQUNsQixPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDOzs7Ozs7O0NBQ2hELG9CQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDNUJpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7c0NBRzdCLDZCQUE2Qjs7Z0NBQ2xCLHVCQUF1Qjs7OzttQ0FDZCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLE1BQU07O0FBRWhCLHFCQUFPLE9BQU8seURBS0YsR0FBRyxtQkFBZ0Isb0JBQUMsTUFBTTtNQUU5QixNQUFNLEVBRU4sTUFBTSxFQUNOLGNBQWMsRUFHZCxRQUFRLEVBQ1IsR0FBRzs7Ozs7O0FBUEgsY0FBTSxHQUFHLG9DQUFZO0FBRXJCLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDbkMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFFckMsZ0JBQVEsR0FBRyxrQ0FBVSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ3BDLFdBQUcsR0FBRyxxQ0FBYSxRQUFRLENBQUM7O3dDQUUxQixNQUFNLENBQUMsS0FBSyxDQUNoQixPQUFPLEVBQ1A7Y0FDTSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3hCLFFBQVE7Ozs7OzBEQUFTLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7O0FBQWxELGtDQUFROzswREFDTixHQUFHLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLFFBQVEsQ0FBQzs7Ozs7OzttQkFDeEUsRUFBQyxDQUFDOzs7QUFMRCxtQkFBRztvREFPQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBS1MsR0FBRyxpQkFBYyxvQkFBQyxNQUFNO01BQzVCLE1BQU0sRUFDTixRQUFRLEVBQ1IsR0FBRyxFQUVILGNBQWMsRUFJZCxNQUFNOzs7Ozs7QUFSTixjQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCxnQkFBUSxHQUFHLGtDQUFVLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDcEMsV0FBRyxHQUFHLHFDQUFhLFFBQVEsQ0FBQztBQUU1QixzQkFBYyxHQUFHLHNDQUFvQjs7d0NBQ25DLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBR3JDLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGVBQWUsRUFDZjtjQUNNLEdBQUc7Ozs7Ozs7Z0RBQVMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUM3QiwwQkFBUSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPO3dCQUN4QixHQUFHLEVBR0QsUUFBUSxFQUVSLFNBQVM7Ozs7QUFMWCw2QkFBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVOzs7MERBR0wsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDOzs7QUFBekUsa0NBQVE7OzBEQUVVLEdBQUcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDOzs7QUFBN0MsbUNBQVM7OzBEQUdQLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDZiwrQkFBRyxFQUFFLElBQUksQ0FBQyxHQUFHOzJCQUNkLEVBQUU7QUFDRCxnQ0FBSSxFQUFFO0FBQ0osMkRBQTZCLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVO0FBQ3ZELGlFQUFtQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCO0FBQ25FLGlFQUFtQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCOzZCQUNwRTsyQkFDRixDQUFDOzs7O0FBRUYsZ0NBQU0sQ0FBQyxRQUFRLEVBQUU7Ozs7Ozs7O0FBRWpCLGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OzttQkFFbkI7aUJBQ0YsRUFDRCxvQkFBTyxDQUFDOzs7OzhCQUNBLENBQUM7Ozs7Ozs7aUJBQ1IsQ0FBQzs7O0FBNUJFLG1CQUFHO29EQThCQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7Ozt3Q0FFRSxNQUFNLENBQUMsS0FBSyxDQUNoQixnQkFBZ0IsRUFDaEI7Y0FDTSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDeEIsR0FBRyxFQUdELFFBQVEsRUFNUixRQUFROzs7O0FBVFYsNkJBQUcsR0FBRyxPQUFPLENBQUMsVUFBVTs7OzBEQUdMLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQzs7O0FBQXpFLGtDQUFROzswREFFTixHQUFHLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDOzs7OzBEQUNoQyxHQUFHLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQzs7OzswREFDM0IsR0FBRyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQzs7OzswREFFZixjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUFsRCxrQ0FBUTs7MERBQ04sR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLENBQUM7Ozs7QUFFdkUsZ0NBQU0sQ0FBQyxRQUFRLEVBQUU7Ozs7Ozs7O0FBRWpCLGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OzttQkFFbkI7aUJBQ0YsRUFDRCxvQkFBTyxDQUFDOzs7OzhCQUNBLENBQUM7Ozs7Ozs7aUJBQ1IsQ0FBQzs7O0FBdEJFLG1CQUFHO29EQXdCQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0JBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0NqSWlCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOzttQ0FDVCwwQkFBMEI7Ozs7NEJBSTlDLGVBQWU7O2lDQUNILHdCQUF3Qjs7Ozt1QkFDdkIsVUFBVTs7Ozt5QkFFWixZQUFZOzs7O3dCQUNULFVBQVU7Ozs7bUJBQ2YsS0FBSzs7OztBQUVyQixJQUFNLEdBQUcsR0FBRyxrQkFBa0I7O0FBRTlCLElBQU0sZUFBZSxHQUFHLE9BQU87O0FBRS9CLHFCQUFPLE9BQU8scUJBTUYsR0FBRyxtQkFBZ0Isb0JBQUMsTUFBTTtNQUU5QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQix1QkFBdUIsRUFDdkI7Y0FDUSxPQUFPLEVBWVAsUUFBUTs7Ozs7O0FBWlIsdUJBQU8sR0FBTSxNQUFNLENBQUMsT0FBTzs7O2dEQUd6QixxQkFBUSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFHN0IscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7OztnREFNUCxxQkFBUSxRQUFRLENBQUksT0FBTyxTQUFJLE1BQU0sQ0FBQyxjQUFjLFVBQU87OztBQUE1RSx3QkFBUTs7Z0RBQ0ssdUJBQU0sTUFBTSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUM7OztBQUEvQyx3QkFBUTs7Z0RBQ1MsdUJBQU0sTUFBTSxDQUFDLFFBQVEsRUFBRSxPQUFPLENBQUM7OztBQUFoRCx3QkFBUTs7Z0RBWUYsTUFBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQzNCLG9CQUFNLENBQUM7c0JBVUMsT0FBTzs7OztBQVRiLCtCQUFPLENBQUMsR0FBRyxpQkFBZSxDQUFDLENBQUMsU0FBUyxDQUFHOzs7Ozs7Ozs7QUFTbEMsK0JBQU8sR0FBRyxxQkFBUSxnQkFBZ0IsQ0FBSSxPQUFPLFNBQUksQ0FBQyxDQUFDLFNBQVMsVUFBTzs7QUFDekUsK0JBQU8sQ0FBQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ3JDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLGlCQUFJLEtBQUssQ0FBQztBQUNkLGlDQUFPLEVBQUUsSUFBSTt5QkFDZCxDQUFDLENBQUM7Ozs7Ozs7aUJBQ04sQ0FDRjs7O3NCQVlHLElBQUkscUJBQU8sS0FBSyxpRUFBK0QsT0FBTyxPQUFJOzs7Ozs7O1NBQ2pHLENBQ0Y7Ozs7Ozs7Q0FDRixFQUNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQzdGaUIsd0JBQXdCOzs7O3NDQUdwQyw2QkFBNkI7O2dDQUNsQix1QkFBdUI7Ozs7NEJBQ3BCLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLE1BQU07O0FBRWhCLHFCQUFPLE9BQU8scUJBS0YsR0FBRyxZQUFTLG9CQUFDLE1BQU07TUFFdkIsTUFBTSxFQUVOLE1BQU0sRUFFSixRQUFROzs7Ozs7QUFKVixjQUFNLEdBQUcsb0NBQVk7QUFFckIsY0FBTSxHQUFHLDBDQUFrQixNQUFNLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7O3dDQUV2QyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxvQkFBTyxDQUFDOzs7O3NCQUMxQyxDQUFDOzs7Ozs7O1NBQ1IsQ0FBQzs7O0FBRkksZ0JBQVE7O3dDQUdSLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLFVBQVUsRUFDVjs7OztvREFDUyxRQUFROzs7Ozs7O1NBQ2hCLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLEVBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDaENpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7bUNBQ1QsMEJBQTBCOzs7OzRCQUVoQyxlQUFlOzt1QkFDaEIsVUFBVTs7Ozs4QkFFVixpQkFBaUI7Ozs7c0NBQ2hCLDZCQUE2Qjs7OztnQ0FDNUIsdUJBQXVCOzs7O0FBRTdDLElBQU0sR0FBRyxHQUFHLE9BQU87O0FBRW5CLHFCQUFPLE9BQU8seURBS0YsR0FBRyxpQ0FBOEIsb0JBQUMsTUFBTTtNQUU1QyxNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixxQkFBcUIsRUFDckI7Y0FHUSxjQUFjLEVBS2hCLEdBQUcsRUE0Q0gsR0FBRzs7Ozs7O0FBakRELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUl6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDLENBa0JGO21CQUNGO2lCQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRSxzQkFBc0I7bUJBQzVCO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO21CQUNqQjtpQkFDRixDQUNGLENBQ0Y7OztBQXpDRyxtQkFBRztBQTRDSCxtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Z0RBQ3BELE1BQU0sQ0FBQyxlQUFlLENBQzFCLEdBQUcsRUFDSCxvQkFBTSxJQUFJO3NCQUdGLEdBQUc7Ozs7eUNBRlQsTUFBTTt5Q0FBUSxJQUFJOzt3REFBUSxjQUFjLENBQUMsb0NBQW9DLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQzs7Ozt1Q0FBckYsTUFBTTs7O3dEQUVLLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDOzs7QUFBaEMsMkJBQUc7NERBQ0EsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUM7Ozs7OzhCQUVuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBQyxFQUFFLDhCQUFVLEtBQUssZ0JBQUcsQ0FBQzs7Ozs7OztpQkFFL0QsQ0FDRjs7Ozs7OztTQUNGLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUtTLEdBQUcsdUJBQW9CLG9CQUFDLE1BQU07TUFFbEMsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsMEJBQTBCLEVBQzFCO2NBR1EsY0FBYyxFQUtoQixHQUFHLEVBeUNILEdBQUc7Ozs7OztBQTlDRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFJekIsY0FBYyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQzVDLENBQ0U7QUFDRSx3QkFBTSxFQUFFO0FBQ04sd0JBQUksRUFBRSxDQUNKO0FBQ0UsMkNBQXFCLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFO3FCQUN0Qzs7Ozs7Ozs7Ozs7Ozs7O3FCQWVGO21CQUNGO2lCQUNGLEVBQ0Q7O0FBRUUsd0JBQU0sRUFBRTtBQUNOLHVCQUFHLEVBQUUsc0JBQXNCO21CQUM1QjtpQkFDRixFQUNEO0FBQ0UsMEJBQVEsRUFBRTtBQUNSLHVCQUFHLEVBQUUsQ0FBQztBQUNOLDRCQUFRLEVBQUUsTUFBTTttQkFDakI7aUJBQ0YsQ0FDRixDQUNGOzs7QUF0Q0csbUJBQUc7QUF5Q0gsbUJBQUcsR0FBRyx3Q0FBYSxNQUFNLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7O2dEQUNwRCxNQUFNLENBQUMsZUFBZSxDQUMxQixHQUFHLEVBQ0gsb0JBQU0sSUFBSTtzQkFJRixHQUFHOzs7O0FBSFQsNEJBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQztBQUNuQiw0QkFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNOzs7d0RBRVQsR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7OztBQUFoQywyQkFBRzs0REFDQSxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBQzs7Ozs7OEJBRW5DLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFDLEVBQUUsOEJBQVUsS0FBSyxnQkFBRyxDQUFDOzs7Ozs7O2lCQUUvRCxDQUNGOzs7Ozs7O1NBQ0YsQ0FDRjs7OzRDQUVNLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBS1MsR0FBRyxtQkFBZ0Isb0JBQUMsTUFBTTtNQUU5QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixhQUFhLEVBQ2I7Y0FHUSxjQUFjLEVBR2hCLEdBQUcsRUFrRUQsSUFBSSxrRkFHQyxDQUFDLEVBT04sR0FBRyxFQUVELEdBQUc7Ozs7O0FBakZMLDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUV6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7cUJBZUY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRTtBQUNILDhCQUFRLEVBQUUsc0JBQXNCO0FBQ2hDLGdEQUEwQixFQUFFLHlCQUF5QjtBQUNyRCw4Q0FBd0IsRUFBRSx5QkFBeUI7cUJBQ3BEO0FBQ0Qsd0JBQUksRUFBRTtBQUNKLDRCQUFNLEVBQUUsTUFBTTtxQkFDZjttQkFDRjtpQkFDRixFQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFLGVBQWU7QUFDcEIsOEJBQVUsRUFBRTtBQUNWLDJCQUFLLEVBQUU7QUFDTCwyQkFBRyxFQUFFLE9BQU87QUFDWixrREFBMEIsRUFBRSxpQ0FBaUM7QUFDN0QsZ0RBQXdCLEVBQUUsK0JBQStCO3VCQUMxRDtxQkFDRjttQkFDRjtpQkFDRixFQUNEO0FBQ0UsMEJBQVEsRUFBRTtBQUNSLHVCQUFHLEVBQUUsQ0FBQztBQUNOLDRCQUFRLEVBQUUsTUFBTTtBQUNoQiw4QkFBVSxFQUFFLGFBQWE7bUJBQzFCO2lCQUNGLENBQ0YsQ0FDRjs7O0FBM0RHLG1CQUFHOzs7O2dEQWlFTSxHQUFHLENBQUMsT0FBTyxFQUFFOzs7Ozs7Ozs7Z0RBQ1AsR0FBRyxDQUFDLElBQUksRUFBRTs7O0FBQXZCLG9CQUFJOzs7Ozs0QkFHTSxJQUFJLENBQUMsVUFBVTs7Ozs7Ozs7QUFBcEIsaUJBQUM7O2dEQUNRLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTlDLGlCQUFDLENBQUMsS0FBSzs7QUFDUCx1QkFBTyxDQUFDLENBQUMsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS1YsbUJBQUcsR0FBRyx3Q0FBYSxNQUFNLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7OztnREFFeEMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDOzs7QUFBbkMsbUJBQUc7O0FBQ1Asc0JBQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDOzs7Ozs7OztBQUVwQixzQkFBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7Ozs7QUFHcEIsbUJBQUcsQ0FBQyxLQUFLLEVBQUU7Ozs7Ozs7U0FDWixDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGtCQUFlLG9CQUFDLE1BQU07TUFFN0IsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBSVEsTUFBTSxFQUNOLGNBQWMsRUFTZCxPQUFPLEVBU1QsR0FBRzs7Ozs7O0FBbkJELHNCQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Z0RBSWpDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7OztBQUkvQix1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPLGVBQVcsSUFBSSxJQUFJLEVBQUUsQ0FBRSxPQUFPLEVBQUU7OztnREFHekQscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7O2dEQU1kLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3hCLE9BQU8sRUFJUCxLQUFLLEVBQ0wsUUFBUTs7OztBQUxSLGlDQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQzs7QUFDekQsaUNBQU8sQ0FBQyxHQUFHLEdBQU0sT0FBTyxDQUFDLEdBQUcsb0JBQWlCO0FBQzdDLGlDQUFPLENBQUMsRUFBRSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFROzs7MERBRTVCLGlDQUFRLE9BQU8sQ0FBQzs7O0FBQTlCLCtCQUFLO0FBQ0wsa0NBQVEsR0FBTSxPQUFPLFNBQUksSUFBSSxDQUFDLEtBQUs7OzBEQUVqQyxxQkFBUSxTQUFTLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQzs7Ozs7OzttQkFDekMsRUFBQyxDQUFDOzs7QUFYRCxtQkFBRztvREFhQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0JBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDMVVpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7bUNBQ1QsMEJBQTBCOzs7OzRCQUVoQyxlQUFlOztBQUVwQyxJQUFNLEdBQUcsR0FBRyxVQUFVOztBQUV0QixxQkFBTyxPQUFPLHFCQUtGLEdBQUcsZUFBWSxvQkFBQyxNQUFNO01BRTFCLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGVBQWUsRUFDZjtjQUlRLE1BQU0sRUFDTixjQUFjLEVBa0JoQixHQUFHOzs7Ozs7QUFuQkQsc0JBQU0sR0FBRywrQ0FBdUIsTUFBTSxDQUFDLFFBQVEsRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ2hFLDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQWlCekIsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7QUFFN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzs7OztBQUM1QixnQ0FBTSxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUM7Ozs7Ozs7bUJBQ3RCLEVBQUMsQ0FBQzs7O0FBSkQsbUJBQUc7b0RBTUEsR0FBRzs7Ozs7OztTQUNYLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLEVBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDeERpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7bUNBQ1QsMEJBQTBCOzs7OzRCQUVoQyxlQUFlOztpQ0FDakIsd0JBQXdCOzs7O3VCQUN2QixVQUFVOzs7O3lCQUVaLFlBQVk7Ozs7d0JBQ1QsVUFBVTs7OzttQkFDZixLQUFLOzs7O3NCQUNrQixRQUFROztBQUUvQyxJQUFNLE1BQU0sR0FBRyxRQUFRO0FBQ3ZCLElBQU0sR0FBRyxHQUFHLE9BQU87O0FBRW5CLHFCQUFPLE9BQU8seURBS0YsR0FBRyxhQUFVLG9CQUFDLE1BQU07TUFFeEIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsUUFBUSxFQUNSO2NBQ1EsY0FBYyxFQUVkLE9BQU8sRUFDUCxDQUFDLEVBQ0QsQ0FBQzs7Ozs7O0FBSkQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUNuQyx1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPO0FBQzNCLGlCQUFDLEdBQUcscUJBQVEsZ0JBQWdCLENBQUksT0FBTyxTQUFJLE1BQU0sQ0FBQyxhQUFhLENBQUc7QUFDbEUsaUJBQUMsR0FBRyxxQkFBUSxpQkFBaUIsQ0FBSSxPQUFPLFNBQUksTUFBTSxDQUFDLGFBQWEsQ0FBRzs7QUFDekUsaUJBQUMsQ0FBQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQy9CLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLGlCQUFJLEtBQUssQ0FBQyxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxpQkFBSSxTQUFTLENBQ2pCLG9CQUFPLE1BQU0sRUFBRSxRQUFRO3NCQUNqQixHQUFHOzs7O0FBQUgsMkJBQUcsR0FBRyxJQUFJOzs7d0RBR1csY0FBYyxDQUFDLGFBQWEsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUM7OztBQUFuRSw4QkFBTSxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7QUFFZCwyQkFBRyxpQkFBSTs7O0FBRVQsZ0NBQVEsQ0FBQyxHQUFHLEVBQUUsTUFBTSxDQUFDOzs7Ozs7O2lCQUN0QixDQUNGLENBQUMsQ0FDRCxJQUFJLENBQUMsaUJBQUksU0FBUyxDQUFDLEVBQUMsTUFBTSxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDbkMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7U0FDWCxDQUNGOzs7Ozs7O0NBQ0Ysb0NBS1MsR0FBRyxlQUFZLG9CQUFDLE1BQU07TUFFMUIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsUUFBUSxFQUNSO2NBSVEsTUFBTSxFQUNOLGNBQWMsRUFJZCxNQUFNLEVBUU4sT0FBTyxFQUtQLFNBQVMsRUFJWCxFQUFFLEVBQ0YsUUFBUSxFQUNSLElBQUksRUFHSixNQUFNLEVBQ04sTUFBTSxFQTZDTixHQUFHOzs7Ozs7QUF6RUQsc0JBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFHbkMsc0JBQU0sR0FBRyxtQ0FBVyxNQUFNLENBQUMsVUFBVSxDQUFDOzs7Z0RBSXBDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7OztBQUkvQix1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPOztnREFDM0IscUJBQVEsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFDdkIscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7O0FBR3RCLHlCQUFTLEdBQU0sTUFBTSxDQUFDLE9BQU87O2dEQUM3QixxQkFBUSxNQUFNLENBQUMsU0FBUyxDQUFDOzs7O2dEQUN6QixxQkFBUSxLQUFLLENBQUMsU0FBUyxDQUFDOzs7QUFFMUIsa0JBQUUsR0FBRyxJQUFJO0FBQ1Qsd0JBQVEsR0FBRyxJQUFJO0FBQ2Ysb0JBQUksR0FBRyxJQUFJO0FBR1gsc0JBQU0sR0FBRyxDQUFDLE1BQU0sRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxnQkFBZ0IsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLE9BQU8sRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsWUFBWSxFQUFFLFlBQVksRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLFlBQVksRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBRSxXQUFXLEVBQUUsUUFBUSxFQUFFLEtBQUssRUFBRSxjQUFjLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLFFBQVEsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFdBQVcsRUFBRSxvQkFBb0IsRUFBRSxpQkFBaUIsRUFBRSxNQUFNLEVBQUUsV0FBVyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsZ0JBQWdCLENBQUM7QUFDOXBDLHNCQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFDOytCQUFRLENBQUM7aUJBQUcsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJOzs7QUFHdkQsc0JBQU0sQ0FBQyxhQUFhLEdBQUcsb0JBQU8sV0FBVzs7OztBQUN2Qyw0QkFBSSxHQUFHLE1BQU0sR0FBRyxDQUFDLE9BQU8sR0FBRyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQ2pELDBCQUFFLEdBQU0sT0FBTyxTQUFJLElBQU07QUFDekIsZ0NBQVEsR0FBTSxFQUFFLFNBQUksTUFBTSxDQUFDLFdBQWE7O3dEQUNsQyxxQkFBUSxLQUFLLENBQUMsRUFBRSxDQUFDOzs7O3dEQUVqQixxQkFBUSxVQUFVLENBQUMsUUFBUSxFQUFFLHVCQUFNLE1BQU0sQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7Ozs7Ozs7aUJBQ3RFOzs7QUFHRCxzQkFBTSxDQUFDLFFBQVEsR0FBRyxvQkFBTyxHQUFHO3NCQUN0QixLQUFLLEVBQ0wsSUFBSSxFQUVKLE1BQU0sa0ZBR0QsR0FBRyxFQUNOLE1BQU0sRUFDTixNQUFNOzs7OztBQVJSLDZCQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUs7QUFDakIsNEJBQUksR0FBRyxHQUFHLENBQUMsSUFBSTtBQUVmLDhCQUFNLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxXQUFDLEVBQUk7QUFBRSxpQ0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFNLElBQUk7eUJBQUUsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsR0FBRyxJQUFJOzt3REFDckYscUJBQVEsVUFBVSxDQUFDLFFBQVEsRUFBRSx1QkFBTSxNQUFNLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDOzs7Ozs7O29DQUVyRCxJQUFJLENBQUMsTUFBTTs7Ozs7Ozs7QUFBbEIsMkJBQUc7QUFDTiw4QkFBTSxHQUFNLE1BQU0sQ0FBQyxRQUFRLFNBQUksR0FBRztBQUNsQyw4QkFBTSxHQUFNLEVBQUUsU0FBSSxHQUFHOzs7d0RBR2pCLHFCQUFRLE1BQU0sQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7Ozs7d0RBRXRCLHFCQUFRLFFBQVEsQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lCQUczQzs7O0FBR0Qsc0JBQU0sQ0FBQyxXQUFXLEdBQUcsb0JBQU8sV0FBVztzQkFDL0IsR0FBRyxFQUNILE9BQU8sRUFDUCxNQUFNOzs7O0FBRk4sMkJBQUcsR0FBRywyQkFBUyxLQUFLLENBQUM7QUFDckIsK0JBQU8sR0FBTSxTQUFTLFNBQUksSUFBSTtBQUM5Qiw4QkFBTSxHQUFHLHFCQUFRLGlCQUFpQixDQUFDLE9BQU8sQ0FBQzs7QUFDakQsMkJBQUcsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ2hCLDJCQUFHLENBQUMsU0FBUyxDQUFDLEVBQUUsRUFBRSxLQUFLLENBQUM7QUFDeEIsMkJBQUcsQ0FBQyxRQUFRLEVBQUU7Ozs7Ozs7aUJBQ2Y7Ozs7OztnREFLZSxNQUFNLENBQUMsT0FBTyxDQUFDOztBQUU3QiwwQkFBUSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPO3dCQUN4QixRQUFRLEVBR04sS0FBSzs7Ozs7MERBSFUsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOzs7QUFBbEQsa0NBQVE7O2dDQUVSLFFBQVEsSUFBSSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXOzs7Ozs7MERBQ3ZCLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLFdBQVEsRUFBRSxJQUFJLENBQUM7OztBQUFuRSwrQkFBSzs7MERBQ0gsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLEtBQUssRUFBRSxLQUFLLEVBQUUsSUFBSSxFQUFFLElBQUksRUFBQyxDQUFDOzs7Ozs7O21CQUVsRCxFQUFDLENBQUM7OztBQVRELG1CQUFHOztBQVdQLHNCQUFNLENBQUMsS0FBSyxFQUFFOztvREFFUCxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0JBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7UUNuS0ssK0JBQStCOztRQUUvQixzQkFBc0IsRTs7Ozs7Ozs7Ozs7Ozs7OzJCQ0ZQLGNBQWM7O0FBRTdCLElBQU0sT0FBTyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFNBQVMsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MkJDQXhFLGNBQWM7O3lCQUNILGVBQWU7Ozs7NEJBRzFCLGVBQWU7Ozs7b0JBR0wsTUFBTTs7OzsyQkFDSCxhQUFhOzs7O3NCQUNQLFVBQVU7O0FBRXBDLElBQU0sT0FBTyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFNBQVMsRUFBRTtBQUM5QyxjQUFZLEVBQUUsT0FBTztDQUN0QixDQUFDLENBQUM7O0lBRVUsTUFBTTtZQUFOLE1BQU07O0FBRU4sV0FGQSxNQUFNLENBRUwsUUFBUSxFQUFFOzs7MEJBRlgsTUFBTTs7QUFJZixRQUFJLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQzVCLFNBQUcsRUFBRSxRQUFRO0tBQ2QsQ0FBQyxDQUFDOztBQUVILCtCQVJTLE1BQU0sNkNBUVQsT0FBTyxFQUFFOztBQUVmLFFBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs7QUFFMUIsWUFBUSxJQUFJLENBQUMsSUFBSTs7QUFFZixXQUFLLE9BQU87QUFDVixZQUFJLENBQUMsS0FBSyxHQUFHLDJCQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxZQUFJLFVBQU8sR0FBRztjQUFRLFFBQVEseURBQUcsVUFBQyxNQUFNLEVBQUcsRUFBRTtjQUFFLE9BQU8seURBQUcsVUFBQyxDQUFDLEVBQUcsRUFBRTtjQUMxRCxHQUFHOzs7O0FBQUgsbUJBQUcsc0JBQW9CLElBQUksQ0FBQyxLQUFLOztnREFDeEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUM7Ozs7Ozs7Ozs7U0FDL0QsQ0FBQztBQUNGLGNBQU07O0FBRVI7QUFDRSxjQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7O0FBQUEsS0FFNUM7R0FDRjs7Ozs7OztlQTFCVSxNQUFNOztXQWdDSjs7O1VBQUMsU0FBUyx5REFBRyxFQUFFO1VBQUUsT0FBTyx5REFBRyxvQkFBTyxDQUFDOzs7Ozs7OztPQUFPOztVQUVqRCxPQUFPLEVBUVAsS0FBSyxrRkFDQSxNQUFNOzs7Ozs7O0FBVFgsbUJBQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFOzs7QUFHL0IsbUJBQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ25CLGtCQUFJLEVBQUUsTUFBTTtBQUNaLG1CQUFLLEVBQUUsRUFBRTthQUNWLENBQUM7O0FBRUUsaUJBQUssR0FBRyxFQUFFOzs7Ozs7QUFDZCw2QkFBbUIsT0FBTyxDQUFDLE9BQU8sdUhBQUU7QUFBM0Isb0JBQU07O0FBQ2IsbUJBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFDbkIscUJBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixxQkFBSyxFQUFFLENBQUM7ZUFDVCxDQUFDO2FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBRUssSUFBSSxVQUFPLENBQ2Ysb0JBQU8sTUFBTTt1R0FDRixNQUFNLEVBQ1QsS0FBSyxFQUNMLElBQUk7Ozs7Ozs7OztpQ0FGUyxPQUFPLENBQUMsT0FBTzs7Ozs7Ozs7QUFBekIsMEJBQU07QUFDVCx5QkFBSyxHQUFHLHlCQUFRLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3RDLHdCQUFJLEdBQUcsdUJBQU0sS0FBSyxDQUFFOzt5QkFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQzs7Ozs7QUFDZCx5QkFBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7MEJBQ3ZCLE9BQU8sU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXOzs7Ozs7b0RBQ3pDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2FBSzNDLEVBQ0QsT0FBTyxDQUNSOzs7Z0RBR00sS0FBSzs7Ozs7OztLQUViOzs7U0F0RVUsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQ2ZaLGNBQWM7O3lCQUNILGVBQWU7Ozs7NEJBRzFCLGVBQWU7O0FBRXRCLElBQU0sTUFBTSxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFFBQVEsRUFBRTtBQUM1QyxjQUFZLEVBQUUsT0FBTztDQUN0QixDQUFDLENBQUM7O0lBRVUsU0FBUztBQUlULFdBSkEsU0FBUyxDQUlSLE9BQU8sRUFBRTswQkFKVixTQUFTOztBQUtsQixRQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztHQUN4Qjs7Ozs7Ozs7ZUFOVSxTQUFTOztXQWFiLG1CQUFHO0FBQ1IsYUFBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztLQUNsQzs7O1dBRVMsc0JBQUc7QUFDWCxhQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7S0FDckI7OztXQUVNLG1CQUE2RDs7O1VBQTVELFFBQVEseURBQUcsb0JBQU8sTUFBTTs7Ozs7Ozs7T0FBTztVQUFFLE9BQU8seURBQUcsb0JBQU8sQ0FBQzs7Ozs7Ozs7T0FBTztLQUFJOzs7U0FyQjNELFNBQVM7Ozs7O0lBeUJULEtBQUs7WUFBTCxLQUFLOztBQUVMLFdBRkEsS0FBSyxDQUVKLE9BQU8sRUFBRTs7OzBCQUZWLEtBQUs7O0FBSWQsUUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMzQixTQUFHLEVBQUUsT0FBTztLQUNiLENBQUMsQ0FBQzs7QUFFSCwrQkFSUyxLQUFLLDZDQVFSLE9BQU8sRUFBRTs7QUFFZixRQUFJLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7O0FBRTFCLFlBQVEsSUFBSSxDQUFDLElBQUk7QUFDZixXQUFLLE9BQU87QUFDVixZQUFJLENBQUMsS0FBSyxHQUFHLDJCQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxZQUFJLFVBQU8sR0FBRyxvQkFBTyxHQUFHO2NBQ2xCLEdBQUc7Ozs7QUFBSCxtQkFBRyxzQkFBb0IsSUFBSSxDQUFDLEtBQUssZ0JBQVksR0FBRyxDQUFDLEdBQUcsYUFBUyxHQUFHLENBQUMsRUFBRTs7Z0RBQzFELElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs7OztTQUNuQyxDQUFDO0FBQ0YsY0FBTTtBQUNSO0FBQ0UsY0FBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQUEsS0FDekM7R0FFRjs7Ozs7OztlQXhCVSxLQUFLOztXQStCVCxtQkFBNkQ7OztVQUE1RCxRQUFRLHlEQUFHLG9CQUFPLE1BQU07Ozs7Ozs7O09BQU87VUFBRSxPQUFPLHlEQUFHLG9CQUFPLENBQUM7Ozs7Ozs7O09BQU87O0FBRWhFLFVBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDcEIsZUFBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRztPQUMxQixFQUFFO0FBQ0QsY0FBTSxFQUFFO0FBQ04sYUFBRyxFQUFFLENBQUM7QUFDTixZQUFFLEVBQUUsQ0FBQztBQUNMLGFBQUcsRUFBRSxDQUFDO1NBQ1A7T0FDRixDQUFDLENBQUM7O0FBRUgsYUFBTyxJQUFJLE9BQU8sQ0FDaEIsVUFBQyxPQUFPLEVBQUUsTUFBTSxFQUFLOztBQUVuQixXQUFHLENBQUMsT0FBTyxDQUNULG9CQUFPLEdBQUcsRUFBRSxLQUFLO2NBRVQsTUFBTTs7Ozs7O2dEQUFTLElBQUksVUFBTyxDQUFDLEdBQUcsQ0FBQzs7O0FBQS9CLHNCQUFNOztnREFDSixRQUFRLENBQUMsTUFBTSxDQUFDOzs7Ozs7Ozs7O0FBRXRCLHVCQUFPLGdCQUFHLENBQUM7OztBQUViLG9CQUFJLEtBQUssR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQzdCLHlCQUFPLEVBQUUsQ0FBQztpQkFDWDs7Ozs7OztTQUNGLENBQUMsQ0FBQztPQUVOLENBQ0YsU0FBTSxDQUNMLFVBQUMsQ0FBQyxFQUFLO0FBQ0wsY0FBTSxDQUFDLENBQUM7T0FDVCxDQUNGLENBQUM7S0FFSDs7O1NBbEVVLEtBQUs7R0FBUyxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQ0NyQ2xCLDBCQUEwQjs7OztJQUUvQixRQUFROzs7Ozs7QUFLUCxXQUxELFFBQVEsQ0FLTixLQUFLLEVBQUU7MEJBTFQsUUFBUTs7QUFNakIsUUFBSSxDQUFDLE1BQU0sR0FBRyxLQUFLO0dBQ3BCOztlQVBVLFFBQVE7O1dBU0QscUJBQUMsY0FBYztVQUFFLFFBQVEseURBQUcsQ0FBQzs7Ozs7NENBQ3ZDLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUMzQixtQkFBbUIsMEJBQ0csY0FBYyxFQUNwQyxFQUFFLEVBQUU7QUFDRixtQkFBSyxFQUFFLFFBQVE7QUFDZiw2QkFBZSxFQUFFLENBQUM7QUFDbEIseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7Ozs7NENBRUssSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQzNCLG1CQUFtQiwwQkFDRyxjQUFjLEVBQ3BDLEVBQUUsRUFBRTtBQUNGLG1CQUFLLEVBQUUsUUFBUTtBQUNmLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7Ozs7O0tBQ0Y7OztXQUVzQiwwQkFBQyxJQUFJO1VBQ3RCLFNBQVMsRUFFVCxHQUFHLEVBR0gsTUFBTSxFQVNOLEtBQUssa0ZBc0JBLE1BQU07Ozs7Ozs7QUFwQ1gscUJBQVMsR0FBRyxJQUFJLENBQUMsVUFBVTtBQUUzQixlQUFHLEdBQUcsRUFBRTs7QUFHUixrQkFBTSxHQUFHLFNBQVQsTUFBTSxDQUFVLEdBQUc7a0JBQ2pCLEdBQUc7Ozs7QUFBSCx1QkFBRyx1RUFFYyxJQUFJLENBQUMsVUFBVSxtQkFBYyxHQUFHO3FDQUVyRCxHQUFHOztvREFBWSxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7Ozs7bUNBQWpDLElBQUk7Ozs7Ozs7YUFDVDs7QUFHRyxpQkFBSyxHQUFHLFNBQVIsS0FBSyxDQUFVLEdBQUc7a0JBRWhCLEdBQUcsRUFJSCxRQUFROzs7O0FBSlIsdUJBQUcsZ0ZBRWMsSUFBSSxDQUFDLFVBQVUsbUJBQWMsR0FBRzs7b0RBRWhDLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQXZDLDRCQUFROzt5QkFDUixRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUMsVUFBVSxDQUFDOzs7Ozs7OztxQ0FFM0IsR0FBRzs7b0RBQ0ssSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQzNCLGlCQUFpQixFQUNqQixFQUFFLEVBQ0Y7QUFDRSxnQ0FBVSxFQUFFLElBQUksQ0FBQyxVQUFVO0FBQzNCLHlCQUFHLEVBQUUsR0FBRztBQUNSLGdDQUFVLEVBQUUsU0FBUztBQUNyQixpQ0FBVyxFQUFFLE9BQU87cUJBQ3JCLENBQ0Y7Ozs7bUNBVkMsSUFBSTs7Ozs7OzthQVdUOzs7Ozs7d0JBRWtCLElBQUksQ0FBQyxJQUFJOzs7Ozs7OztBQUFuQixrQkFBTTs2QkFDTCxNQUFNLENBQUMsR0FBRztrREFDWCxJQUFJLDJCQUdKLEtBQUs7Ozs7OzRDQUZGLEtBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDOzs7Ozs7OzRDQUdqQixNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dEQUt2QjtBQUNMLGlCQUFHLEVBQUUsR0FBRzthQUNUOzs7Ozs7O0tBQ0Y7OztXQUV3Qiw0QkFBQyxJQUFJO1VBQ3hCLFNBQVMsRUFDVCxNQUFNLEVBQ04sU0FBUyxFQUVULEdBQUcsRUFHSCxHQUFHLEVBR0UsQ0FBQzs7OztBQVZOLHFCQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVU7QUFDM0Isa0JBQU0sR0FBRyxJQUFJLENBQUMsTUFBTTtBQUNwQixxQkFBUyxHQUFHLElBQUksQ0FBQyxVQUFVO0FBRTNCLGVBQUcsR0FBRyxFQUFFO0FBR1IsZUFBRyx5REFBdUQsU0FBUzs2QkFDdkUsR0FBRzs7NENBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7OzJCQUFqQyxJQUFJO0FBRUMsYUFBQyxHQUFHLENBQUM7OztrQkFBRSxDQUFDLEdBQUcsTUFBTSxDQUFDLE1BQU07Ozs7Ozs0Q0FDekIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQzNCLG1CQUFtQixFQUFFO0FBQ25CLHdCQUFVLEVBQUUsU0FBUztBQUNyQix3QkFBVSxFQUFFLFNBQVM7QUFDckIsdUJBQVMsRUFBRSxNQUFNLENBQUMsQ0FBQyxDQUFDO0FBQ3BCLGtCQUFJLEVBQUUsQ0FBQyxHQUFHLENBQUM7YUFDWixFQUFFO0FBQ0QseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQVZnQyxhQUFDLEVBQUU7Ozs7O2dEQWEvQjtBQUNMLGlCQUFHLEVBQUUsR0FBRzthQUNUOzs7Ozs7O0tBQ0Y7OztXQUVtQix1QkFBQyxJQUFJO1VBQ25CLFVBQVUsRUFDVixJQUFJLHVGQW9DQyxDQUFDLHVGQUlOLEdBQUc7Ozs7O0FBekNILHNCQUFVLEdBQUcsRUFBRTtBQUNmLGdCQUFJLEdBQUcsRUFBRTs7OztBQUliLGdCQUFJLEdBQUcsQ0FDTCxRQUFRLEVBQ1IsTUFBTSxFQUNOLE1BQU0sRUFDTixrQkFBa0IsRUFDbEIsb0JBQW9CLEVBQ3BCLGFBQWEsRUFDYixXQUFXLENBQ1o7Ozs7O0FBQ0QsOEJBQWMsSUFBSSwySEFBRTtBQUFYLGVBQUM7O0FBQ1Isa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3JDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUVLLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUMzQixhQUFhLG9CQUNHLElBQUksQ0FBQyxVQUFVLEVBQy9CLFVBQVUsRUFBRTtBQUNWLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7Ozs7QUFJRCxzQkFBVSxHQUFHLEVBQUU7QUFDZixnQkFBSSxHQUFHLENBQ0wsa0JBQWtCLEVBQ2xCLGNBQWMsRUFDZCxZQUFZLEVBQ1osU0FBUyxFQUNULFNBQVMsRUFDVCxjQUFjLENBQ2Y7Ozs7O0FBQ0QsOEJBQWMsSUFBSSwySEFBRTtBQUFYLGVBQUM7O0FBQ1Isa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3JDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUVlLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUNyQyxtQkFBbUIsb0JBQ0gsSUFBSSxDQUFDLFVBQVUsRUFDL0IsVUFBVSxFQUFFO0FBQ1YseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQU5HLGVBQUc7Z0RBUUE7QUFDTCxpQkFBRyxFQUFFLEdBQUc7YUFDVDs7Ozs7OztLQUNGOzs7V0FFbUIsdUJBQUMsSUFBSTtVQUNuQixTQUFTLEVBRVQsR0FBRyxFQUVILFVBQVUsRUFDVixJQUFJLHVGQStEQyxDQUFDOzs7OztBQXBFTixxQkFBUyxHQUFHLElBQUksQ0FBQyxVQUFVO0FBRTNCLGVBQUcsR0FBRyxFQUFFO0FBRVIsc0JBQVUsR0FBRyxFQUFFO0FBQ2YsZ0JBQUksR0FBRyxFQUFFOztBQUViLGdCQUFJLEdBQUcsQ0FDTCxNQUFNLEVBQ04sb0JBQW9CLENBQ3JCOzs7Ozs7Ozs7O0FBTUQsOEJBQWMsSUFBSSwySEFBRTtBQUFYLGVBQUM7O0FBQ1Isa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3JDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUVzQixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDNUMsYUFBYSxFQUNiLFVBQVUsRUFBRTtBQUNWLHdCQUFVLEVBQUUsU0FBUztBQUNyQixvQkFBTSxFQUFFLENBQUM7QUFDVCxrQkFBSSxFQUFFLE1BQU07QUFDWiw4QkFBZ0IsRUFBRSxNQUFNO0FBQ3hCLHlCQUFXLEVBQUUsTUFBTTtBQUNuQix1QkFBUyxFQUFFLE1BQU07QUFDakIseUJBQVcsRUFBRSxPQUFPO0FBQ3BCLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFaRCxlQUFHLENBQUMsVUFBVTs7QUFjZCxzQkFBVSxHQUFHLEVBQUU7QUFDZixnQkFBSSxHQUFHLENBQ0wsY0FBYyxFQUNkLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsU0FBUyxFQUNULGNBQWMsQ0FDZjs7Ozs7Ozs7Ozs7QUFPRCw4QkFBYyxJQUFJLDJIQUFFO0FBQVgsZUFBQzs7QUFDUixrQkFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUM7YUFDckM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBRTRCLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUNsRCxtQkFBbUIsRUFDbkIsVUFBVSxFQUFFO0FBQ1Ysd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHdCQUFVLEVBQUUsR0FBRyxDQUFDLFVBQVU7QUFDMUIsbUJBQUssRUFBRSxDQUFDO0FBQ1IsNkJBQWUsRUFBRSxDQUFDO0FBQ2xCLGdDQUFrQixFQUFFLE1BQU07QUFDMUIsZ0NBQWtCLEVBQUUsTUFBTTtBQUMxQiw4QkFBZ0IsRUFBRSxNQUFNO0FBQ3hCLHdCQUFVLEVBQUUsTUFBTTtBQUNsQix5QkFBVyxFQUFFLE9BQU87QUFDcEIseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQWRELGVBQUcsQ0FBQyxnQkFBZ0I7Ozs7OztBQWdCcEIsOEJBQWMsSUFBSSwySEFBRTtBQUFYLGVBQUM7O0FBQ1Isa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3JDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUU0QixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDbEQsbUJBQW1CLEVBQUUsRUFBRSxFQUFFO0FBQ3ZCLDhCQUFnQixFQUFFLEdBQUcsQ0FBQyxnQkFBZ0I7QUFDdEMsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLG1CQUFLLEVBQUUsQ0FBQztBQUNSLHlCQUFXLEVBQUUsT0FBTztBQUNwQix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBUkQsZUFBRyxDQUFDLGdCQUFnQjtnREFXYjtBQUNMLGlCQUFHLEVBQUUsR0FBRzthQUNUOzs7Ozs7O0tBQ0Y7OztTQTlQVSxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQ0ZILGVBQWU7Ozs7dUJBQ1AsU0FBUzs7OEJBQ2YsaUJBQWlCOzs7Ozs7b0JBR3BCLE1BQU07Ozs7MkJBQ0gsYUFBYTs7OztxQkFDVixRQUFROztJQUVsQixlQUFlLEdBQ2QsU0FERCxlQUFlLENBQ2IsSUFBSSxFQUFFLE9BQU8sRUFBRTt3QkFEakIsZUFBZTs7QUFFeEIsTUFBSSxRQUFRO0FBQ1osVUFBUSxJQUFJLENBQUMsSUFBSTtBQUNmLFNBQUssT0FBTztBQUNWLGNBQVEsR0FBRyxJQUFJLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO0FBQUEsR0FDOUM7O0FBRUQsU0FBTyxRQUFRO0NBQ2hCOzs7O0lBR1UsUUFBUTtBQUNQLFdBREQsUUFBUSxDQUNOLElBQUksRUFBRSxPQUFPLEVBQUU7MEJBRGpCLFFBQVE7O0FBRWpCLFFBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSTtBQUNoQixRQUFJLENBQUMsT0FBTyxHQUFHLE9BQU87R0FDdkI7O2VBSlUsUUFBUTs7V0FlVixvQkFBRztBQUNWLGFBQU8sSUFBSSxDQUFDLElBQUk7S0FDakI7OztXQUVRLG9CQUFHO0FBQ1YsYUFBTyxJQUFJLENBQUMsSUFBSSxDQUFDLElBQUk7S0FDdEI7OztXQUVXLHVCQUFHO0FBQ2IsYUFBTyxJQUFJLENBQUMsT0FBTztLQUNwQjs7O1dBRWtCLDhCQUVqQjs7O1VBREEsRUFBRSx5REFBRztZQUFPLFFBQVEseURBQUcsZ0JBQU0sRUFBSSxFQUFFO1lBQUUsT0FBTyx5REFBRyxXQUFDLEVBQUksRUFBRTs7Ozs7Ozs7T0FBTzs7QUFFN0QsVUFBSSxVQUFPLEdBQUcsRUFBRTtLQUNqQjs7Ozs7Ozs7Ozs7OztXQVdhO1VBQUMsU0FBUyx5REFBRyxFQUFFOztVQUN2QixPQUFPLEVBUVAsT0FBTyxrRkFNRixDQUFDLEVBRk4sT0FBTzs7Ozs7OztBQVpQLG1CQUFPLEdBQUcsSUFBSSxDQUFDLFdBQVcsRUFBRTs7O0FBR2hDLG1CQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUNuQixrQkFBSSxFQUFFLE1BQU07QUFDWixtQkFBSyxFQUFFLEVBQUU7YUFDVixDQUFDOztBQUVFLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBQ2hCLDZCQUFjLE9BQU8sQ0FBQyxPQUFPLHVIQUFFO0FBQXRCLGVBQUM7YUFDVDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUcsbUJBQU8sR0FBRyxFQUFFOzs7Ozs7QUFFaEIsOEJBQWMsT0FBTyxDQUFDLE9BQU8sMkhBQUU7QUFBdEIsZUFBQzs7QUFDUixxQkFBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRztBQUNoQixxQkFBSyxFQUFFLENBQUMsQ0FBQyxLQUFLO0FBQ2QscUJBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssV0FBVyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQztBQUNuRCxxQkFBSyxFQUFFLENBQUM7ZUFDVDtBQUNELHFCQUFPLENBQUMsSUFBSSxDQUNWO0FBQ0Usb0JBQUksRUFBRSxDQUFDLENBQUMsSUFBSTtBQUNaLG9CQUFJLEVBQUUsdUJBQUsseUJBQVEsUUFBUSxDQUFDLENBQUMsQ0FBQyxLQUFLLENBQUMsQ0FBQztlQUN0QyxDQUNGO2FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBRUssSUFBSSxVQUFPLENBQ2Ysb0JBQU8sTUFBTSxFQUFFLE9BQU87dUdBQ1gsQ0FBQyxFQUVKLENBQUM7Ozs7Ozs7OztpQ0FGTyxPQUFPOzs7Ozs7OztBQUFaLHFCQUFDO0FBRUoscUJBQUMsR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQzs7eUJBQ25CLENBQUMsQ0FBQyxLQUFLOzs7OzswQkFDTCxDQUFDLENBQUMsS0FBSyxJQUFJLENBQUMsQ0FBQyxLQUFLOzs7Ozs7Ozt5QkFLcEIsQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7Ozs7OztBQUVoQixxQkFBQyxDQUFDLEtBQUssRUFBRTs7OzswQkFHTCxPQUFPLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssV0FBVzs7Ozs7O29EQUNwQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7YUFLL0MsQ0FBQzs7O2dEQUdHLE9BQU87Ozs7Ozs7S0FDZjs7O1dBM0ZjLGlCQUFDLElBQUksRUFBRSxPQUFPLEVBQUU7QUFDN0IsY0FBUSxJQUFJLENBQUMsSUFBSTtBQUNmLGFBQUssT0FBTztBQUNWLGlCQUFPLElBQUksYUFBYSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7QUFDekM7QUFDRSxnQkFBTSxJQUFJLEtBQUssQ0FBQyxtQkFBbUIsQ0FBQztBQUFBLE9BQ3ZDO0tBQ0Y7OztTQWJVLFFBQVE7Ozs7O0lBb0dSLGFBQWE7WUFBYixhQUFhOztBQUNaLFdBREQsYUFBYSxDQUNYLElBQUksRUFBRSxPQUFPLEVBQUU7OzswQkFEakIsYUFBYTs7QUFFdEIsK0JBRlMsYUFBYSw2Q0FFaEIsSUFBSSxFQUFFLE9BQU8sRUFBQzs7QUFFcEIsUUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLFFBQVEsRUFBRTs7QUFFMUIsUUFBSSxDQUFDLEtBQUssR0FBRywyQkFBVSxJQUFJLENBQUM7QUFDNUIsUUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFPLFFBQVEsRUFBRSxPQUFPO1VBQzFDLEdBQUcsRUFDSCxHQUFHOzs7O0FBREgsZUFBRyxzQkFBb0IsSUFBSSxDQUFDLEtBQUs7OzRDQUNyQixJQUFJLENBQUMsS0FBSyxDQUFDLGNBQWMsQ0FBQyxHQUFHLEVBQUUsUUFBUSxFQUFFLFVBQUMsQ0FBQyxFQUFLO0FBQUUsb0JBQU0sQ0FBQzthQUFFLENBQUM7OztBQUF4RSxlQUFHO2dEQUNBLEdBQUc7Ozs7Ozs7S0FDWCxDQUFDO0dBQ0g7Ozs7OztTQVpVLGFBQWE7R0FBUyxRQUFROzs7O0lBbUI5QixhQUFhO1lBQWIsYUFBYTs7QUFDWixXQURELGFBQWEsQ0FDWCxJQUFJLEVBQUUsT0FBTyxFQUFFOzs7MEJBRGpCLGFBQWE7O0FBRXRCLCtCQUZTLGFBQWEsNkNBRWhCLElBQUksRUFBRSxPQUFPLEVBQUM7OztBQUdwQixRQUFJLENBQUMsa0JBQWtCLENBQUMsb0JBQU8sUUFBUSxFQUFFLE9BQU87VUFDMUMsTUFBTSxFQUlOLEVBQUUsRUFDRixVQUFVLEVBRVYsT0FBTyxFQU1QLEdBQUcsRUFRQyxHQUFHOzs7O0FBckJQLGtCQUFNOzs0Q0FDSyxxQkFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7O0FBQTVDLGtCQUFNO0FBR0YsY0FBRSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUM3QixzQkFBVSxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUUzQyxtQkFBTyxHQUFHO0FBQ1osb0JBQU0sRUFBRSxNQUFNO0FBQ2Qsd0JBQVUsRUFBRSxVQUFVO0FBQ3RCLHNCQUFRLEVBQUUsRUFBRTthQUNiO0FBRUcsZUFBRyxHQUFHLFVBQVUsQ0FBQyxJQUFJLEVBQUU7OztBQUczQixlQUFHLENBQUMsYUFBYSxDQUFDLGlCQUFpQixFQUFFLElBQUksQ0FBQzs7Ozs7Ozs0Q0FJM0IsR0FBRyxDQUFDLE9BQU8sRUFBRTs7Ozs7Ozs7OzRDQUNSLEdBQUcsQ0FBQyxJQUFJLEVBQUU7OztBQUF0QixlQUFHOzs0Q0FDRCxRQUFRLENBQUMsR0FBRyxFQUFFLE9BQU8sQ0FBQzs7Ozs7OztBQUM3QixhQUFDOzs7Ozs0Q0FHSSxHQUFHLENBQUMsS0FBSyxFQUFFOzs7Ozs7Ozs7O0tBRXBCLENBQUM7R0FDSDs7U0FuQ1UsYUFBYTtHQUFTLFFBQVE7Ozs7SUFzQzlCLGtCQUFrQjtZQUFsQixrQkFBa0I7O0FBQ2pCLFdBREQsa0JBQWtCLENBQ2hCLElBQUksRUFBRSxPQUFPLEVBQUU7OzswQkFEakIsa0JBQWtCOztBQUUzQiwrQkFGUyxrQkFBa0IsNkNBRXJCLElBQUksRUFBRSxPQUFPLEVBQUM7OztBQUdwQixRQUFJLENBQUMsa0JBQWtCLENBQUMsb0JBQU8sUUFBUSxFQUFFLE9BQU87VUFFMUMsT0FBTyxFQUVQLE9BQU8sRUFNTCxHQUFHLEVBR0gsUUFBUSxFQUNSLFdBQVcsRUFDWCxVQUFVLEVBQ1YsWUFBWSxFQUtMLENBQUMsRUFRUixJQUFJOzs7O0FBM0JOLG1CQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDOztBQUM5QyxtQkFBTyxDQUFDLEdBQUcsR0FBTSxPQUFPLENBQUMsR0FBRyxrQkFBZTtBQUN2QyxtQkFBTyxHQUFHO0FBQ1oscUJBQU8sRUFBRSxPQUFPO2FBQ2pCOzs7aUJBRU0sQ0FBQzs7Ozs7OzRDQUVVLGlDQUFRLE9BQU8sQ0FBQzs7O0FBQTVCLGVBQUc7O0FBQ1AsZUFBRyxHQUFHLG1CQUFPLEdBQUcsRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQzs7QUFFOUIsb0JBQVEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztBQUMzRCx1QkFBVyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO0FBQ2pFLHNCQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7QUFDL0Qsd0JBQVksR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxZQUFZOztrQkFHckQsWUFBWSxZQUFZLEtBQUs7Ozs7O0FBRXRCLGFBQUMsR0FBRyxDQUFDOzs7a0JBQUUsQ0FBQyxHQUFHLFdBQVc7Ozs7Ozs0Q0FDdkIsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUM7OztBQURULGFBQUMsRUFBRTs7Ozs7Ozs7Ozs0Q0FLOUIsUUFBUSxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUM7OztBQUduQyxnQkFBSSxHQUFHLFVBQVUsR0FBRyxXQUFXOztrQkFFL0IsSUFBSSxHQUFHLFFBQVE7Ozs7Ozs7O0FBQ25CLG1CQUFPLENBQUMsRUFBRSxDQUFDLFVBQVUsR0FBRyxJQUFJOzs7Ozs7Ozs7S0FFL0IsQ0FBQztHQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztTQXhDVSxrQkFBa0I7R0FBUyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQ2hMekMsZUFBZTs7MkJBR2YsZ0JBQWdCOztvQkFHaEIsTUFBTTs7d0JBQ0ssVUFBVTs7Ozt3QkFDUCxjQUFjOzs7O0lBRWQsY0FBYztXQUFkLGNBQWM7MEJBQWQsY0FBYzs7O2VBQWQsY0FBYzs7V0FDdEIsY0FBQyxJQUFJOzs7Ozs0Q0FDSywyQkFBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxPQUFPLENBQUM7OztBQUFyRCxnQkFBSSxDQUFDLEtBQUs7OzRDQUNZLDJCQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQzs7O0FBQTNELGdCQUFJLENBQUMsUUFBUTs7Ozs7OztLQUNkOzs7V0FFYyxrQkFBQyxNQUFNO1VBQ2hCLElBQUksRUFPSixVQUFVLEVBUVYsVUFBVSxrRkFFTCxVQUFVLEVBQ2IsV0FBVyx1RkFFTixFQUFFLEVBQ0wsT0FBTyxFQU9QLFVBQVUsdUZBR0wsS0FBSyxFQVVkLFFBQVE7Ozs7Ozs0Q0F6Q0ssSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDbEMsaUJBQUcsRUFBRSxNQUFNO2FBQ1osRUFBRTtBQUNELHdCQUFVLEVBQUU7QUFDVix5QkFBUyxFQUFFLENBQUM7ZUFDYjthQUNGLENBQUM7OztBQU5FLGdCQUFJO0FBT0osc0JBQVUsR0FBRyxJQUFJLENBQUMsT0FBTztBQVF6QixzQkFBVSxHQUFHLEVBQUU7Ozs7O3dCQUVJLFVBQVU7Ozs7Ozs7O0FBQXhCLHNCQUFVO0FBQ2IsdUJBQVcsR0FBRyxDQUFDOzs7Ozt5QkFFSixVQUFVLENBQUMsR0FBRzs7Ozs7Ozs7QUFBcEIsY0FBRTs7NENBQ1csSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDeEMsaUJBQUcsRUFBRSxFQUFFO2FBQ1IsRUFBRTtBQUNELHdCQUFVLEVBQUU7QUFDVix1QkFBTyxFQUFFLENBQUM7ZUFDWDthQUNGLENBQUM7OztBQU5FLG1CQUFPO0FBT1Asc0JBQVUsR0FBRyxPQUFPLENBQUMsS0FBSzs7Ozs7OztBQUc5Qiw4QkFBa0IsVUFBVSwySEFBRTtBQUFyQixtQkFBSzs7QUFDWix5QkFBVyxJQUFJLEtBQUssQ0FBQyxRQUFRO2FBQzlCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSUgsc0JBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJdkQsb0JBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDO2dEQUV4QyxRQUFROzs7Ozs7O0tBQ2hCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBdUJjLGtCQUFDLFFBQVEsRUFBRSxLQUFLO1VBQUUsTUFBTSx5REFBRyxJQUFJO1VBQUUsTUFBTSx5REFBRyxJQUFJO1VBRXZELE1BQU0sRUFLTixNQUFNLEVBS04sR0FBRzs7OztBQVZILGtCQUFNLEdBQUcscUJBQVEsSUFBSSxDQUFDO0FBQ3hCLHNCQUFRLEVBQUUsUUFBUTthQUNuQixDQUFDLENBQUMsS0FBSyxFQUFFLENBQUMsR0FBRyxDQUFDLFVBQUMsQ0FBQztxQkFBSyxDQUFDLENBQUMsZ0JBQWdCO2FBQUEsQ0FBQztBQUdyQyxrQkFBTSxHQUFHLEVBQUU7O0FBQ2Ysa0JBQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSztBQUNwQixnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNO0FBQ3hDLGdCQUFJLE1BQU0sRUFBRSxNQUFNLENBQUMsWUFBWSxHQUFHLE1BQU07Ozs0Q0FFeEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQ25DLE1BQU0sRUFBRTtBQUNOLG1CQUFLLEVBQUU7QUFDTCxzQkFBTSxFQUFFO0FBQ04sdUJBQUssRUFBRSxNQUFNO2lCQUNkO2VBQ0Y7YUFDRixDQUNGOzs7QUFSRyxlQUFHO2dEQVdBLE1BQU07Ozs7Ozs7S0FDZDs7Ozs7Ozs7Ozs7O1dBVWdCLG9CQUFDLEtBQUs7VUFBRSxNQUFNLHlEQUFHLElBQUk7VUFBRSxNQUFNLHlEQUFHLElBQUk7VUFFL0MsTUFBTSxFQUtOLEdBQUc7Ozs7QUFMSCxrQkFBTSxHQUFHLEVBQUU7O0FBQ2Ysa0JBQU0sQ0FBQyxLQUFLLEdBQUcsS0FBSztBQUNwQixnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNO0FBQ3hDLGdCQUFJLE1BQU0sRUFBRSxNQUFNLENBQUMsWUFBWSxHQUFHLE1BQU07Ozs0Q0FFeEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQ25DLE1BQU0sRUFBRTtBQUNOLGtCQUFJLEVBQUU7QUFDSixzQkFBTSxFQUFFLEVBQUU7ZUFDWDthQUNGLENBQ0Y7OztBQU5HLGVBQUc7Ozs7Ozs7S0FPUjs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBZ0JrQixzQkFBQyxJQUFJLEVBQUUsT0FBTztVQVMzQixHQUFHLEVBbUNILEtBQUssdUZBRUEsQ0FBQyx1RkFzQkQsSUFBSSx1RkFDRixDQUFDOzs7OztBQTVEUixlQUFHLEdBQUcsQ0FBQztBQUNULG1CQUFLLEVBQUUsTUFBTTtBQUNiLHFCQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVE7QUFDdEIscUJBQU8sRUFBRTtBQUNQLHFCQUFLLEVBQUUsV0FBVztlQUNuQjtBQUNELG1CQUFLLEVBQUU7QUFDTCw0QkFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO0FBQy9CLDRCQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7ZUFDaEM7YUFDRixFQUNEO0FBQ0UsbUJBQUssRUFBRSxJQUFJLENBQUMsV0FBVztBQUN2QixxQkFBTyxFQUFFLElBQUksQ0FBQyxZQUFZO0FBQzFCLHFCQUFPLEVBQUU7QUFDUCxxQkFBSyxFQUFFLGVBQWU7ZUFDdkI7QUFDRCxtQkFBSyxFQUFFO0FBQ0wsd0JBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtBQUN2Qiw0QkFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO2VBQ2hDO2FBQ0YsRUFDRDtBQUNFLG1CQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVc7QUFDdkIscUJBQU8sRUFBRSxJQUFJLENBQUMsWUFBWTtBQUMxQixxQkFBTyxFQUFFO0FBQ1AscUJBQUssRUFBRSxlQUFlO2VBQ3ZCO0FBQ0QsbUJBQUssRUFBRTtBQUNMLHdCQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7QUFDdkIsNEJBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtlQUNoQzthQUNGLENBQ0E7QUFFRyxpQkFBSyxHQUFHLEVBQUU7Ozs7O3lCQUVBLEdBQUc7Ozs7Ozs7O0FBQVIsYUFBQzs2QkFDUixLQUFLOzs0Q0FDZSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDcEMsQ0FBQztBQUNDLG9CQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO0FBQzdCLHFCQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7ZUFDbEIsQ0FBQzthQUNILEVBQ0Q7QUFDRSxzQkFBUSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7YUFDNUMsRUFDRDtBQUNFLG1CQUFLLEVBQUU7QUFDTCxtQkFBRyxFQUFFLENBQUM7ZUFDUDthQUNGLENBQ0EsQ0FDRixDQUFDLE9BQU8sRUFBRTs7Ozs2QkFDSixDQUFDOztBQWhCUix3QkFBVTtBQWdCVixtQkFBSzs7MkJBakJELElBQUk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7eUJBcUJLLEtBQUs7Ozs7Ozs7O0FBQWIsZ0JBQUk7Ozs7O3lCQUNHLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUFwQixhQUFDOzs0Q0FDUSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUM7OztBQUFwQyxhQUFDLENBQUMsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dEQUlKLEtBQUs7Ozs7Ozs7S0FDYjs7Ozs7O1dBSW1CLHVCQUFDLEdBQUc7VUFDbEIsSUFBSSxFQUdGLEdBQUcsRUFDSCxHQUFHLEVBV0MsS0FBSyxFQWVYLFVBQVU7Ozs7QUE5QlYsZ0JBQUk7O2tCQUVKLE9BQU8sR0FBRyxLQUFLLFFBQVE7Ozs7O0FBQ3JCLGVBQUcsR0FBRyxJQUFJLE1BQU0sQ0FBSSxHQUFHLE9BQUk7QUFDM0IsZUFBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtBQUM1Qix3QkFBVSxFQUFFO0FBQ1YscUJBQUssRUFBRSxDQUFDO0FBQ1IsNEJBQVksRUFBRSxDQUFDO0FBQ2YsNEJBQVksRUFBRSxDQUFDO2VBQ2hCO2FBQ0YsQ0FBQzs7O2lCQUVLLENBQUM7Ozs7Ozs7NENBRVMsR0FBRyxDQUFDLElBQUksRUFBRTs7O0FBQXZCLGdCQUFJOzs0Q0FDYyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEvQyxpQkFBSzs7aUJBQ0wsS0FBSzs7Ozs7Ozs7Ozs7Ozs7OztBQUtULGVBQUcsQ0FBQyxLQUFLLEVBQUU7Z0RBQ0osR0FBRzs7Ozs7OztBQUdkLGVBQUcsQ0FBQyxLQUFLLEVBQUU7Ozs7O0FBRVgsZ0JBQUksR0FBRyxHQUFHOzs7QUFHUixzQkFBVSxHQUFHLEVBQUU7O0FBQ25CLGdCQUFJLElBQUksQ0FBQyxLQUFLLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQzNDLGdCQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO0FBQ3pELGdCQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDO2dEQUNsRCxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7Ozs7OztLQUM1Qjs7O1dBRXNCLDBCQUFDLFNBQVMsRUFBRSxJQUFJO1VBRWpDLFNBQVMsRUFHVCxTQUFTLEVBQ1QsVUFBVSxFQVNWLGFBQWEsRUFjYixJQUFJLEVBdUJKLFdBQVcsRUFjWCxLQUFLLEVBcUJMLGFBQWEsRUEyQmIsaUJBQWlCLEVBTWpCLElBQUk7Ozs7QUF0SEoscUJBQVMsR0FBRyxTQUFaLFNBQVMsQ0FBSSxRQUFRO3FCQUFLLFFBQVEsS0FBSyxRQUFRLEdBQUcsT0FBTyxHQUFHLFFBQVE7YUFBQTs7QUFHcEUscUJBQVMsR0FBRyxJQUFJO0FBQ2hCLHNCQUFVLEdBQUcsRUFBRTs7OztBQUluQixnQkFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUMzQyxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztBQUN6RCxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQzs7O0FBR3JELHlCQUFhOzZCQUNULElBQUksQ0FBQyxRQUFRO2tEQUNkLEtBQUssMkJBR0wsUUFBUTs7OztBQUZYLHlCQUFhLEdBQUcsQ0FBQzs7OztBQUdqQix5QkFBYSxHQUFHLENBQUM7Ozs7QUFHakIseUJBQWEsR0FBRyxDQUFDOzs7O0FBS2pCLGdCQUFJLEdBQUcsRUFBRTs2QkFDTCxJQUFJLENBQUMsUUFBUTtrREFDZCxLQUFLLDJCQVNMLFFBQVE7Ozs7QUFSWCxnQkFBSSxDQUFDLElBQUksQ0FBQztBQUNSLGlCQUFHLEVBQUUsQ0FBQztBQUNOLGlCQUFHLEVBQUUsSUFBSTthQUNWLEVBQUU7QUFDRCxpQkFBRyxFQUFFLENBQUM7QUFDTixpQkFBRyxFQUFFLEtBQUs7YUFDWCxDQUFDOzs7O0FBR0YsZ0JBQUksQ0FBQyxJQUFJLENBQUM7QUFDUixpQkFBRyxFQUFFLENBQUM7QUFDTixpQkFBRyxFQUFFLElBQUk7YUFDVixFQUFFO0FBQ0QsaUJBQUcsRUFBRSxDQUFDO0FBQ04saUJBQUcsRUFBRSxLQUFLO2FBQ1gsQ0FBQzs7OztBQUtGLHVCQUFXLEdBQUcsSUFBSTs2QkFDZCxJQUFJLENBQUMsUUFBUTtrREFDZCxLQUFLLDJCQUdMLFFBQVE7Ozs7QUFGWCx1QkFBVyxHQUFHLElBQUk7Ozs7QUFHbEIsdUJBQVcsR0FBRyxHQUFHOzs7Ozs0Q0FRSCxJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRTtBQUN4Qyx3QkFBVSxFQUFFLDhCQUE4QjthQUMzQyxDQUFDOzs7QUFGRSxpQkFBSzs7Ozs7QUFPVCxpQkFBSyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQ2YsVUFBQyxJQUFJLEVBQUs7QUFDUixrQkFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ2xELGtCQUFJLENBQUMsVUFBVSxHQUFHLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUNuQyxVQUFDLFNBQVMsRUFBSztBQUNiLHlCQUFTLENBQUMsS0FBSyxHQUFHLFNBQVMsQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDO0FBQzVDLHVCQUFPLFNBQVM7ZUFDakIsQ0FDRjtBQUNELHFCQUFPLElBQUk7YUFDWixDQUNGOzs7QUFHRyx5QkFBYSxHQUNmLEtBQUssQ0FBQyxHQUFHLENBQ1AsVUFBQyxJQUFJO3FCQUNILCtCQUErQixzQkFDZCxvRUFDOEMsaUJBQ3RELElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxlQUFXLFdBQzlCLEdBQ1IsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQ2pCLFVBQUMsU0FBUyxFQUFLO0FBQ2Isb0JBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEtBQUssU0FBUyxDQUFDLEtBQUssRUFBRTs7QUFFMUMsbUdBQStFLFNBQVMsQ0FBQyxLQUFLLHdCQUFvQjtpQkFDbkgsTUFDRCxJQUFJLFNBQVMsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxFQUFFOztBQUV2Qix3REFBb0MsU0FBUyxDQUFDLFVBQVUsdUVBQWtFLFNBQVMsQ0FBQyxLQUFLLG1CQUFlO2lCQUN6SixNQUFNOztBQUVMLHVKQUFtSSxTQUFTLENBQUMsS0FBSyxlQUFXO2lCQUM5SjtlQUNGLENBQ0YsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLEdBQ1YsUUFBUSxHQUNSLFFBQVE7YUFBQSxDQUNULENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztBQUVSLDZCQUFpQiw4REFFbkIsYUFBYTtBQUlYLGdCQUFJLEdBQUc7QUFDVCx3QkFBVSxFQUFFLFNBQVM7QUFDckIsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLGtCQUFJLEVBQUssVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBSSxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFJLElBQUksQ0FBQyxJQUFJLElBQUcsSUFBSSxDQUFDLFFBQVEsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFFBQVEsR0FBRyxFQUFFLENBQUU7QUFDbkgsZ0NBQWtCLEVBQUUsaUJBQWlCOztBQUVyQywwQkFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDO0FBQ2xDLHFCQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVk7OztBQUcxQiw2QkFBZSxFQUFFLGFBQWE7QUFDOUIsa0JBQUksRUFBRSxJQUFJO0FBQ1YsMEJBQVksRUFBRSxXQUFXO2FBQzFCOzZCQUVELE1BQU07NkJBQVEsSUFBSTs7NENBQVEsSUFBSSxDQUFDLDhCQUE4QixDQUFDLElBQUksQ0FBQzs7OzsyQkFBNUQsTUFBTTs2QkFDYixNQUFNOzZCQUFRLElBQUk7OzRDQUFRLElBQUksQ0FBQyw2QkFBNkIsQ0FBQyxJQUFJLENBQUM7Ozs7MkJBQTNELE1BQU07NkJBQ2IsTUFBTTs4QkFBUSxJQUFJOzs0Q0FBUSxJQUFJLENBQUMsNEJBQTRCLENBQUMsSUFBSSxDQUFDOzs7OzJCQUExRCxNQUFNOztBQUViLGtCQUFNLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQzs7Z0RBRW5DLElBQUk7Ozs7Ozs7S0FDWjs7O1dBRW9DLHdDQUFDLElBQUk7VUFDcEMsUUFBUSxFQUlILENBQUM7Ozs7QUFKTixvQkFBUSxHQUFHLEVBQUU7OztBQUVqQixvQkFBUSxJQUFJLElBQUksQ0FBQyxXQUFXOztBQUU1QixpQkFBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUMzQyxzQkFBUSxzQ0FBb0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBUTthQUNuRTs7QUFFRCxvQkFBUSxJQUFJLEdBQUc7Z0RBQ1IsRUFBQyxTQUFTLEVBQUUsUUFBUSxFQUFDOzs7Ozs7O0tBQzdCOzs7V0FFbUMsdUNBQUMsSUFBSTs7OztnREFFaEMsRUFBQyxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFDOzs7Ozs7O0tBQzlDOzs7V0FFa0Msc0NBQUMsSUFBSTtVQUVsQyxHQUFHOzs7O0FBQUgsZUFBRyxHQUFHLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHLENBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBRTtnREFDbEUsRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFOzs7Ozs7O0tBQ3ZCOzs7OztXQUdzQiwwQkFBQyxHQUFHLEVBQUUsSUFBSTtVQUN6QixRQUFRLEVBQ1IsV0FBVyxFQUViLEtBQUssRUFLSCxTQUFTLEVBQ04sQ0FBQzs7OztBQVRKLG9CQUFRLEdBQUcsRUFBRTtBQUNiLHVCQUFXLEdBQUcsR0FBRztBQUVuQixpQkFBSyxHQUFHLEVBQUU7OztBQUVkLGlCQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzs7O0FBR2hELHFCQUFTLEdBQUcsSUFBSTs7QUFDdEIsaUJBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDM0MsbUJBQUssQ0FBQyxTQUFTLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFDNUM7OztBQUdELGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUTs7OzRDQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDOzs7Ozs2QkFBSSxJQUFJLENBQUMsUUFBUTs7OzZCQUFJLElBQUksQ0FBQyxJQUFJOzs2QkFBSSxXQUFXO0FBQS9HLGlCQUFLLENBQUMsTUFBTSxDQUFDLGtCQUFZLE9BQU87O0FBQ2hDLGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVc7QUFDaEMsaUJBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVztBQUNoQyxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3ZELGlCQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVc7QUFDOUIsaUJBQUssQ0FBQyxnQkFBZ0IsQ0FBQyxHQUFHLElBQUksQ0FBQyxRQUFROztnREFFaEMsS0FBSzs7Ozs7OztLQUNiOzs7V0FFMEMsOENBQUMsUUFBUTtVQUM5QyxFQUFFLEVBQ0YsR0FBRyxFQUNILE9BQU8sRUFNUCxJQUFJLEVBdUJKLFdBQVcsdUZBQ04sR0FBRyxFQUdSLGNBQWMsRUFDVCxDQUFDLEVBQ0osR0FBRTs7Ozs7QUFyQ0osY0FBRSxHQUFHLHFCQUFxQjtBQUMxQixlQUFHLEdBQUcsVUFBVTtBQUNoQixtQkFBTyxHQUFHO0FBQ1osc0JBQVEsRUFBRSxDQUFDLE1BQU0sQ0FBQztBQUNsQixtQkFBSyxFQUFFLENBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQzthQUMvQjs7NENBR2dCLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUNuQyxDQUNFO0FBQ0Usb0JBQU0sc0JBQ0gsRUFBRSxFQUFHLFFBQVEsQ0FDZjthQUNGLEVBQ0Q7QUFDRSxvQkFBTTtBQUNKLG1CQUFHLFFBQU0sRUFBSTtpQkFDWixHQUFHLEVBQUcsRUFBRSxTQUFTLFFBQU0sR0FBSyxFQUFFLENBQ2hDO2FBQ0YsRUFDRDtBQUNFLHNCQUFRO0FBQ04sbUJBQUcsRUFBRSxDQUFDO0FBQ04sd0JBQVEsRUFBRSxNQUFNO2lCQUNmLEdBQUcsUUFBTyxHQUFHLENBQ2Y7YUFDRixDQUNGLENBQ0YsQ0FBQyxPQUFPLEVBQUU7OztBQXJCUCxnQkFBSTtBQXVCSix1QkFBVyxHQUFHLEVBQUU7Ozs7OztBQUNwQiw4QkFBZ0IsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsMkhBQUU7QUFBekIsaUJBQUc7O0FBQ1YseUJBQVcsR0FBRyxXQUFXLENBQUMsTUFBTSxDQUFDLE9BQU8sTUFBSSxHQUFHLENBQUcsQ0FBQzthQUNwRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRywwQkFBYyxHQUFHLElBQUksS0FBSyxDQUFDLENBQUMsQ0FBQzs7QUFDakMsaUJBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsY0FBYyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUMxQyxpQkFBRSxHQUFHLE9BQU8sV0FBVyxDQUFDLENBQUMsQ0FBQyxLQUFLLFdBQVcsR0FBRyxNQUFNLEdBQUcsV0FBVyxDQUFDLENBQUMsQ0FBQzs7QUFDeEUsNEJBQWMsQ0FBQyxDQUFDLENBQUMsR0FBRyxFQUFDLGlCQUFpQixFQUFFLENBQUMsR0FBRyxDQUFDLEVBQUUsZ0JBQWdCLEVBQUUsR0FBRSxFQUFDO2FBQ3JFOztnREFFTSxFQUFDLGNBQWMsRUFBRSxjQUFjLEVBQUM7Ozs7Ozs7S0FDeEM7Ozs7Ozs7V0FLK0IsNEJBQUMsSUFBSTtVQUMvQixXQUFXLEVBa0JULEtBQUs7Ozs7QUFsQlAsdUJBQVcsR0FBRztBQUNoQixrQkFBSSxFQUFFO0FBQ0osMkJBQVcsRUFBRSxHQUFHO0FBQ2hCLHdCQUFRLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7QUFDaEMsc0JBQU0sRUFBRSxJQUFJO0FBQ1oscUJBQUssRUFBRSxJQUFJLENBQUMsSUFBSTtBQUNoQixvQkFBSSxFQUFFLElBQUk7ZUFDWDtBQUNELG9CQUFNLEVBQUU7QUFDTiwyQkFBVyxFQUFFLEdBQUc7QUFDaEIsd0JBQVEsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtBQUNoQyxzQkFBTSxFQUFFLElBQUk7QUFDWix3QkFBUSxFQUFFLElBQUk7QUFDZCwwQkFBVSxFQUFLLElBQUksQ0FBQyxLQUFLLFNBQUksSUFBSSxDQUFDLFdBQVcsU0FBSSxJQUFJLENBQUMsV0FBYTtlQUNwRTtBQUNELG1CQUFLLEVBQUUsRUFBRTthQUNWO0FBRUssaUJBQUssR0FBRyx5QkFBWSxJQUFJLEVBQUUsQ0FBQyxLQUFLLEVBQUU7O0FBQ3hDLGlCQUFLLENBQUMsT0FBTyxDQUNYLGNBQUksRUFBSTtBQUNOLGtCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsU0FBUyxDQUFHO0FBQzVELGtCQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsVUFBVSxDQUFHO0FBQzlELGtCQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsVUFBVSxDQUFHOztBQUU5RCx5QkFBVyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQ3BCO0FBQ0Usd0JBQVEsRUFBRSxJQUFJO0FBQ2Qsc0JBQU0sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDO0FBQ3BCLHFCQUFLLEVBQUUsSUFBSTtBQUNYLHdCQUFRLEVBQUssS0FBSyxTQUFJLE1BQU0sU0FBSSxNQUFRO0FBQ3hDLHVCQUFPLEVBQUUsSUFBSTtlQUNkLENBQ0Y7YUFDRixDQUNGOztnREFFTSxXQUFXOzs7Ozs7O0tBQ25COzs7U0F6aEJrQixjQUFjOzs7cUJBQWQsY0FBYzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzhCQ1pmLGlCQUFpQjs7OztxQkFDWixRQUFROzt5QkFDWCxlQUFlOzs7O0FBRXJDLElBQU0sUUFBUSxHQUFHLHdDQUF3Qzs7SUFFcEMsUUFBUTtBQUNmLFdBRE8sUUFBUSxDQUNkLElBQUksRUFBRSxNQUFNLEVBQUU7MEJBRFIsUUFBUTs7QUFFekIsUUFBSSxDQUFDLElBQUksR0FBRyxJQUFJO0FBQ2hCLFFBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTTtHQUNyQjs7OztlQUprQixRQUFROztXQU9WLG9CQUFDLFdBQVU7VUFDdEIsT0FBTyxFQUVMLEdBQUc7Ozs7QUFGTCxtQkFBTyx5QkFBdUIsSUFBSSxDQUFDLE1BQU0sNkJBQXdCLHFCQUFTLFdBQVUsRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQzs7OzRDQUV4RixJQUFJLENBQUMsV0FBVyxDQUM5QixnQkFBZ0IsRUFDaEIsT0FBTyxDQUNSOzs7QUFIRyxlQUFHO2dEQUlBLEVBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFDOzs7OztrQkFFckMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx1QkFBVSxLQUFLLGdCQUFHLEVBQUUsRUFBQyxVQUFVLEVBQUUsT0FBTyxFQUFDLENBQUM7Ozs7Ozs7S0FFakU7OztXQUVpQixxQkFBQyxNQUFNLEVBQUUsSUFBSTtVQUV6QixVQUFVLEVBU1YsR0FBRzs7OztBQVRILHNCQUFVLEdBQUc7QUFDZixvQkFBTSxFQUFFLE1BQU07QUFDZCxpQkFBRyxFQUFLLFFBQVEsU0FBSSxNQUFRO0FBQzVCLGtCQUFJLEVBQUUsSUFBSTthQUNYOzs7QUFFRCxrQkFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQzs7Ozs0Q0FHcEIsaUNBQVEsVUFBVSxDQUFDOzs7QUFBL0IsZUFBRztnREFFQSxHQUFHOzs7Ozs7O0tBQ1g7OztXQUVpQixxQkFBQyxlQUFlO1VBRTVCLFVBQVUsRUFVVixHQUFHOzs7O0FBVkgsc0JBQVUsR0FBRztBQUNmLG9CQUFNLEVBQUUsTUFBTTtBQUNkLGlCQUFHLEVBQUssUUFBUSxpQkFBYzthQUMvQjs7O0FBRUQsa0JBQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7Ozs0Q0FFWixJQUFJLENBQUMsNEJBQTRCLENBQUMsZUFBZSxDQUFDOzs7QUFBMUUsc0JBQVUsQ0FBQyxJQUFJOzs0Q0FHQyxpQ0FBUSxVQUFVLENBQUM7OztBQUEvQixlQUFHO2dEQUVBLEdBQUc7Ozs7Ozs7S0FDWDs7O1dBRWtDLHNDQUFDLGVBQWU7VUFnQjdDLGtCQUFrQixrRkFFYixJQUFJLHVGQUVGLENBQUMsRUFZTixJQUFJLHVGQVVHLFNBQVMsdUZBT1AsR0FBRyxFQVdkLGNBQWM7Ozs7O0FBNUNkLDhCQUFrQixHQUFHLEVBQUU7Ozs7O3dCQUVWLGVBQWU7Ozs7Ozs7O0FBQXZCLGdCQUFJOzs7Ozs7O0FBRVgsOEJBQWMsSUFBSSxDQUFDLFVBQVUsMkhBQUU7QUFBdEIsZUFBQzs7O0FBRVIsa0JBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHO2FBQ2pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFRCw4QkFBa0IsSUFBSSxtQkFBbUI7QUFDekMsOEJBQWtCLG1CQUFpQixJQUFJLENBQUMsUUFBUSxnQkFBYTs7Ozs7O0FBTXpELGdCQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7O2tCQUN6QixJQUFJLENBQUMsMEJBQTBCLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQyx3QkFBd0IsS0FBSyxFQUFFOzs7Ozs7QUFFaEYsOEJBQWtCLElBQUksZ0NBQWdDO0FBQ3RELDhCQUFrQixxQkFBbUIsSUFBSSxDQUFDLEtBQUssa0JBQWU7Ozs7OztBQUc5RCw4QkFBa0IsSUFBSSxnQ0FBZ0M7Ozs7Ozs7eUJBR2hDLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUE1QixxQkFBUzs7O0FBRWhCLHFCQUFTLENBQUMsaUJBQWlCLEdBQUcsU0FBUyxDQUFDLEtBQUs7QUFDN0MsbUJBQU8sU0FBUyxDQUFDLEtBQUs7OztBQUd0Qiw4QkFBa0IsSUFBSSxpQkFBaUI7Ozs7O0FBQ3ZDLDhCQUFnQixNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQywySEFBRTtBQUEvQixpQkFBRzs7QUFDVixnQ0FBa0IsVUFBUSxHQUFHLFNBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFLLEdBQUcsTUFBRzthQUMzRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCw4QkFBa0IsSUFBSSxrQkFBa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJNUMsOEJBQWtCLElBQUksb0JBQW9COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJeEMsMEJBQWMscUNBRVIsSUFBSSxDQUFDLE1BQU0sdUJBQ25CLGtCQUFrQjtnREFLYixjQUFjOzs7Ozs7O0tBQ3RCOzs7U0ExSGtCLFFBQVE7OztxQkFBUixRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNOUixTQUFTO1dBQVQsU0FBUzswQkFBVCxTQUFTOzs7ZUFBVCxTQUFTOztXQUNmLGVBQUMsQ0FBQyxFQUFFO0FBQ2YsVUFBSSxHQUFHLEdBQUcsRUFBRTs7QUFFWixVQUFJLENBQUMsWUFBWSxLQUFLLEVBQUU7QUFDdEIsV0FBRyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsT0FBTztBQUN2QixXQUFHLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLFdBQUcsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVE7QUFDekIsV0FBRyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsVUFBVTtBQUM3QixXQUFHLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxZQUFZO0FBQ2pDLFdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUs7T0FDcEIsTUFBTTtBQUNMLFdBQUcsR0FBRyxDQUFDO09BQ1I7O0FBRUQsYUFBTyxHQUFHO0tBQ1g7OztTQWhCa0IsU0FBUzs7O3FCQUFULFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQ0FGLFNBQVM7O0lBRXhCLGVBQWU7V0FBZixlQUFlOzBCQUFmLGVBQWU7OztlQUFmLGVBQWU7O1dBQ1QsYUFBQyxJQUFJLEVBQUUsVUFBVTtVQUM1QixNQUFNLEVBQ04sRUFBRTs7Ozs7NENBRGEscUJBQVksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUE1QyxrQkFBTTtBQUNOLGNBQUUsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0RBQzFCLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDOzs7Ozs7O0tBQ2pDOzs7U0FMVSxlQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkNGVixPQUFPOzs7O3NCQUNOLFFBQVE7Ozs7SUFFTixLQUFLO0FBQ1osV0FETyxLQUFLLENBQ1gsT0FBTyxFQUFFOzBCQURILEtBQUs7OztBQUd0QixRQUFJLENBQUMsSUFBSSxHQUFHLG1CQUFNLFVBQVUsQ0FBQyxPQUFPLENBQUM7OztBQUdyQyxRQUFJLFlBQVksR0FBRyxFQUFDLGtCQUFrQixFQUFFLElBQUksRUFBQztBQUM3QyxVQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDcEMsUUFBSSxDQUFDLFNBQVMsR0FBRyxtQkFBTSxVQUFVLENBQUMsWUFBWSxDQUFDO0dBQ2hEOztlQVRrQixLQUFLOzs7Ozs7O1dBbUJsQixlQUFDLEdBQUcsRUFBRTs7O0FBR1YsYUFBTyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQ2pCLElBQUksQ0FDSCxVQUFDLEdBQUcsRUFBSztBQUNQLGVBQU8sSUFBSSxPQUFPLENBQ2hCLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSzs7QUFFbkIsYUFBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFDLEVBQUUsR0FBRyxFQUFLOztBQUV6QixlQUFHLENBQUMsT0FBTyxFQUFFO0FBQ2IsZ0JBQUksQ0FBQyxFQUFFO0FBQ0wsb0JBQU0sQ0FBQyxDQUFDLENBQUM7YUFDVixNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7V0FDcEIsQ0FBQztTQUNILENBQ0Y7T0FDRixDQUNGLFNBQ0ssQ0FBQyxVQUFDLENBQUMsRUFBSztBQUNaLGNBQU0sQ0FBQztPQUNSLENBQUM7S0FDTDs7O1dBRWtCLHNCQUFDLEdBQUc7VUFDakIsR0FBRzs7Ozs7NENBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNBLEdBQUcsQ0FBQyxRQUFROzs7Ozs7O0tBQ3BCOzs7Ozs7Ozs7O1dBUWlCLHFCQUFDLEtBQUs7VUFBRSxJQUFJLHlEQUFHLEVBQUU7VUFBRSxPQUFPLHlEQUFHLEVBQUU7O1VBSTNDLEdBQUcsRUFFSCxHQUFHLGtGQVdFLENBQUMsdUZBUU4sR0FBRzs7Ozs7QUFyQkgsZUFBRyxvQkFBa0IsS0FBSztBQUUxQixlQUFHLEdBQUcsSUFBSSxHQUFHLEVBQUU7Ozs7OztBQUNuQiw2QkFBYyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx1SEFBRTtBQUF4QixlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUU7QUFDcEIsbUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQztlQUNuQixNQUFNLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFOztBQUU5QyxtQkFBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQU0sS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBSTtlQUM3QyxNQUFNO0FBQ0wsbUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFLLG1CQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRztlQUN2QzthQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCw4QkFBYyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQywySEFBRTtBQUEzQixlQUFDOztBQUNSLGlCQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVELGVBQUcsV0FBUyw2QkFBSSxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFLOztBQUUxQyxlQUFHLGlCQUFlLDZCQUFJLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQUs7Ozs0Q0FFbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNBLEdBQUcsQ0FBQyxRQUFROzs7Ozs7O0tBQ3BCOzs7Ozs7Ozs7OztXQVNpQixxQkFBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPO1VBQ3pDLEdBQUcsRUFFSCxPQUFPLHVGQUlGLENBQUMsdUZBT04sR0FBRzs7Ozs7QUFiSCxlQUFHLGVBQWEsS0FBSztBQUVyQixtQkFBTyxHQUFHLEVBQUU7Ozs7OztBQUNoQiw4QkFBYyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQywySEFBRTtBQUF4QixlQUFDOztBQUNSLHFCQUFPLENBQUMsSUFBSSxDQUFJLENBQUMsU0FBSSxtQkFBTSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUc7YUFDOUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELDhCQUFjLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLDJIQUFFO0FBQTNCLGVBQUM7O0FBQ1IscUJBQU8sQ0FBQyxJQUFJLENBQUksQ0FBQyxTQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBRzthQUNuQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCxlQUFHLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7O0FBRXhCLGVBQUcsZ0JBQWMsTUFBTSxNQUFHOzs7NENBRVYsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNBLEdBQUc7Ozs7Ozs7S0FDWDs7Ozs7V0FHZ0Isb0JBQUMsR0FBRztVQUNmLFFBQVEsRUFHTixHQUFHOzs7O0FBSEwsb0JBQVEsR0FBRyxJQUFJLENBQUMsSUFBSTs7QUFDeEIsZ0JBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVM7Ozs0Q0FFUixJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0EsR0FBRzs7Ozs7QUFFVixnQkFBSSxDQUFDLElBQUksR0FBRyxRQUFROzs7Ozs7OztLQUV2Qjs7O1dBRXNCOzs7Ozs0Q0FDZixJQUFJLENBQUMsS0FBSyxzQkFBc0I7Ozs7Ozs7S0FDdkM7OztXQUVZOzs7Ozs0Q0FDTCxJQUFJLENBQUMsS0FBSyxXQUFXOzs7Ozs7O0tBQzVCOzs7V0FFYzs7Ozs7NENBQ1AsSUFBSSxDQUFDLEtBQUssYUFBYTs7Ozs7OztLQUM5Qjs7O1dBRWMsd0JBQUMsR0FBRyxFQUFrRDs7O1VBQWhELFFBQVEseURBQUcsVUFBQyxNQUFNLEVBQUssRUFBRTtVQUFFLE9BQU8seURBQUcsVUFBQyxDQUFDLEVBQUssRUFBRTs7QUFDakUsYUFBTyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQ2pCLElBQUksQ0FDSCxVQUFDLEdBQUcsRUFBSztBQUNQLGVBQU8sSUFBSSxPQUFPLENBQ2hCLG9CQUFPLE9BQU8sRUFBRSxNQUFNOzs7OztBQUVwQixtQkFBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FDWCxFQUFFLENBQUMsUUFBUSxFQUNWLFVBQUMsTUFBTSxFQUFLO0FBQ1YscUJBQUcsQ0FBQyxLQUFLLEVBQUU7QUFDWCwwQkFBUSxDQUFDLE1BQU0sQ0FBQztBQUNoQixxQkFBRyxDQUFDLE1BQU0sRUFBRTtpQkFDYixDQUFDLENBQ0gsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFDLENBQUMsRUFBSztBQUNsQix5QkFBTyxDQUFDLENBQUMsQ0FBQztpQkFDWCxDQUFDLENBQ0QsRUFBRSxDQUFDLEtBQUssRUFBRSxZQUFNO0FBQ2YscUJBQUcsQ0FBQyxPQUFPLEVBQUU7QUFDYix5QkFBTyxFQUFFO2lCQUNWLENBQUM7Ozs7Ozs7U0FDTCxDQUNGO09BQ0YsQ0FDRixTQUNLLENBQUMsVUFBQyxDQUFDLEVBQUs7QUFDWixjQUFNLENBQUM7T0FDUixDQUFDO0tBQ0w7OztXQUVNLGtCQUFHOzs7QUFDUixhQUFPLElBQUksT0FBTyxDQUNoQixVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUs7O0FBRW5CLGVBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFDLENBQUMsRUFBRSxHQUFHLEVBQUs7QUFDbEMsY0FBSSxDQUFDLEVBQUU7QUFDTCxrQkFBTSxDQUFDLENBQUMsQ0FBQztXQUNWLE1BQU07QUFDTCxtQkFBTyxDQUFDLEdBQUcsQ0FBQztXQUNiO1NBQ0YsQ0FBQztPQUNILENBQ0YsU0FDTyxDQUNKLFVBQUMsQ0FBQyxFQUFLO0FBQ0wsY0FBTSxDQUFDO09BQ1IsQ0FDRjtLQUNKOzs7V0ExS2lCLG9CQUFDLElBQUksRUFBRTtBQUN2QixhQUFPLHlCQUFPLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7S0FDaEU7OztTQWJrQixLQUFLOzs7cUJBQUwsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNITCxNQUFNO0FBQ2IsV0FETyxNQUFNLENBQ1osVUFBVSxFQUFFOzBCQUROLE1BQU07O0FBRXZCLFFBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVTtBQUM1QixRQUFJLENBQUMsYUFBYSxHQUFHLElBQUk7QUFDekIsUUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQ3BCLFFBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSTtBQUN2QixRQUFJLENBQUMsS0FBSyxHQUFHLENBQUM7QUFDZCxRQUFJLENBQUMsV0FBVyxHQUFHLENBQUM7R0FDckI7O2VBUmtCLE1BQU07O1dBVVosZ0JBQUMsR0FBRzs7OztrQkFFWCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQzs7Ozs7aUJBQ2hDLElBQUksQ0FBQyxhQUFhOzs7Ozs7NENBQ2QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDOzs7aUJBRzFDLElBQUksQ0FBQyxRQUFROzs7Ozs7NENBQ1QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7OztBQUUxQixnQkFBSSxDQUFDLEtBQUssRUFBRTs7QUFFWixnQkFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQyxFQUFFO0FBQ3RDLGtCQUFJLENBQUMsS0FBSyxFQUFFO0FBQ1osa0JBQUksQ0FBQyxXQUFXLEVBQUU7YUFDbkI7Ozs7Ozs7S0FDRjs7O1dBQ0ssaUJBQUc7QUFDUCxVQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7QUFDcEIsWUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO09BQ25DO0tBQ0Y7OztTQS9Ca0IsTUFBTTs7O3FCQUFOLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkNBTCxTQUFTOzs7OzRCQUNWLGVBQWU7OzJCQUNmLGdCQUFnQjs7c0JBQ2xCLFFBQVE7Ozs7SUFFTixNQUFNO0FBQ2IsV0FETyxNQUFNLEdBQ1Y7MEJBREksTUFBTTs7QUFFdkIsUUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFO0FBQ2hCLFFBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRTtBQUNuQixRQUFJLENBQUMsUUFBUSxHQUFHLElBQUk7R0FDckI7Ozs7ZUFMa0IsTUFBTTs7V0FRWCx1QkFBQyxPQUFPLEVBQUU7QUFDdEIsVUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDckMsVUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztLQUNuQzs7O1dBRVc7OztVQUFDLElBQUkseURBQUcsRUFBRTtVQUFFLEVBQUUseURBQUc7Ozs7Ozs7O09BQWM7VUFDckMsR0FBRyxFQU9ELEdBQUc7Ozs7QUFQTCxlQUFHLEdBQUc7QUFDUixxQkFBTyxFQUFFLDBCQUFRO2FBQ2xCOztBQUVELGdCQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7Ozs7NENBR2IsRUFBRSxFQUFFOzs7QUFBaEIsZUFBRzs7QUFFUCxrQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsa0JBQUksRUFBRSxTQUFTO0FBQ2YsbUJBQUssRUFBRSxJQUFJO0FBQ1gsb0JBQU0sRUFBRSxHQUFHO2FBQ1osQ0FBQzs7Ozs7Ozs7QUFFRixrQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsa0JBQUksRUFBRSxPQUFPO0FBQ2IsbUJBQUssRUFBRSxJQUFJO0FBQ1gsb0JBQU0sRUFBRSxtQkFBVSxLQUFLLGdCQUFHO2FBQzNCLENBQUM7Ozs7OztBQUdGLGdCQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtBQUM5QixvQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsd0JBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU07ZUFDL0IsQ0FBQzthQUNIOztBQUVELGVBQUcsQ0FBQyxTQUFTLEdBQUcsSUFBSSxJQUFJLEVBQUU7O0FBRTFCLDhCQUFLLE1BQU0sQ0FBQyxHQUFHLENBQUM7OztBQUdoQixnQkFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOzs7Ozs7OztLQUV4Qjs7Ozs7O1dBSXFCLHlCQUFDLEdBQUcsRUFBRSxFQUFFO1VBRXRCLEdBQUcsRUFHRCxHQUFHOzs7Ozs0Q0FKRSxHQUFHLENBQUMsT0FBTyxFQUFFOzs7Ozs7Ozs7NENBQ1IsR0FBRyxDQUFDLElBQUksRUFBRTs7O0FBQXRCLGVBQUc7Ozs0Q0FHVyxFQUFFLENBQUMsR0FBRyxDQUFDOzs7QUFBbkIsZUFBRzs7QUFDUCxnQkFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7O0FBRWxCLGdCQUFJLENBQUMsTUFBTSxnQkFBRzs7Ozs7OztBQUdsQixlQUFHLENBQUMsS0FBSyxFQUFFOzs7Ozs7O0tBQ1o7OztXQUVRLGtCQUFDLFNBQVMsRUFBRTtBQUNuQixVQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7S0FDakM7OztXQUVNLGdCQUFDLFNBQVMsRUFBRTtBQUNqQixVQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxtQkFBVSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7S0FDaEQ7OztXQUVZLHdCQUFHO0FBQ2QsVUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBQztlQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUU7T0FBQSxDQUFDO0FBQ3pELFVBQUksUUFBUSxHQUFHLEtBQUs7Ozs7OztBQUNwQiw2QkFBZ0IsSUFBSSxDQUFDLE1BQU0sOEhBQUU7Y0FBcEIsR0FBRzs7QUFDVixjQUFJLEdBQUcsQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO0FBQ3hCLG9CQUFRLEdBQUcsSUFBSTtBQUNmLGtCQUFLO1dBQ047U0FDRjs7Ozs7Ozs7Ozs7Ozs7OztBQUNELGFBQU8sUUFBUSxJQUFJLFFBQVE7S0FDNUI7OztXQUVPLG1CQUFHOztBQUVULFVBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO0FBQ3ZCLGNBQU0sSUFBSSxxQkFBTyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztPQUNwQztBQUNELGFBQU8sSUFBSSxDQUFDLE1BQU07S0FDbkI7OztTQTdGa0IsTUFBTTs7O3FCQUFOLE1BQU07O0lBZ0dyQixRQUFRO0FBQ0EsV0FEUixRQUFRLENBQ0MsT0FBTyxFQUFFOzBCQURsQixRQUFROztBQUVWLFFBQUksQ0FBQyxNQUFNLEdBQUc7QUFDWixXQUFLLEVBQUUsQ0FBQztBQUNSLGFBQU8sRUFBRSxDQUFDO0FBQ1YsV0FBSyxFQUFFLENBQUM7QUFDUixhQUFPLEVBQUUsT0FBTztLQUNqQjtBQUNELFFBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSTtHQUN0Qjs7ZUFURyxRQUFROztXQVdKLGlCQUFDLFNBQVMsRUFBRTtBQUNsQixVQUFJLFNBQVMsRUFBRTtBQUNiLFlBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQztPQUMxQjtBQUNELFVBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO0FBQ3JCLFVBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0tBQ3BCOzs7V0FFSyxlQUFDLFNBQVMsRUFBRTs7QUFFaEIsVUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxFQUFFO0FBQ2hFLFlBQUksU0FBUyxJQUFJLFNBQVMsS0FBSyxFQUFFLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtBQUNyRCxjQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUM7QUFDMUIsY0FBSSxDQUFDLFNBQVMsR0FBRyxTQUFTO1NBQzNCO09BQ0Y7QUFDRCxVQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtBQUNuQixVQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtLQUNwQjs7O1dBRUcsYUFBQyxTQUFTLEVBQUUsU0FBUywwQ0FBMEM7QUFDakUsVUFBSSxHQUFHLEdBQUc7QUFDUixlQUFPLEVBQUUsU0FBUztBQUNsQixlQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQzVCLGVBQU8sRUFBRSxTQUFTO0FBQ2xCLGlCQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7T0FDdEI7QUFDRCx3QkFBSyxNQUFNLENBQUMsR0FBRyxDQUFDO0tBQ2pCOzs7V0FFWSx3QkFBRztBQUNkLGFBQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLO0tBQ3pCOzs7U0EzQ0csUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDckdPLFFBQVE7V0FBUixRQUFROzBCQUFSLFFBQVE7OztlQUFSLFFBQVE7O1dBQ1osaUJBQUMsSUFBSSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUU7QUFDckMsVUFBSSxVQUFVLEtBQUssU0FBUyxFQUFFO0FBQUUsa0JBQVUsR0FBRyxFQUFFO09BQUU7QUFDakQsVUFBSSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUM7QUFDOUIsVUFBSSxLQUFLLEdBQUcsQ0FBQztBQUNiLFVBQUksR0FBRyxHQUFHLEVBQUU7QUFDWixXQUFLLElBQUksQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsU0FBUyxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUUsRUFBRTtBQUN6QyxZQUFJLENBQUMsR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQzVCLFlBQUksQ0FBQyxDQUFDLE1BQU0sR0FBRyxDQUFDLEVBQUUsS0FBSyxFQUFFLE1BQ3BCLEtBQUssSUFBSSxDQUFDO0FBQ2YsWUFBSSxLQUFLLEdBQUcsR0FBRyxFQUFFO0FBQ2YsaUJBQU8sR0FBRyxHQUFHLFVBQVU7U0FDeEI7QUFDRCxXQUFHLElBQUksSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7T0FDdEI7QUFDRCxhQUFPLElBQUk7S0FDWjs7O1NBaEJrQixRQUFROzs7cUJBQVIsUUFBUTs7Ozs7Ozs7Ozs7Ozs7OzsyQkNBUCxjQUFjOztBQUU3QixJQUFNLElBQUksR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUM7O0FBQ2xFLElBQU0sT0FBTyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFNBQVMsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7QUFDeEUsSUFBTSxXQUFXLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsYUFBYSxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOztBQUNoRixJQUFNLFNBQVMsR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxXQUFXLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcbi8vICAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4vLyAgIHJlcy5lbmQoYEhlbGxvIHdvcmxkIGZyb206ICR7TWV0ZW9yLnJlbGVhc2V9YCk7XHJcbi8vIH0pO1xyXG5cclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnO1xyXG5cclxuLy8gUmVxdWlyZXMgbXVsdGlwYXJ0eSBcclxuaW1wb3J0IG11bHRpcGFydHkgZnJvbSAnY29ubmVjdC1tdWx0aXBhcnR5JztcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9ucyc7XHJcbmxldCBtdWx0aXBhcnR5TWlkZGxld2FyZSA9IG11bHRpcGFydHkoKTtcclxuXHJcbmNvbnN0IHJvdXRlID0gJy91cGxvYWQvaW1hZ2UnO1xyXG5cclxuLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCBmdWMudXBsb2FkRmlsZSApO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgbXVsdGlwYXJ0eU1pZGRsZXdhcmUpO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgKHJlcSwgcmVzcCkgPT4ge1xyXG4gIC8vIGRvbid0IGZvcmdldCB0byBkZWxldGUgYWxsIHJlcS5maWxlcyB3aGVuIGRvbmVcclxuXHJcbiAgY29uc3QgcmVhZGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy5yZWFkRmlsZSk7XHJcbiAgY29uc3Qgd3JpdGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy53cml0ZUZpbGUpO1xyXG4gIGNvbnN0IHVwbG9hZElkID0gdW5pcWlkKCk7XHJcblxyXG4gIGZvciAobGV0IGZpbGUgb2YgcmVxLmZpbGVzLmZpbGUpIHtcclxuICAgIGNvbnN0IGRhdGEgPSByZWFkZXIoZmlsZS5wYXRoKTtcclxuICAgIC8vIOODleOCoeOCpOODq+WQjeOBrumHjeikh+OCkumBv+OBkeOCi+OBn+OCgeOAgeS4gOaEj+OBruODleOCoeOCpOODq+WQjeOCkuS9nOaIkOOBmeOCi1xyXG4gICAgLy8g5qW95aSp44Gu44OV44Kh44Kk44Or5ZCN5paH5a2X5pWw5Yi26ZmQMjDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBmaWxlbmFtZSA9IGAke3VuaXFpZCgpfS5qcGdgXHJcblxyXG4gICAgLy8gc2V0IHRoZSBjb3JyZWN0IHBhdGggZm9yIHRoZSBmaWxlIG5vdCB0aGUgdGVtcG9yYXJ5IG9uZSBmcm9tIHRoZSBBUEk6XHJcbiAgICBsZXQgc2F2ZVBhdGggPSByZXEuYm9keS5pbWFnZWRpciArICcvJyArIGZpbGVuYW1lO1xyXG5cclxuICAgIC8vIGNvcHkgdGhlIGRhdGEgZnJvbSB0aGUgcmVxLmZpbGVzLmZpbGUucGF0aCBhbmQgcGFzdGUgaXQgdG8gZmlsZS5wYXRoXHJcblxyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ57WQ5p6c44KS6KiY6Yyy44GZ44KLXHJcbiAgICBsZXQgZG9jID0ge1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICAgIGNsaWVudEZpbGVOYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgIHVwbG9hZGVkRmlsZU5hbWU6IGZpbGVuYW1lXHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICB0cnl7XHJcbiAgICAgIHdyaXRlcihzYXZlUGF0aCwgZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaChlcnIpe1xyXG4gICAgICBkb2MuZXJyb3IgPSBlcnI7XHJcbiAgICB9XHJcbiAgICBVcGxvYWRzLmluc2VydChkb2MpO1xyXG5cclxuICAgIGRlbGV0ZSBmaWxlO1xyXG5cclxuICB9O1xyXG4gIHJlc3Aud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgc2F2ZURpcjogcmVxLmJvZHkuaW1hZ2VkaXJcclxuICB9KSk7XHJcblxyXG59KTsiLCJpbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0bydcclxuXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBSZXBvcnQgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBHcm91cCxcclxuICBHcm91cEZhY3RvcnlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzJ1xyXG5pbXBvcnQge1xyXG4gIEZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlbWlnJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5taWdyYXRlYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIC8vIHNldHVwIGdyb3VwXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgRmlsdGVyKGNvbmZpZy5zcmNGaWx0ZXJJZClcclxuICAgIC8vIGxldCBwbHVnID0gZ3JvdXAuZ2V0UGx1ZygpO1xyXG5cclxuICAgIC8vIGNoZWNraW5nIGNvbm5lY3Rpb25cclxuICAgIC8vXHJcblxyXG4gICAgbGV0IHRlc3RRdWVyeSA9ICdTSE9XIERBVEFCQVNFUydcclxuXHJcbiAgICBsZXQgZHN0RGIgPSBuZXcgTXlTUUwoY29uZmlnLmRzdC5jcmVkKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnQ29ubmVjdCB0byBEZXN0aW5hdGlvbicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBhd2FpdCBkc3REYi5xdWVyeSh0ZXN0UXVlcnkpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcHJvY2VzcyBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICAvL1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnU2VsZWN0IGxvb3AgaW4gc291cmNlJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICBtb2JpbGVOdWxsOiBhc3luYyAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIC8vIOWApOOCkuaVtOeQhlxyXG4gICAgICAgICAgICAvLyBmb3IgKGxldCBrZXkgb2YgT2JqZWN0LmtleXMocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyAgIGlmIChyZWNvcmRba2V5XSA9PT0gbnVsbCk7XHJcbiAgICAgICAgICAgIC8vICAgZWxzZSBpZiAocmVjb3JkW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAvLyDml6Xku5jjgpLlpInmj5tcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gTXlTUUwuZm9ybWF0RGF0ZShyZWNvcmRba2V5XSk7XHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IGBcIiR7cmVjb3JkW2tleV19XCJgO1xyXG4gICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyIOOBq+S/neWtmFxyXG5cclxuICAgICAgICAgICAgbGV0IHNxbCA9IGBcclxuXHJcbiAgICAgICAgICAgICAgICBJTlNFUlQgZHRiX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAoIFxcYGN1c3RvbWVyX2lkXFxgLCBcXGBzdGF0dXNcXGAsIFxcYHNleFxcYCwgXFxgam9iXFxgLCBcXGBjb3VudHJ5X2lkXFxgLCBcXGBwcmVmXFxgLCBcXGBuYW1lMDFcXGAsIFxcYG5hbWUwMlxcYCwgXFxga2FuYTAxXFxgLCBcXGBrYW5hMDJcXGAsIFxcYGNvbXBhbnlfbmFtZVxcYCwgXFxgemlwMDFcXGAsIFxcYHppcDAyXFxgLCBcXGB6aXBjb2RlXFxgLCBcXGBhZGRyMDFcXGAsIFxcYGFkZHIwMlxcYCwgXFxgZW1haWxcXGAsIFxcYHRlbDAxXFxgLCBcXGB0ZWwwMlxcYCwgXFxgdGVsMDNcXGAsIFxcYGZheDAxXFxgLCBcXGBmYXgwMlxcYCwgXFxgZmF4MDNcXGAsIFxcYGJpcnRoXFxgLCBcXGBwYXNzd29yZFxcYCwgXFxgc2FsdFxcYCwgXFxgc2VjcmV0X2tleVxcYCwgXFxgZmlyc3RfYnV5X2RhdGVcXGAsIFxcYGxhc3RfYnV5X2RhdGVcXGAsIFxcYGJ1eV90aW1lc1xcYCwgXFxgYnV5X3RvdGFsXFxgLCBcXGBub3RlXFxgLCBcXGBjcmVhdGVfZGF0ZVxcYCwgXFxgdXBkYXRlX2RhdGVcXGAsIFxcYGRlbF9mbGdcXGAgKVxyXG5cclxuICAgICAgICAgICAgICAgIFZBTFVFUyggJHtyZWNvcmQuY3VzdG9tZXJfaWR9ICwgJHtyZWNvcmQuc3RhdHVzfSAsICR7cmVjb3JkLnNleH0gLCAke3JlY29yZC5qb2J9ICwgJHtyZWNvcmQuY291bnRyeV9pZH0gLCAke3JlY29yZC5wcmVmfSAsICR7cmVjb3JkLm5hbWUwMX0gLCAke3JlY29yZC5uYW1lMDJ9ICwgJHtyZWNvcmQua2FuYTAxfSAsICR7cmVjb3JkLmthbmEwMn0gLCAke3JlY29yZC5jb21wYW55X25hbWV9ICwgJHtyZWNvcmQuemlwMDF9ICwgJHtyZWNvcmQuemlwMDJ9ICwgJHtyZWNvcmQuemlwY29kZX0gLCAke3JlY29yZC5hZGRyMDF9ICwgJHtyZWNvcmQuYWRkcjAyfSAsICR7cmVjb3JkLmVtYWlsfSAsICR7cmVjb3JkLnRlbDAxfSAsICR7cmVjb3JkLnRlbDAyfSAsICR7cmVjb3JkLnRlbDAzfSAsICR7cmVjb3JkLmZheDAxfSAsICR7cmVjb3JkLmZheDAyfSAsICR7cmVjb3JkLmZheDAzfSAsICR7cmVjb3JkLmJpcnRofSAsICR7cmVjb3JkLnBhc3N3b3JkfSAsICR7cmVjb3JkLnNhbHR9ICwgJHtyZWNvcmQuc2VjcmV0X2tleX0gLCAke3JlY29yZC5maXJzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5sYXN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmJ1eV90aW1lc30gLCAke3JlY29yZC5idXlfdG90YWx9ICwgJHtyZWNvcmQubm90ZX0gLCAke3JlY29yZC5jcmVhdGVfZGF0ZX0gLCAke3JlY29yZC51cGRhdGVfZGF0ZX0gLCAke3JlY29yZC5kZWxfZmxnfSApXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBzdGF0dXM6IHJlY29yZC5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgIHNleDogcmVjb3JkLnNleCxcclxuICAgICAgICAgICAgICAgICAgam9iOiByZWNvcmQuam9iLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIGVtYWlsOiByZWNvcmQuZW1haWwsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGJpcnRoOiByZWNvcmQuYmlydGgsXHJcbiAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiByZWNvcmQucGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICAgIHNhbHQ6IHJlY29yZC5zYWx0LFxyXG4gICAgICAgICAgICAgICAgICBzZWNyZXRfa2V5OiByZWNvcmQuc2VjcmV0X2tleSxcclxuICAgICAgICAgICAgICAgICAgZmlyc3RfYnV5X2RhdGU6IHJlY29yZC5maXJzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgbGFzdF9idXlfZGF0ZTogcmVjb3JkLmxhc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90aW1lczogcmVjb3JkLmJ1eV90aW1lcyxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RvdGFsOiByZWNvcmQuYnV5X3RvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBub3RlOiByZWNvcmQubm90ZSxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lcl9hZGRyZXNzXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyX2FkZHJlc3MnLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2FkZHJlc3NfaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOODoeODq+ODnuOCrOODl+ODqeOCsOOCpOODsyBwbGdfbWFpbG1hZ2FfY3VzdG9tZXJcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfbWFpbG1hZ2FfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGlkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBtYWlsbWFnYV9mbGc6IHJlY29yZC5tYWlsbWFnYV9mbGcsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjgq/jg7zjg53jg7PnmbrooYzvvIhFQ0NVQkUy44Gu44Od44Kk44Oz44OI6YKE5YWD77yJXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uQ2QgPSBjcnlwdG8ucmFuZG9tQnl0ZXMoOCkudG9TdHJpbmcoJ2Jhc2U2NCcpLnN1YnN0cmluZygwLCAxMSlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25OYW1lID0gYCR7cmVjb3JkLm5hbWUwMX0gJHtyZWNvcmQubmFtZTAyfSDmp5gg44GU5YSq5b6F44Kv44O844Od44OzIOS8muWToeeVquWPtzoke3JlY29yZC5jdXN0b21lcl9pZH1gXHJcblxyXG4gICAgICAgICAgICBsZXQgZGlzY291bnRQcmljZSA9IHJlY29yZC5wb2ludCArIDUwMFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX2NvdXBvbicsIHtcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fY2Q6IGNvdXBvbkNkLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdHlwZTogMywgLy8g5YWo5ZWG5ZOBXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9uYW1lOiBjb3Vwb25OYW1lLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF90eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdXNlX3RpbWU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9yZWxlYXNlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9wcmljZTogZGlzY291bnRQcmljZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcmF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgZW5hYmxlX2ZsYWc6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9tZW1iZXI6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9sb3dlcl9saW1pdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX2Zyb21fZGF0ZTogJzIwMTgtMDQtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfdG9fZGF0ZTogJzIwMTktMDUtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiAwXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyAnY3ViZW1pZy5zZXJ2ZXJDaGVjaycgKHByb2ZpbGUpIHtcclxuICAgIGxldCBkYiA9IG5ldyBNeVNRTChwcm9maWxlKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGRiLnF1ZXJ5KCdTSE9XIERBVEFCQVNFUycpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IHsgTW9uZ29Db2xsZWN0aW9uIH0gZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL21vbmdvJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuY29sbGVjdGlvbidcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZmluZGBdIChwbHVnLCBxdWVyeSA9IHt9LCBwcm9qZWN0aW9uID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5maW5kKHF1ZXJ5LCB7cHJvamVjdGlvbjogcHJvamVjdGlvbn0pLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmFnZ3JlZ2F0ZWBdIChwbHVnLCBxdWVyeSA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuYWdncmVnYXRlKHF1ZXJ5KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuaXRlbXMnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z44Kz44Os44Kv44K344On44Oz5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44G+44GZ44CCXHJcbiAgICogQHBhcmFtXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uc2V0SW1hZ2VgXSAocGx1ZywgdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGxldCB1cGxvYWRlZCA9IGF3YWl0IGl0ZW1jb24uc2V0SW1hZ2UodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICAgIHJldHVybiB1cGxvYWRlZFxyXG4gIH0sXHJcblxyXG4gIC8qKlxyXG4gICAqIOOCouOCpOODhuODoOaDheWgseODh+ODvOOCv+ODmeODvOOCueOBrueUu+WDj+eZu+mMsuOCkuWJiumZpOOBmeOCi++8iOeUu+WDj+iHquS9k+OBr+WJiumZpOOBl+OBquOBhO+8iVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LmNsZWFuSW1hZ2VgXSAocGx1ZywgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5jbGVhbkltYWdlKG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IHtcclxuICBDdWJlM0FwaVxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9jdWJlM2FwaSdcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWcqOW6q+abtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVTdG9ja2BdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpXHJcbiAgICBsZXQgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+WcqOW6q+OBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdVUERBVEUnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseeZu+mMsuOBqOabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYkl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKVxyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQilcclxuXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdFQ0NVQkUz44G444Gu5ZWG5ZOB55m76YyyJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnSU5TRVJUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvblxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKVxyXG5cclxuICAgICAgICAgICAgICBsZXQgaW5zZXJ0UmVzID0gYXdhaXQgYXBpLnByb2R1Y3RDcmVhdGUoY3ViZUl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIC8vIGl0ZW0g44OH44O844K/44OZ44O844K544G444Gu55m76YyyXHJcbiAgICAgICAgICAgICAgYXdhaXQgY29sLnVwZGF0ZSh7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkXHJcbiAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X2lkLFxyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X2NsYXNzX2lkLFxyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X3N0b2NrX2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X3N0b2NrX2lkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+WVhuWTgeaDheWgseOBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RJbWFnZVVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IFBhY2tldCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcGFja2V0J1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgYXJjaGl2ZXIgZnJvbSAnYXJjaGl2ZXInXHJcbmltcG9ydCBjc3YgZnJvbSAnY3N2J1xyXG5cclxuY29uc3QgdGFnID0gJ3JvYm90aW5Qb3N0bGFiZWwnXHJcblxyXG5jb25zdCBPUkRFUl9OT19QUkVGSVggPSAn5Y+X5rOo55Wq5Y+377yaJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIFJvYm90LWluXHJcbiAgLy8g6YCB44KK54q244Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6LyJXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmFkZEl0ZW1Db2RlYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnUm9ib3QtaW4g6YCB44KK54q244Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6LyJJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vcG9zdGxhYmVsYFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyB3b3JrZGlyIOOBjOa6luWCmeOBleOCjOOBpuOBhOOBn+OCieWun+ihjOOBmeOCi1xyXG5cclxuICAgICAgICAgIC8vIGNvbnN0IHcgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyU2F2ZWZpbGV9YClcclxuXHJcbiAgICAgICAgICBsZXQgb3JkZXJDc3YgPSBhd2FpdCBmc0V4dHJhLnJlYWRGaWxlKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyQ3N2UHJlZml4fS5jc3ZgKVxyXG4gICAgICAgICAgb3JkZXJDc3YgPSBhd2FpdCBpY29udi5kZWNvZGUob3JkZXJDc3YsICdTSklTJylcclxuICAgICAgICAgIG9yZGVyQ3N2ID0gYXdhaXQgaWNvbnYuZW5jb2RlKG9yZGVyQ3N2LCAnVVRGLTgnKVxyXG5cclxuICAgICAgICAgIC8vIG9yZGVyQ3N2LnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAvLyAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC8vICAgLnBpcGUoY3N2LnBhcnNlKHtcclxuICAgICAgICAgIC8vICAgICBjb2x1bW5zOiB0cnVlXHJcbiAgICAgICAgICAvLyAgIH0pKVxyXG4gICAgICAgICAgLy8gICAucGlwZShjc3YudHJhbnNmb3JtKFxyXG4gICAgICAgICAgLy8gICAgIGFzeW5jIChyZWNPcmRlciwgY2FsbGJhY2spID0+IHtcclxuICAgICAgICAgIC8vICAgICAgIGxldCBlcnIgPSBudWxsXHJcbiAgICAgICAgICAvLyAgICAgICB0cnkge1xyXG4gICAgICAgICAgLy8g6YCB44KK54q244Gu56iu6aGe44GU44Go44Gr57mw44KK6L+U44GZXHJcbiAgICAgICAgICBhd2FpdCBjb25maWcucG9zdGFnZXMuZm9yRWFjaChcclxuICAgICAgICAgICAgYXN5bmMgZSA9PiB7XHJcbiAgICAgICAgICAgICAgY29uc29sZS5sb2coYGNzdlByZWZpeDogJHtlLmNzdlByZWZpeH1gKVxyXG4gICAgICAgICAgICAgIC8vIGF3YWl0IGUuaWQuZm9yRWFjaChcclxuICAgICAgICAgICAgICAvLyAgIGFzeW5jIGlkID0+IHtcclxuICAgICAgICAgICAgICAvLyAgICAgY29uc29sZS5sb2coYCR7aWQub3JkZXJ9OiAke3JlY09yZGVyW2lkLm9yZGVyXX1gKVxyXG4gICAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAgIC8vIClcclxuICAgICAgICAgICAgICAvLyBjb25zb2xlLmxvZyhgJHtjb25maWcuaXRlbUNvZGVDb2x1bW59OiAke3JlY09yZGVyW2NvbmZpZy5pdGVtQ29kZUNvbHVtbl19YClcclxuXHJcbiAgICAgICAgICAgICAgLy8g6YCB44KK54q2Q1NW44KS6ZaL44GN44CB6YWN6YCB44GU44Go44Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6LyJ44GZ44KLXHJcbiAgICAgICAgICAgICAgY29uc3QgcG9zdENTViA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyfS8ke2UuY3N2UHJlZml4fS5jc3ZgKVxyXG4gICAgICAgICAgICAgIHBvc3RDU1YucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGNzdi5wYXJzZSh7XHJcbiAgICAgICAgICAgICAgICAgIGNvbHVtbnM6IHRydWVcclxuICAgICAgICAgICAgICAgIH0pKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgICAvLyAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyAgICAgICAgIGVyciA9IGVcclxuICAgICAgICAgIC8vICAgICAgIH1cclxuICAgICAgICAgIC8vICAgICAgIGNhbGxiYWNrKGVyciwgcmVjT3JkZXIpXHJcbiAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgLy8gICApKVxyXG4gICAgICAgICAgLy8gLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAvLyAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAvLyAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC8vIC5waXBlKHcpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IoYOato+OBl+OBhOS9nOalreODh+OCo+ODrOOCr+ODiOODquOBjOeUqOaEj+OBleOCjOOBpuOBhOOBvuOBm+OCk+OBp+OBl+OBn+OAguS4i+iomOOBruODleOCqeODq+ODgOOBuOWPl+azqENTVuOAgemAgeOCiueKtkNTVuOCkuOCs+ODlOODvOOBl+OBpuOBj+OBoOOBleOBhOOAglxcblske3dvcmtkaXJ9XWApXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAndG9vbCdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udGVzdGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcblxyXG4gICAgY29uc3QgbmV3TG9jYWwgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7fSwgYXN5bmMgKGUpID0+IHtcclxuICAgICAgdGhyb3cgZVxyXG4gICAgfSlcclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODleOCo+ODq+OCv+ODvOODhuOCueODiCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gbmV3TG9jYWxcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5pbXBvcnQgV293bWFBcGkgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL3dvd21hQXBpJ1xyXG5pbXBvcnQgdXRpbEVycm9yIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9lcnJvcidcclxuXHJcbmNvbnN0IHRhZyA9ICd3b3dtYSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDllYblk4Hjga7phY3pgIHmlrnms5XjgpLoqK3lrprjgZnjgotcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlSXRlbS5kZWxpdmVyeU1ldGhvZGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dvd21hISDllYblk4Hjga7phY3pgIHmlrnms5XjgpLoqK3lrprjgZnjgosnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyBqbGluZV9lbmdpbmUg5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aaXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5ZWG5ZOB5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgbGV0IGN1ciA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICAgICAgJGFuZDogW1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiB7ICRleGlzdHM6IDEgfVxyXG4gICAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDk0MicgLy8gSkstMTIwXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihpdGVtLCBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVdvd21hQ3JlYXRlRGVsaXZlcnlNZXRob2QoaXRlbS5pdGVtQ29kZSkpXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS51cGRhdGVJdGVtKGl0ZW0pXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtyZXF1ZXN0Qm9keTogaXRlbSwgcmVzcG9uc2U6IHJlc31cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHRocm93IE9iamVjdC5hc3NpZ24oe3JlcXVlc3RCb2R5OiBpdGVtfSwgdXRpbEVycm9yLnBhcnNlKGUpKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueS4iuOBruWVhuWTgeOCkuWFrOmWi+OBmeOCi1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVJdGVtLm9wZW5gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB44OH44O844K/44OZ44O844K55LiK44Gu5ZWG5ZOB44KS5YWs6ZaL44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgaXRlbS5zYWxlU3RhdHVzID0gMVxyXG4gICAgICAgICAgICBpdGVtLmxpbWl0ZWRQYXNzd2QgPSAnTlVMTCdcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZUl0ZW0oaXRlbSlcclxuICAgICAgICAgICAgICByZXR1cm4ge3JlcXVlc3RCb2R5OiBpdGVtLCByZXNwb25zZTogcmVzfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih7cmVxdWVzdEJvZHk6IGl0ZW19LCB1dGlsRXJyb3IucGFyc2UoZSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5Zyo5bqr5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZVN0b2NrYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWcqOW6q+abtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWcqOW6q+aDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICBsZXQgY3VyID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgICAgICAkYW5kOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6IHsgJGV4aXN0czogMSB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8g44OG44K544OI5qSc57Si5p2h5Lu26Kit5a6aXHJcbiAgICAgICAgICAgICAgICAvLyAgICx7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnZ2stMTYzJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgXVxyXG4gICAgICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g6YWN6YCB5pa55rOV44Gu6YGV44GE44KS55yB44GPXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IHtcclxuICAgICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckbWFsbC53b3dtYS5pdGVtQ29kZScsXHJcbiAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlOiAnJG1hbGwud293bWEuSENob2ljZU5hbWUnLFxyXG4gICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6ICckbWFsbC53b3dtYS5WQ2hvaWNlTmFtZSdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBpdGVtOiB7XHJcbiAgICAgICAgICAgICAgICAgICRmaXJzdDogJyRfaWQnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Oa44O844K444GU44Go77yI5ZWG5ZOB44Kz44O844OJ77yJ44Gr44Kw44Or44O844OX5YyW44GZ44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckX2lkLml0ZW1Db2RlJyxcclxuICAgICAgICAgICAgICAgIHZhcmlhdGlvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgJHB1c2g6IHtcclxuICAgICAgICAgICAgICAgICAgICBfaWQ6ICckaXRlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGU6ICckX2lkLmNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlJyxcclxuICAgICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6ICckX2lkLmNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZSdcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnLFxyXG4gICAgICAgICAgICAgICAgdmFyaWF0aW9uczogJyR2YXJpYXRpb25zJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8gbGV0IHJlc01vbmdvID0gYXdhaXQgY3VyLnRvQXJyYXkoKVxyXG4gICAgICAgIC8vIHJldHVybiByZXNNb25nb1xyXG5cclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqNcclxuICAgICAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICAgICAgbGV0IGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpXHJcblxyXG4gICAgICAgICAgLy8g5Zyo5bqr44KS6Kit5a6a44GZ44KLXHJcbiAgICAgICAgICBmb3IgKGxldCBlIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgICAgICBlLnN0b2NrID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soZS5faWQpXHJcbiAgICAgICAgICAgIGRlbGV0ZSBlLl9pZFxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC8vXHJcbiAgICAgICAgICAvLyDlnKjluqvmm7TmlrDjg6rjgq/jgqjjgrnjg4hcclxuICAgICAgICAgIGxldCBhcGkgPSBuZXcgV293bWFBcGkoY29uZmlnLndvd21hQXBpUG9zdCwgY29uZmlnLnNob3BJZClcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlU3RvY2soW2l0ZW1dKVxyXG4gICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeaknOe0olxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5zZWFyY2hJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBvcHRpb25zID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShjb25maWcud293bWFBcGkpKVxyXG4gICAgICAgICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hJdGVtSW5mb2BcclxuICAgICAgICAgICAgb3B0aW9ucy5xcy5pdGVtQ29kZSA9IGl0ZW0ubWFsbC53b3dtYS5pdGVtQ29kZVxyXG5cclxuICAgICAgICAgICAgbGV0IHJlcG9zID0gYXdhaXQgcmVxdWVzdChvcHRpb25zKVxyXG4gICAgICAgICAgICBsZXQgZmlsZW5hbWUgPSBgJHt3b3JrZGlyfS8ke2l0ZW0ubW9kZWx9LnhtbGBcclxuXHJcbiAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEud3JpdGVGaWxlKGZpbGVuYW1lLCByZXBvcylcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBXb3dtYUFwaUl0ZW1GaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmNvbnN0IHRhZyA9ICd3b3dtYUFwaSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQeWVhuWTgeaDheWgseWPluW+l1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5nZXRJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgV293bWFBcGlJdGVtRmlsdGVyKGNvbmZpZy53b3dtYUFwaSwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIC8vIHRyeSB7XHJcbiAgICAgICAgLy8gICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIC8vIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIC8vIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICAvLyB0cnkge1xyXG4gICAgICAgIC8vICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIC8vIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhpdGVtKVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBQYWNrZXQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3BhY2tldCdcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcblxyXG5pbXBvcnQgaWNvbnYgZnJvbSAnaWNvbnYtbGl0ZSdcclxuaW1wb3J0IGFyY2hpdmVyIGZyb20gJ2FyY2hpdmVyJ1xyXG5pbXBvcnQgY3N2IGZyb20gJ2NzdidcclxuaW1wb3J0IHsgUGFzc1Rocm91Z2gsIFRyYW5zZm9ybSB9IGZyb20gJ3N0cmVhbSdcclxuXHJcbmNvbnN0IHByZWZpeCA9ICdwYWNrZXQnXHJcbmNvbnN0IHRhZyA9ICd5YXVjdCdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDjg6Tjg5Xjgqrjgq/lj5fms6jjg5XjgqHjgqTjg6tcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ub3JkZXJgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lj5fms6gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9vcmRlcmBcclxuICAgICAgICBjb25zdCByID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyTG9hZGZpbGV9YClcclxuICAgICAgICBjb25zdCB3ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbShgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlclNhdmVmaWxlfWApXHJcbiAgICAgICAgci5waXBlKGljb252LmRlY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAucGlwZShjc3YudHJhbnNmb3JtKFxyXG4gICAgICAgICAgICBhc3luYyAocmVjb3JkLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgIGxldCBlcnIgPSBudWxsXHJcbiAgICAgICAgICAgICAgLy8g566h55CG55Wq5Y+344KS572u44GN5o+b44GI44KLXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHJlY29yZFsn566h55CG55Wq5Y+3J10gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRNb2RlbENsYXNzKHJlY29yZFsn566h55CG55Wq5Y+3J10pXHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgZXJyID0gZVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBjYWxsYmFjayhlcnIsIHJlY29yZClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKSlcclxuICAgICAgICAgIC5waXBlKGNzdi5zdHJpbmdpZnkoe2hlYWRlcjogdHJ1ZX0pKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAucGlwZSh3KVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyDjg6Tjg5Xjgqrjgq/lh7rlk4Hjg5XjgqHjgqTjg6tcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJpdGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODpOODleOCquOCr+WHuuWTgScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOe5sOOCiui/lOOBl+WHpueQhuOCkuS7u+aEj+OBru+8iHBhY2tldFNpemXvvInjgafliIblibJcclxuICAgICAgICBjb25zdCBwYWNrZXQgPSBuZXcgUGFja2V0KGNvbmZpZy5wYWNrZXRTaXplKVxyXG5cclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgpLkvZzmiJDjgZfnlLvlg4/jg4fjg7zjgr/jgpLlj47pm4bjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L3dvcmtgXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUod29ya2RpcilcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcblxyXG4gICAgICAgIC8vIFpJUOODleOCoeOCpOODq+OCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHVwbG9hZGRpciA9IGAke2NvbmZpZy53b3JrZGlyfS91cGxvYWRgXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUodXBsb2FkZGlyKVxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIodXBsb2FkZGlyKVxyXG5cclxuICAgICAgICBsZXQgY2QgPSBudWxsIC8vIOODkeOCseODg+ODiOODleOCqeODq+ODgFxyXG4gICAgICAgIGxldCBmaWxlbmFtZSA9IG51bGwgLy8gY3N244OV44Kh44Kk44OrXHJcbiAgICAgICAgbGV0IG5hbWUgPSBudWxsIC8vIOODkeOCseODg+ODiOeVquWPt1xyXG5cclxuICAgICAgICAvLyBDU1bjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZfjgIHpoIbnlarjgpLnorrlrprjgZnjgotcclxuICAgICAgICBsZXQgZmllbGRzID0gWyfnrqHnkIbnlarlj7cnLCAn44Kr44OG44K044OqJywgJ+OCv+OCpOODiOODqycsICfoqqzmmI4nLCAn44K544OI44Ki5YaF5ZWG5ZOB5qSc57Si55So44Kt44O844Ov44O844OJJywgJ+mWi+Wni+S+oeagvCcsICfljbPmsbrkvqHmoLwnLCAn5YCk5LiL44GS5Lqk5riJJywgJ+WAi+aVsCcsICflhaXmnK3lgIvmlbDliLbpmZAnLCAn5pyf6ZaTJywgJ+e1guS6huaZgumWkycsICfllYblk4HnmbrpgIHlhYPjga7pg73pgZPlupznnIwnLCAn5ZWG5ZOB55m66YCB5YWD44Gu5biC5Yy655S65p2RJywgJ+mAgeaWmeiyoOaLhScsICfku6Pph5HlhYjmiZXjgYTjgIHlvozmiZXjgYQnLCAn6JC95pyt44OK44OT5rG65riI5pa55rOV6Kit5a6aJywgJ+WVhuWTgeOBrueKtuaFiycsICfllYblk4Hjga7nirbmhYvlgpnogIMnLCAn6L+U5ZOB44Gu5Y+v5ZCmJywgJ+i/lOWTgeOBruWPr+WQpuWCmeiAgycsICfnlLvlg48xJywgJ+eUu+WDjzHjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMicsICfnlLvlg48y44Kz44Oh44Oz44OIJywgJ+eUu+WDjzMnLCAn55S75YOPM+OCs+ODoeODs+ODiCcsICfnlLvlg480JywgJ+eUu+WDjzTjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNScsICfnlLvlg48144Kz44Oh44Oz44OIJywgJ+eUu+WDjzYnLCAn55S75YOPNuOCs+ODoeODs+ODiCcsICfnlLvlg483JywgJ+eUu+WDjzfjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOCcsICfnlLvlg48444Kz44Oh44Oz44OIJywgJ+eUu+WDjzknLCAn55S75YOPOeOCs+ODoeODs+ODiCcsICfnlLvlg48xMCcsICfnlLvlg48xMOOCs+ODoeODs+ODiCcsICfmnIDkvY7oqZXkvqEnLCAn5oKq6KmV5Ymy5ZCI5Yi26ZmQJywgJ+WFpeacreiAheiqjeiovOWItumZkCcsICfoh6rli5Xlu7bplbcnLCAn5pep5pyf57WC5LqGJywgJ+WVhuWTgeOBruiHquWLleWGjeWHuuWTgScsICfoh6rli5XlgKTkuIvjgZInLCAn5pyA5L2O6JC95pyt5L6h5qC8JywgJ+ODgeODo+ODquODhuOCo+ODvCcsICfms6jnm67jga7jgqrjg7zjgq/jgrfjg6fjg7MnLCAn5aSq5a2X44OG44Kt44K544OIJywgJ+iDjOaZr+iJsicsICfjgrnjg4jjgqLjg5vjg4Pjg4jjgqrjg7zjgq/jgrfjg6fjg7MnLCAn55uu56uL44Gh44Ki44Kk44Kz44OzJywgJ+i0iOetlOWTgeOCouOCpOOCs+ODsycsICdU44Od44Kk44Oz44OI44Kq44OX44K344On44OzJywgJ+OCouODleOCo+ODquOCqOOCpOODiOOCquODl+OCt+ODp+ODsycsICfojbfnianjga7lpKfjgY3jgZUnLCAn6I2354mp44Gu6YeN6YePJywgJ+OBr+OBk0JPT04nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMScsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTHlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMicsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTLlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTPlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTTlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNScsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTXlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNicsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTblhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTflhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTjlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOScsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTnlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTAnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTDmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTDlhajlm73kuIDlvovkvqHmoLwnLCAn5rW35aSW55m66YCBJywgJ+mFjemAgeaWueazleODu+mAgeaWmeioreWumicsICfku6PlvJXmiYvmlbDmlpnoqK3lrponLCAn5raI6LK756iO6Kit5a6aJywgJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXVxyXG4gICAgICAgIGxldCBoZWFkZXIgPSBmaWVsZHMubWFwKHYgPT4gYFwiJHt2fVwiYCkuam9pbignLCcpICsgJ1xcbidcclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW6ZaL5aeL5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0U3RhcnQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcclxuICAgICAgICAgIG5hbWUgPSBwcmVmaXggKyAoJzAwMDAwJyArIHBhY2tldENvdW50KS5zbGljZSgtNSlcclxuICAgICAgICAgIGNkID0gYCR7d29ya2Rpcn0vJHtuYW1lfWBcclxuICAgICAgICAgIGZpbGVuYW1lID0gYCR7Y2R9LyR7Y29uZmlnLmNzdkZpbGVOYW1lfWBcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY2QpXHJcbiAgICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgavjg5XjgqPjg7zjg6vjg4njgpLoqK3lrprjgZnjgotcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKGhlYWRlciwgJ1NoaWZ0X0pJUycpKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0ID0gYXN5bmMgKGFyZykgPT4ge1xyXG4gICAgICAgICAgbGV0IHlhdWN0ID0gYXJnLnlhdWN0XHJcbiAgICAgICAgICBsZXQgaXRlbSA9IGFyZy5pdGVtXHJcbiAgICAgICAgICAvLyBjc3bjg5XjgqHjgqTjg6vjgavjg6zjgrPjg7zjg4nvvIjllYblk4Hjg4bjg7Pjg5fjg6zjg7zjg4jvvInjgpLov73liqDjgZnjgotcclxuICAgICAgICAgIGxldCByZWNvcmQgPSBmaWVsZHMubWFwKHYgPT4geyByZXR1cm4geWF1Y3Rbdl0gPyBgXCIke3lhdWN0W3ZdfVwiYCA6ICdcIlwiJyB9KS5qb2luKCcsJykgKyAnXFxuJ1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUocmVjb3JkLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgICAvLyDnlLvlg4/jg5XjgqHjgqTjg6vjgpLjgrPjg5Tjg7xcclxuICAgICAgICAgIGZvciAobGV0IGltZyBvZiBpdGVtLmltYWdlcykge1xyXG4gICAgICAgICAgICBsZXQgaW1nU3JjID0gYCR7Y29uZmlnLmltYWdlZGlyfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIGxldCBpbWdUZ3QgPSBgJHtjZH0vJHtpbWd9YFxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIC8vIOWQjOOBmOODleOCoeOCpOODq+OBjOOBguOCi+WgtOWQiOOBr+OCs+ODlOODvOOBl+OBquOBhFxyXG4gICAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYWNjZXNzKGltZ1RndClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEuY29weUZpbGUoaW1nU3JjLCBpbWdUZ3QpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOe1guS6huaZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldEVuZCA9IGFzeW5jIChwYWNrZXRDb3VudCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgemlwID0gYXJjaGl2ZXIoJ3ppcCcpXHJcbiAgICAgICAgICBjb25zdCB6aXBuYW1lID0gYCR7dXBsb2FkZGlyfS8ke25hbWV9LnppcGBcclxuICAgICAgICAgIGNvbnN0IG91dHB1dCA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oemlwbmFtZSlcclxuICAgICAgICAgIHppcC5waXBlKG91dHB1dClcclxuICAgICAgICAgIHppcC5kaXJlY3RvcnkoY2QsIGZhbHNlKVxyXG4gICAgICAgICAgemlwLmZpbmFsaXplKClcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICAvLyBpdGVt44Gr5a6a576p44GV44KM44Gm44GE44KL5pyA5L2O5b+F6KaB5Zyo5bqr44KI44KK5aSa44GE5ZWG5ZOB44KS5Ye65ZOB44GZ44KLXHJcbiAgICAgICAgICAgIGlmIChxdWFudGl0eSA+PSBpdGVtLm1hbGwueWF1Y3QubWluUXVhbnRpdHkpIHtcclxuICAgICAgICAgICAgICBsZXQgeWF1Y3QgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVlhdWN0KGNvbmZpZy5kZWZhdWx0LCBpdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IHBhY2tldC5zdWJtaXQoe3lhdWN0OiB5YXVjdCwgaXRlbTogaXRlbX0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICBwYWNrZXQuY2xvc2UoKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgJy4uL2ltcG9ydHMvY29sbGVjdGlvbi9jb25maWdzJ1xyXG5cclxuaW1wb3J0ICcuL3JvdXRlL3VwbG9hZC9pbWFnZSdcclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nXHJcblxyXG5leHBvcnQgY29uc3QgQ29uZmlncyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdjb25maWdzJywge2lkR2VuZXJhdGlvbjogJ01PTkdPJ30pXHJcblxyXG4vLyBNZXRlb3IubWV0aG9kcyh7XHJcbi8vICAgYXN5bmMgJ215c3FsU2VydmVycy5pbnNlcnQnICggbmV3U2VydmVyICl7XHJcbi8vICAgICByZXR1cm4gYXdhaXQgTXlzcWxTZXJ2ZXJzLmluc2VydChuZXdTZXJ2ZXIpO1xyXG4vLyAgIH1cclxuLy8gfSk7XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0JztcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnO1xyXG5pbXBvcnQgeyBHcm91cEJhc2UgfSBmcm9tICcuL2dyb3Vwcyc7XHJcblxyXG5jb25zdCBGaWx0ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZpbHRlcnMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZpbHRlciBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGZpbHRlcklkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBGaWx0ZXJzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGZpbHRlcklkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcblxyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKCBvblJlc3VsdCA9IChyZWNvcmQpPT57fSwgb25FcnJvciA9IChlKT0+e30gKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGxhdGZvcm0gdHlwZScpO1xyXG5cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7eyBmaWx0ZXJUeXBlOiBhc3luYyAocmVjb3JkICkgPT4ge30gfX0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoKGNhbGxiYWNrcyA9IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGUoKTtcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICB0eXBlOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnQgPSB7fTtcclxuICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgY291bnRbZmlsdGVyLnR5cGVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmaWx0ZXIucXVlcnksXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCk9PntcclxuICAgICAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgICAgICBsZXQgcXVlcnkgPSBtb2JqZWN0LnVuZXNjYXBlKGZpbHRlci5xdWVyeSk7XHJcbiAgICAgICAgICBsZXQgZXhhbSA9IHNpZnQoIHF1ZXJ5ICk7XHJcbiAgICAgICAgICBpZiggZXhhbShyZWNvcmQpICl7XHJcbiAgICAgICAgICAgIGNvdW50W2ZpbHRlci50eXBlXS5jb3VudCsrO1xyXG4gICAgICAgICAgICBpZiggdHlwZW9mIGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFja3NbZmlsdGVyLnR5cGVdKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBvbkVycm9yXHJcbiAgICApO1xyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnQ7XHJcblxyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbmNvbnN0IEdyb3VwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdncm91cHMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwQmFzZSB7XHJcblxyXG4gIHByb2ZpbGU7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb2ZpbGUpIHtcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBnZXRzICdQbHVnJyB3aXRjaCBpcyBhIHNldCBvZiBwcm9wZXJ0aWVzIG5lZWRlZFxyXG4gICAqIHdoZW4gY29ubmVjdCB0byBzb21lIHBsYXRmb3Jtc1xyXG4gICAqIHRvIGdldCBkYXRhcyhNZW1iZXJzIG9mIHRoZSBHcm91cClcclxuICAgKi9cclxuICBnZXRQbHVnKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZS5wbGF0Zm9ybVBsdWc7XHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZTtcclxuICB9XHJcblxyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge307XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXAgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihncm91cElkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBHcm91cHMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZ3JvdXBJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKGRvYykgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX0gV0hFUkUgXFxgJHtkb2Mua2V5fVxcYCA9IFwiJHtkb2MuaWR9XCJgO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBncm91cCB0eXBlJyk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7YXN5bmMgKHJlY29yZCk9PnZvaWR9IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IGN1ciA9IEdyb3Vwcy5maW5kKHtcclxuICAgICAgZ3JvdXBJZDogdGhpcy5wcm9maWxlLl9pZFxyXG4gICAgfSwge1xyXG4gICAgICBmaWVsZHM6IHtcclxuICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAga2V5OiAxXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGN1ci5mb3JFYWNoKFxyXG4gICAgICAgICAgYXN5bmMgKGRvYywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVjb3JkID0gYXdhaXQgdGhpcy5pbXBvcnQoZG9jKTtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFjayhyZWNvcmQpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgb25FcnJvcihlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaW5kZXggKyAxID09PSBjdXIuY291bnQoKSkge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICB9XHJcbiAgICApLmNhdGNoKFxyXG4gICAgICAoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcbn0iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5cclxuZXhwb3J0IGNsYXNzIEN1YmUzQXBpIHtcclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7TXlTUUx9IG15c3FsXHJcbiAgICovXHJcbiAgY29uc3RydWN0b3IgKG15c3FsKSB7XHJcbiAgICB0aGlzLm15c3FsXyA9IG15c3FsXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9jayAocHJvZHVjdENsYXNzSWQsIHF1YW50aXR5ID0gMCkge1xyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIGBwcm9kdWN0X2NsYXNzX2lkID0gJHtwcm9kdWN0Q2xhc3NJZH1gLFxyXG4gICAgICB7fSwge1xyXG4gICAgICAgIHN0b2NrOiBxdWFudGl0eSxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcclxuICAgICAge30sIHtcclxuICAgICAgICBzdG9jazogcXVhbnRpdHksXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdFRhZ1VwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSBbXVxyXG5cclxuICAgIC8vIOWJiumZpOOBmeOCi+OCv+OCsFxyXG4gICAgbGV0IHRhZ29mZiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgbGV0IHNxbCA9IGBcclxuICAgICAgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfdGFnIFxyXG4gICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9IEFORCB0YWcgPSAke3RhZ31cclxuICAgICAgYFxyXG4gICAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOihqOekuuOBmeOCi+OCv+OCsFxyXG4gICAgbGV0IHRhZ29uID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICAvLyDjgZnjgafjgavooajnpLrjgZXjgozjgabjgYTjgovjgr/jgrDjgYzjgYLjgozjgbDkvZXjgoLjgZfjgarjgYRcclxuICAgICAgbGV0IHNxbCA9IGBcclxuICAgICAgU0VMRUNUIENPVU5UKCopIEZST00gZHRiX3Byb2R1Y3RfdGFnIFxyXG4gICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9IEFORCB0YWcgPSAke3RhZ31cclxuICAgICAgYFxyXG4gICAgICBsZXQgY291bnRSZXMgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpXHJcbiAgICAgIGlmIChjb3VudFJlc1swXVsnQ09VTlQoKiknXSkgcmV0dXJuXHJcblxyXG4gICAgICByZXMucHVzaChcclxuICAgICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAgICdkdGJfcHJvZHVjdF90YWcnLFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGRhdGEucHJvZHVjdF9pZCxcclxuICAgICAgICAgICAgdGFnOiB0YWcsXHJcbiAgICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICAgIH1cclxuICAgICAgICApKVxyXG4gICAgfVxyXG5cclxuICAgIGZvciAobGV0IHRhZ1NldCBvZiBkYXRhLnRhZ3MpIHtcclxuICAgICAgc3dpdGNoICh0YWdTZXQuc2V0KSB7XHJcbiAgICAgICAgY2FzZSAnb24nOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb24odGFnU2V0LnRhZylcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgY2FzZSAnb2ZmJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29mZih0YWdTZXQudGFnKVxyXG4gICAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0SW1hZ2VVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCBwcm9kdWN0SWQgPSBkYXRhLnByb2R1Y3RfaWRcclxuICAgIGxldCBpbWFnZXMgPSBkYXRhLmltYWdlc1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSBbXVxyXG5cclxuICAgIC8vIOWVhuWTgeOBq+mWoumAo+OBmeOCi+OBmeOBueOBpuOBrueUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi1xyXG4gICAgbGV0IHNxbCA9IGBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF9pbWFnZSBXSEVSRSBwcm9kdWN0X2lkID0gJHtwcm9kdWN0SWR9YFxyXG4gICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSlcclxuICAgIC8vIOaUueOCgeOBpueUu+WDj+OCkueZu+mMsuOBl+OBquOBiuOBmVxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgJ2R0Yl9wcm9kdWN0X2ltYWdlJywge1xyXG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxyXG4gICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgICAgZmlsZV9uYW1lOiBpbWFnZXNbaV0sXHJcbiAgICAgICAgICByYW5rOiBpICsgMVxyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCB1cGRhdGVEYXRhID0ge31cclxuICAgIGxldCBrZXlzID0gW11cclxuXHJcbiAgICAvLyBkdGJfcHJvZHVjdFxyXG5cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdzdGF0dXMnLFxyXG4gICAgICAnbmFtZScsXHJcbiAgICAgICdub3RlJyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2xpc3QnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJyxcclxuICAgICAgJ3NlYXJjaF93b3JkJyxcclxuICAgICAgJ2ZyZWVfYXJlYSdcclxuICAgIF1cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcclxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0X2NsYXNzXHJcblxyXG4gICAgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnZGVsaXZlcnlfZGF0ZV9pZCcsXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAnc2FsZV9saW1pdCcsXHJcbiAgICAgICdwcmljZTAxJyxcclxuICAgICAgJ3ByaWNlMDInLFxyXG4gICAgICAnZGVsaXZlcnlfZmVlJ1xyXG4gICAgXVxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0Q3JlYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IHt9XHJcblxyXG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fVxyXG4gICAgbGV0IGtleXMgPSBbXVxyXG5cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCdcclxuICAgIF1cclxuICAgIC8vIHtcclxuICAgIC8vICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgLy8gICBkZXNjcmlwdGlvbl9kZXRhaWw6IGl0ZW0uZGVzY3JpcHRpb24sXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHN0YXR1czogMSxcclxuICAgICAgICBub3RlOiAnTlVMTCcsXHJcbiAgICAgICAgZGVzY3JpcHRpb25fbGlzdDogJ05VTEwnLFxyXG4gICAgICAgIHNlYXJjaF93b3JkOiAnTlVMTCcsXHJcbiAgICAgICAgZnJlZV9hcmVhOiAnTlVMTCcsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHVwZGF0ZURhdGEgPSB7fVxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdwcm9kdWN0X3R5cGVfaWQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJyxcclxuICAgICAgJ2RlbGl2ZXJ5X2ZlZSdcclxuICAgIF1cclxuICAgIC8vIHtcclxuICAgIC8vICAgcHJvZHVjdF9jb2RlOiBpdGVtLm1vZGVsLFxyXG4gICAgLy8gICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcclxuICAgIC8vICAgcHJpY2UwMjogaXRlbS5zYWxlc19wcmljZSxcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2NsYXNzX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgcHJvZHVjdF9pZDogcmVzLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgc3RvY2s6IDAsXHJcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxyXG4gICAgICAgIGNsYXNzX2NhdGVnb3J5X2lkMTogJ05VTEwnLFxyXG4gICAgICAgIGNsYXNzX2NhdGVnb3J5X2lkMjogJ05VTEwnLFxyXG4gICAgICAgIGRlbGl2ZXJ5X2RhdGVfaWQ6ICdOVUxMJyxcclxuICAgICAgICBzYWxlX2xpbWl0OiAnTlVMTCcsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9zdG9ja19pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLCB7fSwge1xyXG4gICAgICAgIHByb2R1Y3RfY2xhc3NfaWQ6IHJlcy5wcm9kdWN0X2NsYXNzX2lkLFxyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gZm9yIHRlc3RcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJ1xyXG5pbXBvcnQge01vbmdvQ2xpZW50fSBmcm9tICdtb25nb2RiJ1xyXG5pbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0LXByb21pc2UnXHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0J1xyXG5pbXBvcnQgbW9iamVjdCBmcm9tICdtb25nb29iamVjdCdcclxuaW1wb3J0IHsgeG1sMmpzIH0gZnJvbSAneG1sLWpzJ1xyXG5cclxuZXhwb3J0IGNsYXNzIERCRmlsdGVyRmFjdG9yeSB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIGxldCBpbnN0YW5jZVxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIGluc3RhbmNlID0gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSlcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gaW5zdGFuY2VcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHRoaXMucGx1ZyA9IHBsdWdcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGVcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmYWN0b3J5IChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgcmV0dXJuIG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsdWcgdHlwZScpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBnZXRQbHVnXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wbHVnXHJcbiAgfVxyXG5cclxuICBnZXRDcmVkXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wbHVnLmNyZWRcclxuICB9XHJcblxyXG4gIGdldFByb2ZpbGVfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGVcclxuICB9XHJcblxyXG4gIHNldEltcG9ydEZ1bmN0aW9uXyAoXHJcbiAgICBmbiA9IGFzeW5jIChvblJlc3VsdCA9IHJlY29yZCA9PiB7fSwgb25FcnJvciA9IGUgPT4ge30pID0+IHt9XHJcbiAgKSB7XHJcbiAgICB0aGlzLmltcG9ydCA9IGZuXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiB1c2VhZ2U6XHJcbiAgICpcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7IE9iamVjdCB9IGl0ZXJhdG9ycyB7IGZpbHRlck5hbWU6IGFzeW5jIChkb2MsY29udGV4dCk9Pnt9LCAuLi4gfSBpdGVyYXRvciBmb3IgZWFjaCBmaWx0ZXJzXHJcbiAgICogQHBhcmFtIHsgYXN5bmMgZnVuY3Rpb24gfSBvbkVycm9yIGVycm9yIGhhbmRsZXIgd2hpbGUgaXRlcmF0aW5nXHJcbiAgICogQHJldHVybnMgeyBPYmplY3QgfSB7IGZpbHRlck5hbWU6IHsgcXVlcnk6IGFueSwgY291bnQ6IG51bWJlciB9LCAuLi4gfVxyXG4gICAqL1xyXG4gIGFzeW5jIGZvcmVhY2ggKGl0ZXJhdG9ycyA9IHt9KSB7XHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZV8oKVxyXG5cclxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXHJcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XHJcbiAgICAgIG5hbWU6ICdtaXNjJyxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBjb3VudGVyID0ge31cclxuICAgIGZvciAobGV0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IGZpbHRlcnMgPSBbXVxyXG5cclxuICAgIGZvciAobGV0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XHJcbiAgICAgIGNvdW50ZXJbZi5uYW1lXSA9IHtcclxuICAgICAgICBxdWVyeTogZi5xdWVyeSxcclxuICAgICAgICBsaW1pdDogdHlwZW9mIGYubGltaXQgIT09ICd1bmRlZmluZWQnID8gZi5saW1pdCA6IDAsXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfVxyXG4gICAgICBmaWx0ZXJzLnB1c2goXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbmFtZTogZi5uYW1lLFxyXG4gICAgICAgICAgZXhhbTogc2lmdChtb2JqZWN0LnVuZXNjYXBlKGYucXVlcnkpKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgZm9yIChsZXQgZiBvZiBmaWx0ZXJzKSB7XHJcbiAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgIGxldCBjID0gY291bnRlcltmLm5hbWVdXHJcbiAgICAgICAgICBpZiAoYy5saW1pdCkge1xyXG4gICAgICAgICAgICBpZiAoYy5jb3VudCA+PSBjLmxpbWl0KSB7XHJcbiAgICAgICAgICAgICAgY29udGludWVcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChmLmV4YW0ocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgICAgYy5jb3VudCsrXHJcblxyXG4gICAgICAgICAgICAvLyBpdGVyYXRvclxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZXJhdG9yc1tmLm5hbWVdICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGl0ZXJhdG9yc1tmLm5hbWVdKHJlY29yZCwgY29udGV4dClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVha1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50ZXJcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBNeXNxbERCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKVxyXG5cclxuICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpXHJcblxyXG4gICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChjcmVkKVxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YFxyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCAoZSkgPT4geyB0aHJvdyBlIH0pXHJcbiAgICAgIHJldHVybiByZXNcclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgTW9uZ29OYXRpdmUgZnJvbSAnbW9uZ29kYic7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gTW9uZ29OYXRpdmUuTW9uZ29DbGllbnQ7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gcmVxdWlyZSgnbW9uZ29kYicpLk1vbmdvQ2xpZW50O1xyXG5cclxuZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpXHJcblxyXG4gICAgLy8gbW9uZ28g44G45o6l57aaXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgbGV0IGNsaWVudFxyXG4gICAgICBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG5cclxuICAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5Y+W5b6XXHJcbiAgICAgIGxldCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKVxyXG4gICAgICBsZXQgY29sbGVjdGlvbiA9IGRiLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKVxyXG5cclxuICAgICAgbGV0IGNvbnRleHQgPSB7XHJcbiAgICAgICAgY2xpZW50OiBjbGllbnQsXHJcbiAgICAgICAgY29sbGVjdGlvbjogY29sbGVjdGlvbixcclxuICAgICAgICBkYXRhYmFzZTogZGJcclxuICAgICAgfVxyXG5cclxuICAgICAgbGV0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpXHJcblxyXG4gICAgICAvLyDjgqvjg7zjgr3jg6vjga7jgr/jgqTjg6DjgqLjgqbjg4jjgpLop6PpmaRcclxuICAgICAgY3VyLmFkZEN1cnNvckZsYWcoJ25vQ3Vyc29yVGltZW91dCcsIHRydWUpXHJcblxyXG4gICAgICAvLyDjgZnjgbnjgabjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgpLjg6vjg7zjg5dcclxuICAgICAgdHJ5IHtcclxuICAgICAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICAgICAgbGV0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgICAgIGF3YWl0IG9uUmVzdWx0KGRvYywgY29udGV4dClcclxuICAgICAgICB9O1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIC8vIOOCq+ODvOOCveODq+OCkumWi+aUvlxyXG4gICAgICAgIGF3YWl0IGN1ci5jbG9zZSgpXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgV293bWFBcGlJdGVtRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKVxyXG5cclxuICAgIC8vIOWVhuWTgeaDheWgseOBruWPluW+l+ODq+ODvOODl+OCkuWumue+qVxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xyXG4gICAgICBsZXQgb3B0aW9ucyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkocGx1ZykpXHJcbiAgICAgIG9wdGlvbnMudXJpID0gYCR7b3B0aW9ucy51cml9L3NlYXJjaFN0b2Nrc2BcclxuICAgICAgbGV0IGNvbnRleHQgPSB7XHJcbiAgICAgICAgb3B0aW9uczogb3B0aW9uc1xyXG4gICAgICB9XHJcblxyXG4gICAgICB3aGlsZSAoMSkge1xyXG4gICAgICAgIC8vIFdvd21hIEFwaSDjgYvjgonllYblk4Hmg4XloLHjgpLlj5blvpdcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgcmVxdWVzdChvcHRpb25zKVxyXG4gICAgICAgIHJlcyA9IHhtbDJqcyhyZXMsIHtjb21wYWN0OiB0cnVlfSlcclxuXHJcbiAgICAgICAgbGV0IG1heENvdW50ID0gTnVtYmVyKHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQubWF4Q291bnQuX3RleHQpXHJcbiAgICAgICAgbGV0IHJlc3VsdENvdW50ID0gTnVtYmVyKHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQucmVzdWx0Q291bnQuX3RleHQpXHJcbiAgICAgICAgbGV0IHN0YXJ0Q291bnQgPSBOdW1iZXIocmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5zdGFydENvdW50Ll90ZXh0KVxyXG4gICAgICAgIGxldCByZXN1bHRTdG9ja3MgPSByZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0LnJlc3VsdFN0b2Nrc1xyXG5cclxuICAgICAgICAvLyDlj5blvpfjgZfjgZ/llYblk4Hmg4XloLHjgpLjgqvjgrnjgr/jg6Djg5fjg63jgrvjgrnjgavmuKHjgZlcclxuICAgICAgICBpZiAocmVzdWx0U3RvY2tzIGluc3RhbmNlb2YgQXJyYXkpIHtcclxuICAgICAgICAgIC8vIOWPluW+l+OBl+OBn+ODh+ODvOOCv+OBjOikh+aVsOWVhuWTgeOBruWgtOWQiFxyXG4gICAgICAgICAgZm9yIChsZXQgaSA9IDA7IGkgPCByZXN1bHRDb3VudDsgaSsrKSB7XHJcbiAgICAgICAgICAgIGF3YWl0IG9uUmVzdWx0KHJlc3VsdFN0b2Nrc1tpXSwgY29udGV4dClcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgLy8g5Y+W5b6X44GX44Gf44OH44O844K/44GM5Y2Y5pWw5ZWG5ZOB44Gu5aC05ZCIXHJcbiAgICAgICAgICBhd2FpdCBvblJlc3VsdChyZXN1bHRTdG9ja3MsIGNvbnRleHQpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICBsZXQgbmV4dCA9IHN0YXJ0Q291bnQgKyByZXN1bHRDb3VudFxyXG5cclxuICAgICAgICBpZiAobmV4dCA+IG1heENvdW50KSBicmVha1xyXG4gICAgICAgIG9wdGlvbnMucXMuc3RhcnRDb3VudCA9IG5leHRcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBtb25nb29zZSBmcm9tICdtb25nb29zZSc7XHJcblxyXG4vLyBleHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuLy8gICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbi8vICAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcclxuXHJcbi8vICAgICAvLyBtb25nbyDjgbjmjqXntppcclxuLy8gICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpO1xyXG4vLyAgICAgbGV0IGNvbnVyaSA9IGBtb25nb2RiOi8vJHtjcmVkLmhvc3R9OiR7Y3JlZC5wb3J0fS8ke2NyZWQuZGF0YWJhc2V9YDtcclxuLy8gICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoY29udXJpKTtcclxuXHJcbi8vICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLkvZzjgotcclxuLy8gICAgIGxldCBjb2xsZWN0aW9uID0gbW9uZ29vc2UuY29ubmVjdGlvbi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XHJcblxyXG4vLyAgICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbi8vICAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKTtcclxuXHJcbi8vICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4vLyAgICAgfSk7XHJcbi8vICAgfVxyXG4vLyB9XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29Db2xsZWN0aW9uXHJcbn0gZnJvbSAnLi4vdXRpbC9tb25nbydcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzLCBSb2JvdGluU2hvcFxyXG59IGZyb20gJy4uL2NvbGxlY3Rpb25zJ1xyXG5pbXBvcnQge1xyXG4gIE9iamVjdElEXHJcbn0gZnJvbSAnYnNvbidcclxuaW1wb3J0IEJsdWViIGZyb20gJ2JsdWViaXJkJ1xyXG5pbXBvcnQgVGV4dFV0aWwgZnJvbSAnLi4vdXRpbC90ZXh0J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSXRlbUNvbnRyb2xsZXIge1xyXG4gIGFzeW5jIGluaXQgKHBsdWcpIHtcclxuICAgIHRoaXMuSXRlbXMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdpdGVtcycpXHJcbiAgICB0aGlzLlByb2R1Y3RzID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCAncHJvZHVjdHMnKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U3RvY2sgKGl0ZW1JZCkge1xyXG4gICAgbGV0IGl0ZW0gPSBhd2FpdCB0aGlzLkl0ZW1zLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGl0ZW1JZFxyXG4gICAgfSwge1xyXG4gICAgICBwcm9qZWN0aW9uOiB7XHJcbiAgICAgICAgJ3Byb2R1Y3QnOiAxXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICBsZXQgcHJvZHVjdFNldCA9IGl0ZW0ucHJvZHVjdFxyXG5cclxuICAgIC8vIHByb2R1Y3QgKiA8LT4gKiBpdGVtXHJcbiAgICAvLyBwcm9kdWN0W106IOikh+aVsOOBruWVhuWTgeOCkjHjg5Hjg4PjgrHjg7zjgrjjgajjgZfjgabosqnlo7JcclxuICAgIC8vIHByb2R1Y3Rbe2lkczpbPE9iamVjdElkPl0sc2V0OjxOdW1iZXI+fV06IOeVsOOBquOCi+a1gemAmue1jOi3r+OAgeeVsOOBquOCi+WOn+S+oeODu+S7leWFpeOCjOWApFxyXG4gICAgLy8gaXRlbTog55Ww44Gq44KL44K744O844Or44CB6LKp5aOy5b2i5oWLXHJcbiAgICAvLyDigLsgcHJvZHVjdCDjgYvjgonjga/jgIHosqnlo7Llj6/og73jgarlnKjluqvjgIHliKnnm4roqIjnrpfjga7jgZ/jgoHjga7mg4XloLHjgpLlvpfjgotcclxuXHJcbiAgICBsZXQgcXVhbnRpdGllcyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcHJvZHVjdFJlZiBvZiBwcm9kdWN0U2V0KSB7XHJcbiAgICAgIGxldCBwcmRRdWFudGl0eSA9IDBcclxuXHJcbiAgICAgIGZvciAobGV0IGlkIG9mIHByb2R1Y3RSZWYuaWRzKSB7XHJcbiAgICAgICAgbGV0IHByb2R1Y3QgPSBhd2FpdCB0aGlzLlByb2R1Y3RzLmZpbmRPbmUoe1xyXG4gICAgICAgICAgX2lkOiBpZFxyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIHByb2plY3Rpb246IHtcclxuICAgICAgICAgICAgJ3N0b2NrJzogMVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgICAgbGV0IHN0b2NrQXJyYXkgPSBwcm9kdWN0LnN0b2NrXHJcblxyXG4gICAgICAgIC8vIOWNmOe0lOOBq+OBmeOBueOBpuOBruWcqOW6q+WVhuWTgeOAgeefreacn+mWk+WPluOCiuWvhOOBm+WPr+iDveWVhuWTgeOCkuWQiOeul1xyXG4gICAgICAgIGZvciAobGV0IHN0b2NrIG9mIHN0b2NrQXJyYXkpIHtcclxuICAgICAgICAgIHByZFF1YW50aXR5ICs9IHN0b2NrLnF1YW50aXR5XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICAvLyDllYblk4EoaXRlbSnjga7lnKjluqvmlbAgPSDoo73lk4HlnKjluqvmlbAocHJkUXVhbnRpdHkpIC8g5b+F6KaB44K744OD44OI5pWwKHByb2R1Y3RSZWYuc2V0KVxyXG4gICAgICBxdWFudGl0aWVzLnB1c2goTWF0aC5mbG9vcihwcmRRdWFudGl0eSAvIHByb2R1Y3RSZWYuc2V0KSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDjgrvjg4Pjg4jllYblk4Hjga7loLTlkIjjgIHkuIDnlarlsJHjgarjgYTllYblk4HmlbDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBxdWFudGl0eSA9IE1hdGgubWluLmFwcGx5KG51bGwsIHF1YW50aXRpZXMpXHJcblxyXG4gICAgcmV0dXJuIHF1YW50aXR5XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44KL44CCXHJcbiAgICpcclxuICAgKiDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6vjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcclxuICAgKiBjbGFzczHjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOeJueWumuOBruWxnuaAp++8iOOCq+ODqeODvOOBquOBqe+8ieOBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOBq+WApOOCkuaMh+WumuOBl+OAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqIOOCguOBl2NsYXNzMuOBruOBv+aMh+WumuOBl+OBn+OBhOWgtOWQiOOBr2NsYXNzMeOBq251bGzjgpLmjIflrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS+i++8mkpLLTEwMOOBrkJMQUNL44Gu5ZWG5ZOB55S75YOP44KSXHJcbiAgICog44GZ44G544Gm44Gu44K144Kk44K677yIUyxNLEwsWEwsMlhMLDNYTCw0WEzigKbvvInjgavplqLpgKPku5jjgZHjgovloLTlkIhcclxuICAgKiBzZXRJbWFnZSggdXBsb2FkSWQsICdKSy0xMDAnLCAnQkxBQ0snICk7XHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdXBsb2FkSWQg5LiA5Zue44Gu44Ki44OD44OX44Ot44O844OJ55S75YOP44KS5p2f44Gt44Gm44GE44KLSUTjgIJtZXRlb3Ljg4fjg7zjgr/jg5njg7zjgrnjgIFVcGxvYWRz44Kz44Os44Kv44K344On44Oz5YaF44OJ44Kt44Ol44Oh44Oz44OI44GudXBsb2FkSWTjg5fjg63jg5Hjg4bjgqNcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIHNldEltYWdlICh1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OBruaDheWgseWPluW+l1xyXG4gICAgbGV0IGltYWdlcyA9IFVwbG9hZHMuZmluZCh7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZFxyXG4gICAgfSkuZmV0Y2goKS5tYXAoKHYpID0+IHYudXBsb2FkZWRGaWxlTmFtZSlcclxuXHJcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcclxuICAgIGxldCBmaWx0ZXIgPSB7fVxyXG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWxcclxuICAgIGlmIChjbGFzczEpIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczFcclxuICAgIGlmIChjbGFzczIpIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczJcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxyXG4gICAgICBmaWx0ZXIsIHtcclxuICAgICAgICAkcHVzaDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiB7XHJcbiAgICAgICAgICAgICRlYWNoOiBpbWFnZXNcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyDnmbvpjLLjgZfjgZ/nlLvlg4/jg5XjgqHjgqTjg6vlkI3kuIDopqdcclxuICAgIHJldHVybiBpbWFnZXNcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavnmbvpjLLjgZXjgozjgabjgYTjgovnlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgY2xlYW5JbWFnZSAobW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlciwge1xyXG4gICAgICAgICRzZXQ6IHtcclxuICAgICAgICAgIGltYWdlczogW11cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBruWVhuWTgeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBruWxnuaAp+WIpeOBruWVhuWTgeaDheWgseOCkui/lOOBmeOAglxyXG4gICAqXHJcbiAgICog5byV5pWw44Go44GX44Gm5Y+X44GR5Y+W44KLaXRlbeOBr+S7u+aEj+OBruWVhuWTgeaDheWgseOAglxyXG4gICAqIGl0ZW3jgavplqLpgKPjgZnjgovllYblk4HnvqTjgavjgaTjgYTjgablv4XopoHjgarmg4XloLHjgpLmlbTnkIbjgZfov5TjgZnjgIJcclxuICAgKlxyXG4gICAqIHByb2plY3Tjgavlj4LnhafjgZfjgZ/jgYTllYblk4Hmg4XloLHjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZnjgovjgIJcclxuICAgKiDjg6Hjgr3jg4Pjg4njga7lkbzjgbPlh7rjgZfmmYLjgavlv4XopoHjgavlv5zjgZjjgaZwcm9qZWN044KS6Kit5a6a44GZ44KL44CCXHJcbiAgICpcclxuICAgKiDkvZXjgavms6jnm67jgZfjgabllYblk4Hjga7plqLpgKPmgKfjgpLmpJzlh7rjgZnjgovjgYvjga/jgIHjgZPjga7jg6Hjgr3jg4Pjg4nlhoXjgaflrprnvqnjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBpdGVtXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IHByb2plY3RcclxuICAgKi9cclxuICBhc3luYyBnZXRWYXJpYXRpb24gKGl0ZW0sIHByb2plY3QpIHtcclxuICAgIC8qKlxyXG4gICAgICogYWdncmVnYXRpb27oqK3lrppcclxuICAgICAqXHJcbiAgICAgKiBsYWJlbDog5bGe5oCn5ZCN77yI6YWN6YCB5pa55rOV44CB44Kr44Op44O844CB44K144Kk44K644Gq44Gp77yJXHJcbiAgICAgKiBjdXJyZW50OiDmjIflrprjgZXjgozjgZ/jgqLjgqTjg4bjg6DvvIhpdGVt77yJ44GM6Kmy5b2T44GZ44KL6aCF55uuXHJcbiAgICAgKiBwb3JqZWN0OiDjg5Djg6rjgqjjg7zjgrfjg6fjg7PmpJzntKLjga7jgq3jg7zjgajjgarjgotpdGVt5YaF44Gu44OV44Kj44O844Or44OJ5ZCNICRb44OV44Kj44O844Or44OJ5ZCNXeW9ouW8j1xyXG4gICAgICogcXVlcnk6IGFnZ3JlZ2F0aW9u5a++6LGh44Go44GZ44KL44OJ44Kt44Ol44Oh44Oz44OI44Gu5qSc57Si5p2h5Lu2XHJcbiAgICAgKi9cclxuICAgIGxldCBzZXQgPSBbe1xyXG4gICAgICBsYWJlbDogJ+mFjemAgeaWueazlScsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRkZWxpdmVyeSdcclxuICAgICAgfSxcclxuICAgICAgcXVlcnk6IHtcclxuICAgICAgICBjbGFzczFfdmFsdWU6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxyXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MxX25hbWUsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckY2xhc3MxX3ZhbHVlJ1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfSxcclxuICAgIHtcclxuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MyX25hbWUsXHJcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MyX3ZhbHVlLFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckY2xhc3MyX3ZhbHVlJ1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWVcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgXVxyXG5cclxuICAgIGxldCBhdHRycyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcyBvZiBzZXQpIHtcclxuICAgICAgYXR0cnMucHVzaCh7XHJcbiAgICAgICAgdmFyaWF0aW9uczogYXdhaXQgdGhpcy5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbe1xyXG4gICAgICAgICAgICAkbWF0Y2g6IE9iamVjdC5hc3NpZ24ocy5xdWVyeSwge1xyXG4gICAgICAgICAgICAgIG1vZGVsOiBpdGVtLm1vZGVsXHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAkcHJvamVjdDogT2JqZWN0LmFzc2lnbihzLnByb2plY3QsIHByb2plY3QpXHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAkc29ydDoge1xyXG4gICAgICAgICAgICAgIF9pZDogMVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKS50b0FycmF5KCksXHJcbiAgICAgICAgcHJvcHM6IHNcclxuICAgICAgfSlcclxuICAgIH1cclxuXHJcbiAgICBmb3IgKGxldCBhdHRyIG9mIGF0dHJzKSB7XHJcbiAgICAgIGZvciAobGV0IHYgb2YgYXR0ci52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgdi5zdG9jayA9IGF3YWl0IHRoaXMuZ2V0U3RvY2sodi5faWQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gYXR0cnNcclxuICB9XHJcblxyXG4gIC8vIOODouODh+ODq+OCr+ODqeOCueW9ouW8j+OCkuS9nOOCi1xyXG4gIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cclxuICBhc3luYyBnZXRNb2RlbENsYXNzIChhcmcpIHtcclxuICAgIGxldCBpdGVtXHJcbiAgICAvLyBpdGVtIOOBjOaWh+Wtl+WIl+OBquOCieOAgWl0ZW3jga/ku7vmhI/jga7jgqrjg5bjgrjjgqfjgq/jg4hJROOBruacq+WwvuOBi+OCieS7u+aEj+OBruahgeaVsOOBrjE26YCy5pWwXHJcbiAgICBpZiAodHlwZW9mIGFyZyA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgbGV0IGV4cCA9IG5ldyBSZWdFeHAoYCR7YXJnfSRgKVxyXG4gICAgICBsZXQgY3VyID0gdGhpcy5JdGVtcy5maW5kKHt9LCB7XHJcbiAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgbW9kZWw6IDEsXHJcbiAgICAgICAgICBjbGFzczFfdmFsdWU6IDEsXHJcbiAgICAgICAgICBjbGFzczJfdmFsdWU6IDFcclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgICB3aGlsZSAoMSkge1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBpdGVtID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICAgICAgbGV0IG1hdGNoID0gYXdhaXQgaXRlbS5faWQudG9IZXhTdHJpbmcoKS5tYXRjaChleHApXHJcbiAgICAgICAgICBpZiAobWF0Y2gpIHtcclxuICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyDoqbLlvZPjgZnjgotpdGVt44OH44O844K/44GM44Gq44GEXHJcbiAgICAgICAgICBjdXIuY2xvc2UoKVxyXG4gICAgICAgICAgcmV0dXJuIGFyZ1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgICBjdXIuY2xvc2UoKVxyXG4gICAgfSBlbHNlIHtcclxuICAgICAgaXRlbSA9IGFyZ1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBtb2RlbENsYXNzID0gW11cclxuICAgIGlmIChpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbClcclxuICAgIGlmIChpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpXHJcbiAgICByZXR1cm4gbW9kZWxDbGFzcy5qb2luKCcvJylcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTMgKGNyZWF0b3JJZCwgaXRlbSkge1xyXG4gICAgLy8g5YCk5aSJ5o+bXHJcbiAgICBsZXQgY29udkRlbGl2ID0gKGRlbGl2ZXJ5KSA9PiBkZWxpdmVyeSA9PT0gJ+OChuOBhuODkeOCseODg+ODiCcgPyAn44Od44K544OI5oqV5Ye9JyA6IGRlbGl2ZXJ5XHJcblxyXG4gICAgLy8gcHJvZHVjdF9pZFxyXG4gICAgbGV0IHByb2R1Y3RJZCA9IG51bGxcclxuICAgIGxldCBtb2RlbENsYXNzID0gW11cclxuXHJcbiAgICAvLyDkuIvoqJjjga7lvaLlvI/jgpLkvZzjgotcclxuICAgIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cclxuICAgIGlmIChpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbClcclxuICAgIGlmIChpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpXHJcblxyXG4gICAgLy8g5ZWG5ZOB56iu5Yil44KS5Ymy44KK5b2T44Gm44KLXHJcbiAgICBsZXQgcHJvZHVjdFR5cGVJZFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDFcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAyXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB44K/44Kw44KS6Kit5a6a44GZ44KLXHJcbiAgICBsZXQgdGFncyA9IFtdXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICB0YWdzLnB1c2goe1xyXG4gICAgICAgICAgdGFnOiA0LFxyXG4gICAgICAgICAgc2V0OiAnb24nXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgdGFnOiA1LFxyXG4gICAgICAgICAgc2V0OiAnb2ZmJ1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICB0YWdzLnB1c2goe1xyXG4gICAgICAgICAgdGFnOiA1LFxyXG4gICAgICAgICAgc2V0OiAnb24nXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgdGFnOiA0LFxyXG4gICAgICAgICAgc2V0OiAnb2ZmJ1xyXG4gICAgICAgIH0pXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4HliKXpgIHmlpnjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCBkZWxpdmVyeUZlZSA9IG51bGxcclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIGRlbGl2ZXJ5RmVlID0gbnVsbFxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgZGVsaXZlcnlGZWUgPSAyNDBcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vXHJcbiAgICAvLyDpoaflrqLlkJHjgZHjg5Djg6rjgqjjg7zjgrfjg6fjg7PllYblk4Hpgbjmip7mqZ/og73jga7lrp/oo4VcclxuICAgIC8vXHJcblxyXG4gICAgbGV0IGF0dHJzID0gYXdhaXQgdGhpcy5nZXRWYXJpYXRpb24oaXRlbSwge1xyXG4gICAgICBwcm9kdWN0X2lkOiAnJG1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9pZCdcclxuICAgIH0pXHJcblxyXG4gICAgLy8gSFRNTCDjg5Djg6rjgqjjg7zjgrfjg6fjg7PllYblk4HjgZTjgajjga7jg6rjg7Pjgq/ku5jjgY3jg5zjgr/jg7PjgpLooajnpLrjgZnjgotcclxuXHJcbiAgICAvLyDlgKTjga7lpInmj5tcclxuICAgIGF0dHJzID0gYXR0cnMubWFwKFxyXG4gICAgICAoYXR0cikgPT4ge1xyXG4gICAgICAgIGF0dHIucHJvcHMuY3VycmVudCA9IGNvbnZEZWxpdihhdHRyLnByb3BzLmN1cnJlbnQpXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zID0gYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgdmFyaWF0aW9uLnZhbHVlID0gY29udkRlbGl2KHZhcmlhdGlvbi52YWx1ZSlcclxuICAgICAgICAgICAgcmV0dXJuIHZhcmlhdGlvblxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICByZXR1cm4gYXR0clxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gSFRNTOeUn+aIkFxyXG4gICAgbGV0IHZhcmlhdGlvbkh0bWwgPVxyXG4gICAgICBhdHRycy5tYXAoXHJcbiAgICAgICAgKGF0dHIpID0+XHJcbiAgICAgICAgICAnPGRpdiBjbGFzcz1cImNvbnRhaW5lci1mbHVpZFwiPicgK1xyXG4gICAgICAgIGA8ZGl2IGNsYXNzPVwicm93XCI+YCArXHJcbiAgICAgICAgYDxkaXYgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGNsYXNzPVwiYnRuIGJ0bi1pbmZvIGJ0bi1ibG9jayBidG4teHNcIj5gICtcclxuICAgICAgICBgPHN0cm9uZz4ke2F0dHIucHJvcHMubGFiZWx9PC9zdHJvbmc+YCArXHJcbiAgICAgICAgYDwvZGl2PmAgK1xyXG4gICAgICAgIGF0dHIudmFyaWF0aW9ucy5tYXAoXHJcbiAgICAgICAgICAodmFyaWF0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChhdHRyLnByb3BzLmN1cnJlbnQgPT09IHZhcmlhdGlvbi52YWx1ZSkge1xyXG4gICAgICAgICAgICAgIC8vIOihqOekuuS4reOBruWVhuWTgeODnOOCv+ODs1xyXG4gICAgICAgICAgICAgIHJldHVybiBgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tc3VjY2VzcyBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+PHN0cm9uZz4ke3ZhcmlhdGlvbi52YWx1ZX08L3N0cm9uZz48L2J1dHRvbj5gXHJcbiAgICAgICAgICAgIH0gZWxzZVxyXG4gICAgICAgICAgICBpZiAodmFyaWF0aW9uLnN0b2NrID4gMCkge1xyXG4gICAgICAgICAgICAgIC8vIOiyqeWjsuWPr+iDveWVhuWTgeOBruODnOOCv+ODs1xyXG4gICAgICAgICAgICAgIHJldHVybiBgPGEgaHJlZj1cIi9wcm9kdWN0cy9kZXRhaWwvJHt2YXJpYXRpb24ucHJvZHVjdF9pZH1cIj48YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj48L2E+YFxyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIC8vIOiyqeWjsuS4jeWPr+iDveWVhuWTgeOBruODnOOCv+ODs++8iOWcqOW6q+OBquOBl++8iVxyXG4gICAgICAgICAgICAgIHJldHVybiBgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCIgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGRhdGEtdG9nZ2xlPVwidG9vbHRpcFwiIHRpdGxlPVwi5Zyo5bqr44GM44GU44GW44GE44G+44Gb44KTXCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+YFxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKS5qb2luKCcnKSArXHJcbiAgICAgICAgJzwvZGl2PicgK1xyXG4gICAgICAgICc8L2Rpdj4nXHJcbiAgICAgICkuam9pbignJylcclxuXHJcbiAgICBsZXQgZGVzY3JpcHRpb25EZXRhaWwgPSBgXHJcbiAgICA8c21hbGw+4oC7IOmFjemAgeaWueazleODu+OCq+ODqeODvOODu+OCteOCpOOCuuOBr+S4i+iomOOBi+OCieOBiumBuOOBs+OBj+OBoOOBleOBhOOAgjwvc21hbGw+XHJcbiAgICAke3ZhcmlhdGlvbkh0bWx9XHJcbiAgICBgXHJcblxyXG4gICAgLy8g5ZWG5ZOB44OH44O844K/44KS5L2c44KLXHJcbiAgICBsZXQgZGF0YSA9IHtcclxuICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxyXG4gICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgIG5hbWU6IGAke21vZGVsQ2xhc3Muam9pbignLycpfSAke2NvbnZEZWxpdihpdGVtLmRlbGl2ZXJ5KX0gJHtpdGVtLm5hbWV9JHtpdGVtLmphbl9jb2RlID8gJyAnICsgaXRlbS5qYW5fY29kZSA6ICcnfWAsXHJcbiAgICAgIGRlc2NyaXB0aW9uX2RldGFpbDogZGVzY3JpcHRpb25EZXRhaWwsXHJcbiAgICAgIC8vIGZyZWVfYXJlYTogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlRnJlZUFyZWEoaXRlbSksXHJcbiAgICAgIHByb2R1Y3RfY29kZTogbW9kZWxDbGFzcy5qb2luKCcvJyksXHJcbiAgICAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxyXG4gICAgICAvLyBwcmljZTAyOiBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyKGl0ZW0pLFxyXG4gICAgICAvLyBpbWFnZXM6IGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZUltYWdlcyhpdGVtKSxcclxuICAgICAgcHJvZHVjdF90eXBlX2lkOiBwcm9kdWN0VHlwZUlkLFxyXG4gICAgICB0YWdzOiB0YWdzLFxyXG4gICAgICBkZWxpdmVyeV9mZWU6IGRlbGl2ZXJ5RmVlXHJcbiAgICB9XHJcblxyXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVGcmVlQXJlYShpdGVtKSlcclxuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlUHJpY2UwMihpdGVtKSlcclxuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlSW1hZ2VzKGl0ZW0pKVxyXG5cclxuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgaXRlbS5tYWxsLnNoYXJha3VTaG9wKVxyXG5cclxuICAgIHJldHVybiBkYXRhXHJcbiAgfVxyXG5cclxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzY3JlYXRlRnJlZUFyZWEgKGl0ZW0pIHtcclxuICAgIGxldCBmcmVlQXJlYSA9ICcnXHJcbiAgICAvLyDllYblk4Hmg4XloLHjg4bjgq3jgrnjg4jjgpLoqJjovInjgZnjgotcclxuICAgIGZyZWVBcmVhICs9IGl0ZW0uZGVzY3JpcHRpb25cclxuICAgIC8vIDLnlarnm67ku6XpmY3jga7nlLvlg4/jgpLjg5Xjg6rjg7zjgqjjg6rjgqLjgavoqJjovInjgZnjgotcclxuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgZnJlZUFyZWEgKz0gYDxpbWcgc3JjPVwiL3VwbG9hZC9zYXZlX2ltYWdlLyR7aXRlbS5pbWFnZXNbaV19XCI+PGJyPmBcclxuICAgIH1cclxuICAgIC8vIOaDheWgseOBruOCr+ODquOColxyXG4gICAgZnJlZUFyZWEgKz0gJyAnXHJcbiAgICByZXR1cm4ge2ZyZWVfYXJlYTogZnJlZUFyZWF9XHJcbiAgfVxyXG5cclxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzY3JlYXRlUHJpY2UwMiAoaXRlbSkge1xyXG4gICAgLy8g5L6h5qC844KS6L+U44GZXHJcbiAgICByZXR1cm4ge3ByaWNlMDI6IGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcmljZX1cclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVJbWFnZXMgKGl0ZW0pIHtcclxuICAgIC8vIOeUu+WDj+ODquOCueODiOOBruOBhuOBoTHjgaTjgoHjgaDjgZHjgpLov5TjgZlcclxuICAgIGxldCBhcnIgPSB0eXBlb2YgaXRlbS5pbWFnZXNbMF0gPT09ICd1bmRlZmluZWQnID8gW10gOiBbIGl0ZW0uaW1hZ2VzWzBdIF1cclxuICAgIHJldHVybiB7IGltYWdlczogYXJyIH1cclxuICB9XHJcblxyXG4gIC8vIOODpOODleOCquOCr+ODhuODs+ODl+ODrOODvOODiOOBuOOBruWkieaPm1xyXG4gIGFzeW5jIGNvbnZlcnRJdGVtWWF1Y3QgKGRlZiwgaXRlbSkge1xyXG4gICAgY29uc3QgaWRMZW5ndGggPSAyMFxyXG4gICAgY29uc3QgdGl0bGVMZW5ndGggPSAxMzBcclxuXHJcbiAgICBsZXQgeWF1Y3QgPSB7fVxyXG4gICAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44Gu5Yid5pyf5YCk77yI44KG44GG44OR44Kx44OD44OI44O75a6F6YWN5L6/44Gn55Ww44Gq44KL77yJXHJcbiAgICB5YXVjdCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZGVmW2l0ZW0uZGVsaXZlcnldKSlcclxuXHJcbiAgICAvLyDnlLvlg4/jga7oqJjov7BcclxuICAgIGNvbnN0IGltZ1ByZWZpeCA9ICfnlLvlg48nXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGl0ZW0uaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHlhdWN0W2ltZ1ByZWZpeCArIChpICsgMSldID0gaXRlbS5pbWFnZXNbaV1cclxuICAgIH1cclxuXHJcbiAgICAvLyDjgr/jgqTjg4jjg6tcclxuICAgIHlhdWN0Wyfjgqvjg4bjgrTjg6onXSA9IGl0ZW0ubWFsbC55YXVjdC5jYXRlZ29yeVxyXG4gICAgeWF1Y3RbJ+OCv+OCpOODiOODqyddID0gVGV4dFV0aWwuc3Vic3RyOChgJHthd2FpdCB0aGlzLmdldE1vZGVsQ2xhc3MoaXRlbSl9ICR7aXRlbS5kZWxpdmVyeX0gJHtpdGVtLm5hbWV9YCwgdGl0bGVMZW5ndGgpXHJcbiAgICB5YXVjdFsn6ZaL5aeL5L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlXHJcbiAgICB5YXVjdFsn5Y2z5rG65L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlXHJcbiAgICB5YXVjdFsn566h55CG55Wq5Y+3J10gPSBpdGVtLl9pZC50b0hleFN0cmluZygpLnNsaWNlKC1pZExlbmd0aClcclxuICAgIHlhdWN0WyfoqqzmmI4nXSA9IGl0ZW0uZGVzY3JpcHRpb25cclxuICAgIHlhdWN0WydKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ10gPSBpdGVtLmphbl9jb2RlXHJcblxyXG4gICAgcmV0dXJuIHlhdWN0XHJcbiAgfVxyXG5cclxuICBhc3luYyBjb252ZXJ0SXRlbVdvd21hQ3JlYXRlRGVsaXZlcnlNZXRob2QgKGl0ZW1Db2RlKSB7XHJcbiAgICBsZXQgaWQgPSAnbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgIGxldCBzZXQgPSAnZGVsaXZlcnknXHJcbiAgICBsZXQgbWV0cmljcyA9IHtcclxuICAgICAgJ+OChuOBhuODkeOCseODg+ODiCc6IFsnUG9zdCddLFxyXG4gICAgICAn5a6F6YWN5L6/JzogWydZVS1QYWNrJywgJ0thbmdhcm9vJ11cclxuICAgIH1cclxuICAgIC8vIGRlbGl2ZXJ5TWV0aG9kU2VxXHJcblxyXG4gICAgbGV0IGFnZ3IgPSBhd2FpdCB0aGlzLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICBbaWRdOiBpdGVtQ29kZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgIF9pZDogYCQke2lkfWAsXHJcbiAgICAgICAgICAgIFtzZXRdOiB7ICRhZGRUb1NldDogYCQke3NldH1gIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgIF9pZDogMCxcclxuICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJyxcclxuICAgICAgICAgICAgW3NldF06IGAkJHtzZXR9YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgXVxyXG4gICAgKS50b0FycmF5KClcclxuXHJcbiAgICBsZXQgYWNjZXB0RGVsaXYgPSBbXVxyXG4gICAgZm9yIChsZXQgZGVsIG9mIGFnZ3JbMF0uZGVsaXZlcnkpIHtcclxuICAgICAgYWNjZXB0RGVsaXYgPSBhY2NlcHREZWxpdi5jb25jYXQobWV0cmljc1tgJHtkZWx9YF0pXHJcbiAgICB9XHJcbiAgICBsZXQgZGVsaXZlcnlNZXRob2QgPSBuZXcgQXJyYXkoNSlcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGVsaXZlcnlNZXRob2QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgbGV0IGlkID0gdHlwZW9mIGFjY2VwdERlbGl2W2ldID09PSAndW5kZWZpbmVkJyA/ICdOVUxMJyA6IGFjY2VwdERlbGl2W2ldXHJcbiAgICAgIGRlbGl2ZXJ5TWV0aG9kW2ldID0ge2RlbGl2ZXJ5TWV0aG9kU2VxOiBpICsgMSwgZGVsaXZlcnlNZXRob2RJZDogaWR9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtkZWxpdmVyeU1ldGhvZDogZGVsaXZlcnlNZXRob2R9XHJcbiAgfVxyXG5cclxuICAvL1xyXG4gIC8vIFJvYm90LWluIOWklumDqOmAo+aQuuWVhuWTgeeVquWPt+OBrueZu+mMsuOBruOBn+OCgeOBruODh+ODvOOCv+OCkuS9nOOCi1xyXG5cclxuICBzdGF0aWMgYXN5bmMgY29udmVydEl0ZW1Sb2JvdGluIChpdGVtKSB7XHJcbiAgICBsZXQgcm9ib3Rpbkl0ZW0gPSB7XHJcbiAgICAgIGl0ZW06IHtcclxuICAgICAgICAn44Kz44Oz44OI44Ot44O844Or44Kr44Op44OgJzogJ24nLFxyXG4gICAgICAgICfmlrDopo/nmbvpjLJJRCc6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXHJcbiAgICAgICAgJ+WVhuWTgUlEJzogbnVsbCxcclxuICAgICAgICAn5ZWG5ZOB5ZCNJzogaXRlbS5uYW1lLFxyXG4gICAgICAgICfopo/moLwnOiAn44Gq44GXJ1xyXG4gICAgICB9LFxyXG4gICAgICBzZWxlY3Q6IHtcclxuICAgICAgICAn44Kz44Oz44OI44Ot44O844Or44Kr44Op44OgJzogJ24nLFxyXG4gICAgICAgICfmlrDopo/nmbvpjLJJRCc6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXHJcbiAgICAgICAgJ+WVhuWTgUlEJzogbnVsbCxcclxuICAgICAgICAn5aSW6YOo6YCj5pC6SUQnOiBudWxsLFxyXG4gICAgICAgICflpJbpg6jpgKPmkLrllYblk4Hnlarlj7cnOiBgJHtpdGVtLm1vZGVsfS8ke2l0ZW0uY2xhc3MxX25hbWV9LyR7aXRlbS5jbGFzczJfbmFtZX1gXHJcbiAgICAgIH0sXHJcbiAgICAgIHNob3BTOiBbXVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHNob3BTID0gUm9ib3RpblNob3AuZmluZCgpLmZldGNoKClcclxuICAgIHNob3BTLmZvckVhY2goXHJcbiAgICAgIHNob3AgPT4ge1xyXG4gICAgICAgIGNvbnN0IG1vZGVsID0gaXRlbS5tYWxsW2Ake3Nob3AubmFtZX1gXVtgJHtzaG9wLm1vZGVsUGF0aH1gXVxyXG4gICAgICAgIGNvbnN0IGNsYXNzMSA9IGl0ZW0ubWFsbFtgJHtzaG9wLm5hbWV9YF1bYCR7c2hvcC5jbGFzczFQYXRofWBdXHJcbiAgICAgICAgY29uc3QgY2xhc3MyID0gaXRlbS5tYWxsW2Ake3Nob3AubmFtZX1gXVtgJHtzaG9wLmNsYXNzMlBhdGh9YF1cclxuXHJcbiAgICAgICAgcm9ib3Rpbkl0ZW0uc2hvcFMucHVzaChcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgJ+WPl+azqOWVhuWTgUlEJzogbnVsbCxcclxuICAgICAgICAgICAgJ+W6l+iIl0lEJzogc2hvcFsn5bqX6IiXSUQnXSxcclxuICAgICAgICAgICAgJ+W6l+iIl+WQjSc6IG51bGwsXHJcbiAgICAgICAgICAgICflj5fms6jllYblk4Hnlarlj7cnOiBgJHttb2RlbH0vJHtjbGFzczF9LyR7Y2xhc3MyfWAsXHJcbiAgICAgICAgICAgICfmnInlirnjg5Xjg6njgrAnOiAn5pyJ5Yq5J1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByb2JvdGluSXRlbVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0LXByb21pc2UnXHJcbmltcG9ydCB7IGpzb24yeG1sIH0gZnJvbSAneG1sLWpzJ1xyXG5pbXBvcnQgdXRpbEVycm9yIGZyb20gJy4uL3V0aWwvZXJyb3InXHJcblxyXG5jb25zdCBCQVNFX1VSSSA9ICdodHRwczovL2FwaS5tYW5hZ2VyLndvd21hLmpwL3dtc2hvcGFwaSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdvd21hQXBpIHtcclxuICBjb25zdHJ1Y3RvciAocGx1Zywgc2hvcElkKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnXHJcbiAgICB0aGlzLnNob3BJZCA9IHNob3BJZFxyXG4gIH1cclxuXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcbiAgYXN5bmMgdXBkYXRlSXRlbSAodXBkYXRlSXRlbSkge1xyXG4gICAgbGV0IHJlcXVlc3QgPSBgPHJlcXVlc3Q+PHNob3BJZD4ke3RoaXMuc2hvcElkfTwvc2hvcElkPjx1cGRhdGVJdGVtPiR7anNvbjJ4bWwodXBkYXRlSXRlbSwge2NvbXBhY3Q6IHRydWV9KX08L3VwZGF0ZUl0ZW0+PC9yZXF1ZXN0PmBcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnJlcXVlc3RQb3N0KFxyXG4gICAgICAgICd1cGRhdGVJdGVtSW5mbycsXHJcbiAgICAgICAgcmVxdWVzdFxyXG4gICAgICApXHJcbiAgICAgIHJldHVybiB7cmVzcG9uc2U6IHJlcywgcmVxdWVzdFhNTDogcmVxdWVzdH1cclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih1dGlsRXJyb3IucGFyc2UoZSksIHtyZXF1ZXN0WE1MOiByZXF1ZXN0fSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHJlcXVlc3RQb3N0IChtZXRob2QsIGJvZHkpIHtcclxuICAgIC8vIOaOpee2muOCquODl+OCt+ODp+ODs+OBruS9nOaIkFxyXG4gICAgbGV0IGFwaVJlcXVlc3QgPSB7XHJcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICB1cmk6IGAke0JBU0VfVVJJfS8ke21ldGhvZH1gLFxyXG4gICAgICBib2R5OiBib2R5XHJcbiAgICB9XHJcbiAgICAvLyDlhbHpgJrjga7mjqXntproqK3lrprjgajntZDlkIjjgZnjgotcclxuICAgIE9iamVjdC5hc3NpZ24oYXBpUmVxdWVzdCwgdGhpcy5wbHVnKVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3QoYXBpUmVxdWVzdClcclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9jayAoc3RvY2tVcGRhdGVJdGVtKSB7XHJcbiAgICAvLyDmjqXntprjgqrjg5fjgrfjg6fjg7Pjga7kvZzmiJBcclxuICAgIGxldCBhcGlSZXF1ZXN0ID0ge1xyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgdXJpOiBgJHtCQVNFX1VSSX0vdXBkYXRlU3RvY2tgXHJcbiAgICB9XHJcbiAgICAvLyDlhbHpgJrjga7mjqXntproqK3lrprjgajntZDlkIjjgZnjgotcclxuICAgIE9iamVjdC5hc3NpZ24oYXBpUmVxdWVzdCwgdGhpcy5wbHVnKVxyXG5cclxuICAgIGFwaVJlcXVlc3QuYm9keSA9IGF3YWl0IHRoaXMudXBkYXRlU3RvY2tDcmVhdGVSZXF1ZXN0Qm9keShzdG9ja1VwZGF0ZUl0ZW0pXHJcblxyXG4gICAgLy8g44Oq44Kv44Ko44K544OI55m66KGMXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgcmVxdWVzdChhcGlSZXF1ZXN0KVxyXG5cclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZVN0b2NrQ3JlYXRlUmVxdWVzdEJvZHkgKHN0b2NrVXBkYXRlSXRlbSkge1xyXG4gICAgLy9cclxuICAgIC8vIHN0b2NrVXBkYXRlSXRlbSA9XHJcbiAgICAvLyBbXHJcbiAgICAvLyAgIHtcclxuICAgIC8vICAgICBpdGVtQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgdmFyaWF0aW9uczogW1xyXG4gICAgLy8gICAgICAgIHtcclxuICAgIC8vICAgICAgICAgIGNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlOiA8U3RyaW5nPixcclxuICAgIC8vICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgICAgICBzdG9jazogPE51bWJlcj5cclxuICAgIC8vICAgICAgICB9XHJcbiAgICAvLyAgICAgXVxyXG4gICAgLy8gICB9XHJcbiAgICAvLyBdXHJcblxyXG4gICAgbGV0IHN0b2NrVXBkYXRlSXRlbVhNTCA9ICcnXHJcblxyXG4gICAgZm9yIChsZXQgaXRlbSBvZiBzdG9ja1VwZGF0ZUl0ZW0pIHtcclxuICAgICAgLy8g5YCk44Gu44OB44Kn44OD44KvXHJcbiAgICAgIGZvciAobGV0IGUgb2YgaXRlbS52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgLy8g5Zyo5bqr5pWw44Gu5LiK6ZmQMTAwXHJcbiAgICAgICAgaWYgKGUuc3RvY2sgPiAxMDApIGUuc3RvY2sgPSAxMDBcclxuICAgICAgfVxyXG5cclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tVcGRhdGVJdGVtPidcclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8aXRlbUNvZGU+JHtpdGVtLml0ZW1Db2RlfTwvaXRlbUNvZGU+YFxyXG5cclxuICAgICAgLy8g5ZWG5ZOB5Zyo5bqr56iu5Yil44KS5oyv44KK5YiG44GRXHJcbiAgICAgIC8vIDEgLT4g6YCa5bi45ZWG5ZOBXHJcbiAgICAgIC8vIDIgLT4g6YG45oqe6IKi5Yil5Zyo5bqrXHJcblxyXG4gICAgICBsZXQgdmFyMCA9IGl0ZW0udmFyaWF0aW9uc1swXVxyXG4gICAgICBpZiAodmFyMC5jaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZSA9PT0gJycgJiYgdmFyMC5jaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGUgPT09ICcnKSB7XHJcbiAgICAgICAgLy8g6YCa5bi45ZWG5ZOBXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tTZWdtZW50PjE8L3N0b2NrU2VnbWVudD4nXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8c3RvY2tDb3VudD4ke3ZhcjAuc3RvY2t9PC9zdG9ja0NvdW50PmBcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICAvLyDpgbjmip7ogqLliKXlnKjluqtcclxuICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxzdG9ja1NlZ21lbnQ+Mjwvc3RvY2tTZWdtZW50PidcclxuXHJcbiAgICAgICAgLy8g44Oq44Kv44Ko44K544OI44Oc44OH44Kj44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgZm9yIChsZXQgdmFyaWF0aW9uIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgICAgLy8g5Zyo5bqr6Kit5a6a44K/44Kw44Gu5ZCN5YmN44KS5beu44GX5pu/44GI44KLXHJcbiAgICAgICAgICB2YXJpYXRpb24uY2hvaWNlc1N0b2NrQ291bnQgPSB2YXJpYXRpb24uc3RvY2tcclxuICAgICAgICAgIGRlbGV0ZSB2YXJpYXRpb24uc3RvY2tcclxuXHJcbiAgICAgICAgICAvLyB4bWzjgpLmp4vmiJDjgZnjgotcclxuICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPGNob2ljZXNTdG9ja3M+J1xyXG4gICAgICAgICAgZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHZhcmlhdGlvbikpIHtcclxuICAgICAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8JHtrZXl9PiR7dmFyaWF0aW9uW2tleV19PC8ke2tleX0+YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8L2Nob2ljZXNTdG9ja3M+J1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8L3N0b2NrVXBkYXRlSXRlbT4nXHJcbiAgICB9XHJcblxyXG4gICAgLy8g44Oq44Kv44Ko44K544OI44Oc44OH44Kj44Gu5L2c5oiQXHJcbiAgICBsZXQgYXBpUmVxdWVzdEJvZHkgPSBgXHJcbiAgICA8cmVxdWVzdD5cclxuICAgIDxzaG9wSWQ+JHt0aGlzLnNob3BJZH08L3Nob3BJZD5cclxuICAgICR7c3RvY2tVcGRhdGVJdGVtWE1MfVxyXG4gICAgPC9yZXF1ZXN0PlxyXG4gICAgYFxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OCkui/lOOBmVxyXG4gICAgcmV0dXJuIGFwaVJlcXVlc3RCb2R5XHJcbiAgfVxyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIHV0aWxFcnJvciB7XHJcbiAgc3RhdGljIHBhcnNlIChlKSB7XHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICAgIHJlcy5tZXNzYWdlID0gZS5tZXNzYWdlXHJcbiAgICAgIHJlcy5uYW1lID0gZS5uYW1lXHJcbiAgICAgIHJlcy5maWxlTmFtZSA9IGUuZmlsZU5hbWVcclxuICAgICAgcmVzLmxpbmVOdW1iZXIgPSBlLmxpbmVOdW1iZXJcclxuICAgICAgcmVzLmNvbHVtbk51bWJlciA9IGUuY29sdW1uTnVtYmVyXHJcbiAgICAgIHJlcy5zdGFjayA9IGUuc3RhY2tcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlcyA9IGVcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvQ2xpZW50IH0gZnJvbSAnbW9uZ29kYidcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0NvbGxlY3Rpb24ge1xyXG4gIHN0YXRpYyBhc3luYyBnZXQgKHBsdWcsIGNvbGxlY3Rpb24pIHtcclxuICAgIGxldCBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG4gICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICByZXR1cm4gZGIuY29sbGVjdGlvbihjb2xsZWN0aW9uKVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnXHJcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlTUUwge1xyXG4gIGNvbnN0cnVjdG9yIChwcm9maWxlKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pjg5fjg7zjg6vliJ3mnJ/ljJZcclxuICAgIHRoaXMucG9vbCA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZSlcclxuXHJcbiAgICAvLyDopIfmlbDooYzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jlr77lv5xcclxuICAgIGxldCBwcm9maWxlTXVsdGkgPSB7bXVsdGlwbGVTdGF0ZW1lbnRzOiB0cnVlfVxyXG4gICAgT2JqZWN0LmFzc2lnbihwcm9maWxlTXVsdGksIHByb2ZpbGUpXHJcbiAgICB0aGlzLnBvb2xNdWx0aSA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZU11bHRpKVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZvcm1hdERhdGUgKGRhdGUpIHtcclxuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsIDE5KS5yZXBsYWNlKCdUJywgJyAnKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsXHJcbiAgICovXHJcbiAgcXVlcnkgKHNxbCkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz56K656uLXHJcbiAgICAvLyBsZXQgY29uID0gYXdhaXQgdGhpcy5nZXRDb24oKTtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwsIChlLCByZXMpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+mWi+aUvlxyXG4gICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxyXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXMpXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnRfIChzcWwpIHtcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O844CBbnVsbOOAgWphdmFzY3JpcHQtPm15c3Fs5pel5LuY5aSJ5o+b44Gr44KC5a++5b+cXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnQgKHRhYmxlLCBkYXRhID0ge30sIGRhdGFTcWwgPSB7fSkge1xyXG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgXHJcblxyXG4gICAgbGV0IG1hcCA9IG5ldyBNYXAoKVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCkge1xyXG4gICAgICAgIG1hcC5zZXQoaywgJ05VTEwnKVxyXG4gICAgICB9IGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG1hcC5zZXQoaywgYCR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgbWFwLnNldChrLCBkYXRhU3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YVNxbFtrXSlcclxuICAgIH1cclxuXHJcbiAgICBzcWwgKz0gYCggJHtbLi4ubWFwLmtleXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBzcWwgKz0gYFZBTFVFUyggJHtbLi4ubWFwLnZhbHVlcygpXS5qb2luKCcsJyl9ICkgYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICBhc3luYyBxdWVyeVVwZGF0ZSAodGFibGUsIGZpbHRlciwgZGF0YSwgZGF0YVNxbCkge1xyXG4gICAgbGV0IHNxbCA9IGBVUERBVEUgJHt0YWJsZX0gU0VUIGBcclxuXHJcbiAgICBsZXQgdXBkYXRlcyA9IFtdXHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgfVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhU3FsW2tdfWApXHJcbiAgICB9XHJcbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJylcclxuXHJcbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIC8vIGVuYWJsZSB0byB1c2UgbXVsdGlwbGUgc3RhdGVtZW50c1xyXG4gIGFzeW5jIHF1ZXJ5TXVsdGkgKHNxbCkge1xyXG4gICAgbGV0IHBvb2xTd2FwID0gdGhpcy5wb29sXHJcbiAgICB0aGlzLnBvb2wgPSB0aGlzLnBvb2xNdWx0aVxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3RhcnRUcmFuc2FjdGlvbiAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBTVEFSVCBUUkFOU0FDVElPTjtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29tbWl0ICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYENPTU1JVDtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcm9sbGJhY2sgKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgUk9MTEJBQ0s7YClcclxuICB9XHJcblxyXG4gIHN0cmVhbWluZ1F1ZXJ5IChzcWwsIG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pIHtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwpXHJcbiAgICAgICAgICAgICAgICAub24oJ3Jlc3VsdCcsXHJcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb24ucGF1c2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0KHJlY29yZClcclxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKClcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGVcclxuICAgICAgfSlcclxuICB9XHJcblxyXG4gIGdldENvbiAoKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAvLyDjg5fjg7zjg6vjgYvjgonjga7jgrPjg43jgq/jgrfjg6fjg7PnjbLlvpdcclxuICAgICAgICB0aGlzLnBvb2wuZ2V0Q29ubmVjdGlvbigoZSwgY29uKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICByZWplY3QoZSlcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUoY29uKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLmNhdGNoKFxyXG4gICAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgfTtcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBQYWNrZXQge1xyXG4gIGNvbnN0cnVjdG9yIChwYWNrZXRTaXplKSB7XHJcbiAgICB0aGlzLnBhY2tldFNpemUgPSBwYWNrZXRTaXplXHJcbiAgICB0aGlzLm9uUGFja2V0U3RhcnQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldEVuZCA9IG51bGxcclxuICAgIHRoaXMuY291bnQgPSAwXHJcbiAgICB0aGlzLnBhY2tldENvdW50ID0gMFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0IChhcmcpIHtcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHliJ3mnJ/ljJbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0U3RhcnQpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLm9uUGFja2V0U3RhcnQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMub25QYWNrZXQpIHtcclxuICAgICAgYXdhaXQgdGhpcy5vblBhY2tldChhcmcpXHJcbiAgICB9XHJcbiAgICB0aGlzLmNvdW50KytcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHntYLkuoblh6bnkIbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIHRoaXMuY2xvc2UoKVxyXG4gICAgICB0aGlzLnBhY2tldENvdW50KytcclxuICAgIH1cclxuICB9XHJcbiAgY2xvc2UgKCkge1xyXG4gICAgaWYgKHRoaXMub25QYWNrZXRFbmQpIHtcclxuICAgICAgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdXRpbEVycm9yIGZyb20gJy4vZXJyb3InXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgeyBMb2dzIH0gZnJvbSAnLi4vY29sbGVjdGlvbnMnXHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVwb3J0IHtcclxuICBjb25zdHJ1Y3RvciAoKSB7XHJcbiAgICB0aGlzLnJlY29yZCA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9ycyA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgLy8gcHJpdmF0ZVxyXG4gIHNldHVwSXRlcmF0b3IgKHBoYXNlSWQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IocGhhc2VJZClcclxuICAgIHRoaXMuaXRlcmF0b3JzLnB1c2godGhpcy5pdGVyYXRvcilcclxuICB9XHJcblxyXG4gIGFzeW5jIHBoYXNlIChuYW1lID0gJycsIGZuID0gYXN5bmMgKCkgPT4ge30pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHBoYXNlSWQ6IHVuaXFpZCgpXHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKHJlYy5waGFzZUlkKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCBmbigpXHJcblxyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdzdWNjZXNzJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHJlc1xyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiB1dGlsRXJyb3IucGFyc2UoZSlcclxuICAgICAgfSlcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIC8vIOODq+ODvOODl+WHpueQhuOBruODrOODneODvOODiOOCkuS9nOaIkFxyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci5tZXRyaWMudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3IubWV0cmljXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICAvLyDjgr/jgqTjg6Djgrnjgr/jg7Pjg5dcclxuICAgICAgcmVjLnRpbWVTdGFtcCA9IG5ldyBEYXRlKClcclxuICAgICAgLy8g44Os44Od44O844OI44KS44OH44O844K/44OZ44O844K544Gr6KiY6YyyXHJcbiAgICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuXHJcbiAgICAgIC8vIOWRvOOBs+WHuuOBl+WFg+eUqOODrOODneODvOODiOOBq+i/veWKoFxyXG4gICAgICB0aGlzLnJlY29yZC5wdXNoKHJlYylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIOOCq+ODvOOCveODq+OCkuODq+ODvOODl+OBl+OAgeS4juOBiOOCieOCjOOBn+mWouaVsOOCkuWun+ihjFxyXG4gIC8vIOWRvOOBs+WHuuOBmemWouaVsOOBruW8leaVsOOBq+OBr+OCq+ODvOOCveODq+OBi+OCieW+l+OCieOCjOOBn+ODieOCreODpeODoeODs+ODiOOCkua4oeOBmVxyXG4gIGFzeW5jIGZvckVhY2hPbkN1cnNvciAoY3VyLCBmbikge1xyXG4gICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgbGV0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZm4oZG9jKVxyXG4gICAgICAgIHRoaXMuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgdGhpcy5pRXJyb3IoZSlcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgY3VyLmNsb3NlKClcclxuICB9XHJcblxyXG4gIGlTdWNjZXNzIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3Iuc3VjY2VzcyhuZXdSZWNvcmQpXHJcbiAgfVxyXG5cclxuICBpRXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5lcnJvcih1dGlsRXJyb3IucGFyc2UobmV3UmVjb3JkKSlcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICBsZXQgaXRlRXJyb3IgPSB0aGlzLml0ZXJhdG9ycy5maW5kKGUgPT4gZS5lcnJvck9jdXJyZWQoKSlcclxuICAgIGxldCBwaGFFcnJvciA9IGZhbHNlXHJcbiAgICBmb3IgKGxldCByZWMgb2YgdGhpcy5yZWNvcmQpIHtcclxuICAgICAgaWYgKHJlYy50eXBlID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgcGhhRXJyb3IgPSB0cnVlXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGl0ZUVycm9yIHx8IHBoYUVycm9yXHJcbiAgfVxyXG5cclxuICBwdWJsaXNoICgpIHtcclxuICAgIC8vIOWRvOOBs+WHuuOBl+WFg+OBuOODrOODneODvOODiFxyXG4gICAgaWYgKHRoaXMuZXJyb3JPY3VycmVkKCkpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcih0aGlzLnJlY29yZClcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnJlY29yZFxyXG4gIH1cclxufVxyXG5cclxuY2xhc3MgSXRlcmF0b3Ige1xyXG4gIGNvbnN0cnVjdG9yIChwaGFzZUlkKSB7XHJcbiAgICB0aGlzLm1ldHJpYyA9IHtcclxuICAgICAgdG90YWw6IDAsXHJcbiAgICAgIHN1Y2Nlc3M6IDAsXHJcbiAgICAgIGVycm9yOiAwLFxyXG4gICAgICBwaGFzZUlkOiBwaGFzZUlkXHJcbiAgICB9XHJcbiAgICB0aGlzLmxhc3RFcnJvciA9IG51bGxcclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLmxvZyhuZXdSZWNvcmQsIHRydWUpXHJcbiAgICB9XHJcbiAgICB0aGlzLm1ldHJpYy5zdWNjZXNzKytcclxuICAgIHRoaXMubWV0cmljLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIC8vIOebtOWJjeOBqOWQjOOBmOOCqOODqeODvOOBr+ecgeOBj1xyXG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KHRoaXMubGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMubG9nKG5ld1JlY29yZCwgZmFsc2UpXHJcbiAgICAgICAgdGhpcy5sYXN0RXJyb3IgPSBuZXdSZWNvcmRcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy5tZXRyaWMuZXJyb3IrK1xyXG4gICAgdGhpcy5tZXRyaWMudG90YWwrK1xyXG4gIH1cclxuXHJcbiAgbG9nIChuZXdSZWNvcmQsIGlzU3VjY2VzcyAvKiB0cnVlID0+IHN1Y2Nlc3Mgb3IgZmFsc2UgPT4gZXJyb3IgKi8pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IGlzU3VjY2VzcyxcclxuICAgICAgcGhhc2VJZDogdGhpcy5tZXRyaWMucGhhc2VJZCxcclxuICAgICAgbWVzc2FnZTogbmV3UmVjb3JkLFxyXG4gICAgICB0aW1lU3RhbXA6IG5ldyBEYXRlKClcclxuICAgIH1cclxuICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMuZXJyb3JcclxuICB9XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGV4dFV0aWwge1xyXG4gIHN0YXRpYyBzdWJzdHI4ICh0ZXh0LCBsZW4sIHRydW5jYXRpb24pIHtcclxuICAgIGlmICh0cnVuY2F0aW9uID09PSB1bmRlZmluZWQpIHsgdHJ1bmNhdGlvbiA9ICcnIH1cclxuICAgIHZhciB0ZXh0QXJyYXkgPSB0ZXh0LnNwbGl0KCcnKVxyXG4gICAgdmFyIGNvdW50ID0gMFxyXG4gICAgdmFyIHN0ciA9ICcnXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRleHRBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICB2YXIgbiA9IGVzY2FwZSh0ZXh0QXJyYXlbaV0pXHJcbiAgICAgIGlmIChuLmxlbmd0aCA8IDQpIGNvdW50KytcclxuICAgICAgZWxzZSBjb3VudCArPSAyXHJcbiAgICAgIGlmIChjb3VudCA+IGxlbikge1xyXG4gICAgICAgIHJldHVybiBzdHIgKyB0cnVuY2F0aW9uXHJcbiAgICAgIH1cclxuICAgICAgc3RyICs9IHRleHQuY2hhckF0KGkpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGV4dFxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2xvZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2FkcycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5leHBvcnQgY29uc3QgUm9ib3RpblNob3AgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncm9ib3RpblNob3AnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuZXhwb3J0IGNvbnN0IEl0ZW1zVGVzdCA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdpdGVtc1Rlc3QnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuIl19
