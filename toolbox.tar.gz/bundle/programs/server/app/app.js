var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/route/upload/image.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

// WebApp.connectHandlers.use('/upload', (req, res, next) => {
//   res.writeHead(200);
//   res.end(`Hello world from: ${Meteor.release}`);
// });

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

// Requires multiparty

var _connectMultiparty = require('connect-multiparty');

var _connectMultiparty2 = _interopRequireDefault(_connectMultiparty);

var _importsCollections = require('../../../imports/collections');

var multipartyMiddleware = (0, _connectMultiparty2['default'])();

var route = '/upload/image';

// WebApp.connectHandlers.use('/upload', fuc.uploadFile );
WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, function (req, resp) {
  // don't forget to delete all req.files when done

  var reader = Meteor.wrapAsync(_fs2['default'].readFile);
  var writer = Meteor.wrapAsync(_fs2['default'].writeFile);
  var uploadId = (0, _uniqid2['default'])();

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = req.files.file[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var file = _step.value;

      var data = reader(file.path);
      // ファイル名の重複を避けるため、一意のファイル名を作成する
      // 楽天のファイル名文字数制限20に合わせる
      var filename = (0, _uniqid2['default'])() + '.jpg';

      // set the correct path for the file not the temporary one from the API:
      var savePath = req.body.imagedir + '/' + filename;

      // copy the data from the req.files.file.path and paste it to file.path

      // アップロード結果を記録する
      var doc = {
        uploadId: uploadId,
        clientFileName: file.name,
        uploadedFileName: filename
      };

      try {
        writer(savePath, data);
      } catch (err) {
        doc.error = err;
      }
      _importsCollections.Uploads.insert(doc);

      delete file;
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator['return']) {
        _iterator['return']();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube/cubemig.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _crypto = require('crypto');

var _crypto2 = _interopRequireDefault(_crypto);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsUtilReport = require('../../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsCollectionGroups = require('../../imports/collection/groups');

var _importsCollectionFilters = require('../../imports/collection/filters');

var tag = 'cubemig';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.migrate', function callee$0$0(config) {
  var report, filter, testQuery, dstDb;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsCollectionFilters.Filter(config.srcFilterId);
        testQuery = 'SHOW DATABASES';
        dstDb = new _importsUtilMysql2['default'](config.dst.cred);
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(report.phase('Connect to Destination', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(dstDb.query(testQuery));

              case 2:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 6:
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(report.phase('Select loop in source', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this2 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  mobileNull: function mobileNull(record) {
                    var sql, couponCd, couponName, discountPrice, _res;

                    return regeneratorRuntime.async(function mobileNull$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          sql = '\n\n                INSERT dtb_customer\n                ( `customer_id`, `status`, `sex`, `job`, `country_id`, `pref`, `name01`, `name02`, `kana01`, `kana02`, `company_name`, `zip01`, `zip02`, `zipcode`, `addr01`, `addr02`, `email`, `tel01`, `tel02`, `tel03`, `fax01`, `fax02`, `fax03`, `birth`, `password`, `salt`, `secret_key`, `first_buy_date`, `last_buy_date`, `buy_times`, `buy_total`, `note`, `create_date`, `update_date`, `del_flg` )\n\n                VALUES( ' + record.customer_id + ' , ' + record.status + ' , ' + record.sex + ' , ' + record.job + ' , ' + record.country_id + ' , ' + record.pref + ' , ' + record.name01 + ' , ' + record.name02 + ' , ' + record.kana01 + ' , ' + record.kana02 + ' , ' + record.company_name + ' , ' + record.zip01 + ' , ' + record.zip02 + ' , ' + record.zipcode + ' , ' + record.addr01 + ' , ' + record.addr02 + ' , ' + record.email + ' , ' + record.tel01 + ' , ' + record.tel02 + ' , ' + record.tel03 + ' , ' + record.fax01 + ' , ' + record.fax02 + ' , ' + record.fax03 + ' , ' + record.birth + ' , ' + record.password + ' , ' + record.salt + ' , ' + record.secret_key + ' , ' + record.first_buy_date + ' , ' + record.last_buy_date + ' , ' + record.buy_times + ' , ' + record.buy_total + ' , ' + record.note + ' , ' + record.create_date + ' , ' + record.update_date + ' , ' + record.del_flg + ' )\n                \n                ';
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer', {
                            customer_id: record.customer_id,
                            status: record.status,
                            sex: record.sex,
                            job: record.job,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            email: record.email,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            birth: record.birth,
                            password: record.password,
                            salt: record.salt,
                            secret_key: record.secret_key,
                            first_buy_date: record.first_buy_date,
                            last_buy_date: record.last_buy_date,
                            buy_times: record.buy_times,
                            buy_total: record.buy_total,
                            note: record.note,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 4:
                          context$3$0.next = 9;
                          break;

                        case 6:
                          context$3$0.prev = 6;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 9:
                          context$3$0.prev = 9;
                          context$3$0.next = 12;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer_address', {
                            customer_address_id: null,
                            customer_id: record.customer_id,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 12:
                          context$3$0.next = 17;
                          break;

                        case 14:
                          context$3$0.prev = 14;
                          context$3$0.t1 = context$3$0['catch'](9);

                          report.iError(context$3$0.t1);

                        case 17:
                          context$3$0.prev = 17;
                          context$3$0.next = 20;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_mailmaga_customer', {
                            id: null,
                            customer_id: record.customer_id,
                            mailmaga_flg: record.mailmaga_flg,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 20:
                          context$3$0.next = 25;
                          break;

                        case 22:
                          context$3$0.prev = 22;
                          context$3$0.t2 = context$3$0['catch'](17);

                          report.iError(context$3$0.t2);

                        case 25:
                          couponCd = _crypto2['default'].randomBytes(8).toString('base64').substring(0, 11);
                          couponName = record.name01 + ' ' + record.name02 + ' 様 ご優待クーポン 会員番号:' + record.customer_id;
                          discountPrice = record.point + 500;
                          context$3$0.prev = 28;
                          context$3$0.next = 31;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_coupon', {
                            coupon_id: null,
                            coupon_cd: couponCd,
                            coupon_type: 3, // 全商品
                            coupon_name: couponName,
                            discount_type: 1,
                            coupon_use_time: 1,
                            coupon_release: 1,
                            discount_price: discountPrice,
                            discount_rate: null,
                            enable_flag: 1,
                            coupon_member: 1,
                            coupon_lower_limit: null,
                            customer_id: record.customer_id,
                            available_from_date: '2018-04-02 00:00:00',
                            available_to_date: '2019-05-02 00:00:00',
                            del_flg: 0
                          }, {
                            create_date: 'NOW()',
                            update_date: 'NOW()'
                          }));

                        case 31:
                          _res = context$3$0.sent;
                          context$3$0.next = 37;
                          break;

                        case 34:
                          context$3$0.prev = 34;
                          context$3$0.t3 = context$3$0['catch'](28);

                          report.iError(context$3$0.t3);

                        case 37:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this2, [[1, 6], [9, 14], [17, 22], [28, 34]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        report.iError(e);

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this2);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 8:
        return context$1$0.abrupt('return', report.publish());

      case 9:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, 'cubemig.serverCheck', function cubemigServerCheck(profile) {
  var db, res;
  return regeneratorRuntime.async(function cubemigServerCheck$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        db = new _importsUtilMysql2['default'](profile);
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(db.query('SHOW DATABASES'));

      case 3:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// setup group
//

// let plug = group.getPlug();

// checking connection
//

// process for each members
//

// // 値を整理
// for (let key of Object.keys(record)) {
//   if (record[key] === null);
//   else if (record[key].constructor.name === 'Date') {
//     // 日付を変換
//     record[key] = MySQL.formatDate(record[key]);
//     record[key] = `"${record[key]}"`;
//   }
// }

// dtb_customer に保存

// dtb_customer_address

// メルマガプラグイン plg_mailmaga_customer

// クーポン発行（ECCUBE2のポイント還元）
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/collection.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilMongo = require('../../imports/util/mongo');

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.collection';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.find', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var projection = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.find(query, { projection: projection }).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.aggregate', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.aggregate(query).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/items.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsServiceItems = require('../../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.items';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.setImage', function callee$0$0(plug, uploadId, model) {
  var class1 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var class2 = arguments.length <= 4 || arguments[4] === undefined ? null : arguments[4];
  var itemcon, uploaded;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.setImage(uploadId, model, class1, class2));

      case 5:
        uploaded = context$1$0.sent;
        return context$1$0.abrupt('return', uploaded);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.cleanImage', function callee$0$0(plug, model) {
  var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
  var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var itemcon;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.cleanImage(model, class1, class2));

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

/**
 * 指定された条件に一致するitemsコレクション内のドキュメントに、
 * アップロード済み画像を関連付けます。
 * @param
 */

/**
 * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceCube3api = require('../imports/service/cube3api');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'cube';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('在庫の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({

                  'UPDATE': function UPDATE(item, context) {
                    var quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;
                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 5:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibItem', function callee$0$0(config) {
  var filter, targetDB, api, itemController, report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 6:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3への商品登録', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  'INSERT': function INSERT(item, context) {
                    var col, cubeItem, insertRes;
                    return regeneratorRuntime.async(function INSERT$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.creator_id, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productCreate(cubeItem));

                        case 7:
                          insertRes = context$3$0.sent;
                          context$3$0.next = 10;
                          return regeneratorRuntime.awrap(col.update({
                            _id: item._id
                          }, {
                            $set: {
                              'mall.sharakuShop.product_id': insertRes.res.product_id,
                              'mall.sharakuShop.product_class_id': insertRes.res.product_class_id,
                              'mall.sharakuShop.product_stock_id': insertRes.res.product_stock_id
                            }
                          }));

                        case 10:

                          report.iSuccess();
                          context$3$0.next = 16;
                          break;

                        case 13:
                          context$3$0.prev = 13;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 16:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3, [[1, 13]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 9:
        context$1$0.next = 11;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3商品情報の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  'UPDATE': function UPDATE(item, context) {
                    var col, cubeItem, quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.creator_id, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productImageUpdate(cubeItem));

                        case 7:
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(api.productUpdate(cubeItem));

                        case 9:
                          context$3$0.next = 11;
                          return regeneratorRuntime.awrap(api.productTagUpdate(cubeItem));

                        case 11:
                          context$3$0.next = 13;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 13:
                          quantity = context$3$0.sent;
                          context$3$0.next = 16;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 16:

                          report.iSuccess();
                          context$3$0.next = 22;
                          break;

                        case 19:
                          context$3$0.prev = 19;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 22:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this5, [[1, 19]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 11:
        return context$1$0.abrupt('return', report.publish());

      case 12:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 商品情報登録と更新

// クライアントが参照するための処理結果作成オブジェクト

// item データベースへの登録
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/robotin.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var _fibers = require('fibers');

var _fibers2 = _interopRequireDefault(_fibers);

var _importsServiceRobotin = require('../imports/service/robotin');

var _importsServiceRobotin2 = _interopRequireDefault(_importsServiceRobotin);

var tag = 'robotin';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.postlabel', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 送り状発行', function callee$1$0() {
          var workdir, workdirRead, workdirWrite, itemS, robo;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.postlabel.workdir;
                workdirRead = workdir + '/' + config.postlabel.workdirRead;
                workdirWrite = workdir + '/' + config.postlabel.workdirWrite;
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirRead));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                context$2$0.prev = 24;
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirWrite));

              case 27:
                context$2$0.next = 31;
                break;

              case 29:
                context$2$0.prev = 29;
                context$2$0.t3 = context$2$0['catch'](24);

              case 31:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 34;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 34:
                robo = new _importsServiceRobotin2['default']();

                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _fsExtra2['default'].createReadStream(workdirRead + '/' + config.postlabel.ordercsv + '.csv').on('error', function (err) {
                    mcb(err);
                  });
                  var write = new _stream.Writable({
                    objectMode: true,
                    write: function write(chunk, encoding, callback) {
                      return regeneratorRuntime.async(function write$(context$4$0) {
                        while (1) switch (context$4$0.prev = context$4$0.next) {
                          case 0:
                            context$4$0.next = 2;
                            return regeneratorRuntime.awrap(robo.importOrder(chunk, itemS));

                          case 2:
                            callback();

                          case 3:
                          case 'end':
                            return context$4$0.stop();
                        }
                      }, null, this);
                    },
                    final: function final(callback) {
                      callback();
                      mcb();
                    }
                  });

                  read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(write);
                })();

                // 送り状種別ごとに繰り返す
                config.postlabel.labeltypes.forEach(function (labelOption) {
                  try {
                    _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                      var read = _fsExtra2['default'].createReadStream(workdirRead + '/' + labelOption.readcsv + '.csv').on('error', function () {
                        mcb();
                      }); // ファイルがない場合は無視
                      var transform = new _stream.Transform({
                        readableObjectMode: true,
                        writableObjectMode: true,
                        transform: function transform(chunk, encoding, callback) {
                          var record = undefined;
                          try {
                            record = robo[labelOption.method](chunk, labelOption);
                            callback(null, record);
                          } catch (error) {
                            mcb(error);
                          }
                        }
                      });
                      var write = _fsExtra2['default'].createWriteStream(workdirWrite + '/' + labelOption.writecsv + '.csv').on('finish', function () {
                        report.iSuccess();
                        mcb();
                      }).on('error', function (error) {
                        mcb(error);
                      });

                      read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: labelOption.columns === true ? true : null })).pipe(transform).pipe(_csv2['default'].stringify({ header: labelOption.columns })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(write);
                    })();
                  } catch (error) {
                    report.iError(error);
                  }
                });

              case 37:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this, [[3, 8], [10, 15], [17, 22], [24, 29]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.itemcode', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 外部連携商品番号', function callee$1$0() {
          var workdir, itemController, read, writeCsv;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.itemcode.workdir;
                context$2$0.prev = 1;
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 4:
                context$2$0.next = 8;
                break;

              case 6:
                context$2$0.prev = 6;
                context$2$0.t0 = context$2$0['catch'](1);

              case 8:
                context$2$0.prev = 8;
                context$2$0.next = 11;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 11:
                context$2$0.next = 22;
                break;

              case 13:
                context$2$0.prev = 13;
                context$2$0.t1 = context$2$0['catch'](8);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 18;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 18:
                read = itemController.Items.find({ model: { $ne: '' } }).stream();

                writeCsv = function writeCsv(read, tf, filename) {
                  var robotin = new _stream.Transform({
                    readableObjectMode: true,
                    writableObjectMode: true,
                    transform: function transform(chunk, encoding, callback) {
                      (0, _fibers2['default'])(function () {
                        var data = tf(chunk);
                        callback(null, data);
                      }).run();
                    }
                  });
                  var count = 0;
                  var clearnum = new _stream.Transform({
                    encoding: 'utf8',
                    transform: function transform(chunk, encoding, callback) {
                      var str = chunk.toString();
                      if (count === 0) {
                        str = str.replace(/_\d+?/g, '');
                      }
                      count++;
                      callback(null, str);
                    }
                  });
                  var writecsv = _fsExtra2['default'].createWriteStream(filename + '.csv');
                  writecsv.on('error', function (e) {
                    throw _meteorMeteor.Meteor.Error('CSVファイル書き込みエラー');
                  });

                  read.pipe(robotin).pipe(_csv2['default'].stringify({ header: true })).pipe(clearnum).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(writecsv);
                };

                writeCsv(read, _importsServiceItems2['default'].convertItemRobotinItem, workdir + '/' + config.itemcode.csvNameItem);

                writeCsv(read, _importsServiceItems2['default'].convertItemRobotinSelect, workdir + '/' + config.itemcode.csvNameSelect);

              case 22:
                throw new _meteorMeteor.Meteor.Error('正しい作業ディレクトリが用意されていませんでした。\n[' + workdir + ']');

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2, [[1, 6], [8, 13]]);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 書き込みフォルダ

// workdir が準備されていたら実行する

// 受注CSVを読み込む

//
// Robot-in
// 外部連携商品番号

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// workdir が準備されていたら実行する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/tooltest.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _meteorMeteor = require('meteor/meteor');

var tag = 'tool';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.test', function callee$0$0(config) {
  var report, filter, newLocal;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        context$1$0.next = 4;
        return regeneratorRuntime.awrap(filter.foreach({}, function callee$1$0(e) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                throw e;

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 4:
        newLocal = context$1$0.sent;
        context$1$0.next = 7;
        return regeneratorRuntime.awrap(report.phase('フィルターテスト', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                return context$2$0.abrupt('return', newLocal);

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 7:
        return context$1$0.abrupt('return', report.publish());

      case 8:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// 商品情報更新

// クライアントが参照するための処理結果作成オブジェクト
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowma.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _importsServiceWowmaApi = require('../imports/service/wowmaApi');

var _importsServiceWowmaApi2 = _interopRequireDefault(_importsServiceWowmaApi);

var _importsUtilError = require('../imports/util/error');

var _importsUtilError2 = _interopRequireDefault(_importsUtilError);

var tag = 'wowma';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateItem.deliveryMethod', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品の配送方法を設定する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }]
                  }
                },
                // テスト検索条件設定
                // {
                //   $or: [
                //     {
                //       'mall.wowma.itemCode': 'gk-163'
                //     },
                //     {
                //       'mall.wowma.itemCode': '10004942' // JK-120
                //     }
                //     // {
                //     //   'mall.wowma.itemCode': '10005402'
                //     // },
                //     // {
                //     //   'mall.wowma.itemCode': '10004743'
                //     // }
                //   ]
                // }
                {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        context$3$0.t0 = Object;
                        context$3$0.t1 = item;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.convertItemWowmaCreateDeliveryMethod(item.itemCode));

                      case 4:
                        context$3$0.t2 = context$3$0.sent;
                        context$3$0.t0.assign.call(context$3$0.t0, context$3$0.t1, context$3$0.t2);
                        context$3$0.prev = 6;
                        context$3$0.next = 9;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 9:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 13:
                        context$3$0.prev = 13;
                        context$3$0.t3 = context$3$0['catch'](6);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t3));

                      case 16:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[6, 13]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.open', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品データベース上の商品を公開する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        item.saleStatus = 1;
                        item.limitedPasswd = 'NULL';
                        context$3$0.prev = 2;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 5:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 9:
                        context$3$0.prev = 9;
                        context$3$0.t0 = context$3$0['catch'](2);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 12:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[2, 9]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this5 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 在庫更新', function callee$1$0() {
          var itemController, cur, item, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, e, api, res;

          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    //   ,{
                    //     $or: [
                    //       {
                    //         'mall.wowma.itemCode': '10005402'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': 'gk-163'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': '10004743'
                    //       }
                    //     ]
                    //   }
                    ]
                  }
                }, {
                  // 配送方法の違いを省く
                  $group: {
                    _id: {
                      itemCode: '$mall.wowma.itemCode',
                      choicesStockHorizontalCode: '$mall.wowma.HChoiceName',
                      choicesStockVerticalCode: '$mall.wowma.VChoiceName'
                    },
                    item: {
                      $first: '$_id'
                    }
                  }
                }, {
                  // 商品ページごと（商品コード）にグループ化する
                  $group: {
                    _id: '$_id.itemCode',
                    variations: {
                      $push: {
                        _id: '$item',
                        choicesStockHorizontalCode: '$_id.choicesStockHorizontalCode',
                        choicesStockVerticalCode: '$_id.choicesStockVerticalCode'
                      }
                    }
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id',
                    variations: '$variations'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;

              case 6:
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(cur.hasNext());

              case 8:
                if (!context$2$0.sent) {
                  context$2$0.next = 53;
                  break;
                }

                context$2$0.next = 11;
                return regeneratorRuntime.awrap(cur.next());

              case 11:
                item = context$2$0.sent;
                _iteratorNormalCompletion = true;
                _didIteratorError = false;
                _iteratorError = undefined;
                context$2$0.prev = 15;
                _iterator = item.variations[Symbol.iterator]();

              case 17:
                if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                  context$2$0.next = 26;
                  break;
                }

                e = _step.value;
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(itemController.getStock(e._id));

              case 21:
                e.stock = context$2$0.sent;

                delete e._id;

              case 23:
                _iteratorNormalCompletion = true;
                context$2$0.next = 17;
                break;

              case 26:
                context$2$0.next = 32;
                break;

              case 28:
                context$2$0.prev = 28;
                context$2$0.t0 = context$2$0['catch'](15);
                _didIteratorError = true;
                _iteratorError = context$2$0.t0;

              case 32:
                context$2$0.prev = 32;
                context$2$0.prev = 33;

                if (!_iteratorNormalCompletion && _iterator['return']) {
                  _iterator['return']();
                }

              case 35:
                context$2$0.prev = 35;

                if (!_didIteratorError) {
                  context$2$0.next = 38;
                  break;
                }

                throw _iteratorError;

              case 38:
                return context$2$0.finish(35);

              case 39:
                return context$2$0.finish(32);

              case 40:
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.prev = 41;
                context$2$0.next = 44;
                return regeneratorRuntime.awrap(api.updateStock([item]));

              case 44:
                res = context$2$0.sent;

                report.iSuccess(res);
                context$2$0.next = 51;
                break;

              case 48:
                context$2$0.prev = 48;
                context$2$0.t1 = context$2$0['catch'](41);

                report.iError(context$2$0.t1);

              case 51:
                context$2$0.next = 6;
                break;

              case 53:
                cur.close();

              case 54:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this5, [[15, 28, 32, 40], [33,, 35, 39], [41, 48]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.searchItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this7 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, workdir, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this6 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.prev = 4;
                context$2$0.next = 7;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 7:
                context$2$0.next = 11;
                break;

              case 9:
                context$2$0.prev = 9;
                context$2$0.t0 = context$2$0['catch'](4);

              case 11:
                workdir = config.workdir + '/items_' + new Date().getTime();
                context$2$0.prev = 12;
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 15:
                context$2$0.next = 19;
                break;

              case 17:
                context$2$0.prev = 17;
                context$2$0.t1 = context$2$0['catch'](12);

              case 19:
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var options, repos, filename;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          options = JSON.parse(JSON.stringify(config.wowmaApi));

                          options.uri = options.uri + '/searchItemInfo';
                          options.qs.itemCode = item.mall.wowma.itemCode;

                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

                        case 5:
                          repos = context$3$0.sent;
                          filename = workdir + '/' + item.model + '.xml';
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(_fsExtra2['default'].writeFile(filename, repos));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this6);
                  } }));

              case 21:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this7, [[4, 9], [12, 17]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// WOWMA 商品の配送方法を設定する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品データベース上の商品を公開する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 在庫情報の作成

// let resMongo = await cur.toArray()
// return resMongo

// リクエストボディ

// 在庫を設定する

//
// 在庫更新リクエスト

//
// WOWMA 商品検索

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 作業フォルダを作成する

// APIから取得した商品情報を保存する場所

// 作業フォルダを作成する

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowmaApi.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'wowmaApi';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.getItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.WowmaApiItemFilter(config.wowmaApi, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          report.iSuccess(item);

                        case 1:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 6:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 8:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// WOWMA商品情報取得

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(config.workdir)
// } catch (e) {}

// // APIから取得した商品情報を保存する場所
// const workdir = `${config.workdir}/items_${(new Date()).getTime()}`
// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(workdir)
// } catch (e) {}

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/yauct.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilPacket = require('../imports/util/packet');

var _importsUtilPacket2 = _interopRequireDefault(_importsUtilPacket);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var prefix = 'packet';
var tag = 'yauct';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク受注', function callee$1$0() {
          var itemController, workdir, r, w;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                workdir = config.workdir + '/order';
                r = _fsExtra2['default'].createReadStream(workdir + '/' + config.orderLoadfile);
                w = _fsExtra2['default'].createWriteStream(workdir + '/' + config.orderSavefile);

                r.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(_csv2['default'].transform(function callee$2$0(record, callback) {
                  var err;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        err = null;
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.getModelClass(record['管理番号']));

                      case 4:
                        record['管理番号'] = context$3$0.sent;
                        context$3$0.next = 10;
                        break;

                      case 7:
                        context$3$0.prev = 7;
                        context$3$0.t0 = context$3$0['catch'](1);

                        err = context$3$0.t0;

                      case 10:
                        callback(err, record);

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 7]]);
                })).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(w);

              case 7:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibit', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク出品', function callee$1$0() {
          var filter, itemController, packet, workdir, uploaddir, cd, filename, name, fields, header, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                packet = new _importsUtilPacket2['default'](config.packetSize);
                context$2$0.prev = 5;
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 8:
                context$2$0.next = 12;
                break;

              case 10:
                context$2$0.prev = 10;
                context$2$0.t0 = context$2$0['catch'](5);

              case 12:
                workdir = config.workdir + '/work';
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(workdir));

              case 15:
                context$2$0.next = 17;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 17:
                uploaddir = config.workdir + '/upload';
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(uploaddir));

              case 20:
                context$2$0.next = 22;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(uploaddir));

              case 22:
                cd = null;
                filename = null;
                name = null;
                fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
                header = fields.map(function (v) {
                  return '"' + v + '"';
                }).join(',') + '\n';

                // パケット化開始時
                packet.onPacketStart = function callee$2$0(packetCount) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        name = prefix + ('00000' + packetCount).slice(-5);
                        cd = workdir + '/' + name;
                        filename = cd + '/' + config.csvFileName;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(cd));

                      case 5:
                        context$3$0.next = 7;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(header, 'Shift_JIS')));

                      case 7:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // パケット化時
                packet.onPacket = function callee$2$0(arg) {
                  var yauct, item, record, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, img, imgSrc, imgTgt;

                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        yauct = arg.yauct;
                        item = arg.item;
                        record = fields.map(function (v) {
                          return yauct[v] ? '"' + yauct[v] + '"' : '""';
                        }).join(',') + '\n';
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(record, 'Shift_JIS')));

                      case 5:
                        _iteratorNormalCompletion = true;
                        _didIteratorError = false;
                        _iteratorError = undefined;
                        context$3$0.prev = 8;
                        _iterator = item.images[Symbol.iterator]();

                      case 10:
                        if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                          context$3$0.next = 26;
                          break;
                        }

                        img = _step.value;
                        imgSrc = config.imagedir + '/' + img;
                        imgTgt = cd + '/' + img;
                        context$3$0.prev = 14;
                        context$3$0.next = 17;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].access(imgTgt));

                      case 17:
                        context$3$0.next = 23;
                        break;

                      case 19:
                        context$3$0.prev = 19;
                        context$3$0.t0 = context$3$0['catch'](14);
                        context$3$0.next = 23;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].copyFile(imgSrc, imgTgt));

                      case 23:
                        _iteratorNormalCompletion = true;
                        context$3$0.next = 10;
                        break;

                      case 26:
                        context$3$0.next = 32;
                        break;

                      case 28:
                        context$3$0.prev = 28;
                        context$3$0.t1 = context$3$0['catch'](8);
                        _didIteratorError = true;
                        _iteratorError = context$3$0.t1;

                      case 32:
                        context$3$0.prev = 32;
                        context$3$0.prev = 33;

                        if (!_iteratorNormalCompletion && _iterator['return']) {
                          _iterator['return']();
                        }

                      case 35:
                        context$3$0.prev = 35;

                        if (!_didIteratorError) {
                          context$3$0.next = 38;
                          break;
                        }

                        throw _iteratorError;

                      case 38:
                        return context$3$0.finish(35);

                      case 39:
                        return context$3$0.finish(32);

                      case 40:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[8, 28, 32, 40], [14, 19], [33,, 35, 39]]);
                };

                // パケット終了時
                packet.onPacketEnd = function callee$2$0(packetCount) {
                  var zip, zipname, output;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        zip = (0, _archiver2['default'])('zip');
                        zipname = uploaddir + '/' + name + '.zip';
                        output = _fsExtra2['default'].createWriteStream(zipname);

                        zip.pipe(output);
                        zip.directory(cd, false);
                        zip.finalize();

                      case 6:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // メインループ
                //

                context$2$0.next = 32;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var quantity, yauct;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;

                          if (!(quantity >= item.mall.yauct.minQuantity)) {
                            context$3$0.next = 9;
                            break;
                          }

                          context$3$0.next = 6;
                          return regeneratorRuntime.awrap(itemController.convertItemYauct(config['default'], item));

                        case 6:
                          yauct = context$3$0.sent;
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(packet.submit({ yauct: yauct, item: item }));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  } }));

              case 32:
                res = context$2$0.sent;

                packet.close();

                return context$2$0.abrupt('return', res);

              case 35:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[5, 10]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// ヤフオク受注ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 管理番号を置き換える

//
// ヤフオク出品ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 繰り返し処理を任意の（packetSize）で分割

// 作業フォルダを作成する

// CSVファイルを作成し画像データを収集する場所

// ZIPファイルを保存する場所
// パケットフォルダ
// csvファイル
// パケット番号

// CSVフィールドを定義し、順番を確定する

// CSVファイルにフィールドを設定する

// csvファイルにレコード（商品テンプレート）を追加する

// 画像ファイルをコピー

// 同じファイルがある場合はコピーしない

// itemに定義されている最低必要在庫より多い商品を出品する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
require('../imports/collections');

require('./route/upload/image');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"filters.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/filters.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _groups = require('./groups');

var Filters = new _meteorMongo.Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

var Filter = (function (_GroupBase) {
  _inherits(Filter, _GroupBase);

  function Filter(filterId) {
    var _this = this;

    _classCallCheck(this, Filter);

    var profile = Filters.findOne({
      _id: filterId
    });

    _get(Object.getPrototypeOf(Filter.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {

      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0() {
          var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
          var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table;
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, onError));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this);
        };
        break;

      default:
        throw new Error('invalid platform type');

    }
  }

  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */

  _createClass(Filter, [{
    key: 'foreach',
    value: function foreach() {
      var _this2 = this;

      var callbacks = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this2);
      } : arguments[1];

      var profile, count, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, filter;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this3 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              type: 'misc',
              query: {}
            });

            count = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              filter = _step.value;

              count[filter.type] = {
                query: filter.query,
                count: 0
              };
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record) {
              var _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, filter, query, exam;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion2 = true;
                    _didIteratorError2 = false;
                    _iteratorError2 = undefined;
                    context$3$0.prev = 3;
                    _iterator2 = profile.filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
                      context$3$0.next = 18;
                      break;
                    }

                    filter = _step2.value;
                    query = _mongoobject2['default'].unescape(filter.query);
                    exam = (0, _sift2['default'])(query);

                    if (!exam(record)) {
                      context$3$0.next = 15;
                      break;
                    }

                    count[filter.type].count++;

                    if (!(typeof callbacks[filter.type] !== 'undefined')) {
                      context$3$0.next = 14;
                      break;
                    }

                    context$3$0.next = 14;
                    return regeneratorRuntime.awrap(callbacks[filter.type](record));

                  case 14:
                    return context$3$0.abrupt('break', 18);

                  case 15:
                    _iteratorNormalCompletion2 = true;
                    context$3$0.next = 5;
                    break;

                  case 18:
                    context$3$0.next = 24;
                    break;

                  case 20:
                    context$3$0.prev = 20;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError2 = true;
                    _iteratorError2 = context$3$0.t0;

                  case 24:
                    context$3$0.prev = 24;
                    context$3$0.prev = 25;

                    if (!_iteratorNormalCompletion2 && _iterator2['return']) {
                      _iterator2['return']();
                    }

                  case 27:
                    context$3$0.prev = 27;

                    if (!_didIteratorError2) {
                      context$3$0.next = 30;
                      break;
                    }

                    throw _iteratorError2;

                  case 30:
                    return context$3$0.finish(27);

                  case 31:
                    return context$3$0.finish(24);

                  case 32:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this3, [[3, 20, 24, 32], [25,, 27, 31]]);
            }, onError));

          case 24:
            return context$2$0.abrupt('return', count);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21]]);
    }
  }]);

  return Filter;
})(_groups.GroupBase);

exports.Filter = Filter;

// return result of filtering
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/groups.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

var Groups = new _meteorMongo.Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

var GroupBase = (function () {
  function GroupBase(profile) {
    _classCallCheck(this, GroupBase);

    this.profile = profile;
  }

  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */

  _createClass(GroupBase, [{
    key: 'getPlug',
    value: function getPlug() {
      return this.profile.platformPlug;
    }
  }, {
    key: 'getProfile',
    value: function getProfile() {
      return this.profile;
    }
  }, {
    key: 'foreach',
    value: function foreach() {
      var _this = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
    }
  }]);

  return GroupBase;
})();

exports.GroupBase = GroupBase;

var Group = (function (_GroupBase) {
  _inherits(Group, _GroupBase);

  function Group(groupId) {
    var _this2 = this;

    _classCallCheck(this, Group);

    var profile = Groups.findOne({
      _id: groupId
    });

    _get(Object.getPrototypeOf(Group.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0(doc) {
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table + ' WHERE `' + doc.key + '` = "' + doc.id + '"';
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.query(sql));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this2);
        };
        break;
      default:
        throw new Error('invalid group type');
    }
  }

  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */

  _createClass(Group, [{
    key: 'foreach',
    value: function foreach() {
      var _this3 = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[1];

      var cur = Groups.find({
        groupId: this.profile._id
      }, {
        fields: {
          _id: 0,
          id: 1,
          key: 1
        }
      });

      return new Promise(function (resolve, reject) {

        cur.forEach(function callee$3$0(doc, index) {
          var record;
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                context$4$0.prev = 0;
                context$4$0.next = 3;
                return regeneratorRuntime.awrap(this['import'](doc));

              case 3:
                record = context$4$0.sent;
                context$4$0.next = 6;
                return regeneratorRuntime.awrap(callback(record));

              case 6:
                context$4$0.next = 11;
                break;

              case 8:
                context$4$0.prev = 8;
                context$4$0.t0 = context$4$0['catch'](0);

                onError(context$4$0.t0);

              case 11:
                if (index + 1 === cur.count()) {
                  resolve();
                }

              case 12:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this3, [[0, 8]]);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }]);

  return Group;
})(GroupBase);

exports.Group = Group;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/cube3api.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var Cube3Api = (function () {
  /**
   *
   * @param {MySQL} mysql
   */

  function Cube3Api(mysql) {
    _classCallCheck(this, Cube3Api);

    this.mysql_ = mysql;
  }

  _createClass(Cube3Api, [{
    key: 'updateStock',
    value: function updateStock(productClassId) {
      var quantity = arguments.length <= 1 || arguments[1] === undefined ? 0 : arguments[1];
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_class', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              stock_unlimited: 0,
              update_date: 'NOW()'
            }));

          case 2:
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_stock', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              update_date: 'NOW()'
            }));

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productTagUpdate',
    value: function productTagUpdate(data) {
      var creatorId, res, tagoff, tagon, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, tagSet;

      return regeneratorRuntime.async(function productTagUpdate$(context$2$0) {
        var _this = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = [];

            tagoff = function tagoff(tag) {
              var sql;
              return regeneratorRuntime.async(function tagoff$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      DELETE FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.t0 = res;
                    context$3$0.next = 4;
                    return regeneratorRuntime.awrap(this.mysql_.query(sql));

                  case 4:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 6:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            };

            tagon = function tagon(tag) {
              var sql, countRes;
              return regeneratorRuntime.async(function tagon$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      SELECT COUNT(*) FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.next = 3;
                    return regeneratorRuntime.awrap(this.mysql_.query(sql));

                  case 3:
                    countRes = context$3$0.sent;

                    if (!countRes[0]['COUNT(*)']) {
                      context$3$0.next = 6;
                      break;
                    }

                    return context$3$0.abrupt('return');

                  case 6:
                    context$3$0.t0 = res;
                    context$3$0.next = 9;
                    return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_tag', {}, {
                      product_id: data.product_id,
                      tag: tag,
                      creator_id: creatorId,
                      create_date: 'NOW()'
                    }));

                  case 9:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 11:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            };

            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 7;
            _iterator = data.tags[Symbol.iterator]();

          case 9:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 23;
              break;
            }

            tagSet = _step.value;
            context$2$0.t0 = tagSet.set;
            context$2$0.next = context$2$0.t0 === 'on' ? 14 : context$2$0.t0 === 'off' ? 17 : 20;
            break;

          case 14:
            context$2$0.next = 16;
            return regeneratorRuntime.awrap(tagon(tagSet.tag));

          case 16:
            return context$2$0.abrupt('break', 20);

          case 17:
            context$2$0.next = 19;
            return regeneratorRuntime.awrap(tagoff(tagSet.tag));

          case 19:
            return context$2$0.abrupt('break', 20);

          case 20:
            _iteratorNormalCompletion = true;
            context$2$0.next = 9;
            break;

          case 23:
            context$2$0.next = 29;
            break;

          case 25:
            context$2$0.prev = 25;
            context$2$0.t1 = context$2$0['catch'](7);
            _didIteratorError = true;
            _iteratorError = context$2$0.t1;

          case 29:
            context$2$0.prev = 29;
            context$2$0.prev = 30;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 32:
            context$2$0.prev = 32;

            if (!_didIteratorError) {
              context$2$0.next = 35;
              break;
            }

            throw _iteratorError;

          case 35:
            return context$2$0.finish(32);

          case 36:
            return context$2$0.finish(29);

          case 37:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 38:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[7, 25, 29, 37], [30,, 32, 36]]);
    }
  }, {
    key: 'productImageUpdate',
    value: function productImageUpdate(data) {
      var productId, images, creatorId, res, sql, i;
      return regeneratorRuntime.async(function productImageUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productId = data.product_id;
            images = data.images;
            creatorId = data.creator_id;
            res = [];
            sql = 'DELETE FROM dtb_product_image WHERE product_id = ' + productId;
            context$2$0.t0 = res;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(this.mysql_.query(sql));

          case 8:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t1);
            i = 0;

          case 11:
            if (!(i < images.length)) {
              context$2$0.next = 17;
              break;
            }

            context$2$0.next = 14;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_image', {
              product_id: productId,
              creator_id: creatorId,
              file_name: images[i],
              rank: i + 1
            }, {
              create_date: 'NOW()'
            }));

          case 14:
            i++;
            context$2$0.next = 11;
            break;

          case 17:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productUpdate',
    value: function productUpdate(data) {
      var updateData, keys, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, k, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, res;

      return regeneratorRuntime.async(function productUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            updateData = {};
            keys = [];

            // dtb_product

            keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 6;
            for (_iterator2 = keys[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError2) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError2;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 24:

            // dtb_product_class

            updateData = {};
            keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 29;
            for (_iterator3 = keys[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 37;
            break;

          case 33:
            context$2$0.prev = 33;
            context$2$0.t1 = context$2$0['catch'](29);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t1;

          case 37:
            context$2$0.prev = 37;
            context$2$0.prev = 38;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 40:
            context$2$0.prev = 40;

            if (!_didIteratorError3) {
              context$2$0.next = 43;
              break;
            }

            throw _iteratorError3;

          case 43:
            return context$2$0.finish(40);

          case 44:
            return context$2$0.finish(37);

          case 45:
            context$2$0.next = 47;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_class', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 47:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 49:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [29, 33, 37, 45], [38,, 40, 44]]);
    }
  }, {
    key: 'productCreate',
    value: function productCreate(data) {
      var creatorId, res, updateData, keys, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, k, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6;

      return regeneratorRuntime.async(function productCreate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = {};
            updateData = {};
            keys = [];

            keys = ['name', 'description_detail'];
            // {
            //   name: item.name,
            //   description_detail: item.description,
            // },

            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 8;
            for (_iterator4 = keys[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 16;
            break;

          case 12:
            context$2$0.prev = 12;
            context$2$0.t0 = context$2$0['catch'](8);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t0;

          case 16:
            context$2$0.prev = 16;
            context$2$0.prev = 17;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 19:
            context$2$0.prev = 19;

            if (!_didIteratorError4) {
              context$2$0.next = 22;
              break;
            }

            throw _iteratorError4;

          case 22:
            return context$2$0.finish(19);

          case 23:
            return context$2$0.finish(16);

          case 24:
            context$2$0.next = 26;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product', updateData, {
              creator_id: creatorId,
              status: 1,
              note: 'NULL',
              description_list: 'NULL',
              search_word: 'NULL',
              free_area: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 26:
            res.product_id = context$2$0.sent;

            updateData = {};
            keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee'];
            // {
            //   product_code: item.model,
            //   price01: item.retail_price,
            //   price02: item.sales_price,
            // },

            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 32;
            for (_iterator5 = keys[Symbol.iterator](); !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
              k = _step5.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 40;
            break;

          case 36:
            context$2$0.prev = 36;
            context$2$0.t1 = context$2$0['catch'](32);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t1;

          case 40:
            context$2$0.prev = 40;
            context$2$0.prev = 41;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 43:
            context$2$0.prev = 43;

            if (!_didIteratorError5) {
              context$2$0.next = 46;
              break;
            }

            throw _iteratorError5;

          case 46:
            return context$2$0.finish(43);

          case 47:
            return context$2$0.finish(40);

          case 48:
            context$2$0.next = 50;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_class', updateData, {
              creator_id: creatorId,
              product_id: res.product_id,
              stock: 0,
              stock_unlimited: 0,
              class_category_id1: 'NULL',
              class_category_id2: 'NULL',
              delivery_date_id: 'NULL',
              sale_limit: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 50:
            res.product_class_id = context$2$0.sent;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 54;

            for (_iterator6 = keys[Symbol.iterator](); !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
              k = _step6.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 62;
            break;

          case 58:
            context$2$0.prev = 58;
            context$2$0.t2 = context$2$0['catch'](54);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t2;

          case 62:
            context$2$0.prev = 62;
            context$2$0.prev = 63;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 65:
            context$2$0.prev = 65;

            if (!_didIteratorError6) {
              context$2$0.next = 68;
              break;
            }

            throw _iteratorError6;

          case 68:
            return context$2$0.finish(65);

          case 69:
            return context$2$0.finish(62);

          case 70:
            context$2$0.next = 72;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_stock', {}, {
              product_class_id: res.product_class_id,
              creator_id: creatorId,
              stock: 0,
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 72:
            res.product_stock_id = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 74:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 12, 16, 24], [17,, 19, 23], [32, 36, 40, 48], [41,, 43, 47], [54, 58, 62, 70], [63,, 65, 69]]);
    }
  }]);

  return Cube3Api;
})();

exports.Cube3Api = Cube3Api;

// 削除するタグ

// 表示するタグ

// すでに表示されているタグがあれば何もしない

// 商品に関連するすべての画像情報を削除する

// 改めて画像を登録しなおす

// for test
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/dbfilter.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _mongodb = require('mongodb');

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _xmlJs = require('xml-js');

var DBFilterFactory = function DBFilterFactory(plug, profile) {
  _classCallCheck(this, DBFilterFactory);

  var instance = undefined;
  switch (plug.type) {
    case 'mysql':
      instance = new MysqlDBFilter(plug, profile);
  }

  return instance;
};

exports.DBFilterFactory = DBFilterFactory;

var DBFilter = (function () {
  function DBFilter(plug, profile) {
    _classCallCheck(this, DBFilter);

    this.plug = plug;
    this.profile = profile;
  }

  _createClass(DBFilter, [{
    key: 'getPlug_',
    value: function getPlug_() {
      return this.plug;
    }
  }, {
    key: 'getCred_',
    value: function getCred_() {
      return this.plug.cred;
    }
  }, {
    key: 'getProfile_',
    value: function getProfile_() {
      return this.profile;
    }
  }, {
    key: 'setImportFunction_',
    value: function setImportFunction_() {
      var _this = this;

      var fn = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0() {
        var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
        var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];

      this['import'] = fn;
    }

    /**
     * traces members of the group
     * useage:
     *
     *
     * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
     * @param { async function } onError error handler while iterating
     * @returns { Object } { filterName: { query: any, count: number }, ... }
     */
  }, {
    key: 'foreach',
    value: function foreach() {
      var iterators = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      var profile, counter, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, f, filters, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile_();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              name: 'misc',
              query: {}
            });

            counter = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              f = _step.value;
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            filters = [];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 26;

            for (_iterator2 = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              f = _step2.value;

              counter[f.name] = {
                query: f.query,
                limit: typeof f.limit !== 'undefined' ? f.limit : 0,
                count: 0
              };
              filters.push({
                name: f.name,
                exam: (0, _sift2['default'])(_mongoobject2['default'].unescape(f.query))
              });
            }

            context$2$0.next = 34;
            break;

          case 30:
            context$2$0.prev = 30;
            context$2$0.t1 = context$2$0['catch'](26);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 34:
            context$2$0.prev = 34;
            context$2$0.prev = 35;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 37:
            context$2$0.prev = 37;

            if (!_didIteratorError2) {
              context$2$0.next = 40;
              break;
            }

            throw _iteratorError2;

          case 40:
            return context$2$0.finish(37);

          case 41:
            return context$2$0.finish(34);

          case 42:
            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record, context) {
              var _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, f, c;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion3 = true;
                    _didIteratorError3 = false;
                    _iteratorError3 = undefined;
                    context$3$0.prev = 3;
                    _iterator3 = filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
                      context$3$0.next = 20;
                      break;
                    }

                    f = _step3.value;
                    c = counter[f.name];

                    if (!c.limit) {
                      context$3$0.next = 11;
                      break;
                    }

                    if (!(c.count >= c.limit)) {
                      context$3$0.next = 11;
                      break;
                    }

                    return context$3$0.abrupt('continue', 17);

                  case 11:
                    if (!f.exam(record)) {
                      context$3$0.next = 17;
                      break;
                    }

                    // counter limiter
                    c.count++;

                    // iterator

                    if (!(typeof iterators[f.name] !== 'undefined')) {
                      context$3$0.next = 16;
                      break;
                    }

                    context$3$0.next = 16;
                    return regeneratorRuntime.awrap(iterators[f.name](record, context));

                  case 16:
                    return context$3$0.abrupt('break', 20);

                  case 17:
                    _iteratorNormalCompletion3 = true;
                    context$3$0.next = 5;
                    break;

                  case 20:
                    context$3$0.next = 26;
                    break;

                  case 22:
                    context$3$0.prev = 22;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError3 = true;
                    _iteratorError3 = context$3$0.t0;

                  case 26:
                    context$3$0.prev = 26;
                    context$3$0.prev = 27;

                    if (!_iteratorNormalCompletion3 && _iterator3['return']) {
                      _iterator3['return']();
                    }

                  case 29:
                    context$3$0.prev = 29;

                    if (!_didIteratorError3) {
                      context$3$0.next = 32;
                      break;
                    }

                    throw _iteratorError3;

                  case 32:
                    return context$3$0.finish(29);

                  case 33:
                    return context$3$0.finish(26);

                  case 34:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2, [[3, 22, 26, 34], [27,, 29, 33]]);
            }));

          case 44:
            return context$2$0.abrupt('return', counter);

          case 45:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [26, 30, 34, 42], [35,, 37, 41]]);
    }
  }], [{
    key: 'factory',
    value: function factory(plug, profile) {
      switch (plug.type) {
        case 'mysql':
          return new MysqlDBFilter(plug, profile);
        default:
          throw new Error('invalid plug type');
      }
    }
  }]);

  return DBFilter;
})();

exports.DBFilter = DBFilter;

var MysqlDBFilter = (function (_DBFilter) {
  _inherits(MysqlDBFilter, _DBFilter);

  function MysqlDBFilter(plug, profile) {
    var _this3 = this;

    _classCallCheck(this, MysqlDBFilter);

    _get(Object.getPrototypeOf(MysqlDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    var cred = this.getCred_();

    this.mysql = new _utilMysql2['default'](cred);
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var sql, res;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            sql = 'SELECT * FROM ' + plug.table;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, function (e) {
              throw e;
            }));

          case 3:
            res = context$3$0.sent;
            return context$3$0.abrupt('return', res);

          case 5:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this3);
    });
  }

  // import MongoNative from 'mongodb';
  // const MongoClient = MongoNative.MongoClient;
  // const MongoClient = require('mongodb').MongoClient;

  return MysqlDBFilter;
})(DBFilter);

exports.MysqlDBFilter = MysqlDBFilter;

var MongoDBFilter = (function (_DBFilter2) {
  _inherits(MongoDBFilter, _DBFilter2);

  function MongoDBFilter(plug, profile) {
    var _this4 = this;

    _classCallCheck(this, MongoDBFilter);

    _get(Object.getPrototypeOf(MongoDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    // mongo へ接続
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var client, db, collection, context, cur, doc;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            client = undefined;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri));

          case 3:
            client = context$3$0.sent;
            db = client.db(plug.database);
            collection = db.collection(plug.collection);
            context = {
              client: client,
              collection: collection,
              database: db
            };
            cur = collection.find();

            // カーソルのタイムアウトを解除
            cur.addCursorFlag('noCursorTimeout', true);

            // すべてのドキュメントをループ
            context$3$0.prev = 9;

          case 10:
            context$3$0.next = 12;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 12:
            if (!context$3$0.sent) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 15;
            return regeneratorRuntime.awrap(cur.next());

          case 15:
            doc = context$3$0.sent;
            context$3$0.next = 18;
            return regeneratorRuntime.awrap(onResult(doc, context));

          case 18:
            context$3$0.next = 10;
            break;

          case 20:
            ;

          case 21:
            context$3$0.prev = 21;
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(cur.close());

          case 24:
            return context$3$0.finish(21);

          case 25:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this4, [[9,, 21, 25]]);
    });
  }

  return MongoDBFilter;
})(DBFilter);

exports.MongoDBFilter = MongoDBFilter;

var WowmaApiItemFilter = (function (_DBFilter3) {
  _inherits(WowmaApiItemFilter, _DBFilter3);

  function WowmaApiItemFilter(plug, profile) {
    var _this5 = this;

    _classCallCheck(this, WowmaApiItemFilter);

    _get(Object.getPrototypeOf(WowmaApiItemFilter.prototype), 'constructor', this).call(this, plug, profile);

    // 商品情報の取得ループを定義
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var options, context, res, maxCount, resultCount, startCount, resultStocks, i, next;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            options = JSON.parse(JSON.stringify(plug));

            options.uri = options.uri + '/searchStocks';
            context = {
              options: options
            };

          case 3:
            if (!1) {
              context$3$0.next = 30;
              break;
            }

            context$3$0.next = 6;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

          case 6:
            res = context$3$0.sent;

            res = (0, _xmlJs.xml2js)(res, { compact: true });

            maxCount = Number(res.response.searchResult.maxCount._text);
            resultCount = Number(res.response.searchResult.resultCount._text);
            startCount = Number(res.response.searchResult.startCount._text);
            resultStocks = res.response.searchResult.resultStocks;

            if (!(resultStocks instanceof Array)) {
              context$3$0.next = 22;
              break;
            }

            i = 0;

          case 14:
            if (!(i < resultCount)) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 17;
            return regeneratorRuntime.awrap(onResult(resultStocks[i], context));

          case 17:
            i++;
            context$3$0.next = 14;
            break;

          case 20:
            context$3$0.next = 24;
            break;

          case 22:
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(onResult(resultStocks, context));

          case 24:
            next = startCount + resultCount;

            if (!(next > maxCount)) {
              context$3$0.next = 27;
              break;
            }

            return context$3$0.abrupt('break', 30);

          case 27:
            options.qs.startCount = next;
            context$3$0.next = 3;
            break;

          case 30:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this5);
    });
  }

  // import mongoose from 'mongoose';

  // export class MongoDBFilter extends DBFilter {
  //   constructor(plug, profile) {
  //     super(plug, profile);

  //     // mongo へ接続
  //     let cred = this.getCred_();
  //     let conuri = `mongodb://${cred.host}:${cred.port}/${cred.database}`;
  //     await mongoose.connect(conuri);

  //     // コレクションを作る
  //     let collection = mongoose.connection.collection(plug.collection);

  //     this.setImportFunction_(async (onResult, onError) => {
  //       let cur = collection.find();

  //       return await this.mysql.streamingQuery(sql, onResult, onError);
  //     });
  //   }
  // }
  return WowmaApiItemFilter;
})(DBFilter);

exports.WowmaApiItemFilter = WowmaApiItemFilter;

// counter limiter

// return result of filtering

// コレクションを取得

// カーソルを開放

// コレクションを取得

// Wowma Api から商品情報を取得

// 取得した商品情報をカスタムプロセスに渡す

// 取得したデータが複数商品の場合

// 取得したデータが単数商品の場合
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/items.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMongo = require('../util/mongo');

var _collections = require('../collections');

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var ItemController = (function () {
  function ItemController() {
    _classCallCheck(this, ItemController);
  }

  _createClass(ItemController, [{
    key: 'init',

    /**
     *
     * @param {{uri:string, database:string, collection:string}} plug
     */
    value: function init(plug) {
      return regeneratorRuntime.async(function init$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'items'));

          case 2:
            this.Items = context$2$0.sent;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'products'));

          case 5:
            this.Products = context$2$0.sent;

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'getStock',
    value: function getStock(itemId) {
      var item, productSet, quantities, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, productRef, prdQuantity, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, id, product, stockArray, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, stock, quantity;

      return regeneratorRuntime.async(function getStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.Items.findOne({
              _id: itemId
            }, {
              projection: {
                'product': 1
              }
            }));

          case 2:
            item = context$2$0.sent;
            productSet = item.product;
            quantities = [];
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 8;
            _iterator = productSet[Symbol.iterator]();

          case 10:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 64;
              break;
            }

            productRef = _step.value;
            prdQuantity = 0;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 16;
            _iterator2 = productRef.ids[Symbol.iterator]();

          case 18:
            if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
              context$2$0.next = 46;
              break;
            }

            id = _step2.value;
            context$2$0.next = 22;
            return regeneratorRuntime.awrap(this.Products.findOne({
              _id: id
            }, {
              projection: {
                'stock': 1
              }
            }));

          case 22:
            product = context$2$0.sent;
            stockArray = product.stock;
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 27;

            // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算
            for (_iterator3 = stockArray[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              stock = _step3.value;

              prdQuantity += stock.quantity;
            }
            context$2$0.next = 35;
            break;

          case 31:
            context$2$0.prev = 31;
            context$2$0.t0 = context$2$0['catch'](27);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 35:
            context$2$0.prev = 35;
            context$2$0.prev = 36;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 38:
            context$2$0.prev = 38;

            if (!_didIteratorError3) {
              context$2$0.next = 41;
              break;
            }

            throw _iteratorError3;

          case 41:
            return context$2$0.finish(38);

          case 42:
            return context$2$0.finish(35);

          case 43:
            _iteratorNormalCompletion2 = true;
            context$2$0.next = 18;
            break;

          case 46:
            context$2$0.next = 52;
            break;

          case 48:
            context$2$0.prev = 48;
            context$2$0.t1 = context$2$0['catch'](16);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 52:
            context$2$0.prev = 52;
            context$2$0.prev = 53;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 55:
            context$2$0.prev = 55;

            if (!_didIteratorError2) {
              context$2$0.next = 58;
              break;
            }

            throw _iteratorError2;

          case 58:
            return context$2$0.finish(55);

          case 59:
            return context$2$0.finish(52);

          case 60:

            // 商品(item)の在庫数 = 製品在庫数(prdQuantity) / 必要セット数(productRef.set)
            quantities.push(Math.floor(prdQuantity / productRef.set));

          case 61:
            _iteratorNormalCompletion = true;
            context$2$0.next = 10;
            break;

          case 64:
            context$2$0.next = 70;
            break;

          case 66:
            context$2$0.prev = 66;
            context$2$0.t2 = context$2$0['catch'](8);
            _didIteratorError = true;
            _iteratorError = context$2$0.t2;

          case 70:
            context$2$0.prev = 70;
            context$2$0.prev = 71;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 73:
            context$2$0.prev = 73;

            if (!_didIteratorError) {
              context$2$0.next = 76;
              break;
            }

            throw _iteratorError;

          case 76:
            return context$2$0.finish(73);

          case 77:
            return context$2$0.finish(70);

          case 78:
            quantity = Math.min.apply(null, quantities);
            return context$2$0.abrupt('return', quantity);

          case 80:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 66, 70, 78], [16, 48, 52, 60], [27, 31, 35, 43], [36,, 38, 42], [53,, 55, 59], [71,, 73, 77]]);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに、
     * アップロード済み画像を関連付ける。
     *
     * メーカーモデルに共通の画像を一括で関連付けたい場合、
     * class1、class2引数を指定せずに実行する。
     *
     * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
     * class1に値を指定し、class2引数を指定せずに実行する。
     * もしclass2のみ指定したい場合はclass1にnullを指定する。
     *
     * 例：JK-100のBLACKの商品画像を
     * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
     * setImage( uploadId, 'JK-100', 'BLACK' );
     *
     * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'setImage',
    value: function setImage(uploadId, model) {
      var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
      var images, filter, res;
      return regeneratorRuntime.async(function setImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            images = _collections.Uploads.find({
              uploadId: uploadId
            }).fetch().map(function (v) {
              return v.uploadedFileName;
            });
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $push: {
                images: {
                  $each: images
                }
              }
            }));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', images);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
     *
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'cleanImage',
    value: function cleanImage(model) {
      var class1 = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
      var class2 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var filter, res;
      return regeneratorRuntime.async(function cleanImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $set: {
                images: []
              }
            }));

          case 6:
            res = context$2$0.sent;

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * 指定の商品に関連する商品群の属性別の商品情報を返す。
     *
     * 引数として受け取るitemは任意の商品情報。
     * itemに関連する商品群について必要な情報を整理し返す。
     *
     * projectに参照したい商品情報フィールドを定義する。
     * メソッドの呼び出し時に必要に応じてprojectを設定する。
     *
     * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
     *
     * @param {Object} item
     * @param {Object} project
     */
  }, {
    key: 'getVariation',
    value: function getVariation(item, project) {
      var set, attrs, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, s, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, attr, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6, v;

      return regeneratorRuntime.async(function getVariation$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            set = [{
              label: '配送方法',
              current: item.delivery,
              project: {
                value: '$delivery'
              },
              query: {
                class1_value: item.class1_value,
                class2_value: item.class2_value
              }
            }, {
              label: item.class1_name,
              current: item.class1_value,
              project: {
                value: '$class1_value'
              },
              query: {
                delivery: item.delivery,
                class2_value: item.class2_value
              }
            }, {
              label: item.class2_name,
              current: item.class2_value,
              project: {
                value: '$class2_value'
              },
              query: {
                delivery: item.delivery,
                class1_value: item.class1_value
              }
            }];
            attrs = [];
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 5;
            _iterator4 = set[Symbol.iterator]();

          case 7:
            if (_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done) {
              context$2$0.next = 19;
              break;
            }

            s = _step4.value;
            context$2$0.t0 = attrs;
            context$2$0.next = 12;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: Object.assign(s.query, {
                model: item.model
              })
            }, {
              $project: Object.assign(s.project, project)
            }, {
              $sort: {
                _id: 1
              }
            }]).toArray());

          case 12:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = s;
            context$2$0.t3 = {
              variations: context$2$0.t1,
              props: context$2$0.t2
            };
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t3);

          case 16:
            _iteratorNormalCompletion4 = true;
            context$2$0.next = 7;
            break;

          case 19:
            context$2$0.next = 25;
            break;

          case 21:
            context$2$0.prev = 21;
            context$2$0.t4 = context$2$0['catch'](5);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t4;

          case 25:
            context$2$0.prev = 25;
            context$2$0.prev = 26;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 28:
            context$2$0.prev = 28;

            if (!_didIteratorError4) {
              context$2$0.next = 31;
              break;
            }

            throw _iteratorError4;

          case 31:
            return context$2$0.finish(28);

          case 32:
            return context$2$0.finish(25);

          case 33:
            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 36;
            _iterator5 = attrs[Symbol.iterator]();

          case 38:
            if (_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done) {
              context$2$0.next = 70;
              break;
            }

            attr = _step5.value;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 43;
            _iterator6 = attr.variations[Symbol.iterator]();

          case 45:
            if (_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done) {
              context$2$0.next = 53;
              break;
            }

            v = _step6.value;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.getStock(v._id));

          case 49:
            v.stock = context$2$0.sent;

          case 50:
            _iteratorNormalCompletion6 = true;
            context$2$0.next = 45;
            break;

          case 53:
            context$2$0.next = 59;
            break;

          case 55:
            context$2$0.prev = 55;
            context$2$0.t5 = context$2$0['catch'](43);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t5;

          case 59:
            context$2$0.prev = 59;
            context$2$0.prev = 60;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 62:
            context$2$0.prev = 62;

            if (!_didIteratorError6) {
              context$2$0.next = 65;
              break;
            }

            throw _iteratorError6;

          case 65:
            return context$2$0.finish(62);

          case 66:
            return context$2$0.finish(59);

          case 67:
            _iteratorNormalCompletion5 = true;
            context$2$0.next = 38;
            break;

          case 70:
            context$2$0.next = 76;
            break;

          case 72:
            context$2$0.prev = 72;
            context$2$0.t6 = context$2$0['catch'](36);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t6;

          case 76:
            context$2$0.prev = 76;
            context$2$0.prev = 77;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 79:
            context$2$0.prev = 79;

            if (!_didIteratorError5) {
              context$2$0.next = 82;
              break;
            }

            throw _iteratorError5;

          case 82:
            return context$2$0.finish(79);

          case 83:
            return context$2$0.finish(76);

          case 84:
            return context$2$0.abrupt('return', attrs);

          case 85:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 21, 25, 33], [26,, 28, 32], [36, 72, 76, 84], [43, 55, 59, 67], [60,, 62, 66], [77,, 79, 83]]);
    }

    // モデルクラス形式を作る
    // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
  }, {
    key: 'getModelClass',
    value: function getModelClass(arg) {
      var item, exp, cur, match, modelClass;
      return regeneratorRuntime.async(function getModelClass$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            item = undefined;

            if (!(typeof arg === 'string')) {
              context$2$0.next = 25;
              break;
            }

            exp = new RegExp(arg + '$');
            cur = this.Items.find({}, {
              projection: {
                model: 1,
                class1_value: 1,
                class2_value: 1
              }
            });

          case 4:
            if (!1) {
              context$2$0.next = 22;
              break;
            }

            context$2$0.prev = 5;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(cur.next());

          case 8:
            item = context$2$0.sent;
            context$2$0.next = 11;
            return regeneratorRuntime.awrap(item._id.toHexString().match(exp));

          case 11:
            match = context$2$0.sent;

            if (!match) {
              context$2$0.next = 14;
              break;
            }

            return context$2$0.abrupt('break', 22);

          case 14:
            context$2$0.next = 20;
            break;

          case 16:
            context$2$0.prev = 16;
            context$2$0.t0 = context$2$0['catch'](5);

            // 該当するitemデータがない
            cur.close();
            return context$2$0.abrupt('return', arg);

          case 20:
            context$2$0.next = 4;
            break;

          case 22:
            cur.close();
            context$2$0.next = 26;
            break;

          case 25:
            item = arg;

          case 26:
            modelClass = [];

            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);
            return context$2$0.abrupt('return', modelClass.join('/'));

          case 31:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 16]]);
    }
  }, {
    key: 'convertItemCube3',
    value: function convertItemCube3(creatorId, item) {
      var convDeliv, productId, modelClass, productTypeId, tags, deliveryFee, attrs, variationHtml, descriptionDetail, data;
      return regeneratorRuntime.async(function convertItemCube3$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            convDeliv = function convDeliv(delivery) {
              return delivery === 'ゆうパケット' ? 'ポスト投函' : delivery;
            };

            productId = null;
            modelClass = [];

            // 下記の形式を作る
            // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);

            // 商品種別を割り当てる
            productTypeId = undefined;
            context$2$0.t0 = item.delivery;
            context$2$0.next = context$2$0.t0 === '宅配便' ? 10 : context$2$0.t0 === 'ゆうパケット' ? 12 : 14;
            break;

          case 10:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 12:
            productTypeId = 2;
            return context$2$0.abrupt('break', 16);

          case 14:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 16:
            tags = [];
            context$2$0.t1 = item.delivery;
            context$2$0.next = context$2$0.t1 === '宅配便' ? 20 : context$2$0.t1 === 'ゆうパケット' ? 22 : 24;
            break;

          case 20:
            tags.push({
              tag: 4,
              set: 'on'
            }, {
              tag: 5,
              set: 'off'
            });
            return context$2$0.abrupt('break', 24);

          case 22:
            tags.push({
              tag: 5,
              set: 'on'
            }, {
              tag: 4,
              set: 'off'
            });
            return context$2$0.abrupt('break', 24);

          case 24:
            deliveryFee = null;
            context$2$0.t2 = item.delivery;
            context$2$0.next = context$2$0.t2 === '宅配便' ? 28 : context$2$0.t2 === 'ゆうパケット' ? 30 : 32;
            break;

          case 28:
            deliveryFee = null;
            return context$2$0.abrupt('break', 32);

          case 30:
            deliveryFee = 240;
            return context$2$0.abrupt('break', 32);

          case 32:
            context$2$0.next = 34;
            return regeneratorRuntime.awrap(this.getVariation(item, {
              product_id: '$mall.sharakuShop.product_id'
            }));

          case 34:
            attrs = context$2$0.sent;

            // HTML バリエーション商品ごとのリンク付きボタンを表示する

            // 値の変換
            attrs = attrs.map(function (attr) {
              attr.props.current = convDeliv(attr.props.current);
              attr.variations = attr.variations.map(function (variation) {
                variation.value = convDeliv(variation.value);
                return variation;
              });
              return attr;
            });

            // HTML生成
            variationHtml = attrs.map(function (attr) {
              return '<div class="container-fluid">' + '<div class="row">' + '<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">' + ('<strong>' + attr.props.label + '</strong>') + '</div>' + attr.variations.map(function (variation) {
                if (attr.props.current === variation.value) {
                  // 表示中の商品ボタン
                  return '<button class="btn btn-success btn-sm btn-item-class-select"><strong>' + variation.value + '</strong></button>';
                } else if (variation.stock > 0) {
                  // 販売可能商品のボタン
                  return '<a href="/products/detail/' + variation.product_id + '"><button class="btn btn-default btn-sm btn-item-class-select">' + variation.value + '</button></a>';
                } else {
                  // 販売不可能商品のボタン（在庫なし）
                  return '<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">' + variation.value + '</button>';
                }
              }).join('') + '</div>' + '</div>';
            }).join('');
            descriptionDetail = '\n    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>\n    ' + variationHtml + '\n    ';
            data = {
              product_id: productId,
              creator_id: creatorId,
              name: modelClass.join('/') + ' ' + convDeliv(item.delivery) + ' ' + item.name + (item.jan_code ? ' ' + item.jan_code : ''),
              description_detail: descriptionDetail,
              // free_area: await this.convertItemCube3createFreeArea(item),
              product_code: modelClass.join('/'),
              price01: item.retail_price,
              // price02: await this.convertItemCube3createPrice02(item),
              // images: await this.convertItemCube3createImages(item),
              product_type_id: productTypeId,
              tags: tags,
              delivery_fee: deliveryFee
            };
            context$2$0.t3 = Object;
            context$2$0.t4 = data;
            context$2$0.next = 43;
            return regeneratorRuntime.awrap(this.convertItemCube3createFreeArea(item));

          case 43:
            context$2$0.t5 = context$2$0.sent;
            context$2$0.t3.assign.call(context$2$0.t3, context$2$0.t4, context$2$0.t5);
            context$2$0.t6 = Object;
            context$2$0.t7 = data;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.convertItemCube3createPrice02(item));

          case 49:
            context$2$0.t8 = context$2$0.sent;
            context$2$0.t6.assign.call(context$2$0.t6, context$2$0.t7, context$2$0.t8);
            context$2$0.t9 = Object;
            context$2$0.t10 = data;
            context$2$0.next = 55;
            return regeneratorRuntime.awrap(this.convertItemCube3createImages(item));

          case 55:
            context$2$0.t11 = context$2$0.sent;
            context$2$0.t9.assign.call(context$2$0.t9, context$2$0.t10, context$2$0.t11);

            Object.assign(data, item.mall.sharakuShop);

            return context$2$0.abrupt('return', data);

          case 59:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createFreeArea',
    value: function convertItemCube3createFreeArea(item) {
      var freeArea, i;
      return regeneratorRuntime.async(function convertItemCube3createFreeArea$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            freeArea = '';

            // 商品情報テキストを記載する
            freeArea += item.description;
            // 2番目以降の画像をフリーエリアに記載する
            for (i = 1; i < item.images.length; i++) {
              freeArea += '<img src="/upload/save_image/' + item.images[i] + '"><br>';
            }
            // 情報のクリア
            freeArea += ' ';
            return context$2$0.abrupt('return', { free_area: freeArea });

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createPrice02',
    value: function convertItemCube3createPrice02(item) {
      return regeneratorRuntime.async(function convertItemCube3createPrice02$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            return context$2$0.abrupt('return', { price02: item.mall.sharakuShop.price });

          case 1:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createImages',
    value: function convertItemCube3createImages(item) {
      var arr;
      return regeneratorRuntime.async(function convertItemCube3createImages$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            arr = typeof item.images[0] === 'undefined' ? [] : [item.images[0]];
            return context$2$0.abrupt('return', { images: arr });

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct1',
    value: function convertItemYauct1(config, item) {
      var res;
      return regeneratorRuntime.async(function convertItemYauct1$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.convertItemYauct(config['default'], item));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct',
    value: function convertItemYauct(def, item) {
      var idLength, titleLength, yauct, imgPrefix, i;
      return regeneratorRuntime.async(function convertItemYauct$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            idLength = 20;
            titleLength = 130;
            yauct = {};

            // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）
            yauct = JSON.parse(JSON.stringify(def[item.delivery]));

            // 画像の記述
            imgPrefix = '画像';

            for (i = 0; i < item.images.length; i++) {
              yauct[imgPrefix + (i + 1)] = item.images[i];
            }

            // タイトル
            yauct['カテゴリ'] = item.mall.yauct.category;
            context$2$0.t0 = _utilText2['default'];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap(this.getModelClass(item));

          case 10:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = context$2$0.t1 + ' ';
            context$2$0.t3 = item.delivery;
            context$2$0.t4 = context$2$0.t2 + context$2$0.t3;
            context$2$0.t5 = context$2$0.t4 + ' ';
            context$2$0.t6 = item.name;
            context$2$0.t7 = context$2$0.t5 + context$2$0.t6;
            context$2$0.t8 = titleLength;
            yauct['タイトル'] = context$2$0.t0.substr8.call(context$2$0.t0, context$2$0.t7, context$2$0.t8);

            yauct['開始価格'] = item.sales_price;
            yauct['即決価格'] = item.sales_price;
            yauct['管理番号'] = item._id.toHexString().slice(-idLength);
            if (typeof yauct['説明'] === 'string') {
              yauct['説明'] = item.description + '<br><br>' + yauct['説明'];
            } else {
              yauct['説明'] = item.description;
            }
            yauct['JANコード・ISBNコード'] = item.jan_code;

            return context$2$0.abrupt('return', yauct);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemWowmaCreateDeliveryMethod',
    value: function convertItemWowmaCreateDeliveryMethod(itemCode) {
      var id, set, metrics, aggr, acceptDeliv, _iteratorNormalCompletion7, _didIteratorError7, _iteratorError7, _iterator7, _step7, del, deliveryMethod, i, _id;

      return regeneratorRuntime.async(function convertItemWowmaCreateDeliveryMethod$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            id = 'mall.wowma.itemCode';
            set = 'delivery';
            metrics = {
              'ゆうパケット': ['Post'],
              '宅配便': ['YU-Pack', 'Kangaroo']
            };
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: _defineProperty({}, id, itemCode)
            }, {
              $group: _defineProperty({
                _id: '$' + id
              }, set, { $addToSet: '$' + set })
            }, {
              $project: _defineProperty({
                _id: 0,
                itemCode: '$_id'
              }, set, '$' + set)
            }]).toArray());

          case 5:
            aggr = context$2$0.sent;
            acceptDeliv = [];
            _iteratorNormalCompletion7 = true;
            _didIteratorError7 = false;
            _iteratorError7 = undefined;
            context$2$0.prev = 10;

            for (_iterator7 = aggr[0].delivery[Symbol.iterator](); !(_iteratorNormalCompletion7 = (_step7 = _iterator7.next()).done); _iteratorNormalCompletion7 = true) {
              del = _step7.value;

              acceptDeliv = acceptDeliv.concat(metrics['' + del]);
            }
            context$2$0.next = 18;
            break;

          case 14:
            context$2$0.prev = 14;
            context$2$0.t0 = context$2$0['catch'](10);
            _didIteratorError7 = true;
            _iteratorError7 = context$2$0.t0;

          case 18:
            context$2$0.prev = 18;
            context$2$0.prev = 19;

            if (!_iteratorNormalCompletion7 && _iterator7['return']) {
              _iterator7['return']();
            }

          case 21:
            context$2$0.prev = 21;

            if (!_didIteratorError7) {
              context$2$0.next = 24;
              break;
            }

            throw _iteratorError7;

          case 24:
            return context$2$0.finish(21);

          case 25:
            return context$2$0.finish(18);

          case 26:
            deliveryMethod = new Array(5);

            for (i = 0; i < deliveryMethod.length; i++) {
              _id = typeof acceptDeliv[i] === 'undefined' ? 'NULL' : acceptDeliv[i];

              deliveryMethod[i] = { deliveryMethodSeq: i + 1, deliveryMethodId: _id };
            }

            return context$2$0.abrupt('return', { deliveryMethod: deliveryMethod });

          case 29:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[10, 14, 18, 26], [19,, 21, 25]]);
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その1 item.csv

  }], [{
    key: 'convertItemRobotinItem',
    value: function convertItemRobotinItem(item) {
      return {
        'コントロールカラム': 'n',
        '新規登録ID': item._id.toHexString(),
        '商品ID': null,
        '商品名': '' + item.model + (item.class1_value === '' ? '' : '/' + item.class1_value) + (item.class2_value === '' ? '' : '/' + item.class2_value),
        '規格': 'なし'
      };
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その2 select.csv

  }, {
    key: 'convertItemRobotinSelect',
    value: function convertItemRobotinSelect(item) {
      var select = {
        'コントロールカラム': 'n',
        '新規登録ID': item._id.toHexString(),
        '商品ID': null,
        '外部連携ID': null,
        '外部連携商品番号': item._id.toHexString()
      };

      var shops = _collections.RobotinShop.find();

      shops.forEach(function (doc, index) {
        var model = undefined,
            class1 = undefined,
            class2 = undefined;
        try {
          // モールの商品番号を特定する
          model = item.mall['' + doc.name]['' + doc.modelPath];
          model = typeof model === 'undefined' ? '' : model;
          class1 = item.mall['' + doc.name]['' + doc.class1Path];
          class1 = typeof class1 === 'undefined' ? '' : class1;
          class2 = item.mall['' + doc.name]['' + doc.class2Path];
          class2 = typeof class2 === 'undefined' ? '' : class2;
        } catch (e) {
          // 商品のモール情報の取得に失敗した（データが設定されていないなど）
          // model = item.model
          // class1 = item.class1_value
          // class2 = item.class2_value
          return;
        }

        select['受注商品ID_' + index] = null;
        select['店舗ID_' + index] = doc['店舗ID'];
        select['店舗名_' + index] = doc.name;
        select['受注商品番号_' + index] = '' + model + class1 + class2;
        select['有効フラグ_' + index] = '有効';
      });

      return select;
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その3 selectShop.csv

  }, {
    key: 'convertItemRobotinSelectShop',
    value: function convertItemRobotinSelectShop(shop, item) {
      var model = item.mall['' + shop.name]['' + shop.modelPath];
      var class1 = item.mall['' + shop.name]['' + shop.class1Path];
      var class2 = item.mall['' + shop.name]['' + shop.class2Path];

      return {
        'コントロールカラム': 'u',
        '新規登録ID': item._id.toHexString(),
        '受注商品ID': null,
        '店舗ID': shop['店舗ID'],
        '店舗名': null,
        '受注商品番号': '' + model + class1 + class2,
        '有効フラグ': '有効'
      };
    }
  }]);

  return ItemController;
})();

exports['default'] = ItemController;
module.exports = exports['default'];

// product * <-> * item
// product[]: 複数の商品を1パッケージとして販売
// product[{ids:[<ObjectId>],set:<Number>}]: 異なる流通経路、異なる原価・仕入れ値
// item: 異なるセール、販売形態
// ※ product からは、販売可能な在庫、利益計算のための情報を得る

// セット商品の場合、一番少ない商品数に合わせる

// アップロード済み画像の情報取得

// 検索条件の組み立て

// 登録した画像ファイル名一覧

// 検索条件の組み立て

/**
 * aggregation設定
 *
 * label: 属性名（配送方法、カラー、サイズなど）
 * current: 指定されたアイテム（item）が該当する項目
 * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
 * query: aggregation対象とするドキュメントの検索条件
 */

// item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

// 値変換

// product_id

// 商品タグを設定する

// 商品別送料を設定する

//
// 顧客向けバリエーション商品選択機能の実装
//

// 商品データを作る

// 価格を返す

// 画像リストのうち1つめだけを返す

// deliveryMethodSeq
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/robotin.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var _items = require('./items');

var _bson = require('bson');

var Robotin = (function () {
  function Robotin() {
    _classCallCheck(this, Robotin);

    this.Order = new _meteorMongo.Mongo.Collection(null);
  }

  /**
   *
   * @param {*} docOrder
   * @param {ItemController} itemS
   */

  _createClass(Robotin, [{
    key: 'importOrder',
    value: function importOrder(docOrder, itemS) {
      var item;
      return regeneratorRuntime.async(function importOrder$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            if (!_bson.ObjectID.isValid(docOrder['商品コード'])) {
              context$2$0.next = 8;
              break;
            }

            context$2$0.next = 3;
            return regeneratorRuntime.awrap(itemS.Items.findOne({ _id: new _bson.ObjectID(docOrder['商品コード']) }));

          case 3:
            item = context$2$0.sent;

            if (!item) {
              context$2$0.next = 8;
              break;
            }

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(itemS.getModelClass(item));

          case 7:
            docOrder['商品コード'] = context$2$0.sent;

          case 8:
            // 受注データをデータベースに保存
            this.Order.insert(docOrder);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * @param {*} docLabel
     * @param {Array} writeItemCodeTo
     */
  }, {
    key: 'transformLabelSeino',
    value: function transformLabelSeino(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      //

      // 受注番号を抽出
      var orderNumber = docLabel[32]; // 33番目の項目「記事１」

      // 受注CSVから店舗名と受注番号をキーに商品コード一覧を取得する
      var cur = this.Order.find({
        '店舗名': docLabel[11], // 12番目の項目「荷送人名称」
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        '受注番号': { $in: [orderNumber, Number(orderNumber)] }
      }, { fields: {
          _id: 0,
          '商品コード': 1
        } });

      // 送り状レコードに該当する受注レコードが見つからない場合
      if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');

      // 送り状の発送商品コード一覧を配列にする
      var items = cur.fetch();

      // docLabel : 入力送り状データ
      // conLabel : 出力用送り状データ
      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // writeItemCodeTo （一つの送り状に記載できる商品コードの最大数）の総数より、受注データの商品数が多い場合はエラー
      var writeItemCodeTo = labelOptions.writeItemCodeTo;
      if (writeItemCodeTo.length < items.length) {
        throw new Error('送り状データに記載できる商品数は' + writeItemCodeTo.length + '個までです');
      }

      // 定数の埋め込み
      labelOptions['const'].forEach(function (e) {
        conLabel[e.column] = e.value;
      });

      // 送り状データに商品コードを記録する
      items.forEach(function (e, i) {
        conLabel[writeItemCodeTo[i]] = e['商品コード'];
      });

      // 住所文字列の分割を修正する
      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      _utilText2['default'].splitlenb(conLabel, [12, 13], 40); // 項目13「荷送人住所１」、項目14「荷送人住所２」
      _utilText2['default'].splitlenb(conLabel, [21, 22], 60); // 項目22「お届け先住所１」、項目23「お届け先住所２」
      return conLabel;
    }

    /**
     *
     * @param {*} docLabel
     * @param {Array} writeItemCodeTo
     */
  }, {
    key: 'transformLabelYupack',
    value: function transformLabelYupack(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      //

      // 受注番号を抽出
      var orderNumber = docLabel['記事名１'].replace('受注番号：', '');

      // 受注CSVから店舗名と受注番号をキーに商品コード一覧を取得する
      var cur = this.Order.find({
        '店舗名': docLabel['ご依頼主 名称1'],
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        '受注番号': { $in: [orderNumber, Number(orderNumber)] }
      }, { fields: {
          _id: 0,
          '商品コード': 1
        } });

      // 送り状レコードに該当する受注レコードが見つからない場合
      if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');

      // 送り状の発送商品コード一覧を配列にする
      var items = cur.fetch();

      // docLabel : 入力送り状データ
      // conLabel : 出力用送り状データ
      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // writeItemCodeTo （一つの送り状に記載できる商品コードの最大数）の総数より、受注データの商品数が多い場合はエラー
      var writeItemCodeTo = labelOptions.writeItemCodeTo;
      if (writeItemCodeTo.length < items.length) {
        throw new Error('送り状データに記載できる商品数は' + writeItemCodeTo.length + '個までです');
      }

      // 送り状データに商品コードを記録する
      items.forEach(function (e, i) {
        conLabel[writeItemCodeTo[i]] = e['商品コード'];
      });

      // 送り状種別を設定
      conLabel['送り状種別'] = labelOptions.labelId;

      // 住所文字列の分割を修正する
      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      _utilText2['default'].splitlenb(conLabel, ['ご依頼主 住所1', 'ご依頼主 住所2', 'ご依頼主 住所3'], 50);
      _utilText2['default'].splitlenb(conLabel, ['お届け先 住所1', 'お届け先 住所2', 'お届け先 住所3'], 50);
      return conLabel;
    }
  }, {
    key: 'transformLabelYupacket',
    value: function transformLabelYupacket(docLabel, writeItemCodeTo) {
      // 商品コードを送り状CSVに埋め込む
      var orderNumber = docLabel['記事名１'].replace('受注番号：', '');
      var cur = this.Order.find({
        '店舗名': docLabel['ご依頼主 名称1'],
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        '受注番号': { $in: [orderNumber, Number(orderNumber)] }
      }, { fields: {
          _id: 0,
          '商品コード': 1
        } });

      if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');

      var items = cur.fetch();

      var conLabel = JSON.parse(JSON.stringify(docLabel));
      conLabel['記事名１'] = items.map(function (e) {
        return e['商品コード'];
      }).join('　');

      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      _utilText2['default'].splitlenb(conLabel, ['ご依頼主 住所1', 'ご依頼主 住所2', 'ご依頼主 住所3'], 50);
      _utilText2['default'].splitlenb(conLabel, ['お届け先 住所1', 'お届け先 住所2', 'お届け先 住所3'], 50);
      return conLabel;
    }
  }]);

  return Robotin;
})();

exports['default'] = Robotin;
module.exports = exports['default'];

// 商品番号をmongoIdとして検索し、該当するitemがあれば書き換える
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/wowmaApi.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _xmlJs = require('xml-js');

var _utilError = require('../util/error');

var _utilError2 = _interopRequireDefault(_utilError);

var BASE_URI = 'https://api.manager.wowma.jp/wmshopapi';

var WowmaApi = (function () {
  function WowmaApi(plug, shopId) {
    _classCallCheck(this, WowmaApi);

    this.plug = plug;
    this.shopId = shopId;
  }

  // 商品情報更新

  _createClass(WowmaApi, [{
    key: 'updateItem',
    value: function updateItem(_updateItem) {
      var request, res;
      return regeneratorRuntime.async(function updateItem$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            request = '<request><shopId>' + this.shopId + '</shopId><updateItem>' + (0, _xmlJs.json2xml)(_updateItem, { compact: true }) + '</updateItem></request>';
            context$2$0.prev = 1;
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.requestPost('updateItemInfo', request));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', { response: res, requestXML: request });

          case 8:
            context$2$0.prev = 8;
            context$2$0.t0 = context$2$0['catch'](1);
            throw Object.assign(_utilError2['default'].parse(context$2$0.t0), { requestXML: request });

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[1, 8]]);
    }
  }, {
    key: 'requestPost',
    value: function requestPost(method, body) {
      var apiRequest, res;
      return regeneratorRuntime.async(function requestPost$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/' + method,
              body: body
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            // リクエスト発行
            context$2$0.next = 4;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(stockUpdateItem) {
      var apiRequest, res;
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/updateStock'
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.updateStockCreateRequestBody(stockUpdateItem));

          case 4:
            apiRequest.body = context$2$0.sent;
            context$2$0.next = 7;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStockCreateRequestBody',
    value: function updateStockCreateRequestBody(stockUpdateItem) {
      var stockUpdateItemXML, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, item, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, e, var0, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, variation, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, key, apiRequestBody;

      return regeneratorRuntime.async(function updateStockCreateRequestBody$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            stockUpdateItemXML = '';
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 4;
            _iterator = stockUpdateItem[Symbol.iterator]();

          case 6:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 87;
              break;
            }

            item = _step.value;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 11;

            // 値のチェック
            for (_iterator2 = item.variations[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              e = _step2.value;

              // 在庫数の上限100
              if (e.stock > 100) e.stock = 100;
            }

            context$2$0.next = 19;
            break;

          case 15:
            context$2$0.prev = 15;
            context$2$0.t0 = context$2$0['catch'](11);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 19:
            context$2$0.prev = 19;
            context$2$0.prev = 20;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 22:
            context$2$0.prev = 22;

            if (!_didIteratorError2) {
              context$2$0.next = 25;
              break;
            }

            throw _iteratorError2;

          case 25:
            return context$2$0.finish(22);

          case 26:
            return context$2$0.finish(19);

          case 27:
            stockUpdateItemXML += '<stockUpdateItem>';
            stockUpdateItemXML += '<itemCode>' + item.itemCode + '</itemCode>';

            // 商品在庫種別を振り分け
            // 1 -> 通常商品
            // 2 -> 選択肢別在庫

            var0 = item.variations[0];

            if (!(var0.choicesStockHorizontalCode === '' && var0.choicesStockVerticalCode === '')) {
              context$2$0.next = 35;
              break;
            }

            // 通常商品
            stockUpdateItemXML += '<stockSegment>1</stockSegment>';
            stockUpdateItemXML += '<stockCount>' + var0.stock + '</stockCount>';
            context$2$0.next = 83;
            break;

          case 35:
            // 選択肢別在庫
            stockUpdateItemXML += '<stockSegment>2</stockSegment>';

            // リクエストボディを作成する
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 39;
            _iterator3 = item.variations[Symbol.iterator]();

          case 41:
            if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
              context$2$0.next = 69;
              break;
            }

            variation = _step3.value;

            // 在庫設定タグの名前を差し替える
            variation.choicesStockCount = variation.stock;
            delete variation.stock;

            // xmlを構成する
            stockUpdateItemXML += '<choicesStocks>';
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 49;
            for (_iterator4 = Object.keys(variation)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              key = _step4.value;

              stockUpdateItemXML += '<' + key + '>' + variation[key] + '</' + key + '>';
            }
            context$2$0.next = 57;
            break;

          case 53:
            context$2$0.prev = 53;
            context$2$0.t1 = context$2$0['catch'](49);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 57:
            context$2$0.prev = 57;
            context$2$0.prev = 58;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 60:
            context$2$0.prev = 60;

            if (!_didIteratorError4) {
              context$2$0.next = 63;
              break;
            }

            throw _iteratorError4;

          case 63:
            return context$2$0.finish(60);

          case 64:
            return context$2$0.finish(57);

          case 65:
            stockUpdateItemXML += '</choicesStocks>';

          case 66:
            _iteratorNormalCompletion3 = true;
            context$2$0.next = 41;
            break;

          case 69:
            context$2$0.next = 75;
            break;

          case 71:
            context$2$0.prev = 71;
            context$2$0.t2 = context$2$0['catch'](39);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t2;

          case 75:
            context$2$0.prev = 75;
            context$2$0.prev = 76;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 78:
            context$2$0.prev = 78;

            if (!_didIteratorError3) {
              context$2$0.next = 81;
              break;
            }

            throw _iteratorError3;

          case 81:
            return context$2$0.finish(78);

          case 82:
            return context$2$0.finish(75);

          case 83:

            stockUpdateItemXML += '</stockUpdateItem>';

          case 84:
            _iteratorNormalCompletion = true;
            context$2$0.next = 6;
            break;

          case 87:
            context$2$0.next = 93;
            break;

          case 89:
            context$2$0.prev = 89;
            context$2$0.t3 = context$2$0['catch'](4);
            _didIteratorError = true;
            _iteratorError = context$2$0.t3;

          case 93:
            context$2$0.prev = 93;
            context$2$0.prev = 94;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 96:
            context$2$0.prev = 96;

            if (!_didIteratorError) {
              context$2$0.next = 99;
              break;
            }

            throw _iteratorError;

          case 99:
            return context$2$0.finish(96);

          case 100:
            return context$2$0.finish(93);

          case 101:
            apiRequestBody = '\n    <request>\n    <shopId>' + this.shopId + '</shopId>\n    ' + stockUpdateItemXML + '\n    </request>\n    ';
            return context$2$0.abrupt('return', apiRequestBody);

          case 103:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[4, 89, 93, 101], [11, 15, 19, 27], [20,, 22, 26], [39, 71, 75, 83], [49, 53, 57, 65], [58,, 60, 64], [76,, 78, 82], [94,, 96, 100]]);
    }
  }]);

  return WowmaApi;
})();

exports['default'] = WowmaApi;
module.exports = exports['default'];

// 接続オプションの作成

// 接続オプションの作成

// リクエスト発行

//
// stockUpdateItem =
// [
//   {
//     itemCode: <String>,
//     variations: [
//        {
//          choicesStockHorizontalCode: <String>,
//          choicesStockVerticalCode: <String>,
//          stock: <Number>
//        }
//     ]
//   }
// ]

// リクエストボディの作成

// リクエストボディを返す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/error.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var utilError = (function () {
  function utilError() {
    _classCallCheck(this, utilError);
  }

  _createClass(utilError, null, [{
    key: "parse",
    value: function parse(e) {
      var res = {};

      if (e instanceof Error) {
        res.message = e.message;
        res.name = e.name;
        res.fileName = e.fileName;
        res.lineNumber = e.lineNumber;
        res.columnNumber = e.columnNumber;
        res.stack = e.stack;
      } else {
        res = e;
      }

      return res;
    }
  }]);

  return utilError;
})();

exports["default"] = utilError;
module.exports = exports["default"];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mongo.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var MongoCollection = (function () {
  function MongoCollection() {
    _classCallCheck(this, MongoCollection);
  }

  _createClass(MongoCollection, null, [{
    key: 'get',
    value: function get(plug, collection) {
      var client, db;
      return regeneratorRuntime.async(function get$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri));

          case 2:
            client = context$2$0.sent;
            db = client.db(plug.database);
            return context$2$0.abrupt('return', db.collection(collection));

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }]);

  return MongoCollection;
})();

exports.MongoCollection = MongoCollection;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mysql.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mysql = require('mysql');

var _mysql2 = _interopRequireDefault(_mysql);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var MySQL = (function () {
  function MySQL(profile) {
    _classCallCheck(this, MySQL);

    // コネクションプール初期化
    this.pool = _mysql2['default'].createPool(profile);

    // 複数行ステートメント対応
    var profileMulti = { multipleStatements: true };
    Object.assign(profileMulti, profile);
    this.poolMulti = _mysql2['default'].createPool(profileMulti);
  }

  _createClass(MySQL, [{
    key: 'query',

    /**
     *
     * @param {String} sql
     */
    value: function query(sql) {
      // コネクション確立
      // let con = await this.getCon();
      return this.getCon().then(function (con) {
        return new Promise(function (resolve, reject) {
          // クエリ送信
          con.query(sql, function (e, res) {
            // コネクション開放
            con.release();
            if (e) {
              reject(e);
            } else resolve(res);
          });
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'queryInsert_',
    value: function queryInsert_(sql) {
      var res;
      return regeneratorRuntime.async(function queryInsert_$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query(sql));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * @param {String} table
     * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryInsert',
    value: function queryInsert(table) {
      var data = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
      var dataSql = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

      var sql, map, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, k, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, res;

      return regeneratorRuntime.async(function queryInsert$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'INSERT INTO ' + table + ' ';
            map = new Map();
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 5;

            for (_iterator = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              k = _step.value;

              if (data[k] === null) {
                map.set(k, 'NULL');
              } else if (data[k].constructor.name === 'Date') {
                // 日付を変換
                map.set(k, '"' + MySQL.formatDate(data[k]) + '"');
              } else {
                map.set(k, '' + _mysql2['default'].escape(data[k]));
              }
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 24;
            for (_iterator2 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
            }

            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError2) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError2;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += '( ' + [].concat(_toConsumableArray(map.keys())).join(',') + ' ) ';

            sql += 'VALUES( ' + [].concat(_toConsumableArray(map.values())).join(',') + ' ) ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    /**
     *
     * @param {String} table
     * @param {String} filter SQL UPDATEステートメントのWHERE句
     * @param {Object} data 文字列のパラメーター
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryUpdate',
    value: function queryUpdate(table, filter, data, dataSql) {
      var sql, updates, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, k, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, res;

      return regeneratorRuntime.async(function queryUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'UPDATE ' + table + ' SET ';
            updates = [];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 5;

            for (_iterator3 = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              updates.push(k + '=' + _mysql2['default'].escape(data[k]));
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError3) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError3;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 24;
            for (_iterator4 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              updates.push(k + '=' + dataSql[k]);
            }
            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError4) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError4;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += updates.join(',');

            sql += ' WHERE ' + filter + ' ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    // enable to use multiple statements
  }, {
    key: 'queryMulti',
    value: function queryMulti(sql) {
      var poolSwap, res;
      return regeneratorRuntime.async(function queryMulti$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            poolSwap = this.pool;

            this.pool = this.poolMulti;
            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query(sql));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 7:
            context$2$0.prev = 7;

            this.pool = poolSwap;
            return context$2$0.finish(7);

          case 10:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2,, 7, 10]]);
    }
  }, {
    key: 'startTransaction',
    value: function startTransaction() {
      return regeneratorRuntime.async(function startTransaction$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('START TRANSACTION;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'commit',
    value: function commit() {
      return regeneratorRuntime.async(function commit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('COMMIT;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'rollback',
    value: function rollback() {
      return regeneratorRuntime.async(function rollback$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('ROLLBACK;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'streamingQuery',
    value: function streamingQuery(sql) {
      var _this = this;

      var onResult = arguments.length <= 1 || arguments[1] === undefined ? function (record) {} : arguments[1];
      var onError = arguments.length <= 2 || arguments[2] === undefined ? function (e) {} : arguments[2];

      return this.getCon().then(function (con) {
        return new Promise(function callee$3$0(resolve, reject) {
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                // クエリ送信
                con.query(sql).on('result', function (record) {
                  con.pause();
                  onResult(record);
                  con.resume();
                }).on('error', function (e) {
                  onError(e);
                }).on('end', function () {
                  con.release();
                  resolve();
                });

              case 1:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'getCon',
    value: function getCon() {
      var _this2 = this;

      return new Promise(function (resolve, reject) {
        // プールからのコネクション獲得
        _this2.pool.getConnection(function (e, con) {
          if (e) {
            reject(e);
          } else {
            resolve(con);
          }
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }], [{
    key: 'formatDate',
    value: function formatDate(date) {
      return (0, _moment2['default'])(date).format().substring(0, 19).replace('T', ' ');
    }
  }]);

  return MySQL;
})();

exports['default'] = MySQL;
module.exports = exports['default'];

// let res = await this.query(sql);
// return res.insertId;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/packet.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Packet = (function () {
  function Packet(packetSize) {
    _classCallCheck(this, Packet);

    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  _createClass(Packet, [{
    key: "submit",
    value: function submit(arg) {
      return regeneratorRuntime.async(function submit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            if (!(this.count % this.packetSize === 0)) {
              context$2$0.next = 4;
              break;
            }

            if (!this.onPacketStart) {
              context$2$0.next = 4;
              break;
            }

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.onPacketStart(this.packetCount));

          case 4:
            if (!this.onPacket) {
              context$2$0.next = 7;
              break;
            }

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.onPacket(arg));

          case 7:
            this.count++;
            // packetSizeの回数ごとに、終了処理を呼び出す
            if (this.count % this.packetSize === 0) {
              this.close();
              this.packetCount++;
            }

          case 9:
          case "end":
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: "close",
    value: function close() {
      if (this.onPacketEnd) {
        this.onPacketEnd(this.packetCount);
      }
    }
  }]);

  return Packet;
})();

exports["default"] = Packet;
module.exports = exports["default"];

// packetSizeの回数ごとに、初期化を呼び出す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/report.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _error = require('./error');

var _error2 = _interopRequireDefault(_error);

var _meteorMeteor = require('meteor/meteor');

var _collections = require('../collections');

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

var Report = (function () {
  function Report() {
    _classCallCheck(this, Report);

    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  // private

  _createClass(Report, [{
    key: 'setupIterator',
    value: function setupIterator(phaseId) {
      this.iterator = new Iterator(phaseId);
      this.iterators.push(this.iterator);
    }
  }, {
    key: 'phase',
    value: function phase() {
      var _this = this;

      var name = arguments.length <= 0 || arguments[0] === undefined ? '' : arguments[0];
      var fn = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0() {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
      var rec, res;
      return regeneratorRuntime.async(function phase$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            rec = {
              phaseId: (0, _uniqid2['default'])()
            };

            this.setupIterator(rec.phaseId);

            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(fn());

          case 5:
            res = context$2$0.sent;

            Object.assign(rec, {
              type: 'success',
              phase: name,
              result: res
            });
            context$2$0.next = 12;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](2);

            Object.assign(rec, {
              type: 'error',
              phase: name,
              result: _error2['default'].parse(context$2$0.t0)
            });

          case 12:
            context$2$0.prev = 12;

            // ループ処理のレポートを作成
            if (this.iterator.metric.total) {
              Object.assign(rec, {
                iterator: this.iterator.metric
              });
            }
            // タイムスタンプ
            rec.timeStamp = new Date();
            // レポートをデータベースに記録
            _collections.Logs.insert(rec);

            // 呼び出し元用レポートに追加
            this.record.push(rec);
            return context$2$0.finish(12);

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2, 9, 12, 18]]);
    }

    // カーソルをループし、与えられた関数を実行
    // 呼び出す関数の引数にはカーソルから得られたドキュメントを渡す
  }, {
    key: 'forEachOnCursor',
    value: function forEachOnCursor(cur, fn) {
      var doc, res;
      return regeneratorRuntime.async(function forEachOnCursor$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 2:
            if (!context$2$0.sent) {
              context$2$0.next = 18;
              break;
            }

            context$2$0.next = 5;
            return regeneratorRuntime.awrap(cur.next());

          case 5:
            doc = context$2$0.sent;
            context$2$0.prev = 6;
            context$2$0.next = 9;
            return regeneratorRuntime.awrap(fn(doc));

          case 9:
            res = context$2$0.sent;

            this.iSuccess(res);
            context$2$0.next = 16;
            break;

          case 13:
            context$2$0.prev = 13;
            context$2$0.t0 = context$2$0['catch'](6);

            this.iError(context$2$0.t0);

          case 16:
            context$2$0.next = 0;
            break;

          case 18:
            cur.close();

          case 19:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 13]]);
    }
  }, {
    key: 'iSuccess',
    value: function iSuccess(newRecord) {
      this.iterator.success(newRecord);
    }
  }, {
    key: 'iError',
    value: function iError(newRecord) {
      this.iterator.error(_error2['default'].parse(newRecord));
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      var iteError = this.iterators.find(function (e) {
        return e.errorOcurred();
      });
      var phaError = false;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.record[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var rec = _step.value;

          if (rec.type === 'error') {
            phaError = true;
            break;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return iteError || phaError;
    }
  }, {
    key: 'publish',
    value: function publish() {
      // 呼び出し元へレポート
      if (this.errorOcurred()) {
        throw new _meteorMeteor.Meteor.Error(this.record);
      }
      return this.record;
    }
  }]);

  return Report;
})();

exports['default'] = Report;

var Iterator = (function () {
  function Iterator(phaseId) {
    _classCallCheck(this, Iterator);

    this.metric = {
      total: 0,
      success: 0,
      error: 0,
      phaseId: phaseId
    };
    this.lastError = null;
  }

  _createClass(Iterator, [{
    key: 'success',
    value: function success(newRecord) {
      if (newRecord) {
        this.log(newRecord, true);
      }
      this.metric.success++;
      this.metric.total++;
    }
  }, {
    key: 'error',
    value: function error(newRecord) {
      // 直前と同じエラーは省く
      if (JSON.stringify(this.lastError) !== JSON.stringify(newRecord)) {
        if (newRecord && newRecord !== {} && newRecord !== '') {
          this.log(newRecord, false);
          this.lastError = newRecord;
        }
      }
      this.metric.error++;
      this.metric.total++;
    }
  }, {
    key: 'log',
    value: function log(newRecord, isSuccess /* true => success or false => error */) {
      var rec = {
        success: isSuccess,
        phaseId: this.metric.phaseId,
        message: newRecord,
        timeStamp: new Date()
      };
      _collections.Logs.insert(rec);
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      return this.metric.error;
    }
  }]);

  return Iterator;
})();

module.exports = exports['default'];

// リクエスト発行
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/text.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var TextUtil = (function () {
  function TextUtil() {
    _classCallCheck(this, TextUtil);
  }

  _createClass(TextUtil, null, [{
    key: 'substr8',

    // 8ビットで文字列切り取る
    value: function substr8(text, len, truncation) {
      if (truncation === undefined) {
        truncation = '';
      }
      var textArray = text.split('');
      var count = 0;
      var str = '';
      for (var i = 0; i < textArray.length; i++) {
        var n = escape(textArray[i]);
        if (n.length < 4) count++;else count += 2;
        if (count > len) {
          return str + truncation;
        }
        str += text.charAt(i);
      }
      return text;
    }

    // 文字列のバイト数を数える
  }, {
    key: 'lenb',
    value: function lenb(text) {
      return encodeURIComponent(text).replace(/%..%..%../g, 'xx').length;
    }
  }, {
    key: 'splitlenb',
    value: function splitlenb(target, keyS, length) {
      var sep = ' ';
      // keyS で指定された target 内の要素の値をすべて結合した文字列を作る
      var strEntire = keyS.reduce(function (prev, current) {
        return prev + target[current];
      }, '');
      // 結合した文字列を半角スペースで分割する
      var arrEntire = strEntire.split(sep);
      var arrRes = [];
      var last = '';
      // バイト長がlengthを超えない限り前後の分割文字列を結合していく
      // バイト長がlengthを超えたら、ひとつまえの結合文字列を配列登録する
      try {
        arrEntire.reduce(function (prev, current) {
          // length を超えるバイト長の分割文字列がある場合は何もしない
          if (TextUtil.lenb(current) > length) throw new Error('文字列超過');
          var exam = (prev !== '' ? prev + sep : '') + current;
          if (TextUtil.lenb(exam) > length) {
            arrRes.push(prev);
            last = current; // 最後の文字列
            return '';
          } else {
            last = exam; // 最後の文字列
            return exam;
          }
        }, '');
      } catch (e) {
        // length を超えるバイト長の分割文字列がある場合は何もしない
        if (e.message === '文字列超過') return;
      }

      arrRes.push(last); // 最後の文字列を配列登録する
      // keyS で指定された target 内の要素の値を修正する
      for (var i = 0; i < keyS.length; i++) {
        target[keyS[i]] = arrRes[i] ? arrRes[i] : '';
      }
    }
  }]);

  return TextUtil;
})();

exports['default'] = TextUtil;
module.exports = exports['default'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _meteorMeteor = require('meteor/meteor');

var _meteorMongo = require('meteor/mongo');

var Logs = new _meteorMongo.Mongo.Collection('logs', { idGeneration: 'MONGO' });
exports.Logs = Logs;
var Uploads = new _meteorMongo.Mongo.Collection('uploads', { idGeneration: 'MONGO' });
exports.Uploads = Uploads;
var RobotinShop = new _meteorMongo.Mongo.Collection('robotinShop', { idGeneration: 'MONGO' });

exports.RobotinShop = RobotinShop;
var Configs = new _meteorMongo.Mongo.Collection('configs', { idGeneration: 'MONGO' });

exports.Configs = Configs;
if (_meteorMeteor.Meteor.isServer) {
  _meteorMeteor.Meteor.publish('configs', function () {
    return Configs.find();
  });
}

if (_meteorMeteor.Meteor.isClient) {
  _meteorMeteor.Meteor.subscribe('configs');
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/robotin.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/wowmaApi.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yb2JvdGluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdG9vbHRlc3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci93b3dtYS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIveWF1Y3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3Vwcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL3JvYm90aW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS93b3dtYUFwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3RleHQuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbnMuanMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O2tCQUtlLElBQUk7Ozs7c0JBQ0EsUUFBUTs7Ozs7O2lDQUdKLG9CQUFvQjs7OztrQ0FHcEMsOEJBQThCOztBQUNyQyxJQUFJLG9CQUFvQixHQUFHLHFDQUFZLENBQUM7O0FBRXhDLElBQU0sS0FBSyxHQUFHLGVBQWUsQ0FBQzs7O0FBRzlCLE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxvQkFBb0IsQ0FBQyxDQUFDO0FBQ3hELE1BQU0sQ0FBQyxlQUFlLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxVQUFDLEdBQUcsRUFBRSxJQUFJLEVBQUs7OztBQUcvQyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLGdCQUFHLFFBQVEsQ0FBQyxDQUFDO0FBQzdDLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsZ0JBQUcsU0FBUyxDQUFDLENBQUM7QUFDOUMsTUFBTSxRQUFRLEdBQUcsMEJBQVEsQ0FBQzs7Ozs7OztBQUUxQix5QkFBaUIsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLDhIQUFFO1VBQXhCLElBQUk7O0FBQ1gsVUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQzs7O0FBRy9CLFVBQUksUUFBUSxHQUFNLDBCQUFRLFNBQU07OztBQUdoQyxVQUFJLFFBQVEsR0FBRyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsR0FBRyxHQUFHLEdBQUcsUUFBUSxDQUFDOzs7OztBQUtsRCxVQUFJLEdBQUcsR0FBRztBQUNSLGdCQUFRLEVBQUUsUUFBUTtBQUNsQixzQkFBYyxFQUFFLElBQUksQ0FBQyxJQUFJO0FBQ3pCLHdCQUFnQixFQUFFLFFBQVE7T0FDM0IsQ0FBQzs7QUFFRixVQUFHO0FBQ0QsY0FBTSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsQ0FBQztPQUN4QixDQUNELE9BQU0sR0FBRyxFQUFDO0FBQ1IsV0FBRyxDQUFDLEtBQUssR0FBRyxHQUFHLENBQUM7T0FDakI7QUFDRCxrQ0FBUSxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7O0FBRXBCLGFBQU8sSUFBSSxDQUFDO0tBRWI7Ozs7Ozs7Ozs7Ozs7Ozs7QUFBQSxHQUFDO0FBQ0YsTUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsQ0FBQztBQUNwQixNQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUM7QUFDdEIsWUFBUSxFQUFFLFFBQVE7QUFDbEIsV0FBTyxFQUFFLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUTtHQUMzQixDQUFDLENBQUMsQ0FBQztDQUVMLENBQUMsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7c0JDN0RpQixRQUFROzs7OzRCQUVKLGVBQWU7O2dDQUNwQiwwQkFBMEI7Ozs7aUNBQ3pCLDJCQUEyQjs7Ozt1Q0FJdkMsaUNBQWlDOzt3Q0FHakMsa0NBQWtDOztBQUV6QyxJQUFJLEdBQUcsR0FBRyxTQUFTOztBQUVuQixxQkFBTyxPQUFPLHlEQUVGLEdBQUcsZUFBWSxvQkFBQyxNQUFNO01BQzFCLE1BQU0sRUFLTixNQUFNLEVBTU4sU0FBUyxFQUVULEtBQUs7Ozs7OztBQWJMLGNBQU0sR0FBRyxvQ0FBWTtBQUtyQixjQUFNLEdBQUcscUNBQVcsTUFBTSxDQUFDLFdBQVcsQ0FBQztBQU12QyxpQkFBUyxHQUFHLGdCQUFnQjtBQUU1QixhQUFLLEdBQUcsa0NBQVUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUM7O3dDQUVoQyxNQUFNLENBQUMsS0FBSyxDQUFDLHdCQUF3QixFQUN6Qzs7Ozs7Z0RBQ1EsS0FBSyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQUM7Ozs7Ozs7U0FDN0IsQ0FBQzs7Ozt3Q0FLRSxNQUFNLENBQUMsS0FBSyxDQUFDLHVCQUF1QixFQUN4QztjQUNNLEdBQUc7Ozs7Ozs7Z0RBQVMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUM3Qiw0QkFBVSxFQUFFLG9CQUFPLE1BQU07d0JBYW5CLEdBQUcsRUF3R0gsUUFBUSxFQUVSLFVBQVUsRUFFVixhQUFhLEVBR1gsSUFBRzs7Ozs7QUEvR0wsNkJBQUcsNmRBS08sTUFBTSxDQUFDLFdBQVcsV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxHQUFHLFdBQU0sTUFBTSxDQUFDLEdBQUcsV0FBTSxNQUFNLENBQUMsVUFBVSxXQUFNLE1BQU0sQ0FBQyxJQUFJLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsWUFBWSxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsT0FBTyxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLFFBQVEsV0FBTSxNQUFNLENBQUMsSUFBSSxXQUFNLE1BQU0sQ0FBQyxVQUFVLFdBQU0sTUFBTSxDQUFDLGNBQWMsV0FBTSxNQUFNLENBQUMsYUFBYSxXQUFNLE1BQU0sQ0FBQyxTQUFTLFdBQU0sTUFBTSxDQUFDLFNBQVMsV0FBTSxNQUFNLENBQUMsSUFBSSxXQUFNLE1BQU0sQ0FBQyxXQUFXLFdBQU0sTUFBTSxDQUFDLFdBQVcsV0FBTSxNQUFNLENBQUMsT0FBTzs7OzBEQUt6ckIsS0FBSyxDQUFDLFdBQVcsQ0FDckIsY0FBYyxFQUFFO0FBQ2QsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLCtCQUFHLEVBQUUsTUFBTSxDQUFDLEdBQUc7QUFDZiwrQkFBRyxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQ2Ysc0NBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtBQUM3QixnQ0FBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO0FBQ2pCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsd0NBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtBQUNqQyxpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTztBQUN2QixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLG9DQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVE7QUFDekIsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQixzQ0FBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO0FBQzdCLDBDQUFjLEVBQUUsTUFBTSxDQUFDLGNBQWM7QUFDckMseUNBQWEsRUFBRSxNQUFNLENBQUMsYUFBYTtBQUNuQyxxQ0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO0FBQzNCLHFDQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7QUFDM0IsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTzsyQkFDeEIsQ0FDRjs7Ozs7Ozs7OztBQUVELGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7MERBS1YsS0FBSyxDQUFDLFdBQVcsQ0FDckIsc0JBQXNCLEVBQUU7QUFDdEIsK0NBQW1CLEVBQUUsSUFBSTtBQUN6Qix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHNDQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDN0IsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLHdDQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7QUFDakMsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87QUFDdkIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPOzJCQUN4QixDQUNGOzs7Ozs7Ozs7O0FBRUQsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7OzswREFLVixLQUFLLENBQUMsV0FBVyxDQUNyQix1QkFBdUIsRUFBRTtBQUN2Qiw4QkFBRSxFQUFFLElBQUk7QUFDUix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHdDQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7QUFDakMsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87MkJBQ3hCLENBQ0Y7Ozs7Ozs7Ozs7QUFFRCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7OztBQUtkLGtDQUFRLEdBQUcsb0JBQU8sV0FBVyxDQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxRQUFRLENBQUMsQ0FBQyxTQUFTLENBQUMsQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUVwRSxvQ0FBVSxHQUFNLE1BQU0sQ0FBQyxNQUFNLFNBQUksTUFBTSxDQUFDLE1BQU0sd0JBQW1CLE1BQU0sQ0FBQyxXQUFXO0FBRW5GLHVDQUFhLEdBQUcsTUFBTSxDQUFDLEtBQUssR0FBRyxHQUFHOzs7MERBR3BCLEtBQUssQ0FBQyxXQUFXLENBQy9CLFlBQVksRUFBRTtBQUNaLHFDQUFTLEVBQUUsSUFBSTtBQUNmLHFDQUFTLEVBQUUsUUFBUTtBQUNuQix1Q0FBVyxFQUFFLENBQUM7QUFDZCx1Q0FBVyxFQUFFLFVBQVU7QUFDdkIseUNBQWEsRUFBRSxDQUFDO0FBQ2hCLDJDQUFlLEVBQUUsQ0FBQztBQUNsQiwwQ0FBYyxFQUFFLENBQUM7QUFDakIsMENBQWMsRUFBRSxhQUFhO0FBQzdCLHlDQUFhLEVBQUUsSUFBSTtBQUNuQix1Q0FBVyxFQUFFLENBQUM7QUFDZCx5Q0FBYSxFQUFFLENBQUM7QUFDaEIsOENBQWtCLEVBQUUsSUFBSTtBQUN4Qix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLCtDQUFtQixFQUFFLHFCQUFxQjtBQUMxQyw2Q0FBaUIsRUFBRSxxQkFBcUI7QUFDeEMsbUNBQU8sRUFBRSxDQUFDOzJCQUNYLEVBQUU7QUFDRCx1Q0FBVyxFQUFFLE9BQU87QUFDcEIsdUNBQVcsRUFBRSxPQUFPOzJCQUNyQixDQUNGOzs7QUF0QkcsOEJBQUc7Ozs7Ozs7O0FBd0JQLGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OzttQkFFbkI7aUJBQ0YsRUFDRCxvQkFBTyxDQUFDOzs7O0FBQ04sOEJBQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDOzs7Ozs7O2lCQUNqQixDQUNBOzs7QUE1SkcsbUJBQUc7b0RBOEpBLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FFSyxxQkFBcUIsRUFBQyw0QkFBQyxPQUFPO01BQzlCLEVBQUUsRUFDRixHQUFHOzs7O0FBREgsVUFBRSxHQUFHLGtDQUFVLE9BQU8sQ0FBQzs7d0NBQ1gsRUFBRSxDQUFDLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBQzs7O0FBQXRDLFdBQUc7NENBQ0EsR0FBRzs7Ozs7OztDQUNYLG9CQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnQ0NyTjhCLDBCQUEwQjs7NEJBQ3JDLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLGtCQUFrQjs7QUFFNUIscUJBQU8sT0FBTyx5REFFRixHQUFHLFlBQVMsb0JBQUMsSUFBSTtNQUFFLEtBQUsseURBQUcsRUFBRTtNQUFFLFVBQVUseURBQUcsRUFBRTtNQUNsRCxJQUFJLEVBQ0osR0FBRzs7Ozs7d0NBRFUsa0NBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQzs7O0FBQXZELFlBQUk7O3dDQUNRLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUMsVUFBVSxFQUFFLFVBQVUsRUFBQyxDQUFDLENBQUMsT0FBTyxFQUFFOzs7QUFBaEUsV0FBRzs0Q0FDQSxHQUFHOzs7Ozs7O0NBQ1gsb0NBRVMsR0FBRyxpQkFBYyxvQkFBQyxJQUFJO01BQUUsS0FBSyx5REFBRyxFQUFFO01BQ3RDLElBQUksRUFDSixHQUFHOzs7Ozt3Q0FEVSxrQ0FBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDOzs7QUFBdkQsWUFBSTs7d0NBQ1EsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQyxPQUFPLEVBQUU7OztBQUEzQyxXQUFHOzRDQUNBLEdBQUc7Ozs7Ozs7Q0FDWCxvQkFFRCxDOzs7Ozs7Ozs7Ozs7Ozs7OzttQ0NuQnlCLDZCQUE2Qjs7Ozs0QkFDbkMsZUFBZTs7QUFFcEMsSUFBSSxHQUFHLEdBQUcsYUFBYTs7QUFFdkIscUJBQU8sT0FBTyx5REFPRixHQUFHLGdCQUFhLG9CQUFDLElBQUksRUFBRSxRQUFRLEVBQUUsS0FBSztNQUFFLE1BQU0seURBQUcsSUFBSTtNQUFFLE1BQU0seURBQUcsSUFBSTtNQUN4RSxPQUFPLEVBRVAsUUFBUTs7OztBQUZSLGVBQU8sR0FBRyxzQ0FBb0I7O3dDQUM1QixPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs7Ozt3Q0FDSCxPQUFPLENBQUMsUUFBUSxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQzs7O0FBQWxFLGdCQUFROzRDQUNMLFFBQVE7Ozs7Ozs7Q0FDaEIsb0NBS1MsR0FBRyxrQkFBZSxvQkFBQyxJQUFJLEVBQUUsS0FBSztNQUFFLE1BQU0seURBQUcsSUFBSTtNQUFFLE1BQU0seURBQUcsSUFBSTtNQUNoRSxPQUFPOzs7O0FBQVAsZUFBTyxHQUFHLHNDQUFvQjs7d0NBQzVCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDOzs7O3dDQUNsQixPQUFPLENBQUMsVUFBVSxDQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDOzs7Ozs7O0NBQ2hELG9CQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDNUJpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7c0NBRzdCLDZCQUE2Qjs7Z0NBQ2xCLHVCQUF1Qjs7OzttQ0FDZCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLE1BQU07O0FBRWhCLHFCQUFPLE9BQU8seURBS0YsR0FBRyxtQkFBZ0Isb0JBQUMsTUFBTTtNQUU5QixNQUFNLEVBRU4sTUFBTSxFQUNOLGNBQWMsRUFHZCxRQUFRLEVBQ1IsR0FBRzs7Ozs7O0FBUEgsY0FBTSxHQUFHLG9DQUFZO0FBRXJCLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDbkMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFFckMsZ0JBQVEsR0FBRyxrQ0FBVSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ3BDLFdBQUcsR0FBRyxxQ0FBYSxRQUFRLENBQUM7O3dDQUUxQixNQUFNLENBQUMsS0FBSyxDQUNoQixPQUFPLEVBQ1A7Y0FDTSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3hCLFFBQVE7Ozs7OzBEQUFTLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7O0FBQWxELGtDQUFROzswREFDTixHQUFHLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLFFBQVEsQ0FBQzs7Ozs7OzttQkFDeEUsRUFBQyxDQUFDOzs7QUFMRCxtQkFBRztvREFPQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBS1MsR0FBRyxpQkFBYyxvQkFBQyxNQUFNO01BQzVCLE1BQU0sRUFDTixRQUFRLEVBQ1IsR0FBRyxFQUVILGNBQWMsRUFJZCxNQUFNOzs7Ozs7QUFSTixjQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCxnQkFBUSxHQUFHLGtDQUFVLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDcEMsV0FBRyxHQUFHLHFDQUFhLFFBQVEsQ0FBQztBQUU1QixzQkFBYyxHQUFHLHNDQUFvQjs7d0NBQ25DLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBR3JDLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGVBQWUsRUFDZjtjQUNNLEdBQUc7Ozs7Ozs7Z0RBQVMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUM3QiwwQkFBUSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPO3dCQUN4QixHQUFHLEVBR0QsUUFBUSxFQUVSLFNBQVM7Ozs7QUFMWCw2QkFBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVOzs7MERBR0wsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDOzs7QUFBekUsa0NBQVE7OzBEQUVVLEdBQUcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDOzs7QUFBN0MsbUNBQVM7OzBEQUdQLEdBQUcsQ0FBQyxNQUFNLENBQUM7QUFDZiwrQkFBRyxFQUFFLElBQUksQ0FBQyxHQUFHOzJCQUNkLEVBQUU7QUFDRCxnQ0FBSSxFQUFFO0FBQ0osMkRBQTZCLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVO0FBQ3ZELGlFQUFtQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCO0FBQ25FLGlFQUFtQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCOzZCQUNwRTsyQkFDRixDQUFDOzs7O0FBRUYsZ0NBQU0sQ0FBQyxRQUFRLEVBQUU7Ozs7Ozs7O0FBRWpCLGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OzttQkFFbkI7aUJBQ0YsRUFDRCxvQkFBTyxDQUFDOzs7OzhCQUNBLENBQUM7Ozs7Ozs7aUJBQ1IsQ0FBQzs7O0FBNUJFLG1CQUFHO29EQThCQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7Ozt3Q0FFRSxNQUFNLENBQUMsS0FBSyxDQUNoQixnQkFBZ0IsRUFDaEI7Y0FDTSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDeEIsR0FBRyxFQUdELFFBQVEsRUFNUixRQUFROzs7O0FBVFYsNkJBQUcsR0FBRyxPQUFPLENBQUMsVUFBVTs7OzBEQUdMLGNBQWMsQ0FBQyxnQkFBZ0IsQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQzs7O0FBQXpFLGtDQUFROzswREFFTixHQUFHLENBQUMsa0JBQWtCLENBQUMsUUFBUSxDQUFDOzs7OzBEQUNoQyxHQUFHLENBQUMsYUFBYSxDQUFDLFFBQVEsQ0FBQzs7OzswREFDM0IsR0FBRyxDQUFDLGdCQUFnQixDQUFDLFFBQVEsQ0FBQzs7OzswREFFZixjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUFsRCxrQ0FBUTs7MERBQ04sR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLENBQUM7Ozs7QUFFdkUsZ0NBQU0sQ0FBQyxRQUFRLEVBQUU7Ozs7Ozs7O0FBRWpCLGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OzttQkFFbkI7aUJBQ0YsRUFDRCxvQkFBTyxDQUFDOzs7OzhCQUNBLENBQUM7Ozs7Ozs7aUJBQ1IsQ0FBQzs7O0FBdEJFLG1CQUFHO29EQXdCQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0JBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQ2pJaUIsd0JBQXdCOzs7O21DQUNoQiwwQkFBMEI7Ozs7NEJBQzlCLGVBQWU7O3VCQUNsQixVQUFVOzs7O3lCQUNaLFlBQVk7Ozs7bUJBQ2QsS0FBSzs7OztzQkFDZSxRQUFROztzQkFFMUIsUUFBUTs7OztxQ0FDTiw0QkFBNEI7Ozs7QUFFaEQsSUFBTSxHQUFHLEdBQUcsU0FBUzs7QUFFckIscUJBQU8sT0FBTyx5REFFRixHQUFHLGlCQUFjLG9CQUFDLE1BQU07TUFFNUIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZ0JBQWdCLEVBQ2hCO2NBQ1EsT0FBTyxFQUNQLFdBQVcsRUFDWCxZQUFZLEVBa0JaLEtBQUssRUFJTCxJQUFJOzs7O0FBeEJKLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsU0FBUyxDQUFDLE9BQU87QUFDdkQsMkJBQVcsR0FBTSxPQUFPLFNBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXO0FBQ3hELDRCQUFZLEdBQU0sT0FBTyxTQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsWUFBWTs7O2dEQUd4RCxxQkFBUSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFHN0IscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFJdEIscUJBQVEsS0FBSyxDQUFDLFdBQVcsQ0FBQzs7Ozs7Ozs7Ozs7OztnREFJMUIscUJBQVEsS0FBSyxDQUFDLFlBQVksQ0FBQzs7Ozs7Ozs7Ozs7QUFJN0IscUJBQUssR0FBRyxzQ0FBb0I7O2dEQUM1QixLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUcxQixvQkFBSSxHQUFHLHdDQUFhOztBQUMxQixxQ0FBTyxTQUFTLENBQUMsYUFBRyxFQUFJO0FBQ3RCLHNCQUFNLElBQUksR0FBRyxxQkFBUSxnQkFBZ0IsQ0FBSSxXQUFXLFNBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLFVBQU8sQ0FDckYsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDO0FBQ25DLHNCQUFNLEtBQUssR0FBRyxxQkFBYTtBQUN6Qiw4QkFBVSxFQUFFLElBQUk7QUFDVix5QkFBSyxFQUFDLGVBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFROzs7Ozs0REFDOUIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDOzs7QUFDcEMsb0NBQVEsRUFBRTs7Ozs7OztxQkFDWDtBQUNELHlCQUFLLEVBQUMsZUFBQyxRQUFRLEVBQUU7QUFDZiw4QkFBUSxFQUFFO0FBQ1YseUJBQUcsRUFBRTtxQkFDTjttQkFDRixDQUFDOztBQUVGLHNCQUFJLENBQUMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNsQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyxpQkFBSSxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUNmLENBQUMsRUFBRTs7O0FBR0osc0JBQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxxQkFBVyxFQUFJO0FBQ2pELHNCQUFJO0FBQ0YseUNBQU8sU0FBUyxDQUFDLGFBQUcsRUFBSTtBQUN0QiwwQkFBTSxJQUFJLEdBQUcscUJBQVEsZ0JBQWdCLENBQUksV0FBVyxTQUFJLFdBQVcsQ0FBQyxPQUFPLFVBQU8sQ0FDL0UsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFNO0FBQUUsMkJBQUcsRUFBRTt1QkFBRSxDQUFDO0FBQy9CLDBCQUFNLFNBQVMsR0FBRyxzQkFBYztBQUM5QiwwQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLDBDQUFrQixFQUFFLElBQUk7QUFDeEIsaUNBQVMsRUFBRSxtQkFBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBSztBQUN4Qyw4QkFBSSxNQUFNO0FBQ1YsOEJBQUk7QUFDRixrQ0FBTSxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUMsS0FBSyxFQUFFLFdBQVcsQ0FBQztBQUNyRCxvQ0FBUSxDQUFDLElBQUksRUFBRSxNQUFNLENBQUM7MkJBQ3ZCLENBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCwrQkFBRyxDQUFDLEtBQUssQ0FBQzsyQkFDWDt5QkFDRjt1QkFDRixDQUFDO0FBQ0YsMEJBQU0sS0FBSyxHQUFHLHFCQUFRLGlCQUFpQixDQUFJLFlBQVksU0FBSSxXQUFXLENBQUMsUUFBUSxVQUFPLENBQ25GLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBTTtBQUNsQiw4QkFBTSxDQUFDLFFBQVEsRUFBRTtBQUNqQiwyQkFBRyxFQUFFO3VCQUNOLENBQUMsQ0FDRCxFQUFFLENBQUMsT0FBTyxFQUFFLGVBQUssRUFBSTtBQUFFLDJCQUFHLENBQUMsS0FBSyxDQUFDO3VCQUFFLENBQUM7O0FBRXZDLDBCQUFJLENBQ0QsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyxpQkFBSSxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLE9BQU8sS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDdEUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUNmLElBQUksQ0FBQyxpQkFBSSxTQUFTLENBQUMsRUFBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUMsQ0FDbEQsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUM7cUJBQ2YsQ0FBQyxFQUFFO21CQUNMLENBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCwwQkFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7bUJBQ3JCO2lCQUNGLENBQUM7Ozs7Ozs7U0FDSCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FNUyxHQUFHLGdCQUFhLG9CQUFDLE1BQU07TUFFM0IsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsbUJBQW1CLEVBQ25CO2NBQ1EsT0FBTyxFQVNMLGNBQWMsRUFHZCxJQUFJLEVBRUosUUFBUTs7OztBQWRWLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU87OztnREFHcEQscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7Z0RBRzdCLHFCQUFRLEtBQUssQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7OztBQUd0Qiw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBRW5DLG9CQUFJLEdBQUcsY0FBYyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxHQUFHLEVBQUUsRUFBRSxFQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRTs7QUFFN0Qsd0JBQVEsR0FBRyxTQUFYLFFBQVEsQ0FBSSxJQUFJLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBSztBQUN2QyxzQkFBTSxPQUFPLEdBQUcsc0JBQWM7QUFDNUIsc0NBQWtCLEVBQUUsSUFBSTtBQUN4QixzQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLDZCQUFTLEVBQUMsbUJBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUU7QUFDcEMsK0NBQU0sWUFBTTtBQUNWLDRCQUFNLElBQUksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQ3RCLGdDQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQzt1QkFDckIsQ0FBQyxDQUFDLEdBQUcsRUFBRTtxQkFDVDttQkFDRixDQUFDO0FBQ0Ysc0JBQUksS0FBSyxHQUFHLENBQUM7QUFDYixzQkFBTSxRQUFRLEdBQUcsc0JBQWM7QUFDN0IsNEJBQVEsRUFBRSxNQUFNO0FBQ2hCLDZCQUFTLEVBQUUsbUJBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUs7QUFDeEMsMEJBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDMUIsMEJBQUksS0FBSyxLQUFLLENBQUMsRUFBRTtBQUNmLDJCQUFHLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO3VCQUNoQztBQUNELDJCQUFLLEVBQUU7QUFDUCw4QkFBUSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUM7cUJBQ3BCO21CQUNGLENBQUM7QUFDRixzQkFBTSxRQUFRLEdBQUcscUJBQVEsaUJBQWlCLENBQUksUUFBUSxVQUFPO0FBQzdELDBCQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxXQUFDLEVBQUk7QUFBRSwwQkFBTSxxQkFBTyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7bUJBQUUsQ0FBQzs7QUFFbkUsc0JBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQ2YsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FBQyxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ25DLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FDZCxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLFFBQVEsQ0FBQztpQkFDbEI7O0FBRUQsd0JBQVEsQ0FDTixJQUFJLEVBQ0osaUNBQWUsc0JBQXNCLEVBQ2xDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FDMUM7O0FBRUQsd0JBQVEsQ0FDTixJQUFJLEVBQ0osaUNBQWUsd0JBQXdCLEVBQ3BDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FDNUM7OztzQkFHRyxJQUFJLHFCQUFPLEtBQUssa0NBQWdDLE9BQU8sT0FBSTs7Ozs7OztTQUNsRSxDQUNGOzs7Ozs7O0NBQ0Ysb0JBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDOUxpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7Z0NBQ2xCLHVCQUF1Qjs7Ozs0QkFDcEIsZUFBZTs7QUFFcEMsSUFBSSxHQUFHLEdBQUcsTUFBTTs7QUFFaEIscUJBQU8sT0FBTyxxQkFLRixHQUFHLFlBQVMsb0JBQUMsTUFBTTtNQUV2QixNQUFNLEVBRU4sTUFBTSxFQUVKLFFBQVE7Ozs7OztBQUpWLGNBQU0sR0FBRyxvQ0FBWTtBQUVyQixjQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7d0NBRXZDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLG9CQUFPLENBQUM7Ozs7c0JBQzFDLENBQUM7Ozs7Ozs7U0FDUixDQUFDOzs7QUFGSSxnQkFBUTs7d0NBR1IsTUFBTSxDQUFDLEtBQUssQ0FDaEIsVUFBVSxFQUNWOzs7O29EQUNTLFFBQVE7Ozs7Ozs7U0FDaEIsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsRUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0NoQ2lCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOzttQ0FDVCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O3VCQUNoQixVQUFVOzs7OzhCQUVWLGlCQUFpQjs7OztzQ0FDaEIsNkJBQTZCOzs7O2dDQUM1Qix1QkFBdUI7Ozs7QUFFN0MsSUFBTSxHQUFHLEdBQUcsT0FBTzs7QUFFbkIscUJBQU8sT0FBTyx5REFLRixHQUFHLGlDQUE4QixvQkFBQyxNQUFNO01BRTVDLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLHFCQUFxQixFQUNyQjtjQUdRLGNBQWMsRUFLaEIsR0FBRyxFQTRDSCxHQUFHOzs7Ozs7QUFqREQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBSXpCLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUM1QyxDQUNFO0FBQ0Usd0JBQU0sRUFBRTtBQUNOLHdCQUFJLEVBQUUsQ0FDSjtBQUNFLDJDQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtxQkFDdEMsQ0FrQkY7bUJBQ0Y7aUJBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFLHNCQUFzQjttQkFDNUI7aUJBQ0YsRUFDRDtBQUNFLDBCQUFRLEVBQUU7QUFDUix1QkFBRyxFQUFFLENBQUM7QUFDTiw0QkFBUSxFQUFFLE1BQU07bUJBQ2pCO2lCQUNGLENBQ0YsQ0FDRjs7O0FBekNHLG1CQUFHO0FBNENILG1CQUFHLEdBQUcsd0NBQWEsTUFBTSxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDOztnREFDcEQsTUFBTSxDQUFDLGVBQWUsQ0FDMUIsR0FBRyxFQUNILG9CQUFNLElBQUk7c0JBR0YsR0FBRzs7Ozt5Q0FGVCxNQUFNO3lDQUFRLElBQUk7O3dEQUFRLGNBQWMsQ0FBQyxvQ0FBb0MsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDOzs7O3VDQUFyRixNQUFNOzs7d0RBRUssR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7OztBQUFoQywyQkFBRzs0REFDQSxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBQzs7Ozs7OEJBRW5DLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFDLEVBQUUsOEJBQVUsS0FBSyxnQkFBRyxDQUFDOzs7Ozs7O2lCQUUvRCxDQUNGOzs7Ozs7O1NBQ0YsQ0FDRjs7OzRDQUVNLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBS1MsR0FBRyx1QkFBb0Isb0JBQUMsTUFBTTtNQUVsQyxNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQiwwQkFBMEIsRUFDMUI7Y0FHUSxjQUFjLEVBS2hCLEdBQUcsRUF5Q0gsR0FBRzs7Ozs7O0FBOUNELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUl6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7cUJBZUY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRSxzQkFBc0I7bUJBQzVCO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO21CQUNqQjtpQkFDRixDQUNGLENBQ0Y7OztBQXRDRyxtQkFBRztBQXlDSCxtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Z0RBQ3BELE1BQU0sQ0FBQyxlQUFlLENBQzFCLEdBQUcsRUFDSCxvQkFBTSxJQUFJO3NCQUlGLEdBQUc7Ozs7QUFIVCw0QkFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDO0FBQ25CLDRCQUFJLENBQUMsYUFBYSxHQUFHLE1BQU07Ozt3REFFVCxHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQzs7O0FBQWhDLDJCQUFHOzREQUNBLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFDOzs7Ozs4QkFFbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUMsRUFBRSw4QkFBVSxLQUFLLGdCQUFHLENBQUM7Ozs7Ozs7aUJBRS9ELENBQ0Y7Ozs7Ozs7U0FDRixDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLG1CQUFnQixvQkFBQyxNQUFNO01BRTlCLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGFBQWEsRUFDYjtjQUdRLGNBQWMsRUFHaEIsR0FBRyxFQWtFRCxJQUFJLGtGQUdDLENBQUMsRUFPTixHQUFHLEVBRUQsR0FBRzs7Ozs7QUFqRkwsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBRXpCLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUM1QyxDQUNFO0FBQ0Usd0JBQU0sRUFBRTtBQUNOLHdCQUFJLEVBQUUsQ0FDSjtBQUNFLDJDQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtxQkFDdEM7Ozs7Ozs7Ozs7Ozs7OztxQkFlRjttQkFDRjtpQkFDRixFQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFO0FBQ0gsOEJBQVEsRUFBRSxzQkFBc0I7QUFDaEMsZ0RBQTBCLEVBQUUseUJBQXlCO0FBQ3JELDhDQUF3QixFQUFFLHlCQUF5QjtxQkFDcEQ7QUFDRCx3QkFBSSxFQUFFO0FBQ0osNEJBQU0sRUFBRSxNQUFNO3FCQUNmO21CQUNGO2lCQUNGLEVBQ0Q7O0FBRUUsd0JBQU0sRUFBRTtBQUNOLHVCQUFHLEVBQUUsZUFBZTtBQUNwQiw4QkFBVSxFQUFFO0FBQ1YsMkJBQUssRUFBRTtBQUNMLDJCQUFHLEVBQUUsT0FBTztBQUNaLGtEQUEwQixFQUFFLGlDQUFpQztBQUM3RCxnREFBd0IsRUFBRSwrQkFBK0I7dUJBQzFEO3FCQUNGO21CQUNGO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO0FBQ2hCLDhCQUFVLEVBQUUsYUFBYTttQkFDMUI7aUJBQ0YsQ0FDRixDQUNGOzs7QUEzREcsbUJBQUc7Ozs7Z0RBaUVNLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7OztnREFDUCxHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdkIsb0JBQUk7Ozs7OzRCQUdNLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUFwQixpQkFBQzs7Z0RBQ1EsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDOzs7QUFBOUMsaUJBQUMsQ0FBQyxLQUFLOztBQUNQLHVCQUFPLENBQUMsQ0FBQyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLVixtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7O2dEQUV4QyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7OztBQUFuQyxtQkFBRzs7QUFDUCxzQkFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7O0FBRXBCLHNCQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OztBQUdwQixtQkFBRyxDQUFDLEtBQUssRUFBRTs7Ozs7OztTQUNaLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUtTLEdBQUcsa0JBQWUsb0JBQUMsTUFBTTtNQUU3QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixlQUFlLEVBQ2Y7Y0FJUSxNQUFNLEVBQ04sY0FBYyxFQVNkLE9BQU8sRUFTVCxHQUFHOzs7Ozs7QUFuQkQsc0JBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7OztnREFJakMscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7O0FBSS9CLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sZUFBVyxJQUFJLElBQUksRUFBRSxDQUFFLE9BQU8sRUFBRTs7O2dEQUd6RCxxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7Z0RBTWQsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7QUFFN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDeEIsT0FBTyxFQUlQLEtBQUssRUFDTCxRQUFROzs7O0FBTFIsaUNBQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDOztBQUN6RCxpQ0FBTyxDQUFDLEdBQUcsR0FBTSxPQUFPLENBQUMsR0FBRyxvQkFBaUI7QUFDN0MsaUNBQU8sQ0FBQyxFQUFFLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVE7OzswREFFNUIsaUNBQVEsT0FBTyxDQUFDOzs7QUFBOUIsK0JBQUs7QUFDTCxrQ0FBUSxHQUFNLE9BQU8sU0FBSSxJQUFJLENBQUMsS0FBSzs7MERBRWpDLHFCQUFRLFNBQVMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDOzs7Ozs7O21CQUN6QyxFQUFDLENBQUM7OztBQVhELG1CQUFHO29EQWFBLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQkFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0MxVWlCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOzttQ0FDVCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O0FBRXBDLElBQU0sR0FBRyxHQUFHLFVBQVU7O0FBRXRCLHFCQUFPLE9BQU8scUJBS0YsR0FBRyxlQUFZLG9CQUFDLE1BQU07TUFFMUIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBSVEsTUFBTSxFQUNOLGNBQWMsRUFrQmhCLEdBQUc7Ozs7OztBQW5CRCxzQkFBTSxHQUFHLCtDQUF1QixNQUFNLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDaEUsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBaUJ6QixNQUFNLENBQUMsT0FBTyxDQUFDOztBQUU3QiwwQkFBUSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPOzs7O0FBQzVCLGdDQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQzs7Ozs7OzttQkFDdEIsRUFBQyxDQUFDOzs7QUFKRCxtQkFBRztvREFNQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsRUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0N4RGlCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOzttQ0FDVCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O2lDQUNqQix3QkFBd0I7Ozs7dUJBQ3ZCLFVBQVU7Ozs7eUJBRVosWUFBWTs7Ozt3QkFDVCxVQUFVOzs7O21CQUNmLEtBQUs7Ozs7c0JBQ2tCLFFBQVE7O0FBRS9DLElBQU0sTUFBTSxHQUFHLFFBQVE7QUFDdkIsSUFBTSxHQUFHLEdBQUcsT0FBTzs7QUFFbkIscUJBQU8sT0FBTyx5REFLRixHQUFHLGFBQVUsb0JBQUMsTUFBTTtNQUV4QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixRQUFRLEVBQ1I7Y0FDUSxjQUFjLEVBRWQsT0FBTyxFQUNQLENBQUMsRUFDRCxDQUFDOzs7Ozs7QUFKRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBQ25DLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU87QUFDM0IsaUJBQUMsR0FBRyxxQkFBUSxnQkFBZ0IsQ0FBSSxPQUFPLFNBQUksTUFBTSxDQUFDLGFBQWEsQ0FBRztBQUNsRSxpQkFBQyxHQUFHLHFCQUFRLGlCQUFpQixDQUFJLE9BQU8sU0FBSSxNQUFNLENBQUMsYUFBYSxDQUFHOztBQUN6RSxpQkFBQyxDQUFDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDL0IsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsaUJBQUksS0FBSyxDQUFDLEVBQUMsT0FBTyxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FDakIsb0JBQU8sTUFBTSxFQUFFLFFBQVE7c0JBQ2pCLEdBQUc7Ozs7QUFBSCwyQkFBRyxHQUFHLElBQUk7Ozt3REFHVyxjQUFjLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQzs7O0FBQW5FLDhCQUFNLENBQUMsTUFBTSxDQUFDOzs7Ozs7OztBQUVkLDJCQUFHLGlCQUFJOzs7QUFFVCxnQ0FBUSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUM7Ozs7Ozs7aUJBQ3RCLENBQ0YsQ0FBQyxDQUNELElBQUksQ0FBQyxpQkFBSSxTQUFTLENBQUMsRUFBQyxNQUFNLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUNuQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLENBQUMsQ0FBQzs7Ozs7OztTQUNYLENBQ0Y7Ozs7Ozs7Q0FDRixvQ0FLUyxHQUFHLGVBQVksb0JBQUMsTUFBTTtNQUUxQixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixRQUFRLEVBQ1I7Y0FJUSxNQUFNLEVBQ04sY0FBYyxFQUlkLE1BQU0sRUFRTixPQUFPLEVBS1AsU0FBUyxFQUlYLEVBQUUsRUFDRixRQUFRLEVBQ1IsSUFBSSxFQUdKLE1BQU0sRUFDTixNQUFNLEVBNkNOLEdBQUc7Ozs7OztBQXpFRCxzQkFBTSxHQUFHLDBDQUFrQixNQUFNLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDMUQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUduQyxzQkFBTSxHQUFHLG1DQUFXLE1BQU0sQ0FBQyxVQUFVLENBQUM7OztnREFJcEMscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7O0FBSS9CLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU87O2dEQUMzQixxQkFBUSxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUN2QixxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7QUFHdEIseUJBQVMsR0FBTSxNQUFNLENBQUMsT0FBTzs7Z0RBQzdCLHFCQUFRLE1BQU0sQ0FBQyxTQUFTLENBQUM7Ozs7Z0RBQ3pCLHFCQUFRLEtBQUssQ0FBQyxTQUFTLENBQUM7OztBQUUxQixrQkFBRSxHQUFHLElBQUk7QUFDVCx3QkFBUSxHQUFHLElBQUk7QUFDZixvQkFBSSxHQUFHLElBQUk7QUFHWCxzQkFBTSxHQUFHLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxjQUFjLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsV0FBVyxFQUFFLG9CQUFvQixFQUFFLGlCQUFpQixFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQztBQUM5cEMsc0JBQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQUM7K0JBQVEsQ0FBQztpQkFBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUk7OztBQUd2RCxzQkFBTSxDQUFDLGFBQWEsR0FBRyxvQkFBTyxXQUFXOzs7O0FBQ3ZDLDRCQUFJLEdBQUcsTUFBTSxHQUFHLENBQUMsT0FBTyxHQUFHLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsMEJBQUUsR0FBTSxPQUFPLFNBQUksSUFBTTtBQUN6QixnQ0FBUSxHQUFNLEVBQUUsU0FBSSxNQUFNLENBQUMsV0FBYTs7d0RBQ2xDLHFCQUFRLEtBQUssQ0FBQyxFQUFFLENBQUM7Ozs7d0RBRWpCLHFCQUFRLFVBQVUsQ0FBQyxRQUFRLEVBQUUsdUJBQU0sTUFBTSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQzs7Ozs7OztpQkFDdEU7OztBQUdELHNCQUFNLENBQUMsUUFBUSxHQUFHLG9CQUFPLEdBQUc7c0JBQ3RCLEtBQUssRUFDTCxJQUFJLEVBRUosTUFBTSxrRkFHRCxHQUFHLEVBQ04sTUFBTSxFQUNOLE1BQU07Ozs7O0FBUlIsNkJBQUssR0FBRyxHQUFHLENBQUMsS0FBSztBQUNqQiw0QkFBSSxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBRWYsOEJBQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQUMsRUFBSTtBQUFFLGlDQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQU0sSUFBSTt5QkFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUk7O3dEQUNyRixxQkFBUSxVQUFVLENBQUMsUUFBUSxFQUFFLHVCQUFNLE1BQU0sQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7Ozs7Ozs7b0NBRXJELElBQUksQ0FBQyxNQUFNOzs7Ozs7OztBQUFsQiwyQkFBRztBQUNOLDhCQUFNLEdBQU0sTUFBTSxDQUFDLFFBQVEsU0FBSSxHQUFHO0FBQ2xDLDhCQUFNLEdBQU0sRUFBRSxTQUFJLEdBQUc7Ozt3REFHakIscUJBQVEsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7Ozt3REFFdEIscUJBQVEsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUJBRzNDOzs7QUFHRCxzQkFBTSxDQUFDLFdBQVcsR0FBRyxvQkFBTyxXQUFXO3NCQUMvQixHQUFHLEVBQ0gsT0FBTyxFQUNQLE1BQU07Ozs7QUFGTiwyQkFBRyxHQUFHLDJCQUFTLEtBQUssQ0FBQztBQUNyQiwrQkFBTyxHQUFNLFNBQVMsU0FBSSxJQUFJO0FBQzlCLDhCQUFNLEdBQUcscUJBQVEsaUJBQWlCLENBQUMsT0FBTyxDQUFDOztBQUNqRCwyQkFBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDaEIsMkJBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQztBQUN4QiwyQkFBRyxDQUFDLFFBQVEsRUFBRTs7Ozs7OztpQkFDZjs7Ozs7O2dEQUtlLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3hCLFFBQVEsRUFHTixLQUFLOzs7OzswREFIVSxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUFsRCxrQ0FBUTs7Z0NBRVIsUUFBUSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVc7Ozs7OzswREFDdkIsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sV0FBUSxFQUFFLElBQUksQ0FBQzs7O0FBQW5FLCtCQUFLOzswREFDSCxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFDLENBQUM7Ozs7Ozs7bUJBRWxELEVBQUMsQ0FBQzs7O0FBVEQsbUJBQUc7O0FBV1Asc0JBQU0sQ0FBQyxLQUFLLEVBQUU7O29EQUVQLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztRQ25LSyx3QkFBd0I7O1FBQ3hCLHNCQUFzQixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQ0N0QixjQUFjOzt5QkFDSCxlQUFlOzs7OzRCQUcxQixlQUFlOzs7O29CQUdMLE1BQU07Ozs7MkJBQ0gsYUFBYTs7OztzQkFDUCxVQUFVOztBQUVwQyxJQUFNLE9BQU8sR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxTQUFTLEVBQUU7QUFDOUMsY0FBWSxFQUFFLE9BQU87Q0FDdEIsQ0FBQyxDQUFDOztJQUVVLE1BQU07WUFBTixNQUFNOztBQUVOLFdBRkEsTUFBTSxDQUVMLFFBQVEsRUFBRTs7OzBCQUZYLE1BQU07O0FBSWYsUUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUM1QixTQUFHLEVBQUUsUUFBUTtLQUNkLENBQUMsQ0FBQzs7QUFFSCwrQkFSUyxNQUFNLDZDQVFULE9BQU8sRUFBRTs7QUFFZixRQUFJLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7O0FBRTFCLFlBQVEsSUFBSSxDQUFDLElBQUk7O0FBRWYsV0FBSyxPQUFPO0FBQ1YsWUFBSSxDQUFDLEtBQUssR0FBRywyQkFBVSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEMsWUFBSSxVQUFPLEdBQUc7Y0FBUSxRQUFRLHlEQUFHLFVBQUMsTUFBTSxFQUFHLEVBQUU7Y0FBRSxPQUFPLHlEQUFHLFVBQUMsQ0FBQyxFQUFHLEVBQUU7Y0FDMUQsR0FBRzs7OztBQUFILG1CQUFHLHNCQUFvQixJQUFJLENBQUMsS0FBSzs7Z0RBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDOzs7Ozs7Ozs7O1NBQy9ELENBQUM7QUFDRixjQUFNOztBQUVSO0FBQ0UsY0FBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDOztBQUFBLEtBRTVDO0dBQ0Y7Ozs7Ozs7ZUExQlUsTUFBTTs7V0FnQ0o7OztVQUFDLFNBQVMseURBQUcsRUFBRTtVQUFFLE9BQU8seURBQUcsb0JBQU8sQ0FBQzs7Ozs7Ozs7T0FBTzs7VUFFakQsT0FBTyxFQVFQLEtBQUssa0ZBQ0EsTUFBTTs7Ozs7OztBQVRYLG1CQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRTs7O0FBRy9CLG1CQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUNuQixrQkFBSSxFQUFFLE1BQU07QUFDWixtQkFBSyxFQUFFLEVBQUU7YUFDVixDQUFDOztBQUVFLGlCQUFLLEdBQUcsRUFBRTs7Ozs7O0FBQ2QsNkJBQW1CLE9BQU8sQ0FBQyxPQUFPLHVIQUFFO0FBQTNCLG9CQUFNOztBQUNiLG1CQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHO0FBQ25CLHFCQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIscUJBQUssRUFBRSxDQUFDO2VBQ1QsQ0FBQzthQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUVLLElBQUksVUFBTyxDQUNmLG9CQUFPLE1BQU07dUdBQ0YsTUFBTSxFQUNULEtBQUssRUFDTCxJQUFJOzs7Ozs7Ozs7aUNBRlMsT0FBTyxDQUFDLE9BQU87Ozs7Ozs7O0FBQXpCLDBCQUFNO0FBQ1QseUJBQUssR0FBRyx5QkFBUSxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUN0Qyx3QkFBSSxHQUFHLHVCQUFNLEtBQUssQ0FBRTs7eUJBQ3BCLElBQUksQ0FBQyxNQUFNLENBQUM7Ozs7O0FBQ2QseUJBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7OzBCQUN2QixPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssV0FBVzs7Ozs7O29EQUN6QyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzthQUszQyxFQUNELE9BQU8sQ0FDUjs7O2dEQUdNLEtBQUs7Ozs7Ozs7S0FFYjs7O1NBdEVVLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkNmWixjQUFjOzt5QkFDSCxlQUFlOzs7OzRCQUcxQixlQUFlOztBQUV0QixJQUFNLE1BQU0sR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxRQUFRLEVBQUU7QUFDNUMsY0FBWSxFQUFFLE9BQU87Q0FDdEIsQ0FBQyxDQUFDOztJQUVVLFNBQVM7QUFJVCxXQUpBLFNBQVMsQ0FJUixPQUFPLEVBQUU7MEJBSlYsU0FBUzs7QUFLbEIsUUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7R0FDeEI7Ozs7Ozs7O2VBTlUsU0FBUzs7V0FhYixtQkFBRztBQUNSLGFBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7S0FDbEM7OztXQUVTLHNCQUFHO0FBQ1gsYUFBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0tBQ3JCOzs7V0FFTSxtQkFBNkQ7OztVQUE1RCxRQUFRLHlEQUFHLG9CQUFPLE1BQU07Ozs7Ozs7O09BQU87VUFBRSxPQUFPLHlEQUFHLG9CQUFPLENBQUM7Ozs7Ozs7O09BQU87S0FBSTs7O1NBckIzRCxTQUFTOzs7OztJQXlCVCxLQUFLO1lBQUwsS0FBSzs7QUFFTCxXQUZBLEtBQUssQ0FFSixPQUFPLEVBQUU7OzswQkFGVixLQUFLOztBQUlkLFFBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDM0IsU0FBRyxFQUFFLE9BQU87S0FDYixDQUFDLENBQUM7O0FBRUgsK0JBUlMsS0FBSyw2Q0FRUixPQUFPLEVBQUU7O0FBRWYsUUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDOztBQUUxQixZQUFRLElBQUksQ0FBQyxJQUFJO0FBQ2YsV0FBSyxPQUFPO0FBQ1YsWUFBSSxDQUFDLEtBQUssR0FBRywyQkFBVSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEMsWUFBSSxVQUFPLEdBQUcsb0JBQU8sR0FBRztjQUNsQixHQUFHOzs7O0FBQUgsbUJBQUcsc0JBQW9CLElBQUksQ0FBQyxLQUFLLGdCQUFZLEdBQUcsQ0FBQyxHQUFHLGFBQVMsR0FBRyxDQUFDLEVBQUU7O2dEQUMxRCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7Ozs7U0FDbkMsQ0FBQztBQUNGLGNBQU07QUFDUjtBQUNFLGNBQU0sSUFBSSxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUFBLEtBQ3pDO0dBRUY7Ozs7Ozs7ZUF4QlUsS0FBSzs7V0ErQlQsbUJBQTZEOzs7VUFBNUQsUUFBUSx5REFBRyxvQkFBTyxNQUFNOzs7Ozs7OztPQUFPO1VBQUUsT0FBTyx5REFBRyxvQkFBTyxDQUFDOzs7Ozs7OztPQUFPOztBQUVoRSxVQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ3BCLGVBQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUc7T0FDMUIsRUFBRTtBQUNELGNBQU0sRUFBRTtBQUNOLGFBQUcsRUFBRSxDQUFDO0FBQ04sWUFBRSxFQUFFLENBQUM7QUFDTCxhQUFHLEVBQUUsQ0FBQztTQUNQO09BQ0YsQ0FBQyxDQUFDOztBQUVILGFBQU8sSUFBSSxPQUFPLENBQ2hCLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSzs7QUFFbkIsV0FBRyxDQUFDLE9BQU8sQ0FDVCxvQkFBTyxHQUFHLEVBQUUsS0FBSztjQUVULE1BQU07Ozs7OztnREFBUyxJQUFJLFVBQU8sQ0FBQyxHQUFHLENBQUM7OztBQUEvQixzQkFBTTs7Z0RBQ0osUUFBUSxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7OztBQUV0Qix1QkFBTyxnQkFBRyxDQUFDOzs7QUFFYixvQkFBSSxLQUFLLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUM3Qix5QkFBTyxFQUFFLENBQUM7aUJBQ1g7Ozs7Ozs7U0FDRixDQUFDLENBQUM7T0FFTixDQUNGLFNBQU0sQ0FDTCxVQUFDLENBQUMsRUFBSztBQUNMLGNBQU0sQ0FBQyxDQUFDO09BQ1QsQ0FDRixDQUFDO0tBRUg7OztTQWxFVSxLQUFLO0dBQVMsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0NDckNsQiwwQkFBMEI7Ozs7SUFFL0IsUUFBUTs7Ozs7O0FBS1AsV0FMRCxRQUFRLENBS04sS0FBSyxFQUFFOzBCQUxULFFBQVE7O0FBTWpCLFFBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSztHQUNwQjs7ZUFQVSxRQUFROztXQVNELHFCQUFDLGNBQWM7VUFBRSxRQUFRLHlEQUFHLENBQUM7Ozs7OzRDQUN2QyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDM0IsbUJBQW1CLDBCQUNHLGNBQWMsRUFDcEMsRUFBRSxFQUFFO0FBQ0YsbUJBQUssRUFBRSxRQUFRO0FBQ2YsNkJBQWUsRUFBRSxDQUFDO0FBQ2xCLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7OzRDQUVLLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUMzQixtQkFBbUIsMEJBQ0csY0FBYyxFQUNwQyxFQUFFLEVBQUU7QUFDRixtQkFBSyxFQUFFLFFBQVE7QUFDZix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs7OztLQUNGOzs7V0FFc0IsMEJBQUMsSUFBSTtVQUN0QixTQUFTLEVBRVQsR0FBRyxFQUdILE1BQU0sRUFTTixLQUFLLGtGQXNCQSxNQUFNOzs7Ozs7O0FBcENYLHFCQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVU7QUFFM0IsZUFBRyxHQUFHLEVBQUU7O0FBR1Isa0JBQU0sR0FBRyxTQUFULE1BQU0sQ0FBVSxHQUFHO2tCQUNqQixHQUFHOzs7O0FBQUgsdUJBQUcsdUVBRWMsSUFBSSxDQUFDLFVBQVUsbUJBQWMsR0FBRztxQ0FFckQsR0FBRzs7b0RBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7O21DQUFqQyxJQUFJOzs7Ozs7O2FBQ1Q7O0FBR0csaUJBQUssR0FBRyxTQUFSLEtBQUssQ0FBVSxHQUFHO2tCQUVoQixHQUFHLEVBSUgsUUFBUTs7OztBQUpSLHVCQUFHLGdGQUVjLElBQUksQ0FBQyxVQUFVLG1CQUFjLEdBQUc7O29EQUVoQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUF2Qyw0QkFBUTs7eUJBQ1IsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQzs7Ozs7Ozs7cUNBRTNCLEdBQUc7O29EQUNLLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUMzQixpQkFBaUIsRUFDakIsRUFBRSxFQUNGO0FBQ0UsZ0NBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtBQUMzQix5QkFBRyxFQUFFLEdBQUc7QUFDUixnQ0FBVSxFQUFFLFNBQVM7QUFDckIsaUNBQVcsRUFBRSxPQUFPO3FCQUNyQixDQUNGOzs7O21DQVZDLElBQUk7Ozs7Ozs7YUFXVDs7Ozs7O3dCQUVrQixJQUFJLENBQUMsSUFBSTs7Ozs7Ozs7QUFBbkIsa0JBQU07NkJBQ0wsTUFBTSxDQUFDLEdBQUc7a0RBQ1gsSUFBSSwyQkFHSixLQUFLOzs7Ozs0Q0FGRixLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs0Q0FHakIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnREFLdkI7QUFDTCxpQkFBRyxFQUFFLEdBQUc7YUFDVDs7Ozs7OztLQUNGOzs7V0FFd0IsNEJBQUMsSUFBSTtVQUN4QixTQUFTLEVBQ1QsTUFBTSxFQUNOLFNBQVMsRUFFVCxHQUFHLEVBR0gsR0FBRyxFQUdFLENBQUM7Ozs7QUFWTixxQkFBUyxHQUFHLElBQUksQ0FBQyxVQUFVO0FBQzNCLGtCQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU07QUFDcEIscUJBQVMsR0FBRyxJQUFJLENBQUMsVUFBVTtBQUUzQixlQUFHLEdBQUcsRUFBRTtBQUdSLGVBQUcseURBQXVELFNBQVM7NkJBQ3ZFLEdBQUc7OzRDQUFZLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7OzsyQkFBakMsSUFBSTtBQUVDLGFBQUMsR0FBRyxDQUFDOzs7a0JBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNOzs7Ozs7NENBQ3pCLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUMzQixtQkFBbUIsRUFBRTtBQUNuQix3QkFBVSxFQUFFLFNBQVM7QUFDckIsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHVCQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQixrQkFBSSxFQUFFLENBQUMsR0FBRyxDQUFDO2FBQ1osRUFBRTtBQUNELHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFWZ0MsYUFBQyxFQUFFOzs7OztnREFhL0I7QUFDTCxpQkFBRyxFQUFFLEdBQUc7YUFDVDs7Ozs7OztLQUNGOzs7V0FFbUIsdUJBQUMsSUFBSTtVQUNuQixVQUFVLEVBQ1YsSUFBSSx1RkFvQ0MsQ0FBQyx1RkFJTixHQUFHOzs7OztBQXpDSCxzQkFBVSxHQUFHLEVBQUU7QUFDZixnQkFBSSxHQUFHLEVBQUU7Ozs7QUFJYixnQkFBSSxHQUFHLENBQ0wsUUFBUSxFQUNSLE1BQU0sRUFDTixNQUFNLEVBQ04sa0JBQWtCLEVBQ2xCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2IsV0FBVyxDQUNaOzs7OztBQUNELDhCQUFjLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFSyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDM0IsYUFBYSxvQkFDRyxJQUFJLENBQUMsVUFBVSxFQUMvQixVQUFVLEVBQUU7QUFDVix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs7O0FBSUQsc0JBQVUsR0FBRyxFQUFFO0FBQ2YsZ0JBQUksR0FBRyxDQUNMLGtCQUFrQixFQUNsQixjQUFjLEVBQ2QsWUFBWSxFQUNaLFNBQVMsRUFDVCxTQUFTLEVBQ1QsY0FBYyxDQUNmOzs7OztBQUNELDhCQUFjLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFZSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDckMsbUJBQW1CLG9CQUNILElBQUksQ0FBQyxVQUFVLEVBQy9CLFVBQVUsRUFBRTtBQUNWLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFORyxlQUFHO2dEQVFBO0FBQ0wsaUJBQUcsRUFBRSxHQUFHO2FBQ1Q7Ozs7Ozs7S0FDRjs7O1dBRW1CLHVCQUFDLElBQUk7VUFDbkIsU0FBUyxFQUVULEdBQUcsRUFFSCxVQUFVLEVBQ1YsSUFBSSx1RkErREMsQ0FBQzs7Ozs7QUFwRU4scUJBQVMsR0FBRyxJQUFJLENBQUMsVUFBVTtBQUUzQixlQUFHLEdBQUcsRUFBRTtBQUVSLHNCQUFVLEdBQUcsRUFBRTtBQUNmLGdCQUFJLEdBQUcsRUFBRTs7QUFFYixnQkFBSSxHQUFHLENBQ0wsTUFBTSxFQUNOLG9CQUFvQixDQUNyQjs7Ozs7Ozs7OztBQU1ELDhCQUFjLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFc0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQzVDLGFBQWEsRUFDYixVQUFVLEVBQUU7QUFDVix3QkFBVSxFQUFFLFNBQVM7QUFDckIsb0JBQU0sRUFBRSxDQUFDO0FBQ1Qsa0JBQUksRUFBRSxNQUFNO0FBQ1osOEJBQWdCLEVBQUUsTUFBTTtBQUN4Qix5QkFBVyxFQUFFLE1BQU07QUFDbkIsdUJBQVMsRUFBRSxNQUFNO0FBQ2pCLHlCQUFXLEVBQUUsT0FBTztBQUNwQix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBWkQsZUFBRyxDQUFDLFVBQVU7O0FBY2Qsc0JBQVUsR0FBRyxFQUFFO0FBQ2YsZ0JBQUksR0FBRyxDQUNMLGNBQWMsRUFDZCxpQkFBaUIsRUFDakIsU0FBUyxFQUNULFNBQVMsRUFDVCxjQUFjLENBQ2Y7Ozs7Ozs7Ozs7O0FBT0QsOEJBQWMsSUFBSSwySEFBRTtBQUFYLGVBQUM7O0FBQ1Isa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3JDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUU0QixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDbEQsbUJBQW1CLEVBQ25CLFVBQVUsRUFBRTtBQUNWLHdCQUFVLEVBQUUsU0FBUztBQUNyQix3QkFBVSxFQUFFLEdBQUcsQ0FBQyxVQUFVO0FBQzFCLG1CQUFLLEVBQUUsQ0FBQztBQUNSLDZCQUFlLEVBQUUsQ0FBQztBQUNsQixnQ0FBa0IsRUFBRSxNQUFNO0FBQzFCLGdDQUFrQixFQUFFLE1BQU07QUFDMUIsOEJBQWdCLEVBQUUsTUFBTTtBQUN4Qix3QkFBVSxFQUFFLE1BQU07QUFDbEIseUJBQVcsRUFBRSxPQUFPO0FBQ3BCLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFkRCxlQUFHLENBQUMsZ0JBQWdCOzs7Ozs7QUFnQnBCLDhCQUFjLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFNEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQ2xELG1CQUFtQixFQUFFLEVBQUUsRUFBRTtBQUN2Qiw4QkFBZ0IsRUFBRSxHQUFHLENBQUMsZ0JBQWdCO0FBQ3RDLHdCQUFVLEVBQUUsU0FBUztBQUNyQixtQkFBSyxFQUFFLENBQUM7QUFDUix5QkFBVyxFQUFFLE9BQU87QUFDcEIseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQVJELGVBQUcsQ0FBQyxnQkFBZ0I7Z0RBV2I7QUFDTCxpQkFBRyxFQUFFLEdBQUc7YUFDVDs7Ozs7OztLQUNGOzs7U0E5UFUsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkNGSCxlQUFlOzs7O3VCQUNQLFNBQVM7OzhCQUNmLGlCQUFpQjs7Ozs7O29CQUdwQixNQUFNOzs7OzJCQUNILGFBQWE7Ozs7cUJBQ1YsUUFBUTs7SUFFbEIsZUFBZSxHQUNkLFNBREQsZUFBZSxDQUNiLElBQUksRUFBRSxPQUFPLEVBQUU7d0JBRGpCLGVBQWU7O0FBRXhCLE1BQUksUUFBUTtBQUNaLFVBQVEsSUFBSSxDQUFDLElBQUk7QUFDZixTQUFLLE9BQU87QUFDVixjQUFRLEdBQUcsSUFBSSxhQUFhLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQztBQUFBLEdBQzlDOztBQUVELFNBQU8sUUFBUTtDQUNoQjs7OztJQUdVLFFBQVE7QUFDUCxXQURELFFBQVEsQ0FDTixJQUFJLEVBQUUsT0FBTyxFQUFFOzBCQURqQixRQUFROztBQUVqQixRQUFJLENBQUMsSUFBSSxHQUFHLElBQUk7QUFDaEIsUUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPO0dBQ3ZCOztlQUpVLFFBQVE7O1dBZVYsb0JBQUc7QUFDVixhQUFPLElBQUksQ0FBQyxJQUFJO0tBQ2pCOzs7V0FFUSxvQkFBRztBQUNWLGFBQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJO0tBQ3RCOzs7V0FFVyx1QkFBRztBQUNiLGFBQU8sSUFBSSxDQUFDLE9BQU87S0FDcEI7OztXQUVrQiw4QkFFakI7OztVQURBLEVBQUUseURBQUc7WUFBTyxRQUFRLHlEQUFHLGdCQUFNLEVBQUksRUFBRTtZQUFFLE9BQU8seURBQUcsV0FBQyxFQUFJLEVBQUU7Ozs7Ozs7O09BQU87O0FBRTdELFVBQUksVUFBTyxHQUFHLEVBQUU7S0FDakI7Ozs7Ozs7Ozs7Ozs7V0FXYTtVQUFDLFNBQVMseURBQUcsRUFBRTs7VUFDdkIsT0FBTyxFQVFQLE9BQU8sa0ZBTUYsQ0FBQyxFQUZOLE9BQU87Ozs7Ozs7QUFaUCxtQkFBTyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUU7OztBQUdoQyxtQkFBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDbkIsa0JBQUksRUFBRSxNQUFNO0FBQ1osbUJBQUssRUFBRSxFQUFFO2FBQ1YsQ0FBQzs7QUFFRSxtQkFBTyxHQUFHLEVBQUU7Ozs7OztBQUNoQiw2QkFBYyxPQUFPLENBQUMsT0FBTyx1SEFBRTtBQUF0QixlQUFDO2FBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVHLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBRWhCLDhCQUFjLE9BQU8sQ0FBQyxPQUFPLDJIQUFFO0FBQXRCLGVBQUM7O0FBQ1IscUJBQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFDaEIscUJBQUssRUFBRSxDQUFDLENBQUMsS0FBSztBQUNkLHFCQUFLLEVBQUUsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLFdBQVcsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUM7QUFDbkQscUJBQUssRUFBRSxDQUFDO2VBQ1Q7QUFDRCxxQkFBTyxDQUFDLElBQUksQ0FDVjtBQUNFLG9CQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7QUFDWixvQkFBSSxFQUFFLHVCQUFLLHlCQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7ZUFDdEMsQ0FDRjthQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUVLLElBQUksVUFBTyxDQUNmLG9CQUFPLE1BQU0sRUFBRSxPQUFPO3VHQUNYLENBQUMsRUFFSixDQUFDOzs7Ozs7Ozs7aUNBRk8sT0FBTzs7Ozs7Ozs7QUFBWixxQkFBQztBQUVKLHFCQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7O3lCQUNuQixDQUFDLENBQUMsS0FBSzs7Ozs7MEJBQ0wsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSzs7Ozs7Ozs7eUJBS3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDOzs7Ozs7QUFFaEIscUJBQUMsQ0FBQyxLQUFLLEVBQUU7Ozs7MEJBR0wsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLFdBQVc7Ozs7OztvREFDcEMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2FBSy9DLENBQUM7OztnREFHRyxPQUFPOzs7Ozs7O0tBQ2Y7OztXQTNGYyxpQkFBQyxJQUFJLEVBQUUsT0FBTyxFQUFFO0FBQzdCLGNBQVEsSUFBSSxDQUFDLElBQUk7QUFDZixhQUFLLE9BQU87QUFDVixpQkFBTyxJQUFJLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO0FBQ3pDO0FBQ0UsZ0JBQU0sSUFBSSxLQUFLLENBQUMsbUJBQW1CLENBQUM7QUFBQSxPQUN2QztLQUNGOzs7U0FiVSxRQUFROzs7OztJQW9HUixhQUFhO1lBQWIsYUFBYTs7QUFDWixXQURELGFBQWEsQ0FDWCxJQUFJLEVBQUUsT0FBTyxFQUFFOzs7MEJBRGpCLGFBQWE7O0FBRXRCLCtCQUZTLGFBQWEsNkNBRWhCLElBQUksRUFBRSxPQUFPLEVBQUM7O0FBRXBCLFFBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUU7O0FBRTFCLFFBQUksQ0FBQyxLQUFLLEdBQUcsMkJBQVUsSUFBSSxDQUFDO0FBQzVCLFFBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBTyxRQUFRLEVBQUUsT0FBTztVQUMxQyxHQUFHLEVBQ0gsR0FBRzs7OztBQURILGVBQUcsc0JBQW9CLElBQUksQ0FBQyxLQUFLOzs0Q0FDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxVQUFDLENBQUMsRUFBSztBQUFFLG9CQUFNLENBQUM7YUFBRSxDQUFDOzs7QUFBeEUsZUFBRztnREFDQSxHQUFHOzs7Ozs7O0tBQ1gsQ0FBQztHQUNIOzs7Ozs7U0FaVSxhQUFhO0dBQVMsUUFBUTs7OztJQW1COUIsYUFBYTtZQUFiLGFBQWE7O0FBQ1osV0FERCxhQUFhLENBQ1gsSUFBSSxFQUFFLE9BQU8sRUFBRTs7OzBCQURqQixhQUFhOztBQUV0QiwrQkFGUyxhQUFhLDZDQUVoQixJQUFJLEVBQUUsT0FBTyxFQUFDOzs7QUFHcEIsUUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFPLFFBQVEsRUFBRSxPQUFPO1VBQzFDLE1BQU0sRUFJTixFQUFFLEVBQ0YsVUFBVSxFQUVWLE9BQU8sRUFNUCxHQUFHLEVBUUMsR0FBRzs7OztBQXJCUCxrQkFBTTs7NENBQ0sscUJBQVksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUE1QyxrQkFBTTtBQUdGLGNBQUUsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDN0Isc0JBQVUsR0FBRyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7QUFFM0MsbUJBQU8sR0FBRztBQUNaLG9CQUFNLEVBQUUsTUFBTTtBQUNkLHdCQUFVLEVBQUUsVUFBVTtBQUN0QixzQkFBUSxFQUFFLEVBQUU7YUFDYjtBQUVHLGVBQUcsR0FBRyxVQUFVLENBQUMsSUFBSSxFQUFFOzs7QUFHM0IsZUFBRyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUM7Ozs7Ozs7NENBSTNCLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Ozs0Q0FDUixHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdEIsZUFBRzs7NENBQ0QsUUFBUSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUM7Ozs7Ozs7QUFDN0IsYUFBQzs7Ozs7NENBR0ksR0FBRyxDQUFDLEtBQUssRUFBRTs7Ozs7Ozs7OztLQUVwQixDQUFDO0dBQ0g7O1NBbkNVLGFBQWE7R0FBUyxRQUFROzs7O0lBc0M5QixrQkFBa0I7WUFBbEIsa0JBQWtCOztBQUNqQixXQURELGtCQUFrQixDQUNoQixJQUFJLEVBQUUsT0FBTyxFQUFFOzs7MEJBRGpCLGtCQUFrQjs7QUFFM0IsK0JBRlMsa0JBQWtCLDZDQUVyQixJQUFJLEVBQUUsT0FBTyxFQUFDOzs7QUFHcEIsUUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFPLFFBQVEsRUFBRSxPQUFPO1VBRTFDLE9BQU8sRUFFUCxPQUFPLEVBTUwsR0FBRyxFQUdILFFBQVEsRUFDUixXQUFXLEVBQ1gsVUFBVSxFQUNWLFlBQVksRUFLTCxDQUFDLEVBUVIsSUFBSTs7OztBQTNCTixtQkFBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs7QUFDOUMsbUJBQU8sQ0FBQyxHQUFHLEdBQU0sT0FBTyxDQUFDLEdBQUcsa0JBQWU7QUFDdkMsbUJBQU8sR0FBRztBQUNaLHFCQUFPLEVBQUUsT0FBTzthQUNqQjs7O2lCQUVNLENBQUM7Ozs7Ozs0Q0FFVSxpQ0FBUSxPQUFPLENBQUM7OztBQUE1QixlQUFHOztBQUNQLGVBQUcsR0FBRyxtQkFBTyxHQUFHLEVBQUUsRUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUM7O0FBRTlCLG9CQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7QUFDM0QsdUJBQVcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztBQUNqRSxzQkFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO0FBQy9ELHdCQUFZLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsWUFBWTs7a0JBR3JELFlBQVksWUFBWSxLQUFLOzs7OztBQUV0QixhQUFDLEdBQUcsQ0FBQzs7O2tCQUFFLENBQUMsR0FBRyxXQUFXOzs7Ozs7NENBQ3ZCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDOzs7QUFEVCxhQUFDLEVBQUU7Ozs7Ozs7Ozs7NENBSzlCLFFBQVEsQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDOzs7QUFHbkMsZ0JBQUksR0FBRyxVQUFVLEdBQUcsV0FBVzs7a0JBRS9CLElBQUksR0FBRyxRQUFROzs7Ozs7OztBQUNuQixtQkFBTyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEdBQUcsSUFBSTs7Ozs7Ozs7O0tBRS9CLENBQUM7R0FDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7U0F4Q1Usa0JBQWtCO0dBQVMsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkNsTGhCLGVBQWU7OzJCQUNWLGdCQUFnQjs7d0JBQ2hDLGNBQWM7Ozs7SUFFZCxjQUFjO1dBQWQsY0FBYzswQkFBZCxjQUFjOzs7ZUFBZCxjQUFjOzs7Ozs7O1dBS3RCLGNBQUMsSUFBSTs7Ozs7NENBQ0ssMkJBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDOzs7QUFBckQsZ0JBQUksQ0FBQyxLQUFLOzs0Q0FDWSwyQkFBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUM7OztBQUEzRCxnQkFBSSxDQUFDLFFBQVE7Ozs7Ozs7S0FDZDs7O1dBRWMsa0JBQUMsTUFBTTtVQUNoQixJQUFJLEVBT0osVUFBVSxFQVFWLFVBQVUsa0ZBRUwsVUFBVSxFQUNiLFdBQVcsdUZBRU4sRUFBRSxFQUNMLE9BQU8sRUFPUCxVQUFVLHVGQUdMLEtBQUssRUFVZCxRQUFROzs7Ozs7NENBekNLLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ2xDLGlCQUFHLEVBQUUsTUFBTTthQUNaLEVBQUU7QUFDRCx3QkFBVSxFQUFFO0FBQ1YseUJBQVMsRUFBRSxDQUFDO2VBQ2I7YUFDRixDQUFDOzs7QUFORSxnQkFBSTtBQU9KLHNCQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU87QUFRekIsc0JBQVUsR0FBRyxFQUFFOzs7Ozt3QkFFSSxVQUFVOzs7Ozs7OztBQUF4QixzQkFBVTtBQUNiLHVCQUFXLEdBQUcsQ0FBQzs7Ozs7eUJBRUosVUFBVSxDQUFDLEdBQUc7Ozs7Ozs7O0FBQXBCLGNBQUU7OzRDQUNXLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO0FBQ3hDLGlCQUFHLEVBQUUsRUFBRTthQUNSLEVBQUU7QUFDRCx3QkFBVSxFQUFFO0FBQ1YsdUJBQU8sRUFBRSxDQUFDO2VBQ1g7YUFDRixDQUFDOzs7QUFORSxtQkFBTztBQU9QLHNCQUFVLEdBQUcsT0FBTyxDQUFDLEtBQUs7Ozs7Ozs7QUFHOUIsOEJBQWtCLFVBQVUsMkhBQUU7QUFBckIsbUJBQUs7O0FBQ1oseUJBQVcsSUFBSSxLQUFLLENBQUMsUUFBUTthQUM5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUlILHNCQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSXZELG9CQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQztnREFFeEMsUUFBUTs7Ozs7OztLQUNoQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztXQXVCYyxrQkFBQyxRQUFRLEVBQUUsS0FBSztVQUFFLE1BQU0seURBQUcsSUFBSTtVQUFFLE1BQU0seURBQUcsSUFBSTtVQUV2RCxNQUFNLEVBS04sTUFBTSxFQUtOLEdBQUc7Ozs7QUFWSCxrQkFBTSxHQUFHLHFCQUFRLElBQUksQ0FBQztBQUN4QixzQkFBUSxFQUFFLFFBQVE7YUFDbkIsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxVQUFDLENBQUM7cUJBQUssQ0FBQyxDQUFDLGdCQUFnQjthQUFBLENBQUM7QUFHckMsa0JBQU0sR0FBRyxFQUFFOztBQUNmLGtCQUFNLENBQUMsS0FBSyxHQUFHLEtBQUs7QUFDcEIsZ0JBQUksTUFBTSxFQUFFLE1BQU0sQ0FBQyxZQUFZLEdBQUcsTUFBTTtBQUN4QyxnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNOzs7NENBRXhCLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUNuQyxNQUFNLEVBQUU7QUFDTixtQkFBSyxFQUFFO0FBQ0wsc0JBQU0sRUFBRTtBQUNOLHVCQUFLLEVBQUUsTUFBTTtpQkFDZDtlQUNGO2FBQ0YsQ0FDRjs7O0FBUkcsZUFBRztnREFXQSxNQUFNOzs7Ozs7O0tBQ2Q7Ozs7Ozs7Ozs7OztXQVVnQixvQkFBQyxLQUFLO1VBQUUsTUFBTSx5REFBRyxJQUFJO1VBQUUsTUFBTSx5REFBRyxJQUFJO1VBRS9DLE1BQU0sRUFLTixHQUFHOzs7O0FBTEgsa0JBQU0sR0FBRyxFQUFFOztBQUNmLGtCQUFNLENBQUMsS0FBSyxHQUFHLEtBQUs7QUFDcEIsZ0JBQUksTUFBTSxFQUFFLE1BQU0sQ0FBQyxZQUFZLEdBQUcsTUFBTTtBQUN4QyxnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNOzs7NENBRXhCLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUNuQyxNQUFNLEVBQUU7QUFDTixrQkFBSSxFQUFFO0FBQ0osc0JBQU0sRUFBRSxFQUFFO2VBQ1g7YUFDRixDQUNGOzs7QUFORyxlQUFHOzs7Ozs7O0tBT1I7Ozs7Ozs7Ozs7Ozs7Ozs7OztXQWdCa0Isc0JBQUMsSUFBSSxFQUFFLE9BQU87VUFTM0IsR0FBRyxFQW1DSCxLQUFLLHVGQUVBLENBQUMsdUZBc0JELElBQUksdUZBQ0YsQ0FBQzs7Ozs7QUE1RFIsZUFBRyxHQUFHLENBQUM7QUFDVCxtQkFBSyxFQUFFLE1BQU07QUFDYixxQkFBTyxFQUFFLElBQUksQ0FBQyxRQUFRO0FBQ3RCLHFCQUFPLEVBQUU7QUFDUCxxQkFBSyxFQUFFLFdBQVc7ZUFDbkI7QUFDRCxtQkFBSyxFQUFFO0FBQ0wsNEJBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtBQUMvQiw0QkFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO2VBQ2hDO2FBQ0YsRUFDRDtBQUNFLG1CQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVc7QUFDdkIscUJBQU8sRUFBRSxJQUFJLENBQUMsWUFBWTtBQUMxQixxQkFBTyxFQUFFO0FBQ1AscUJBQUssRUFBRSxlQUFlO2VBQ3ZCO0FBQ0QsbUJBQUssRUFBRTtBQUNMLHdCQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7QUFDdkIsNEJBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtlQUNoQzthQUNGLEVBQ0Q7QUFDRSxtQkFBSyxFQUFFLElBQUksQ0FBQyxXQUFXO0FBQ3ZCLHFCQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVk7QUFDMUIscUJBQU8sRUFBRTtBQUNQLHFCQUFLLEVBQUUsZUFBZTtlQUN2QjtBQUNELG1CQUFLLEVBQUU7QUFDTCx3QkFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO0FBQ3ZCLDRCQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7ZUFDaEM7YUFDRixDQUNBO0FBRUcsaUJBQUssR0FBRyxFQUFFOzs7Ozt5QkFFQSxHQUFHOzs7Ozs7OztBQUFSLGFBQUM7NkJBQ1IsS0FBSzs7NENBQ2UsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQ3BDLENBQUM7QUFDQyxvQkFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtBQUM3QixxQkFBSyxFQUFFLElBQUksQ0FBQyxLQUFLO2VBQ2xCLENBQUM7YUFDSCxFQUNEO0FBQ0Usc0JBQVEsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO2FBQzVDLEVBQ0Q7QUFDRSxtQkFBSyxFQUFFO0FBQ0wsbUJBQUcsRUFBRSxDQUFDO2VBQ1A7YUFDRixDQUNBLENBQ0YsQ0FBQyxPQUFPLEVBQUU7Ozs7NkJBQ0osQ0FBQzs7QUFoQlIsd0JBQVU7QUFnQlYsbUJBQUs7OzJCQWpCRCxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQXFCSyxLQUFLOzs7Ozs7OztBQUFiLGdCQUFJOzs7Ozt5QkFDRyxJQUFJLENBQUMsVUFBVTs7Ozs7Ozs7QUFBcEIsYUFBQzs7NENBQ1EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDOzs7QUFBcEMsYUFBQyxDQUFDLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnREFJSixLQUFLOzs7Ozs7O0tBQ2I7Ozs7OztXQUltQix1QkFBQyxHQUFHO1VBQ2xCLElBQUksRUFHRixHQUFHLEVBQ0gsR0FBRyxFQVdDLEtBQUssRUFlWCxVQUFVOzs7O0FBOUJWLGdCQUFJOztrQkFFSixPQUFPLEdBQUcsS0FBSyxRQUFROzs7OztBQUNyQixlQUFHLEdBQUcsSUFBSSxNQUFNLENBQUksR0FBRyxPQUFJO0FBQzNCLGVBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUU7QUFDNUIsd0JBQVUsRUFBRTtBQUNWLHFCQUFLLEVBQUUsQ0FBQztBQUNSLDRCQUFZLEVBQUUsQ0FBQztBQUNmLDRCQUFZLEVBQUUsQ0FBQztlQUNoQjthQUNGLENBQUM7OztpQkFFSyxDQUFDOzs7Ozs7OzRDQUVTLEdBQUcsQ0FBQyxJQUFJLEVBQUU7OztBQUF2QixnQkFBSTs7NENBQ2MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBL0MsaUJBQUs7O2lCQUNMLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLVCxlQUFHLENBQUMsS0FBSyxFQUFFO2dEQUNKLEdBQUc7Ozs7Ozs7QUFHZCxlQUFHLENBQUMsS0FBSyxFQUFFOzs7OztBQUVYLGdCQUFJLEdBQUcsR0FBRzs7O0FBR1Isc0JBQVUsR0FBRyxFQUFFOztBQUNuQixnQkFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUMzQyxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztBQUN6RCxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnREFDbEQsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7S0FDNUI7OztXQUVzQiwwQkFBQyxTQUFTLEVBQUUsSUFBSTtVQUVqQyxTQUFTLEVBR1QsU0FBUyxFQUNULFVBQVUsRUFTVixhQUFhLEVBY2IsSUFBSSxFQXVCSixXQUFXLEVBY1gsS0FBSyxFQXFCTCxhQUFhLEVBMkJiLGlCQUFpQixFQU1qQixJQUFJOzs7O0FBdEhKLHFCQUFTLEdBQUcsU0FBWixTQUFTLENBQUksUUFBUTtxQkFBSyxRQUFRLEtBQUssUUFBUSxHQUFHLE9BQU8sR0FBRyxRQUFRO2FBQUE7O0FBR3BFLHFCQUFTLEdBQUcsSUFBSTtBQUNoQixzQkFBVSxHQUFHLEVBQUU7Ozs7QUFJbkIsZ0JBQUksSUFBSSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDM0MsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7QUFDekQsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7OztBQUdyRCx5QkFBYTs2QkFDVCxJQUFJLENBQUMsUUFBUTtrREFDZCxLQUFLLDJCQUdMLFFBQVE7Ozs7QUFGWCx5QkFBYSxHQUFHLENBQUM7Ozs7QUFHakIseUJBQWEsR0FBRyxDQUFDOzs7O0FBR2pCLHlCQUFhLEdBQUcsQ0FBQzs7OztBQUtqQixnQkFBSSxHQUFHLEVBQUU7NkJBQ0wsSUFBSSxDQUFDLFFBQVE7a0RBQ2QsS0FBSywyQkFTTCxRQUFROzs7O0FBUlgsZ0JBQUksQ0FBQyxJQUFJLENBQUM7QUFDUixpQkFBRyxFQUFFLENBQUM7QUFDTixpQkFBRyxFQUFFLElBQUk7YUFDVixFQUFFO0FBQ0QsaUJBQUcsRUFBRSxDQUFDO0FBQ04saUJBQUcsRUFBRSxLQUFLO2FBQ1gsQ0FBQzs7OztBQUdGLGdCQUFJLENBQUMsSUFBSSxDQUFDO0FBQ1IsaUJBQUcsRUFBRSxDQUFDO0FBQ04saUJBQUcsRUFBRSxJQUFJO2FBQ1YsRUFBRTtBQUNELGlCQUFHLEVBQUUsQ0FBQztBQUNOLGlCQUFHLEVBQUUsS0FBSzthQUNYLENBQUM7Ozs7QUFLRix1QkFBVyxHQUFHLElBQUk7NkJBQ2QsSUFBSSxDQUFDLFFBQVE7a0RBQ2QsS0FBSywyQkFHTCxRQUFROzs7O0FBRlgsdUJBQVcsR0FBRyxJQUFJOzs7O0FBR2xCLHVCQUFXLEdBQUcsR0FBRzs7Ozs7NENBUUgsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUU7QUFDeEMsd0JBQVUsRUFBRSw4QkFBOEI7YUFDM0MsQ0FBQzs7O0FBRkUsaUJBQUs7Ozs7O0FBT1QsaUJBQUssR0FBRyxLQUFLLENBQUMsR0FBRyxDQUNmLFVBQUMsSUFBSSxFQUFLO0FBQ1Isa0JBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNsRCxrQkFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FDbkMsVUFBQyxTQUFTLEVBQUs7QUFDYix5QkFBUyxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztBQUM1Qyx1QkFBTyxTQUFTO2VBQ2pCLENBQ0Y7QUFDRCxxQkFBTyxJQUFJO2FBQ1osQ0FDRjs7O0FBR0cseUJBQWEsR0FDZixLQUFLLENBQUMsR0FBRyxDQUNQLFVBQUMsSUFBSTtxQkFDSCwrQkFBK0Isc0JBQ2Qsb0VBQzhDLGlCQUN0RCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssZUFBVyxXQUM5QixHQUNSLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUNqQixVQUFDLFNBQVMsRUFBSztBQUNiLG9CQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFNBQVMsQ0FBQyxLQUFLLEVBQUU7O0FBRTFDLG1HQUErRSxTQUFTLENBQUMsS0FBSyx3QkFBb0I7aUJBQ25ILE1BQ0QsSUFBSSxTQUFTLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTs7QUFFdkIsd0RBQW9DLFNBQVMsQ0FBQyxVQUFVLHVFQUFrRSxTQUFTLENBQUMsS0FBSyxtQkFBZTtpQkFDekosTUFBTTs7QUFFTCx1SkFBbUksU0FBUyxDQUFDLEtBQUssZUFBVztpQkFDOUo7ZUFDRixDQUNGLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUNWLFFBQVEsR0FDUixRQUFRO2FBQUEsQ0FDVCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFFUiw2QkFBaUIsOERBRW5CLGFBQWE7QUFJWCxnQkFBSSxHQUFHO0FBQ1Qsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHdCQUFVLEVBQUUsU0FBUztBQUNyQixrQkFBSSxFQUFLLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBSSxJQUFJLENBQUMsSUFBSSxJQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFFO0FBQ25ILGdDQUFrQixFQUFFLGlCQUFpQjs7QUFFckMsMEJBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNsQyxxQkFBTyxFQUFFLElBQUksQ0FBQyxZQUFZOzs7QUFHMUIsNkJBQWUsRUFBRSxhQUFhO0FBQzlCLGtCQUFJLEVBQUUsSUFBSTtBQUNWLDBCQUFZLEVBQUUsV0FBVzthQUMxQjs2QkFFRCxNQUFNOzZCQUFRLElBQUk7OzRDQUFRLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxJQUFJLENBQUM7Ozs7MkJBQTVELE1BQU07NkJBQ2IsTUFBTTs2QkFBUSxJQUFJOzs0Q0FBUSxJQUFJLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDOzs7OzJCQUEzRCxNQUFNOzZCQUNiLE1BQU07OEJBQVEsSUFBSTs7NENBQVEsSUFBSSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQzs7OzsyQkFBMUQsTUFBTTs7QUFFYixrQkFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7O2dEQUVuQyxJQUFJOzs7Ozs7O0tBQ1o7OztXQUVvQyx3Q0FBQyxJQUFJO1VBQ3BDLFFBQVEsRUFJSCxDQUFDOzs7O0FBSk4sb0JBQVEsR0FBRyxFQUFFOzs7QUFFakIsb0JBQVEsSUFBSSxJQUFJLENBQUMsV0FBVzs7QUFFNUIsaUJBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDM0Msc0JBQVEsc0NBQW9DLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVE7YUFDbkU7O0FBRUQsb0JBQVEsSUFBSSxHQUFHO2dEQUNSLEVBQUMsU0FBUyxFQUFFLFFBQVEsRUFBQzs7Ozs7OztLQUM3Qjs7O1dBRW1DLHVDQUFDLElBQUk7Ozs7Z0RBRWhDLEVBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBQzs7Ozs7OztLQUM5Qzs7O1dBRWtDLHNDQUFDLElBQUk7VUFFbEMsR0FBRzs7OztBQUFILGVBQUcsR0FBRyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxHQUFHLEVBQUUsR0FBRyxDQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUU7Z0RBQ2xFLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRTs7Ozs7OztLQUN2Qjs7Ozs7V0FHdUIsMkJBQUMsTUFBTSxFQUFFLElBQUk7VUFDN0IsR0FBRzs7Ozs7NENBQVMsSUFBSSxDQUFDLGdCQUFnQixDQUFDLE1BQU0sV0FBUSxFQUFFLElBQUksQ0FBQzs7O0FBQXZELGVBQUc7Z0RBQ0YsR0FBRzs7Ozs7OztLQUNYOzs7OztXQUdzQiwwQkFBQyxHQUFHLEVBQUUsSUFBSTtVQUN6QixRQUFRLEVBQ1IsV0FBVyxFQUViLEtBQUssRUFLSCxTQUFTLEVBQ04sQ0FBQzs7OztBQVRKLG9CQUFRLEdBQUcsRUFBRTtBQUNiLHVCQUFXLEdBQUcsR0FBRztBQUVuQixpQkFBSyxHQUFHLEVBQUU7OztBQUVkLGlCQUFLLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzs7O0FBR2hELHFCQUFTLEdBQUcsSUFBSTs7QUFDdEIsaUJBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDM0MsbUJBQUssQ0FBQyxTQUFTLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7YUFDNUM7OztBQUdELGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsUUFBUTs7OzRDQUNFLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDOzs7Ozs2QkFBSSxJQUFJLENBQUMsUUFBUTs7OzZCQUFJLElBQUksQ0FBQyxJQUFJOzs2QkFBSSxXQUFXO0FBQS9HLGlCQUFLLENBQUMsTUFBTSxDQUFDLGtCQUFZLE9BQU87O0FBQ2hDLGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVc7QUFDaEMsaUJBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVztBQUNoQyxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFLENBQUMsS0FBSyxDQUFDLENBQUMsUUFBUSxDQUFDO0FBQ3ZELGdCQUFJLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLFFBQVEsRUFBRTtBQUNuQyxtQkFBSyxDQUFDLElBQUksQ0FBQyxHQUFNLElBQUksQ0FBQyxXQUFXLGdCQUFXLEtBQUssQ0FBQyxJQUFJLENBQUc7YUFDMUQsTUFBTTtBQUNMLG1CQUFLLENBQUMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVc7YUFDL0I7QUFDRCxpQkFBSyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVE7O2dEQUVoQyxLQUFLOzs7Ozs7O0tBQ2I7OztXQUUwQyw4Q0FBQyxRQUFRO1VBQzlDLEVBQUUsRUFDRixHQUFHLEVBQ0gsT0FBTyxFQU1QLElBQUksRUF1QkosV0FBVyx1RkFDTixHQUFHLEVBR1IsY0FBYyxFQUNULENBQUMsRUFDSixHQUFFOzs7OztBQXJDSixjQUFFLEdBQUcscUJBQXFCO0FBQzFCLGVBQUcsR0FBRyxVQUFVO0FBQ2hCLG1CQUFPLEdBQUc7QUFDWixzQkFBUSxFQUFFLENBQUMsTUFBTSxDQUFDO0FBQ2xCLG1CQUFLLEVBQUUsQ0FBQyxTQUFTLEVBQUUsVUFBVSxDQUFDO2FBQy9COzs0Q0FHZ0IsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQ25DLENBQ0U7QUFDRSxvQkFBTSxzQkFDSCxFQUFFLEVBQUcsUUFBUSxDQUNmO2FBQ0YsRUFDRDtBQUNFLG9CQUFNO0FBQ0osbUJBQUcsUUFBTSxFQUFJO2lCQUNaLEdBQUcsRUFBRyxFQUFFLFNBQVMsUUFBTSxHQUFLLEVBQUUsQ0FDaEM7YUFDRixFQUNEO0FBQ0Usc0JBQVE7QUFDTixtQkFBRyxFQUFFLENBQUM7QUFDTix3QkFBUSxFQUFFLE1BQU07aUJBQ2YsR0FBRyxRQUFPLEdBQUcsQ0FDZjthQUNGLENBQ0YsQ0FDRixDQUFDLE9BQU8sRUFBRTs7O0FBckJQLGdCQUFJO0FBdUJKLHVCQUFXLEdBQUcsRUFBRTs7Ozs7O0FBQ3BCLDhCQUFnQixJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSwySEFBRTtBQUF6QixpQkFBRzs7QUFDVix5QkFBVyxHQUFHLFdBQVcsQ0FBQyxNQUFNLENBQUMsT0FBTyxNQUFJLEdBQUcsQ0FBRyxDQUFDO2FBQ3BEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNHLDBCQUFjLEdBQUcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOztBQUNqQyxpQkFBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQzFDLGlCQUFFLEdBQUcsT0FBTyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxHQUFHLE1BQU0sR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDOztBQUN4RSw0QkFBYyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUMsaUJBQWlCLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxnQkFBZ0IsRUFBRSxHQUFFLEVBQUM7YUFDckU7O2dEQUVNLEVBQUMsY0FBYyxFQUFFLGNBQWMsRUFBQzs7Ozs7OztLQUN4Qzs7Ozs7Ozs7V0FNNkIsZ0NBQUMsSUFBSSxFQUFFO0FBQ25DLGFBQU87QUFDTCxtQkFBVyxFQUFFLEdBQUc7QUFDaEIsZ0JBQVEsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtBQUNoQyxjQUFNLEVBQUUsSUFBSTtBQUNaLGFBQUssT0FBSyxJQUFJLENBQUMsS0FBSyxJQUFHLElBQUksQ0FBQyxZQUFZLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFlBQVksS0FBRyxJQUFJLENBQUMsWUFBWSxLQUFLLEVBQUUsR0FBRyxFQUFFLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUU7QUFDMUksWUFBSSxFQUFFLElBQUk7T0FDWDtLQUNGOzs7Ozs7OztXQU0rQixrQ0FBQyxJQUFJLEVBQUU7QUFDckMsVUFBSSxNQUFNLEdBQUc7QUFDWCxtQkFBVyxFQUFFLEdBQUc7QUFDaEIsZ0JBQVEsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtBQUNoQyxjQUFNLEVBQUUsSUFBSTtBQUNaLGdCQUFRLEVBQUUsSUFBSTtBQUNkLGtCQUFVLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7T0FDbkM7O0FBRUQsVUFBTSxLQUFLLEdBQUcseUJBQVksSUFBSSxFQUFFOztBQUVoQyxXQUFLLENBQUMsT0FBTyxDQUNYLFVBQUMsR0FBRyxFQUFFLEtBQUssRUFBSztBQUNkLFlBQUksS0FBSztZQUFFLE1BQU07WUFBRSxNQUFNO0FBQ3pCLFlBQUk7O0FBRUYsZUFBSyxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksR0FBRyxDQUFDLElBQUksQ0FBRyxNQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUc7QUFDcEQsZUFBSyxHQUFHLE9BQU8sS0FBSyxLQUFLLFdBQVcsR0FBRyxFQUFFLEdBQUcsS0FBSztBQUNqRCxnQkFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksR0FBRyxDQUFDLElBQUksQ0FBRyxNQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUc7QUFDdEQsZ0JBQU0sR0FBRyxPQUFPLE1BQU0sS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHLE1BQU07QUFDcEQsZ0JBQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUcsTUFBSSxHQUFHLENBQUMsVUFBVSxDQUFHO0FBQ3RELGdCQUFNLEdBQUcsT0FBTyxNQUFNLEtBQUssV0FBVyxHQUFHLEVBQUUsR0FBRyxNQUFNO1NBQ3JELENBQUMsT0FBTyxDQUFDLEVBQUU7Ozs7O0FBS1YsaUJBQU07U0FDUDs7QUFFRCxjQUFNLGFBQVcsS0FBSyxDQUFHLEdBQUcsSUFBSTtBQUNoQyxjQUFNLFdBQVMsS0FBSyxDQUFHLEdBQUcsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUNyQyxjQUFNLFVBQVEsS0FBSyxDQUFHLEdBQUcsR0FBRyxDQUFDLElBQUk7QUFDakMsY0FBTSxhQUFXLEtBQUssQ0FBRyxRQUFNLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBUTtBQUN4RCxjQUFNLFlBQVUsS0FBSyxDQUFHLEdBQUcsSUFBSTtPQUNoQyxDQUNGOztBQUVELGFBQU8sTUFBTTtLQUNkOzs7Ozs7OztXQU1tQyxzQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO0FBQy9DLFVBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksSUFBSSxDQUFDLElBQUksQ0FBRyxNQUFJLElBQUksQ0FBQyxTQUFTLENBQUc7QUFDNUQsVUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBSSxJQUFJLENBQUMsSUFBSSxDQUFHLE1BQUksSUFBSSxDQUFDLFVBQVUsQ0FBRztBQUM5RCxVQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsVUFBVSxDQUFHOztBQUU5RCxhQUFPO0FBQ0wsbUJBQVcsRUFBRSxHQUFHO0FBQ2hCLGdCQUFRLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7QUFDaEMsZ0JBQVEsRUFBRSxJQUFJO0FBQ2QsY0FBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDcEIsYUFBSyxFQUFFLElBQUk7QUFDWCxnQkFBUSxPQUFLLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBUTtBQUN0QyxlQUFPLEVBQUUsSUFBSTtPQUNkO0tBQ0Y7OztTQTFrQmtCLGNBQWM7OztxQkFBZCxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MkJDSmIsY0FBYzs7d0JBQ2YsY0FBYzs7OztxQkFDSixTQUFTOztvQkFDZixNQUFNOztJQUVWLE9BQU87QUFDZCxXQURPLE9BQU8sR0FDWDswQkFESSxPQUFPOztBQUV4QixRQUFJLENBQUMsS0FBSyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLElBQUksQ0FBQztHQUN4Qzs7Ozs7Ozs7ZUFIa0IsT0FBTzs7V0FTUixxQkFBQyxRQUFRLEVBQUUsS0FBSztVQUd4QixJQUFJOzs7O2lCQURSLGVBQVMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQzs7Ozs7OzRDQUNsQixLQUFLLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQyxFQUFDLEdBQUcsRUFBRSxtQkFBYSxRQUFRLENBQUMsT0FBTyxDQUFDLENBQUMsRUFBQyxDQUFDOzs7QUFBeEUsZ0JBQUk7O2lCQUNOLElBQUk7Ozs7Ozs0Q0FDb0IsS0FBSyxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUM7OztBQUFuRCxvQkFBUSxDQUFDLE9BQU8sQ0FBQzs7OztBQUlyQixnQkFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsUUFBUSxDQUFDOzs7Ozs7O0tBQzVCOzs7Ozs7Ozs7V0FPbUIsNkJBQUMsUUFBUSxFQUFFLFlBQVksRUFBRTs7Ozs7QUFLM0MsVUFBTSxXQUFXLEdBQUcsUUFBUSxDQUFDLEVBQUUsQ0FBQzs7O0FBR2hDLFVBQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDO0FBQzFCLGFBQUssRUFBRSxRQUFRLENBQUMsRUFBRSxDQUFDOztBQUVuQixjQUFNLEVBQUUsRUFBRSxHQUFHLEVBQUUsQ0FBRSxXQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFFLEVBQUU7T0FDdEQsRUFBRSxFQUFDLE1BQU0sRUFBRTtBQUNWLGFBQUcsRUFBRSxDQUFDO0FBQ04saUJBQU8sRUFBRSxDQUFDO1NBQ1gsRUFBQyxDQUFDOzs7QUFHSCxVQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFLE1BQU0sSUFBSSxLQUFLLENBQUMsc0NBQXNDLENBQUM7OztBQUd6RSxVQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxFQUFFOzs7O0FBSXpCLFVBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxRQUFRLENBQUMsQ0FBQzs7O0FBR25ELFVBQU0sZUFBZSxHQUFHLFlBQVksQ0FBQyxlQUFlO0FBQ3BELFVBQUksZUFBZSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFO0FBQ3pDLGNBQU0sSUFBSSxLQUFLLHNCQUFvQixlQUFlLENBQUMsTUFBTSxXQUFRO09BQ2xFOzs7QUFHRCxrQkFBWSxTQUFNLENBQUMsT0FBTyxDQUFDLFdBQUMsRUFBSTtBQUM5QixnQkFBUSxDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUMsS0FBSztPQUM3QixDQUFDOzs7QUFHRixXQUFLLENBQUMsT0FBTyxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUMsRUFBSztBQUN0QixnQkFBUSxDQUFDLGVBQWUsQ0FBQyxDQUFDLENBQUMsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFPLENBQUM7T0FDMUMsQ0FBQzs7Ozs7QUFLRiw0QkFBUyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUMxQyw0QkFBUyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUMxQyxhQUFPLFFBQVE7S0FDaEI7Ozs7Ozs7OztXQU9vQiw4QkFBQyxRQUFRLEVBQUUsWUFBWSxFQUFFOzs7OztBQUs1QyxVQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUM7OztBQUd6RCxVQUFNLEdBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQztBQUMxQixhQUFLLEVBQUUsUUFBUSxDQUFDLFVBQVUsQ0FBQzs7QUFFM0IsY0FBTSxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUUsV0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBRSxFQUFFO09BQ3RELEVBQUUsRUFBQyxNQUFNLEVBQUU7QUFDVixhQUFHLEVBQUUsQ0FBQztBQUNOLGlCQUFPLEVBQUUsQ0FBQztTQUNYLEVBQUMsQ0FBQzs7O0FBR0gsVUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxNQUFNLElBQUksS0FBSyxDQUFDLHNDQUFzQyxDQUFDOzs7QUFHekUsVUFBTSxLQUFLLEdBQUcsR0FBRyxDQUFDLEtBQUssRUFBRTs7OztBQUl6QixVQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7OztBQUduRCxVQUFNLGVBQWUsR0FBRyxZQUFZLENBQUMsZUFBZTtBQUNwRCxVQUFJLGVBQWUsQ0FBQyxNQUFNLEdBQUcsS0FBSyxDQUFDLE1BQU0sRUFBRTtBQUN6QyxjQUFNLElBQUksS0FBSyxzQkFBb0IsZUFBZSxDQUFDLE1BQU0sV0FBUTtPQUNsRTs7O0FBR0QsV0FBSyxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDLEVBQUs7QUFDdEIsZ0JBQVEsQ0FBQyxlQUFlLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsT0FBTyxDQUFDO09BQzFDLENBQUM7OztBQUdGLGNBQVEsQ0FBQyxPQUFPLENBQUMsR0FBRyxZQUFZLENBQUMsT0FBTzs7Ozs7QUFLeEMsNEJBQVMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLEVBQUUsRUFBRSxDQUFDO0FBQ3RFLDRCQUFTLFNBQVMsQ0FBQyxRQUFRLEVBQUUsQ0FBQyxVQUFVLEVBQUUsVUFBVSxFQUFFLFVBQVUsQ0FBQyxFQUFFLEVBQUUsQ0FBQztBQUN0RSxhQUFPLFFBQVE7S0FDaEI7OztXQUVzQixnQ0FBQyxRQUFRLEVBQUUsZUFBZSxFQUFFOztBQUVqRCxVQUFNLFdBQVcsR0FBRyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUMsT0FBTyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUM7QUFDekQsVUFBTSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUM7QUFDMUIsYUFBSyxFQUFFLFFBQVEsQ0FBQyxVQUFVLENBQUM7O0FBRTNCLGNBQU0sRUFBRSxFQUFFLEdBQUcsRUFBRSxDQUFFLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUUsRUFBRTtPQUN0RCxFQUFFLEVBQUMsTUFBTSxFQUFFO0FBQ1YsYUFBRyxFQUFFLENBQUM7QUFDTixpQkFBTyxFQUFFLENBQUM7U0FDWCxFQUFDLENBQUM7O0FBRUgsVUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRSxNQUFNLElBQUksS0FBSyxDQUFDLHNDQUFzQyxDQUFDOztBQUV6RSxVQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsS0FBSyxFQUFFOztBQUV6QixVQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUM7QUFDbkQsY0FBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQUMsV0FBQztlQUFJLENBQUMsQ0FBQyxPQUFPLENBQUM7T0FBQSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7OztBQUl2RCw0QkFBUyxTQUFTLENBQUMsUUFBUSxFQUFFLENBQUMsVUFBVSxFQUFFLFVBQVUsRUFBRSxVQUFVLENBQUMsRUFBRSxFQUFFLENBQUM7QUFDdEUsNEJBQVMsU0FBUyxDQUFDLFFBQVEsRUFBRSxDQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUUsVUFBVSxDQUFDLEVBQUUsRUFBRSxDQUFDO0FBQ3RFLGFBQU8sUUFBUTtLQUNoQjs7O1NBM0prQixPQUFPOzs7cUJBQVAsT0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzhCQ0xSLGlCQUFpQjs7OztxQkFDWixRQUFROzt5QkFDWCxlQUFlOzs7O0FBRXJDLElBQU0sUUFBUSxHQUFHLHdDQUF3Qzs7SUFFcEMsUUFBUTtBQUNmLFdBRE8sUUFBUSxDQUNkLElBQUksRUFBRSxNQUFNLEVBQUU7MEJBRFIsUUFBUTs7QUFFekIsUUFBSSxDQUFDLElBQUksR0FBRyxJQUFJO0FBQ2hCLFFBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTTtHQUNyQjs7OztlQUprQixRQUFROztXQU9WLG9CQUFDLFdBQVU7VUFDdEIsT0FBTyxFQUVMLEdBQUc7Ozs7QUFGTCxtQkFBTyx5QkFBdUIsSUFBSSxDQUFDLE1BQU0sNkJBQXdCLHFCQUFTLFdBQVUsRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQzs7OzRDQUV4RixJQUFJLENBQUMsV0FBVyxDQUM5QixnQkFBZ0IsRUFDaEIsT0FBTyxDQUNSOzs7QUFIRyxlQUFHO2dEQUlBLEVBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFDOzs7OztrQkFFckMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx1QkFBVSxLQUFLLGdCQUFHLEVBQUUsRUFBQyxVQUFVLEVBQUUsT0FBTyxFQUFDLENBQUM7Ozs7Ozs7S0FFakU7OztXQUVpQixxQkFBQyxNQUFNLEVBQUUsSUFBSTtVQUV6QixVQUFVLEVBU1YsR0FBRzs7OztBQVRILHNCQUFVLEdBQUc7QUFDZixvQkFBTSxFQUFFLE1BQU07QUFDZCxpQkFBRyxFQUFLLFFBQVEsU0FBSSxNQUFRO0FBQzVCLGtCQUFJLEVBQUUsSUFBSTthQUNYOzs7QUFFRCxrQkFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQzs7Ozs0Q0FHcEIsaUNBQVEsVUFBVSxDQUFDOzs7QUFBL0IsZUFBRztnREFFQSxHQUFHOzs7Ozs7O0tBQ1g7OztXQUVpQixxQkFBQyxlQUFlO1VBRTVCLFVBQVUsRUFVVixHQUFHOzs7O0FBVkgsc0JBQVUsR0FBRztBQUNmLG9CQUFNLEVBQUUsTUFBTTtBQUNkLGlCQUFHLEVBQUssUUFBUSxpQkFBYzthQUMvQjs7O0FBRUQsa0JBQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7Ozs0Q0FFWixJQUFJLENBQUMsNEJBQTRCLENBQUMsZUFBZSxDQUFDOzs7QUFBMUUsc0JBQVUsQ0FBQyxJQUFJOzs0Q0FHQyxpQ0FBUSxVQUFVLENBQUM7OztBQUEvQixlQUFHO2dEQUVBLEdBQUc7Ozs7Ozs7S0FDWDs7O1dBRWtDLHNDQUFDLGVBQWU7VUFnQjdDLGtCQUFrQixrRkFFYixJQUFJLHVGQUVGLENBQUMsRUFZTixJQUFJLHVGQVVHLFNBQVMsdUZBT1AsR0FBRyxFQVdkLGNBQWM7Ozs7O0FBNUNkLDhCQUFrQixHQUFHLEVBQUU7Ozs7O3dCQUVWLGVBQWU7Ozs7Ozs7O0FBQXZCLGdCQUFJOzs7Ozs7O0FBRVgsOEJBQWMsSUFBSSxDQUFDLFVBQVUsMkhBQUU7QUFBdEIsZUFBQzs7O0FBRVIsa0JBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHO2FBQ2pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFRCw4QkFBa0IsSUFBSSxtQkFBbUI7QUFDekMsOEJBQWtCLG1CQUFpQixJQUFJLENBQUMsUUFBUSxnQkFBYTs7Ozs7O0FBTXpELGdCQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7O2tCQUN6QixJQUFJLENBQUMsMEJBQTBCLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQyx3QkFBd0IsS0FBSyxFQUFFOzs7Ozs7QUFFaEYsOEJBQWtCLElBQUksZ0NBQWdDO0FBQ3RELDhCQUFrQixxQkFBbUIsSUFBSSxDQUFDLEtBQUssa0JBQWU7Ozs7OztBQUc5RCw4QkFBa0IsSUFBSSxnQ0FBZ0M7Ozs7Ozs7eUJBR2hDLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUE1QixxQkFBUzs7O0FBRWhCLHFCQUFTLENBQUMsaUJBQWlCLEdBQUcsU0FBUyxDQUFDLEtBQUs7QUFDN0MsbUJBQU8sU0FBUyxDQUFDLEtBQUs7OztBQUd0Qiw4QkFBa0IsSUFBSSxpQkFBaUI7Ozs7O0FBQ3ZDLDhCQUFnQixNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQywySEFBRTtBQUEvQixpQkFBRzs7QUFDVixnQ0FBa0IsVUFBUSxHQUFHLFNBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFLLEdBQUcsTUFBRzthQUMzRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCw4QkFBa0IsSUFBSSxrQkFBa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJNUMsOEJBQWtCLElBQUksb0JBQW9COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJeEMsMEJBQWMscUNBRVIsSUFBSSxDQUFDLE1BQU0sdUJBQ25CLGtCQUFrQjtnREFLYixjQUFjOzs7Ozs7O0tBQ3RCOzs7U0ExSGtCLFFBQVE7OztxQkFBUixRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNOUixTQUFTO1dBQVQsU0FBUzswQkFBVCxTQUFTOzs7ZUFBVCxTQUFTOztXQUNmLGVBQUMsQ0FBQyxFQUFFO0FBQ2YsVUFBSSxHQUFHLEdBQUcsRUFBRTs7QUFFWixVQUFJLENBQUMsWUFBWSxLQUFLLEVBQUU7QUFDdEIsV0FBRyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsT0FBTztBQUN2QixXQUFHLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLFdBQUcsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVE7QUFDekIsV0FBRyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsVUFBVTtBQUM3QixXQUFHLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxZQUFZO0FBQ2pDLFdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUs7T0FDcEIsTUFBTTtBQUNMLFdBQUcsR0FBRyxDQUFDO09BQ1I7O0FBRUQsYUFBTyxHQUFHO0tBQ1g7OztTQWhCa0IsU0FBUzs7O3FCQUFULFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQ0FGLFNBQVM7O0lBRXhCLGVBQWU7V0FBZixlQUFlOzBCQUFmLGVBQWU7OztlQUFmLGVBQWU7O1dBQ1QsYUFBQyxJQUFJLEVBQUUsVUFBVTtVQUM1QixNQUFNLEVBQ04sRUFBRTs7Ozs7NENBRGEscUJBQVksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUE1QyxrQkFBTTtBQUNOLGNBQUUsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0RBQzFCLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDOzs7Ozs7O0tBQ2pDOzs7U0FMVSxlQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkNGVixPQUFPOzs7O3NCQUNOLFFBQVE7Ozs7SUFFTixLQUFLO0FBQ1osV0FETyxLQUFLLENBQ1gsT0FBTyxFQUFFOzBCQURILEtBQUs7OztBQUd0QixRQUFJLENBQUMsSUFBSSxHQUFHLG1CQUFNLFVBQVUsQ0FBQyxPQUFPLENBQUM7OztBQUdyQyxRQUFJLFlBQVksR0FBRyxFQUFDLGtCQUFrQixFQUFFLElBQUksRUFBQztBQUM3QyxVQUFNLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUM7QUFDcEMsUUFBSSxDQUFDLFNBQVMsR0FBRyxtQkFBTSxVQUFVLENBQUMsWUFBWSxDQUFDO0dBQ2hEOztlQVRrQixLQUFLOzs7Ozs7O1dBbUJsQixlQUFDLEdBQUcsRUFBRTs7O0FBR1YsYUFBTyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQ2pCLElBQUksQ0FDSCxVQUFDLEdBQUcsRUFBSztBQUNQLGVBQU8sSUFBSSxPQUFPLENBQ2hCLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSzs7QUFFbkIsYUFBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFDLEVBQUUsR0FBRyxFQUFLOztBQUV6QixlQUFHLENBQUMsT0FBTyxFQUFFO0FBQ2IsZ0JBQUksQ0FBQyxFQUFFO0FBQ0wsb0JBQU0sQ0FBQyxDQUFDLENBQUM7YUFDVixNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7V0FDcEIsQ0FBQztTQUNILENBQ0Y7T0FDRixDQUNGLFNBQ0ssQ0FBQyxVQUFDLENBQUMsRUFBSztBQUNaLGNBQU0sQ0FBQztPQUNSLENBQUM7S0FDTDs7O1dBRWtCLHNCQUFDLEdBQUc7VUFDakIsR0FBRzs7Ozs7NENBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNBLEdBQUcsQ0FBQyxRQUFROzs7Ozs7O0tBQ3BCOzs7Ozs7Ozs7O1dBUWlCLHFCQUFDLEtBQUs7VUFBRSxJQUFJLHlEQUFHLEVBQUU7VUFBRSxPQUFPLHlEQUFHLEVBQUU7O1VBSTNDLEdBQUcsRUFFSCxHQUFHLGtGQVdFLENBQUMsdUZBUU4sR0FBRzs7Ozs7QUFyQkgsZUFBRyxvQkFBa0IsS0FBSztBQUUxQixlQUFHLEdBQUcsSUFBSSxHQUFHLEVBQUU7Ozs7OztBQUNuQiw2QkFBYyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyx1SEFBRTtBQUF4QixlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLEVBQUU7QUFDcEIsbUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLE1BQU0sQ0FBQztlQUNuQixNQUFNLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFOztBQUU5QyxtQkFBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQU0sS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBSTtlQUM3QyxNQUFNO0FBQ0wsbUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxPQUFLLG1CQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRztlQUN2QzthQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCw4QkFBYyxNQUFNLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQywySEFBRTtBQUEzQixlQUFDOztBQUNSLGlCQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxHQUFHLE1BQU0sR0FBRyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFDdEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVELGVBQUcsV0FBUyw2QkFBSSxHQUFHLENBQUMsSUFBSSxFQUFFLEdBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxRQUFLOztBQUUxQyxlQUFHLGlCQUFlLDZCQUFJLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQUs7Ozs0Q0FFbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNBLEdBQUcsQ0FBQyxRQUFROzs7Ozs7O0tBQ3BCOzs7Ozs7Ozs7OztXQVNpQixxQkFBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLElBQUksRUFBRSxPQUFPO1VBQ3pDLEdBQUcsRUFFSCxPQUFPLHVGQUlGLENBQUMsdUZBT04sR0FBRzs7Ozs7QUFiSCxlQUFHLGVBQWEsS0FBSztBQUVyQixtQkFBTyxHQUFHLEVBQUU7Ozs7OztBQUNoQiw4QkFBYyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQywySEFBRTtBQUF4QixlQUFDOztBQUNSLHFCQUFPLENBQUMsSUFBSSxDQUFJLENBQUMsU0FBSSxtQkFBTSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUc7YUFDOUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELDhCQUFjLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLDJIQUFFO0FBQTNCLGVBQUM7O0FBQ1IscUJBQU8sQ0FBQyxJQUFJLENBQUksQ0FBQyxTQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBRzthQUNuQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCxlQUFHLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7O0FBRXhCLGVBQUcsZ0JBQWMsTUFBTSxNQUFHOzs7NENBRVYsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNBLEdBQUc7Ozs7Ozs7S0FDWDs7Ozs7V0FHZ0Isb0JBQUMsR0FBRztVQUNmLFFBQVEsRUFHTixHQUFHOzs7O0FBSEwsb0JBQVEsR0FBRyxJQUFJLENBQUMsSUFBSTs7QUFDeEIsZ0JBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVM7Ozs0Q0FFUixJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0EsR0FBRzs7Ozs7QUFFVixnQkFBSSxDQUFDLElBQUksR0FBRyxRQUFROzs7Ozs7OztLQUV2Qjs7O1dBRXNCOzs7Ozs0Q0FDZixJQUFJLENBQUMsS0FBSyxzQkFBc0I7Ozs7Ozs7S0FDdkM7OztXQUVZOzs7Ozs0Q0FDTCxJQUFJLENBQUMsS0FBSyxXQUFXOzs7Ozs7O0tBQzVCOzs7V0FFYzs7Ozs7NENBQ1AsSUFBSSxDQUFDLEtBQUssYUFBYTs7Ozs7OztLQUM5Qjs7O1dBRWMsd0JBQUMsR0FBRyxFQUFrRDs7O1VBQWhELFFBQVEseURBQUcsVUFBQyxNQUFNLEVBQUssRUFBRTtVQUFFLE9BQU8seURBQUcsVUFBQyxDQUFDLEVBQUssRUFBRTs7QUFDakUsYUFBTyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQ2pCLElBQUksQ0FDSCxVQUFDLEdBQUcsRUFBSztBQUNQLGVBQU8sSUFBSSxPQUFPLENBQ2hCLG9CQUFPLE9BQU8sRUFBRSxNQUFNOzs7OztBQUVwQixtQkFBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FDWCxFQUFFLENBQUMsUUFBUSxFQUNWLFVBQUMsTUFBTSxFQUFLO0FBQ1YscUJBQUcsQ0FBQyxLQUFLLEVBQUU7QUFDWCwwQkFBUSxDQUFDLE1BQU0sQ0FBQztBQUNoQixxQkFBRyxDQUFDLE1BQU0sRUFBRTtpQkFDYixDQUFDLENBQ0gsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFDLENBQUMsRUFBSztBQUNsQix5QkFBTyxDQUFDLENBQUMsQ0FBQztpQkFDWCxDQUFDLENBQ0QsRUFBRSxDQUFDLEtBQUssRUFBRSxZQUFNO0FBQ2YscUJBQUcsQ0FBQyxPQUFPLEVBQUU7QUFDYix5QkFBTyxFQUFFO2lCQUNWLENBQUM7Ozs7Ozs7U0FDTCxDQUNGO09BQ0YsQ0FDRixTQUNLLENBQUMsVUFBQyxDQUFDLEVBQUs7QUFDWixjQUFNLENBQUM7T0FDUixDQUFDO0tBQ0w7OztXQUVNLGtCQUFHOzs7QUFDUixhQUFPLElBQUksT0FBTyxDQUNoQixVQUFDLE9BQU8sRUFBRSxNQUFNLEVBQUs7O0FBRW5CLGVBQUssSUFBSSxDQUFDLGFBQWEsQ0FBQyxVQUFDLENBQUMsRUFBRSxHQUFHLEVBQUs7QUFDbEMsY0FBSSxDQUFDLEVBQUU7QUFDTCxrQkFBTSxDQUFDLENBQUMsQ0FBQztXQUNWLE1BQU07QUFDTCxtQkFBTyxDQUFDLEdBQUcsQ0FBQztXQUNiO1NBQ0YsQ0FBQztPQUNILENBQ0YsU0FDTyxDQUNKLFVBQUMsQ0FBQyxFQUFLO0FBQ0wsY0FBTSxDQUFDO09BQ1IsQ0FDRjtLQUNKOzs7V0ExS2lCLG9CQUFDLElBQUksRUFBRTtBQUN2QixhQUFPLHlCQUFPLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUMsT0FBTyxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUM7S0FDaEU7OztTQWJrQixLQUFLOzs7cUJBQUwsS0FBSzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNITCxNQUFNO0FBQ2IsV0FETyxNQUFNLENBQ1osVUFBVSxFQUFFOzBCQUROLE1BQU07O0FBRXZCLFFBQUksQ0FBQyxVQUFVLEdBQUcsVUFBVTtBQUM1QixRQUFJLENBQUMsYUFBYSxHQUFHLElBQUk7QUFDekIsUUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJO0FBQ3BCLFFBQUksQ0FBQyxXQUFXLEdBQUcsSUFBSTtBQUN2QixRQUFJLENBQUMsS0FBSyxHQUFHLENBQUM7QUFDZCxRQUFJLENBQUMsV0FBVyxHQUFHLENBQUM7R0FDckI7O2VBUmtCLE1BQU07O1dBVVosZ0JBQUMsR0FBRzs7OztrQkFFWCxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQzs7Ozs7aUJBQ2hDLElBQUksQ0FBQyxhQUFhOzs7Ozs7NENBQ2QsSUFBSSxDQUFDLGFBQWEsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDOzs7aUJBRzFDLElBQUksQ0FBQyxRQUFROzs7Ozs7NENBQ1QsSUFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7OztBQUUxQixnQkFBSSxDQUFDLEtBQUssRUFBRTs7QUFFWixnQkFBSSxJQUFJLENBQUMsS0FBSyxHQUFHLElBQUksQ0FBQyxVQUFVLEtBQUssQ0FBQyxFQUFFO0FBQ3RDLGtCQUFJLENBQUMsS0FBSyxFQUFFO0FBQ1osa0JBQUksQ0FBQyxXQUFXLEVBQUU7YUFDbkI7Ozs7Ozs7S0FDRjs7O1dBQ0ssaUJBQUc7QUFDUCxVQUFJLElBQUksQ0FBQyxXQUFXLEVBQUU7QUFDcEIsWUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDO09BQ25DO0tBQ0Y7OztTQS9Ca0IsTUFBTTs7O3FCQUFOLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkNBTCxTQUFTOzs7OzRCQUNWLGVBQWU7OzJCQUNmLGdCQUFnQjs7c0JBQ2xCLFFBQVE7Ozs7SUFFTixNQUFNO0FBQ2IsV0FETyxNQUFNLEdBQ1Y7MEJBREksTUFBTTs7QUFFdkIsUUFBSSxDQUFDLE1BQU0sR0FBRyxFQUFFO0FBQ2hCLFFBQUksQ0FBQyxTQUFTLEdBQUcsRUFBRTtBQUNuQixRQUFJLENBQUMsUUFBUSxHQUFHLElBQUk7R0FDckI7Ozs7ZUFMa0IsTUFBTTs7V0FRWCx1QkFBQyxPQUFPLEVBQUU7QUFDdEIsVUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDckMsVUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztLQUNuQzs7O1dBRVc7OztVQUFDLElBQUkseURBQUcsRUFBRTtVQUFFLEVBQUUseURBQUc7Ozs7Ozs7O09BQWM7VUFDckMsR0FBRyxFQU9ELEdBQUc7Ozs7QUFQTCxlQUFHLEdBQUc7QUFDUixxQkFBTyxFQUFFLDBCQUFRO2FBQ2xCOztBQUVELGdCQUFJLENBQUMsYUFBYSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7Ozs7NENBR2IsRUFBRSxFQUFFOzs7QUFBaEIsZUFBRzs7QUFFUCxrQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsa0JBQUksRUFBRSxTQUFTO0FBQ2YsbUJBQUssRUFBRSxJQUFJO0FBQ1gsb0JBQU0sRUFBRSxHQUFHO2FBQ1osQ0FBQzs7Ozs7Ozs7QUFFRixrQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsa0JBQUksRUFBRSxPQUFPO0FBQ2IsbUJBQUssRUFBRSxJQUFJO0FBQ1gsb0JBQU0sRUFBRSxtQkFBVSxLQUFLLGdCQUFHO2FBQzNCLENBQUM7Ozs7OztBQUdGLGdCQUFJLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtBQUM5QixvQkFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEVBQUU7QUFDakIsd0JBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU07ZUFDL0IsQ0FBQzthQUNIOztBQUVELGVBQUcsQ0FBQyxTQUFTLEdBQUcsSUFBSSxJQUFJLEVBQUU7O0FBRTFCLDhCQUFLLE1BQU0sQ0FBQyxHQUFHLENBQUM7OztBQUdoQixnQkFBSSxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOzs7Ozs7OztLQUV4Qjs7Ozs7O1dBSXFCLHlCQUFDLEdBQUcsRUFBRSxFQUFFO1VBRXRCLEdBQUcsRUFHRCxHQUFHOzs7Ozs0Q0FKRSxHQUFHLENBQUMsT0FBTyxFQUFFOzs7Ozs7Ozs7NENBQ1IsR0FBRyxDQUFDLElBQUksRUFBRTs7O0FBQXRCLGVBQUc7Ozs0Q0FHVyxFQUFFLENBQUMsR0FBRyxDQUFDOzs7QUFBbkIsZUFBRzs7QUFDUCxnQkFBSSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7O0FBRWxCLGdCQUFJLENBQUMsTUFBTSxnQkFBRzs7Ozs7OztBQUdsQixlQUFHLENBQUMsS0FBSyxFQUFFOzs7Ozs7O0tBQ1o7OztXQUVRLGtCQUFDLFNBQVMsRUFBRTtBQUNuQixVQUFJLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUM7S0FDakM7OztXQUVNLGdCQUFDLFNBQVMsRUFBRTtBQUNqQixVQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxtQkFBVSxLQUFLLENBQUMsU0FBUyxDQUFDLENBQUM7S0FDaEQ7OztXQUVZLHdCQUFHO0FBQ2QsVUFBSSxRQUFRLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsV0FBQztlQUFJLENBQUMsQ0FBQyxZQUFZLEVBQUU7T0FBQSxDQUFDO0FBQ3pELFVBQUksUUFBUSxHQUFHLEtBQUs7Ozs7OztBQUNwQiw2QkFBZ0IsSUFBSSxDQUFDLE1BQU0sOEhBQUU7Y0FBcEIsR0FBRzs7QUFDVixjQUFJLEdBQUcsQ0FBQyxJQUFJLEtBQUssT0FBTyxFQUFFO0FBQ3hCLG9CQUFRLEdBQUcsSUFBSTtBQUNmLGtCQUFLO1dBQ047U0FDRjs7Ozs7Ozs7Ozs7Ozs7OztBQUNELGFBQU8sUUFBUSxJQUFJLFFBQVE7S0FDNUI7OztXQUVPLG1CQUFHOztBQUVULFVBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxFQUFFO0FBQ3ZCLGNBQU0sSUFBSSxxQkFBTyxLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztPQUNwQztBQUNELGFBQU8sSUFBSSxDQUFDLE1BQU07S0FDbkI7OztTQTdGa0IsTUFBTTs7O3FCQUFOLE1BQU07O0lBZ0dyQixRQUFRO0FBQ0EsV0FEUixRQUFRLENBQ0MsT0FBTyxFQUFFOzBCQURsQixRQUFROztBQUVWLFFBQUksQ0FBQyxNQUFNLEdBQUc7QUFDWixXQUFLLEVBQUUsQ0FBQztBQUNSLGFBQU8sRUFBRSxDQUFDO0FBQ1YsV0FBSyxFQUFFLENBQUM7QUFDUixhQUFPLEVBQUUsT0FBTztLQUNqQjtBQUNELFFBQUksQ0FBQyxTQUFTLEdBQUcsSUFBSTtHQUN0Qjs7ZUFURyxRQUFROztXQVdKLGlCQUFDLFNBQVMsRUFBRTtBQUNsQixVQUFJLFNBQVMsRUFBRTtBQUNiLFlBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLElBQUksQ0FBQztPQUMxQjtBQUNELFVBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxFQUFFO0FBQ3JCLFVBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0tBQ3BCOzs7V0FFSyxlQUFDLFNBQVMsRUFBRTs7QUFFaEIsVUFBSSxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxJQUFJLENBQUMsU0FBUyxDQUFDLFNBQVMsQ0FBQyxFQUFFO0FBQ2hFLFlBQUksU0FBUyxJQUFJLFNBQVMsS0FBSyxFQUFFLElBQUksU0FBUyxLQUFLLEVBQUUsRUFBRTtBQUNyRCxjQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxLQUFLLENBQUM7QUFDMUIsY0FBSSxDQUFDLFNBQVMsR0FBRyxTQUFTO1NBQzNCO09BQ0Y7QUFDRCxVQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtBQUNuQixVQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtLQUNwQjs7O1dBRUcsYUFBQyxTQUFTLEVBQUUsU0FBUywwQ0FBMEM7QUFDakUsVUFBSSxHQUFHLEdBQUc7QUFDUixlQUFPLEVBQUUsU0FBUztBQUNsQixlQUFPLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPO0FBQzVCLGVBQU8sRUFBRSxTQUFTO0FBQ2xCLGlCQUFTLEVBQUUsSUFBSSxJQUFJLEVBQUU7T0FDdEI7QUFDRCx3QkFBSyxNQUFNLENBQUMsR0FBRyxDQUFDO0tBQ2pCOzs7V0FFWSx3QkFBRztBQUNkLGFBQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLO0tBQ3pCOzs7U0EzQ0csUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDckdPLFFBQVE7V0FBUixRQUFROzBCQUFSLFFBQVE7OztlQUFSLFFBQVE7Ozs7V0FFWixpQkFBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRTtBQUNyQyxVQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUU7QUFBRSxrQkFBVSxHQUFHLEVBQUU7T0FBRTtBQUNqRCxVQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztBQUM5QixVQUFJLEtBQUssR0FBRyxDQUFDO0FBQ2IsVUFBSSxHQUFHLEdBQUcsRUFBRTtBQUNaLFdBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ3pDLFlBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsWUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFDcEIsS0FBSyxJQUFJLENBQUM7QUFDZixZQUFJLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFDZixpQkFBTyxHQUFHLEdBQUcsVUFBVTtTQUN4QjtBQUNELFdBQUcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztPQUN0QjtBQUNELGFBQU8sSUFBSTtLQUNaOzs7OztXQUdXLGNBQUMsSUFBSSxFQUFFO0FBQ2pCLGFBQU8sa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFNO0tBQ25FOzs7V0FFZ0IsbUJBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUU7QUFDdEMsVUFBTSxHQUFHLEdBQUcsR0FBRzs7QUFFZixVQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQUMsSUFBSSxFQUFFLE9BQU87ZUFBSyxJQUFJLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztPQUFBLEVBQUUsRUFBRSxDQUFDOztBQUU1RSxVQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUN0QyxVQUFJLE1BQU0sR0FBRyxFQUFFO0FBQ2YsVUFBSSxJQUFJLEdBQUcsRUFBRTs7O0FBR2IsVUFBSTtBQUNGLGlCQUFTLENBQUMsTUFBTSxDQUFDLFVBQUMsSUFBSSxFQUFFLE9BQU8sRUFBSzs7QUFFbEMsY0FBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLE1BQU0sRUFBRSxNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUM3RCxjQUFNLElBQUksR0FBRyxDQUFDLElBQUksS0FBSyxFQUFFLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksT0FBTztBQUN0RCxjQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsTUFBTSxFQUFFO0FBQ2hDLGtCQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNqQixnQkFBSSxHQUFHLE9BQU87QUFDZCxtQkFBTyxFQUFFO1dBQ1YsTUFBTTtBQUNMLGdCQUFJLEdBQUcsSUFBSTtBQUNYLG1CQUFPLElBQUk7V0FDWjtTQUNGLEVBQUUsRUFBRSxDQUFDO09BQ1AsQ0FBQyxPQUFPLENBQUMsRUFBRTs7QUFFVixZQUFJLENBQUMsQ0FBQyxPQUFPLEtBQUssT0FBTyxFQUFFLE9BQU07T0FDbEM7O0FBRUQsWUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7O0FBRWpCLFdBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ3BDLGNBQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUU7T0FDN0M7S0FDRjs7O1NBMURrQixRQUFROzs7cUJBQVIsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs0QkNBTixlQUFlOzsyQkFDaEIsY0FBYzs7QUFFN0IsSUFBTSxJQUFJLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsTUFBTSxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOztBQUNsRSxJQUFNLE9BQU8sR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxTQUFTLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUM7O0FBQ3hFLElBQU0sV0FBVyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLGFBQWEsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7O0FBRWhGLElBQU0sT0FBTyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFNBQVMsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7O0FBRS9FLElBQUkscUJBQU8sUUFBUSxFQUFFO0FBQ25CLHVCQUFPLE9BQU8sQ0FBQyxTQUFTLEVBQUUsWUFBTTtBQUM5QixXQUFPLE9BQU8sQ0FBQyxJQUFJLEVBQUU7R0FDdEIsQ0FBQztDQUNIOztBQUVELElBQUkscUJBQU8sUUFBUSxFQUFFO0FBQ25CLHVCQUFPLFNBQVMsQ0FBQyxTQUFTLENBQUMiLCJmaWxlIjoiL2FwcC5qcyIsInNvdXJjZXNDb250ZW50IjpbIi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgKHJlcSwgcmVzLCBuZXh0KSA9PiB7XHJcbi8vICAgcmVzLndyaXRlSGVhZCgyMDApO1xyXG4vLyAgIHJlcy5lbmQoYEhlbGxvIHdvcmxkIGZyb206ICR7TWV0ZW9yLnJlbGVhc2V9YCk7XHJcbi8vIH0pO1xyXG5cclxuaW1wb3J0IGZzIGZyb20gJ2ZzJztcclxuaW1wb3J0IHVuaXFpZCBmcm9tICd1bmlxaWQnO1xyXG5cclxuLy8gUmVxdWlyZXMgbXVsdGlwYXJ0eSBcclxuaW1wb3J0IG11bHRpcGFydHkgZnJvbSAnY29ubmVjdC1tdWx0aXBhcnR5JztcclxuaW1wb3J0IHtcclxuICBVcGxvYWRzXHJcbn0gZnJvbSAnLi4vLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9ucyc7XHJcbmxldCBtdWx0aXBhcnR5TWlkZGxld2FyZSA9IG11bHRpcGFydHkoKTtcclxuXHJcbmNvbnN0IHJvdXRlID0gJy91cGxvYWQvaW1hZ2UnO1xyXG5cclxuLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCBmdWMudXBsb2FkRmlsZSApO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgbXVsdGlwYXJ0eU1pZGRsZXdhcmUpO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgKHJlcSwgcmVzcCkgPT4ge1xyXG4gIC8vIGRvbid0IGZvcmdldCB0byBkZWxldGUgYWxsIHJlcS5maWxlcyB3aGVuIGRvbmVcclxuXHJcbiAgY29uc3QgcmVhZGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy5yZWFkRmlsZSk7XHJcbiAgY29uc3Qgd3JpdGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy53cml0ZUZpbGUpO1xyXG4gIGNvbnN0IHVwbG9hZElkID0gdW5pcWlkKCk7XHJcblxyXG4gIGZvciAobGV0IGZpbGUgb2YgcmVxLmZpbGVzLmZpbGUpIHtcclxuICAgIGNvbnN0IGRhdGEgPSByZWFkZXIoZmlsZS5wYXRoKTtcclxuICAgIC8vIOODleOCoeOCpOODq+WQjeOBrumHjeikh+OCkumBv+OBkeOCi+OBn+OCgeOAgeS4gOaEj+OBruODleOCoeOCpOODq+WQjeOCkuS9nOaIkOOBmeOCi1xyXG4gICAgLy8g5qW95aSp44Gu44OV44Kh44Kk44Or5ZCN5paH5a2X5pWw5Yi26ZmQMjDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBmaWxlbmFtZSA9IGAke3VuaXFpZCgpfS5qcGdgXHJcblxyXG4gICAgLy8gc2V0IHRoZSBjb3JyZWN0IHBhdGggZm9yIHRoZSBmaWxlIG5vdCB0aGUgdGVtcG9yYXJ5IG9uZSBmcm9tIHRoZSBBUEk6XHJcbiAgICBsZXQgc2F2ZVBhdGggPSByZXEuYm9keS5pbWFnZWRpciArICcvJyArIGZpbGVuYW1lO1xyXG5cclxuICAgIC8vIGNvcHkgdGhlIGRhdGEgZnJvbSB0aGUgcmVxLmZpbGVzLmZpbGUucGF0aCBhbmQgcGFzdGUgaXQgdG8gZmlsZS5wYXRoXHJcblxyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ57WQ5p6c44KS6KiY6Yyy44GZ44KLXHJcbiAgICBsZXQgZG9jID0ge1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICAgIGNsaWVudEZpbGVOYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgIHVwbG9hZGVkRmlsZU5hbWU6IGZpbGVuYW1lXHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICB0cnl7XHJcbiAgICAgIHdyaXRlcihzYXZlUGF0aCwgZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaChlcnIpe1xyXG4gICAgICBkb2MuZXJyb3IgPSBlcnI7XHJcbiAgICB9XHJcbiAgICBVcGxvYWRzLmluc2VydChkb2MpO1xyXG5cclxuICAgIGRlbGV0ZSBmaWxlO1xyXG5cclxuICB9O1xyXG4gIHJlc3Aud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgc2F2ZURpcjogcmVxLmJvZHkuaW1hZ2VkaXJcclxuICB9KSk7XHJcblxyXG59KTsiLCJpbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0bydcclxuXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBSZXBvcnQgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBHcm91cCxcclxuICBHcm91cEZhY3RvcnlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzJ1xyXG5pbXBvcnQge1xyXG4gIEZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlbWlnJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5taWdyYXRlYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIC8vIHNldHVwIGdyb3VwXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgRmlsdGVyKGNvbmZpZy5zcmNGaWx0ZXJJZClcclxuICAgIC8vIGxldCBwbHVnID0gZ3JvdXAuZ2V0UGx1ZygpO1xyXG5cclxuICAgIC8vIGNoZWNraW5nIGNvbm5lY3Rpb25cclxuICAgIC8vXHJcblxyXG4gICAgbGV0IHRlc3RRdWVyeSA9ICdTSE9XIERBVEFCQVNFUydcclxuXHJcbiAgICBsZXQgZHN0RGIgPSBuZXcgTXlTUUwoY29uZmlnLmRzdC5jcmVkKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnQ29ubmVjdCB0byBEZXN0aW5hdGlvbicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBhd2FpdCBkc3REYi5xdWVyeSh0ZXN0UXVlcnkpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcHJvY2VzcyBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICAvL1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnU2VsZWN0IGxvb3AgaW4gc291cmNlJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICBtb2JpbGVOdWxsOiBhc3luYyAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIC8vIOWApOOCkuaVtOeQhlxyXG4gICAgICAgICAgICAvLyBmb3IgKGxldCBrZXkgb2YgT2JqZWN0LmtleXMocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyAgIGlmIChyZWNvcmRba2V5XSA9PT0gbnVsbCk7XHJcbiAgICAgICAgICAgIC8vICAgZWxzZSBpZiAocmVjb3JkW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAvLyDml6Xku5jjgpLlpInmj5tcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gTXlTUUwuZm9ybWF0RGF0ZShyZWNvcmRba2V5XSk7XHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IGBcIiR7cmVjb3JkW2tleV19XCJgO1xyXG4gICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyIOOBq+S/neWtmFxyXG5cclxuICAgICAgICAgICAgbGV0IHNxbCA9IGBcclxuXHJcbiAgICAgICAgICAgICAgICBJTlNFUlQgZHRiX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAoIFxcYGN1c3RvbWVyX2lkXFxgLCBcXGBzdGF0dXNcXGAsIFxcYHNleFxcYCwgXFxgam9iXFxgLCBcXGBjb3VudHJ5X2lkXFxgLCBcXGBwcmVmXFxgLCBcXGBuYW1lMDFcXGAsIFxcYG5hbWUwMlxcYCwgXFxga2FuYTAxXFxgLCBcXGBrYW5hMDJcXGAsIFxcYGNvbXBhbnlfbmFtZVxcYCwgXFxgemlwMDFcXGAsIFxcYHppcDAyXFxgLCBcXGB6aXBjb2RlXFxgLCBcXGBhZGRyMDFcXGAsIFxcYGFkZHIwMlxcYCwgXFxgZW1haWxcXGAsIFxcYHRlbDAxXFxgLCBcXGB0ZWwwMlxcYCwgXFxgdGVsMDNcXGAsIFxcYGZheDAxXFxgLCBcXGBmYXgwMlxcYCwgXFxgZmF4MDNcXGAsIFxcYGJpcnRoXFxgLCBcXGBwYXNzd29yZFxcYCwgXFxgc2FsdFxcYCwgXFxgc2VjcmV0X2tleVxcYCwgXFxgZmlyc3RfYnV5X2RhdGVcXGAsIFxcYGxhc3RfYnV5X2RhdGVcXGAsIFxcYGJ1eV90aW1lc1xcYCwgXFxgYnV5X3RvdGFsXFxgLCBcXGBub3RlXFxgLCBcXGBjcmVhdGVfZGF0ZVxcYCwgXFxgdXBkYXRlX2RhdGVcXGAsIFxcYGRlbF9mbGdcXGAgKVxyXG5cclxuICAgICAgICAgICAgICAgIFZBTFVFUyggJHtyZWNvcmQuY3VzdG9tZXJfaWR9ICwgJHtyZWNvcmQuc3RhdHVzfSAsICR7cmVjb3JkLnNleH0gLCAke3JlY29yZC5qb2J9ICwgJHtyZWNvcmQuY291bnRyeV9pZH0gLCAke3JlY29yZC5wcmVmfSAsICR7cmVjb3JkLm5hbWUwMX0gLCAke3JlY29yZC5uYW1lMDJ9ICwgJHtyZWNvcmQua2FuYTAxfSAsICR7cmVjb3JkLmthbmEwMn0gLCAke3JlY29yZC5jb21wYW55X25hbWV9ICwgJHtyZWNvcmQuemlwMDF9ICwgJHtyZWNvcmQuemlwMDJ9ICwgJHtyZWNvcmQuemlwY29kZX0gLCAke3JlY29yZC5hZGRyMDF9ICwgJHtyZWNvcmQuYWRkcjAyfSAsICR7cmVjb3JkLmVtYWlsfSAsICR7cmVjb3JkLnRlbDAxfSAsICR7cmVjb3JkLnRlbDAyfSAsICR7cmVjb3JkLnRlbDAzfSAsICR7cmVjb3JkLmZheDAxfSAsICR7cmVjb3JkLmZheDAyfSAsICR7cmVjb3JkLmZheDAzfSAsICR7cmVjb3JkLmJpcnRofSAsICR7cmVjb3JkLnBhc3N3b3JkfSAsICR7cmVjb3JkLnNhbHR9ICwgJHtyZWNvcmQuc2VjcmV0X2tleX0gLCAke3JlY29yZC5maXJzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5sYXN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmJ1eV90aW1lc30gLCAke3JlY29yZC5idXlfdG90YWx9ICwgJHtyZWNvcmQubm90ZX0gLCAke3JlY29yZC5jcmVhdGVfZGF0ZX0gLCAke3JlY29yZC51cGRhdGVfZGF0ZX0gLCAke3JlY29yZC5kZWxfZmxnfSApXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBzdGF0dXM6IHJlY29yZC5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgIHNleDogcmVjb3JkLnNleCxcclxuICAgICAgICAgICAgICAgICAgam9iOiByZWNvcmQuam9iLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIGVtYWlsOiByZWNvcmQuZW1haWwsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGJpcnRoOiByZWNvcmQuYmlydGgsXHJcbiAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiByZWNvcmQucGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICAgIHNhbHQ6IHJlY29yZC5zYWx0LFxyXG4gICAgICAgICAgICAgICAgICBzZWNyZXRfa2V5OiByZWNvcmQuc2VjcmV0X2tleSxcclxuICAgICAgICAgICAgICAgICAgZmlyc3RfYnV5X2RhdGU6IHJlY29yZC5maXJzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgbGFzdF9idXlfZGF0ZTogcmVjb3JkLmxhc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90aW1lczogcmVjb3JkLmJ1eV90aW1lcyxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RvdGFsOiByZWNvcmQuYnV5X3RvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBub3RlOiByZWNvcmQubm90ZSxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lcl9hZGRyZXNzXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyX2FkZHJlc3MnLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2FkZHJlc3NfaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOODoeODq+ODnuOCrOODl+ODqeOCsOOCpOODsyBwbGdfbWFpbG1hZ2FfY3VzdG9tZXJcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfbWFpbG1hZ2FfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGlkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBtYWlsbWFnYV9mbGc6IHJlY29yZC5tYWlsbWFnYV9mbGcsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjgq/jg7zjg53jg7PnmbrooYzvvIhFQ0NVQkUy44Gu44Od44Kk44Oz44OI6YKE5YWD77yJXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uQ2QgPSBjcnlwdG8ucmFuZG9tQnl0ZXMoOCkudG9TdHJpbmcoJ2Jhc2U2NCcpLnN1YnN0cmluZygwLCAxMSlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25OYW1lID0gYCR7cmVjb3JkLm5hbWUwMX0gJHtyZWNvcmQubmFtZTAyfSDmp5gg44GU5YSq5b6F44Kv44O844Od44OzIOS8muWToeeVquWPtzoke3JlY29yZC5jdXN0b21lcl9pZH1gXHJcblxyXG4gICAgICAgICAgICBsZXQgZGlzY291bnRQcmljZSA9IHJlY29yZC5wb2ludCArIDUwMFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX2NvdXBvbicsIHtcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fY2Q6IGNvdXBvbkNkLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdHlwZTogMywgLy8g5YWo5ZWG5ZOBXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9uYW1lOiBjb3Vwb25OYW1lLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF90eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdXNlX3RpbWU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9yZWxlYXNlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9wcmljZTogZGlzY291bnRQcmljZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcmF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgZW5hYmxlX2ZsYWc6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9tZW1iZXI6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9sb3dlcl9saW1pdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX2Zyb21fZGF0ZTogJzIwMTgtMDQtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfdG9fZGF0ZTogJzIwMTktMDUtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiAwXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyAnY3ViZW1pZy5zZXJ2ZXJDaGVjaycgKHByb2ZpbGUpIHtcclxuICAgIGxldCBkYiA9IG5ldyBNeVNRTChwcm9maWxlKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGRiLnF1ZXJ5KCdTSE9XIERBVEFCQVNFUycpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IHsgTW9uZ29Db2xsZWN0aW9uIH0gZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL21vbmdvJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuY29sbGVjdGlvbidcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZmluZGBdIChwbHVnLCBxdWVyeSA9IHt9LCBwcm9qZWN0aW9uID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5maW5kKHF1ZXJ5LCB7cHJvamVjdGlvbjogcHJvamVjdGlvbn0pLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmFnZ3JlZ2F0ZWBdIChwbHVnLCBxdWVyeSA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuYWdncmVnYXRlKHF1ZXJ5KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuaXRlbXMnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z44Kz44Os44Kv44K344On44Oz5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44G+44GZ44CCXHJcbiAgICogQHBhcmFtXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uc2V0SW1hZ2VgXSAocGx1ZywgdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGxldCB1cGxvYWRlZCA9IGF3YWl0IGl0ZW1jb24uc2V0SW1hZ2UodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICAgIHJldHVybiB1cGxvYWRlZFxyXG4gIH0sXHJcblxyXG4gIC8qKlxyXG4gICAqIOOCouOCpOODhuODoOaDheWgseODh+ODvOOCv+ODmeODvOOCueOBrueUu+WDj+eZu+mMsuOCkuWJiumZpOOBmeOCi++8iOeUu+WDj+iHquS9k+OBr+WJiumZpOOBl+OBquOBhO+8iVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LmNsZWFuSW1hZ2VgXSAocGx1ZywgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5jbGVhbkltYWdlKG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IHtcclxuICBDdWJlM0FwaVxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9jdWJlM2FwaSdcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWcqOW6q+abtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVTdG9ja2BdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpXHJcbiAgICBsZXQgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+WcqOW6q+OBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdVUERBVEUnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseeZu+mMsuOBqOabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYkl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKVxyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQilcclxuXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdFQ0NVQkUz44G444Gu5ZWG5ZOB55m76YyyJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnSU5TRVJUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvblxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKVxyXG5cclxuICAgICAgICAgICAgICBsZXQgaW5zZXJ0UmVzID0gYXdhaXQgYXBpLnByb2R1Y3RDcmVhdGUoY3ViZUl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIC8vIGl0ZW0g44OH44O844K/44OZ44O844K544G444Gu55m76YyyXHJcbiAgICAgICAgICAgICAgYXdhaXQgY29sLnVwZGF0ZSh7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkXHJcbiAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X2lkLFxyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X2NsYXNzX2lkLFxyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X3N0b2NrX2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X3N0b2NrX2lkXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+WVhuWTgeaDheWgseOBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb25cclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RJbWFnZVVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuXHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5pbXBvcnQgaWNvbnYgZnJvbSAnaWNvbnYtbGl0ZSdcclxuaW1wb3J0IGNzdiBmcm9tICdjc3YnXHJcbmltcG9ydCB7IFRyYW5zZm9ybSwgV3JpdGFibGUgfSBmcm9tICdzdHJlYW0nXHJcblxyXG5pbXBvcnQgRmliZXIgZnJvbSAnZmliZXJzJ1xyXG5pbXBvcnQgUm9ib3RpbiBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2Uvcm9ib3RpbidcclxuXHJcbmNvbnN0IHRhZyA9ICdyb2JvdGluJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5wb3N0bGFiZWxgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdSb2JvdC1pbiDpgIHjgornirbnmbrooYwnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS8ke2NvbmZpZy5wb3N0bGFiZWwud29ya2Rpcn1gXHJcbiAgICAgICAgY29uc3Qgd29ya2RpclJlYWQgPSBgJHt3b3JrZGlyfS8ke2NvbmZpZy5wb3N0bGFiZWwud29ya2RpclJlYWR9YFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXJXcml0ZSA9IGAke3dvcmtkaXJ9LyR7Y29uZmlnLnBvc3RsYWJlbC53b3JrZGlyV3JpdGV9YFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAvLyDoqq3jgb/lj5bjgorjg5Xjgqnjg6vjg4BcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpclJlYWQpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgLy8g5pu444GN6L6844G/44OV44Kp44Or44OAXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXJXcml0ZSlcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyB3b3JrZGlyIOOBjOa6luWCmeOBleOCjOOBpuOBhOOBn+OCieWun+ihjOOBmeOCi1xyXG4gICAgICAgIGNvbnN0IGl0ZW1TID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtUy5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDlj5fms6hDU1bjgpLoqq3jgb/ovrzjgoBcclxuICAgICAgICBjb25zdCByb2JvID0gbmV3IFJvYm90aW4oKVxyXG4gICAgICAgIE1ldGVvci53cmFwQXN5bmMobWNiID0+IHtcclxuICAgICAgICAgIGNvbnN0IHJlYWQgPSBmc0V4dHJhLmNyZWF0ZVJlYWRTdHJlYW0oYCR7d29ya2RpclJlYWR9LyR7Y29uZmlnLnBvc3RsYWJlbC5vcmRlcmNzdn0uY3N2YClcclxuICAgICAgICAgICAgLm9uKCdlcnJvcicsIGVyciA9PiB7IG1jYihlcnIpIH0pXHJcbiAgICAgICAgICBjb25zdCB3cml0ZSA9IG5ldyBXcml0YWJsZSh7XHJcbiAgICAgICAgICAgIG9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgIGFzeW5jIHdyaXRlIChjaHVuaywgZW5jb2RpbmcsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgcm9iby5pbXBvcnRPcmRlcihjaHVuaywgaXRlbVMpXHJcbiAgICAgICAgICAgICAgY2FsbGJhY2soKVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBmaW5hbCAoY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgICBjYWxsYmFjaygpXHJcbiAgICAgICAgICAgICAgbWNiKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICByZWFkLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAgIC5waXBlKHdyaXRlKVxyXG4gICAgICAgIH0pKClcclxuXHJcbiAgICAgICAgLy8g6YCB44KK54q256iu5Yil44GU44Go44Gr57mw44KK6L+U44GZXHJcbiAgICAgICAgY29uZmlnLnBvc3RsYWJlbC5sYWJlbHR5cGVzLmZvckVhY2gobGFiZWxPcHRpb24gPT4ge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgTWV0ZW9yLndyYXBBc3luYyhtY2IgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IHJlYWQgPSBmc0V4dHJhLmNyZWF0ZVJlYWRTdHJlYW0oYCR7d29ya2RpclJlYWR9LyR7bGFiZWxPcHRpb24ucmVhZGNzdn0uY3N2YClcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoKSA9PiB7IG1jYigpIH0pIC8vIOODleOCoeOCpOODq+OBjOOBquOBhOWgtOWQiOOBr+eEoeimllxyXG4gICAgICAgICAgICAgIGNvbnN0IHRyYW5zZm9ybSA9IG5ldyBUcmFuc2Zvcm0oe1xyXG4gICAgICAgICAgICAgICAgcmVhZGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgd3JpdGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiAoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBsZXQgcmVjb3JkXHJcbiAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgcmVjb3JkID0gcm9ib1tsYWJlbE9wdGlvbi5tZXRob2RdKGNodW5rLCBsYWJlbE9wdGlvbilcclxuICAgICAgICAgICAgICAgICAgICBjYWxsYmFjayhudWxsLCByZWNvcmQpXHJcbiAgICAgICAgICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgICAgICAgICAgbWNiKGVycm9yKVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICBjb25zdCB3cml0ZSA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2RpcldyaXRlfS8ke2xhYmVsT3B0aW9uLndyaXRlY3N2fS5jc3ZgKVxyXG4gICAgICAgICAgICAgICAgLm9uKCdmaW5pc2gnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpXHJcbiAgICAgICAgICAgICAgICAgIG1jYigpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlcnJvcicsIGVycm9yID0+IHsgbWNiKGVycm9yKSB9KVxyXG5cclxuICAgICAgICAgICAgICByZWFkXHJcbiAgICAgICAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGNzdi5wYXJzZSh7Y29sdW1uczogbGFiZWxPcHRpb24uY29sdW1ucyA9PT0gdHJ1ZSA/IHRydWUgOiBudWxsfSkpXHJcbiAgICAgICAgICAgICAgICAucGlwZSh0cmFuc2Zvcm0pXHJcbiAgICAgICAgICAgICAgICAucGlwZShjc3Yuc3RyaW5naWZ5KHtoZWFkZXI6IGxhYmVsT3B0aW9uLmNvbHVtbnN9KSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgICAgICAgLnBpcGUod3JpdGUpXHJcbiAgICAgICAgICAgIH0pKClcclxuICAgICAgICAgIH0gY2F0Y2ggKGVycm9yKSB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZXJyb3IpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyBSb2JvdC1pblxyXG4gIC8vIOWklumDqOmAo+aQuuWVhuWTgeeVquWPt1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5pdGVtY29kZWBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1JvYm90LWluIOWklumDqOmAo+aQuuWVhuWTgeeVquWPtycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9LyR7Y29uZmlnLml0ZW1jb2RlLndvcmtkaXJ9YFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyB3b3JrZGlyIOOBjOa6luWCmeOBleOCjOOBpuOBhOOBn+OCieWun+ihjOOBmeOCi1xyXG4gICAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgICBjb25zdCByZWFkID0gaXRlbUNvbnRyb2xsZXIuSXRlbXMuZmluZCh7bW9kZWw6IHskbmU6ICcnfX0pLnN0cmVhbSgpXHJcblxyXG4gICAgICAgICAgY29uc3Qgd3JpdGVDc3YgPSAocmVhZCwgdGYsIGZpbGVuYW1lKSA9PiB7XHJcbiAgICAgICAgICAgIGNvbnN0IHJvYm90aW4gPSBuZXcgVHJhbnNmb3JtKHtcclxuICAgICAgICAgICAgICByZWFkYWJsZU9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgICAgd3JpdGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybSAoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykge1xyXG4gICAgICAgICAgICAgICAgRmliZXIoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb25zdCBkYXRhID0gdGYoY2h1bmspXHJcbiAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIGRhdGEpXHJcbiAgICAgICAgICAgICAgICB9KS5ydW4oKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgbGV0IGNvdW50ID0gMFxyXG4gICAgICAgICAgICBjb25zdCBjbGVhcm51bSA9IG5ldyBUcmFuc2Zvcm0oe1xyXG4gICAgICAgICAgICAgIGVuY29kaW5nOiAndXRmOCcsXHJcbiAgICAgICAgICAgICAgdHJhbnNmb3JtOiAoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgICAgbGV0IHN0ciA9IGNodW5rLnRvU3RyaW5nKClcclxuICAgICAgICAgICAgICAgIGlmIChjb3VudCA9PT0gMCkge1xyXG4gICAgICAgICAgICAgICAgICBzdHIgPSBzdHIucmVwbGFjZSgvX1xcZCs/L2csICcnKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY291bnQrK1xyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2sobnVsbCwgc3RyKVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgY29uc3Qgd3JpdGVjc3YgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke2ZpbGVuYW1lfS5jc3ZgKVxyXG4gICAgICAgICAgICB3cml0ZWNzdi5vbignZXJyb3InLCBlID0+IHsgdGhyb3cgTWV0ZW9yLkVycm9yKCdDU1bjg5XjgqHjgqTjg6vmm7jjgY3ovrzjgb/jgqjjg6njg7wnKSB9KVxyXG5cclxuICAgICAgICAgICAgcmVhZC5waXBlKHJvYm90aW4pXHJcbiAgICAgICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAgICAgLnBpcGUoY2xlYXJudW0pXHJcbiAgICAgICAgICAgICAgLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgICAgIC5waXBlKHdyaXRlY3N2KVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIHdyaXRlQ3N2KFxyXG4gICAgICAgICAgICByZWFkLFxyXG4gICAgICAgICAgICBJdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVJvYm90aW5JdGVtLFxyXG4gICAgICAgICAgICBgJHt3b3JrZGlyfS8ke2NvbmZpZy5pdGVtY29kZS5jc3ZOYW1lSXRlbX1gXHJcbiAgICAgICAgICApXHJcblxyXG4gICAgICAgICAgd3JpdGVDc3YoXHJcbiAgICAgICAgICAgIHJlYWQsXHJcbiAgICAgICAgICAgIEl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtUm9ib3RpblNlbGVjdCxcclxuICAgICAgICAgICAgYCR7d29ya2Rpcn0vJHtjb25maWcuaXRlbWNvZGUuY3N2TmFtZVNlbGVjdH1gXHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKGDmraPjgZfjgYTkvZzmpa3jg4fjgqPjg6zjgq/jg4jjg6rjgYznlKjmhI/jgZXjgozjgabjgYTjgb7jgZvjgpPjgafjgZfjgZ/jgIJcXG5bJHt3b3JrZGlyfV1gKVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ3Rvb2wnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnRlc3RgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG5cclxuICAgIGNvbnN0IG5ld0xvY2FsID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe30sIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgIHRocm93IGVcclxuICAgIH0pXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg5XjgqPjg6vjgr/jg7zjg4bjgrnjg4gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIG5ld0xvY2FsXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QtcHJvbWlzZSdcclxuaW1wb3J0IFdvd21hQXBpIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS93b3dtYUFwaSdcclxuaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuLi9pbXBvcnRzL3V0aWwvZXJyb3InXHJcblxyXG5jb25zdCB0YWcgPSAnd293bWEnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB44Gu6YWN6YCB5pa55rOV44KS6Kit5a6a44GZ44KLXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZUl0ZW0uZGVsaXZlcnlNZXRob2RgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB44Gu6YWN6YCB5pa55rOV44KS6Kit5a6a44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgLy8g44OG44K544OI5qSc57Si5p2h5Lu26Kit5a6aXHJcbiAgICAgICAgICAgICAgICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAkb3I6IFtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnZ2stMTYzJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ5NDInIC8vIEpLLTEyMFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNTQwMidcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIH0sXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA0NzQzJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgICAvLyAgIF1cclxuICAgICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIC8vIOWVhuWTgeOCs+ODvOODieOBruS4gOimp+OCkuS9nOOCi1xyXG4gICAgICAgICAgICAgICRncm91cDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAnJG1hbGwud293bWEuaXRlbUNvZGUnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJHByb2plY3Q6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogMCxcclxuICAgICAgICAgICAgICAgIGl0ZW1Db2RlOiAnJF9pZCdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIF1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIC8vIOW+l+OCieOCjOOBn+WVhuWTgeOBlOOBqOOBq0FQSeODquOCr+OCqOOCueODiOOCkueZuuihjFxyXG4gICAgICAgIGxldCBhcGkgPSBuZXcgV293bWFBcGkoY29uZmlnLndvd21hQXBpUG9zdCwgY29uZmlnLnNob3BJZClcclxuICAgICAgICBhd2FpdCByZXBvcnQuZm9yRWFjaE9uQ3Vyc29yKFxyXG4gICAgICAgICAgY3VyLFxyXG4gICAgICAgICAgYXN5bmMgaXRlbSA9PiB7XHJcbiAgICAgICAgICAgIE9iamVjdC5hc3NpZ24oaXRlbSwgYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1Xb3dtYUNyZWF0ZURlbGl2ZXJ5TWV0aG9kKGl0ZW0uaXRlbUNvZGUpKVxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlSXRlbShpdGVtKVxyXG4gICAgICAgICAgICAgIHJldHVybiB7cmVxdWVzdEJvZHk6IGl0ZW0sIHJlc3BvbnNlOiByZXN9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICB0aHJvdyBPYmplY3QuYXNzaWduKHtyZXF1ZXN0Qm9keTogaXRlbX0sIHV0aWxFcnJvci5wYXJzZShlKSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDllYblk4Hjg4fjg7zjgr/jg5njg7zjgrnkuIrjga7llYblk4HjgpLlhazplovjgZnjgotcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlSXRlbS5vcGVuYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV293bWEhIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueS4iuOBruWVhuWTgeOCkuWFrOmWi+OBmeOCiycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIGpsaW5lX2VuZ2luZSDllYblk4Hjg4fjg7zjgr/jg5njg7zjgrnjgbjjga7mjqXntppcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyDllYblk4Hmg4XloLHjga7kvZzmiJBcclxuICAgICAgICBsZXQgY3VyID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgICAgICAkYW5kOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6IHsgJGV4aXN0czogMSB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8g44OG44K544OI5qSc57Si5p2h5Lu26Kit5a6aXHJcbiAgICAgICAgICAgICAgICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAkb3I6IFtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnZ2stMTYzJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNTQwMidcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIH0sXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA0NzQzJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgICAvLyAgIF1cclxuICAgICAgICAgICAgICAgICAgLy8gfVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIC8vIOWVhuWTgeOCs+ODvOODieOBruS4gOimp+OCkuS9nOOCi1xyXG4gICAgICAgICAgICAgICRncm91cDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAnJG1hbGwud293bWEuaXRlbUNvZGUnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJHByb2plY3Q6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogMCxcclxuICAgICAgICAgICAgICAgIGl0ZW1Db2RlOiAnJF9pZCdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIF1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIC8vIOW+l+OCieOCjOOBn+WVhuWTgeOBlOOBqOOBq0FQSeODquOCr+OCqOOCueODiOOCkueZuuihjFxyXG4gICAgICAgIGxldCBhcGkgPSBuZXcgV293bWFBcGkoY29uZmlnLndvd21hQXBpUG9zdCwgY29uZmlnLnNob3BJZClcclxuICAgICAgICBhd2FpdCByZXBvcnQuZm9yRWFjaE9uQ3Vyc29yKFxyXG4gICAgICAgICAgY3VyLFxyXG4gICAgICAgICAgYXN5bmMgaXRlbSA9PiB7XHJcbiAgICAgICAgICAgIGl0ZW0uc2FsZVN0YXR1cyA9IDFcclxuICAgICAgICAgICAgaXRlbS5saW1pdGVkUGFzc3dkID0gJ05VTEwnXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS51cGRhdGVJdGVtKGl0ZW0pXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtyZXF1ZXN0Qm9keTogaXRlbSwgcmVzcG9uc2U6IHJlc31cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHRocm93IE9iamVjdC5hc3NpZ24oe3JlcXVlc3RCb2R5OiBpdGVtfSwgdXRpbEVycm9yLnBhcnNlKGUpKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWcqOW6q+abtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVTdG9ja2BdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dPV01BISDlnKjluqvmm7TmlrAnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyDlnKjluqvmg4XloLHjga7kvZzmiJBcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgbGV0IGN1ciA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICAgICAgJGFuZDogW1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiB7ICRleGlzdHM6IDEgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vIOODhuOCueODiOaknOe0ouadoeS7tuioreWumlxyXG4gICAgICAgICAgICAgICAgLy8gICAse1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAge1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNTQwMidcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICx7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJ2drLTE2MydcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICAgICx7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA0NzQzJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgIF1cclxuICAgICAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAgICAgXVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIC8vIOmFjemAgeaWueazleOBrumBleOBhOOCkuecgeOBj1xyXG4gICAgICAgICAgICAgICRncm91cDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiB7XHJcbiAgICAgICAgICAgICAgICAgIGl0ZW1Db2RlOiAnJG1hbGwud293bWEuaXRlbUNvZGUnLFxyXG4gICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZTogJyRtYWxsLndvd21hLkhDaG9pY2VOYW1lJyxcclxuICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlOiAnJG1hbGwud293bWEuVkNob2ljZU5hbWUnXHJcbiAgICAgICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICAgICAgaXRlbToge1xyXG4gICAgICAgICAgICAgICAgICAkZmlyc3Q6ICckX2lkJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgIC8vIOWVhuWTgeODmuODvOOCuOOBlOOBqO+8iOWVhuWTgeOCs+ODvOODie+8ieOBq+OCsOODq+ODvOODl+WMluOBmeOCi1xyXG4gICAgICAgICAgICAgICRncm91cDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAnJF9pZC5pdGVtQ29kZScsXHJcbiAgICAgICAgICAgICAgICB2YXJpYXRpb25zOiB7XHJcbiAgICAgICAgICAgICAgICAgICRwdXNoOiB7XHJcbiAgICAgICAgICAgICAgICAgICAgX2lkOiAnJGl0ZW0nLFxyXG4gICAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlOiAnJF9pZC5jaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZScsXHJcbiAgICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlOiAnJF9pZC5jaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGUnXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJyxcclxuICAgICAgICAgICAgICAgIHZhcmlhdGlvbnM6ICckdmFyaWF0aW9ucydcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIF1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIC8vIGxldCByZXNNb25nbyA9IGF3YWl0IGN1ci50b0FycmF5KClcclxuICAgICAgICAvLyByZXR1cm4gcmVzTW9uZ29cclxuXHJcbiAgICAgICAgLy8g44Oq44Kv44Ko44K544OI44Oc44OH44KjXHJcbiAgICAgICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgICAgIGxldCBpdGVtID0gYXdhaXQgY3VyLm5leHQoKVxyXG5cclxuICAgICAgICAgIC8vIOWcqOW6q+OCkuioreWumuOBmeOCi1xyXG4gICAgICAgICAgZm9yIChsZXQgZSBvZiBpdGVtLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICAgICAgZS5zdG9jayA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGUuX2lkKVxyXG4gICAgICAgICAgICBkZWxldGUgZS5faWRcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAvL1xyXG4gICAgICAgICAgLy8g5Zyo5bqr5pu05paw44Oq44Kv44Ko44K544OIXHJcbiAgICAgICAgICBsZXQgYXBpID0gbmV3IFdvd21hQXBpKGNvbmZpZy53b3dtYUFwaVBvc3QsIGNvbmZpZy5zaG9wSWQpXHJcbiAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKFtpdGVtXSlcclxuICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKHJlcylcclxuICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgICBjdXIuY2xvc2UoKVxyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDllYblk4HmpJzntKJcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uc2VhcmNoSXRlbWBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dPV01BISDllYblk4Hmg4XloLHlj5blvpcnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyBBUEnjgYvjgonlj5blvpfjgZfjgZ/llYblk4Hmg4XloLHjgpLkv53lrZjjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L2l0ZW1zXyR7KG5ldyBEYXRlKCkpLmdldFRpbWUoKX1gXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyDjg6HjgqTjg7Pjg6vjg7zjg5dcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdUQVJHRVQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgb3B0aW9ucyA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoY29uZmlnLndvd21hQXBpKSlcclxuICAgICAgICAgICAgb3B0aW9ucy51cmkgPSBgJHtvcHRpb25zLnVyaX0vc2VhcmNoSXRlbUluZm9gXHJcbiAgICAgICAgICAgIG9wdGlvbnMucXMuaXRlbUNvZGUgPSBpdGVtLm1hbGwud293bWEuaXRlbUNvZGVcclxuXHJcbiAgICAgICAgICAgIGxldCByZXBvcyA9IGF3YWl0IHJlcXVlc3Qob3B0aW9ucylcclxuICAgICAgICAgICAgbGV0IGZpbGVuYW1lID0gYCR7d29ya2Rpcn0vJHtpdGVtLm1vZGVsfS54bWxgXHJcblxyXG4gICAgICAgICAgICBhd2FpdCBmc0V4dHJhLndyaXRlRmlsZShmaWxlbmFtZSwgcmVwb3MpXHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgV293bWFBcGlJdGVtRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5jb25zdCB0YWcgPSAnd293bWFBcGknXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUHllYblk4Hmg4XloLHlj5blvpdcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZ2V0SXRlbWBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dPV01BISDllYblk4Hmg4XloLHlj5blvpcnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IFdvd21hQXBpSXRlbUZpbHRlcihjb25maWcud293bWFBcGksIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICAvLyB0cnkge1xyXG4gICAgICAgIC8vICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICAvLyB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyAvLyBBUEnjgYvjgonlj5blvpfjgZfjgZ/llYblk4Hmg4XloLHjgpLkv53lrZjjgZnjgovloLTmiYBcclxuICAgICAgICAvLyBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L2l0ZW1zXyR7KG5ldyBEYXRlKCkpLmdldFRpbWUoKX1gXHJcbiAgICAgICAgLy8gLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgLy8gdHJ5IHtcclxuICAgICAgICAvLyAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuICAgICAgICAvLyB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyDjg6HjgqTjg7Pjg6vjg7zjg5dcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdUQVJHRVQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoaXRlbSlcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgUGFja2V0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9wYWNrZXQnXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IGljb252IGZyb20gJ2ljb252LWxpdGUnXHJcbmltcG9ydCBhcmNoaXZlciBmcm9tICdhcmNoaXZlcidcclxuaW1wb3J0IGNzdiBmcm9tICdjc3YnXHJcbmltcG9ydCB7IFBhc3NUaHJvdWdoLCBUcmFuc2Zvcm0gfSBmcm9tICdzdHJlYW0nXHJcblxyXG5jb25zdCBwcmVmaXggPSAncGFja2V0J1xyXG5jb25zdCB0YWcgPSAneWF1Y3QnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Y+X5rOo44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm9yZGVyYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44Ok44OV44Kq44Kv5Y+X5rOoJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vb3JkZXJgXHJcbiAgICAgICAgY29uc3QgciA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlckxvYWRmaWxlfWApXHJcbiAgICAgICAgY29uc3QgdyA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJTYXZlZmlsZX1gKVxyXG4gICAgICAgIHIucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC5waXBlKGNzdi5wYXJzZSh7Y29sdW1uczogdHJ1ZX0pKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnRyYW5zZm9ybShcclxuICAgICAgICAgICAgYXN5bmMgKHJlY29yZCwgY2FsbGJhY2spID0+IHtcclxuICAgICAgICAgICAgICBsZXQgZXJyID0gbnVsbFxyXG4gICAgICAgICAgICAgIC8vIOeuoeeQhueVquWPt+OCkue9ruOBjeaPm+OBiOOCi1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICByZWNvcmRbJ+euoeeQhueVquWPtyddID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0TW9kZWxDbGFzcyhyZWNvcmRbJ+euoeeQhueVquWPtyddKVxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIGVyciA9IGVcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgY2FsbGJhY2soZXJyLCByZWNvcmQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICkpXHJcbiAgICAgICAgICAucGlwZShjc3Yuc3RyaW5naWZ5KHtoZWFkZXI6IHRydWV9KSlcclxuICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLnBpcGUodylcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Ye65ZOB44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliaXRgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lh7rlk4EnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDnubDjgorov5TjgZflh6bnkIbjgpLku7vmhI/jga7vvIhwYWNrZXRTaXpl77yJ44Gn5YiG5YmyXHJcbiAgICAgICAgY29uc3QgcGFja2V0ID0gbmV3IFBhY2tldChjb25maWcucGFja2V0U2l6ZSlcclxuXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44KS5L2c5oiQ44GX55S75YOP44OH44O844K/44KS5Y+O6ZuG44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS93b3JrYFxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEucmVtb3ZlKHdvcmtkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG5cclxuICAgICAgICAvLyBaSVDjg5XjgqHjgqTjg6vjgpLkv53lrZjjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB1cGxvYWRkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vdXBsb2FkYFxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEucmVtb3ZlKHVwbG9hZGRpcilcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHVwbG9hZGRpcilcclxuXHJcbiAgICAgICAgbGV0IGNkID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jjg5Xjgqnjg6vjg4BcclxuICAgICAgICBsZXQgZmlsZW5hbWUgPSBudWxsIC8vIGNzduODleOCoeOCpOODq1xyXG4gICAgICAgIGxldCBuYW1lID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jnlarlj7dcclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kj44O844Or44OJ44KS5a6a576p44GX44CB6aCG55Wq44KS56K65a6a44GZ44KLXHJcbiAgICAgICAgbGV0IGZpZWxkcyA9IFsn566h55CG55Wq5Y+3JywgJ+OCq+ODhuOCtOODqicsICfjgr/jgqTjg4jjg6snLCAn6Kqs5piOJywgJ+OCueODiOOCouWGheWVhuWTgeaknOe0oueUqOOCreODvOODr+ODvOODiScsICfplovlp4vkvqHmoLwnLCAn5Y2z5rG65L6h5qC8JywgJ+WApOS4i+OBkuS6pOa4iScsICflgIvmlbAnLCAn5YWl5pyt5YCL5pWw5Yi26ZmQJywgJ+acn+mWkycsICfntYLkuobmmYLplpMnLCAn5ZWG5ZOB55m66YCB5YWD44Gu6YO96YGT5bqc55yMJywgJ+WVhuWTgeeZuumAgeWFg+OBruW4guWMuueUuuadkScsICfpgIHmlpnosqDmi4UnLCAn5Luj6YeR5YWI5omV44GE44CB5b6M5omV44GEJywgJ+iQveacreODiuODk+axuua4iOaWueazleioreWumicsICfllYblk4Hjga7nirbmhYsnLCAn5ZWG5ZOB44Gu54q25oWL5YKZ6ICDJywgJ+i/lOWTgeOBruWPr+WQpicsICfov5Tlk4Hjga7lj6/lkKblgpnogIMnLCAn55S75YOPMScsICfnlLvlg48x44Kz44Oh44Oz44OIJywgJ+eUu+WDjzInLCAn55S75YOPMuOCs+ODoeODs+ODiCcsICfnlLvlg48zJywgJ+eUu+WDjzPjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNCcsICfnlLvlg48044Kz44Oh44Oz44OIJywgJ+eUu+WDjzUnLCAn55S75YOPNeOCs+ODoeODs+ODiCcsICfnlLvlg482JywgJ+eUu+WDjzbjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNycsICfnlLvlg48344Kz44Oh44Oz44OIJywgJ+eUu+WDjzgnLCAn55S75YOPOOOCs+ODoeODs+ODiCcsICfnlLvlg485JywgJ+eUu+WDjznjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMTAnLCAn55S75YOPMTDjgrPjg6Hjg7Pjg4gnLCAn5pyA5L2O6KmV5L6hJywgJ+aCquipleWJsuWQiOWItumZkCcsICflhaXmnK3ogIXoqo3oqLzliLbpmZAnLCAn6Ieq5YuV5bu26ZW3JywgJ+aXqeacn+e1guS6hicsICfllYblk4Hjga7oh6rli5Xlho3lh7rlk4EnLCAn6Ieq5YuV5YCk5LiL44GSJywgJ+acgOS9juiQveacreS+oeagvCcsICfjg4Hjg6Pjg6rjg4bjgqPjg7wnLCAn5rOo55uu44Gu44Kq44O844Kv44K344On44OzJywgJ+WkquWtl+ODhuOCreOCueODiCcsICfog4zmma/oibInLCAn44K544OI44Ki44Ob44OD44OI44Kq44O844Kv44K344On44OzJywgJ+ebrueri+OBoeOCouOCpOOCs+ODsycsICfotIjnrZTlk4HjgqLjgqTjgrPjg7MnLCAnVOODneOCpOODs+ODiOOCquODl+OCt+ODp+ODsycsICfjgqLjg5XjgqPjg6rjgqjjgqTjg4jjgqrjg5fjgrfjg6fjg7MnLCAn6I2354mp44Gu5aSn44GN44GVJywgJ+iNt+eJqeOBrumHjemHjycsICfjga/jgZNCT09OJywgJ+OBneOBruS7lumFjemAgeaWueazlTEnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTInLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTMnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTQnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTUnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTYnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTcnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTgnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTknLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTEwJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+a1t+WklueZuumAgScsICfphY3pgIHmlrnms5Xjg7vpgIHmlpnoqK3lrponLCAn5Luj5byV5omL5pWw5paZ6Kit5a6aJywgJ+a2iOiyu+eojuioreWumicsICdKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ11cclxuICAgICAgICBsZXQgaGVhZGVyID0gZmllbGRzLm1hcCh2ID0+IGBcIiR7dn1cImApLmpvaW4oJywnKSArICdcXG4nXHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMlumWi+Wni+aZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldFN0YXJ0ID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBuYW1lID0gcHJlZml4ICsgKCcwMDAwMCcgKyBwYWNrZXRDb3VudCkuc2xpY2UoLTUpXHJcbiAgICAgICAgICBjZCA9IGAke3dvcmtkaXJ9LyR7bmFtZX1gXHJcbiAgICAgICAgICBmaWxlbmFtZSA9IGAke2NkfS8ke2NvbmZpZy5jc3ZGaWxlTmFtZX1gXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNkKVxyXG4gICAgICAgICAgLy8gQ1NW44OV44Kh44Kk44Or44Gr44OV44Kj44O844Or44OJ44KS6Kit5a6a44GZ44KLXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShoZWFkZXIsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMluaZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldCA9IGFzeW5jIChhcmcpID0+IHtcclxuICAgICAgICAgIGxldCB5YXVjdCA9IGFyZy55YXVjdFxyXG4gICAgICAgICAgbGV0IGl0ZW0gPSBhcmcuaXRlbVxyXG4gICAgICAgICAgLy8gY3N244OV44Kh44Kk44Or44Gr44Os44Kz44O844OJ77yI5ZWG5ZOB44OG44Oz44OX44Os44O844OI77yJ44KS6L+95Yqg44GZ44KLXHJcbiAgICAgICAgICBsZXQgcmVjb3JkID0gZmllbGRzLm1hcCh2ID0+IHsgcmV0dXJuIHlhdWN0W3ZdID8gYFwiJHt5YXVjdFt2XX1cImAgOiAnXCJcIicgfSkuam9pbignLCcpICsgJ1xcbidcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKHJlY29yZCwgJ1NoaWZ0X0pJUycpKVxyXG4gICAgICAgICAgLy8g55S75YOP44OV44Kh44Kk44Or44KS44Kz44OU44O8XHJcbiAgICAgICAgICBmb3IgKGxldCBpbWcgb2YgaXRlbS5pbWFnZXMpIHtcclxuICAgICAgICAgICAgbGV0IGltZ1NyYyA9IGAke2NvbmZpZy5pbWFnZWRpcn0vJHtpbWd9YFxyXG4gICAgICAgICAgICBsZXQgaW1nVGd0ID0gYCR7Y2R9LyR7aW1nfWBcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAvLyDlkIzjgZjjg5XjgqHjgqTjg6vjgYzjgYLjgovloLTlkIjjga/jgrPjg5Tjg7zjgZfjgarjgYRcclxuICAgICAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFjY2VzcyhpbWdUZ3QpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBhd2FpdCBmc0V4dHJhLmNvcHlGaWxlKGltZ1NyYywgaW1nVGd0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jntYLkuobmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXRFbmQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcclxuICAgICAgICAgIGNvbnN0IHppcCA9IGFyY2hpdmVyKCd6aXAnKVxyXG4gICAgICAgICAgY29uc3QgemlwbmFtZSA9IGAke3VwbG9hZGRpcn0vJHtuYW1lfS56aXBgXHJcbiAgICAgICAgICBjb25zdCBvdXRwdXQgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKHppcG5hbWUpXHJcbiAgICAgICAgICB6aXAucGlwZShvdXRwdXQpXHJcbiAgICAgICAgICB6aXAuZGlyZWN0b3J5KGNkLCBmYWxzZSlcclxuICAgICAgICAgIHppcC5maW5hbGl6ZSgpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg6HjgqTjg7Pjg6vjg7zjg5dcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdUQVJHRVQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgLy8gaXRlbeOBq+Wumue+qeOBleOCjOOBpuOBhOOCi+acgOS9juW/heimgeWcqOW6q+OCiOOCiuWkmuOBhOWVhuWTgeOCkuWHuuWTgeOBmeOCi1xyXG4gICAgICAgICAgICBpZiAocXVhbnRpdHkgPj0gaXRlbS5tYWxsLnlhdWN0Lm1pblF1YW50aXR5KSB7XHJcbiAgICAgICAgICAgICAgbGV0IHlhdWN0ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1ZYXVjdChjb25maWcuZGVmYXVsdCwgaXRlbSlcclxuICAgICAgICAgICAgICBhd2FpdCBwYWNrZXQuc3VibWl0KHt5YXVjdDogeWF1Y3QsIGl0ZW06IGl0ZW19KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcGFja2V0LmNsb3NlKClcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0ICcuLi9pbXBvcnRzL2NvbGxlY3Rpb25zJ1xyXG5pbXBvcnQgJy4vcm91dGUvdXBsb2FkL2ltYWdlJ1xyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCc7XHJcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0JztcclxuaW1wb3J0IHsgR3JvdXBCYXNlIH0gZnJvbSAnLi9ncm91cHMnO1xyXG5cclxuY29uc3QgRmlsdGVycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdmaWx0ZXJzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBGaWx0ZXIgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcihmaWx0ZXJJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gRmlsdGVycy5maW5kT25lKHtcclxuICAgICAgX2lkOiBmaWx0ZXJJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG5cclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jICggb25SZXN1bHQgPSAocmVjb3JkKT0+e30sIG9uRXJyb3IgPSAoZSk9Pnt9ICkgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgb25FcnJvcik7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsYXRmb3JtIHR5cGUnKTtcclxuXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge3sgZmlsdGVyVHlwZTogYXN5bmMgKHJlY29yZCApID0+IHt9IH19IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaChjYWxsYmFja3MgPSB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlKCk7XHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgdHlwZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ID0ge307XHJcbiAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgIGNvdW50W2ZpbHRlci50eXBlXSA9IHtcclxuICAgICAgICBxdWVyeTogZmlsdGVyLnF1ZXJ5LFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQpPT57XHJcbiAgICAgICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICAgICAgbGV0IHF1ZXJ5ID0gbW9iamVjdC51bmVzY2FwZShmaWx0ZXIucXVlcnkpO1xyXG4gICAgICAgICAgbGV0IGV4YW0gPSBzaWZ0KCBxdWVyeSApO1xyXG4gICAgICAgICAgaWYoIGV4YW0ocmVjb3JkKSApe1xyXG4gICAgICAgICAgICBjb3VudFtmaWx0ZXIudHlwZV0uY291bnQrKztcclxuICAgICAgICAgICAgaWYoIHR5cGVvZiBjYWxsYmFja3NbZmlsdGVyLnR5cGVdICE9PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2tzW2ZpbHRlci50eXBlXShyZWNvcmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgb25FcnJvclxyXG4gICAgKTtcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50O1xyXG5cclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG5jb25zdCBHcm91cHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZ3JvdXBzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cEJhc2Uge1xyXG5cclxuICBwcm9maWxlO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9maWxlKSB7XHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogZ2V0cyAnUGx1Zycgd2l0Y2ggaXMgYSBzZXQgb2YgcHJvcGVydGllcyBuZWVkZWRcclxuICAgKiB3aGVuIGNvbm5lY3QgdG8gc29tZSBwbGF0Zm9ybXNcclxuICAgKiB0byBnZXQgZGF0YXMoTWVtYmVycyBvZiB0aGUgR3JvdXApXHJcbiAgICovXHJcbiAgZ2V0UGx1ZygpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGUucGxhdGZvcm1QbHVnO1xyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZSgpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHt9O1xyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZ3JvdXBJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gR3JvdXBzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGdyb3VwSWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jIChkb2MpID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9IFdIRVJFIFxcYCR7ZG9jLmtleX1cXGAgPSBcIiR7ZG9jLmlkfVwiYDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgZ3JvdXAgdHlwZScpO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge2FzeW5jIChyZWNvcmQpPT52b2lkfSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBjdXIgPSBHcm91cHMuZmluZCh7XHJcbiAgICAgIGdyb3VwSWQ6IHRoaXMucHJvZmlsZS5faWRcclxuICAgIH0sIHtcclxuICAgICAgZmllbGRzOiB7XHJcbiAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgIGlkOiAxLFxyXG4gICAgICAgIGtleTogMVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBcclxuICAgICAgICBjdXIuZm9yRWFjaChcclxuICAgICAgICAgIGFzeW5jIChkb2MsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlY29yZCA9IGF3YWl0IHRoaXMuaW1wb3J0KGRvYyk7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2socmVjb3JkKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIG9uRXJyb3IoZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGluZGV4ICsgMSA9PT0gY3VyLmNvdW50KCkpIHtcclxuICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgfVxyXG4gICAgKS5jYXRjaChcclxuICAgICAgKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICB9XHJcblxyXG59IiwiaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuXHJcbmV4cG9ydCBjbGFzcyBDdWJlM0FwaSB7XHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge015U1FMfSBteXNxbFxyXG4gICAqL1xyXG4gIGNvbnN0cnVjdG9yIChteXNxbCkge1xyXG4gICAgdGhpcy5teXNxbF8gPSBteXNxbFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2sgKHByb2R1Y3RDbGFzc0lkLCBxdWFudGl0eSA9IDApIHtcclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcclxuICAgICAge30sIHtcclxuICAgICAgICBzdG9jazogcXVhbnRpdHksXHJcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJyxcclxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXHJcbiAgICAgIHt9LCB7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RUYWdVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDliYrpmaTjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvZmYgPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSlcclxuICAgIH1cclxuXHJcbiAgICAvLyDooajnpLrjgZnjgovjgr/jgrBcclxuICAgIGxldCB0YWdvbiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgLy8g44GZ44Gn44Gr6KGo56S644GV44KM44Gm44GE44KL44K/44Kw44GM44GC44KM44Gw5L2V44KC44GX44Gq44GEXHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIFNFTEVDVCBDT1VOVCgqKSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGBcclxuICAgICAgbGV0IGNvdW50UmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKVxyXG4gICAgICBpZiAoY291bnRSZXNbMF1bJ0NPVU5UKCopJ10pIHJldHVyblxyXG5cclxuICAgICAgcmVzLnB1c2goXHJcbiAgICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAnZHRiX3Byb2R1Y3RfdGFnJyxcclxuICAgICAgICAgIHt9LFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBkYXRhLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgICAgIHRhZzogdGFnLFxyXG4gICAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKSlcclxuICAgIH1cclxuXHJcbiAgICBmb3IgKGxldCB0YWdTZXQgb2YgZGF0YS50YWdzKSB7XHJcbiAgICAgIHN3aXRjaCAodGFnU2V0LnNldCkge1xyXG4gICAgICAgIGNhc2UgJ29uJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29uKHRhZ1NldC50YWcpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICAgIGNhc2UgJ29mZic6XHJcbiAgICAgICAgICBhd2FpdCB0YWdvZmYodGFnU2V0LnRhZylcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdEltYWdlVXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgcHJvZHVjdElkID0gZGF0YS5wcm9kdWN0X2lkXHJcbiAgICBsZXQgaW1hZ2VzID0gZGF0YS5pbWFnZXNcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0gW11cclxuXHJcbiAgICAvLyDllYblk4HjgavplqLpgKPjgZnjgovjgZnjgbnjgabjga7nlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgotcclxuICAgIGxldCBzcWwgPSBgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfaW1hZ2UgV0hFUkUgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdElkfWBcclxuICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbCkpXHJcbiAgICAvLyDmlLnjgoHjgabnlLvlg4/jgpLnmbvpjLLjgZfjgarjgYrjgZlcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICdkdGJfcHJvZHVjdF9pbWFnZScsIHtcclxuICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcclxuICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICAgIGZpbGVfbmFtZTogaW1hZ2VzW2ldLFxyXG4gICAgICAgICAgcmFuazogaSArIDFcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBsZXQga2V5cyA9IFtdXHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RcclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnc3RhdHVzJyxcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnbm90ZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9saXN0JyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXHJcbiAgICAgICdzZWFyY2hfd29yZCcsXHJcbiAgICAgICdmcmVlX2FyZWEnXHJcbiAgICBdXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBkdGJfcHJvZHVjdF9jbGFzc1xyXG5cclxuICAgIHVwZGF0ZURhdGEgPSB7fVxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ2RlbGl2ZXJ5X2RhdGVfaWQnLFxyXG4gICAgICAncHJvZHVjdF9jb2RlJyxcclxuICAgICAgJ3NhbGVfbGltaXQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJyxcclxuICAgICAgJ2RlbGl2ZXJ5X2ZlZSdcclxuICAgIF1cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdENyZWF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSB7fVxyXG5cclxuICAgIGxldCB1cGRhdGVEYXRhID0ge31cclxuICAgIGxldCBrZXlzID0gW11cclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnbmFtZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnXHJcbiAgICBdXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgIC8vICAgZGVzY3JpcHRpb25fZGV0YWlsOiBpdGVtLmRlc2NyaXB0aW9uLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBzdGF0dXM6IDEsXHJcbiAgICAgICAgbm90ZTogJ05VTEwnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uX2xpc3Q6ICdOVUxMJyxcclxuICAgICAgICBzZWFyY2hfd29yZDogJ05VTEwnLFxyXG4gICAgICAgIGZyZWVfYXJlYTogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICB1cGRhdGVEYXRhID0ge31cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAncHJvZHVjdF90eXBlX2lkJyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIHByb2R1Y3RfY29kZTogaXRlbS5tb2RlbCxcclxuICAgIC8vICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAvLyAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9jbGFzc19pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHByb2R1Y3RfaWQ6IHJlcy5wcm9kdWN0X2lkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDE6ICdOVUxMJyxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDI6ICdOVUxMJyxcclxuICAgICAgICBkZWxpdmVyeV9kYXRlX2lkOiAnTlVMTCcsXHJcbiAgICAgICAgc2FsZV9saW1pdDogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3Rfc3RvY2tfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJywge30sIHtcclxuICAgICAgICBwcm9kdWN0X2NsYXNzX2lkOiByZXMucHJvZHVjdF9jbGFzc19pZCxcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgc3RvY2s6IDAsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIGZvciB0ZXN0XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNb25nb0NsaWVudH0gZnJvbSAnbW9uZ29kYidcclxuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCdcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnXHJcbmltcG9ydCB7IHhtbDJqcyB9IGZyb20gJ3htbC1qcydcclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlckZhY3Rvcnkge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBsZXQgaW5zdGFuY2VcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICBpbnN0YW5jZSA9IG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGluc3RhbmNlXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnXHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlXHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZmFjdG9yeSAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHJldHVybiBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKVxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbHVnIHR5cGUnKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0UGx1Z18gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Z1xyXG4gIH1cclxuXHJcbiAgZ2V0Q3JlZF8gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Zy5jcmVkXHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlXHJcbiAgfVxyXG5cclxuICBzZXRJbXBvcnRGdW5jdGlvbl8gKFxyXG4gICAgZm4gPSBhc3luYyAob25SZXN1bHQgPSByZWNvcmQgPT4ge30sIG9uRXJyb3IgPSBlID0+IHt9KSA9PiB7fVxyXG4gICkge1xyXG4gICAgdGhpcy5pbXBvcnQgPSBmblxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogdXNlYWdlOlxyXG4gICAqXHJcbiAgICpcclxuICAgKiBAcGFyYW0geyBPYmplY3QgfSBpdGVyYXRvcnMgeyBmaWx0ZXJOYW1lOiBhc3luYyAoZG9jLGNvbnRleHQpPT57fSwgLi4uIH0gaXRlcmF0b3IgZm9yIGVhY2ggZmlsdGVyc1xyXG4gICAqIEBwYXJhbSB7IGFzeW5jIGZ1bmN0aW9uIH0gb25FcnJvciBlcnJvciBoYW5kbGVyIHdoaWxlIGl0ZXJhdGluZ1xyXG4gICAqIEByZXR1cm5zIHsgT2JqZWN0IH0geyBmaWx0ZXJOYW1lOiB7IHF1ZXJ5OiBhbnksIGNvdW50OiBudW1iZXIgfSwgLi4uIH1cclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoIChpdGVyYXRvcnMgPSB7fSkge1xyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGVfKClcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICBuYW1lOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnRlciA9IHt9XHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBmaWx0ZXJzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgICBjb3VudGVyW2YubmFtZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGYucXVlcnksXHJcbiAgICAgICAgbGltaXQ6IHR5cGVvZiBmLmxpbWl0ICE9PSAndW5kZWZpbmVkJyA/IGYubGltaXQgOiAwLFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH1cclxuICAgICAgZmlsdGVycy5wdXNoKFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6IGYubmFtZSxcclxuICAgICAgICAgIGV4YW06IHNpZnQobW9iamVjdC51bmVzY2FwZShmLnF1ZXJ5KSlcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgIGZvciAobGV0IGYgb2YgZmlsdGVycykge1xyXG4gICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXHJcbiAgICAgICAgICBsZXQgYyA9IGNvdW50ZXJbZi5uYW1lXVxyXG4gICAgICAgICAgaWYgKGMubGltaXQpIHtcclxuICAgICAgICAgICAgaWYgKGMuY291bnQgPj0gYy5saW1pdCkge1xyXG4gICAgICAgICAgICAgIGNvbnRpbnVlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZi5leGFtKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXHJcbiAgICAgICAgICAgIGMuY291bnQrK1xyXG5cclxuICAgICAgICAgICAgLy8gaXRlcmF0b3JcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVyYXRvcnNbZi5uYW1lXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICBhd2FpdCBpdGVyYXRvcnNbZi5uYW1lXShyZWNvcmQsIGNvbnRleHQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudGVyXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTXlzcWxEQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKVxyXG5cclxuICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwoY3JlZClcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWBcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgKGUpID0+IHsgdGhyb3cgZSB9KVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuLy8gaW1wb3J0IE1vbmdvTmF0aXZlIGZyb20gJ21vbmdvZGInO1xyXG4vLyBjb25zdCBNb25nb0NsaWVudCA9IE1vbmdvTmF0aXZlLk1vbmdvQ2xpZW50O1xyXG4vLyBjb25zdCBNb25nb0NsaWVudCA9IHJlcXVpcmUoJ21vbmdvZGInKS5Nb25nb0NsaWVudDtcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKVxyXG5cclxuICAgIC8vIG1vbmdvIOOBuOaOpee2mlxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBjbGllbnRcclxuICAgICAgY2xpZW50ID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSlcclxuXHJcbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xyXG4gICAgICBsZXQgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSlcclxuICAgICAgbGV0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbilcclxuXHJcbiAgICAgIGxldCBjb250ZXh0ID0ge1xyXG4gICAgICAgIGNsaWVudDogY2xpZW50LFxyXG4gICAgICAgIGNvbGxlY3Rpb246IGNvbGxlY3Rpb24sXHJcbiAgICAgICAgZGF0YWJhc2U6IGRiXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKVxyXG5cclxuICAgICAgLy8g44Kr44O844K944Or44Gu44K/44Kk44Og44Ki44Km44OI44KS6Kej6ZmkXHJcbiAgICAgIGN1ci5hZGRDdXJzb3JGbGFnKCdub0N1cnNvclRpbWVvdXQnLCB0cnVlKVxyXG5cclxuICAgICAgLy8g44GZ44G544Gm44Gu44OJ44Kt44Ol44Oh44Oz44OI44KS44Or44O844OXXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgICAgIGxldCBkb2MgPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgICAgICBhd2FpdCBvblJlc3VsdChkb2MsIGNvbnRleHQpXHJcbiAgICAgICAgfTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAvLyDjgqvjg7zjgr3jg6vjgpLplovmlL5cclxuICAgICAgICBhd2FpdCBjdXIuY2xvc2UoKVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIFdvd21hQXBpSXRlbUZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICAvLyDllYblk4Hmg4XloLHjga7lj5blvpfjg6vjg7zjg5fjgpLlrprnvqlcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcclxuICAgICAgbGV0IG9wdGlvbnMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHBsdWcpKVxyXG4gICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hTdG9ja3NgXHJcbiAgICAgIGxldCBjb250ZXh0ID0ge1xyXG4gICAgICAgIG9wdGlvbnM6IG9wdGlvbnNcclxuICAgICAgfVxyXG5cclxuICAgICAgd2hpbGUgKDEpIHtcclxuICAgICAgICAvLyBXb3dtYSBBcGkg44GL44KJ5ZWG5ZOB5oOF5aCx44KS5Y+W5b6XXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3Qob3B0aW9ucylcclxuICAgICAgICByZXMgPSB4bWwyanMocmVzLCB7Y29tcGFjdDogdHJ1ZX0pXHJcblxyXG4gICAgICAgIGxldCBtYXhDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0Lm1heENvdW50Ll90ZXh0KVxyXG4gICAgICAgIGxldCByZXN1bHRDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0LnJlc3VsdENvdW50Ll90ZXh0KVxyXG4gICAgICAgIGxldCBzdGFydENvdW50ID0gTnVtYmVyKHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQuc3RhcnRDb3VudC5fdGV4dClcclxuICAgICAgICBsZXQgcmVzdWx0U3RvY2tzID0gcmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5yZXN1bHRTdG9ja3NcclxuXHJcbiAgICAgICAgLy8g5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS44Kr44K544K/44Og44OX44Ot44K744K544Gr5rih44GZXHJcbiAgICAgICAgaWYgKHJlc3VsdFN0b2NrcyBpbnN0YW5jZW9mIEFycmF5KSB7XHJcbiAgICAgICAgICAvLyDlj5blvpfjgZfjgZ/jg4fjg7zjgr/jgYzopIfmlbDllYblk4Hjga7loLTlkIhcclxuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0Q291bnQ7IGkrKykge1xyXG4gICAgICAgICAgICBhd2FpdCBvblJlc3VsdChyZXN1bHRTdG9ja3NbaV0sIGNvbnRleHQpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIC8vIOWPluW+l+OBl+OBn+ODh+ODvOOCv+OBjOWNmOaVsOWVhuWTgeOBruWgtOWQiFxyXG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQocmVzdWx0U3RvY2tzLCBjb250ZXh0KVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgbGV0IG5leHQgPSBzdGFydENvdW50ICsgcmVzdWx0Q291bnRcclxuXHJcbiAgICAgICAgaWYgKG5leHQgPiBtYXhDb3VudCkgYnJlYWtcclxuICAgICAgICBvcHRpb25zLnFzLnN0YXJ0Q291bnQgPSBuZXh0XHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbi8vICAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xyXG4vLyAgICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XHJcblxyXG4vLyAgICAgLy8gbW9uZ28g44G45o6l57aaXHJcbi8vICAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuLy8gICAgIGxldCBjb251cmkgPSBgbW9uZ29kYjovLyR7Y3JlZC5ob3N0fToke2NyZWQucG9ydH0vJHtjcmVkLmRhdGFiYXNlfWA7XHJcbi8vICAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KGNvbnVyaSk7XHJcblxyXG4vLyAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5L2c44KLXHJcbi8vICAgICBsZXQgY29sbGVjdGlvbiA9IG1vbmdvb3NlLmNvbm5lY3Rpb24uY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG5cclxuLy8gICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4vLyAgICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XHJcblxyXG4vLyAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH1cclxuLy8gfVxyXG4iLCJpbXBvcnQgeyBNb25nb0NvbGxlY3Rpb24gfSBmcm9tICcuLi91dGlsL21vbmdvJ1xyXG5pbXBvcnQgeyBVcGxvYWRzLCBSb2JvdGluU2hvcCB9IGZyb20gJy4uL2NvbGxlY3Rpb25zJ1xyXG5pbXBvcnQgVGV4dFV0aWwgZnJvbSAnLi4vdXRpbC90ZXh0J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSXRlbUNvbnRyb2xsZXIge1xyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHt7dXJpOnN0cmluZywgZGF0YWJhc2U6c3RyaW5nLCBjb2xsZWN0aW9uOnN0cmluZ319IHBsdWdcclxuICAgKi9cclxuICBhc3luYyBpbml0IChwbHVnKSB7XHJcbiAgICB0aGlzLkl0ZW1zID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCAnaXRlbXMnKVxyXG4gICAgdGhpcy5Qcm9kdWN0cyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ3Byb2R1Y3RzJylcclxuICB9XHJcblxyXG4gIGFzeW5jIGdldFN0b2NrIChpdGVtSWQpIHtcclxuICAgIGxldCBpdGVtID0gYXdhaXQgdGhpcy5JdGVtcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBpdGVtSWRcclxuICAgIH0sIHtcclxuICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICdwcm9kdWN0JzogMVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gICAgbGV0IHByb2R1Y3RTZXQgPSBpdGVtLnByb2R1Y3RcclxuXHJcbiAgICAvLyBwcm9kdWN0ICogPC0+ICogaXRlbVxyXG4gICAgLy8gcHJvZHVjdFtdOiDopIfmlbDjga7llYblk4HjgpIx44OR44OD44Kx44O844K444Go44GX44Gm6LKp5aOyXHJcbiAgICAvLyBwcm9kdWN0W3tpZHM6WzxPYmplY3RJZD5dLHNldDo8TnVtYmVyPn1dOiDnlbDjgarjgovmtYHpgJrntYzot6/jgIHnlbDjgarjgovljp/kvqHjg7vku5XlhaXjgozlgKRcclxuICAgIC8vIGl0ZW06IOeVsOOBquOCi+OCu+ODvOODq+OAgeiyqeWjsuW9ouaFi1xyXG4gICAgLy8g4oC7IHByb2R1Y3Qg44GL44KJ44Gv44CB6LKp5aOy5Y+v6IO944Gq5Zyo5bqr44CB5Yip55uK6KiI566X44Gu44Gf44KB44Gu5oOF5aCx44KS5b6X44KLXHJcblxyXG4gICAgbGV0IHF1YW50aXRpZXMgPSBbXVxyXG5cclxuICAgIGZvciAobGV0IHByb2R1Y3RSZWYgb2YgcHJvZHVjdFNldCkge1xyXG4gICAgICBsZXQgcHJkUXVhbnRpdHkgPSAwXHJcblxyXG4gICAgICBmb3IgKGxldCBpZCBvZiBwcm9kdWN0UmVmLmlkcykge1xyXG4gICAgICAgIGxldCBwcm9kdWN0ID0gYXdhaXQgdGhpcy5Qcm9kdWN0cy5maW5kT25lKHtcclxuICAgICAgICAgIF9pZDogaWRcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBwcm9qZWN0aW9uOiB7XHJcbiAgICAgICAgICAgICdzdG9jayc6IDFcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIGxldCBzdG9ja0FycmF5ID0gcHJvZHVjdC5zdG9ja1xyXG5cclxuICAgICAgICAvLyDljZjntJTjgavjgZnjgbnjgabjga7lnKjluqvllYblk4HjgIHnn63mnJ/plpPlj5bjgorlr4TjgZvlj6/og73llYblk4HjgpLlkIjnrpdcclxuICAgICAgICBmb3IgKGxldCBzdG9jayBvZiBzdG9ja0FycmF5KSB7XHJcbiAgICAgICAgICBwcmRRdWFudGl0eSArPSBzdG9jay5xdWFudGl0eVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgLy8g5ZWG5ZOBKGl0ZW0p44Gu5Zyo5bqr5pWwID0g6KO95ZOB5Zyo5bqr5pWwKHByZFF1YW50aXR5KSAvIOW/heimgeOCu+ODg+ODiOaVsChwcm9kdWN0UmVmLnNldClcclxuICAgICAgcXVhbnRpdGllcy5wdXNoKE1hdGguZmxvb3IocHJkUXVhbnRpdHkgLyBwcm9kdWN0UmVmLnNldCkpXHJcbiAgICB9XHJcblxyXG4gICAgLy8g44K744OD44OI5ZWG5ZOB44Gu5aC05ZCI44CB5LiA55Wq5bCR44Gq44GE5ZWG5ZOB5pWw44Gr5ZCI44KP44Gb44KLXHJcbiAgICBsZXQgcXVhbnRpdHkgPSBNYXRoLm1pbi5hcHBseShudWxsLCBxdWFudGl0aWVzKVxyXG5cclxuICAgIHJldHVybiBxdWFudGl0eVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOCi+OAglxyXG4gICAqXHJcbiAgICog44Oh44O844Kr44O844Oi44OH44Or44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXHJcbiAgICogY2xhc3Mx44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXHJcbiAgICpcclxuICAgKiDnibnlrprjga7lsZ7mgKfvvIjjgqvjg6njg7zjgarjganvvInjgavlhbHpgJrjga7nlLvlg4/jgpLkuIDmi6zjgafplqLpgKPku5jjgZHjgZ/jgYTloLTlkIjjgIFcclxuICAgKiBjbGFzczHjgavlgKTjgpLmjIflrprjgZfjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcclxuICAgKiDjgoLjgZdjbGFzczLjga7jgb/mjIflrprjgZfjgZ/jgYTloLTlkIjjga9jbGFzczHjgatudWxs44KS5oyH5a6a44GZ44KL44CCXHJcbiAgICpcclxuICAgKiDkvovvvJpKSy0xMDDjga5CTEFDS+OBruWVhuWTgeeUu+WDj+OCklxyXG4gICAqIOOBmeOBueOBpuOBruOCteOCpOOCuu+8iFMsTSxMLFhMLDJYTCwzWEwsNFhM4oCm77yJ44Gr6Zai6YCj5LuY44GR44KL5aC05ZCIXHJcbiAgICogc2V0SW1hZ2UoIHVwbG9hZElkLCAnSkstMTAwJywgJ0JMQUNLJyApO1xyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHVwbG9hZElkIOS4gOWbnuOBruOCouODg+ODl+ODreODvOODieeUu+WDj+OCkuadn+OBreOBpuOBhOOCi0lE44CCbWV0ZW9y44OH44O844K/44OZ44O844K544CBVXBsb2Fkc+OCs+ODrOOCr+OCt+ODp+ODs+WGheODieOCreODpeODoeODs+ODiOOBrnVwbG9hZElk44OX44Ot44OR44OG44KjXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKi9cclxuICBhc3luYyBzZXRJbWFnZSAodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jga7mg4XloLHlj5blvpdcclxuICAgIGxldCBpbWFnZXMgPSBVcGxvYWRzLmZpbmQoe1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWRcclxuICAgIH0pLmZldGNoKCkubWFwKCh2KSA9PiB2LnVwbG9hZGVkRmlsZU5hbWUpXHJcblxyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge31cclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsXHJcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxXHJcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLCB7XHJcbiAgICAgICAgJHB1c2g6IHtcclxuICAgICAgICAgIGltYWdlczoge1xyXG4gICAgICAgICAgICAkZWFjaDogaW1hZ2VzXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8g55m76Yyy44GX44Gf55S75YOP44OV44Kh44Kk44Or5ZCN5LiA6KanXHJcbiAgICByZXR1cm4gaW1hZ2VzXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr55m76Yyy44GV44KM44Gm44GE44KL55S75YOP5oOF5aCx44KS5YmK6Zmk44GZ44KL44CCXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIGNsZWFuSW1hZ2UgKG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcclxuICAgIGxldCBmaWx0ZXIgPSB7fVxyXG4gICAgZmlsdGVyLm1vZGVsID0gbW9kZWxcclxuICAgIGlmIChjbGFzczEpIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczFcclxuICAgIGlmIChjbGFzczIpIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczJcclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5JdGVtcy51cGRhdGVNYW55KFxyXG4gICAgICBmaWx0ZXIsIHtcclxuICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICBpbWFnZXM6IFtdXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiDmjIflrprjga7llYblk4HjgavplqLpgKPjgZnjgovllYblk4HnvqTjga7lsZ7mgKfliKXjga7llYblk4Hmg4XloLHjgpLov5TjgZnjgIJcclxuICAgKlxyXG4gICAqIOW8leaVsOOBqOOBl+OBpuWPl+OBkeWPluOCi2l0ZW3jga/ku7vmhI/jga7llYblk4Hmg4XloLHjgIJcclxuICAgKiBpdGVt44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gr44Gk44GE44Gm5b+F6KaB44Gq5oOF5aCx44KS5pW055CG44GX6L+U44GZ44CCXHJcbiAgICpcclxuICAgKiBwcm9qZWN044Gr5Y+C54Wn44GX44Gf44GE5ZWG5ZOB5oOF5aCx44OV44Kj44O844Or44OJ44KS5a6a576p44GZ44KL44CCXHJcbiAgICog44Oh44K944OD44OJ44Gu5ZG844Gz5Ye644GX5pmC44Gr5b+F6KaB44Gr5b+c44GY44GmcHJvamVjdOOCkuioreWumuOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog5L2V44Gr5rOo55uu44GX44Gm5ZWG5ZOB44Gu6Zai6YCj5oCn44KS5qSc5Ye644GZ44KL44GL44Gv44CB44GT44Gu44Oh44K944OD44OJ5YaF44Gn5a6a576p44GZ44KL44CCXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge09iamVjdH0gaXRlbVxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBwcm9qZWN0XHJcbiAgICovXHJcbiAgYXN5bmMgZ2V0VmFyaWF0aW9uIChpdGVtLCBwcm9qZWN0KSB7XHJcbiAgICAvKipcclxuICAgICAqIGFnZ3JlZ2F0aW9u6Kit5a6aXHJcbiAgICAgKlxyXG4gICAgICogbGFiZWw6IOWxnuaAp+WQje+8iOmFjemAgeaWueazleOAgeOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqe+8iVxyXG4gICAgICogY3VycmVudDog5oyH5a6a44GV44KM44Gf44Ki44Kk44OG44Og77yIaXRlbe+8ieOBjOipsuW9k+OBmeOCi+mgheebrlxyXG4gICAgICogcG9yamVjdDog44OQ44Oq44Ko44O844K344On44Oz5qSc57Si44Gu44Kt44O844Go44Gq44KLaXRlbeWGheOBruODleOCo+ODvOODq+ODieWQjSAkW+ODleOCo+ODvOODq+ODieWQjV3lvaLlvI9cclxuICAgICAqIHF1ZXJ5OiBhZ2dyZWdhdGlvbuWvvuixoeOBqOOBmeOCi+ODieOCreODpeODoeODs+ODiOOBruaknOe0ouadoeS7tlxyXG4gICAgICovXHJcbiAgICBsZXQgc2V0ID0gW3tcclxuICAgICAgbGFiZWw6ICfphY3pgIHmlrnms5UnLFxyXG4gICAgICBjdXJyZW50OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgdmFsdWU6ICckZGVsaXZlcnknXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgY2xhc3MxX3ZhbHVlOiBpdGVtLmNsYXNzMV92YWx1ZSxcclxuICAgICAgICBjbGFzczJfdmFsdWU6IGl0ZW0uY2xhc3MyX3ZhbHVlXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBpdGVtLmNsYXNzMV9uYW1lLFxyXG4gICAgICBjdXJyZW50OiBpdGVtLmNsYXNzMV92YWx1ZSxcclxuICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgIHZhbHVlOiAnJGNsYXNzMV92YWx1ZSdcclxuICAgICAgfSxcclxuICAgICAgcXVlcnk6IHtcclxuICAgICAgICBkZWxpdmVyeTogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgICBjbGFzczJfdmFsdWU6IGl0ZW0uY2xhc3MyX3ZhbHVlXHJcbiAgICAgIH1cclxuICAgIH0sXHJcbiAgICB7XHJcbiAgICAgIGxhYmVsOiBpdGVtLmNsYXNzMl9uYW1lLFxyXG4gICAgICBjdXJyZW50OiBpdGVtLmNsYXNzMl92YWx1ZSxcclxuICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgIHZhbHVlOiAnJGNsYXNzMl92YWx1ZSdcclxuICAgICAgfSxcclxuICAgICAgcXVlcnk6IHtcclxuICAgICAgICBkZWxpdmVyeTogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgICBjbGFzczFfdmFsdWU6IGl0ZW0uY2xhc3MxX3ZhbHVlXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIF1cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBbXVxyXG5cclxuICAgIGZvciAobGV0IHMgb2Ygc2V0KSB7XHJcbiAgICAgIGF0dHJzLnB1c2goe1xyXG4gICAgICAgIHZhcmlhdGlvbnM6IGF3YWl0IHRoaXMuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW3tcclxuICAgICAgICAgICAgJG1hdGNoOiBPYmplY3QuYXNzaWduKHMucXVlcnksIHtcclxuICAgICAgICAgICAgICBtb2RlbDogaXRlbS5tb2RlbFxyXG4gICAgICAgICAgICB9KVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgJHByb2plY3Q6IE9iamVjdC5hc3NpZ24ocy5wcm9qZWN0LCBwcm9qZWN0KVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgJHNvcnQ6IHtcclxuICAgICAgICAgICAgICBfaWQ6IDFcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgICkudG9BcnJheSgpLFxyXG4gICAgICAgIHByb3BzOiBzXHJcbiAgICAgIH0pXHJcbiAgICB9XHJcblxyXG4gICAgZm9yIChsZXQgYXR0ciBvZiBhdHRycykge1xyXG4gICAgICBmb3IgKGxldCB2IG9mIGF0dHIudmFyaWF0aW9ucykge1xyXG4gICAgICAgIHYuc3RvY2sgPSBhd2FpdCB0aGlzLmdldFN0b2NrKHYuX2lkKVxyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGF0dHJzXHJcbiAgfVxyXG5cclxuICAvLyDjg6Ljg4fjg6vjgq/jg6njgrnlvaLlvI/jgpLkvZzjgotcclxuICAvLyBb44Oh44O844Kr44O844Kz44O844OJXS9b5bGe5oCnMe+8iOOCq+ODqeODvOOBquOBqe+8iV0vW+WxnuaApzLvvIjjgrXjgqTjgrrjgarjganvvIldXHJcbiAgYXN5bmMgZ2V0TW9kZWxDbGFzcyAoYXJnKSB7XHJcbiAgICBsZXQgaXRlbVxyXG4gICAgLy8gaXRlbSDjgYzmloflrZfliJfjgarjgonjgIFpdGVt44Gv5Lu75oSP44Gu44Kq44OW44K444Kn44Kv44OISUTjga7mnKvlsL7jgYvjgonku7vmhI/jga7moYHmlbDjga4xNumAsuaVsFxyXG4gICAgaWYgKHR5cGVvZiBhcmcgPT09ICdzdHJpbmcnKSB7XHJcbiAgICAgIGxldCBleHAgPSBuZXcgUmVnRXhwKGAke2FyZ30kYClcclxuICAgICAgbGV0IGN1ciA9IHRoaXMuSXRlbXMuZmluZCh7fSwge1xyXG4gICAgICAgIHByb2plY3Rpb246IHtcclxuICAgICAgICAgIG1vZGVsOiAxLFxyXG4gICAgICAgICAgY2xhc3MxX3ZhbHVlOiAxLFxyXG4gICAgICAgICAgY2xhc3MyX3ZhbHVlOiAxXHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgICAgd2hpbGUgKDEpIHtcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgaXRlbSA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgICAgIGxldCBtYXRjaCA9IGF3YWl0IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkubWF0Y2goZXhwKVxyXG4gICAgICAgICAgaWYgKG1hdGNoKSB7XHJcbiAgICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgLy8g6Kmy5b2T44GZ44KLaXRlbeODh+ODvOOCv+OBjOOBquOBhFxyXG4gICAgICAgICAgY3VyLmNsb3NlKClcclxuICAgICAgICAgIHJldHVybiBhcmdcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICAgY3VyLmNsb3NlKClcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIGl0ZW0gPSBhcmdcclxuICAgIH1cclxuXHJcbiAgICBsZXQgbW9kZWxDbGFzcyA9IFtdXHJcbiAgICBpZiAoaXRlbS5tb2RlbCkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0ubW9kZWwpXHJcbiAgICBpZiAoaXRlbS5jbGFzczFfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMV92YWx1ZSlcclxuICAgIGlmIChpdGVtLmNsYXNzMl92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MyX3ZhbHVlKVxyXG4gICAgcmV0dXJuIG1vZGVsQ2xhc3Muam9pbignLycpXHJcbiAgfVxyXG5cclxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzIChjcmVhdG9ySWQsIGl0ZW0pIHtcclxuICAgIC8vIOWApOWkieaPm1xyXG4gICAgbGV0IGNvbnZEZWxpdiA9IChkZWxpdmVyeSkgPT4gZGVsaXZlcnkgPT09ICfjgobjgYbjg5HjgrHjg4Pjg4gnID8gJ+ODneOCueODiOaKleWHvScgOiBkZWxpdmVyeVxyXG5cclxuICAgIC8vIHByb2R1Y3RfaWRcclxuICAgIGxldCBwcm9kdWN0SWQgPSBudWxsXHJcbiAgICBsZXQgbW9kZWxDbGFzcyA9IFtdXHJcblxyXG4gICAgLy8g5LiL6KiY44Gu5b2i5byP44KS5L2c44KLXHJcbiAgICAvLyBb44Oh44O844Kr44O844Kz44O844OJXS9b5bGe5oCnMe+8iOOCq+ODqeODvOOBquOBqe+8iV0vW+WxnuaApzLvvIjjgrXjgqTjgrrjgarjganvvIldXHJcbiAgICBpZiAoaXRlbS5tb2RlbCkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0ubW9kZWwpXHJcbiAgICBpZiAoaXRlbS5jbGFzczFfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMV92YWx1ZSlcclxuICAgIGlmIChpdGVtLmNsYXNzMl92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MyX3ZhbHVlKVxyXG5cclxuICAgIC8vIOWVhuWTgeeoruWIpeOCkuWJsuOCiuW9k+OBpuOCi1xyXG4gICAgbGV0IHByb2R1Y3RUeXBlSWRcclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMlxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDFcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeOCv+OCsOOCkuioreWumuOBmeOCi1xyXG4gICAgbGV0IHRhZ3MgPSBbXVxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgdGFncy5wdXNoKHtcclxuICAgICAgICAgIHRhZzogNCxcclxuICAgICAgICAgIHNldDogJ29uJ1xyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIHRhZzogNSxcclxuICAgICAgICAgIHNldDogJ29mZidcclxuICAgICAgICB9KVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgdGFncy5wdXNoKHtcclxuICAgICAgICAgIHRhZzogNSxcclxuICAgICAgICAgIHNldDogJ29uJ1xyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIHRhZzogNCxcclxuICAgICAgICAgIHNldDogJ29mZidcclxuICAgICAgICB9KVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB5Yil6YCB5paZ44KS6Kit5a6a44GZ44KLXHJcbiAgICBsZXQgZGVsaXZlcnlGZWUgPSBudWxsXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICBkZWxpdmVyeUZlZSA9IG51bGxcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIGRlbGl2ZXJ5RmVlID0gMjQwXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvL1xyXG4gICAgLy8g6aGn5a6i5ZCR44GR44OQ44Oq44Ko44O844K344On44Oz5ZWG5ZOB6YG45oqe5qmf6IO944Gu5a6f6KOFXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBhdHRycyA9IGF3YWl0IHRoaXMuZ2V0VmFyaWF0aW9uKGl0ZW0sIHtcclxuICAgICAgcHJvZHVjdF9pZDogJyRtYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfaWQnXHJcbiAgICB9KVxyXG5cclxuICAgIC8vIEhUTUwg44OQ44Oq44Ko44O844K344On44Oz5ZWG5ZOB44GU44Go44Gu44Oq44Oz44Kv5LuY44GN44Oc44K/44Oz44KS6KGo56S644GZ44KLXHJcblxyXG4gICAgLy8g5YCk44Gu5aSJ5o+bXHJcbiAgICBhdHRycyA9IGF0dHJzLm1hcChcclxuICAgICAgKGF0dHIpID0+IHtcclxuICAgICAgICBhdHRyLnByb3BzLmN1cnJlbnQgPSBjb252RGVsaXYoYXR0ci5wcm9wcy5jdXJyZW50KVxyXG4gICAgICAgIGF0dHIudmFyaWF0aW9ucyA9IGF0dHIudmFyaWF0aW9ucy5tYXAoXHJcbiAgICAgICAgICAodmFyaWF0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgIHZhcmlhdGlvbi52YWx1ZSA9IGNvbnZEZWxpdih2YXJpYXRpb24udmFsdWUpXHJcbiAgICAgICAgICAgIHJldHVybiB2YXJpYXRpb25cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgICAgcmV0dXJuIGF0dHJcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIEhUTUznlJ/miJBcclxuICAgIGxldCB2YXJpYXRpb25IdG1sID1cclxuICAgICAgYXR0cnMubWFwKFxyXG4gICAgICAgIChhdHRyKSA9PlxyXG4gICAgICAgICAgJzxkaXYgY2xhc3M9XCJjb250YWluZXItZmx1aWRcIj4nICtcclxuICAgICAgICBgPGRpdiBjbGFzcz1cInJvd1wiPmAgK1xyXG4gICAgICAgIGA8ZGl2IHN0eWxlPVwib3BhY2l0eTowLjNcIiBjbGFzcz1cImJ0biBidG4taW5mbyBidG4tYmxvY2sgYnRuLXhzXCI+YCArXHJcbiAgICAgICAgYDxzdHJvbmc+JHthdHRyLnByb3BzLmxhYmVsfTwvc3Ryb25nPmAgK1xyXG4gICAgICAgIGA8L2Rpdj5gICtcclxuICAgICAgICBhdHRyLnZhcmlhdGlvbnMubWFwKFxyXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoYXR0ci5wcm9wcy5jdXJyZW50ID09PSB2YXJpYXRpb24udmFsdWUpIHtcclxuICAgICAgICAgICAgICAvLyDooajnpLrkuK3jga7llYblk4Hjg5zjgr/jg7NcclxuICAgICAgICAgICAgICByZXR1cm4gYDxidXR0b24gY2xhc3M9XCJidG4gYnRuLXN1Y2Nlc3MgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPjxzdHJvbmc+JHt2YXJpYXRpb24udmFsdWV9PC9zdHJvbmc+PC9idXR0b24+YFxyXG4gICAgICAgICAgICB9IGVsc2VcclxuICAgICAgICAgICAgaWYgKHZhcmlhdGlvbi5zdG9jayA+IDApIHtcclxuICAgICAgICAgICAgICAvLyDosqnlo7Llj6/og73llYblk4Hjga7jg5zjgr/jg7NcclxuICAgICAgICAgICAgICByZXR1cm4gYDxhIGhyZWY9XCIvcHJvZHVjdHMvZGV0YWlsLyR7dmFyaWF0aW9uLnByb2R1Y3RfaWR9XCI+PGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICAvLyDosqnlo7LkuI3lj6/og73llYblk4Hjga7jg5zjgr/jg7PvvIjlnKjluqvjgarjgZfvvIlcclxuICAgICAgICAgICAgICByZXR1cm4gYDxidXR0b24gY2xhc3M9XCJidG4gYnRuLWRlZmF1bHQgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiIHN0eWxlPVwib3BhY2l0eTowLjNcIiBkYXRhLXRvZ2dsZT1cInRvb2x0aXBcIiB0aXRsZT1cIuWcqOW6q+OBjOOBlOOBluOBhOOBvuOBm+OCk1wiPiR7dmFyaWF0aW9uLnZhbHVlfTwvYnV0dG9uPmBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICkuam9pbignJykgK1xyXG4gICAgICAgICc8L2Rpdj4nICtcclxuICAgICAgICAnPC9kaXY+J1xyXG4gICAgICApLmpvaW4oJycpXHJcblxyXG4gICAgbGV0IGRlc2NyaXB0aW9uRGV0YWlsID0gYFxyXG4gICAgPHNtYWxsPuKAuyDphY3pgIHmlrnms5Xjg7vjgqvjg6njg7zjg7vjgrXjgqTjgrrjga/kuIvoqJjjgYvjgonjgYrpgbjjgbPjgY/jgaDjgZXjgYTjgII8L3NtYWxsPlxyXG4gICAgJHt2YXJpYXRpb25IdG1sfVxyXG4gICAgYFxyXG5cclxuICAgIC8vIOWVhuWTgeODh+ODvOOCv+OCkuS9nOOCi1xyXG4gICAgbGV0IGRhdGEgPSB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcclxuICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICBuYW1lOiBgJHttb2RlbENsYXNzLmpvaW4oJy8nKX0gJHtjb252RGVsaXYoaXRlbS5kZWxpdmVyeSl9ICR7aXRlbS5uYW1lfSR7aXRlbS5qYW5fY29kZSA/ICcgJyArIGl0ZW0uamFuX2NvZGUgOiAnJ31gLFxyXG4gICAgICBkZXNjcmlwdGlvbl9kZXRhaWw6IGRlc2NyaXB0aW9uRGV0YWlsLFxyXG4gICAgICAvLyBmcmVlX2FyZWE6IGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZUZyZWVBcmVhKGl0ZW0pLFxyXG4gICAgICBwcm9kdWN0X2NvZGU6IG1vZGVsQ2xhc3Muam9pbignLycpLFxyXG4gICAgICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcclxuICAgICAgLy8gcHJpY2UwMjogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlUHJpY2UwMihpdGVtKSxcclxuICAgICAgLy8gaW1hZ2VzOiBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVJbWFnZXMoaXRlbSksXHJcbiAgICAgIHByb2R1Y3RfdHlwZV9pZDogcHJvZHVjdFR5cGVJZCxcclxuICAgICAgdGFnczogdGFncyxcclxuICAgICAgZGVsaXZlcnlfZmVlOiBkZWxpdmVyeUZlZVxyXG4gICAgfVxyXG5cclxuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlRnJlZUFyZWEoaXRlbSkpXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZVByaWNlMDIoaXRlbSkpXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZUltYWdlcyhpdGVtKSlcclxuXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcClcclxuXHJcbiAgICByZXR1cm4gZGF0YVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlM2NyZWF0ZUZyZWVBcmVhIChpdGVtKSB7XHJcbiAgICBsZXQgZnJlZUFyZWEgPSAnJ1xyXG4gICAgLy8g5ZWG5ZOB5oOF5aCx44OG44Kt44K544OI44KS6KiY6LyJ44GZ44KLXHJcbiAgICBmcmVlQXJlYSArPSBpdGVtLmRlc2NyaXB0aW9uXHJcbiAgICAvLyAy55Wq55uu5Lul6ZmN44Gu55S75YOP44KS44OV44Oq44O844Ko44Oq44Ki44Gr6KiY6LyJ44GZ44KLXHJcbiAgICBmb3IgKGxldCBpID0gMTsgaSA8IGl0ZW0uaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGZyZWVBcmVhICs9IGA8aW1nIHNyYz1cIi91cGxvYWQvc2F2ZV9pbWFnZS8ke2l0ZW0uaW1hZ2VzW2ldfVwiPjxicj5gXHJcbiAgICB9XHJcbiAgICAvLyDmg4XloLHjga7jgq/jg6rjgqJcclxuICAgIGZyZWVBcmVhICs9ICcgJ1xyXG4gICAgcmV0dXJuIHtmcmVlX2FyZWE6IGZyZWVBcmVhfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlM2NyZWF0ZVByaWNlMDIgKGl0ZW0pIHtcclxuICAgIC8vIOS+oeagvOOCkui/lOOBmVxyXG4gICAgcmV0dXJuIHtwcmljZTAyOiBpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJpY2V9XHJcbiAgfVxyXG5cclxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzY3JlYXRlSW1hZ2VzIChpdGVtKSB7XHJcbiAgICAvLyDnlLvlg4/jg6rjgrnjg4jjga7jgYbjgaEx44Gk44KB44Gg44GR44KS6L+U44GZXHJcbiAgICBsZXQgYXJyID0gdHlwZW9mIGl0ZW0uaW1hZ2VzWzBdID09PSAndW5kZWZpbmVkJyA/IFtdIDogWyBpdGVtLmltYWdlc1swXSBdXHJcbiAgICByZXR1cm4geyBpbWFnZXM6IGFyciB9XHJcbiAgfVxyXG5cclxuICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjgbjjga7lpInmj5tcclxuICBhc3luYyBjb252ZXJ0SXRlbVlhdWN0MSAoY29uZmlnLCBpdGVtKSB7XHJcbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtWWF1Y3QoY29uZmlnLmRlZmF1bHQsIGl0ZW0pXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjgbjjga7lpInmj5tcclxuICBhc3luYyBjb252ZXJ0SXRlbVlhdWN0IChkZWYsIGl0ZW0pIHtcclxuICAgIGNvbnN0IGlkTGVuZ3RoID0gMjBcclxuICAgIGNvbnN0IHRpdGxlTGVuZ3RoID0gMTMwXHJcblxyXG4gICAgbGV0IHlhdWN0ID0ge31cclxuICAgIC8vIOODpOODleOCquOCr+ODhuODs+ODl+ODrOODvOODiOOBruWIneacn+WApO+8iOOChuOBhuODkeOCseODg+ODiOODu+WuhemFjeS+v+OBp+eVsOOBquOCi++8iVxyXG4gICAgeWF1Y3QgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGRlZltpdGVtLmRlbGl2ZXJ5XSkpXHJcblxyXG4gICAgLy8g55S75YOP44Gu6KiY6L+wXHJcbiAgICBjb25zdCBpbWdQcmVmaXggPSAn55S75YOPJ1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtLmltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICB5YXVjdFtpbWdQcmVmaXggKyAoaSArIDEpXSA9IGl0ZW0uaW1hZ2VzW2ldXHJcbiAgICB9XHJcblxyXG4gICAgLy8g44K/44Kk44OI44OrXHJcbiAgICB5YXVjdFsn44Kr44OG44K044OqJ10gPSBpdGVtLm1hbGwueWF1Y3QuY2F0ZWdvcnlcclxuICAgIHlhdWN0Wyfjgr/jgqTjg4jjg6snXSA9IFRleHRVdGlsLnN1YnN0cjgoYCR7YXdhaXQgdGhpcy5nZXRNb2RlbENsYXNzKGl0ZW0pfSAke2l0ZW0uZGVsaXZlcnl9ICR7aXRlbS5uYW1lfWAsIHRpdGxlTGVuZ3RoKVxyXG4gICAgeWF1Y3RbJ+mWi+Wni+S+oeagvCddID0gaXRlbS5zYWxlc19wcmljZVxyXG4gICAgeWF1Y3RbJ+WNs+axuuS+oeagvCddID0gaXRlbS5zYWxlc19wcmljZVxyXG4gICAgeWF1Y3RbJ+euoeeQhueVquWPtyddID0gaXRlbS5faWQudG9IZXhTdHJpbmcoKS5zbGljZSgtaWRMZW5ndGgpXHJcbiAgICBpZiAodHlwZW9mIHlhdWN0WyfoqqzmmI4nXSA9PT0gJ3N0cmluZycpIHtcclxuICAgICAgeWF1Y3RbJ+iqrOaYjiddID0gYCR7aXRlbS5kZXNjcmlwdGlvbn08YnI+PGJyPiR7eWF1Y3RbJ+iqrOaYjiddfWBcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHlhdWN0WyfoqqzmmI4nXSA9IGl0ZW0uZGVzY3JpcHRpb25cclxuICAgIH1cclxuICAgIHlhdWN0WydKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ10gPSBpdGVtLmphbl9jb2RlXHJcblxyXG4gICAgcmV0dXJuIHlhdWN0XHJcbiAgfVxyXG5cclxuICBhc3luYyBjb252ZXJ0SXRlbVdvd21hQ3JlYXRlRGVsaXZlcnlNZXRob2QgKGl0ZW1Db2RlKSB7XHJcbiAgICBsZXQgaWQgPSAnbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgIGxldCBzZXQgPSAnZGVsaXZlcnknXHJcbiAgICBsZXQgbWV0cmljcyA9IHtcclxuICAgICAgJ+OChuOBhuODkeOCseODg+ODiCc6IFsnUG9zdCddLFxyXG4gICAgICAn5a6F6YWN5L6/JzogWydZVS1QYWNrJywgJ0thbmdhcm9vJ11cclxuICAgIH1cclxuICAgIC8vIGRlbGl2ZXJ5TWV0aG9kU2VxXHJcblxyXG4gICAgbGV0IGFnZ3IgPSBhd2FpdCB0aGlzLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgW1xyXG4gICAgICAgIHtcclxuICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICBbaWRdOiBpdGVtQ29kZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgIF9pZDogYCQke2lkfWAsXHJcbiAgICAgICAgICAgIFtzZXRdOiB7ICRhZGRUb1NldDogYCQke3NldH1gIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIHtcclxuICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgIF9pZDogMCxcclxuICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJyxcclxuICAgICAgICAgICAgW3NldF06IGAkJHtzZXR9YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgXVxyXG4gICAgKS50b0FycmF5KClcclxuXHJcbiAgICBsZXQgYWNjZXB0RGVsaXYgPSBbXVxyXG4gICAgZm9yIChsZXQgZGVsIG9mIGFnZ3JbMF0uZGVsaXZlcnkpIHtcclxuICAgICAgYWNjZXB0RGVsaXYgPSBhY2NlcHREZWxpdi5jb25jYXQobWV0cmljc1tgJHtkZWx9YF0pXHJcbiAgICB9XHJcbiAgICBsZXQgZGVsaXZlcnlNZXRob2QgPSBuZXcgQXJyYXkoNSlcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgZGVsaXZlcnlNZXRob2QubGVuZ3RoOyBpKyspIHtcclxuICAgICAgbGV0IGlkID0gdHlwZW9mIGFjY2VwdERlbGl2W2ldID09PSAndW5kZWZpbmVkJyA/ICdOVUxMJyA6IGFjY2VwdERlbGl2W2ldXHJcbiAgICAgIGRlbGl2ZXJ5TWV0aG9kW2ldID0ge2RlbGl2ZXJ5TWV0aG9kU2VxOiBpICsgMSwgZGVsaXZlcnlNZXRob2RJZDogaWR9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtkZWxpdmVyeU1ldGhvZDogZGVsaXZlcnlNZXRob2R9XHJcbiAgfVxyXG5cclxuICAvL1xyXG4gIC8vIFJvYm90LWluIOWklumDqOmAo+aQuuWVhuWTgeeVquWPt+OBrueZu+mMsuOBruOBn+OCgeOBruODh+ODvOOCv+OCkuS9nOOCi1xyXG4gIC8vIOOBneOBrjEgaXRlbS5jc3ZcclxuXHJcbiAgc3RhdGljIGNvbnZlcnRJdGVtUm9ib3Rpbkl0ZW0gKGl0ZW0pIHtcclxuICAgIHJldHVybiB7XHJcbiAgICAgICfjgrPjg7Pjg4jjg63jg7zjg6vjgqvjg6njg6AnOiAnbicsXHJcbiAgICAgICfmlrDopo/nmbvpjLJJRCc6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXHJcbiAgICAgICfllYblk4FJRCc6IG51bGwsXHJcbiAgICAgICfllYblk4HlkI0nOiBgJHtpdGVtLm1vZGVsfSR7aXRlbS5jbGFzczFfdmFsdWUgPT09ICcnID8gJycgOiAnLycgKyBpdGVtLmNsYXNzMV92YWx1ZX0ke2l0ZW0uY2xhc3MyX3ZhbHVlID09PSAnJyA/ICcnIDogJy8nICsgaXRlbS5jbGFzczJfdmFsdWV9YCxcclxuICAgICAgJ+imj+agvCc6ICfjgarjgZcnXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL1xyXG4gIC8vIFJvYm90LWluIOWklumDqOmAo+aQuuWVhuWTgeeVquWPt+OBrueZu+mMsuOBruOBn+OCgeOBruODh+ODvOOCv+OCkuS9nOOCi1xyXG4gIC8vIOOBneOBrjIgc2VsZWN0LmNzdlxyXG5cclxuICBzdGF0aWMgY29udmVydEl0ZW1Sb2JvdGluU2VsZWN0IChpdGVtKSB7XHJcbiAgICBsZXQgc2VsZWN0ID0ge1xyXG4gICAgICAn44Kz44Oz44OI44Ot44O844Or44Kr44Op44OgJzogJ24nLFxyXG4gICAgICAn5paw6KaP55m76YyySUQnOiBpdGVtLl9pZC50b0hleFN0cmluZygpLFxyXG4gICAgICAn5ZWG5ZOBSUQnOiBudWxsLFxyXG4gICAgICAn5aSW6YOo6YCj5pC6SUQnOiBudWxsLFxyXG4gICAgICAn5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+3JzogaXRlbS5faWQudG9IZXhTdHJpbmcoKVxyXG4gICAgfVxyXG5cclxuICAgIGNvbnN0IHNob3BzID0gUm9ib3RpblNob3AuZmluZCgpXHJcblxyXG4gICAgc2hvcHMuZm9yRWFjaChcclxuICAgICAgKGRvYywgaW5kZXgpID0+IHtcclxuICAgICAgICBsZXQgbW9kZWwsIGNsYXNzMSwgY2xhc3MyXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIC8vIOODouODvOODq+OBruWVhuWTgeeVquWPt+OCkueJueWumuOBmeOCi1xyXG4gICAgICAgICAgbW9kZWwgPSBpdGVtLm1hbGxbYCR7ZG9jLm5hbWV9YF1bYCR7ZG9jLm1vZGVsUGF0aH1gXVxyXG4gICAgICAgICAgbW9kZWwgPSB0eXBlb2YgbW9kZWwgPT09ICd1bmRlZmluZWQnID8gJycgOiBtb2RlbFxyXG4gICAgICAgICAgY2xhc3MxID0gaXRlbS5tYWxsW2Ake2RvYy5uYW1lfWBdW2Ake2RvYy5jbGFzczFQYXRofWBdXHJcbiAgICAgICAgICBjbGFzczEgPSB0eXBlb2YgY2xhc3MxID09PSAndW5kZWZpbmVkJyA/ICcnIDogY2xhc3MxXHJcbiAgICAgICAgICBjbGFzczIgPSBpdGVtLm1hbGxbYCR7ZG9jLm5hbWV9YF1bYCR7ZG9jLmNsYXNzMlBhdGh9YF1cclxuICAgICAgICAgIGNsYXNzMiA9IHR5cGVvZiBjbGFzczIgPT09ICd1bmRlZmluZWQnID8gJycgOiBjbGFzczJcclxuICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAvLyDllYblk4Hjga7jg6Ljg7zjg6vmg4XloLHjga7lj5blvpfjgavlpLHmlZfjgZfjgZ/vvIjjg4fjg7zjgr/jgYzoqK3lrprjgZXjgozjgabjgYTjgarjgYTjgarjganvvIlcclxuICAgICAgICAgIC8vIG1vZGVsID0gaXRlbS5tb2RlbFxyXG4gICAgICAgICAgLy8gY2xhc3MxID0gaXRlbS5jbGFzczFfdmFsdWVcclxuICAgICAgICAgIC8vIGNsYXNzMiA9IGl0ZW0uY2xhc3MyX3ZhbHVlXHJcbiAgICAgICAgICByZXR1cm5cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIHNlbGVjdFtg5Y+X5rOo5ZWG5ZOBSURfJHtpbmRleH1gXSA9IG51bGxcclxuICAgICAgICBzZWxlY3RbYOW6l+iIl0lEXyR7aW5kZXh9YF0gPSBkb2NbJ+W6l+iIl0lEJ11cclxuICAgICAgICBzZWxlY3RbYOW6l+iIl+WQjV8ke2luZGV4fWBdID0gZG9jLm5hbWVcclxuICAgICAgICBzZWxlY3RbYOWPl+azqOWVhuWTgeeVquWPt18ke2luZGV4fWBdID0gYCR7bW9kZWx9JHtjbGFzczF9JHtjbGFzczJ9YFxyXG4gICAgICAgIHNlbGVjdFtg5pyJ5Yq544OV44Op44KwXyR7aW5kZXh9YF0gPSAn5pyJ5Yq5J1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHNlbGVjdFxyXG4gIH1cclxuXHJcbiAgLy9cclxuICAvLyBSb2JvdC1pbiDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7fjga7nmbvpjLLjga7jgZ/jgoHjga7jg4fjg7zjgr/jgpLkvZzjgotcclxuICAvLyDjgZ3jga4zIHNlbGVjdFNob3AuY3N2XHJcblxyXG4gIHN0YXRpYyBjb252ZXJ0SXRlbVJvYm90aW5TZWxlY3RTaG9wIChzaG9wLCBpdGVtKSB7XHJcbiAgICBjb25zdCBtb2RlbCA9IGl0ZW0ubWFsbFtgJHtzaG9wLm5hbWV9YF1bYCR7c2hvcC5tb2RlbFBhdGh9YF1cclxuICAgIGNvbnN0IGNsYXNzMSA9IGl0ZW0ubWFsbFtgJHtzaG9wLm5hbWV9YF1bYCR7c2hvcC5jbGFzczFQYXRofWBdXHJcbiAgICBjb25zdCBjbGFzczIgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AuY2xhc3MyUGF0aH1gXVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgICfjgrPjg7Pjg4jjg63jg7zjg6vjgqvjg6njg6AnOiAndScsXHJcbiAgICAgICfmlrDopo/nmbvpjLJJRCc6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXHJcbiAgICAgICflj5fms6jllYblk4FJRCc6IG51bGwsXHJcbiAgICAgICflupfoiJdJRCc6IHNob3BbJ+W6l+iIl0lEJ10sXHJcbiAgICAgICflupfoiJflkI0nOiBudWxsLFxyXG4gICAgICAn5Y+X5rOo5ZWG5ZOB55Wq5Y+3JzogYCR7bW9kZWx9JHtjbGFzczF9JHtjbGFzczJ9YCxcclxuICAgICAgJ+acieWKueODleODqeOCsCc6ICfmnInlirknXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xyXG5pbXBvcnQgVGV4dFV0aWwgZnJvbSAnLi4vdXRpbC90ZXh0J1xyXG5pbXBvcnQgeyBJdGVtQ29udHJvbGxlciB9IGZyb20gJy4vaXRlbXMnXHJcbmltcG9ydCB7IE9iamVjdElEIH0gZnJvbSAnYnNvbidcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFJvYm90aW4ge1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMuT3JkZXIgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbihudWxsKVxyXG4gIH1cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7Kn0gZG9jT3JkZXJcclxuICAgKiBAcGFyYW0ge0l0ZW1Db250cm9sbGVyfSBpdGVtU1xyXG4gICAqL1xyXG4gIGFzeW5jIGltcG9ydE9yZGVyIChkb2NPcmRlciwgaXRlbVMpIHtcclxuICAgIC8vIOWVhuWTgeeVquWPt+OCkm1vbmdvSWTjgajjgZfjgabmpJzntKLjgZfjgIHoqbLlvZPjgZnjgotpdGVt44GM44GC44KM44Gw5pu444GN5o+b44GI44KLXHJcbiAgICBpZiAoT2JqZWN0SUQuaXNWYWxpZChkb2NPcmRlclsn5ZWG5ZOB44Kz44O844OJJ10pKSB7XHJcbiAgICAgIGNvbnN0IGl0ZW0gPSBhd2FpdCBpdGVtUy5JdGVtcy5maW5kT25lKHtfaWQ6IG5ldyBPYmplY3RJRChkb2NPcmRlclsn5ZWG5ZOB44Kz44O844OJJ10pfSlcclxuICAgICAgaWYgKGl0ZW0pIHtcclxuICAgICAgICBkb2NPcmRlclsn5ZWG5ZOB44Kz44O844OJJ10gPSBhd2FpdCBpdGVtUy5nZXRNb2RlbENsYXNzKGl0ZW0pXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIC8vIOWPl+azqOODh+ODvOOCv+OCkuODh+ODvOOCv+ODmeODvOOCueOBq+S/neWtmFxyXG4gICAgdGhpcy5PcmRlci5pbnNlcnQoZG9jT3JkZXIpXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7Kn0gZG9jTGFiZWxcclxuICAgKiBAcGFyYW0ge0FycmF5fSB3cml0ZUl0ZW1Db2RlVG9cclxuICAgKi9cclxuICB0cmFuc2Zvcm1MYWJlbFNlaW5vIChkb2NMYWJlbCwgbGFiZWxPcHRpb25zKSB7XHJcbiAgICAvLyDllYblk4HjgrPjg7zjg4njgpLpgIHjgornirZDU1bjgavln4vjgoHovrzjgoBcclxuICAgIC8vXHJcblxyXG4gICAgLy8g5Y+X5rOo55Wq5Y+344KS5oq95Ye6XHJcbiAgICBjb25zdCBvcmRlck51bWJlciA9IGRvY0xhYmVsWzMyXSAvLyAzM+eVquebruOBrumgheebruOAjOiomOS6i++8keOAjVxyXG5cclxuICAgIC8vIOWPl+azqENTVuOBi+OCieW6l+iIl+WQjeOBqOWPl+azqOeVquWPt+OCkuOCreODvOOBq+WVhuWTgeOCs+ODvOODieS4gOimp+OCkuWPluW+l+OBmeOCi1xyXG4gICAgY29uc3QgY3VyID0gdGhpcy5PcmRlci5maW5kKHtcclxuICAgICAgJ+W6l+iIl+WQjSc6IGRvY0xhYmVsWzExXSwgLy8gMTLnlarnm67jga7poIXnm67jgIzojbfpgIHkurrlkI3np7DjgI1cclxuICAgICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXHJcbiAgICAgICflj5fms6jnlarlj7cnOiB7ICRpbjogWyBvcmRlck51bWJlciwgTnVtYmVyKG9yZGVyTnVtYmVyKSBdIH1cclxuICAgIH0sIHtmaWVsZHM6IHtcclxuICAgICAgX2lkOiAwLFxyXG4gICAgICAn5ZWG5ZOB44Kz44O844OJJzogMVxyXG4gICAgfX0pXHJcblxyXG4gICAgLy8g6YCB44KK54q244Os44Kz44O844OJ44Gr6Kmy5b2T44GZ44KL5Y+X5rOo44Os44Kz44O844OJ44GM6KaL44Gk44GL44KJ44Gq44GE5aC05ZCIXHJcbiAgICBpZiAoIWN1ci5jb3VudCgpKSB0aHJvdyBuZXcgRXJyb3IoJ+mAgeOCiueKtuOBq+WvvuW/nOOBmeOCi+WPl+azqOOBjOimi+OBpOOBi+OCiuOBvuOBm+OCk+OAgkNTVuODleOCoeOCpOODq+OCkueiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicpXHJcblxyXG4gICAgLy8g6YCB44KK54q244Gu55m66YCB5ZWG5ZOB44Kz44O844OJ5LiA6Kan44KS6YWN5YiX44Gr44GZ44KLXHJcbiAgICBjb25zdCBpdGVtcyA9IGN1ci5mZXRjaCgpXHJcblxyXG4gICAgLy8gZG9jTGFiZWwgOiDlhaXlipvpgIHjgornirbjg4fjg7zjgr9cclxuICAgIC8vIGNvbkxhYmVsIDog5Ye65Yqb55So6YCB44KK54q244OH44O844K/XHJcbiAgICBsZXQgY29uTGFiZWwgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGRvY0xhYmVsKSlcclxuXHJcbiAgICAvLyB3cml0ZUl0ZW1Db2RlVG8g77yI5LiA44Gk44Gu6YCB44KK54q244Gr6KiY6LyJ44Gn44GN44KL5ZWG5ZOB44Kz44O844OJ44Gu5pyA5aSn5pWw77yJ44Gu57eP5pWw44KI44KK44CB5Y+X5rOo44OH44O844K/44Gu5ZWG5ZOB5pWw44GM5aSa44GE5aC05ZCI44Gv44Ko44Op44O8XHJcbiAgICBjb25zdCB3cml0ZUl0ZW1Db2RlVG8gPSBsYWJlbE9wdGlvbnMud3JpdGVJdGVtQ29kZVRvXHJcbiAgICBpZiAod3JpdGVJdGVtQ29kZVRvLmxlbmd0aCA8IGl0ZW1zLmxlbmd0aCkge1xyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYOmAgeOCiueKtuODh+ODvOOCv+OBq+iomOi8ieOBp+OBjeOCi+WVhuWTgeaVsOOBryR7d3JpdGVJdGVtQ29kZVRvLmxlbmd0aH3lgIvjgb7jgafjgafjgZlgKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOWumuaVsOOBruWfi+OCgei+vOOBv1xyXG4gICAgbGFiZWxPcHRpb25zLmNvbnN0LmZvckVhY2goZSA9PiB7XHJcbiAgICAgIGNvbkxhYmVsW2UuY29sdW1uXSA9IGUudmFsdWVcclxuICAgIH0pXHJcblxyXG4gICAgLy8g6YCB44KK54q244OH44O844K/44Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6Yyy44GZ44KLXHJcbiAgICBpdGVtcy5mb3JFYWNoKChlLCBpKSA9PiB7XHJcbiAgICAgIGNvbkxhYmVsW3dyaXRlSXRlbUNvZGVUb1tpXV0gPSBlWyfllYblk4HjgrPjg7zjg4knXVxyXG4gICAgfSlcclxuXHJcbiAgICAvLyDkvY/miYDmloflrZfliJfjga7liIblibLjgpLkv67mraPjgZnjgotcclxuICAgIC8vIGtleVMg44Gn5oyH5a6a44GV44KM44GfIHRhcmdldCDlhoXjga7opoHntKDjga7lgKTjgpLjgIFsZW5ndGjvvIjjg5DjgqTjg4jplbfvvInjgafliIblibLjgZflho3mp4vnr4njgZnjgotcclxuICAgIC8vIGxlbmd0aO+8iOODkOOCpOODiOmVt++8ieOCkui2heOBiOOCi+aWh+Wtl+WIl+OBr+OAgeWNiuinkuOCueODmuODvOOCueOBp+WIhuWJsuOBmeOCi1xyXG4gICAgVGV4dFV0aWwuc3BsaXRsZW5iKGNvbkxhYmVsLCBbMTIsIDEzXSwgNDApIC8vIOmgheebrjEz44CM6I236YCB5Lq65L2P5omA77yR44CN44CB6aCF55uuMTTjgIzojbfpgIHkurrkvY/miYDvvJLjgI1cclxuICAgIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWzIxLCAyMl0sIDYwKSAvLyDpoIXnm64yMuOAjOOBiuWxiuOBkeWFiOS9j+aJgO+8keOAjeOAgemgheebrjIz44CM44GK5bGK44GR5YWI5L2P5omA77yS44CNXHJcbiAgICByZXR1cm4gY29uTGFiZWxcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHsqfSBkb2NMYWJlbFxyXG4gICAqIEBwYXJhbSB7QXJyYXl9IHdyaXRlSXRlbUNvZGVUb1xyXG4gICAqL1xyXG4gIHRyYW5zZm9ybUxhYmVsWXVwYWNrIChkb2NMYWJlbCwgbGFiZWxPcHRpb25zKSB7XHJcbiAgICAvLyDllYblk4HjgrPjg7zjg4njgpLpgIHjgornirZDU1bjgavln4vjgoHovrzjgoBcclxuICAgIC8vXHJcblxyXG4gICAgLy8g5Y+X5rOo55Wq5Y+344KS5oq95Ye6XHJcbiAgICBjb25zdCBvcmRlck51bWJlciA9IGRvY0xhYmVsWyfoqJjkuovlkI3vvJEnXS5yZXBsYWNlKCflj5fms6jnlarlj7fvvJonLCAnJylcclxuXHJcbiAgICAvLyDlj5fms6hDU1bjgYvjgonlupfoiJflkI3jgajlj5fms6jnlarlj7fjgpLjgq3jg7zjgavllYblk4HjgrPjg7zjg4nkuIDopqfjgpLlj5blvpfjgZnjgotcclxuICAgIGNvbnN0IGN1ciA9IHRoaXMuT3JkZXIuZmluZCh7XHJcbiAgICAgICflupfoiJflkI0nOiBkb2NMYWJlbFsn44GU5L6d6aC85Li7IOWQjeensDEnXSxcclxuICAgICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXHJcbiAgICAgICflj5fms6jnlarlj7cnOiB7ICRpbjogWyBvcmRlck51bWJlciwgTnVtYmVyKG9yZGVyTnVtYmVyKSBdIH1cclxuICAgIH0sIHtmaWVsZHM6IHtcclxuICAgICAgX2lkOiAwLFxyXG4gICAgICAn5ZWG5ZOB44Kz44O844OJJzogMVxyXG4gICAgfX0pXHJcblxyXG4gICAgLy8g6YCB44KK54q244Os44Kz44O844OJ44Gr6Kmy5b2T44GZ44KL5Y+X5rOo44Os44Kz44O844OJ44GM6KaL44Gk44GL44KJ44Gq44GE5aC05ZCIXHJcbiAgICBpZiAoIWN1ci5jb3VudCgpKSB0aHJvdyBuZXcgRXJyb3IoJ+mAgeOCiueKtuOBq+WvvuW/nOOBmeOCi+WPl+azqOOBjOimi+OBpOOBi+OCiuOBvuOBm+OCk+OAgkNTVuODleOCoeOCpOODq+OCkueiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicpXHJcblxyXG4gICAgLy8g6YCB44KK54q244Gu55m66YCB5ZWG5ZOB44Kz44O844OJ5LiA6Kan44KS6YWN5YiX44Gr44GZ44KLXHJcbiAgICBjb25zdCBpdGVtcyA9IGN1ci5mZXRjaCgpXHJcblxyXG4gICAgLy8gZG9jTGFiZWwgOiDlhaXlipvpgIHjgornirbjg4fjg7zjgr9cclxuICAgIC8vIGNvbkxhYmVsIDog5Ye65Yqb55So6YCB44KK54q244OH44O844K/XHJcbiAgICBsZXQgY29uTGFiZWwgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGRvY0xhYmVsKSlcclxuXHJcbiAgICAvLyB3cml0ZUl0ZW1Db2RlVG8g77yI5LiA44Gk44Gu6YCB44KK54q244Gr6KiY6LyJ44Gn44GN44KL5ZWG5ZOB44Kz44O844OJ44Gu5pyA5aSn5pWw77yJ44Gu57eP5pWw44KI44KK44CB5Y+X5rOo44OH44O844K/44Gu5ZWG5ZOB5pWw44GM5aSa44GE5aC05ZCI44Gv44Ko44Op44O8XHJcbiAgICBjb25zdCB3cml0ZUl0ZW1Db2RlVG8gPSBsYWJlbE9wdGlvbnMud3JpdGVJdGVtQ29kZVRvXHJcbiAgICBpZiAod3JpdGVJdGVtQ29kZVRvLmxlbmd0aCA8IGl0ZW1zLmxlbmd0aCkge1xyXG4gICAgICB0aHJvdyBuZXcgRXJyb3IoYOmAgeOCiueKtuODh+ODvOOCv+OBq+iomOi8ieOBp+OBjeOCi+WVhuWTgeaVsOOBryR7d3JpdGVJdGVtQ29kZVRvLmxlbmd0aH3lgIvjgb7jgafjgafjgZlgKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOmAgeOCiueKtuODh+ODvOOCv+OBq+WVhuWTgeOCs+ODvOODieOCkuiomOmMsuOBmeOCi1xyXG4gICAgaXRlbXMuZm9yRWFjaCgoZSwgaSkgPT4ge1xyXG4gICAgICBjb25MYWJlbFt3cml0ZUl0ZW1Db2RlVG9baV1dID0gZVsn5ZWG5ZOB44Kz44O844OJJ11cclxuICAgIH0pXHJcblxyXG4gICAgLy8g6YCB44KK54q256iu5Yil44KS6Kit5a6aXHJcbiAgICBjb25MYWJlbFsn6YCB44KK54q256iu5YilJ10gPSBsYWJlbE9wdGlvbnMubGFiZWxJZFxyXG5cclxuICAgIC8vIOS9j+aJgOaWh+Wtl+WIl+OBruWIhuWJsuOCkuS/ruato+OBmeOCi1xyXG4gICAgLy8ga2V5UyDjgafmjIflrprjgZXjgozjgZ8gdGFyZ2V0IOWGheOBruimgee0oOOBruWApOOCkuOAgWxlbmd0aO+8iOODkOOCpOODiOmVt++8ieOBp+WIhuWJsuOBl+WGjeani+evieOBmeOCi1xyXG4gICAgLy8gbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44KS6LaF44GI44KL5paH5a2X5YiX44Gv44CB5Y2K6KeS44K544Oa44O844K544Gn5YiG5Ymy44GZ44KLXHJcbiAgICBUZXh0VXRpbC5zcGxpdGxlbmIoY29uTGFiZWwsIFsn44GU5L6d6aC85Li7IOS9j+aJgDEnLCAn44GU5L6d6aC85Li7IOS9j+aJgDInLCAn44GU5L6d6aC85Li7IOS9j+aJgDMnXSwgNTApXHJcbiAgICBUZXh0VXRpbC5zcGxpdGxlbmIoY29uTGFiZWwsIFsn44GK5bGK44GR5YWIIOS9j+aJgDEnLCAn44GK5bGK44GR5YWIIOS9j+aJgDInLCAn44GK5bGK44GR5YWIIOS9j+aJgDMnXSwgNTApXHJcbiAgICByZXR1cm4gY29uTGFiZWxcclxuICB9XHJcblxyXG4gIHRyYW5zZm9ybUxhYmVsWXVwYWNrZXQgKGRvY0xhYmVsLCB3cml0ZUl0ZW1Db2RlVG8pIHtcclxuICAgIC8vIOWVhuWTgeOCs+ODvOODieOCkumAgeOCiueKtkNTVuOBq+Wfi+OCgei+vOOCgFxyXG4gICAgY29uc3Qgb3JkZXJOdW1iZXIgPSBkb2NMYWJlbFsn6KiY5LqL5ZCN77yRJ10ucmVwbGFjZSgn5Y+X5rOo55Wq5Y+377yaJywgJycpXHJcbiAgICBjb25zdCBjdXIgPSB0aGlzLk9yZGVyLmZpbmQoe1xyXG4gICAgICAn5bqX6IiX5ZCNJzogZG9jTGFiZWxbJ+OBlOS+nemgvOS4uyDlkI3np7AxJ10sXHJcbiAgICAgIC8vIOWPl+azqENTVuWHuuWKm+OBleOCjOOBpuOBhOOCi+WPl+azqOeVquWPt+OBjOaWh+Wtl+WIl+W9ouW8j+OBp+OCguaVsOWApOW9ouW8j+OBp+OCguW8leOBo+OBi+OBi+OCi+OCiOOBhuOBq+OBmeOCi++8iCRpbu+8iVxyXG4gICAgICAn5Y+X5rOo55Wq5Y+3JzogeyAkaW46IFsgb3JkZXJOdW1iZXIsIE51bWJlcihvcmRlck51bWJlcikgXSB9XHJcbiAgICB9LCB7ZmllbGRzOiB7XHJcbiAgICAgIF9pZDogMCxcclxuICAgICAgJ+WVhuWTgeOCs+ODvOODiSc6IDFcclxuICAgIH19KVxyXG5cclxuICAgIGlmICghY3VyLmNvdW50KCkpIHRocm93IG5ldyBFcnJvcign6YCB44KK54q244Gr5a++5b+c44GZ44KL5Y+X5rOo44GM6KaL44Gk44GL44KK44G+44Gb44KT44CCQ1NW44OV44Kh44Kk44Or44KS56K66KqN44GX44Gm44GP44Gg44GV44GE44CCJylcclxuXHJcbiAgICBjb25zdCBpdGVtcyA9IGN1ci5mZXRjaCgpXHJcblxyXG4gICAgbGV0IGNvbkxhYmVsID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkb2NMYWJlbCkpXHJcbiAgICBjb25MYWJlbFsn6KiY5LqL5ZCN77yRJ10gPSBpdGVtcy5tYXAoZSA9PiBlWyfllYblk4HjgrPjg7zjg4knXSkuam9pbign44CAJylcclxuXHJcbiAgICAvLyBrZXlTIOOBp+aMh+WumuOBleOCjOOBnyB0YXJnZXQg5YaF44Gu6KaB57Sg44Gu5YCk44KS44CBbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44Gn5YiG5Ymy44GX5YaN5qeL56+J44GZ44KLXHJcbiAgICAvLyBsZW5ndGjvvIjjg5DjgqTjg4jplbfvvInjgpLotoXjgYjjgovmloflrZfliJfjga/jgIHljYrop5Ljgrnjg5rjg7zjgrnjgafliIblibLjgZnjgotcclxuICAgIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWyfjgZTkvp3poLzkuLsg5L2P5omAMScsICfjgZTkvp3poLzkuLsg5L2P5omAMicsICfjgZTkvp3poLzkuLsg5L2P5omAMyddLCA1MClcclxuICAgIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWyfjgYrlsYrjgZHlhYgg5L2P5omAMScsICfjgYrlsYrjgZHlhYgg5L2P5omAMicsICfjgYrlsYrjgZHlhYgg5L2P5omAMyddLCA1MClcclxuICAgIHJldHVybiBjb25MYWJlbFxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0LXByb21pc2UnXHJcbmltcG9ydCB7IGpzb24yeG1sIH0gZnJvbSAneG1sLWpzJ1xyXG5pbXBvcnQgdXRpbEVycm9yIGZyb20gJy4uL3V0aWwvZXJyb3InXHJcblxyXG5jb25zdCBCQVNFX1VSSSA9ICdodHRwczovL2FwaS5tYW5hZ2VyLndvd21hLmpwL3dtc2hvcGFwaSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdvd21hQXBpIHtcclxuICBjb25zdHJ1Y3RvciAocGx1Zywgc2hvcElkKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnXHJcbiAgICB0aGlzLnNob3BJZCA9IHNob3BJZFxyXG4gIH1cclxuXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcbiAgYXN5bmMgdXBkYXRlSXRlbSAodXBkYXRlSXRlbSkge1xyXG4gICAgbGV0IHJlcXVlc3QgPSBgPHJlcXVlc3Q+PHNob3BJZD4ke3RoaXMuc2hvcElkfTwvc2hvcElkPjx1cGRhdGVJdGVtPiR7anNvbjJ4bWwodXBkYXRlSXRlbSwge2NvbXBhY3Q6IHRydWV9KX08L3VwZGF0ZUl0ZW0+PC9yZXF1ZXN0PmBcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnJlcXVlc3RQb3N0KFxyXG4gICAgICAgICd1cGRhdGVJdGVtSW5mbycsXHJcbiAgICAgICAgcmVxdWVzdFxyXG4gICAgICApXHJcbiAgICAgIHJldHVybiB7cmVzcG9uc2U6IHJlcywgcmVxdWVzdFhNTDogcmVxdWVzdH1cclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih1dGlsRXJyb3IucGFyc2UoZSksIHtyZXF1ZXN0WE1MOiByZXF1ZXN0fSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHJlcXVlc3RQb3N0IChtZXRob2QsIGJvZHkpIHtcclxuICAgIC8vIOaOpee2muOCquODl+OCt+ODp+ODs+OBruS9nOaIkFxyXG4gICAgbGV0IGFwaVJlcXVlc3QgPSB7XHJcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICB1cmk6IGAke0JBU0VfVVJJfS8ke21ldGhvZH1gLFxyXG4gICAgICBib2R5OiBib2R5XHJcbiAgICB9XHJcbiAgICAvLyDlhbHpgJrjga7mjqXntproqK3lrprjgajntZDlkIjjgZnjgotcclxuICAgIE9iamVjdC5hc3NpZ24oYXBpUmVxdWVzdCwgdGhpcy5wbHVnKVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3QoYXBpUmVxdWVzdClcclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9jayAoc3RvY2tVcGRhdGVJdGVtKSB7XHJcbiAgICAvLyDmjqXntprjgqrjg5fjgrfjg6fjg7Pjga7kvZzmiJBcclxuICAgIGxldCBhcGlSZXF1ZXN0ID0ge1xyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgdXJpOiBgJHtCQVNFX1VSSX0vdXBkYXRlU3RvY2tgXHJcbiAgICB9XHJcbiAgICAvLyDlhbHpgJrjga7mjqXntproqK3lrprjgajntZDlkIjjgZnjgotcclxuICAgIE9iamVjdC5hc3NpZ24oYXBpUmVxdWVzdCwgdGhpcy5wbHVnKVxyXG5cclxuICAgIGFwaVJlcXVlc3QuYm9keSA9IGF3YWl0IHRoaXMudXBkYXRlU3RvY2tDcmVhdGVSZXF1ZXN0Qm9keShzdG9ja1VwZGF0ZUl0ZW0pXHJcblxyXG4gICAgLy8g44Oq44Kv44Ko44K544OI55m66KGMXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgcmVxdWVzdChhcGlSZXF1ZXN0KVxyXG5cclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZVN0b2NrQ3JlYXRlUmVxdWVzdEJvZHkgKHN0b2NrVXBkYXRlSXRlbSkge1xyXG4gICAgLy9cclxuICAgIC8vIHN0b2NrVXBkYXRlSXRlbSA9XHJcbiAgICAvLyBbXHJcbiAgICAvLyAgIHtcclxuICAgIC8vICAgICBpdGVtQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgdmFyaWF0aW9uczogW1xyXG4gICAgLy8gICAgICAgIHtcclxuICAgIC8vICAgICAgICAgIGNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlOiA8U3RyaW5nPixcclxuICAgIC8vICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgICAgICBzdG9jazogPE51bWJlcj5cclxuICAgIC8vICAgICAgICB9XHJcbiAgICAvLyAgICAgXVxyXG4gICAgLy8gICB9XHJcbiAgICAvLyBdXHJcblxyXG4gICAgbGV0IHN0b2NrVXBkYXRlSXRlbVhNTCA9ICcnXHJcblxyXG4gICAgZm9yIChsZXQgaXRlbSBvZiBzdG9ja1VwZGF0ZUl0ZW0pIHtcclxuICAgICAgLy8g5YCk44Gu44OB44Kn44OD44KvXHJcbiAgICAgIGZvciAobGV0IGUgb2YgaXRlbS52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgLy8g5Zyo5bqr5pWw44Gu5LiK6ZmQMTAwXHJcbiAgICAgICAgaWYgKGUuc3RvY2sgPiAxMDApIGUuc3RvY2sgPSAxMDBcclxuICAgICAgfVxyXG5cclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tVcGRhdGVJdGVtPidcclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8aXRlbUNvZGU+JHtpdGVtLml0ZW1Db2RlfTwvaXRlbUNvZGU+YFxyXG5cclxuICAgICAgLy8g5ZWG5ZOB5Zyo5bqr56iu5Yil44KS5oyv44KK5YiG44GRXHJcbiAgICAgIC8vIDEgLT4g6YCa5bi45ZWG5ZOBXHJcbiAgICAgIC8vIDIgLT4g6YG45oqe6IKi5Yil5Zyo5bqrXHJcblxyXG4gICAgICBsZXQgdmFyMCA9IGl0ZW0udmFyaWF0aW9uc1swXVxyXG4gICAgICBpZiAodmFyMC5jaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZSA9PT0gJycgJiYgdmFyMC5jaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGUgPT09ICcnKSB7XHJcbiAgICAgICAgLy8g6YCa5bi45ZWG5ZOBXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tTZWdtZW50PjE8L3N0b2NrU2VnbWVudD4nXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8c3RvY2tDb3VudD4ke3ZhcjAuc3RvY2t9PC9zdG9ja0NvdW50PmBcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICAvLyDpgbjmip7ogqLliKXlnKjluqtcclxuICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxzdG9ja1NlZ21lbnQ+Mjwvc3RvY2tTZWdtZW50PidcclxuXHJcbiAgICAgICAgLy8g44Oq44Kv44Ko44K544OI44Oc44OH44Kj44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgZm9yIChsZXQgdmFyaWF0aW9uIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgICAgLy8g5Zyo5bqr6Kit5a6a44K/44Kw44Gu5ZCN5YmN44KS5beu44GX5pu/44GI44KLXHJcbiAgICAgICAgICB2YXJpYXRpb24uY2hvaWNlc1N0b2NrQ291bnQgPSB2YXJpYXRpb24uc3RvY2tcclxuICAgICAgICAgIGRlbGV0ZSB2YXJpYXRpb24uc3RvY2tcclxuXHJcbiAgICAgICAgICAvLyB4bWzjgpLmp4vmiJDjgZnjgotcclxuICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPGNob2ljZXNTdG9ja3M+J1xyXG4gICAgICAgICAgZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHZhcmlhdGlvbikpIHtcclxuICAgICAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8JHtrZXl9PiR7dmFyaWF0aW9uW2tleV19PC8ke2tleX0+YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8L2Nob2ljZXNTdG9ja3M+J1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8L3N0b2NrVXBkYXRlSXRlbT4nXHJcbiAgICB9XHJcblxyXG4gICAgLy8g44Oq44Kv44Ko44K544OI44Oc44OH44Kj44Gu5L2c5oiQXHJcbiAgICBsZXQgYXBpUmVxdWVzdEJvZHkgPSBgXHJcbiAgICA8cmVxdWVzdD5cclxuICAgIDxzaG9wSWQ+JHt0aGlzLnNob3BJZH08L3Nob3BJZD5cclxuICAgICR7c3RvY2tVcGRhdGVJdGVtWE1MfVxyXG4gICAgPC9yZXF1ZXN0PlxyXG4gICAgYFxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OCkui/lOOBmVxyXG4gICAgcmV0dXJuIGFwaVJlcXVlc3RCb2R5XHJcbiAgfVxyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIHV0aWxFcnJvciB7XHJcbiAgc3RhdGljIHBhcnNlIChlKSB7XHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICAgIHJlcy5tZXNzYWdlID0gZS5tZXNzYWdlXHJcbiAgICAgIHJlcy5uYW1lID0gZS5uYW1lXHJcbiAgICAgIHJlcy5maWxlTmFtZSA9IGUuZmlsZU5hbWVcclxuICAgICAgcmVzLmxpbmVOdW1iZXIgPSBlLmxpbmVOdW1iZXJcclxuICAgICAgcmVzLmNvbHVtbk51bWJlciA9IGUuY29sdW1uTnVtYmVyXHJcbiAgICAgIHJlcy5zdGFjayA9IGUuc3RhY2tcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlcyA9IGVcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvQ2xpZW50IH0gZnJvbSAnbW9uZ29kYidcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0NvbGxlY3Rpb24ge1xyXG4gIHN0YXRpYyBhc3luYyBnZXQgKHBsdWcsIGNvbGxlY3Rpb24pIHtcclxuICAgIGxldCBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG4gICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICByZXR1cm4gZGIuY29sbGVjdGlvbihjb2xsZWN0aW9uKVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnXHJcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlTUUwge1xyXG4gIGNvbnN0cnVjdG9yIChwcm9maWxlKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pjg5fjg7zjg6vliJ3mnJ/ljJZcclxuICAgIHRoaXMucG9vbCA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZSlcclxuXHJcbiAgICAvLyDopIfmlbDooYzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jlr77lv5xcclxuICAgIGxldCBwcm9maWxlTXVsdGkgPSB7bXVsdGlwbGVTdGF0ZW1lbnRzOiB0cnVlfVxyXG4gICAgT2JqZWN0LmFzc2lnbihwcm9maWxlTXVsdGksIHByb2ZpbGUpXHJcbiAgICB0aGlzLnBvb2xNdWx0aSA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZU11bHRpKVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZvcm1hdERhdGUgKGRhdGUpIHtcclxuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsIDE5KS5yZXBsYWNlKCdUJywgJyAnKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsXHJcbiAgICovXHJcbiAgcXVlcnkgKHNxbCkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz56K656uLXHJcbiAgICAvLyBsZXQgY29uID0gYXdhaXQgdGhpcy5nZXRDb24oKTtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwsIChlLCByZXMpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+mWi+aUvlxyXG4gICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxyXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXMpXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnRfIChzcWwpIHtcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O844CBbnVsbOOAgWphdmFzY3JpcHQtPm15c3Fs5pel5LuY5aSJ5o+b44Gr44KC5a++5b+cXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnQgKHRhYmxlLCBkYXRhID0ge30sIGRhdGFTcWwgPSB7fSkge1xyXG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgXHJcblxyXG4gICAgbGV0IG1hcCA9IG5ldyBNYXAoKVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCkge1xyXG4gICAgICAgIG1hcC5zZXQoaywgJ05VTEwnKVxyXG4gICAgICB9IGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG1hcC5zZXQoaywgYCR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgbWFwLnNldChrLCBkYXRhU3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YVNxbFtrXSlcclxuICAgIH1cclxuXHJcbiAgICBzcWwgKz0gYCggJHtbLi4ubWFwLmtleXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBzcWwgKz0gYFZBTFVFUyggJHtbLi4ubWFwLnZhbHVlcygpXS5qb2luKCcsJyl9ICkgYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICBhc3luYyBxdWVyeVVwZGF0ZSAodGFibGUsIGZpbHRlciwgZGF0YSwgZGF0YVNxbCkge1xyXG4gICAgbGV0IHNxbCA9IGBVUERBVEUgJHt0YWJsZX0gU0VUIGBcclxuXHJcbiAgICBsZXQgdXBkYXRlcyA9IFtdXHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgfVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhU3FsW2tdfWApXHJcbiAgICB9XHJcbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJylcclxuXHJcbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIC8vIGVuYWJsZSB0byB1c2UgbXVsdGlwbGUgc3RhdGVtZW50c1xyXG4gIGFzeW5jIHF1ZXJ5TXVsdGkgKHNxbCkge1xyXG4gICAgbGV0IHBvb2xTd2FwID0gdGhpcy5wb29sXHJcbiAgICB0aGlzLnBvb2wgPSB0aGlzLnBvb2xNdWx0aVxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3RhcnRUcmFuc2FjdGlvbiAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBTVEFSVCBUUkFOU0FDVElPTjtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29tbWl0ICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYENPTU1JVDtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcm9sbGJhY2sgKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgUk9MTEJBQ0s7YClcclxuICB9XHJcblxyXG4gIHN0cmVhbWluZ1F1ZXJ5IChzcWwsIG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pIHtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwpXHJcbiAgICAgICAgICAgICAgICAub24oJ3Jlc3VsdCcsXHJcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb24ucGF1c2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0KHJlY29yZClcclxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKClcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGVcclxuICAgICAgfSlcclxuICB9XHJcblxyXG4gIGdldENvbiAoKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAvLyDjg5fjg7zjg6vjgYvjgonjga7jgrPjg43jgq/jgrfjg6fjg7PnjbLlvpdcclxuICAgICAgICB0aGlzLnBvb2wuZ2V0Q29ubmVjdGlvbigoZSwgY29uKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICByZWplY3QoZSlcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUoY29uKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLmNhdGNoKFxyXG4gICAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgfTtcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBQYWNrZXQge1xyXG4gIGNvbnN0cnVjdG9yIChwYWNrZXRTaXplKSB7XHJcbiAgICB0aGlzLnBhY2tldFNpemUgPSBwYWNrZXRTaXplXHJcbiAgICB0aGlzLm9uUGFja2V0U3RhcnQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldEVuZCA9IG51bGxcclxuICAgIHRoaXMuY291bnQgPSAwXHJcbiAgICB0aGlzLnBhY2tldENvdW50ID0gMFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0IChhcmcpIHtcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHliJ3mnJ/ljJbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0U3RhcnQpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLm9uUGFja2V0U3RhcnQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMub25QYWNrZXQpIHtcclxuICAgICAgYXdhaXQgdGhpcy5vblBhY2tldChhcmcpXHJcbiAgICB9XHJcbiAgICB0aGlzLmNvdW50KytcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHntYLkuoblh6bnkIbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIHRoaXMuY2xvc2UoKVxyXG4gICAgICB0aGlzLnBhY2tldENvdW50KytcclxuICAgIH1cclxuICB9XHJcbiAgY2xvc2UgKCkge1xyXG4gICAgaWYgKHRoaXMub25QYWNrZXRFbmQpIHtcclxuICAgICAgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdXRpbEVycm9yIGZyb20gJy4vZXJyb3InXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgeyBMb2dzIH0gZnJvbSAnLi4vY29sbGVjdGlvbnMnXHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVwb3J0IHtcclxuICBjb25zdHJ1Y3RvciAoKSB7XHJcbiAgICB0aGlzLnJlY29yZCA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9ycyA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgLy8gcHJpdmF0ZVxyXG4gIHNldHVwSXRlcmF0b3IgKHBoYXNlSWQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IocGhhc2VJZClcclxuICAgIHRoaXMuaXRlcmF0b3JzLnB1c2godGhpcy5pdGVyYXRvcilcclxuICB9XHJcblxyXG4gIGFzeW5jIHBoYXNlIChuYW1lID0gJycsIGZuID0gYXN5bmMgKCkgPT4ge30pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHBoYXNlSWQ6IHVuaXFpZCgpXHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKHJlYy5waGFzZUlkKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCBmbigpXHJcblxyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdzdWNjZXNzJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHJlc1xyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiB1dGlsRXJyb3IucGFyc2UoZSlcclxuICAgICAgfSlcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIC8vIOODq+ODvOODl+WHpueQhuOBruODrOODneODvOODiOOCkuS9nOaIkFxyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci5tZXRyaWMudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3IubWV0cmljXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICAvLyDjgr/jgqTjg6Djgrnjgr/jg7Pjg5dcclxuICAgICAgcmVjLnRpbWVTdGFtcCA9IG5ldyBEYXRlKClcclxuICAgICAgLy8g44Os44Od44O844OI44KS44OH44O844K/44OZ44O844K544Gr6KiY6YyyXHJcbiAgICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuXHJcbiAgICAgIC8vIOWRvOOBs+WHuuOBl+WFg+eUqOODrOODneODvOODiOOBq+i/veWKoFxyXG4gICAgICB0aGlzLnJlY29yZC5wdXNoKHJlYylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIOOCq+ODvOOCveODq+OCkuODq+ODvOODl+OBl+OAgeS4juOBiOOCieOCjOOBn+mWouaVsOOCkuWun+ihjFxyXG4gIC8vIOWRvOOBs+WHuuOBmemWouaVsOOBruW8leaVsOOBq+OBr+OCq+ODvOOCveODq+OBi+OCieW+l+OCieOCjOOBn+ODieOCreODpeODoeODs+ODiOOCkua4oeOBmVxyXG4gIGFzeW5jIGZvckVhY2hPbkN1cnNvciAoY3VyLCBmbikge1xyXG4gICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgbGV0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZm4oZG9jKVxyXG4gICAgICAgIHRoaXMuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgdGhpcy5pRXJyb3IoZSlcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgY3VyLmNsb3NlKClcclxuICB9XHJcblxyXG4gIGlTdWNjZXNzIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3Iuc3VjY2VzcyhuZXdSZWNvcmQpXHJcbiAgfVxyXG5cclxuICBpRXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5lcnJvcih1dGlsRXJyb3IucGFyc2UobmV3UmVjb3JkKSlcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICBsZXQgaXRlRXJyb3IgPSB0aGlzLml0ZXJhdG9ycy5maW5kKGUgPT4gZS5lcnJvck9jdXJyZWQoKSlcclxuICAgIGxldCBwaGFFcnJvciA9IGZhbHNlXHJcbiAgICBmb3IgKGxldCByZWMgb2YgdGhpcy5yZWNvcmQpIHtcclxuICAgICAgaWYgKHJlYy50eXBlID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgcGhhRXJyb3IgPSB0cnVlXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGl0ZUVycm9yIHx8IHBoYUVycm9yXHJcbiAgfVxyXG5cclxuICBwdWJsaXNoICgpIHtcclxuICAgIC8vIOWRvOOBs+WHuuOBl+WFg+OBuOODrOODneODvOODiFxyXG4gICAgaWYgKHRoaXMuZXJyb3JPY3VycmVkKCkpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcih0aGlzLnJlY29yZClcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnJlY29yZFxyXG4gIH1cclxufVxyXG5cclxuY2xhc3MgSXRlcmF0b3Ige1xyXG4gIGNvbnN0cnVjdG9yIChwaGFzZUlkKSB7XHJcbiAgICB0aGlzLm1ldHJpYyA9IHtcclxuICAgICAgdG90YWw6IDAsXHJcbiAgICAgIHN1Y2Nlc3M6IDAsXHJcbiAgICAgIGVycm9yOiAwLFxyXG4gICAgICBwaGFzZUlkOiBwaGFzZUlkXHJcbiAgICB9XHJcbiAgICB0aGlzLmxhc3RFcnJvciA9IG51bGxcclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLmxvZyhuZXdSZWNvcmQsIHRydWUpXHJcbiAgICB9XHJcbiAgICB0aGlzLm1ldHJpYy5zdWNjZXNzKytcclxuICAgIHRoaXMubWV0cmljLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIC8vIOebtOWJjeOBqOWQjOOBmOOCqOODqeODvOOBr+ecgeOBj1xyXG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KHRoaXMubGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMubG9nKG5ld1JlY29yZCwgZmFsc2UpXHJcbiAgICAgICAgdGhpcy5sYXN0RXJyb3IgPSBuZXdSZWNvcmRcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy5tZXRyaWMuZXJyb3IrK1xyXG4gICAgdGhpcy5tZXRyaWMudG90YWwrK1xyXG4gIH1cclxuXHJcbiAgbG9nIChuZXdSZWNvcmQsIGlzU3VjY2VzcyAvKiB0cnVlID0+IHN1Y2Nlc3Mgb3IgZmFsc2UgPT4gZXJyb3IgKi8pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IGlzU3VjY2VzcyxcclxuICAgICAgcGhhc2VJZDogdGhpcy5tZXRyaWMucGhhc2VJZCxcclxuICAgICAgbWVzc2FnZTogbmV3UmVjb3JkLFxyXG4gICAgICB0aW1lU3RhbXA6IG5ldyBEYXRlKClcclxuICAgIH1cclxuICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMuZXJyb3JcclxuICB9XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGV4dFV0aWwge1xyXG4gIC8vIDjjg5Pjg4Pjg4jjgafmloflrZfliJfliIfjgorlj5bjgotcclxuICBzdGF0aWMgc3Vic3RyOCAodGV4dCwgbGVuLCB0cnVuY2F0aW9uKSB7XHJcbiAgICBpZiAodHJ1bmNhdGlvbiA9PT0gdW5kZWZpbmVkKSB7IHRydW5jYXRpb24gPSAnJyB9XHJcbiAgICB2YXIgdGV4dEFycmF5ID0gdGV4dC5zcGxpdCgnJylcclxuICAgIHZhciBjb3VudCA9IDBcclxuICAgIHZhciBzdHIgPSAnJ1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0ZXh0QXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgdmFyIG4gPSBlc2NhcGUodGV4dEFycmF5W2ldKVxyXG4gICAgICBpZiAobi5sZW5ndGggPCA0KSBjb3VudCsrXHJcbiAgICAgIGVsc2UgY291bnQgKz0gMlxyXG4gICAgICBpZiAoY291bnQgPiBsZW4pIHtcclxuICAgICAgICByZXR1cm4gc3RyICsgdHJ1bmNhdGlvblxyXG4gICAgICB9XHJcbiAgICAgIHN0ciArPSB0ZXh0LmNoYXJBdChpKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRleHRcclxuICB9XHJcblxyXG4gIC8vIOaWh+Wtl+WIl+OBruODkOOCpOODiOaVsOOCkuaVsOOBiOOCi1xyXG4gIHN0YXRpYyBsZW5iICh0ZXh0KSB7XHJcbiAgICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHRleHQpLnJlcGxhY2UoLyUuLiUuLiUuLi9nLCAneHgnKS5sZW5ndGhcclxuICB9XHJcblxyXG4gIHN0YXRpYyBzcGxpdGxlbmIgKHRhcmdldCwga2V5UywgbGVuZ3RoKSB7XHJcbiAgICBjb25zdCBzZXAgPSAnICdcclxuICAgIC8vIGtleVMg44Gn5oyH5a6a44GV44KM44GfIHRhcmdldCDlhoXjga7opoHntKDjga7lgKTjgpLjgZnjgbnjgabntZDlkIjjgZfjgZ/mloflrZfliJfjgpLkvZzjgotcclxuICAgIGNvbnN0IHN0ckVudGlyZSA9IGtleVMucmVkdWNlKChwcmV2LCBjdXJyZW50KSA9PiBwcmV2ICsgdGFyZ2V0W2N1cnJlbnRdLCAnJylcclxuICAgIC8vIOe1kOWQiOOBl+OBn+aWh+Wtl+WIl+OCkuWNiuinkuOCueODmuODvOOCueOBp+WIhuWJsuOBmeOCi1xyXG4gICAgY29uc3QgYXJyRW50aXJlID0gc3RyRW50aXJlLnNwbGl0KHNlcClcclxuICAgIGxldCBhcnJSZXMgPSBbXVxyXG4gICAgbGV0IGxhc3QgPSAnJ1xyXG4gICAgLy8g44OQ44Kk44OI6ZW344GMbGVuZ3Ro44KS6LaF44GI44Gq44GE6ZmQ44KK5YmN5b6M44Gu5YiG5Ymy5paH5a2X5YiX44KS57WQ5ZCI44GX44Gm44GE44GPXHJcbiAgICAvLyDjg5DjgqTjg4jplbfjgYxsZW5ndGjjgpLotoXjgYjjgZ/jgonjgIHjgbLjgajjgaTjgb7jgYjjga7ntZDlkIjmloflrZfliJfjgpLphY3liJfnmbvpjLLjgZnjgotcclxuICAgIHRyeSB7XHJcbiAgICAgIGFyckVudGlyZS5yZWR1Y2UoKHByZXYsIGN1cnJlbnQpID0+IHtcclxuICAgICAgICAvLyBsZW5ndGgg44KS6LaF44GI44KL44OQ44Kk44OI6ZW344Gu5YiG5Ymy5paH5a2X5YiX44GM44GC44KL5aC05ZCI44Gv5L2V44KC44GX44Gq44GEXHJcbiAgICAgICAgaWYgKFRleHRVdGlsLmxlbmIoY3VycmVudCkgPiBsZW5ndGgpIHRocm93IG5ldyBFcnJvcign5paH5a2X5YiX6LaF6YGOJylcclxuICAgICAgICBjb25zdCBleGFtID0gKHByZXYgIT09ICcnID8gcHJldiArIHNlcCA6ICcnKSArIGN1cnJlbnRcclxuICAgICAgICBpZiAoVGV4dFV0aWwubGVuYihleGFtKSA+IGxlbmd0aCkge1xyXG4gICAgICAgICAgYXJyUmVzLnB1c2gocHJldilcclxuICAgICAgICAgIGxhc3QgPSBjdXJyZW50IC8vIOacgOW+jOOBruaWh+Wtl+WIl1xyXG4gICAgICAgICAgcmV0dXJuICcnXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGxhc3QgPSBleGFtIC8vIOacgOW+jOOBruaWh+Wtl+WIl1xyXG4gICAgICAgICAgcmV0dXJuIGV4YW1cclxuICAgICAgICB9XHJcbiAgICAgIH0sICcnKVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAvLyBsZW5ndGgg44KS6LaF44GI44KL44OQ44Kk44OI6ZW344Gu5YiG5Ymy5paH5a2X5YiX44GM44GC44KL5aC05ZCI44Gv5L2V44KC44GX44Gq44GEXHJcbiAgICAgIGlmIChlLm1lc3NhZ2UgPT09ICfmloflrZfliJfotoXpgY4nKSByZXR1cm5cclxuICAgIH1cclxuXHJcbiAgICBhcnJSZXMucHVzaChsYXN0KSAvLyDmnIDlvozjga7mloflrZfliJfjgpLphY3liJfnmbvpjLLjgZnjgotcclxuICAgIC8vIGtleVMg44Gn5oyH5a6a44GV44KM44GfIHRhcmdldCDlhoXjga7opoHntKDjga7lgKTjgpLkv67mraPjgZnjgotcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwga2V5Uy5sZW5ndGg7IGkrKykge1xyXG4gICAgICB0YXJnZXRba2V5U1tpXV0gPSBhcnJSZXNbaV0gPyBhcnJSZXNbaV0gOiAnJ1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2xvZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2FkcycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5leHBvcnQgY29uc3QgUm9ib3RpblNob3AgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncm9ib3RpblNob3AnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuXHJcbmV4cG9ydCBjb25zdCBDb25maWdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NvbmZpZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuICBNZXRlb3IucHVibGlzaCgnY29uZmlncycsICgpID0+IHtcclxuICAgIHJldHVybiBDb25maWdzLmZpbmQoKVxyXG4gIH0pXHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpIHtcclxuICBNZXRlb3Iuc3Vic2NyaWJlKCdjb25maWdzJylcclxufVxyXG4iXX0=
