var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/route/upload/image.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

// WebApp.connectHandlers.use('/upload', (req, res, next) => {
//   res.writeHead(200);
//   res.end(`Hello world from: ${Meteor.release}`);
// });

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

// Requires multiparty

var _connectMultiparty = require('connect-multiparty');

var _connectMultiparty2 = _interopRequireDefault(_connectMultiparty);

var _importsCollections = require('../../../imports/collections');

var multipartyMiddleware = (0, _connectMultiparty2['default'])();

var route = '/upload/image';

// WebApp.connectHandlers.use('/upload', fuc.uploadFile );
WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, function (req, resp) {
  // don't forget to delete all req.files when done

  var reader = Meteor.wrapAsync(_fs2['default'].readFile);
  var writer = Meteor.wrapAsync(_fs2['default'].writeFile);
  var uploadId = (0, _uniqid2['default'])();

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = req.files.file[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var file = _step.value;

      var data = reader(file.path);
      // ファイル名の重複を避けるため、一意のファイル名を作成する
      // 楽天のファイル名文字数制限20に合わせる
      var filename = (0, _uniqid2['default'])() + '.jpg';

      // set the correct path for the file not the temporary one from the API:
      var savePath = req.body.imagedir + '/' + filename;

      // copy the data from the req.files.file.path and paste it to file.path

      // アップロード結果を記録する
      var doc = {
        uploadId: uploadId,
        clientFileName: file.name,
        uploadedFileName: filename
      };

      try {
        writer(savePath, data);
      } catch (err) {
        doc.error = err;
      }
      _importsCollections.Uploads.insert(doc);

      delete file;
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator['return']) {
        _iterator['return']();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube/cubemig.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _crypto = require('crypto');

var _crypto2 = _interopRequireDefault(_crypto);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsUtilReport = require('../../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsCollectionGroups = require('../../imports/collection/groups');

var _importsCollectionFilters = require('../../imports/collection/filters');

var tag = 'cubemig';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.migrate', function callee$0$0(config) {
  var report, filter, testQuery, dstDb;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsCollectionFilters.Filter(config.srcFilterId);
        testQuery = 'SHOW DATABASES';
        dstDb = new _importsUtilMysql2['default'](config.dst.cred);
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(report.phase('Connect to Destination', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(dstDb.query(testQuery));

              case 2:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 6:
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(report.phase('Select loop in source', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this2 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  mobileNull: function mobileNull(record) {
                    var sql, couponCd, couponName, discountPrice, _res;

                    return regeneratorRuntime.async(function mobileNull$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          sql = '\n\n                INSERT dtb_customer\n                ( `customer_id`, `status`, `sex`, `job`, `country_id`, `pref`, `name01`, `name02`, `kana01`, `kana02`, `company_name`, `zip01`, `zip02`, `zipcode`, `addr01`, `addr02`, `email`, `tel01`, `tel02`, `tel03`, `fax01`, `fax02`, `fax03`, `birth`, `password`, `salt`, `secret_key`, `first_buy_date`, `last_buy_date`, `buy_times`, `buy_total`, `note`, `create_date`, `update_date`, `del_flg` )\n\n                VALUES( ' + record.customer_id + ' , ' + record.status + ' , ' + record.sex + ' , ' + record.job + ' , ' + record.country_id + ' , ' + record.pref + ' , ' + record.name01 + ' , ' + record.name02 + ' , ' + record.kana01 + ' , ' + record.kana02 + ' , ' + record.company_name + ' , ' + record.zip01 + ' , ' + record.zip02 + ' , ' + record.zipcode + ' , ' + record.addr01 + ' , ' + record.addr02 + ' , ' + record.email + ' , ' + record.tel01 + ' , ' + record.tel02 + ' , ' + record.tel03 + ' , ' + record.fax01 + ' , ' + record.fax02 + ' , ' + record.fax03 + ' , ' + record.birth + ' , ' + record.password + ' , ' + record.salt + ' , ' + record.secret_key + ' , ' + record.first_buy_date + ' , ' + record.last_buy_date + ' , ' + record.buy_times + ' , ' + record.buy_total + ' , ' + record.note + ' , ' + record.create_date + ' , ' + record.update_date + ' , ' + record.del_flg + ' )\n                \n                ';
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer', {
                            customer_id: record.customer_id,
                            status: record.status,
                            sex: record.sex,
                            job: record.job,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            email: record.email,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            birth: record.birth,
                            password: record.password,
                            salt: record.salt,
                            secret_key: record.secret_key,
                            first_buy_date: record.first_buy_date,
                            last_buy_date: record.last_buy_date,
                            buy_times: record.buy_times,
                            buy_total: record.buy_total,
                            note: record.note,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 4:
                          context$3$0.next = 9;
                          break;

                        case 6:
                          context$3$0.prev = 6;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 9:
                          context$3$0.prev = 9;
                          context$3$0.next = 12;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer_address', {
                            customer_address_id: null,
                            customer_id: record.customer_id,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 12:
                          context$3$0.next = 17;
                          break;

                        case 14:
                          context$3$0.prev = 14;
                          context$3$0.t1 = context$3$0['catch'](9);

                          report.iError(context$3$0.t1);

                        case 17:
                          context$3$0.prev = 17;
                          context$3$0.next = 20;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_mailmaga_customer', {
                            id: null,
                            customer_id: record.customer_id,
                            mailmaga_flg: record.mailmaga_flg,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 20:
                          context$3$0.next = 25;
                          break;

                        case 22:
                          context$3$0.prev = 22;
                          context$3$0.t2 = context$3$0['catch'](17);

                          report.iError(context$3$0.t2);

                        case 25:
                          couponCd = _crypto2['default'].randomBytes(8).toString('base64').substring(0, 11);
                          couponName = record.name01 + ' ' + record.name02 + ' 様 ご優待クーポン 会員番号:' + record.customer_id;
                          discountPrice = record.point + 500;
                          context$3$0.prev = 28;
                          context$3$0.next = 31;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_coupon', {
                            coupon_id: null,
                            coupon_cd: couponCd,
                            coupon_type: 3, // 全商品
                            coupon_name: couponName,
                            discount_type: 1,
                            coupon_use_time: 1,
                            coupon_release: 1,
                            discount_price: discountPrice,
                            discount_rate: null,
                            enable_flag: 1,
                            coupon_member: 1,
                            coupon_lower_limit: null,
                            customer_id: record.customer_id,
                            available_from_date: '2018-04-02 00:00:00',
                            available_to_date: '2019-05-02 00:00:00',
                            del_flg: 0
                          }, {
                            create_date: 'NOW()',
                            update_date: 'NOW()'
                          }));

                        case 31:
                          _res = context$3$0.sent;
                          context$3$0.next = 37;
                          break;

                        case 34:
                          context$3$0.prev = 34;
                          context$3$0.t3 = context$3$0['catch'](28);

                          report.iError(context$3$0.t3);

                        case 37:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this2, [[1, 6], [9, 14], [17, 22], [28, 34]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        report.iError(e);

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this2);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 8:
        return context$1$0.abrupt('return', report.publish());

      case 9:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, 'cubemig.serverCheck', function cubemigServerCheck(profile) {
  var db, res;
  return regeneratorRuntime.async(function cubemigServerCheck$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        db = new _importsUtilMysql2['default'](profile);
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(db.query('SHOW DATABASES'));

      case 3:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// setup group
//

// let plug = group.getPlug();

// checking connection
//

// process for each members
//

// // 値を整理
// for (let key of Object.keys(record)) {
//   if (record[key] === null);
//   else if (record[key].constructor.name === 'Date') {
//     // 日付を変換
//     record[key] = MySQL.formatDate(record[key]);
//     record[key] = `"${record[key]}"`;
//   }
// }

// dtb_customer に保存

// dtb_customer_address

// メルマガプラグイン plg_mailmaga_customer

// クーポン発行（ECCUBE2のポイント還元）
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/collection.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilMongo = require('../../imports/util/mongo');

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.collection';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.find', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var projection = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.find(query, { projection: projection }).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.aggregate', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.aggregate(query).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/items.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsServiceItems = require('../../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.items';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.setImage', function callee$0$0(plug, uploadId, model) {
  var class1 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var class2 = arguments.length <= 4 || arguments[4] === undefined ? null : arguments[4];
  var itemcon, uploaded;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.setImage(uploadId, model, class1, class2));

      case 5:
        uploaded = context$1$0.sent;
        return context$1$0.abrupt('return', uploaded);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.cleanImage', function callee$0$0(plug, model) {
  var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
  var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var itemcon;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.cleanImage(model, class1, class2));

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

/**
 * 指定された条件に一致するitemsコレクション内のドキュメントに、
 * アップロード済み画像を関連付けます。
 * @param
 */

/**
 * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceCube3api = require('../imports/service/cube3api');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var tag = 'cube';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.category', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('商品カテゴリの更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  UPDATE: function UPDATE(item, context) {
                    var results;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          if (!_lodash2['default'].isArray(item.mall.sharakuShop.categories)) {
                            context$3$0.next = 11;
                            break;
                          }

                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(api.modifyCategory(item.mall.sharakuShop.product_id, item.mall.sharakuShop.categories));

                        case 4:
                          results = context$3$0.sent;

                          // SQLクエリ結果を記録
                          report.iSuccess(results);
                          context$3$0.next = 11;
                          break;

                        case 8:
                          context$3$0.prev = 8;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 11:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this, [[1, 8]]);
                  }
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('在庫の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({

                  UPDATE: function UPDATE(item, context) {
                    var quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;
                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 5:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  }
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibItem', function callee$0$0(config) {
  var filter, targetDB, api, itemController, report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this6 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 6:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3への商品登録', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  INSERT: function INSERT(item, context) {
                    var col, cubeItem, insertRes;
                    return regeneratorRuntime.async(function INSERT$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.updateItem, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productCreate(cubeItem));

                        case 7:
                          insertRes = context$3$0.sent;
                          context$3$0.next = 10;
                          return regeneratorRuntime.awrap(col.updateOne({
                            _id: item._id
                          }, {
                            $set: {
                              'mall.sharakuShop.product_id': insertRes.res.product_id,
                              'mall.sharakuShop.product_class_id': insertRes.res.product_class_id,
                              'mall.sharakuShop.product_stock_id': insertRes.res.product_stock_id
                            }
                          }));

                        case 10:

                          report.iSuccess();
                          context$3$0.next = 16;
                          break;

                        case 13:
                          context$3$0.prev = 13;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 16:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this5, [[1, 13]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 9:
        context$1$0.next = 11;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3商品情報の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this7 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  UPDATE: function UPDATE(item, context) {
                    var col, cubeItem, quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.updateItem, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productImageUpdate(cubeItem));

                        case 7:
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(api.productUpdate(cubeItem));

                        case 9:
                          context$3$0.next = 11;
                          return regeneratorRuntime.awrap(api.productTagUpdate(cubeItem));

                        case 11:
                          context$3$0.next = 13;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 13:
                          quantity = context$3$0.sent;
                          context$3$0.next = 16;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 16:

                          report.iSuccess();
                          context$3$0.next = 22;
                          break;

                        case 19:
                          context$3$0.prev = 19;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 22:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this7, [[1, 19]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this7);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 11:
        return context$1$0.abrupt('return', report.publish());

      case 12:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// カテゴリ更新

// クライアントが参照するための処理結果作成オブジェクト

// 商品にカテゴリーデータが記録されていれば処理する

// 商品情報データベースに記録された商品カテゴリー情報を、モールに適用する

//
// 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 商品情報登録と更新

// クライアントが参照するための処理結果作成オブジェクト

// item データベースへの登録
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/robotin.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var _fibers = require('fibers');

var _fibers2 = _interopRequireDefault(_fibers);

var _importsServiceRobotin = require('../imports/service/robotin');

var _importsServiceRobotin2 = _interopRequireDefault(_importsServiceRobotin);

var tag = 'robotin';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order.export', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 受注CSV 出力', function callee$1$0() {
          var workdir, workdirExport, orderCsvExport, itemS;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.order.workdir;
                workdirExport = workdir + '/' + config.order.workdirExport;
                orderCsvExport = config.order.ordercsvExport + '.csv';
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirExport));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 27:

                // 受注CSVを出力する
                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _importsServiceRobotin2['default'].createReadableOrder().on('error', function (err) {
                    mcb(err);
                  });

                  var transform = new _stream.Transform({
                    writableObjectMode: true,
                    readableObjectMode: true,
                    transform: function transform(chunk, enc, cb) {
                      cb(null, chunk.robotin);
                    }
                  });

                  var write = _fsExtra2['default'].createWriteStream(workdirExport + '/' + orderCsvExport).on('error', function (err) {
                    mcb(err);
                  }).on('finish', function () {
                    mcb();
                  });

                  read.pipe(transform).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(write);
                })();

              case 28:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this, [[3, 8], [10, 15], [17, 22]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.order.import', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this3 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 受注CSV 取込み', function callee$1$0() {
          var workdir, workdirImport, orderCsv, itemS;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.order.workdir;
                workdirImport = workdir + '/' + config.order.workdirImport;
                orderCsv = config.order.ordercsv + '.csv';
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirImport));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 27:

                // 受注CSVを読み込む
                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _fsExtra2['default'].createReadStream(workdirImport + '/' + orderCsv).on('error', function (err) {
                    mcb(err);
                  });
                  var write = new _stream.Writable({
                    objectMode: true,
                    write: function write(chunk, encoding, callback) {
                      var _this2 = this;

                      (0, _fibers2['default'])(function callee$4$0() {
                        return regeneratorRuntime.async(function callee$4$0$(context$5$0) {
                          while (1) switch (context$5$0.prev = context$5$0.next) {
                            case 0:
                              context$5$0.prev = 0;
                              context$5$0.next = 3;
                              return regeneratorRuntime.awrap(_importsServiceRobotin2['default'].importOrder(chunk, itemS));

                            case 3:
                              report.iSuccess();
                              context$5$0.next = 9;
                              break;

                            case 6:
                              context$5$0.prev = 6;
                              context$5$0.t0 = context$5$0['catch'](0);

                              callback(context$5$0.t0);

                            case 9:
                              callback();

                            case 10:
                            case 'end':
                              return context$5$0.stop();
                          }
                        }, null, _this2, [[0, 6]]);
                      }).run();
                    },
                    final: function final(callback) {
                      callback();
                      mcb();
                    }
                  }).on('error', function (err) {
                    return report.iError(err);
                  });

                  read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(write);
                })();

              case 28:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this3, [[3, 8], [10, 15], [17, 22]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.postlabel', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 送り状発行', function callee$1$0() {
          var workdir, workdirRead, workdirWrite, itemS, robo;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.postlabel.workdir;
                workdirRead = workdir + '/' + config.postlabel.workdirRead;
                workdirWrite = workdir + '/' + config.postlabel.workdirWrite;
                context$2$0.prev = 3;
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 6:
                context$2$0.next = 10;
                break;

              case 8:
                context$2$0.prev = 8;
                context$2$0.t0 = context$2$0['catch'](3);

              case 10:
                context$2$0.prev = 10;
                context$2$0.next = 13;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 13:
                context$2$0.next = 17;
                break;

              case 15:
                context$2$0.prev = 15;
                context$2$0.t1 = context$2$0['catch'](10);

              case 17:
                context$2$0.prev = 17;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirRead));

              case 20:
                context$2$0.next = 24;
                break;

              case 22:
                context$2$0.prev = 22;
                context$2$0.t2 = context$2$0['catch'](17);

              case 24:
                context$2$0.prev = 24;
                context$2$0.next = 27;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdirWrite));

              case 27:
                context$2$0.next = 31;
                break;

              case 29:
                context$2$0.prev = 29;
                context$2$0.t3 = context$2$0['catch'](24);

              case 31:
                itemS = new _importsServiceItems2['default']();
                context$2$0.next = 34;
                return regeneratorRuntime.awrap(itemS.init(config.itemsDB));

              case 34:
                robo = new _importsServiceRobotin2['default']();

                _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                  var read = _fsExtra2['default'].createReadStream(workdirRead + '/' + config.postlabel.ordercsv + '.csv').on('error', function (err) {
                    mcb(err);
                  });
                  var write = new _stream.Writable({
                    objectMode: true,
                    write: function write(chunk, encoding, callback) {
                      robo.importOrderTemp(chunk, itemS);
                      callback();
                    },
                    final: function final(callback) {
                      callback();
                      mcb();
                    }
                  });

                  read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(write);
                })();

                // 送り状種別ごとに繰り返す
                config.postlabel.labeltypes.forEach(function (labelOption) {
                  try {
                    _meteorMeteor.Meteor.wrapAsync(function (mcb) {
                      var read = _fsExtra2['default'].createReadStream(workdirRead + '/' + labelOption.readcsv + '.csv').on('error', function () {
                        mcb();
                      }); // ファイルがない場合は無視
                      var transform = new _stream.Transform({
                        readableObjectMode: true,
                        writableObjectMode: true,
                        transform: function transform(chunk, encoding, callback) {
                          var record = undefined;
                          try {
                            (0, _fibers2['default'])(function () {
                              record = robo[labelOption.method](chunk, labelOption);
                              callback(null, record);
                            }).run();
                          } catch (error) {
                            mcb(error);
                          }
                        }
                      });
                      var write = _fsExtra2['default'].createWriteStream(workdirWrite + '/' + labelOption.writecsv + '.csv').on('finish', function () {
                        report.iSuccess();
                        mcb();
                      }).on('error', function (error) {
                        mcb(error);
                      });

                      read.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: labelOption.columns === true ? true : null })).pipe(transform).pipe(_csv2['default'].stringify({ header: labelOption.columns })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(write);
                    })();
                  } catch (error) {
                    report.iError(error);
                  }
                });

              case 37:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[3, 8], [10, 15], [17, 22], [24, 29]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.itemcode', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this5 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 外部連携商品番号', function callee$1$0() {
          var workdir, itemController, read, writeCsv;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/' + config.itemcode.workdir;
                context$2$0.prev = 1;
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 4:
                context$2$0.next = 8;
                break;

              case 6:
                context$2$0.prev = 6;
                context$2$0.t0 = context$2$0['catch'](1);

              case 8:
                context$2$0.prev = 8;
                context$2$0.next = 11;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 11:
                context$2$0.next = 22;
                break;

              case 13:
                context$2$0.prev = 13;
                context$2$0.t1 = context$2$0['catch'](8);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 18;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 18:
                read = itemController.Items.find({ model: { $ne: '' } }).stream();

                writeCsv = function writeCsv(read, tf, filename) {
                  var robotin = new _stream.Transform({
                    readableObjectMode: true,
                    writableObjectMode: true,
                    transform: function transform(chunk, encoding, callback) {
                      (0, _fibers2['default'])(function () {
                        var data = tf(chunk);
                        callback(null, data);
                      }).run();
                    }
                  });
                  var count = 0;
                  var clearnum = new _stream.Transform({
                    encoding: 'utf8',
                    transform: function transform(chunk, encoding, callback) {
                      var str = chunk.toString();
                      if (count === 0) {
                        str = str.replace(/_\d+?/g, '');
                      }
                      count++;
                      callback(null, str);
                    }
                  });
                  var writecsv = _fsExtra2['default'].createWriteStream(filename + '.csv');
                  writecsv.on('error', function (e) {
                    throw _meteorMeteor.Meteor.Error('CSVファイル書き込みエラー');
                  });

                  read.pipe(robotin).pipe(_csv2['default'].stringify({ header: true })).pipe(clearnum).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(writecsv);
                };

                writeCsv(read, _importsServiceItems2['default'].convertItemRobotinItem, workdir + '/' + config.itemcode.csvNameItem);

                writeCsv(read, _importsServiceItems2['default'].convertItemRobotinSelect, workdir + '/' + config.itemcode.csvNameSelect);

              case 22:
                throw new _meteorMeteor.Meteor.Error('正しい作業ディレクトリが用意されていませんでした。\n[' + workdir + ']');

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this5, [[1, 6], [8, 13]]);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 商品データベースへの接続準備

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 商品データベースへの接続準備

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// 読み取りフォルダ

// 書き込みフォルダ

// workdir が準備されていたら実行する

// 受注CSVを読み込む

//
// Robot-in
// 外部連携商品番号

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// workdir が準備されていたら実行する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/tooltest.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _meteorMeteor = require('meteor/meteor');

var tag = 'tool';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.test', function callee$0$0(config) {
  var report, filter, newLocal;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        context$1$0.next = 4;
        return regeneratorRuntime.awrap(filter.foreach({}, function callee$1$0(e) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                throw e;

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 4:
        newLocal = context$1$0.sent;
        context$1$0.next = 7;
        return regeneratorRuntime.awrap(report.phase('フィルターテスト', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                return context$2$0.abrupt('return', newLocal);

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 7:
        return context$1$0.abrupt('return', report.publish());

      case 8:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// 商品情報更新

// クライアントが参照するための処理結果作成オブジェクト
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowma.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _importsServiceWowmaApi = require('../imports/service/wowmaApi');

var _importsServiceWowmaApi2 = _interopRequireDefault(_importsServiceWowmaApi);

var _importsUtilError = require('../imports/util/error');

var _importsUtilError2 = _interopRequireDefault(_importsUtilError);

var tag = 'wowma';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateItem.info', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品情報を更新する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     },
                    //     {
                    //       'mall.wowma.itemCode': '10004942' // JK-120
                    //     }
                    // {
                    //   'mall.wowma.itemCode': '10005402'
                    // },
                    // {
                    //   'mall.wowma.itemCode': '10004743'
                    // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        Object.assign(item, config.itemInfo['default']);
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 4:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 8:
                        context$3$0.prev = 8;
                        context$3$0.t0 = context$3$0['catch'](1);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 8]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.deliveryMethod', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品の配送方法を設定する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     },
                    //     {
                    //       'mall.wowma.itemCode': '10004942' // JK-120
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        context$3$0.t0 = Object;
                        context$3$0.t1 = item;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.convertItemWowmaCreateDeliveryMethod(item.itemCode));

                      case 4:
                        context$3$0.t2 = context$3$0.sent;
                        context$3$0.t0.assign.call(context$3$0.t0, context$3$0.t1, context$3$0.t2);
                        context$3$0.prev = 6;
                        context$3$0.next = 9;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 9:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 13:
                        context$3$0.prev = 13;
                        context$3$0.t3 = context$3$0['catch'](6);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t3));

                      case 16:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[6, 13]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.open', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this6 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品データベース上の商品を公開する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        item.saleStatus = 1;
                        item.limitedPasswd = 'NULL';
                        context$3$0.prev = 2;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 5:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 9:
                        context$3$0.prev = 9;
                        context$3$0.t0 = context$3$0['catch'](2);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 12:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5, [[2, 9]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this6);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this7 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 在庫更新', function callee$1$0() {
          var itemController, cur, item, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, e, api, res;

          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    //   ,{
                    //     $or: [
                    //       {
                    //         'mall.wowma.itemCode': '10005402'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': 'gk-163'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': '10004743'
                    //       }
                    //     ]
                    //   }
                    ]
                  }
                }, {
                  // 配送方法の違いを省く
                  $group: {
                    _id: {
                      itemCode: '$mall.wowma.itemCode',
                      choicesStockHorizontalCode: '$mall.wowma.HChoiceName',
                      choicesStockVerticalCode: '$mall.wowma.VChoiceName'
                    },
                    item: {
                      $first: '$_id'
                    }
                  }
                }, {
                  // 商品ページごと（商品コード）にグループ化する
                  $group: {
                    _id: '$_id.itemCode',
                    variations: {
                      $push: {
                        _id: '$item',
                        choicesStockHorizontalCode: '$_id.choicesStockHorizontalCode',
                        choicesStockVerticalCode: '$_id.choicesStockVerticalCode'
                      }
                    }
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id',
                    variations: '$variations'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;

              case 6:
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(cur.hasNext());

              case 8:
                if (!context$2$0.sent) {
                  context$2$0.next = 53;
                  break;
                }

                context$2$0.next = 11;
                return regeneratorRuntime.awrap(cur.next());

              case 11:
                item = context$2$0.sent;
                _iteratorNormalCompletion = true;
                _didIteratorError = false;
                _iteratorError = undefined;
                context$2$0.prev = 15;
                _iterator = item.variations[Symbol.iterator]();

              case 17:
                if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                  context$2$0.next = 26;
                  break;
                }

                e = _step.value;
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(itemController.getStock(e._id));

              case 21:
                e.stock = context$2$0.sent;

                delete e._id;

              case 23:
                _iteratorNormalCompletion = true;
                context$2$0.next = 17;
                break;

              case 26:
                context$2$0.next = 32;
                break;

              case 28:
                context$2$0.prev = 28;
                context$2$0.t0 = context$2$0['catch'](15);
                _didIteratorError = true;
                _iteratorError = context$2$0.t0;

              case 32:
                context$2$0.prev = 32;
                context$2$0.prev = 33;

                if (!_iteratorNormalCompletion && _iterator['return']) {
                  _iterator['return']();
                }

              case 35:
                context$2$0.prev = 35;

                if (!_didIteratorError) {
                  context$2$0.next = 38;
                  break;
                }

                throw _iteratorError;

              case 38:
                return context$2$0.finish(35);

              case 39:
                return context$2$0.finish(32);

              case 40:
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.prev = 41;
                context$2$0.next = 44;
                return regeneratorRuntime.awrap(api.updateStock([item]));

              case 44:
                res = context$2$0.sent;

                report.iSuccess(res);
                context$2$0.next = 51;
                break;

              case 48:
                context$2$0.prev = 48;
                context$2$0.t1 = context$2$0['catch'](41);

                report.iError(context$2$0.t1);

              case 51:
                context$2$0.next = 6;
                break;

              case 53:
                cur.close();

              case 54:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this7, [[15, 28, 32, 40], [33,, 35, 39], [41, 48]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.searchItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this9 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, workdir, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this8 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.prev = 4;
                context$2$0.next = 7;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 7:
                context$2$0.next = 11;
                break;

              case 9:
                context$2$0.prev = 9;
                context$2$0.t0 = context$2$0['catch'](4);

              case 11:
                workdir = config.workdir + '/items_' + new Date().getTime();
                context$2$0.prev = 12;
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 15:
                context$2$0.next = 19;
                break;

              case 17:
                context$2$0.prev = 17;
                context$2$0.t1 = context$2$0['catch'](12);

              case 19:
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var options, repos, filename;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          options = JSON.parse(JSON.stringify(config.wowmaApi));

                          options.uri = options.uri + '/searchItemInfo';
                          options.qs.itemCode = item.mall.wowma.itemCode;

                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

                        case 5:
                          repos = context$3$0.sent;
                          filename = workdir + '/' + item.model + '.xml';
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(_fsExtra2['default'].writeFile(filename, repos));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this8);
                  } }));

              case 21:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this9, [[4, 9], [12, 17]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// WOWMA 商品情報の変更

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品の配送方法を設定する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品データベース上の商品を公開する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 在庫情報の作成

// let resMongo = await cur.toArray()
// return resMongo

// リクエストボディ

// 在庫を設定する

//
// 在庫更新リクエスト

//
// WOWMA 商品検索

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 作業フォルダを作成する

// APIから取得した商品情報を保存する場所

// 作業フォルダを作成する

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowmaApi.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'wowmaApi';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.getItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.WowmaApiItemFilter(config.wowmaApi, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          report.iSuccess(item);

                        case 1:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 6:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 8:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// WOWMA商品情報取得

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(config.workdir)
// } catch (e) {}

// // APIから取得した商品情報を保存する場所
// const workdir = `${config.workdir}/items_${(new Date()).getTime()}`
// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(workdir)
// } catch (e) {}

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/yauct.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilPacket = require('../imports/util/packet');

var _importsUtilPacket2 = _interopRequireDefault(_importsUtilPacket);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var prefix = 'packet';
var tag = 'yauct';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク受注', function callee$1$0() {
          var itemController, workdir, r, w;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                workdir = config.workdir + '/order';
                r = _fsExtra2['default'].createReadStream(workdir + '/' + config.orderLoadfile);
                w = _fsExtra2['default'].createWriteStream(workdir + '/' + config.orderSavefile);

                r.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(_csv2['default'].transform(function callee$2$0(record, callback) {
                  var err;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        err = null;
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.getModelClass(record['管理番号']));

                      case 4:
                        record['管理番号'] = context$3$0.sent;
                        context$3$0.next = 10;
                        break;

                      case 7:
                        context$3$0.prev = 7;
                        context$3$0.t0 = context$3$0['catch'](1);

                        err = context$3$0.t0;

                      case 10:
                        callback(err, record);

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 7]]);
                })).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(w);

              case 7:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibit', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク出品', function callee$1$0() {
          var filter, itemController, packet, workdir, uploaddir, cd, filename, name, fields, header, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                packet = new _importsUtilPacket2['default'](config.packetSize);
                context$2$0.prev = 5;
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 8:
                context$2$0.next = 12;
                break;

              case 10:
                context$2$0.prev = 10;
                context$2$0.t0 = context$2$0['catch'](5);

              case 12:
                workdir = config.workdir + '/work';
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(workdir));

              case 15:
                context$2$0.next = 17;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 17:
                uploaddir = config.workdir + '/upload';
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(uploaddir));

              case 20:
                context$2$0.next = 22;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(uploaddir));

              case 22:
                cd = null;
                filename = null;
                name = null;
                fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
                header = fields.map(function (v) {
                  return '"' + v + '"';
                }).join(',') + '\n';

                // パケット化開始時
                packet.onPacketStart = function callee$2$0(packetCount) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        name = prefix + ('00000' + packetCount).slice(-5);
                        cd = workdir + '/' + name;
                        filename = cd + '/' + config.csvFileName;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(cd));

                      case 5:
                        context$3$0.next = 7;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(header, 'Shift_JIS')));

                      case 7:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // パケット化時
                packet.onPacket = function callee$2$0(arg) {
                  var yauct, item, record, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, img, imgSrc, imgTgt;

                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        yauct = arg.yauct;
                        item = arg.item;
                        record = fields.map(function (v) {
                          return yauct[v] ? '"' + yauct[v] + '"' : '""';
                        }).join(',') + '\n';
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(record, 'Shift_JIS')));

                      case 5:
                        _iteratorNormalCompletion = true;
                        _didIteratorError = false;
                        _iteratorError = undefined;
                        context$3$0.prev = 8;
                        _iterator = item.images[Symbol.iterator]();

                      case 10:
                        if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                          context$3$0.next = 26;
                          break;
                        }

                        img = _step.value;
                        imgSrc = config.imagedir + '/' + img;
                        imgTgt = cd + '/' + img;
                        context$3$0.prev = 14;
                        context$3$0.next = 17;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].access(imgTgt));

                      case 17:
                        context$3$0.next = 23;
                        break;

                      case 19:
                        context$3$0.prev = 19;
                        context$3$0.t0 = context$3$0['catch'](14);
                        context$3$0.next = 23;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].copyFile(imgSrc, imgTgt));

                      case 23:
                        _iteratorNormalCompletion = true;
                        context$3$0.next = 10;
                        break;

                      case 26:
                        context$3$0.next = 32;
                        break;

                      case 28:
                        context$3$0.prev = 28;
                        context$3$0.t1 = context$3$0['catch'](8);
                        _didIteratorError = true;
                        _iteratorError = context$3$0.t1;

                      case 32:
                        context$3$0.prev = 32;
                        context$3$0.prev = 33;

                        if (!_iteratorNormalCompletion && _iterator['return']) {
                          _iterator['return']();
                        }

                      case 35:
                        context$3$0.prev = 35;

                        if (!_didIteratorError) {
                          context$3$0.next = 38;
                          break;
                        }

                        throw _iteratorError;

                      case 38:
                        return context$3$0.finish(35);

                      case 39:
                        return context$3$0.finish(32);

                      case 40:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[8, 28, 32, 40], [14, 19], [33,, 35, 39]]);
                };

                // パケット終了時
                packet.onPacketEnd = function callee$2$0(packetCount) {
                  var zip, zipname, output;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        zip = (0, _archiver2['default'])('zip');
                        zipname = uploaddir + '/' + name + '.zip';
                        output = _fsExtra2['default'].createWriteStream(zipname);

                        zip.pipe(output);
                        zip.directory(cd, false);
                        zip.finalize();

                      case 6:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // メインループ
                //

                context$2$0.next = 32;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var quantity, yauct;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;

                          if (!(quantity >= item.mall.yauct.minQuantity)) {
                            context$3$0.next = 9;
                            break;
                          }

                          context$3$0.next = 6;
                          return regeneratorRuntime.awrap(itemController.convertItemYauct(config['default'], item));

                        case 6:
                          yauct = context$3$0.sent;
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(packet.submit({ yauct: yauct, item: item }));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  } }));

              case 32:
                res = context$2$0.sent;

                packet.close();

                return context$2$0.abrupt('return', res);

              case 35:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[5, 10]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// ヤフオク受注ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 管理番号を置き換える

//
// ヤフオク出品ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 繰り返し処理を任意の（packetSize）で分割

// 作業フォルダを作成する

// CSVファイルを作成し画像データを収集する場所

// ZIPファイルを保存する場所
// パケットフォルダ
// csvファイル
// パケット番号

// CSVフィールドを定義し、順番を確定する

// CSVファイルにフィールドを設定する

// csvファイルにレコード（商品テンプレート）を追加する

// 画像ファイルをコピー

// 同じファイルがある場合はコピーしない

// itemに定義されている最低必要在庫より多い商品を出品する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
require('../imports/collections');

require('./route/upload/image');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"filters.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/filters.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _groups = require('./groups');

var Filters = new _meteorMongo.Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

var Filter = (function (_GroupBase) {
  _inherits(Filter, _GroupBase);

  function Filter(filterId) {
    var _this = this;

    _classCallCheck(this, Filter);

    var profile = Filters.findOne({
      _id: filterId
    });

    _get(Object.getPrototypeOf(Filter.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {

      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0() {
          var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
          var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table;
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, onError));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this);
        };
        break;

      default:
        throw new Error('invalid platform type');

    }
  }

  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */

  _createClass(Filter, [{
    key: 'foreach',
    value: function foreach() {
      var _this2 = this;

      var callbacks = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this2);
      } : arguments[1];

      var profile, count, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, filter;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this3 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              type: 'misc',
              query: {}
            });

            count = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              filter = _step.value;

              count[filter.type] = {
                query: filter.query,
                count: 0
              };
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record) {
              var _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, filter, query, exam;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion2 = true;
                    _didIteratorError2 = false;
                    _iteratorError2 = undefined;
                    context$3$0.prev = 3;
                    _iterator2 = profile.filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
                      context$3$0.next = 18;
                      break;
                    }

                    filter = _step2.value;
                    query = _mongoobject2['default'].unescape(filter.query);
                    exam = (0, _sift2['default'])(query);

                    if (!exam(record)) {
                      context$3$0.next = 15;
                      break;
                    }

                    count[filter.type].count++;

                    if (!(typeof callbacks[filter.type] !== 'undefined')) {
                      context$3$0.next = 14;
                      break;
                    }

                    context$3$0.next = 14;
                    return regeneratorRuntime.awrap(callbacks[filter.type](record));

                  case 14:
                    return context$3$0.abrupt('break', 18);

                  case 15:
                    _iteratorNormalCompletion2 = true;
                    context$3$0.next = 5;
                    break;

                  case 18:
                    context$3$0.next = 24;
                    break;

                  case 20:
                    context$3$0.prev = 20;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError2 = true;
                    _iteratorError2 = context$3$0.t0;

                  case 24:
                    context$3$0.prev = 24;
                    context$3$0.prev = 25;

                    if (!_iteratorNormalCompletion2 && _iterator2['return']) {
                      _iterator2['return']();
                    }

                  case 27:
                    context$3$0.prev = 27;

                    if (!_didIteratorError2) {
                      context$3$0.next = 30;
                      break;
                    }

                    throw _iteratorError2;

                  case 30:
                    return context$3$0.finish(27);

                  case 31:
                    return context$3$0.finish(24);

                  case 32:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this3, [[3, 20, 24, 32], [25,, 27, 31]]);
            }, onError));

          case 24:
            return context$2$0.abrupt('return', count);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21]]);
    }
  }]);

  return Filter;
})(_groups.GroupBase);

exports.Filter = Filter;

// return result of filtering
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/groups.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

var Groups = new _meteorMongo.Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

var GroupBase = (function () {
  function GroupBase(profile) {
    _classCallCheck(this, GroupBase);

    this.profile = profile;
  }

  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */

  _createClass(GroupBase, [{
    key: 'getPlug',
    value: function getPlug() {
      return this.profile.platformPlug;
    }
  }, {
    key: 'getProfile',
    value: function getProfile() {
      return this.profile;
    }
  }, {
    key: 'foreach',
    value: function foreach() {
      var _this = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
    }
  }]);

  return GroupBase;
})();

exports.GroupBase = GroupBase;

var Group = (function (_GroupBase) {
  _inherits(Group, _GroupBase);

  function Group(groupId) {
    var _this2 = this;

    _classCallCheck(this, Group);

    var profile = Groups.findOne({
      _id: groupId
    });

    _get(Object.getPrototypeOf(Group.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0(doc) {
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table + ' WHERE `' + doc.key + '` = "' + doc.id + '"';
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.query(sql));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this2);
        };
        break;
      default:
        throw new Error('invalid group type');
    }
  }

  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */

  _createClass(Group, [{
    key: 'foreach',
    value: function foreach() {
      var _this3 = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[1];

      var cur = Groups.find({
        groupId: this.profile._id
      }, {
        fields: {
          _id: 0,
          id: 1,
          key: 1
        }
      });

      return new Promise(function (resolve, reject) {

        cur.forEach(function callee$3$0(doc, index) {
          var record;
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                context$4$0.prev = 0;
                context$4$0.next = 3;
                return regeneratorRuntime.awrap(this['import'](doc));

              case 3:
                record = context$4$0.sent;
                context$4$0.next = 6;
                return regeneratorRuntime.awrap(callback(record));

              case 6:
                context$4$0.next = 11;
                break;

              case 8:
                context$4$0.prev = 8;
                context$4$0.t0 = context$4$0['catch'](0);

                onError(context$4$0.t0);

              case 11:
                if (index + 1 === cur.count()) {
                  resolve();
                }

              case 12:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this3, [[0, 8]]);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }]);

  return Group;
})(GroupBase);

exports.Group = Group;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/cube3api.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _utilSyncObject = require('../util/syncObject');

var _utilSyncObject2 = _interopRequireDefault(_utilSyncObject);

var Cube3Api = (function () {
  /**
   *
   * @param {MySQL} mysql
   */

  function Cube3Api(mysql) {
    _classCallCheck(this, Cube3Api);

    this.mysql = mysql;
  }

  _createClass(Cube3Api, [{
    key: 'modifyCategory',
    value: function modifyCategory(productId, categoryIdArray) {
      var tableCategory, colSrc, sql, colDst, results;
      return regeneratorRuntime.async(function modifyCategory$(context$2$0) {
        var _this = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            tableCategory = 'dtb_product_category';
            colSrc = [];

            categoryIdArray.forEach(function (elem) {
              colSrc.push({
                product_id: productId,
                category_id: elem
              });
            });

            // モールデータベースから現在の商品カテゴリー情報を取得
            sql = '\n    SELECT product_id, category_id\n    FROM ' + tableCategory + '\n    WHERE product_id = ' + productId + '\n    ';
            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.mysql.querySelect(tableCategory, 'product_id = ' + productId, 'product_id, category_id'));

          case 6:
            colDst = context$2$0.sent;
            results = [];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap((0, _utilSyncObject2['default'])(colSrc, colDst, null, function callee$2$0(id, object) {
              var res;
              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    context$3$0.next = 2;
                    return regeneratorRuntime.awrap(this.mysql.queryInsert(tableCategory, {}, Object.assign({ rank: 1 }, object)));

                  case 2:
                    res = context$3$0.sent;

                    results.push(res);

                  case 4:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            }, function callee$2$0(id, object) {
              var res;
              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    context$3$0.next = 2;
                    return regeneratorRuntime.awrap(this.mysql.query('\n          DELETE FROM ' + tableCategory + '\n          WHERE product_id = ' + object.product_id + '\n            AND category_id = ' + object.category_id + '\n          '));

                  case 2:
                    res = context$3$0.sent;

                    results.push(res);

                  case 4:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            }));

          case 10:
            return context$2$0.abrupt('return', results);

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(productClassId) {
      var quantity = arguments.length <= 1 || arguments[1] === undefined ? 0 : arguments[1];
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_class', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              stock_unlimited: 0,
              update_date: 'NOW()'
            }));

          case 2:
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_stock', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              update_date: 'NOW()'
            }));

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productTagUpdate',
    value: function productTagUpdate(data) {
      var creatorId, res, tagoff, tagon, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, tagSet;

      return regeneratorRuntime.async(function productTagUpdate$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = [];

            tagoff = function tagoff(tag) {
              var sql;
              return regeneratorRuntime.async(function tagoff$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      DELETE FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.t0 = res;
                    context$3$0.next = 4;
                    return regeneratorRuntime.awrap(this.mysql.query(sql));

                  case 4:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 6:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2);
            };

            tagon = function tagon(tag) {
              var sql, countRes;
              return regeneratorRuntime.async(function tagon$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      SELECT COUNT(*) FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.next = 3;
                    return regeneratorRuntime.awrap(this.mysql.query(sql));

                  case 3:
                    countRes = context$3$0.sent;

                    if (!countRes[0]['COUNT(*)']) {
                      context$3$0.next = 6;
                      break;
                    }

                    return context$3$0.abrupt('return');

                  case 6:
                    context$3$0.t0 = res;
                    context$3$0.next = 9;
                    return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_tag', {}, {
                      product_id: data.product_id,
                      tag: tag,
                      creator_id: creatorId,
                      create_date: 'NOW()'
                    }));

                  case 9:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 11:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2);
            };

            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 7;
            _iterator = data.tags[Symbol.iterator]();

          case 9:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 23;
              break;
            }

            tagSet = _step.value;
            context$2$0.t0 = tagSet.set;
            context$2$0.next = context$2$0.t0 === 'on' ? 14 : context$2$0.t0 === 'off' ? 17 : 20;
            break;

          case 14:
            context$2$0.next = 16;
            return regeneratorRuntime.awrap(tagon(tagSet.tag));

          case 16:
            return context$2$0.abrupt('break', 20);

          case 17:
            context$2$0.next = 19;
            return regeneratorRuntime.awrap(tagoff(tagSet.tag));

          case 19:
            return context$2$0.abrupt('break', 20);

          case 20:
            _iteratorNormalCompletion = true;
            context$2$0.next = 9;
            break;

          case 23:
            context$2$0.next = 29;
            break;

          case 25:
            context$2$0.prev = 25;
            context$2$0.t1 = context$2$0['catch'](7);
            _didIteratorError = true;
            _iteratorError = context$2$0.t1;

          case 29:
            context$2$0.prev = 29;
            context$2$0.prev = 30;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 32:
            context$2$0.prev = 32;

            if (!_didIteratorError) {
              context$2$0.next = 35;
              break;
            }

            throw _iteratorError;

          case 35:
            return context$2$0.finish(32);

          case 36:
            return context$2$0.finish(29);

          case 37:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 38:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[7, 25, 29, 37], [30,, 32, 36]]);
    }
  }, {
    key: 'productImageUpdate',
    value: function productImageUpdate(data) {
      var productId, images, creatorId, res, sql, i;
      return regeneratorRuntime.async(function productImageUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productId = data.product_id;
            images = data.images;
            creatorId = data.creator_id;
            res = [];
            sql = 'DELETE FROM dtb_product_image WHERE product_id = ' + productId;
            context$2$0.t0 = res;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(this.mysql.query(sql));

          case 8:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t1);
            i = 0;

          case 11:
            if (!(i < images.length)) {
              context$2$0.next = 17;
              break;
            }

            context$2$0.next = 14;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_image', {
              product_id: productId,
              creator_id: creatorId,
              file_name: images[i],
              rank: i + 1
            }, {
              create_date: 'NOW()'
            }));

          case 14:
            i++;
            context$2$0.next = 11;
            break;

          case 17:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productUpdate',
    value: function productUpdate(data) {
      var updateData, keys, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, k, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, res;

      return regeneratorRuntime.async(function productUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            updateData = {};
            keys = [];

            // dtb_product

            keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 6;
            for (_iterator2 = keys[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              if (data[k]) {
                updateData[k] = data[k];
              }
            }

            // [
            //   'status',
            //   'name',
            //   'note',
            //   'description_list',
            //   'description_detail',
            //   'search_word',
            //   'free_area',
            // ].forEach(
            //   (v) => {
            //     if (data[v]) {
            //       updateData[v] = data[v];
            //     }
            //   },
            // );

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError2) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError2;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 24:

            // dtb_product_class

            updateData = {};
            keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 29;
            for (_iterator3 = keys[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 37;
            break;

          case 33:
            context$2$0.prev = 33;
            context$2$0.t1 = context$2$0['catch'](29);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t1;

          case 37:
            context$2$0.prev = 37;
            context$2$0.prev = 38;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 40:
            context$2$0.prev = 40;

            if (!_didIteratorError3) {
              context$2$0.next = 43;
              break;
            }

            throw _iteratorError3;

          case 43:
            return context$2$0.finish(40);

          case 44:
            return context$2$0.finish(37);

          case 45:
            context$2$0.next = 47;
            return regeneratorRuntime.awrap(this.mysql.queryUpdate('dtb_product_class', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 47:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 49:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [29, 33, 37, 45], [38,, 40, 44]]);
    }
  }, {
    key: 'productCreate',
    value: function productCreate(data) {
      var creatorId, res, updateData, keys, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, k, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6;

      return regeneratorRuntime.async(function productCreate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = {};
            updateData = {};
            keys = [];

            keys = ['name', 'description_detail'];
            // {
            //   name: item.name,
            //   description_detail: item.description,
            // },

            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 8;
            for (_iterator4 = keys[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 16;
            break;

          case 12:
            context$2$0.prev = 12;
            context$2$0.t0 = context$2$0['catch'](8);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t0;

          case 16:
            context$2$0.prev = 16;
            context$2$0.prev = 17;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 19:
            context$2$0.prev = 19;

            if (!_didIteratorError4) {
              context$2$0.next = 22;
              break;
            }

            throw _iteratorError4;

          case 22:
            return context$2$0.finish(19);

          case 23:
            return context$2$0.finish(16);

          case 24:
            context$2$0.next = 26;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product', updateData, {
              creator_id: creatorId,
              status: 1,
              note: 'NULL',
              description_list: 'NULL',
              search_word: 'NULL',
              free_area: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 26:
            res.product_id = context$2$0.sent;

            updateData = {};
            keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee'];
            // {
            //   product_code: item.model,
            //   price01: item.retail_price,
            //   price02: item.sales_price,
            // },

            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 32;
            for (_iterator5 = keys[Symbol.iterator](); !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
              k = _step5.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 40;
            break;

          case 36:
            context$2$0.prev = 36;
            context$2$0.t1 = context$2$0['catch'](32);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t1;

          case 40:
            context$2$0.prev = 40;
            context$2$0.prev = 41;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 43:
            context$2$0.prev = 43;

            if (!_didIteratorError5) {
              context$2$0.next = 46;
              break;
            }

            throw _iteratorError5;

          case 46:
            return context$2$0.finish(43);

          case 47:
            return context$2$0.finish(40);

          case 48:
            context$2$0.next = 50;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_class', updateData, {
              creator_id: creatorId,
              product_id: res.product_id,
              stock: 0,
              stock_unlimited: 0,
              class_category_id1: 'NULL',
              class_category_id2: 'NULL',
              delivery_date_id: 'NULL',
              sale_limit: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 50:
            res.product_class_id = context$2$0.sent;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 54;

            for (_iterator6 = keys[Symbol.iterator](); !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
              k = _step6.value;
              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 62;
            break;

          case 58:
            context$2$0.prev = 58;
            context$2$0.t2 = context$2$0['catch'](54);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t2;

          case 62:
            context$2$0.prev = 62;
            context$2$0.prev = 63;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 65:
            context$2$0.prev = 65;

            if (!_didIteratorError6) {
              context$2$0.next = 68;
              break;
            }

            throw _iteratorError6;

          case 68:
            return context$2$0.finish(65);

          case 69:
            return context$2$0.finish(62);

          case 70:
            context$2$0.next = 72;
            return regeneratorRuntime.awrap(this.mysql.queryInsert('dtb_product_stock', {}, {
              product_class_id: res.product_class_id,
              creator_id: creatorId,
              stock: 0,
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 72:
            res.product_stock_id = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res:

              // for test
              res
            });

          case 74:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 12, 16, 24], [17,, 19, 23], [32, 36, 40, 48], [41,, 43, 47], [54, 58, 62, 70], [63,, 65, 69]]);
    }
  }]);

  return Cube3Api;
})();

exports.Cube3Api = Cube3Api;

// 商品情報データベースに記録された商品カテゴリー情報

// const colDst = JSON.parse(JSON.stringify(await this.mysql.query(sql)));

// 各SQLクエリの結果すべてを記録する

// 削除するタグ

// 表示するタグ

// すでに表示されているタグがあれば何もしない

// 商品に関連するすべての画像情報を削除する

// 改めて画像を登録しなおす
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/dbfilter.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _xmlJs = require('xml-js');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var DBFilterFactory = function DBFilterFactory(plug, profile) {
  _classCallCheck(this, DBFilterFactory);

  var instance = undefined;
  switch (plug.type) {
    case 'mysql':
      instance = new MysqlDBFilter(plug, profile);
  }

  return instance;
};

exports.DBFilterFactory = DBFilterFactory;

var DBFilter = (function () {
  function DBFilter(plug, profile) {
    _classCallCheck(this, DBFilter);

    this.plug = plug;
    this.profile = profile;
  }

  _createClass(DBFilter, [{
    key: 'getPlug_',
    value: function getPlug_() {
      return this.plug;
    }
  }, {
    key: 'getCred_',
    value: function getCred_() {
      return this.plug.cred;
    }
  }, {
    key: 'getProfile_',
    value: function getProfile_() {
      return this.profile;
    }
  }, {
    key: 'setImportFunction_',
    value: function setImportFunction_() {
      var _this = this;

      var fn = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0() {
        var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
        var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];

      this['import'] = fn;
    }

    /**
     * traces members of the group
     * useage:
     *
     *
     * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
     * @param { async function } onError error handler while iterating
     * @returns { Object } { filterName: { query: any, count: number }, ... }
     */
  }, {
    key: 'foreach',
    value: function foreach() {
      var iterators = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      var profile, counter, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, f, filters, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile_();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              name: 'misc',
              query: {}
            });

            counter = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              f = _step.value;
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            filters = [];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 26;

            for (_iterator2 = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              f = _step2.value;

              counter[f.name] = {
                query: f.query,
                limit: typeof f.limit !== 'undefined' ? f.limit : 0,
                count: 0
              };
              filters.push({
                name: f.name,
                exam: (0, _sift2['default'])(_mongoobject2['default'].unescape(f.query))
              });
            }

            context$2$0.next = 34;
            break;

          case 30:
            context$2$0.prev = 30;
            context$2$0.t1 = context$2$0['catch'](26);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 34:
            context$2$0.prev = 34;
            context$2$0.prev = 35;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 37:
            context$2$0.prev = 37;

            if (!_didIteratorError2) {
              context$2$0.next = 40;
              break;
            }

            throw _iteratorError2;

          case 40:
            return context$2$0.finish(37);

          case 41:
            return context$2$0.finish(34);

          case 42:
            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record, context) {
              var _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, f, c;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion3 = true;
                    _didIteratorError3 = false;
                    _iteratorError3 = undefined;
                    context$3$0.prev = 3;
                    _iterator3 = filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
                      context$3$0.next = 20;
                      break;
                    }

                    f = _step3.value;
                    c = counter[f.name];

                    if (!c.limit) {
                      context$3$0.next = 11;
                      break;
                    }

                    if (!(c.count >= c.limit)) {
                      context$3$0.next = 11;
                      break;
                    }

                    return context$3$0.abrupt('continue', 17);

                  case 11:
                    if (!f.exam(record)) {
                      context$3$0.next = 17;
                      break;
                    }

                    // counter limiter
                    c.count++;

                    // iterator

                    if (!(typeof iterators[f.name] !== 'undefined')) {
                      context$3$0.next = 16;
                      break;
                    }

                    context$3$0.next = 16;
                    return regeneratorRuntime.awrap(iterators[f.name](record, context));

                  case 16:
                    return context$3$0.abrupt('break', 20);

                  case 17:
                    _iteratorNormalCompletion3 = true;
                    context$3$0.next = 5;
                    break;

                  case 20:
                    context$3$0.next = 26;
                    break;

                  case 22:
                    context$3$0.prev = 22;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError3 = true;
                    _iteratorError3 = context$3$0.t0;

                  case 26:
                    context$3$0.prev = 26;
                    context$3$0.prev = 27;

                    if (!_iteratorNormalCompletion3 && _iterator3['return']) {
                      _iterator3['return']();
                    }

                  case 29:
                    context$3$0.prev = 29;

                    if (!_didIteratorError3) {
                      context$3$0.next = 32;
                      break;
                    }

                    throw _iteratorError3;

                  case 32:
                    return context$3$0.finish(29);

                  case 33:
                    return context$3$0.finish(26);

                  case 34:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2, [[3, 22, 26, 34], [27,, 29, 33]]);
            }));

          case 44:
            return context$2$0.abrupt('return', counter);

          case 45:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [26, 30, 34, 42], [35,, 37, 41]]);
    }
  }], [{
    key: 'factory',
    value: function factory(plug, profile) {
      switch (plug.type) {
        case 'mysql':
          return new MysqlDBFilter(plug, profile);
        default:
          throw new Error('invalid plug type');
      }
    }
  }]);

  return DBFilter;
})();

exports.DBFilter = DBFilter;

var MysqlDBFilter = (function (_DBFilter) {
  _inherits(MysqlDBFilter, _DBFilter);

  function MysqlDBFilter(plug, profile) {
    var _this3 = this;

    _classCallCheck(this, MysqlDBFilter);

    _get(Object.getPrototypeOf(MysqlDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    var cred = this.getCred_();

    this.mysql = new _utilMysql2['default'](cred);
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var sql, res;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            sql = 'SELECT * FROM ' + plug.table;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, function (e) {
              throw e;
            }));

          case 3:
            res = context$3$0.sent;
            return context$3$0.abrupt('return', res);

          case 5:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this3);
    });
  }

  // import MongoNative from 'mongodb';
  // const MongoClient = MongoNative.MongoClient;
  // const MongoClient = require('mongodb').MongoClient;

  return MysqlDBFilter;
})(DBFilter);

exports.MysqlDBFilter = MysqlDBFilter;

var MongoDBFilter = (function (_DBFilter2) {
  _inherits(MongoDBFilter, _DBFilter2);

  function MongoDBFilter(plug, profile) {
    var _this4 = this;

    _classCallCheck(this, MongoDBFilter);

    _get(Object.getPrototypeOf(MongoDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    // mongo へ接続
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var client, db, collection, context, cur, doc;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            client = undefined;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri, { useNewUrlParser: true }));

          case 3:
            client = context$3$0.sent;
            db = client.db(plug.database);
            collection = db.collection(plug.collection);
            context = {
              client: client,
              collection: collection,
              database: db
            };
            cur = collection.find();

            // カーソルのタイムアウトを解除
            cur.addCursorFlag('noCursorTimeout', true);

            // すべてのドキュメントをループ
            context$3$0.prev = 9;

          case 10:
            context$3$0.next = 12;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 12:
            if (!context$3$0.sent) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 15;
            return regeneratorRuntime.awrap(cur.next());

          case 15:
            doc = context$3$0.sent;
            context$3$0.next = 18;
            return regeneratorRuntime.awrap(onResult(doc, context));

          case 18:
            context$3$0.next = 10;
            break;

          case 20:
            context$3$0.prev = 20;
            context$3$0.next = 23;
            return regeneratorRuntime.awrap(cur.close());

          case 23:
            return context$3$0.finish(20);

          case 24:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this4, [[9,, 20, 24]]);
    });
  }

  return MongoDBFilter;
})(DBFilter);

exports.MongoDBFilter = MongoDBFilter;

var WowmaApiItemFilter = (function (_DBFilter3) {
  _inherits(WowmaApiItemFilter, _DBFilter3);

  function WowmaApiItemFilter(plug, profile) {
    var _this5 = this;

    _classCallCheck(this, WowmaApiItemFilter);

    _get(Object.getPrototypeOf(WowmaApiItemFilter.prototype), 'constructor', this).call(this, plug, profile);

    // 商品情報の取得ループを定義
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var options, context, res, maxCount, resultCount, startCount, resultStocks, i, next;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            options = JSON.parse(JSON.stringify(plug));

            options.uri = options.uri + '/searchStocks';
            context = {
              options: options
            };

          case 3:
            if (!1) {
              context$3$0.next = 30;
              break;
            }

            context$3$0.next = 6;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

          case 6:
            res = context$3$0.sent;

            res = (0, _xmlJs.xml2js)(res, { compact: true });

            maxCount = Number(res.response.searchResult.maxCount._text);
            resultCount = Number(res.response.searchResult.resultCount._text);
            startCount = Number(res.response.searchResult.startCount._text);
            resultStocks = res.response.searchResult.resultStocks;

            if (!(resultStocks instanceof Array)) {
              context$3$0.next = 22;
              break;
            }

            i = 0;

          case 14:
            if (!(i < resultCount)) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 17;
            return regeneratorRuntime.awrap(onResult(resultStocks[i], context));

          case 17:
            i++;
            context$3$0.next = 14;
            break;

          case 20:
            context$3$0.next = 24;
            break;

          case 22:
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(onResult(resultStocks, context));

          case 24:
            next = startCount + resultCount;

            if (!(next > maxCount)) {
              context$3$0.next = 27;
              break;
            }

            return context$3$0.abrupt('break', 30);

          case 27:
            options.qs.startCount = next;
            context$3$0.next = 3;
            break;

          case 30:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this5);
    });
  }

  // import mongoose from 'mongoose';

  // export class MongoDBFilter extends DBFilter {
  //   constructor(plug, profile) {
  //     super(plug, profile);

  //     // mongo へ接続
  //     let cred = this.getCred_();
  //     let conuri = `mongodb://${cred.host}:${cred.port}/${cred.database}`;
  //     await mongoose.connect(conuri);

  //     // コレクションを作る
  //     let collection = mongoose.connection.collection(plug.collection);

  //     this.setImportFunction_(async (onResult, onError) => {
  //       let cur = collection.find();

  //       return await this.mysql.streamingQuery(sql, onResult, onError);
  //     });
  //   }
  // }
  return WowmaApiItemFilter;
})(DBFilter);

exports.WowmaApiItemFilter = WowmaApiItemFilter;

// counter limiter

// return result of filtering

// コレクションを取得

// カーソルを開放

// コレクションを取得

// Wowma Api から商品情報を取得

// 取得した商品情報をカスタムプロセスに渡す

// 取得したデータが複数商品の場合

// 取得したデータが単数商品の場合
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/items.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMongo = require('../util/mongo');

var _collections = require('../collections');

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var ItemController = (function () {
  function ItemController() {
    _classCallCheck(this, ItemController);
  }

  _createClass(ItemController, [{
    key: 'init',

    /**
     *
     * @param {{uri:string, database:string, collection:string}} plug
     */
    value: function init(plug) {
      return regeneratorRuntime.async(function init$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'items'));

          case 2:
            this.Items = context$2$0.sent;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'products'));

          case 5:
            this.Products = context$2$0.sent;

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'getStock',
    value: function getStock(itemId) {
      var item, productSet, quantities, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, productRef, prdQuantity, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, id, product, stockArray, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, stock, quantity;

      return regeneratorRuntime.async(function getStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.Items.findOne({
              _id: itemId
            }, {
              projection: {
                product: 1
              }
            }));

          case 2:
            item = context$2$0.sent;
            productSet = item.product;
            quantities = [];
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 8;
            _iterator = productSet[Symbol.iterator]();

          case 10:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 64;
              break;
            }

            productRef = _step.value;
            prdQuantity = 0;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 16;
            _iterator2 = productRef.ids[Symbol.iterator]();

          case 18:
            if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
              context$2$0.next = 46;
              break;
            }

            id = _step2.value;
            context$2$0.next = 22;
            return regeneratorRuntime.awrap(this.Products.findOne({
              _id: id
            }, {
              projection: {
                stock: 1
              }
            }));

          case 22:
            product = context$2$0.sent;
            stockArray = product.stock;
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 27;

            // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算
            for (_iterator3 = stockArray[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              stock = _step3.value;
              prdQuantity += stock.quantity;
            }context$2$0.next = 35;
            break;

          case 31:
            context$2$0.prev = 31;
            context$2$0.t0 = context$2$0['catch'](27);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 35:
            context$2$0.prev = 35;
            context$2$0.prev = 36;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 38:
            context$2$0.prev = 38;

            if (!_didIteratorError3) {
              context$2$0.next = 41;
              break;
            }

            throw _iteratorError3;

          case 41:
            return context$2$0.finish(38);

          case 42:
            return context$2$0.finish(35);

          case 43:
            _iteratorNormalCompletion2 = true;
            context$2$0.next = 18;
            break;

          case 46:
            context$2$0.next = 52;
            break;

          case 48:
            context$2$0.prev = 48;
            context$2$0.t1 = context$2$0['catch'](16);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 52:
            context$2$0.prev = 52;
            context$2$0.prev = 53;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 55:
            context$2$0.prev = 55;

            if (!_didIteratorError2) {
              context$2$0.next = 58;
              break;
            }

            throw _iteratorError2;

          case 58:
            return context$2$0.finish(55);

          case 59:
            return context$2$0.finish(52);

          case 60:

            // 商品(item)の在庫数 = 製品在庫数(prdQuantity) / 必要セット数(productRef.set)
            quantities.push(Math.floor(prdQuantity / productRef.set));

          case 61:
            _iteratorNormalCompletion = true;
            context$2$0.next = 10;
            break;

          case 64:
            context$2$0.next = 70;
            break;

          case 66:
            context$2$0.prev = 66;
            context$2$0.t2 = context$2$0['catch'](8);
            _didIteratorError = true;
            _iteratorError = context$2$0.t2;

          case 70:
            context$2$0.prev = 70;
            context$2$0.prev = 71;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 73:
            context$2$0.prev = 73;

            if (!_didIteratorError) {
              context$2$0.next = 76;
              break;
            }

            throw _iteratorError;

          case 76:
            return context$2$0.finish(73);

          case 77:
            return context$2$0.finish(70);

          case 78:
            quantity = Math.min.apply(null, quantities);
            return context$2$0.abrupt('return', quantity);

          case 80:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 66, 70, 78], [16, 48, 52, 60], [27, 31, 35, 43], [36,, 38, 42], [53,, 55, 59], [71,, 73, 77]]);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに、
     * アップロード済み画像を関連付ける。
     *
     * メーカーモデルに共通の画像を一括で関連付けたい場合、
     * class1、class2引数を指定せずに実行する。
     *
     * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
     * class1に値を指定し、class2引数を指定せずに実行する。
     * もしclass2のみ指定したい場合はclass1にnullを指定する。
     *
     * 例：JK-100のBLACKの商品画像を
     * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
     * setImage( uploadId, 'JK-100', 'BLACK' );
     *
     * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'setImage',
    value: function setImage(uploadId, model) {
      var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
      var images, filter, res;
      return regeneratorRuntime.async(function setImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            images = _collections.Uploads.find({
              uploadId: uploadId
            }).fetch().map(function (v) {
              return v.uploadedFileName;
            });
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $push: {
                images: {
                  $each: images
                }
              }
            }));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', images);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
     *
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'cleanImage',
    value: function cleanImage(model) {
      var class1 = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
      var class2 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var filter, res;
      return regeneratorRuntime.async(function cleanImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $set: {
                images: []
              }
            }));

          case 6:
            res = context$2$0.sent;

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * 指定の商品に関連する商品群の属性別の商品情報を返す。
     *
     * 引数として受け取るitemは任意の商品情報。
     * itemに関連する商品群について必要な情報を整理し返す。
     *
     * projectに参照したい商品情報フィールドを定義する。
     * メソッドの呼び出し時に必要に応じてprojectを設定する。
     *
     * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
     *
     * @param {Object} item
     * @param {Object} project
     */
  }, {
    key: 'getVariation',
    value: function getVariation(item, project) {
      var set, attrs, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, s, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, attr, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6, v;

      return regeneratorRuntime.async(function getVariation$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            set = [{
              label: '配送方法',
              current: item.delivery,
              project: {
                value: '$delivery'
              },
              query: {
                class1_value: item.class1_value,
                class2_value: item.class2_value
              }
            }, {
              label: item.class1_name,
              current: item.class1_value,
              project: {
                value: '$class1_value'
              },
              query: {
                delivery: item.delivery,
                class2_value: item.class2_value
              }
            }, {
              label: item.class2_name,
              current: item.class2_value,
              project: {
                value: '$class2_value'
              },
              query: {
                delivery: item.delivery,
                class1_value: item.class1_value
              }
            }];
            attrs = [];
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 5;
            _iterator4 = set[Symbol.iterator]();

          case 7:
            if (_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done) {
              context$2$0.next = 19;
              break;
            }

            s = _step4.value;
            context$2$0.t0 = attrs;
            context$2$0.next = 12;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: Object.assign(s.query, {
                model: item.model
              })
            }, {
              $project: Object.assign(s.project, project)
            }, {
              $sort: {
                _id: 1
              }
            }]).toArray());

          case 12:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = s;
            context$2$0.t3 = {
              variations: context$2$0.t1,
              props: context$2$0.t2
            };
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t3);

          case 16:
            _iteratorNormalCompletion4 = true;
            context$2$0.next = 7;
            break;

          case 19:
            context$2$0.next = 25;
            break;

          case 21:
            context$2$0.prev = 21;
            context$2$0.t4 = context$2$0['catch'](5);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t4;

          case 25:
            context$2$0.prev = 25;
            context$2$0.prev = 26;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 28:
            context$2$0.prev = 28;

            if (!_didIteratorError4) {
              context$2$0.next = 31;
              break;
            }

            throw _iteratorError4;

          case 31:
            return context$2$0.finish(28);

          case 32:
            return context$2$0.finish(25);

          case 33:
            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 36;
            _iterator5 = attrs[Symbol.iterator]();

          case 38:
            if (_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done) {
              context$2$0.next = 70;
              break;
            }

            attr = _step5.value;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 43;
            _iterator6 = attr.variations[Symbol.iterator]();

          case 45:
            if (_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done) {
              context$2$0.next = 53;
              break;
            }

            v = _step6.value;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.getStock(v._id));

          case 49:
            v.stock = context$2$0.sent;

          case 50:
            _iteratorNormalCompletion6 = true;
            context$2$0.next = 45;
            break;

          case 53:
            context$2$0.next = 59;
            break;

          case 55:
            context$2$0.prev = 55;
            context$2$0.t5 = context$2$0['catch'](43);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t5;

          case 59:
            context$2$0.prev = 59;
            context$2$0.prev = 60;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 62:
            context$2$0.prev = 62;

            if (!_didIteratorError6) {
              context$2$0.next = 65;
              break;
            }

            throw _iteratorError6;

          case 65:
            return context$2$0.finish(62);

          case 66:
            return context$2$0.finish(59);

          case 67:
            _iteratorNormalCompletion5 = true;
            context$2$0.next = 38;
            break;

          case 70:
            context$2$0.next = 76;
            break;

          case 72:
            context$2$0.prev = 72;
            context$2$0.t6 = context$2$0['catch'](36);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t6;

          case 76:
            context$2$0.prev = 76;
            context$2$0.prev = 77;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 79:
            context$2$0.prev = 79;

            if (!_didIteratorError5) {
              context$2$0.next = 82;
              break;
            }

            throw _iteratorError5;

          case 82:
            return context$2$0.finish(79);

          case 83:
            return context$2$0.finish(76);

          case 84:
            return context$2$0.abrupt('return', attrs);

          case 85:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 21, 25, 33], [26,, 28, 32], [36, 72, 76, 84], [43, 55, 59, 67], [60,, 62, 66], [77,, 79, 83]]);
    }

    // モデルクラス形式を作る
    // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
  }, {
    key: 'getModelClass',
    value: function getModelClass(arg) {
      var item, exp, cur, match, modelClass;
      return regeneratorRuntime.async(function getModelClass$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            item = undefined;

            if (!(typeof arg === 'string')) {
              context$2$0.next = 25;
              break;
            }

            exp = new RegExp(arg + '$');
            cur = this.Items.find({}, {
              projection: {
                model: 1,
                class1_value: 1,
                class2_value: 1
              }
            });

          case 4:
            if (!1) {
              context$2$0.next = 22;
              break;
            }

            context$2$0.prev = 5;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(cur.next());

          case 8:
            item = context$2$0.sent;
            context$2$0.next = 11;
            return regeneratorRuntime.awrap(item._id.toHexString().match(exp));

          case 11:
            match = context$2$0.sent;

            if (!match) {
              context$2$0.next = 14;
              break;
            }

            return context$2$0.abrupt('break', 22);

          case 14:
            context$2$0.next = 20;
            break;

          case 16:
            context$2$0.prev = 16;
            context$2$0.t0 = context$2$0['catch'](5);

            // 該当するitemデータがない
            cur.close();
            return context$2$0.abrupt('return', arg);

          case 20:
            context$2$0.next = 4;
            break;

          case 22:
            cur.close();
            context$2$0.next = 26;
            break;

          case 25:
            item = arg;

          case 26:
            modelClass = [];

            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);
            return context$2$0.abrupt('return', modelClass.join('/'));

          case 31:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 16]]);
    }
  }, {
    key: 'convertItemCube3',
    value: function convertItemCube3(configUploadItem, item) {
      var convDeliv, productId, modelClass, productTypeId, tags, deliveryFee, attrs, variationHtml, descriptionDetail, data;
      return regeneratorRuntime.async(function convertItemCube3$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            convDeliv = function convDeliv(delivery) {
              return delivery === 'ゆうパケット' ? 'ポスト投函' : delivery;
            };

            productId = null;
            modelClass = [];

            // 下記の形式を作る
            // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);

            // 商品種別を割り当てる
            productTypeId = undefined;
            context$2$0.t0 = item.delivery;
            context$2$0.next = context$2$0.t0 === '宅配便' ? 10 : context$2$0.t0 === 'ゆうパケット' ? 12 : 14;
            break;

          case 10:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 12:
            productTypeId = 2;
            return context$2$0.abrupt('break', 16);

          case 14:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 16:
            tags = [];
            context$2$0.t1 = item.delivery;
            context$2$0.next = context$2$0.t1 === '宅配便' ? 20 : context$2$0.t1 === 'ゆうパケット' ? 22 : 24;
            break;

          case 20:
            tags.push({
              tag: 4,
              set: 'on'
            }, {
              tag: 5,
              set: 'off'
            });
            return context$2$0.abrupt('break', 25);

          case 22:
            tags.push({
              tag: 5,
              set: 'on'
            }, {
              tag: 4,
              set: 'off'
            });
            return context$2$0.abrupt('break', 25);

          case 24:
            return context$2$0.abrupt('break', 25);

          case 25:
            deliveryFee = null;
            context$2$0.t2 = item.delivery;
            context$2$0.next = context$2$0.t2 === '宅配便' ? 29 : context$2$0.t2 === 'ゆうパケット' ? 31 : 33;
            break;

          case 29:
            deliveryFee = null;
            return context$2$0.abrupt('break', 34);

          case 31:
            deliveryFee = 240;
            return context$2$0.abrupt('break', 34);

          case 33:
            return context$2$0.abrupt('break', 34);

          case 34:
            context$2$0.next = 36;
            return regeneratorRuntime.awrap(this.getVariation(item, {
              product_id: '$mall.sharakuShop.product_id'
            }));

          case 36:
            attrs = context$2$0.sent;

            // HTML バリエーション商品ごとのリンク付きボタンを表示する

            // 値の変換
            attrs = attrs.map(function (attr) {
              attr.props.current = convDeliv(attr.props.current);
              attr.variations = attr.variations.map(function (variation) {
                variation.value = convDeliv(variation.value);
                return variation;
              });
              return attr;
            });

            // HTML生成
            variationHtml = attrs.map(function (attr) {
              return '' + ('<div class="container-fluid">' + '<div class="row">' + '<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">' + ('<strong>' + attr.props.label + '</strong>') + '</div>') + attr.variations.map(function (variation) {
                if (attr.props.current === variation.value) {
                  // 表示中の商品ボタン
                  return '<button class="btn btn-success btn-sm btn-item-class-select"><strong>' + variation.value + '</strong></button>';
                }if (variation.stock > 0) {
                  // 販売可能商品のボタン
                  return '<a href="/products/detail/' + variation.product_id + '"><button class="btn btn-default btn-sm btn-item-class-select">' + variation.value + '</button></a>';
                }
                // 販売不可能商品のボタン（在庫なし）
                return '<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">' + variation.value + '</button>';
              }).join('') + '</div>' + '</div>';
            }).join('');
            descriptionDetail = '\n    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>\n    ' + variationHtml + '\n    ';
            data = {
              product_id: productId,
              creator_id: configUploadItem.creator_id,
              name: modelClass.join('/') + ' ' + convDeliv(item.delivery) + ' ' + item.name + (item.jan_code ? ' ' + item.jan_code : ''),
              description_detail: descriptionDetail,
              // free_area: await this.convertItemCube3createFreeArea(item),
              product_code: modelClass.join('/'),
              price01: item.retail_price,
              // price02: await this.convertItemCube3createPrice02(item),
              // images: await this.convertItemCube3createImages(item),
              product_type_id: productTypeId,
              tags: tags,
              delivery_fee: deliveryFee
            };
            context$2$0.t3 = Object;
            context$2$0.t4 = data;
            context$2$0.next = 45;
            return regeneratorRuntime.awrap(this.convertItemCube3createFreeArea(configUploadItem, item));

          case 45:
            context$2$0.t5 = context$2$0.sent;
            context$2$0.t3.assign.call(context$2$0.t3, context$2$0.t4, context$2$0.t5);
            context$2$0.t6 = Object;
            context$2$0.t7 = data;
            context$2$0.next = 51;
            return regeneratorRuntime.awrap(this.convertItemCube3createPrice02(configUploadItem, item));

          case 51:
            context$2$0.t8 = context$2$0.sent;
            context$2$0.t6.assign.call(context$2$0.t6, context$2$0.t7, context$2$0.t8);
            context$2$0.t9 = Object;
            context$2$0.t10 = data;
            context$2$0.next = 57;
            return regeneratorRuntime.awrap(this.convertItemCube3createImages(configUploadItem, item));

          case 57:
            context$2$0.t11 = context$2$0.sent;
            context$2$0.t9.assign.call(context$2$0.t9, context$2$0.t10, context$2$0.t11);

            Object.assign(data, item.mall.sharakuShop);

            return context$2$0.abrupt('return', data);

          case 61:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createFreeArea',
    value: function convertItemCube3createFreeArea(configUploadItem, item) {
      var freeArea, i;
      return regeneratorRuntime.async(function convertItemCube3createFreeArea$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            freeArea = '';

            // 商品情報テキストを記載する
            freeArea += item.description;
            // 2番目以降の画像をフリーエリアに記載する
            for (i = 1; i < item.images.length; i++) {
              freeArea += '<img src="/upload/save_image/' + item.images[i] + '"><br>';
            } // 情報のクリア
            freeArea += ' ';
            return context$2$0.abrupt('return', { free_area: freeArea });

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createPrice02',
    value: function convertItemCube3createPrice02(configUploadItem, item) {
      return regeneratorRuntime.async(function convertItemCube3createPrice02$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            return context$2$0.abrupt('return', { price02: item.mall.sharakuShop.price });

          case 1:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createImages',
    value: function convertItemCube3createImages(configUploadItem, item) {
      var arr;
      return regeneratorRuntime.async(function convertItemCube3createImages$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            arr = typeof item.images[0] === 'undefined' ? [] : [item.images[0]];
            return context$2$0.abrupt('return', { images: arr });

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct1',
    value: function convertItemYauct1(config, item) {
      var res;
      return regeneratorRuntime.async(function convertItemYauct1$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.convertItemYauct(config['default'], item));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct',
    value: function convertItemYauct(def, item) {
      var idLength, titleLength, yauct, imgPrefix, i;
      return regeneratorRuntime.async(function convertItemYauct$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            idLength = 20;
            titleLength = 130;
            yauct = {};

            // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）
            yauct = JSON.parse(JSON.stringify(def[item.delivery]));

            // 画像の記述
            imgPrefix = '画像';

            for (i = 0; i < item.images.length; i++) {
              yauct[imgPrefix + (i + 1)] = item.images[i];
            } // タイトル
            yauct['カテゴリ'] = item.mall.yauct.category;
            context$2$0.t0 = _utilText2['default'];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap(this.getModelClass(item));

          case 10:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = context$2$0.t1 + ' ';
            context$2$0.t3 = item.delivery;
            context$2$0.t4 = context$2$0.t2 + context$2$0.t3;
            context$2$0.t5 = context$2$0.t4 + ' ';
            context$2$0.t6 = item.name;
            context$2$0.t7 = context$2$0.t5 + context$2$0.t6;
            context$2$0.t8 = titleLength;
            yauct['タイトル'] = context$2$0.t0.substr8.call(context$2$0.t0, context$2$0.t7, context$2$0.t8);

            yauct['開始価格'] = item.sales_price;
            yauct['即決価格'] = item.sales_price;
            yauct['管理番号'] = item._id.toHexString().slice(-idLength);
            if (typeof yauct['説明'] === 'string') yauct['説明'] = item.description + '<br><br>' + yauct['説明'];else yauct['説明'] = item.description;

            yauct['JANコード・ISBNコード'] = item.jan_code;

            return context$2$0.abrupt('return', yauct);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemWowmaCreateDeliveryMethod',
    value: function convertItemWowmaCreateDeliveryMethod(itemCode) {
      var id, set, metrics, aggr, acceptDeliv, _iteratorNormalCompletion7, _didIteratorError7, _iteratorError7, _iterator7, _step7, del, deliveryMethod, i, _id;

      return regeneratorRuntime.async(function convertItemWowmaCreateDeliveryMethod$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            id = 'mall.wowma.itemCode';
            set = 'delivery';
            metrics = {
              ゆうパケット: ['Post'],
              宅配便: ['YU-Pack', 'Kangaroo']
            };
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: _defineProperty({}, id, itemCode)
            }, {
              $group: _defineProperty({
                _id: '$' + id
              }, set, { $addToSet: '$' + set })
            }, {
              $project: _defineProperty({
                _id: 0,
                itemCode: '$_id'
              }, set, '$' + set)
            }]).toArray());

          case 5:
            aggr = context$2$0.sent;
            acceptDeliv = [];
            _iteratorNormalCompletion7 = true;
            _didIteratorError7 = false;
            _iteratorError7 = undefined;
            context$2$0.prev = 10;

            for (_iterator7 = aggr[0].delivery[Symbol.iterator](); !(_iteratorNormalCompletion7 = (_step7 = _iterator7.next()).done); _iteratorNormalCompletion7 = true) {
              del = _step7.value;
              acceptDeliv = acceptDeliv.concat(metrics['' + del]);
            }context$2$0.next = 18;
            break;

          case 14:
            context$2$0.prev = 14;
            context$2$0.t0 = context$2$0['catch'](10);
            _didIteratorError7 = true;
            _iteratorError7 = context$2$0.t0;

          case 18:
            context$2$0.prev = 18;
            context$2$0.prev = 19;

            if (!_iteratorNormalCompletion7 && _iterator7['return']) {
              _iterator7['return']();
            }

          case 21:
            context$2$0.prev = 21;

            if (!_didIteratorError7) {
              context$2$0.next = 24;
              break;
            }

            throw _iteratorError7;

          case 24:
            return context$2$0.finish(21);

          case 25:
            return context$2$0.finish(18);

          case 26:
            deliveryMethod = new Array(5);

            for (i = 0; i < deliveryMethod.length; i++) {
              _id = typeof acceptDeliv[i] === 'undefined' ? 'NULL' : acceptDeliv[i];

              deliveryMethod[i] = { deliveryMethodSeq: i + 1, deliveryMethodId: _id };
            }

            return context$2$0.abrupt('return', { deliveryMethod: deliveryMethod });

          case 29:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[10, 14, 18, 26], [19,, 21, 25]]);
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その1 item.csv

  }], [{
    key: 'convertItemRobotinItem',
    value: function convertItemRobotinItem(item) {
      return {
        コントロールカラム: 'n',
        新規登録ID: item._id.toHexString(),
        商品ID: null,
        商品名: '' + item.model + (item.class1_value === '' ? '' : '/' + item.class1_value) + (item.class2_value === '' ? '' : '/' + item.class2_value),
        規格: 'なし'
      };
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その2 select.csv

  }, {
    key: 'convertItemRobotinSelect',
    value: function convertItemRobotinSelect(item) {
      var select = {
        コントロールカラム: 'n',
        新規登録ID: item._id.toHexString(),
        商品ID: null,
        外部連携ID: null,
        外部連携商品番号: item._id.toHexString()
      };

      var shops = _collections.RobotinShop.find();

      shops.forEach(function (doc, index) {
        var model = undefined;
        var class1 = undefined;
        var class2 = undefined;
        try {
          // モールの商品番号を特定する
          model = item.mall['' + doc.name]['' + doc.modelPath];
          model = typeof model === 'undefined' ? '' : model;
          class1 = item.mall['' + doc.name]['' + doc.class1Path];
          class1 = typeof class1 === 'undefined' ? '' : class1;
          class2 = item.mall['' + doc.name]['' + doc.class2Path];
          class2 = typeof class2 === 'undefined' ? '' : class2;
        } catch (e) {
          // 商品のモール情報の取得に失敗した（データが設定されていないなど）
          // model = item.model
          // class1 = item.class1_value
          // class2 = item.class2_value
          return;
        }

        select['受注商品ID_' + index] = null;
        select['店舗ID_' + index] = doc['店舗ID'];
        select['店舗名_' + index] = doc.name;
        select['受注商品番号_' + index] = '' + model + class1 + class2;
        select['有効フラグ_' + index] = '有効';
      });

      return select;
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その3 selectShop.csv

  }, {
    key: 'convertItemRobotinSelectShop',
    value: function convertItemRobotinSelectShop(shop, item) {
      var model = item.mall['' + shop.name]['' + shop.modelPath];
      var class1 = item.mall['' + shop.name]['' + shop.class1Path];
      var class2 = item.mall['' + shop.name]['' + shop.class2Path];

      return {
        コントロールカラム: 'u',
        新規登録ID: item._id.toHexString(),
        受注商品ID: null,
        店舗ID: shop['店舗ID'],
        店舗名: null,
        受注商品番号: '' + model + class1 + class2,
        有効フラグ: '有効'
      };
    }
  }]);

  return ItemController;
})();

exports['default'] = ItemController;
module.exports = exports['default'];

// product * <-> * item
// product[]: 複数の商品を1パッケージとして販売
// product[{ids:[<ObjectId>],set:<Number>}]: 異なる流通経路、異なる原価・仕入れ値
// item: 異なるセール、販売形態
// ※ product からは、販売可能な在庫、利益計算のための情報を得る

// セット商品の場合、一番少ない商品数に合わせる

// アップロード済み画像の情報取得

// 検索条件の組み立て

// 登録した画像ファイル名一覧

// 検索条件の組み立て

/**
 * aggregation設定
 *
 * label: 属性名（配送方法、カラー、サイズなど）
 * current: 指定されたアイテム（item）が該当する項目
 * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
 * query: aggregation対象とするドキュメントの検索条件
 */

// item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

// 値変換

// product_id

// 商品タグを設定する

// 商品別送料を設定する

//
// 顧客向けバリエーション商品選択機能の実装
//

// 商品データを作る

// 価格を返す

// 画像リストのうち1つめだけを返す

// deliveryMethodSeq
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/robotin.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _bson = require('bson');

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var _items = require('./items');

var _items2 = _interopRequireDefault(_items);

var _collections = require('../collections');

var Robotin = (function () {
  function Robotin() {
    _classCallCheck(this, Robotin);

    // importOrderTemp に関連
    // 受発注システムでは処理できない例外的受注処理に対して
    // 個別の送り状発行などを行う
    this.Order = new _meteorMongo.Mongo.Collection(null);
  }

  _createClass(Robotin, [{
    key: 'importOrderTemp',

    /**
     *
     * @param {*} docOrder
     * @param {ItemController} itemS
     */
    value: function importOrderTemp(docOrder, itemS) {
      // 受注データをデータベースに保存
      this.Order.insert({ robotin: docOrder });
    }

    /**
     *
     * @param {*} docOrder
     * @param {ItemController} itemCon
     */
  }, {
    key: 'transformLabelSeino',

    /**
     *
     * @param {*} docLabel
     * @param {Array} writeItemCodeTo
     */
    value: function transformLabelSeino(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      //

      // 受注番号を抽出
      var orderNumber = docLabel[32]; // 33番目の項目「記事１」

      // // 受注CSVから店舗名と受注番号をキーに商品コード一覧を取得する
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel[11], // 12番目の項目「荷送人名称」
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });

      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel[11], // 12番目の項目「荷送人名称」
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      // // 送り状レコードに該当する受注レコードが見つからない場合
      // if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');

      // // 送り状の発送商品コード一覧を配列にする
      // const items = cur.fetch();

      // docLabel : 入力送り状データ
      // conLabel : 出力用送り状データ
      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // writeItemCodeTo （一つの送り状に記載できる商品コードの最大数）の総数より、受注データの商品数が多い場合はエラー
      var writeItemCodeTo = labelOptions.writeItemCodeTo;
      if (writeItemCodeTo.length < items.length) throw new Error('送り状データに記載できる商品数は' + writeItemCodeTo.length + '個までです');

      // 定数の埋め込み
      labelOptions['const'].forEach(function (e) {
        conLabel[e.column] = e.value;
      });

      // 送り状データに商品コードを記録する
      writeItemCodeTo.forEach(function (e, i) {
        if (items[i]) {
          conLabel[e] = items[i];
        } else {
          // 送り状の商品コード欄はすべて埋める
          // これにより列の欠落を防ぐ
          conLabel[e] = '';
        }
      });

      // 住所文字列の分割を修正する
      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      // TextUtil.splitlenb(conLabel, [12, 13], 40); // 項目13「荷送人住所１」、項目14「荷送人住所２」
      // TextUtil.splitlenb(conLabel, [21, 22], 60); // 項目22「お届け先住所１」、項目23「お届け先住所２」

      return conLabel;
    }

    /**
     *
     * @param {*} docLabel
     * @param {Array} writeItemCodeTo
     */
  }, {
    key: 'transformLabelYupack',
    value: function transformLabelYupack(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      //

      // 受注番号を抽出
      var orderNumber = docLabel['記事名１'].replace('受注番号：', '');

      // // 受注CSVから店舗名と受注番号をキーに商品コード一覧を取得する
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel['ご依頼主 名称1'],
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });

      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel['ご依頼主 名称1'],
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      // docLabel : 入力送り状データ
      // conLabel : 出力用送り状データ
      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // writeItemCodeTo （一つの送り状に記載できる商品コードの最大数）の総数より、受注データの商品数が多い場合はエラー
      var writeItemCodeTo = labelOptions.writeItemCodeTo;
      if (writeItemCodeTo.length < items.length) throw new Error('送り状データに記載できる商品数は' + writeItemCodeTo.length + '個までです');

      // 送り状データに商品コードを記録する
      writeItemCodeTo.forEach(function (e, i) {
        if (items[i]) {
          conLabel[e] = items[i];
        } else {
          // 送り状の商品コード欄はすべて埋める
          // これにより列の欠落を防ぐ
          conLabel[e] = '';
        }
      });

      // 送り状種別を設定
      conLabel['送り状種別'] = labelOptions.labelId;

      // 住所文字列の分割を修正する
      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // // length（バイト長）を超える文字列は、半角スペースで分割する
      // TextUtil.splitlenb(conLabel, ['ご依頼主 住所1', 'ご依頼主 住所2', 'ご依頼主 住所3'], 50);
      // TextUtil.splitlenb(conLabel, ['お届け先 住所1', 'お届け先 住所2', 'お届け先 住所3'], 50);
      return conLabel;
    }
  }, {
    key: 'transformLabelYupacket',
    value: function transformLabelYupacket(docLabel, labelOptions) {
      // 商品コードを送り状CSVに埋め込む
      var orderNumber = docLabel['記事名１'].replace('受注番号：', '');
      // const cur = RobotinOrders.find({
      //   店舗名: docLabel['ご依頼主 名称1'],
      //   // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
      //   受注番号: { $in: [orderNumber, Number(orderNumber)] }
      // }, {
      //   fields: {
      //     _id: 0,
      //     商品コード: 1
      //   }
      // });
      var items = Robotin.listItemCodeForLabel({
        'robotin.店舗名': docLabel['ご依頼主 名称1'],
        // 受注CSV出力されている受注番号が文字列形式でも数値形式でも引っかかるようにする（$in）
        'robotin.受注番号': {
          $in: [orderNumber, Number(orderNumber)]
        }
      },
      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      typeof this.Order === 'undefined' ? null : this.Order);

      var conLabel = JSON.parse(JSON.stringify(docLabel));

      // 送り状種別を設定
      conLabel['送り状種別'] = labelOptions.labelId;

      conLabel['記事名１'] = items[0];
      conLabel['フリー項目０１'] = items[1];
      conLabel['フリー項目０５'] = items[2];

      // keyS で指定された target 内の要素の値を、length（バイト長）で分割し再構築する
      // length（バイト長）を超える文字列は、半角スペースで分割する
      // TextUtil.splitlenb(conLabel, ['ご依頼主 住所1', 'ご依頼主 住所2', 'ご依頼主 住所3'], 50);
      // TextUtil.splitlenb(conLabel, ['お届け先 住所1', 'お届け先 住所2', 'お届け先 住所3'], 50);
      return conLabel;
    }
  }], [{
    key: 'createReadableOrder',
    value: function createReadableOrder() {
      var query = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      return _collections.RobotinOrders.rawCollection().find(query, { _id: 0, robotin: 1 }).stream();
    }
  }, {
    key: 'importOrder',
    value: function importOrder(docOrder, itemCon) {
      var insertDoc;
      return regeneratorRuntime.async(function importOrder$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            insertDoc = {
              robotin: docOrder
            };

            // すでに受注が取り込まれていた場合は、docOrderの内容に更新する
            // 取り込まれていない受注の場合は新規登録する
            _collections.RobotinOrders.update({
              'robotin.受注ID': docOrder['受注ID'],
              'robotin.明細ID': docOrder['明細ID']
            }, {
              $set: {
                robotin: docOrder
              }
            }, {
              upsert: true
            });

            // 発注ステータスが設定されていないドキュメント（新規登録受注）
            // 発注ステータスの初期値を設定する
            _collections.RobotinOrders.update({
              vendor: { $exists: 0 }
            }, {
              $set: {
                vendor: { // 発注ステータスの初期値
                  orderto: '', // 発注先
                  orderDate: null, // 発注日
                  promise: null }
              }
            });

          case 3:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'listItemCodeForLabel',
    // 発送予定日
    value: function listItemCodeForLabel(query) {
      var collection = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];

      // 受注システム例外の場合、任意のコレクション（minimongoの一時データベース）が選択できる
      collection = collection === null ? _collections.RobotinOrders : collection;

      // 検索条件に該当する受注を調べる
      var cur = collection.find(query, {
        fields: {
          _id: 0,
          'robotin.商品コード': 1,
          'robotin.数量': 1
        }
      });
      // 送り状レコードに該当する受注レコードが見つからない場合
      if (!cur.count()) throw new Error('送り状に対応する受注が見つかりません。CSVファイルを確認してください。');
      // 商品リストを作成する
      var list = [];
      cur.forEach(function (doc) {
        var q = doc.robotin.数量 == 1 ? '' : '[' + doc.robotin.数量 + 'EA]';
        list.push(doc.robotin.商品コード + ' ' + q);
      });
      // 商品リストを返す
      return list;
    }
  }]);

  return Robotin;
})();

exports['default'] = Robotin;
module.exports = exports['default'];

// 商品番号をmongoIdとして検索し、該当するitemがあれば書き換える
// if (ObjectID.isValid(docOrder['商品コード'])) {
//   const item = await itemCon.Items.findOne({ _id: new ObjectID(docOrder['商品コード']) });
//   if (item) docOrder['商品コード'] = await itemCon.getModelClass(item);
// }

// 受注データをデータベースに保存
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/wowmaApi.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _xmlJs = require('xml-js');

var _utilError = require('../util/error');

var _utilError2 = _interopRequireDefault(_utilError);

var BASE_URI = 'https://api.manager.wowma.jp/wmshopapi';

var WowmaApi = (function () {
  function WowmaApi(plug, shopId) {
    _classCallCheck(this, WowmaApi);

    this.plug = plug;
    this.shopId = shopId;
  }

  // 商品情報更新

  _createClass(WowmaApi, [{
    key: 'updateItem',
    value: function updateItem(_updateItem) {
      var request, res;
      return regeneratorRuntime.async(function updateItem$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            request = '<request><shopId>' + this.shopId + '</shopId><updateItem>' + (0, _xmlJs.json2xml)(_updateItem, { compact: true }) + '</updateItem></request>';
            context$2$0.prev = 1;
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.requestPost('updateItemInfo', request));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', { response: res, requestXML: request });

          case 8:
            context$2$0.prev = 8;
            context$2$0.t0 = context$2$0['catch'](1);
            throw Object.assign(_utilError2['default'].parse(context$2$0.t0), { requestXML: request });

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[1, 8]]);
    }
  }, {
    key: 'requestPost',
    value: function requestPost(method, body) {
      var apiRequest, res;
      return regeneratorRuntime.async(function requestPost$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/' + method,
              body: body
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            // リクエスト発行
            context$2$0.next = 4;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(stockUpdateItem) {
      var apiRequest, res;
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/updateStock'
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.updateStockCreateRequestBody(stockUpdateItem));

          case 4:
            apiRequest.body = context$2$0.sent;
            context$2$0.next = 7;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStockCreateRequestBody',
    value: function updateStockCreateRequestBody(stockUpdateItem) {
      var stockUpdateItemXML, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, item, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, e, var0, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, variation, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, key, apiRequestBody;

      return regeneratorRuntime.async(function updateStockCreateRequestBody$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            stockUpdateItemXML = '';
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 4;
            _iterator = stockUpdateItem[Symbol.iterator]();

          case 6:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 87;
              break;
            }

            item = _step.value;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 11;

            // 値のチェック
            for (_iterator2 = item.variations[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              e = _step2.value;

              // 在庫数の上限100
              if (e.stock > 100) e.stock = 100;
            }

            context$2$0.next = 19;
            break;

          case 15:
            context$2$0.prev = 15;
            context$2$0.t0 = context$2$0['catch'](11);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 19:
            context$2$0.prev = 19;
            context$2$0.prev = 20;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 22:
            context$2$0.prev = 22;

            if (!_didIteratorError2) {
              context$2$0.next = 25;
              break;
            }

            throw _iteratorError2;

          case 25:
            return context$2$0.finish(22);

          case 26:
            return context$2$0.finish(19);

          case 27:
            stockUpdateItemXML += '<stockUpdateItem>';
            stockUpdateItemXML += '<itemCode>' + item.itemCode + '</itemCode>';

            // 商品在庫種別を振り分け
            // 1 -> 通常商品
            // 2 -> 選択肢別在庫

            var0 = item.variations[0];

            if (!(var0.choicesStockHorizontalCode === '' && var0.choicesStockVerticalCode === '')) {
              context$2$0.next = 35;
              break;
            }

            // 通常商品
            stockUpdateItemXML += '<stockSegment>1</stockSegment>';
            stockUpdateItemXML += '<stockCount>' + var0.stock + '</stockCount>';
            context$2$0.next = 83;
            break;

          case 35:
            // 選択肢別在庫
            stockUpdateItemXML += '<stockSegment>2</stockSegment>';

            // リクエストボディを作成する
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 39;
            _iterator3 = item.variations[Symbol.iterator]();

          case 41:
            if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
              context$2$0.next = 69;
              break;
            }

            variation = _step3.value;

            // 在庫設定タグの名前を差し替える
            variation.choicesStockCount = variation.stock;
            delete variation.stock;

            // xmlを構成する
            stockUpdateItemXML += '<choicesStocks>';
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 49;
            for (_iterator4 = Object.keys(variation)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              key = _step4.value;

              stockUpdateItemXML += '<' + key + '>' + variation[key] + '</' + key + '>';
            }
            context$2$0.next = 57;
            break;

          case 53:
            context$2$0.prev = 53;
            context$2$0.t1 = context$2$0['catch'](49);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 57:
            context$2$0.prev = 57;
            context$2$0.prev = 58;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 60:
            context$2$0.prev = 60;

            if (!_didIteratorError4) {
              context$2$0.next = 63;
              break;
            }

            throw _iteratorError4;

          case 63:
            return context$2$0.finish(60);

          case 64:
            return context$2$0.finish(57);

          case 65:
            stockUpdateItemXML += '</choicesStocks>';

          case 66:
            _iteratorNormalCompletion3 = true;
            context$2$0.next = 41;
            break;

          case 69:
            context$2$0.next = 75;
            break;

          case 71:
            context$2$0.prev = 71;
            context$2$0.t2 = context$2$0['catch'](39);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t2;

          case 75:
            context$2$0.prev = 75;
            context$2$0.prev = 76;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 78:
            context$2$0.prev = 78;

            if (!_didIteratorError3) {
              context$2$0.next = 81;
              break;
            }

            throw _iteratorError3;

          case 81:
            return context$2$0.finish(78);

          case 82:
            return context$2$0.finish(75);

          case 83:

            stockUpdateItemXML += '</stockUpdateItem>';

          case 84:
            _iteratorNormalCompletion = true;
            context$2$0.next = 6;
            break;

          case 87:
            context$2$0.next = 93;
            break;

          case 89:
            context$2$0.prev = 89;
            context$2$0.t3 = context$2$0['catch'](4);
            _didIteratorError = true;
            _iteratorError = context$2$0.t3;

          case 93:
            context$2$0.prev = 93;
            context$2$0.prev = 94;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 96:
            context$2$0.prev = 96;

            if (!_didIteratorError) {
              context$2$0.next = 99;
              break;
            }

            throw _iteratorError;

          case 99:
            return context$2$0.finish(96);

          case 100:
            return context$2$0.finish(93);

          case 101:
            apiRequestBody = '\n    <request>\n    <shopId>' + this.shopId + '</shopId>\n    ' + stockUpdateItemXML + '\n    </request>\n    ';
            return context$2$0.abrupt('return', apiRequestBody);

          case 103:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[4, 89, 93, 101], [11, 15, 19, 27], [20,, 22, 26], [39, 71, 75, 83], [49, 53, 57, 65], [58,, 60, 64], [76,, 78, 82], [94,, 96, 100]]);
    }
  }]);

  return WowmaApi;
})();

exports['default'] = WowmaApi;
module.exports = exports['default'];

// 接続オプションの作成

// 接続オプションの作成

// リクエスト発行

//
// stockUpdateItem =
// [
//   {
//     itemCode: <String>,
//     variations: [
//        {
//          choicesStockHorizontalCode: <String>,
//          choicesStockVerticalCode: <String>,
//          stock: <Number>
//        }
//     ]
//   }
// ]

// リクエストボディの作成

// リクエストボディを返す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/error.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var utilError = (function () {
  function utilError() {
    _classCallCheck(this, utilError);
  }

  _createClass(utilError, null, [{
    key: "parse",
    value: function parse(e) {
      var res = {};

      if (e instanceof Error) {
        res.message = e.message;
        res.name = e.name;
        res.fileName = e.fileName;
        res.lineNumber = e.lineNumber;
        res.columnNumber = e.columnNumber;
        res.stack = e.stack;
      } else {
        res = e;
      }

      return res;
    }
  }]);

  return utilError;
})();

exports["default"] = utilError;
module.exports = exports["default"];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mongo.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var MongoCollection = (function () {
  function MongoCollection() {
    _classCallCheck(this, MongoCollection);
  }

  _createClass(MongoCollection, null, [{
    key: 'get',
    value: function get(plug, collection) {
      var client, db;
      return regeneratorRuntime.async(function get$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri, { useNewUrlParser: true }));

          case 2:
            client = context$2$0.sent;
            db = client.db(plug.database);
            return context$2$0.abrupt('return', db.collection(collection));

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }]);

  return MongoCollection;
})();

exports.MongoCollection = MongoCollection;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mysql.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mysql = require('mysql');

var _mysql2 = _interopRequireDefault(_mysql);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var MySQL = (function () {
  function MySQL(profile) {
    _classCallCheck(this, MySQL);

    // コネクションプール初期化
    this.pool = _mysql2['default'].createPool(profile);

    // 複数行ステートメント対応
    var profileMulti = { multipleStatements: true };
    Object.assign(profileMulti, profile);
    this.poolMulti = _mysql2['default'].createPool(profileMulti);
  }

  _createClass(MySQL, [{
    key: 'querySelect',
    value: function querySelect(table, condition) {
      var product = arguments.length <= 2 || arguments[2] === undefined ? '*' : arguments[2];
      var productPart, tablePart, conditionPart, res;
      return regeneratorRuntime.async(function querySelect$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productPart = product;
            tablePart = 'FROM ' + table;
            conditionPart = condition ? 'WHERE ' + condition : '';
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query('SELECT ' + productPart + ' ' + tablePart + ' ' + conditionPart));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', JSON.parse(JSON.stringify(res)));

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'query',

    /**
     *
     * @param {String} sql
     */
    value: function query(sql) {
      // コネクション確立
      // let con = await this.getCon();
      return this.getCon().then(function (con) {
        return new Promise(function (resolve, reject) {
          // クエリ送信
          con.query(sql, function (e, res) {
            // コネクション開放
            con.release();
            if (e) {
              reject(e);
            } else resolve(res);
          });
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'queryInsert_',
    value: function queryInsert_(sql) {
      var res;
      return regeneratorRuntime.async(function queryInsert_$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query(sql));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * @param {String} table
     * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryInsert',
    value: function queryInsert(table) {
      var data = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
      var dataSql = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

      var sql, map, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, k, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, res;

      return regeneratorRuntime.async(function queryInsert$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'INSERT INTO ' + table + ' ';
            map = new Map();
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 5;

            for (_iterator = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              k = _step.value;

              if (data[k] === null) {
                map.set(k, 'NULL');
              } else if (data[k].constructor.name === 'Date') {
                // 日付を変換
                map.set(k, '"' + MySQL.formatDate(data[k]) + '"');
              } else {
                map.set(k, '' + _mysql2['default'].escape(data[k]));
              }
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 24;
            for (_iterator2 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
            }

            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError2) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError2;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += '( ' + [].concat(_toConsumableArray(map.keys())).join(',') + ' ) ';

            sql += 'VALUES( ' + [].concat(_toConsumableArray(map.values())).join(',') + ' ) ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    /**
     *
     * @param {String} table
     * @param {String} filter SQL UPDATEステートメントのWHERE句
     * @param {Object} data 文字列のパラメーター
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryUpdate',
    value: function queryUpdate(table, filter, data, dataSql) {
      var sql, updates, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, k, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, res;

      return regeneratorRuntime.async(function queryUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'UPDATE ' + table + ' SET ';
            updates = [];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 5;

            for (_iterator3 = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              updates.push(k + '=' + _mysql2['default'].escape(data[k]));
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError3) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError3;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 24;
            for (_iterator4 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              updates.push(k + '=' + dataSql[k]);
            }
            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError4) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError4;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += updates.join(',');

            sql += ' WHERE ' + filter + ' ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    // enable to use multiple statements
  }, {
    key: 'queryMulti',
    value: function queryMulti(sql) {
      var poolSwap, res;
      return regeneratorRuntime.async(function queryMulti$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            poolSwap = this.pool;

            this.pool = this.poolMulti;
            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query(sql));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 7:
            context$2$0.prev = 7;

            this.pool = poolSwap;
            return context$2$0.finish(7);

          case 10:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2,, 7, 10]]);
    }
  }, {
    key: 'startTransaction',
    value: function startTransaction() {
      return regeneratorRuntime.async(function startTransaction$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('START TRANSACTION;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'commit',
    value: function commit() {
      return regeneratorRuntime.async(function commit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('COMMIT;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'rollback',
    value: function rollback() {
      return regeneratorRuntime.async(function rollback$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('ROLLBACK;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'streamingQuery',
    value: function streamingQuery(sql) {
      var _this = this;

      var onResult = arguments.length <= 1 || arguments[1] === undefined ? function (record) {} : arguments[1];
      var onError = arguments.length <= 2 || arguments[2] === undefined ? function (e) {} : arguments[2];

      return this.getCon().then(function (con) {
        return new Promise(function callee$3$0(resolve, reject) {
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                // クエリ送信
                con.query(sql).on('result', function (record) {
                  con.pause();
                  onResult(record);
                  con.resume();
                }).on('error', function (e) {
                  onError(e);
                }).on('end', function () {
                  con.release();
                  resolve();
                });

              case 1:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'getCon',
    value: function getCon() {
      var _this2 = this;

      return new Promise(function (resolve, reject) {
        // プールからのコネクション獲得
        _this2.pool.getConnection(function (e, con) {
          if (e) {
            reject(e);
          } else {
            resolve(con);
          }
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }], [{
    key: 'formatDate',
    value: function formatDate(date) {
      return (0, _moment2['default'])(date).format().substring(0, 19).replace('T', ' ');
    }
  }]);

  return MySQL;
})();

exports['default'] = MySQL;
module.exports = exports['default'];

// SELECTの結果はディープコピーすることで rowdatapacket を外す

// let res = await this.query(sql);
// return res.insertId;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/packet.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Packet = (function () {
  function Packet(packetSize) {
    _classCallCheck(this, Packet);

    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  _createClass(Packet, [{
    key: "submit",
    value: function submit(arg) {
      return regeneratorRuntime.async(function submit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            if (!(this.count % this.packetSize === 0)) {
              context$2$0.next = 4;
              break;
            }

            if (!this.onPacketStart) {
              context$2$0.next = 4;
              break;
            }

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.onPacketStart(this.packetCount));

          case 4:
            if (!this.onPacket) {
              context$2$0.next = 7;
              break;
            }

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.onPacket(arg));

          case 7:
            this.count++;
            // packetSizeの回数ごとに、終了処理を呼び出す
            if (this.count % this.packetSize === 0) {
              this.close();
              this.packetCount++;
            }

          case 9:
          case "end":
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: "close",
    value: function close() {
      if (this.onPacketEnd) {
        this.onPacketEnd(this.packetCount);
      }
    }
  }]);

  return Packet;
})();

exports["default"] = Packet;
module.exports = exports["default"];

// packetSizeの回数ごとに、初期化を呼び出す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/report.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _error = require('./error');

var _error2 = _interopRequireDefault(_error);

var _meteorMeteor = require('meteor/meteor');

var _collections = require('../collections');

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

var Report = (function () {
  function Report() {
    _classCallCheck(this, Report);

    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  // private

  _createClass(Report, [{
    key: 'setupIterator',
    value: function setupIterator(phaseId) {
      this.iterator = new Iterator(phaseId);
      this.iterators.push(this.iterator);
    }
  }, {
    key: 'phase',
    value: function phase() {
      var _this = this;

      var name = arguments.length <= 0 || arguments[0] === undefined ? '' : arguments[0];
      var fn = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0() {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
      var rec, res;
      return regeneratorRuntime.async(function phase$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            rec = {
              phaseId: (0, _uniqid2['default'])()
            };

            this.setupIterator(rec.phaseId);

            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(fn());

          case 5:
            res = context$2$0.sent;

            Object.assign(rec, {
              type: 'success',
              phase: name,
              result: res
            });
            context$2$0.next = 12;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](2);

            Object.assign(rec, {
              type: 'error',
              phase: name,
              result: _error2['default'].parse(context$2$0.t0)
            });

          case 12:
            context$2$0.prev = 12;

            // ループ処理のレポートを作成
            if (this.iterator.metric.total) {
              Object.assign(rec, {
                iterator: this.iterator.metric
              });
            }
            // タイムスタンプ
            rec.timeStamp = new Date();
            // レポートをデータベースに記録
            _collections.Logs.insert(rec);

            // 呼び出し元用レポートに追加
            this.record.push(rec);
            return context$2$0.finish(12);

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2, 9, 12, 18]]);
    }

    // カーソルをループし、与えられた関数を実行
    // 呼び出す関数の引数にはカーソルから得られたドキュメントを渡す
  }, {
    key: 'forEachOnCursor',
    value: function forEachOnCursor(cur, fn) {
      var doc, res;
      return regeneratorRuntime.async(function forEachOnCursor$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 2:
            if (!context$2$0.sent) {
              context$2$0.next = 18;
              break;
            }

            context$2$0.next = 5;
            return regeneratorRuntime.awrap(cur.next());

          case 5:
            doc = context$2$0.sent;
            context$2$0.prev = 6;
            context$2$0.next = 9;
            return regeneratorRuntime.awrap(fn(doc));

          case 9:
            res = context$2$0.sent;

            this.iSuccess(res);
            context$2$0.next = 16;
            break;

          case 13:
            context$2$0.prev = 13;
            context$2$0.t0 = context$2$0['catch'](6);

            this.iError(context$2$0.t0);

          case 16:
            context$2$0.next = 0;
            break;

          case 18:
            cur.close();

          case 19:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 13]]);
    }
  }, {
    key: 'iSuccess',
    value: function iSuccess(newRecord) {
      this.iterator.success(newRecord);
    }
  }, {
    key: 'iError',
    value: function iError(newRecord) {
      this.iterator.error(_error2['default'].parse(newRecord));
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      var iteError = this.iterators.find(function (e) {
        return e.errorOcurred();
      });
      var phaError = false;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.record[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var rec = _step.value;

          if (rec.type === 'error') {
            phaError = true;
            break;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return iteError || phaError;
    }
  }, {
    key: 'publish',
    value: function publish() {
      // 呼び出し元へレポート
      if (this.errorOcurred()) {
        throw new _meteorMeteor.Meteor.Error(this.record);
      }
      return this.record;
    }
  }]);

  return Report;
})();

exports['default'] = Report;

var Iterator = (function () {
  function Iterator(phaseId) {
    _classCallCheck(this, Iterator);

    this.metric = {
      total: 0,
      success: 0,
      error: 0,
      phaseId: phaseId
    };
    this.lastError = null;
  }

  _createClass(Iterator, [{
    key: 'success',
    value: function success(newRecord) {
      if (newRecord) {
        this.log(newRecord, true);
      }
      this.metric.success++;
      this.metric.total++;
    }
  }, {
    key: 'error',
    value: function error(newRecord) {
      // 直前と同じエラーは省く
      if (JSON.stringify(this.lastError) !== JSON.stringify(newRecord)) {
        if (newRecord && newRecord !== {} && newRecord !== '') {
          this.log(newRecord, false);
          this.lastError = newRecord;
        }
      }
      this.metric.error++;
      this.metric.total++;
    }
  }, {
    key: 'log',
    value: function log(newRecord, isSuccess /* true => success or false => error */) {
      var rec = {
        success: isSuccess,
        phaseId: this.metric.phaseId,
        message: newRecord,
        timeStamp: new Date()
      };
      _collections.Logs.insert(rec);
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      return this.metric.error;
    }
  }]);

  return Iterator;
})();

module.exports = exports['default'];

// リクエスト発行
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"syncObject.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/syncObject.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

var _lodash = require('lodash');

var _lodash2 = _interopRequireDefault(_lodash);

/**
 *
 * @param {[Object]} src
 * @param {[Object]} dst
 * @param {string} idkey
 * @param {function(any, Object)} create
 * @param {function(any, Object)} remove
 */

exports['default'] = function syncObject(src, dst, idkey, addFunc, remFunc) {
  if (idkey === undefined) idkey = null;
  var srcContainer, dstContainer, idDeletedClone;
  return regeneratorRuntime.async(function syncObject$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        srcContainer = [];
        dstContainer = [];

        idDeletedClone = function idDeletedClone(elem, idkeyAP) {
          var elemSave = _lodash2['default'].cloneDeep(elem);
          // id を比較対象から外す
          if (_lodash2['default'].isUndefined(elemSave[idkeyAP]) === false) {
            delete elemSave[idkeyAP];
          }
          // ディープクローンしたオブジェクトを返す
          return elemSave;
        };

        // オブジェクト比較の前準備
        src.forEach(function (elem) {
          srcContainer.push({
            object: idDeletedClone(elem, idkey),
            id: elem[idkey],
            state: {
              /**
               * true 何もしない
               * false 新規に作成
               */
              find: false
            }
          });
        });

        dst.forEach(function (elem) {
          dstContainer.push({
            object: idDeletedClone(elem, idkey),
            id: elem[idkey],
            state: {
              /**
               * true 何もしない
               * false 削除する
               */
              find: false
            }
          });
        });

        // オブジェクトを比較
        srcContainer.forEach(function (srcElem) {
          dstContainer.forEach(function (dstElem) {
            if (_lodash2['default'].isEqual(srcElem.object, dstElem.object)) {
              // 同じオブジェクトが見つかった場合
              srcElem.state.find = true;
              dstElem.state.find = true;
            }
          });
        });

        // データの挿入
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(Promise.all(srcContainer.map(function callee$1$0(elem) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                if (!(elem.state.find === false)) {
                  context$2$0.next = 3;
                  break;
                }

                context$2$0.next = 3;
                return regeneratorRuntime.awrap(addFunc(elem.id, elem.object));

              case 3:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        })));

      case 8:
        context$1$0.next = 10;
        return regeneratorRuntime.awrap(Promise.all(dstContainer.map(function callee$1$0(elem) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                if (!(elem.state.find === false)) {
                  context$2$0.next = 3;
                  break;
                }

                context$2$0.next = 3;
                return regeneratorRuntime.awrap(remFunc(elem.id, elem.object));

              case 3:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        })));

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
};

module.exports = exports['default'];

// データの削除
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/text.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var TextUtil = (function () {
  function TextUtil() {
    _classCallCheck(this, TextUtil);
  }

  _createClass(TextUtil, null, [{
    key: 'substr8',

    // 8ビットで文字列切り取る
    value: function substr8(text, len, truncation) {
      if (truncation === undefined) {
        truncation = '';
      }
      var textArray = text.split('');
      var count = 0;
      var str = '';
      for (var i = 0; i < textArray.length; i++) {
        var n = escape(textArray[i]);
        if (n.length < 4) count++;else count += 2;
        if (count > len) {
          return str + truncation;
        }
        str += text.charAt(i);
      }
      return text;
    }

    // 文字列のバイト数を数える
  }, {
    key: 'lenb',
    value: function lenb(text) {
      return encodeURIComponent(text).replace(/%..%..%../g, 'xx').length;
    }
  }, {
    key: 'splitlenb',
    value: function splitlenb(target, keyS, length) {
      var sep = ' ';
      // keyS で指定された target 内の要素の値をすべて結合した文字列を作る
      var strEntire = keyS.reduce(function (prev, current) {
        return prev + target[current];
      }, '');
      // 結合した文字列を半角スペースで分割する
      var arrEntire = strEntire.split(sep);
      var arrRes = [];
      var last = '';
      // バイト長がlengthを超えない限り前後の分割文字列を結合していく
      // バイト長がlengthを超えたら、ひとつまえの結合文字列を配列登録する
      try {
        arrEntire.reduce(function (prev, current) {
          // length を超えるバイト長の分割文字列がある場合は何もしない
          if (TextUtil.lenb(current) > length) throw new Error('文字列超過');
          var exam = (prev !== '' ? prev + sep : '') + current;
          if (TextUtil.lenb(exam) > length) {
            arrRes.push(prev);
            last = current; // 最後の文字列
            return '';
          } else {
            last = exam; // 最後の文字列
            return exam;
          }
        }, '');
      } catch (e) {
        // length を超えるバイト長の分割文字列がある場合は何もしない
        if (e.message === '文字列超過') return;
      }

      arrRes.push(last); // 最後の文字列を配列登録する
      // keyS で指定された target 内の要素の値を修正する
      for (var i = 0; i < keyS.length; i++) {
        target[keyS[i]] = arrRes[i] ? arrRes[i] : '';
      }
    }
  }]);

  return TextUtil;
})();

exports['default'] = TextUtil;
module.exports = exports['default'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _this = this;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _meteorMeteor = require('meteor/meteor');

var _meteorMongo = require('meteor/mongo');

var Logs = new _meteorMongo.Mongo.Collection('logs', { idGeneration: 'MONGO' });
exports.Logs = Logs;
var Uploads = new _meteorMongo.Mongo.Collection('uploads', { idGeneration: 'MONGO' });

exports.Uploads = Uploads;
var RobotinShop = new _meteorMongo.Mongo.Collection('robotinShop', { idGeneration: 'MONGO' });
exports.RobotinShop = RobotinShop;
var RobotinOrders = new _meteorMongo.Mongo.Collection('robotinOrders', { idGeneration: 'MONGO' });

exports.RobotinOrders = RobotinOrders;
var Configs = new _meteorMongo.Mongo.Collection('configs', { idGeneration: 'MONGO' });

exports.Configs = Configs;
if (_meteorMeteor.Meteor.isServer) {
  _meteorMeteor.Meteor.publish('configs', function () {
    return Configs.find();
  });
  _meteorMeteor.Meteor.methods(_defineProperty({}, 'robotinOrderGroups', function robotinOrderGroups() {
    var res;
    return regeneratorRuntime.async(function robotinOrderGroups$(context$1$0) {
      while (1) switch (context$1$0.prev = context$1$0.next) {
        case 0:
          context$1$0.next = 2;
          return regeneratorRuntime.awrap(RobotinOrders.rawCollection().aggregate([{
            // 受注IDごとにグループ化
            $group: {
              _id: {
                受注ID: '$robotin.受注ID',
                受注日時: '$robotin.受注日時',
                店舗名: '$robotin.店舗名',
                受注番号: '$robotin.受注番号'
              },
              items: { $push: { 商品コード: '$robotin.商品コード', 数量: '$robotin.数量' } }
            }
          }, {
            $project: {
              _id: 0,
              受注ID: '$_id.受注ID',
              受注日時: '$_id.受注日時',
              店舗名: '$_id.店舗名',
              受注番号: '$_id.受注番号',
              items: '$items'
            }
          }]).toArray());

        case 2:
          res = context$1$0.sent;
          return context$1$0.abrupt('return', res);

        case 4:
        case 'end':
          return context$1$0.stop();
      }
    }, null, this);
  }));

  _meteorMeteor.Meteor.publish('robotinOrderItems', function callee$0$0() {
    return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
      while (1) switch (context$1$0.prev = context$1$0.next) {
        case 0:
          return context$1$0.abrupt('return', RobotinOrders.find());

        case 1:
        case 'end':
          return context$1$0.stop();
      }
    }, null, _this);
  });
}

if (_meteorMeteor.Meteor.isClient) {
  _meteorMeteor.Meteor.subscribe('configs');
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/robotin.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/wowmaApi.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yb2JvdGluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdG9vbHRlc3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci93b3dtYS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIveWF1Y3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3Vwcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL3JvYm90aW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS93b3dtYUFwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3N5bmNPYmplY3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC90ZXh0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb25zLmpzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztrQkFLZSxJQUFJOzs7O3NCQUNBLFFBQVE7Ozs7OztpQ0FHSixvQkFBb0I7Ozs7a0NBR3BDLDhCQUE4Qjs7QUFDckMsSUFBSSxvQkFBb0IsR0FBRyxxQ0FBWSxDQUFDOztBQUV4QyxJQUFNLEtBQUssR0FBRyxlQUFlLENBQUM7OztBQUc5QixNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsb0JBQW9CLENBQUMsQ0FBQztBQUN4RCxNQUFNLENBQUMsZUFBZSxDQUFDLEdBQUcsQ0FBQyxLQUFLLEVBQUUsVUFBQyxHQUFHLEVBQUUsSUFBSSxFQUFLOzs7QUFHL0MsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxnQkFBRyxRQUFRLENBQUMsQ0FBQztBQUM3QyxNQUFNLE1BQU0sR0FBRyxNQUFNLENBQUMsU0FBUyxDQUFDLGdCQUFHLFNBQVMsQ0FBQyxDQUFDO0FBQzlDLE1BQU0sUUFBUSxHQUFHLDBCQUFRLENBQUM7Ozs7Ozs7QUFFMUIseUJBQWlCLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSw4SEFBRTtVQUF4QixJQUFJOztBQUNYLFVBQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7OztBQUcvQixVQUFJLFFBQVEsR0FBTSwwQkFBUSxTQUFNOzs7QUFHaEMsVUFBSSxRQUFRLEdBQUcsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxHQUFHLFFBQVEsQ0FBQzs7Ozs7QUFLbEQsVUFBSSxHQUFHLEdBQUc7QUFDUixnQkFBUSxFQUFFLFFBQVE7QUFDbEIsc0JBQWMsRUFBRSxJQUFJLENBQUMsSUFBSTtBQUN6Qix3QkFBZ0IsRUFBRSxRQUFRO09BQzNCLENBQUM7O0FBRUYsVUFBRztBQUNELGNBQU0sQ0FBQyxRQUFRLEVBQUUsSUFBSSxDQUFDLENBQUM7T0FDeEIsQ0FDRCxPQUFNLEdBQUcsRUFBQztBQUNSLFdBQUcsQ0FBQyxLQUFLLEdBQUcsR0FBRyxDQUFDO09BQ2pCO0FBQ0Qsa0NBQVEsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDOztBQUVwQixhQUFPLElBQUksQ0FBQztLQUViOzs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsR0FBQztBQUNGLE1BQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7QUFDcEIsTUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDO0FBQ3RCLFlBQVEsRUFBRSxRQUFRO0FBQ2xCLFdBQU8sRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVE7R0FDM0IsQ0FBQyxDQUFDLENBQUM7Q0FFTCxDQUFDLEM7Ozs7Ozs7Ozs7Ozs7Ozs7O3NCQzdEaUIsUUFBUTs7Ozs0QkFFSixlQUFlOztnQ0FDcEIsMEJBQTBCOzs7O2lDQUN6QiwyQkFBMkI7Ozs7dUNBSXZDLGlDQUFpQzs7d0NBR2pDLGtDQUFrQzs7QUFFekMsSUFBSSxHQUFHLEdBQUcsU0FBUzs7QUFFbkIscUJBQU8sT0FBTyx5REFFRixHQUFHLGVBQVksb0JBQUMsTUFBTTtNQUMxQixNQUFNLEVBS04sTUFBTSxFQU1OLFNBQVMsRUFFVCxLQUFLOzs7Ozs7QUFiTCxjQUFNLEdBQUcsb0NBQVk7QUFLckIsY0FBTSxHQUFHLHFDQUFXLE1BQU0sQ0FBQyxXQUFXLENBQUM7QUFNdkMsaUJBQVMsR0FBRyxnQkFBZ0I7QUFFNUIsYUFBSyxHQUFHLGtDQUFVLE1BQU0sQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDOzt3Q0FFaEMsTUFBTSxDQUFDLEtBQUssQ0FBQyx3QkFBd0IsRUFDekM7Ozs7O2dEQUNRLEtBQUssQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDOzs7Ozs7O1NBQzdCLENBQUM7Ozs7d0NBS0UsTUFBTSxDQUFDLEtBQUssQ0FBQyx1QkFBdUIsRUFDeEM7Y0FDTSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDN0IsNEJBQVUsRUFBRSxvQkFBTyxNQUFNO3dCQWFuQixHQUFHLEVBd0dILFFBQVEsRUFFUixVQUFVLEVBRVYsYUFBYSxFQUdYLElBQUc7Ozs7O0FBL0dMLDZCQUFHLDZkQUtPLE1BQU0sQ0FBQyxXQUFXLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsR0FBRyxXQUFNLE1BQU0sQ0FBQyxHQUFHLFdBQU0sTUFBTSxDQUFDLFVBQVUsV0FBTSxNQUFNLENBQUMsSUFBSSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLFlBQVksV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLE9BQU8sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxRQUFRLFdBQU0sTUFBTSxDQUFDLElBQUksV0FBTSxNQUFNLENBQUMsVUFBVSxXQUFNLE1BQU0sQ0FBQyxjQUFjLFdBQU0sTUFBTSxDQUFDLGFBQWEsV0FBTSxNQUFNLENBQUMsU0FBUyxXQUFNLE1BQU0sQ0FBQyxTQUFTLFdBQU0sTUFBTSxDQUFDLElBQUksV0FBTSxNQUFNLENBQUMsV0FBVyxXQUFNLE1BQU0sQ0FBQyxXQUFXLFdBQU0sTUFBTSxDQUFDLE9BQU87OzswREFLenJCLEtBQUssQ0FBQyxXQUFXLENBQ3JCLGNBQWMsRUFBRTtBQUNkLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0Isa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQiwrQkFBRyxFQUFFLE1BQU0sQ0FBQyxHQUFHO0FBQ2YsK0JBQUcsRUFBRSxNQUFNLENBQUMsR0FBRztBQUNmLHNDQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDN0IsZ0NBQUksRUFBRSxNQUFNLENBQUMsSUFBSTtBQUNqQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLHdDQUFZLEVBQUUsTUFBTSxDQUFDLFlBQVk7QUFDakMsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87QUFDdkIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixvQ0FBUSxFQUFFLE1BQU0sQ0FBQyxRQUFRO0FBQ3pCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsc0NBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtBQUM3QiwwQ0FBYyxFQUFFLE1BQU0sQ0FBQyxjQUFjO0FBQ3JDLHlDQUFhLEVBQUUsTUFBTSxDQUFDLGFBQWE7QUFDbkMscUNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztBQUMzQixxQ0FBUyxFQUFFLE1BQU0sQ0FBQyxTQUFTO0FBQzNCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87MkJBQ3hCLENBQ0Y7Ozs7Ozs7Ozs7QUFFRCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7OzBEQUtWLEtBQUssQ0FBQyxXQUFXLENBQ3JCLHNCQUFzQixFQUFFO0FBQ3RCLCtDQUFtQixFQUFFLElBQUk7QUFDekIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixzQ0FBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO0FBQzdCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQix3Q0FBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO0FBQ2pDLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO0FBQ3ZCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTzsyQkFDeEIsQ0FDRjs7Ozs7Ozs7OztBQUVELGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7MERBS1YsS0FBSyxDQUFDLFdBQVcsQ0FDckIsdUJBQXVCLEVBQUU7QUFDdkIsOEJBQUUsRUFBRSxJQUFJO0FBQ1IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix3Q0FBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO0FBQ2pDLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPOzJCQUN4QixDQUNGOzs7Ozs7Ozs7O0FBRUQsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7QUFLZCxrQ0FBUSxHQUFHLG9CQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLENBQUMsUUFBUSxDQUFDLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUM7QUFFcEUsb0NBQVUsR0FBTSxNQUFNLENBQUMsTUFBTSxTQUFJLE1BQU0sQ0FBQyxNQUFNLHdCQUFtQixNQUFNLENBQUMsV0FBVztBQUVuRix1Q0FBYSxHQUFHLE1BQU0sQ0FBQyxLQUFLLEdBQUcsR0FBRzs7OzBEQUdwQixLQUFLLENBQUMsV0FBVyxDQUMvQixZQUFZLEVBQUU7QUFDWixxQ0FBUyxFQUFFLElBQUk7QUFDZixxQ0FBUyxFQUFFLFFBQVE7QUFDbkIsdUNBQVcsRUFBRSxDQUFDO0FBQ2QsdUNBQVcsRUFBRSxVQUFVO0FBQ3ZCLHlDQUFhLEVBQUUsQ0FBQztBQUNoQiwyQ0FBZSxFQUFFLENBQUM7QUFDbEIsMENBQWMsRUFBRSxDQUFDO0FBQ2pCLDBDQUFjLEVBQUUsYUFBYTtBQUM3Qix5Q0FBYSxFQUFFLElBQUk7QUFDbkIsdUNBQVcsRUFBRSxDQUFDO0FBQ2QseUNBQWEsRUFBRSxDQUFDO0FBQ2hCLDhDQUFrQixFQUFFLElBQUk7QUFDeEIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQiwrQ0FBbUIsRUFBRSxxQkFBcUI7QUFDMUMsNkNBQWlCLEVBQUUscUJBQXFCO0FBQ3hDLG1DQUFPLEVBQUUsQ0FBQzsyQkFDWCxFQUFFO0FBQ0QsdUNBQVcsRUFBRSxPQUFPO0FBQ3BCLHVDQUFXLEVBQUUsT0FBTzsyQkFDckIsQ0FDRjs7O0FBdEJHLDhCQUFHOzs7Ozs7OztBQXdCUCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7Ozs7bUJBRW5CO2lCQUNGLEVBQ0Qsb0JBQU8sQ0FBQzs7OztBQUNOLDhCQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQzs7Ozs7OztpQkFDakIsQ0FDQTs7O0FBNUpHLG1CQUFHO29EQThKQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBRUsscUJBQXFCLEVBQUMsNEJBQUMsT0FBTztNQUM5QixFQUFFLEVBQ0YsR0FBRzs7OztBQURILFVBQUUsR0FBRyxrQ0FBVSxPQUFPLENBQUM7O3dDQUNYLEVBQUUsQ0FBQyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7OztBQUF0QyxXQUFHOzRDQUNBLEdBQUc7Ozs7Ozs7Q0FDWCxvQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0NDck44QiwwQkFBMEI7OzRCQUNyQyxlQUFlOztBQUVwQyxJQUFJLEdBQUcsR0FBRyxrQkFBa0I7O0FBRTVCLHFCQUFPLE9BQU8seURBRUYsR0FBRyxZQUFTLG9CQUFDLElBQUk7TUFBRSxLQUFLLHlEQUFHLEVBQUU7TUFBRSxVQUFVLHlEQUFHLEVBQUU7TUFDbEQsSUFBSSxFQUNKLEdBQUc7Ozs7O3dDQURVLGtDQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUM7OztBQUF2RCxZQUFJOzt3Q0FDUSxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssRUFBRSxFQUFDLFVBQVUsRUFBRSxVQUFVLEVBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRTs7O0FBQWhFLFdBQUc7NENBQ0EsR0FBRzs7Ozs7OztDQUNYLG9DQUVTLEdBQUcsaUJBQWMsb0JBQUMsSUFBSTtNQUFFLEtBQUsseURBQUcsRUFBRTtNQUN0QyxJQUFJLEVBQ0osR0FBRzs7Ozs7d0NBRFUsa0NBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLFVBQVUsQ0FBQzs7O0FBQXZELFlBQUk7O3dDQUNRLElBQUksQ0FBQyxTQUFTLENBQUMsS0FBSyxDQUFDLENBQUMsT0FBTyxFQUFFOzs7QUFBM0MsV0FBRzs0Q0FDQSxHQUFHOzs7Ozs7O0NBQ1gsb0JBRUQsQzs7Ozs7Ozs7Ozs7Ozs7Ozs7bUNDbkJ5Qiw2QkFBNkI7Ozs7NEJBQ25DLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLGFBQWE7O0FBRXZCLHFCQUFPLE9BQU8seURBT0YsR0FBRyxnQkFBYSxvQkFBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLEtBQUs7TUFBRSxNQUFNLHlEQUFHLElBQUk7TUFBRSxNQUFNLHlEQUFHLElBQUk7TUFDeEUsT0FBTyxFQUVQLFFBQVE7Ozs7QUFGUixlQUFPLEdBQUcsc0NBQW9COzt3Q0FDNUIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7Ozs7d0NBQ0gsT0FBTyxDQUFDLFFBQVEsQ0FBQyxRQUFRLEVBQUUsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7OztBQUFsRSxnQkFBUTs0Q0FDTCxRQUFROzs7Ozs7O0NBQ2hCLG9DQUtTLEdBQUcsa0JBQWUsb0JBQUMsSUFBSSxFQUFFLEtBQUs7TUFBRSxNQUFNLHlEQUFHLElBQUk7TUFBRSxNQUFNLHlEQUFHLElBQUk7TUFDaEUsT0FBTzs7OztBQUFQLGVBQU8sR0FBRyxzQ0FBb0I7O3dDQUM1QixPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQzs7Ozt3Q0FDbEIsT0FBTyxDQUFDLFVBQVUsQ0FBQyxLQUFLLEVBQUUsTUFBTSxFQUFFLE1BQU0sQ0FBQzs7Ozs7OztDQUNoRCxvQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3NCQzVCWSxRQUFROzs7OzRCQUNDLGVBQWU7O2lDQUNuQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7c0NBRzdCLDZCQUE2Qjs7Z0NBQ2xCLHVCQUF1Qjs7OzttQ0FDZCwwQkFBMEI7Ozs7QUFHckQsSUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDOztBQUVuQixxQkFBTyxPQUFPLHlEQUtGLEdBQUcsZ0JBQWEsb0JBQUMsTUFBTTtNQUV6QixNQUFNLEVBRU4sTUFBTSxFQUNOLGNBQWMsRUFHZCxRQUFRLEVBQ1IsR0FBRzs7Ozs7O0FBUEgsY0FBTSxHQUFHLG9DQUFZO0FBRXJCLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFFbkMsZ0JBQVEsR0FBRyxrQ0FBVSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQ3BDLFdBQUcsR0FBRyxxQ0FBYSxRQUFRLENBQUM7O3dDQUU1QixNQUFNLENBQUMsS0FBSyxDQUNoQixXQUFXLEVBQ1g7Y0FDUSxHQUFHOzs7Ozs7O2dEQUFTLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDL0Isd0JBQU0sRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFPaEIsT0FBTzs7OzsrQkFKYixvQkFBRSxPQUFPLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDOzs7Ozs7OzBEQUlyQixHQUFHLENBQUMsY0FBYyxDQUN0QyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FDakM7OztBQUhLLGlDQUFPOzs7QUFNYixnQ0FBTSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQzs7Ozs7Ozs7QUFHekIsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHLENBQUM7Ozs7Ozs7bUJBS3RCO2lCQUNGLENBQUM7OztBQXZCSSxtQkFBRztvREF5QkYsR0FBRzs7Ozs7OztTQUNYLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBRXhCLG9DQUtTLEdBQUcsbUJBQWdCLG9CQUFDLE1BQU07TUFFNUIsTUFBTSxFQUVOLE1BQU0sRUFDTixjQUFjLEVBR2QsUUFBUSxFQUNSLEdBQUc7Ozs7OztBQVBILGNBQU0sR0FBRyxvQ0FBWTtBQUVyQixjQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCxzQkFBYyxHQUFHLHNDQUFvQjs7d0NBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBRW5DLGdCQUFRLEdBQUcsa0NBQVUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNwQyxXQUFHLEdBQUcscUNBQWEsUUFBUSxDQUFDOzt3Q0FFNUIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsT0FBTyxFQUNQO2NBQ1EsR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDOztBQUUvQix3QkFBTSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPO3dCQUNwQixRQUFROzs7OzswREFBUyxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUFsRCxrQ0FBUTs7MERBQ1IsR0FBRyxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxRQUFRLENBQUM7Ozs7Ozs7bUJBQ3hFO2lCQUNGLENBQUM7OztBQU5JLG1CQUFHO29EQVFGLEdBQUc7Ozs7Ozs7U0FDWCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGlCQUFjLG9CQUFDLE1BQU07TUFDMUIsTUFBTSxFQUNOLFFBQVEsRUFDUixHQUFHLEVBRUgsY0FBYyxFQUlkLE1BQU07Ozs7OztBQVJOLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELGdCQUFRLEdBQUcsa0NBQVUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNwQyxXQUFHLEdBQUcscUNBQWEsUUFBUSxDQUFDO0FBRTVCLHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFHbkMsY0FBTSxHQUFHLG9DQUFZOzt3Q0FFckIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBQ1EsR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQy9CLHdCQUFNLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3BCLEdBQUcsRUFHRCxRQUFRLEVBRVIsU0FBUzs7OztBQUxYLDZCQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVU7OzswREFHTCxjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7OztBQUF6RSxrQ0FBUTs7MERBRVUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7OztBQUE3QyxtQ0FBUzs7MERBR1QsR0FBRyxDQUFDLFNBQVMsQ0FBQztBQUNsQiwrQkFBRyxFQUFFLElBQUksQ0FBQyxHQUFHOzJCQUNkLEVBQUU7QUFDRCxnQ0FBSSxFQUFFO0FBQ0osMkRBQTZCLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFVO0FBQ3ZELGlFQUFtQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCO0FBQ25FLGlFQUFtQyxFQUFFLFNBQVMsQ0FBQyxHQUFHLENBQUMsZ0JBQWdCOzZCQUNwRTsyQkFDRixDQUFDOzs7O0FBRUYsZ0NBQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQzs7Ozs7Ozs7QUFFbEIsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHLENBQUM7Ozs7Ozs7bUJBRXBCO2lCQUNGLEVBQ0Qsb0JBQU8sQ0FBQzs7Ozs4QkFDQSxDQUFDOzs7Ozs7O2lCQUNSLENBQUM7OztBQTVCSSxtQkFBRztvREE4QkYsR0FBRzs7Ozs7OztTQUNYLENBQ0Y7Ozs7d0NBRUssTUFBTSxDQUFDLEtBQUssQ0FDaEIsZ0JBQWdCLEVBQ2hCO2NBQ1EsR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQy9CLHdCQUFNLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3BCLEdBQUcsRUFHRCxRQUFRLEVBTVIsUUFBUTs7OztBQVRWLDZCQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVU7OzswREFHTCxjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7OztBQUF6RSxrQ0FBUTs7MERBRVIsR0FBRyxDQUFDLGtCQUFrQixDQUFDLFFBQVEsQ0FBQzs7OzswREFDaEMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7Ozs7MERBQzNCLEdBQUcsQ0FBQyxnQkFBZ0IsQ0FBQyxRQUFRLENBQUM7Ozs7MERBRWIsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOzs7QUFBbEQsa0NBQVE7OzBEQUNSLEdBQUcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsUUFBUSxDQUFDOzs7O0FBRXZFLGdDQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7Ozs7Ozs7O0FBRWxCLGdDQUFNLENBQUMsTUFBTSxnQkFBRyxDQUFDOzs7Ozs7O21CQUVwQjtpQkFDRixFQUNELG9CQUFPLENBQUM7Ozs7OEJBQ0EsQ0FBQzs7Ozs7OztpQkFDUixDQUFDOzs7QUF0QkksbUJBQUc7b0RBd0JGLEdBQUc7Ozs7Ozs7U0FDWCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQkFFRCxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0N4TGdCLHdCQUF3Qjs7OzttQ0FDaEIsMEJBQTBCOzs7OzRCQUM5QixlQUFlOzt1QkFDbEIsVUFBVTs7Ozt5QkFDWixZQUFZOzs7O21CQUNkLEtBQUs7Ozs7c0JBQ2UsUUFBUTs7c0JBRTFCLFFBQVE7Ozs7cUNBQ04sNEJBQTRCOzs7O0FBRWhELElBQU0sR0FBRyxHQUFHLFNBQVM7O0FBRXJCLHFCQUFPLE9BQU8seURBRUYsR0FBRyxvQkFBaUIsb0JBQUMsTUFBTTtNQUUvQixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixtQkFBbUIsRUFDbkI7Y0FDUSxPQUFPLEVBQ1AsYUFBYSxFQUNiLGNBQWMsRUFlZCxLQUFLOzs7O0FBakJMLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsS0FBSyxDQUFDLE9BQU87QUFDbkQsNkJBQWEsR0FBTSxPQUFPLFNBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxhQUFhO0FBQ3hELDhCQUFjLEdBQU0sTUFBTSxDQUFDLEtBQUssQ0FBQyxjQUFjOzs7Z0RBSTdDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUc3QixxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUl0QixxQkFBUSxLQUFLLENBQUMsYUFBYSxDQUFDOzs7Ozs7Ozs7OztBQUk5QixxQkFBSyxHQUFHLHNDQUFvQjs7Z0RBQzVCLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7QUFHaEMscUNBQU8sU0FBUyxDQUFDLGFBQUcsRUFBSTtBQUN0QixzQkFBTSxJQUFJLEdBQUcsbUNBQVEsbUJBQW1CLEVBQUUsQ0FDdkMsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDOztBQUVuQyxzQkFBTSxTQUFTLEdBQUcsc0JBQWM7QUFDOUIsc0NBQWtCLEVBQUUsSUFBSTtBQUN4QixzQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLDZCQUFTLEVBQUUsbUJBQUMsS0FBSyxFQUFFLEdBQUcsRUFBRSxFQUFFLEVBQUc7QUFDM0Isd0JBQUUsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDLE9BQU8sQ0FBQyxDQUFDO3FCQUN6QjttQkFDRixDQUFDLENBQUM7O0FBRUgsc0JBQU0sS0FBSyxHQUFHLHFCQUFRLGlCQUFpQixDQUFJLGFBQWEsU0FBSSxjQUFjLENBQUcsQ0FDMUUsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDLENBQ2hDLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBSTtBQUNoQix1QkFBRyxFQUFFO21CQUNOLENBQUM7O0FBRUosc0JBQUksQ0FDRCxJQUFJLENBQUMsU0FBUyxDQUFDLENBQ2YsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FBQyxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ25DLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUNmLENBQUMsRUFBRTs7Ozs7OztTQUVMLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUVTLEdBQUcsb0JBQWlCLG9CQUFDLE1BQU07TUFFL0IsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsb0JBQW9CLEVBQ3BCO2NBQ1EsT0FBTyxFQUNQLGFBQWEsRUFDYixRQUFRLEVBZVIsS0FBSzs7OztBQWpCTCx1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPLFNBQUksTUFBTSxDQUFDLEtBQUssQ0FBQyxPQUFPO0FBQ25ELDZCQUFhLEdBQU0sT0FBTyxTQUFJLE1BQU0sQ0FBQyxLQUFLLENBQUMsYUFBYTtBQUN4RCx3QkFBUSxHQUFNLE1BQU0sQ0FBQyxLQUFLLENBQUMsUUFBUTs7O2dEQUlqQyxxQkFBUSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFHN0IscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFJdEIscUJBQVEsS0FBSyxDQUFDLGFBQWEsQ0FBQzs7Ozs7Ozs7Ozs7QUFJOUIscUJBQUssR0FBRyxzQ0FBb0I7O2dEQUM1QixLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7O0FBR2hDLHFDQUFPLFNBQVMsQ0FBQyxhQUFHLEVBQUk7QUFDdEIsc0JBQU0sSUFBSSxHQUFHLHFCQUFRLGdCQUFnQixDQUFJLGFBQWEsU0FBSSxRQUFRLENBQUcsQ0FDbEUsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDO0FBQ25DLHNCQUFNLEtBQUssR0FBRyxxQkFBYTtBQUN6Qiw4QkFBVSxFQUFFLElBQUk7QUFDaEIseUJBQUssRUFBQyxlQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFOzs7QUFDaEMsK0NBQU07Ozs7Ozs4REFFSSxtQ0FBUSxXQUFXLENBQUMsS0FBSyxFQUFFLEtBQUssQ0FBQzs7O0FBQ3ZDLG9DQUFNLENBQUMsUUFBUSxFQUFFLENBQUM7Ozs7Ozs7O0FBR2xCLHNDQUFRLGdCQUFLOzs7QUFFZixzQ0FBUSxFQUFFOzs7Ozs7O3VCQUNYLENBQUMsQ0FBQyxHQUFHLEVBQUU7cUJBQ1Q7QUFDRCx5QkFBSyxFQUFDLGVBQUMsUUFBUSxFQUFFO0FBQ2YsOEJBQVEsRUFBRTtBQUNWLHlCQUFHLEVBQUU7cUJBQ047bUJBQ0YsQ0FBQyxDQUNDLEVBQUUsQ0FBQyxPQUFPLEVBQUUsYUFBRzsyQkFBSSxNQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzttQkFBQSxDQUFDOztBQUV6QyxzQkFBSSxDQUFDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDbEMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsaUJBQUksS0FBSyxDQUFDLEVBQUMsT0FBTyxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLEtBQUssQ0FBQztpQkFDZixDQUFDLEVBQUU7Ozs7Ozs7U0FFTCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FFUyxHQUFHLGlCQUFjLG9CQUFDLE1BQU07TUFFNUIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZ0JBQWdCLEVBQ2hCO2NBQ1EsT0FBTyxFQUNQLFdBQVcsRUFDWCxZQUFZLEVBa0JaLEtBQUssRUFJTCxJQUFJOzs7O0FBeEJKLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsU0FBUyxDQUFDLE9BQU87QUFDdkQsMkJBQVcsR0FBTSxPQUFPLFNBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxXQUFXO0FBQ3hELDRCQUFZLEdBQU0sT0FBTyxTQUFJLE1BQU0sQ0FBQyxTQUFTLENBQUMsWUFBWTs7O2dEQUd4RCxxQkFBUSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFHN0IscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7OztnREFJdEIscUJBQVEsS0FBSyxDQUFDLFdBQVcsQ0FBQzs7Ozs7Ozs7Ozs7OztnREFJMUIscUJBQVEsS0FBSyxDQUFDLFlBQVksQ0FBQzs7Ozs7Ozs7Ozs7QUFJN0IscUJBQUssR0FBRyxzQ0FBb0I7O2dEQUM1QixLQUFLLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUcxQixvQkFBSSxHQUFHLHdDQUFhOztBQUMxQixxQ0FBTyxTQUFTLENBQUMsYUFBRyxFQUFJO0FBQ3RCLHNCQUFNLElBQUksR0FBRyxxQkFBUSxnQkFBZ0IsQ0FBSSxXQUFXLFNBQUksTUFBTSxDQUFDLFNBQVMsQ0FBQyxRQUFRLFVBQU8sQ0FDckYsRUFBRSxDQUFDLE9BQU8sRUFBRSxhQUFHLEVBQUk7QUFBRSx1QkFBRyxDQUFDLEdBQUcsQ0FBQzttQkFBRSxDQUFDO0FBQ25DLHNCQUFNLEtBQUssR0FBRyxxQkFBYTtBQUN6Qiw4QkFBVSxFQUFFLElBQUk7QUFDaEIseUJBQUssRUFBQyxlQUFDLEtBQUssRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFO0FBQ2hDLDBCQUFJLENBQUMsZUFBZSxDQUFDLEtBQUssRUFBRSxLQUFLLENBQUM7QUFDbEMsOEJBQVEsRUFBRTtxQkFDWDtBQUNELHlCQUFLLEVBQUMsZUFBQyxRQUFRLEVBQUU7QUFDZiw4QkFBUSxFQUFFO0FBQ1YseUJBQUcsRUFBRTtxQkFDTjttQkFDRixDQUFDOztBQUVGLHNCQUFJLENBQUMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNsQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyxpQkFBSSxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsS0FBSyxDQUFDO2lCQUNmLENBQUMsRUFBRTs7O0FBR0osc0JBQU0sQ0FBQyxTQUFTLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxxQkFBVyxFQUFJO0FBQ2pELHNCQUFJO0FBQ0YseUNBQU8sU0FBUyxDQUFDLGFBQUcsRUFBSTtBQUN0QiwwQkFBTSxJQUFJLEdBQUcscUJBQVEsZ0JBQWdCLENBQUksV0FBVyxTQUFJLFdBQVcsQ0FBQyxPQUFPLFVBQU8sQ0FDL0UsRUFBRSxDQUFDLE9BQU8sRUFBRSxZQUFNO0FBQUUsMkJBQUcsRUFBRTt1QkFBRSxDQUFDO0FBQy9CLDBCQUFNLFNBQVMsR0FBRyxzQkFBYztBQUM5QiwwQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLDBDQUFrQixFQUFFLElBQUk7QUFDeEIsaUNBQVMsRUFBRSxtQkFBQyxLQUFLLEVBQUUsUUFBUSxFQUFFLFFBQVEsRUFBSztBQUN4Qyw4QkFBSSxNQUFNO0FBQ1YsOEJBQUk7QUFDRixxREFBTSxZQUFNO0FBQ1Ysb0NBQU0sR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDLEtBQUssRUFBRSxXQUFXLENBQUM7QUFDckQsc0NBQVEsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDOzZCQUN2QixDQUFDLENBQUMsR0FBRyxFQUFFOzJCQUNULENBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCwrQkFBRyxDQUFDLEtBQUssQ0FBQzsyQkFDWDt5QkFDRjt1QkFDRixDQUFDO0FBQ0YsMEJBQU0sS0FBSyxHQUFHLHFCQUFRLGlCQUFpQixDQUFJLFlBQVksU0FBSSxXQUFXLENBQUMsUUFBUSxVQUFPLENBQ25GLEVBQUUsQ0FBQyxRQUFRLEVBQUUsWUFBTTtBQUNsQiw4QkFBTSxDQUFDLFFBQVEsRUFBRTtBQUNqQiwyQkFBRyxFQUFFO3VCQUNOLENBQUMsQ0FDRCxFQUFFLENBQUMsT0FBTyxFQUFFLGVBQUssRUFBSTtBQUFFLDJCQUFHLENBQUMsS0FBSyxDQUFDO3VCQUFFLENBQUM7O0FBRXZDLDBCQUFJLENBQ0QsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyxpQkFBSSxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsV0FBVyxDQUFDLE9BQU8sS0FBSyxJQUFJLEdBQUcsSUFBSSxHQUFHLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDdEUsSUFBSSxDQUFDLFNBQVMsQ0FBQyxDQUNmLElBQUksQ0FBQyxpQkFBSSxTQUFTLENBQUMsRUFBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLE9BQU8sRUFBQyxDQUFDLENBQUMsQ0FDbEQsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQ2hDLElBQUksQ0FBQyxLQUFLLENBQUM7cUJBQ2YsQ0FBQyxFQUFFO21CQUNMLENBQUMsT0FBTyxLQUFLLEVBQUU7QUFDZCwwQkFBTSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUM7bUJBQ3JCO2lCQUNGLENBQUM7Ozs7Ozs7U0FDSCxDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FNUyxHQUFHLGdCQUFhLG9CQUFDLE1BQU07TUFFM0IsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsbUJBQW1CLEVBQ25CO2NBQ1EsT0FBTyxFQVNMLGNBQWMsRUFHZCxJQUFJLEVBRUosUUFBUTs7OztBQWRWLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU87OztnREFHcEQscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7Z0RBRzdCLHFCQUFRLEtBQUssQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7OztBQUd0Qiw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBRW5DLG9CQUFJLEdBQUcsY0FBYyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsRUFBQyxLQUFLLEVBQUUsRUFBQyxHQUFHLEVBQUUsRUFBRSxFQUFDLEVBQUMsQ0FBQyxDQUFDLE1BQU0sRUFBRTs7QUFFN0Qsd0JBQVEsR0FBRyxTQUFYLFFBQVEsQ0FBSSxJQUFJLEVBQUUsRUFBRSxFQUFFLFFBQVEsRUFBSztBQUN2QyxzQkFBTSxPQUFPLEdBQUcsc0JBQWM7QUFDNUIsc0NBQWtCLEVBQUUsSUFBSTtBQUN4QixzQ0FBa0IsRUFBRSxJQUFJO0FBQ3hCLDZCQUFTLEVBQUMsbUJBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUU7QUFDcEMsK0NBQU0sWUFBTTtBQUNWLDRCQUFNLElBQUksR0FBRyxFQUFFLENBQUMsS0FBSyxDQUFDO0FBQ3RCLGdDQUFRLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQzt1QkFDckIsQ0FBQyxDQUFDLEdBQUcsRUFBRTtxQkFDVDttQkFDRixDQUFDO0FBQ0Ysc0JBQUksS0FBSyxHQUFHLENBQUM7QUFDYixzQkFBTSxRQUFRLEdBQUcsc0JBQWM7QUFDN0IsNEJBQVEsRUFBRSxNQUFNO0FBQ2hCLDZCQUFTLEVBQUUsbUJBQUMsS0FBSyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUs7QUFDeEMsMEJBQUksR0FBRyxHQUFHLEtBQUssQ0FBQyxRQUFRLEVBQUU7QUFDMUIsMEJBQUksS0FBSyxLQUFLLENBQUMsRUFBRTtBQUNmLDJCQUFHLEdBQUcsR0FBRyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsRUFBRSxDQUFDO3VCQUNoQztBQUNELDJCQUFLLEVBQUU7QUFDUCw4QkFBUSxDQUFDLElBQUksRUFBRSxHQUFHLENBQUM7cUJBQ3BCO21CQUNGLENBQUM7QUFDRixzQkFBTSxRQUFRLEdBQUcscUJBQVEsaUJBQWlCLENBQUksUUFBUSxVQUFPO0FBQzdELDBCQUFRLENBQUMsRUFBRSxDQUFDLE9BQU8sRUFBRSxXQUFDLEVBQUk7QUFBRSwwQkFBTSxxQkFBTyxLQUFLLENBQUMsZ0JBQWdCLENBQUM7bUJBQUUsQ0FBQzs7QUFFbkUsc0JBQUksQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLENBQ2YsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FBQyxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ25DLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FDZCxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLFFBQVEsQ0FBQztpQkFDbEI7O0FBRUQsd0JBQVEsQ0FDTixJQUFJLEVBQ0osaUNBQWUsc0JBQXNCLEVBQ2xDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLFdBQVcsQ0FDMUM7O0FBRUQsd0JBQVEsQ0FDTixJQUFJLEVBQ0osaUNBQWUsd0JBQXdCLEVBQ3BDLE9BQU8sU0FBSSxNQUFNLENBQUMsUUFBUSxDQUFDLGFBQWEsQ0FDNUM7OztzQkFHRyxJQUFJLHFCQUFPLEtBQUssa0NBQWdDLE9BQU8sT0FBSTs7Ozs7OztTQUNsRSxDQUNGOzs7Ozs7O0NBQ0Ysb0JBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQzVUaUIsd0JBQXdCOzs7O3NDQUdwQyw2QkFBNkI7O2dDQUNsQix1QkFBdUI7Ozs7NEJBQ3BCLGVBQWU7O0FBRXBDLElBQUksR0FBRyxHQUFHLE1BQU07O0FBRWhCLHFCQUFPLE9BQU8scUJBS0YsR0FBRyxZQUFTLG9CQUFDLE1BQU07TUFFdkIsTUFBTSxFQUVOLE1BQU0sRUFFSixRQUFROzs7Ozs7QUFKVixjQUFNLEdBQUcsb0NBQVk7QUFFckIsY0FBTSxHQUFHLDBDQUFrQixNQUFNLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7O3dDQUV2QyxNQUFNLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxvQkFBTyxDQUFDOzs7O3NCQUMxQyxDQUFDOzs7Ozs7O1NBQ1IsQ0FBQzs7O0FBRkksZ0JBQVE7O3dDQUdSLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLFVBQVUsRUFDVjs7OztvREFDUyxRQUFROzs7Ozs7O1NBQ2hCLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLEVBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDaENpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7bUNBQ1QsMEJBQTBCOzs7OzRCQUVoQyxlQUFlOzt1QkFDaEIsVUFBVTs7Ozs4QkFFVixpQkFBaUI7Ozs7c0NBQ2hCLDZCQUE2Qjs7OztnQ0FDNUIsdUJBQXVCOzs7O0FBRTdDLElBQU0sR0FBRyxHQUFHLE9BQU87O0FBRW5CLHFCQUFPLE9BQU8seURBS0YsR0FBRyx1QkFBb0Isb0JBQUMsTUFBTTtNQUVsQyxNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixrQkFBa0IsRUFDbEI7Y0FHUSxjQUFjLEVBS2hCLEdBQUcsRUE0Q0gsR0FBRzs7Ozs7O0FBakRELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUl6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7cUJBa0JGO21CQUNGO2lCQUNGLEVBQ0Q7O0FBRUUsd0JBQU0sRUFBRTtBQUNOLHVCQUFHLEVBQUUsc0JBQXNCO21CQUM1QjtpQkFDRixFQUNEO0FBQ0UsMEJBQVEsRUFBRTtBQUNSLHVCQUFHLEVBQUUsQ0FBQztBQUNOLDRCQUFRLEVBQUUsTUFBTTttQkFDakI7aUJBQ0YsQ0FDRixDQUNGOzs7QUF6Q0csbUJBQUc7QUE0Q0gsbUJBQUcsR0FBRyx3Q0FBYSxNQUFNLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7O2dEQUNwRCxNQUFNLENBQUMsZUFBZSxDQUMxQixHQUFHLEVBQ0gsb0JBQU0sSUFBSTtzQkFHRixHQUFHOzs7O0FBRlQsOEJBQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLE1BQU0sQ0FBQyxRQUFRLFdBQVEsQ0FBQzs7O3dEQUUxQixHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQzs7O0FBQWhDLDJCQUFHOzREQUNBLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFDOzs7Ozs4QkFFbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUMsRUFBRSw4QkFBVSxLQUFLLGdCQUFHLENBQUM7Ozs7Ozs7aUJBRS9ELENBQ0Y7Ozs7Ozs7U0FDRixDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGlDQUE4QixvQkFBQyxNQUFNO01BRTVDLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLHFCQUFxQixFQUNyQjtjQUdRLGNBQWMsRUFLaEIsR0FBRyxFQTRDSCxHQUFHOzs7Ozs7QUFqREQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBSXpCLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUM1QyxDQUNFO0FBQ0Usd0JBQU0sRUFBRTtBQUNOLHdCQUFJLEVBQUUsQ0FDSjtBQUNFLDJDQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtxQkFDdEM7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkFrQkY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRSxzQkFBc0I7bUJBQzVCO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO21CQUNqQjtpQkFDRixDQUNGLENBQ0Y7OztBQXpDRyxtQkFBRztBQTRDSCxtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Z0RBQ3BELE1BQU0sQ0FBQyxlQUFlLENBQzFCLEdBQUcsRUFDSCxvQkFBTSxJQUFJO3NCQUdGLEdBQUc7Ozs7eUNBRlQsTUFBTTt5Q0FBUSxJQUFJOzt3REFBUSxjQUFjLENBQUMsb0NBQW9DLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQzs7Ozt1Q0FBckYsTUFBTTs7O3dEQUVLLEdBQUcsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDOzs7QUFBaEMsMkJBQUc7NERBQ0EsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxHQUFHLEVBQUM7Ozs7OzhCQUVuQyxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBQyxFQUFFLDhCQUFVLEtBQUssZ0JBQUcsQ0FBQzs7Ozs7OztpQkFFL0QsQ0FDRjs7Ozs7OztTQUNGLENBQ0Y7Ozs0Q0FFTSxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUtTLEdBQUcsdUJBQW9CLG9CQUFDLE1BQU07TUFFbEMsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsMEJBQTBCLEVBQzFCO2NBR1EsY0FBYyxFQUtoQixHQUFHLEVBeUNILEdBQUc7Ozs7OztBQTlDRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFJekIsY0FBYyxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQzVDLENBQ0U7QUFDRSx3QkFBTSxFQUFFO0FBQ04sd0JBQUksRUFBRSxDQUNKO0FBQ0UsMkNBQXFCLEVBQUUsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFO3FCQUN0Qzs7Ozs7Ozs7Ozs7Ozs7O3FCQWVGO21CQUNGO2lCQUNGLEVBQ0Q7O0FBRUUsd0JBQU0sRUFBRTtBQUNOLHVCQUFHLEVBQUUsc0JBQXNCO21CQUM1QjtpQkFDRixFQUNEO0FBQ0UsMEJBQVEsRUFBRTtBQUNSLHVCQUFHLEVBQUUsQ0FBQztBQUNOLDRCQUFRLEVBQUUsTUFBTTttQkFDakI7aUJBQ0YsQ0FDRixDQUNGOzs7QUF0Q0csbUJBQUc7QUF5Q0gsbUJBQUcsR0FBRyx3Q0FBYSxNQUFNLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7O2dEQUNwRCxNQUFNLENBQUMsZUFBZSxDQUMxQixHQUFHLEVBQ0gsb0JBQU0sSUFBSTtzQkFJRixHQUFHOzs7O0FBSFQsNEJBQUksQ0FBQyxVQUFVLEdBQUcsQ0FBQztBQUNuQiw0QkFBSSxDQUFDLGFBQWEsR0FBRyxNQUFNOzs7d0RBRVQsR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7OztBQUFoQywyQkFBRzs0REFDQSxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBQzs7Ozs7OEJBRW5DLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFDLEVBQUUsOEJBQVUsS0FBSyxnQkFBRyxDQUFDOzs7Ozs7O2lCQUUvRCxDQUNGOzs7Ozs7O1NBQ0YsQ0FDRjs7OzRDQUVNLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBS1MsR0FBRyxtQkFBZ0Isb0JBQUMsTUFBTTtNQUU5QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixhQUFhLEVBQ2I7Y0FHUSxjQUFjLEVBR2hCLEdBQUcsRUFrRUQsSUFBSSxrRkFHQyxDQUFDLEVBT04sR0FBRyxFQUVELEdBQUc7Ozs7O0FBakZMLDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUV6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7cUJBZUY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRTtBQUNILDhCQUFRLEVBQUUsc0JBQXNCO0FBQ2hDLGdEQUEwQixFQUFFLHlCQUF5QjtBQUNyRCw4Q0FBd0IsRUFBRSx5QkFBeUI7cUJBQ3BEO0FBQ0Qsd0JBQUksRUFBRTtBQUNKLDRCQUFNLEVBQUUsTUFBTTtxQkFDZjttQkFDRjtpQkFDRixFQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFLGVBQWU7QUFDcEIsOEJBQVUsRUFBRTtBQUNWLDJCQUFLLEVBQUU7QUFDTCwyQkFBRyxFQUFFLE9BQU87QUFDWixrREFBMEIsRUFBRSxpQ0FBaUM7QUFDN0QsZ0RBQXdCLEVBQUUsK0JBQStCO3VCQUMxRDtxQkFDRjttQkFDRjtpQkFDRixFQUNEO0FBQ0UsMEJBQVEsRUFBRTtBQUNSLHVCQUFHLEVBQUUsQ0FBQztBQUNOLDRCQUFRLEVBQUUsTUFBTTtBQUNoQiw4QkFBVSxFQUFFLGFBQWE7bUJBQzFCO2lCQUNGLENBQ0YsQ0FDRjs7O0FBM0RHLG1CQUFHOzs7O2dEQWlFTSxHQUFHLENBQUMsT0FBTyxFQUFFOzs7Ozs7Ozs7Z0RBQ1AsR0FBRyxDQUFDLElBQUksRUFBRTs7O0FBQXZCLG9CQUFJOzs7Ozs0QkFHTSxJQUFJLENBQUMsVUFBVTs7Ozs7Ozs7QUFBcEIsaUJBQUM7O2dEQUNRLGNBQWMsQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTlDLGlCQUFDLENBQUMsS0FBSzs7QUFDUCx1QkFBTyxDQUFDLENBQUMsR0FBRzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBS1YsbUJBQUcsR0FBRyx3Q0FBYSxNQUFNLENBQUMsWUFBWSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUM7OztnREFFeEMsR0FBRyxDQUFDLFdBQVcsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDOzs7QUFBbkMsbUJBQUc7O0FBQ1Asc0JBQU0sQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDOzs7Ozs7OztBQUVwQixzQkFBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7Ozs7QUFHcEIsbUJBQUcsQ0FBQyxLQUFLLEVBQUU7Ozs7Ozs7U0FDWixDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGtCQUFlLG9CQUFDLE1BQU07TUFFN0IsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBSVEsTUFBTSxFQUNOLGNBQWMsRUFTZCxPQUFPLEVBU1QsR0FBRzs7Ozs7O0FBbkJELHNCQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Z0RBSWpDLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7OztBQUkvQix1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPLGVBQVcsSUFBSSxJQUFJLEVBQUUsQ0FBRSxPQUFPLEVBQUU7OztnREFHekQscUJBQVEsS0FBSyxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7O2dEQU1kLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3hCLE9BQU8sRUFJUCxLQUFLLEVBQ0wsUUFBUTs7OztBQUxSLGlDQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsQ0FBQzs7QUFDekQsaUNBQU8sQ0FBQyxHQUFHLEdBQU0sT0FBTyxDQUFDLEdBQUcsb0JBQWlCO0FBQzdDLGlDQUFPLENBQUMsRUFBRSxDQUFDLFFBQVEsR0FBRyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxRQUFROzs7MERBRTVCLGlDQUFRLE9BQU8sQ0FBQzs7O0FBQTlCLCtCQUFLO0FBQ0wsa0NBQVEsR0FBTSxPQUFPLFNBQUksSUFBSSxDQUFDLEtBQUs7OzBEQUVqQyxxQkFBUSxTQUFTLENBQUMsUUFBUSxFQUFFLEtBQUssQ0FBQzs7Ozs7OzttQkFDekMsRUFBQyxDQUFDOzs7QUFYRCxtQkFBRztvREFhQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0JBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQzFaaUIsd0JBQXdCOzs7O3NDQUdwQyw2QkFBNkI7O21DQUNULDBCQUEwQjs7Ozs0QkFFaEMsZUFBZTs7QUFFcEMsSUFBTSxHQUFHLEdBQUcsVUFBVTs7QUFFdEIscUJBQU8sT0FBTyxxQkFLRixHQUFHLGVBQVksb0JBQUMsTUFBTTtNQUUxQixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixlQUFlLEVBQ2Y7Y0FJUSxNQUFNLEVBQ04sY0FBYyxFQWtCaEIsR0FBRzs7Ozs7O0FBbkJELHNCQUFNLEdBQUcsK0NBQXVCLE1BQU0sQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNoRSw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7OztnREFpQnpCLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87Ozs7QUFDNUIsZ0NBQU0sQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDOzs7Ozs7O21CQUN0QixFQUFDLENBQUM7OztBQUpELG1CQUFHO29EQU1BLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixFQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQ3hEaUIsd0JBQXdCOzs7O3NDQUdwQyw2QkFBNkI7O21DQUNULDBCQUEwQjs7Ozs0QkFFaEMsZUFBZTs7aUNBQ2pCLHdCQUF3Qjs7Ozt1QkFDdkIsVUFBVTs7Ozt5QkFFWixZQUFZOzs7O3dCQUNULFVBQVU7Ozs7bUJBQ2YsS0FBSzs7OztzQkFDa0IsUUFBUTs7QUFFL0MsSUFBTSxNQUFNLEdBQUcsUUFBUTtBQUN2QixJQUFNLEdBQUcsR0FBRyxPQUFPOztBQUVuQixxQkFBTyxPQUFPLHlEQUtGLEdBQUcsYUFBVSxvQkFBQyxNQUFNO01BRXhCLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLFFBQVEsRUFDUjtjQUNRLGNBQWMsRUFFZCxPQUFPLEVBQ1AsQ0FBQyxFQUNELENBQUM7Ozs7OztBQUpELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFDbkMsdUJBQU8sR0FBTSxNQUFNLENBQUMsT0FBTztBQUMzQixpQkFBQyxHQUFHLHFCQUFRLGdCQUFnQixDQUFJLE9BQU8sU0FBSSxNQUFNLENBQUMsYUFBYSxDQUFHO0FBQ2xFLGlCQUFDLEdBQUcscUJBQVEsaUJBQWlCLENBQUksT0FBTyxTQUFJLE1BQU0sQ0FBQyxhQUFhLENBQUc7O0FBQ3pFLGlCQUFDLENBQUMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUMvQixJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyxpQkFBSSxLQUFLLENBQUMsRUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsaUJBQUksU0FBUyxDQUNqQixvQkFBTyxNQUFNLEVBQUUsUUFBUTtzQkFDakIsR0FBRzs7OztBQUFILDJCQUFHLEdBQUcsSUFBSTs7O3dEQUdXLGNBQWMsQ0FBQyxhQUFhLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDOzs7QUFBbkUsOEJBQU0sQ0FBQyxNQUFNLENBQUM7Ozs7Ozs7O0FBRWQsMkJBQUcsaUJBQUk7OztBQUVULGdDQUFRLENBQUMsR0FBRyxFQUFFLE1BQU0sQ0FBQzs7Ozs7OztpQkFDdEIsQ0FDRixDQUFDLENBQ0QsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FBQyxFQUFDLE1BQU0sRUFBRSxJQUFJLEVBQUMsQ0FBQyxDQUFDLENBQ25DLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FDakMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUNoQyxJQUFJLENBQUMsQ0FBQyxDQUFDOzs7Ozs7O1NBQ1gsQ0FDRjs7Ozs7OztDQUNGLG9DQUtTLEdBQUcsZUFBWSxvQkFBQyxNQUFNO01BRTFCLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLFFBQVEsRUFDUjtjQUlRLE1BQU0sRUFDTixjQUFjLEVBSWQsTUFBTSxFQVFOLE9BQU8sRUFLUCxTQUFTLEVBSVgsRUFBRSxFQUNGLFFBQVEsRUFDUixJQUFJLEVBR0osTUFBTSxFQUNOLE1BQU0sRUE2Q04sR0FBRzs7Ozs7O0FBekVELHNCQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMxRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBR25DLHNCQUFNLEdBQUcsbUNBQVcsTUFBTSxDQUFDLFVBQVUsQ0FBQzs7O2dEQUlwQyxxQkFBUSxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7Ozs7Ozs7Ozs7QUFJL0IsdUJBQU8sR0FBTSxNQUFNLENBQUMsT0FBTzs7Z0RBQzNCLHFCQUFRLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBQ3ZCLHFCQUFRLEtBQUssQ0FBQyxPQUFPLENBQUM7OztBQUd0Qix5QkFBUyxHQUFNLE1BQU0sQ0FBQyxPQUFPOztnREFDN0IscUJBQVEsTUFBTSxDQUFDLFNBQVMsQ0FBQzs7OztnREFDekIscUJBQVEsS0FBSyxDQUFDLFNBQVMsQ0FBQzs7O0FBRTFCLGtCQUFFLEdBQUcsSUFBSTtBQUNULHdCQUFRLEdBQUcsSUFBSTtBQUNmLG9CQUFJLEdBQUcsSUFBSTtBQUdYLHNCQUFNLEdBQUcsQ0FBQyxNQUFNLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxJQUFJLEVBQUUsZ0JBQWdCLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLFlBQVksRUFBRSxZQUFZLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxZQUFZLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsTUFBTSxFQUFFLFFBQVEsRUFBRSxTQUFTLEVBQUUsTUFBTSxFQUFFLE1BQU0sRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsV0FBVyxFQUFFLFFBQVEsRUFBRSxLQUFLLEVBQUUsY0FBYyxFQUFFLFNBQVMsRUFBRSxTQUFTLEVBQUUsWUFBWSxFQUFFLGNBQWMsRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxXQUFXLEVBQUUsb0JBQW9CLEVBQUUsaUJBQWlCLEVBQUUsTUFBTSxFQUFFLFdBQVcsRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLGdCQUFnQixDQUFDO0FBQzlwQyxzQkFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBQzsrQkFBUSxDQUFDO2lCQUFHLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSTs7O0FBR3ZELHNCQUFNLENBQUMsYUFBYSxHQUFHLG9CQUFPLFdBQVc7Ozs7QUFDdkMsNEJBQUksR0FBRyxNQUFNLEdBQUcsQ0FBQyxPQUFPLEdBQUcsV0FBVyxFQUFFLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUNqRCwwQkFBRSxHQUFNLE9BQU8sU0FBSSxJQUFNO0FBQ3pCLGdDQUFRLEdBQU0sRUFBRSxTQUFJLE1BQU0sQ0FBQyxXQUFhOzt3REFDbEMscUJBQVEsS0FBSyxDQUFDLEVBQUUsQ0FBQzs7Ozt3REFFakIscUJBQVEsVUFBVSxDQUFDLFFBQVEsRUFBRSx1QkFBTSxNQUFNLENBQUMsTUFBTSxFQUFFLFdBQVcsQ0FBQyxDQUFDOzs7Ozs7O2lCQUN0RTs7O0FBR0Qsc0JBQU0sQ0FBQyxRQUFRLEdBQUcsb0JBQU8sR0FBRztzQkFDdEIsS0FBSyxFQUNMLElBQUksRUFFSixNQUFNLGtGQUdELEdBQUcsRUFDTixNQUFNLEVBQ04sTUFBTTs7Ozs7QUFSUiw2QkFBSyxHQUFHLEdBQUcsQ0FBQyxLQUFLO0FBQ2pCLDRCQUFJLEdBQUcsR0FBRyxDQUFDLElBQUk7QUFFZiw4QkFBTSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsV0FBQyxFQUFJO0FBQUUsaUNBQU8sS0FBSyxDQUFDLENBQUMsQ0FBQyxTQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBTSxJQUFJO3lCQUFFLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLEdBQUcsSUFBSTs7d0RBQ3JGLHFCQUFRLFVBQVUsQ0FBQyxRQUFRLEVBQUUsdUJBQU0sTUFBTSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQzs7Ozs7OztvQ0FFckQsSUFBSSxDQUFDLE1BQU07Ozs7Ozs7O0FBQWxCLDJCQUFHO0FBQ04sOEJBQU0sR0FBTSxNQUFNLENBQUMsUUFBUSxTQUFJLEdBQUc7QUFDbEMsOEJBQU0sR0FBTSxFQUFFLFNBQUksR0FBRzs7O3dEQUdqQixxQkFBUSxNQUFNLENBQUMsTUFBTSxDQUFDOzs7Ozs7Ozs7O3dEQUV0QixxQkFBUSxRQUFRLENBQUMsTUFBTSxFQUFFLE1BQU0sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQkFHM0M7OztBQUdELHNCQUFNLENBQUMsV0FBVyxHQUFHLG9CQUFPLFdBQVc7c0JBQy9CLEdBQUcsRUFDSCxPQUFPLEVBQ1AsTUFBTTs7OztBQUZOLDJCQUFHLEdBQUcsMkJBQVMsS0FBSyxDQUFDO0FBQ3JCLCtCQUFPLEdBQU0sU0FBUyxTQUFJLElBQUk7QUFDOUIsOEJBQU0sR0FBRyxxQkFBUSxpQkFBaUIsQ0FBQyxPQUFPLENBQUM7O0FBQ2pELDJCQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNoQiwyQkFBRyxDQUFDLFNBQVMsQ0FBQyxFQUFFLEVBQUUsS0FBSyxDQUFDO0FBQ3hCLDJCQUFHLENBQUMsUUFBUSxFQUFFOzs7Ozs7O2lCQUNmOzs7Ozs7Z0RBS2UsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7QUFFN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDeEIsUUFBUSxFQUdOLEtBQUs7Ozs7OzBEQUhVLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7O0FBQWxELGtDQUFROztnQ0FFUixRQUFRLElBQUksSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVzs7Ozs7OzBEQUN2QixjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxXQUFRLEVBQUUsSUFBSSxDQUFDOzs7QUFBbkUsK0JBQUs7OzBEQUNILE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxLQUFLLEVBQUUsS0FBSyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUMsQ0FBQzs7Ozs7OzttQkFFbEQsRUFBQyxDQUFDOzs7QUFURCxtQkFBRzs7QUFXUCxzQkFBTSxDQUFDLEtBQUssRUFBRTs7b0RBRVAsR0FBRzs7Ozs7OztTQUNYLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9CQUVEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1FDbktLLHdCQUF3Qjs7UUFDeEIsc0JBQXNCLEU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MkJDQ3RCLGNBQWM7O3lCQUNILGVBQWU7Ozs7NEJBRzFCLGVBQWU7Ozs7b0JBR0wsTUFBTTs7OzsyQkFDSCxhQUFhOzs7O3NCQUNQLFVBQVU7O0FBRXBDLElBQU0sT0FBTyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFNBQVMsRUFBRTtBQUM5QyxjQUFZLEVBQUUsT0FBTztDQUN0QixDQUFDLENBQUM7O0lBRVUsTUFBTTtZQUFOLE1BQU07O0FBRU4sV0FGQSxNQUFNLENBRUwsUUFBUSxFQUFFOzs7MEJBRlgsTUFBTTs7QUFJZixRQUFJLE9BQU8sR0FBRyxPQUFPLENBQUMsT0FBTyxDQUFDO0FBQzVCLFNBQUcsRUFBRSxRQUFRO0tBQ2QsQ0FBQyxDQUFDOztBQUVILCtCQVJTLE1BQU0sNkNBUVQsT0FBTyxFQUFFOztBQUVmLFFBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxPQUFPLEVBQUUsQ0FBQzs7QUFFMUIsWUFBUSxJQUFJLENBQUMsSUFBSTs7QUFFZixXQUFLLE9BQU87QUFDVixZQUFJLENBQUMsS0FBSyxHQUFHLDJCQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxZQUFJLFVBQU8sR0FBRztjQUFRLFFBQVEseURBQUcsVUFBQyxNQUFNLEVBQUcsRUFBRTtjQUFFLE9BQU8seURBQUcsVUFBQyxDQUFDLEVBQUcsRUFBRTtjQUMxRCxHQUFHOzs7O0FBQUgsbUJBQUcsc0JBQW9CLElBQUksQ0FBQyxLQUFLOztnREFDeEIsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxPQUFPLENBQUM7Ozs7Ozs7Ozs7U0FDL0QsQ0FBQztBQUNGLGNBQU07O0FBRVI7QUFDRSxjQUFNLElBQUksS0FBSyxDQUFDLHVCQUF1QixDQUFDLENBQUM7O0FBQUEsS0FFNUM7R0FDRjs7Ozs7OztlQTFCVSxNQUFNOztXQWdDSjs7O1VBQUMsU0FBUyx5REFBRyxFQUFFO1VBQUUsT0FBTyx5REFBRyxvQkFBTyxDQUFDOzs7Ozs7OztPQUFPOztVQUVqRCxPQUFPLEVBUVAsS0FBSyxrRkFDQSxNQUFNOzs7Ozs7O0FBVFgsbUJBQU8sR0FBRyxJQUFJLENBQUMsVUFBVSxFQUFFOzs7QUFHL0IsbUJBQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ25CLGtCQUFJLEVBQUUsTUFBTTtBQUNaLG1CQUFLLEVBQUUsRUFBRTthQUNWLENBQUM7O0FBRUUsaUJBQUssR0FBRyxFQUFFOzs7Ozs7QUFDZCw2QkFBbUIsT0FBTyxDQUFDLE9BQU8sdUhBQUU7QUFBM0Isb0JBQU07O0FBQ2IsbUJBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFDbkIscUJBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixxQkFBSyxFQUFFLENBQUM7ZUFDVCxDQUFDO2FBQ0g7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBRUssSUFBSSxVQUFPLENBQ2Ysb0JBQU8sTUFBTTt1R0FDRixNQUFNLEVBQ1QsS0FBSyxFQUNMLElBQUk7Ozs7Ozs7OztpQ0FGUyxPQUFPLENBQUMsT0FBTzs7Ozs7Ozs7QUFBekIsMEJBQU07QUFDVCx5QkFBSyxHQUFHLHlCQUFRLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDO0FBQ3RDLHdCQUFJLEdBQUcsdUJBQU0sS0FBSyxDQUFFOzt5QkFDcEIsSUFBSSxDQUFDLE1BQU0sQ0FBQzs7Ozs7QUFDZCx5QkFBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7MEJBQ3ZCLE9BQU8sU0FBUyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsS0FBSyxXQUFXOzs7Ozs7b0RBQ3pDLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsTUFBTSxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2FBSzNDLEVBQ0QsT0FBTyxDQUNSOzs7Z0RBR00sS0FBSzs7Ozs7OztLQUViOzs7U0F0RVUsTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQ2ZaLGNBQWM7O3lCQUNILGVBQWU7Ozs7NEJBRzFCLGVBQWU7O0FBRXRCLElBQU0sTUFBTSxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFFBQVEsRUFBRTtBQUM1QyxjQUFZLEVBQUUsT0FBTztDQUN0QixDQUFDLENBQUM7O0lBRVUsU0FBUztBQUlULFdBSkEsU0FBUyxDQUlSLE9BQU8sRUFBRTswQkFKVixTQUFTOztBQUtsQixRQUFJLENBQUMsT0FBTyxHQUFHLE9BQU8sQ0FBQztHQUN4Qjs7Ozs7Ozs7ZUFOVSxTQUFTOztXQWFiLG1CQUFHO0FBQ1IsYUFBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFlBQVksQ0FBQztLQUNsQzs7O1dBRVMsc0JBQUc7QUFDWCxhQUFPLElBQUksQ0FBQyxPQUFPLENBQUM7S0FDckI7OztXQUVNLG1CQUE2RDs7O1VBQTVELFFBQVEseURBQUcsb0JBQU8sTUFBTTs7Ozs7Ozs7T0FBTztVQUFFLE9BQU8seURBQUcsb0JBQU8sQ0FBQzs7Ozs7Ozs7T0FBTztLQUFJOzs7U0FyQjNELFNBQVM7Ozs7O0lBeUJULEtBQUs7WUFBTCxLQUFLOztBQUVMLFdBRkEsS0FBSyxDQUVKLE9BQU8sRUFBRTs7OzBCQUZWLEtBQUs7O0FBSWQsUUFBSSxPQUFPLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUMzQixTQUFHLEVBQUUsT0FBTztLQUNiLENBQUMsQ0FBQzs7QUFFSCwrQkFSUyxLQUFLLDZDQVFSLE9BQU8sRUFBRTs7QUFFZixRQUFJLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7O0FBRTFCLFlBQVEsSUFBSSxDQUFDLElBQUk7QUFDZixXQUFLLE9BQU87QUFDVixZQUFJLENBQUMsS0FBSyxHQUFHLDJCQUFVLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQztBQUNsQyxZQUFJLFVBQU8sR0FBRyxvQkFBTyxHQUFHO2NBQ2xCLEdBQUc7Ozs7QUFBSCxtQkFBRyxzQkFBb0IsSUFBSSxDQUFDLEtBQUssZ0JBQVksR0FBRyxDQUFDLEdBQUcsYUFBUyxHQUFHLENBQUMsRUFBRTs7Z0RBQzFELElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs7OztTQUNuQyxDQUFDO0FBQ0YsY0FBTTtBQUNSO0FBQ0UsY0FBTSxJQUFJLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQyxDQUFDO0FBQUEsS0FDekM7R0FFRjs7Ozs7OztlQXhCVSxLQUFLOztXQStCVCxtQkFBNkQ7OztVQUE1RCxRQUFRLHlEQUFHLG9CQUFPLE1BQU07Ozs7Ozs7O09BQU87VUFBRSxPQUFPLHlEQUFHLG9CQUFPLENBQUM7Ozs7Ozs7O09BQU87O0FBRWhFLFVBQUksR0FBRyxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUM7QUFDcEIsZUFBTyxFQUFFLElBQUksQ0FBQyxPQUFPLENBQUMsR0FBRztPQUMxQixFQUFFO0FBQ0QsY0FBTSxFQUFFO0FBQ04sYUFBRyxFQUFFLENBQUM7QUFDTixZQUFFLEVBQUUsQ0FBQztBQUNMLGFBQUcsRUFBRSxDQUFDO1NBQ1A7T0FDRixDQUFDLENBQUM7O0FBRUgsYUFBTyxJQUFJLE9BQU8sQ0FDaEIsVUFBQyxPQUFPLEVBQUUsTUFBTSxFQUFLOztBQUVuQixXQUFHLENBQUMsT0FBTyxDQUNULG9CQUFPLEdBQUcsRUFBRSxLQUFLO2NBRVQsTUFBTTs7Ozs7O2dEQUFTLElBQUksVUFBTyxDQUFDLEdBQUcsQ0FBQzs7O0FBQS9CLHNCQUFNOztnREFDSixRQUFRLENBQUMsTUFBTSxDQUFDOzs7Ozs7Ozs7O0FBRXRCLHVCQUFPLGdCQUFHLENBQUM7OztBQUViLG9CQUFJLEtBQUssR0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLEtBQUssRUFBRSxFQUFFO0FBQzdCLHlCQUFPLEVBQUUsQ0FBQztpQkFDWDs7Ozs7OztTQUNGLENBQUMsQ0FBQztPQUVOLENBQ0YsU0FBTSxDQUNMLFVBQUMsQ0FBQyxFQUFLO0FBQ0wsY0FBTSxDQUFDLENBQUM7T0FDVCxDQUNGLENBQUM7S0FFSDs7O1NBbEVVLEtBQUs7R0FBUyxTQUFTOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkNyQ2xCLGVBQWU7Ozs7OEJBQ1Ysb0JBQW9COzs7O0lBRTlCLFFBQVE7Ozs7OztBQUtSLFdBTEEsUUFBUSxDQUtQLEtBQUssRUFBRTswQkFMUixRQUFROztBQU1qQixRQUFJLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztHQUNwQjs7ZUFQVSxRQUFROztXQVNDLHdCQUFDLFNBQVMsRUFBRSxlQUFlO1VBQ3ZDLGFBQWEsRUFHYixNQUFNLEVBU04sR0FBRyxFQU9ILE1BQU0sRUFPTixPQUFPOzs7Ozs7QUExQlAseUJBQWEsR0FBRyxzQkFBc0I7QUFHdEMsa0JBQU0sR0FBRyxFQUFFOztBQUNqQiwyQkFBZSxDQUFDLE9BQU8sQ0FBQyxVQUFDLElBQUksRUFBSztBQUNoQyxvQkFBTSxDQUFDLElBQUksQ0FBQztBQUNWLDBCQUFVLEVBQUUsU0FBUztBQUNyQiwyQkFBVyxFQUFFLElBQUk7ZUFDbEIsQ0FBQyxDQUFDO2FBQ0osQ0FBQyxDQUFDOzs7QUFHRyxlQUFHLHVEQUVGLGFBQWEsaUNBQ0MsU0FBUzs7NENBSVQsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ3pDLGFBQWEsb0JBQ0csU0FBUyxFQUN6Qix5QkFBeUIsQ0FDMUI7OztBQUpLLGtCQUFNO0FBT04sbUJBQU8sR0FBRyxFQUFFOzs0Q0FFWixpQ0FDSixNQUFNLEVBQUUsTUFBTSxFQUFFLElBQUksRUFDcEIsb0JBQU8sRUFBRSxFQUFFLE1BQU07a0JBQ1QsR0FBRzs7Ozs7b0RBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ3RDLGFBQWEsRUFDYixFQUFFLEVBQ0YsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFFLElBQUksRUFBRSxDQUFDLEVBQUUsRUFBRSxNQUFNLENBQUMsQ0FDbkM7OztBQUpLLHVCQUFHOztBQUtULDJCQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7Ozs7O2FBQ25CLEVBQ0Qsb0JBQU8sRUFBRSxFQUFFLE1BQU07a0JBQ1QsR0FBRzs7Ozs7b0RBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLDhCQUVsQixhQUFhLHVDQUNOLE1BQU0sQ0FBQyxVQUFVLHdDQUNoQixNQUFNLENBQUMsV0FBVyxrQkFFekM7OztBQU5LLHVCQUFHOztBQU9ULDJCQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOzs7Ozs7O2FBQ25CLENBQ0Y7OztnREFFTSxPQUFPOzs7Ozs7O0tBQ2Y7OztXQUVnQixxQkFBQyxjQUFjO1VBQUUsUUFBUSx5REFBRyxDQUFDOzs7Ozs0Q0FDdEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQzFCLG1CQUFtQiwwQkFDRyxjQUFjLEVBQ3BDLEVBQUUsRUFBRTtBQUNGLG1CQUFLLEVBQUUsUUFBUTtBQUNmLDZCQUFlLEVBQUUsQ0FBQztBQUNsQix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs0Q0FFSyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDMUIsbUJBQW1CLDBCQUNHLGNBQWMsRUFDcEMsRUFBRSxFQUFFO0FBQ0YsbUJBQUssRUFBRSxRQUFRO0FBQ2YseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7Ozs7Ozs7S0FDRjs7O1dBRXFCLDBCQUFDLElBQUk7VUFDbkIsU0FBUyxFQUVULEdBQUcsRUFHSCxNQUFNLEVBU04sS0FBSyxrRkF1QkEsTUFBTTs7Ozs7OztBQXJDWCxxQkFBUyxHQUFHLElBQUksQ0FBQyxVQUFVO0FBRTNCLGVBQUcsR0FBRyxFQUFFOztBQUdSLGtCQUFNLEdBQUcsU0FBVCxNQUFNLENBQVUsR0FBRztrQkFDakIsR0FBRzs7OztBQUFILHVCQUFHLHVFQUVZLElBQUksQ0FBQyxVQUFVLG1CQUFjLEdBQUc7cUNBRXJELEdBQUc7O29EQUFZLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7OzttQ0FBaEMsSUFBSTs7Ozs7OzthQUNUOztBQUdLLGlCQUFLLEdBQUcsU0FBUixLQUFLLENBQVUsR0FBRztrQkFFaEIsR0FBRyxFQUlILFFBQVE7Ozs7QUFKUix1QkFBRyxnRkFFWSxJQUFJLENBQUMsVUFBVSxtQkFBYyxHQUFHOztvREFFOUIsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBdEMsNEJBQVE7O3lCQUNWLFFBQVEsQ0FBQyxDQUFDLENBQUMsQ0FBQyxVQUFVLENBQUM7Ozs7Ozs7O3FDQUUzQixHQUFHOztvREFDSyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDMUIsaUJBQWlCLEVBQ2pCLEVBQUUsRUFDRjtBQUNFLGdDQUFVLEVBQUUsSUFBSSxDQUFDLFVBQVU7QUFDM0IseUJBQUcsRUFBSCxHQUFHO0FBQ0gsZ0NBQVUsRUFBRSxTQUFTO0FBQ3JCLGlDQUFXLEVBQUUsT0FBTztxQkFDckIsQ0FDRjs7OzttQ0FWQyxJQUFJOzs7Ozs7O2FBWVQ7Ozs7Ozt3QkFFb0IsSUFBSSxDQUFDLElBQUk7Ozs7Ozs7O0FBQW5CLGtCQUFNOzZCQUNQLE1BQU0sQ0FBQyxHQUFHO2tEQUNYLElBQUksMkJBR0osS0FBSzs7Ozs7NENBRkYsS0FBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7NENBR2pCLE1BQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0RBS3ZCO0FBQ0wsaUJBQUcsRUFBSCxHQUFHO2FBQ0o7Ozs7Ozs7S0FDRjs7O1dBRXVCLDRCQUFDLElBQUk7VUFDckIsU0FBUyxFQUNULE1BQU0sRUFDTixTQUFTLEVBRVQsR0FBRyxFQUdILEdBQUcsRUFHQSxDQUFDOzs7O0FBVkoscUJBQVMsR0FBRyxJQUFJLENBQUMsVUFBVTtBQUMzQixrQkFBTSxHQUFHLElBQUksQ0FBQyxNQUFNO0FBQ3BCLHFCQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVU7QUFFM0IsZUFBRyxHQUFHLEVBQUU7QUFHUixlQUFHLHlEQUF1RCxTQUFTOzZCQUN6RSxHQUFHOzs0Q0FBWSxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7Ozs7MkJBQWhDLElBQUk7QUFFQyxhQUFDLEdBQUcsQ0FBQzs7O2tCQUFFLENBQUMsR0FBRyxNQUFNLENBQUMsTUFBTTs7Ozs7OzRDQUN6QixJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDMUIsbUJBQW1CLEVBQUU7QUFDbkIsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHdCQUFVLEVBQUUsU0FBUztBQUNyQix1QkFBUyxFQUFFLE1BQU0sQ0FBQyxDQUFDLENBQUM7QUFDcEIsa0JBQUksRUFBRSxDQUFDLEdBQUcsQ0FBQzthQUNaLEVBQUU7QUFDRCx5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBVmdDLGFBQUMsRUFBRTs7Ozs7Z0RBYS9CO0FBQ0wsaUJBQUcsRUFBSCxHQUFHO2FBQ0o7Ozs7Ozs7S0FDRjs7O1dBRWtCLHVCQUFDLElBQUk7VUFDbEIsVUFBVSxFQUNWLElBQUksdUZBc0RHLENBQUMsdUZBR04sR0FBRzs7Ozs7QUExREwsc0JBQVUsR0FBRyxFQUFFO0FBQ2YsZ0JBQUksR0FBRyxFQUFFOzs7O0FBSWIsZ0JBQUksR0FBRyxDQUNMLFFBQVEsRUFDUixNQUFNLEVBQ04sTUFBTSxFQUNOLGtCQUFrQixFQUNsQixvQkFBb0IsRUFDcEIsYUFBYSxFQUNiLFdBQVcsQ0FDWixDQUFDOzs7OztBQUNGLDhCQUFnQixJQUFJLDJIQUFFO0FBQVgsZUFBQzs7QUFDVixrQkFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDWCwwQkFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQztlQUN6QjthQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FrQkssSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQzFCLGFBQWEsb0JBQ0csSUFBSSxDQUFDLFVBQVUsRUFDL0IsVUFBVSxFQUFFO0FBQ1YseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7Ozs7OztBQUlELHNCQUFVLEdBQUcsRUFBRSxDQUFDO0FBQ2hCLGdCQUFJLEdBQUcsQ0FDTCxrQkFBa0IsRUFDbEIsY0FBYyxFQUNkLFlBQVksRUFDWixTQUFTLEVBQ1QsU0FBUyxFQUNULGNBQWMsQ0FDZixDQUFDOzs7OztBQUNGLDhCQUFnQixJQUFJLDJIQUFFO0FBQVgsZUFBQztBQUFZLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBRzdDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUN0QyxtQkFBbUIsb0JBQ0gsSUFBSSxDQUFDLFVBQVUsRUFDL0IsVUFBVSxFQUFFO0FBQ1YseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQU5LLGVBQUc7Z0RBUUY7QUFDTCxpQkFBRyxFQUFILEdBQUc7YUFDSjs7Ozs7OztLQUNGOzs7V0FFa0IsdUJBQUMsSUFBSTtVQUNoQixTQUFTLEVBRVQsR0FBRyxFQUVMLFVBQVUsRUFDVixJQUFJLHVGQTZERyxDQUFDOzs7OztBQWxFTixxQkFBUyxHQUFHLElBQUksQ0FBQyxVQUFVO0FBRTNCLGVBQUcsR0FBRyxFQUFFO0FBRVYsc0JBQVUsR0FBRyxFQUFFO0FBQ2YsZ0JBQUksR0FBRyxFQUFFOztBQUViLGdCQUFJLEdBQUcsQ0FDTCxNQUFNLEVBQ04sb0JBQW9CLENBQ3JCLENBQUM7Ozs7Ozs7Ozs7QUFNRiw4QkFBZ0IsSUFBSSwySEFBRTtBQUFYLGVBQUM7QUFBWSxrQkFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUFFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUd4QyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVcsQ0FDM0MsYUFBYSxFQUNiLFVBQVUsRUFBRTtBQUNWLHdCQUFVLEVBQUUsU0FBUztBQUNyQixvQkFBTSxFQUFFLENBQUM7QUFDVCxrQkFBSSxFQUFFLE1BQU07QUFDWiw4QkFBZ0IsRUFBRSxNQUFNO0FBQ3hCLHlCQUFXLEVBQUUsTUFBTTtBQUNuQix1QkFBUyxFQUFFLE1BQU07QUFDakIseUJBQVcsRUFBRSxPQUFPO0FBQ3BCLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFaRCxlQUFHLENBQUMsVUFBVTs7QUFjZCxzQkFBVSxHQUFHLEVBQUUsQ0FBQztBQUNoQixnQkFBSSxHQUFHLENBQ0wsY0FBYyxFQUNkLGlCQUFpQixFQUNqQixTQUFTLEVBQ1QsU0FBUyxFQUNULGNBQWMsQ0FDZixDQUFDOzs7Ozs7Ozs7OztBQU9GLDhCQUFnQixJQUFJLDJIQUFFO0FBQVgsZUFBQztBQUFZLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQUU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NENBR2xDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxDQUNqRCxtQkFBbUIsRUFDbkIsVUFBVSxFQUFFO0FBQ1Ysd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHdCQUFVLEVBQUUsR0FBRyxDQUFDLFVBQVU7QUFDMUIsbUJBQUssRUFBRSxDQUFDO0FBQ1IsNkJBQWUsRUFBRSxDQUFDO0FBQ2xCLGdDQUFrQixFQUFFLE1BQU07QUFDMUIsZ0NBQWtCLEVBQUUsTUFBTTtBQUMxQiw4QkFBZ0IsRUFBRSxNQUFNO0FBQ3hCLHdCQUFVLEVBQUUsTUFBTTtBQUNsQix5QkFBVyxFQUFFLE9BQU87QUFDcEIseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQWRELGVBQUcsQ0FBQyxnQkFBZ0I7Ozs7OztBQWdCcEIsOEJBQWdCLElBQUksMkhBQUU7QUFBWCxlQUFDO0FBQVksa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFBRTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FHbEMsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQ2pELG1CQUFtQixFQUFFLEVBQUUsRUFBRTtBQUN2Qiw4QkFBZ0IsRUFBRSxHQUFHLENBQUMsZ0JBQWdCO0FBQ3RDLHdCQUFVLEVBQUUsU0FBUztBQUNyQixtQkFBSyxFQUFFLENBQUM7QUFDUix5QkFBVyxFQUFFLE9BQU87QUFDcEIseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQVJELGVBQUcsQ0FBQyxnQkFBZ0I7Z0RBV2I7QUFDTCxpQkFBRzs7O0FBQUgsaUJBQUc7YUFDSjs7Ozs7OztLQUNGOzs7U0FuVVUsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUJDSEssU0FBUzs7OEJBQ2YsaUJBQWlCOzs7Ozs7b0JBR3BCLE1BQU07Ozs7MkJBQ0gsYUFBYTs7OztxQkFDVixRQUFROzt5QkFDYixlQUFlOzs7O0lBRXBCLGVBQWUsR0FDZCxTQURELGVBQWUsQ0FDYixJQUFJLEVBQUUsT0FBTyxFQUFFO3dCQURqQixlQUFlOztBQUV4QixNQUFJLFFBQVEsYUFBQztBQUNiLFVBQVEsSUFBSSxDQUFDLElBQUk7QUFDZixTQUFLLE9BQU87QUFDVixjQUFRLEdBQUcsSUFBSSxhQUFhLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQyxDQUFDO0FBQUEsR0FDL0M7O0FBRUQsU0FBTyxRQUFRLENBQUM7Q0FDakI7Ozs7SUFHVSxRQUFRO0FBQ1AsV0FERCxRQUFRLENBQ04sSUFBSSxFQUFFLE9BQU8sRUFBRTswQkFEakIsUUFBUTs7QUFFakIsUUFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7QUFDakIsUUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7R0FDeEI7O2VBSlUsUUFBUTs7V0FlVixvQkFBRztBQUNWLGFBQU8sSUFBSSxDQUFDLElBQUksQ0FBQztLQUNsQjs7O1dBRVEsb0JBQUc7QUFDVixhQUFPLElBQUksQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDO0tBQ3ZCOzs7V0FFVyx1QkFBRztBQUNiLGFBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQztLQUNyQjs7O1dBRWtCLDhCQUVqQjs7O1VBREEsRUFBRSx5REFBRztZQUFPLFFBQVEseURBQUcsVUFBQyxNQUFNLEVBQUssRUFBRTtZQUFFLE9BQU8seURBQUcsVUFBQyxDQUFDLEVBQUssRUFBRTs7Ozs7Ozs7T0FBTzs7QUFFakUsVUFBSSxVQUFPLEdBQUcsRUFBRSxDQUFDO0tBQ2xCOzs7Ozs7Ozs7Ozs7O1dBV2E7VUFBQyxTQUFTLHlEQUFHLEVBQUU7O1VBQ3JCLE9BQU8sRUFRUCxPQUFPLGtGQU1GLENBQUMsRUFGTixPQUFPOzs7Ozs7O0FBWlAsbUJBQU8sR0FBRyxJQUFJLENBQUMsV0FBVyxFQUFFOzs7QUFHbEMsbUJBQU8sQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDO0FBQ25CLGtCQUFJLEVBQUUsTUFBTTtBQUNaLG1CQUFLLEVBQUUsRUFBRTthQUNWLENBQUMsQ0FBQzs7QUFFRyxtQkFBTyxHQUFHLEVBQUU7Ozs7OztBQUNsQiw2QkFBZ0IsT0FBTyxDQUFDLE9BQU8sdUhBQUU7QUFBdEIsZUFBQzthQUNYOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFSyxtQkFBTyxHQUFHLEVBQUU7Ozs7OztBQUVsQiw4QkFBZ0IsT0FBTyxDQUFDLE9BQU8sMkhBQUU7QUFBdEIsZUFBQzs7QUFDVixxQkFBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsR0FBRztBQUNoQixxQkFBSyxFQUFFLENBQUMsQ0FBQyxLQUFLO0FBQ2QscUJBQUssRUFBRSxPQUFPLENBQUMsQ0FBQyxLQUFLLEtBQUssV0FBVyxHQUFHLENBQUMsQ0FBQyxLQUFLLEdBQUcsQ0FBQztBQUNuRCxxQkFBSyxFQUFFLENBQUM7ZUFDVCxDQUFDO0FBQ0YscUJBQU8sQ0FBQyxJQUFJLENBQ1Y7QUFDRSxvQkFBSSxFQUFFLENBQUMsQ0FBQyxJQUFJO0FBQ1osb0JBQUksRUFBRSx1QkFBSyx5QkFBUSxRQUFRLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO2VBQ3RDLENBQ0YsQ0FBQzthQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUVLLElBQUksVUFBTyxDQUNmLG9CQUFPLE1BQU0sRUFBRSxPQUFPO3VHQUNULENBQUMsRUFFSixDQUFDOzs7Ozs7Ozs7aUNBRk8sT0FBTzs7Ozs7Ozs7QUFBWixxQkFBQztBQUVKLHFCQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7O3lCQUNyQixDQUFDLENBQUMsS0FBSzs7Ozs7MEJBQ0wsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSzs7Ozs7Ozs7eUJBS3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDOzs7Ozs7QUFFaEIscUJBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7OzswQkFHTixPQUFPLFNBQVMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEtBQUssV0FBVzs7Ozs7O29EQUNwQyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sRUFBRSxPQUFPLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7YUFLL0MsQ0FDTjs7O2dEQUdVLE9BQU87Ozs7Ozs7S0FDZjs7O1dBNUZjLGlCQUFDLElBQUksRUFBRSxPQUFPLEVBQUU7QUFDN0IsY0FBUSxJQUFJLENBQUMsSUFBSTtBQUNmLGFBQUssT0FBTztBQUNWLGlCQUFPLElBQUksYUFBYSxDQUFDLElBQUksRUFBRSxPQUFPLENBQUMsQ0FBQztBQUMxQztBQUNFLGdCQUFNLElBQUksS0FBSyxDQUFDLG1CQUFtQixDQUFDLENBQUM7QUFBQSxPQUN4QztLQUNGOzs7U0FiVSxRQUFROzs7OztJQXFHUixhQUFhO1lBQWIsYUFBYTs7QUFDWixXQURELGFBQWEsQ0FDWCxJQUFJLEVBQUUsT0FBTyxFQUFFOzs7MEJBRGpCLGFBQWE7O0FBRXRCLCtCQUZTLGFBQWEsNkNBRWhCLElBQUksRUFBRSxPQUFPLEVBQUU7O0FBRXJCLFFBQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUUsQ0FBQzs7QUFFN0IsUUFBSSxDQUFDLEtBQUssR0FBRywyQkFBVSxJQUFJLENBQUMsQ0FBQztBQUM3QixRQUFJLENBQUMsa0JBQWtCLENBQUMsb0JBQU8sUUFBUSxFQUFFLE9BQU87VUFDeEMsR0FBRyxFQUNILEdBQUc7Ozs7QUFESCxlQUFHLHNCQUFvQixJQUFJLENBQUMsS0FBSzs7NENBQ3JCLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsVUFBQyxDQUFDLEVBQUs7QUFBRSxvQkFBTSxDQUFDLENBQUM7YUFBRSxDQUFDOzs7QUFBekUsZUFBRztnREFDRixHQUFHOzs7Ozs7O0tBQ1gsQ0FBQyxDQUFDO0dBQ0o7Ozs7OztTQVpVLGFBQWE7R0FBUyxRQUFROzs7O0lBbUI5QixhQUFhO1lBQWIsYUFBYTs7QUFDWixXQURELGFBQWEsQ0FDWCxJQUFJLEVBQUUsT0FBTyxFQUFFOzs7MEJBRGpCLGFBQWE7O0FBRXRCLCtCQUZTLGFBQWEsNkNBRWhCLElBQUksRUFBRSxPQUFPLEVBQUU7OztBQUdyQixRQUFJLENBQUMsa0JBQWtCLENBQUMsb0JBQU8sUUFBUSxFQUFFLE9BQU87VUFDMUMsTUFBTSxFQUlKLEVBQUUsRUFDRixVQUFVLEVBRVYsT0FBTyxFQU1QLEdBQUcsRUFRQyxHQUFHOzs7O0FBckJULGtCQUFNOzs0Q0FDSyxxQkFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsRUFBRSxFQUFFLGVBQWUsRUFBRSxJQUFJLEVBQUUsQ0FBQzs7O0FBQXZFLGtCQUFNO0FBR0EsY0FBRSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztBQUM3QixzQkFBVSxHQUFHLEVBQUUsQ0FBQyxVQUFVLENBQUMsSUFBSSxDQUFDLFVBQVUsQ0FBQztBQUUzQyxtQkFBTyxHQUFHO0FBQ2Qsb0JBQU0sRUFBTixNQUFNO0FBQ04sd0JBQVUsRUFBVixVQUFVO0FBQ1Ysc0JBQVEsRUFBRSxFQUFFO2FBQ2I7QUFFSyxlQUFHLEdBQUcsVUFBVSxDQUFDLElBQUksRUFBRTs7O0FBRzdCLGVBQUcsQ0FBQyxhQUFhLENBQUMsaUJBQWlCLEVBQUUsSUFBSSxDQUFDLENBQUM7Ozs7Ozs7NENBSTVCLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Ozs0Q0FDTixHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdEIsZUFBRzs7NENBQ0gsUUFBUSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUM7Ozs7Ozs7Ozs0Q0FJeEIsR0FBRyxDQUFDLEtBQUssRUFBRTs7Ozs7Ozs7OztLQUVwQixDQUFDLENBQUM7R0FDSjs7U0FuQ1UsYUFBYTtHQUFTLFFBQVE7Ozs7SUFzQzlCLGtCQUFrQjtZQUFsQixrQkFBa0I7O0FBQ2pCLFdBREQsa0JBQWtCLENBQ2hCLElBQUksRUFBRSxPQUFPLEVBQUU7OzswQkFEakIsa0JBQWtCOztBQUUzQiwrQkFGUyxrQkFBa0IsNkNBRXJCLElBQUksRUFBRSxPQUFPLEVBQUU7OztBQUdyQixRQUFJLENBQUMsa0JBQWtCLENBQUMsb0JBQU8sUUFBUSxFQUFFLE9BQU87VUFFeEMsT0FBTyxFQUVQLE9BQU8sRUFNUCxHQUFHLEVBR0QsUUFBUSxFQUNSLFdBQVcsRUFDWCxVQUFVLEVBQ1YsWUFBWSxFQUtQLENBQUMsRUFRTixJQUFJOzs7O0FBM0JOLG1CQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxDQUFDOztBQUNoRCxtQkFBTyxDQUFDLEdBQUcsR0FBTSxPQUFPLENBQUMsR0FBRyxrQkFBZSxDQUFDO0FBQ3RDLG1CQUFPLEdBQUc7QUFDZCxxQkFBTyxFQUFQLE9BQU87YUFDUjs7O2lCQUVNLENBQUM7Ozs7Ozs0Q0FFVSxpQ0FBUSxPQUFPLENBQUM7OztBQUE1QixlQUFHOztBQUNQLGVBQUcsR0FBRyxtQkFBTyxHQUFHLEVBQUUsRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQzs7QUFFL0Isb0JBQVEsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQztBQUMzRCx1QkFBVyxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDO0FBQ2pFLHNCQUFVLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFVBQVUsQ0FBQyxLQUFLLENBQUM7QUFDL0Qsd0JBQVksR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxZQUFZOztrQkFHdkQsWUFBWSxZQUFZLEtBQUs7Ozs7O0FBRXRCLGFBQUMsR0FBRyxDQUFDOzs7a0JBQUUsQ0FBQyxHQUFHLFdBQVc7Ozs7Ozs0Q0FDdkIsUUFBUSxDQUFDLFlBQVksQ0FBQyxDQUFDLENBQUMsRUFBRSxPQUFPLENBQUM7OztBQURULGFBQUMsRUFBRTs7Ozs7Ozs7Ozs0Q0FLOUIsUUFBUSxDQUFDLFlBQVksRUFBRSxPQUFPLENBQUM7OztBQUdqQyxnQkFBSSxHQUFHLFVBQVUsR0FBRyxXQUFXOztrQkFFakMsSUFBSSxHQUFHLFFBQVE7Ozs7Ozs7O0FBQ25CLG1CQUFPLENBQUMsRUFBRSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUM7Ozs7Ozs7OztLQUVoQyxDQUFDLENBQUM7R0FDSjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7U0F4Q1Usa0JBQWtCO0dBQVMsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkNuTGhCLGVBQWU7OzJCQUNWLGdCQUFnQjs7d0JBQ2hDLGNBQWM7Ozs7SUFFZCxjQUFjO1dBQWQsY0FBYzswQkFBZCxjQUFjOzs7ZUFBZCxjQUFjOzs7Ozs7O1dBS3ZCLGNBQUMsSUFBSTs7Ozs7NENBQ00sMkJBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDOzs7QUFBckQsZ0JBQUksQ0FBQyxLQUFLOzs0Q0FDWSwyQkFBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUM7OztBQUEzRCxnQkFBSSxDQUFDLFFBQVE7Ozs7Ozs7S0FDZDs7O1dBRWEsa0JBQUMsTUFBTTtVQUNiLElBQUksRUFPSixVQUFVLEVBUVYsVUFBVSxrRkFFTCxVQUFVLEVBQ2YsV0FBVyx1RkFFSixFQUFFLEVBQ0wsT0FBTyxFQU9QLFVBQVUsdUZBR0wsS0FBSyxFQVFkLFFBQVE7Ozs7Ozs0Q0F2Q0ssSUFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLENBQUM7QUFDcEMsaUJBQUcsRUFBRSxNQUFNO2FBQ1osRUFBRTtBQUNELHdCQUFVLEVBQUU7QUFDVix1QkFBTyxFQUFFLENBQUM7ZUFDWDthQUNGLENBQUM7OztBQU5JLGdCQUFJO0FBT0osc0JBQVUsR0FBRyxJQUFJLENBQUMsT0FBTztBQVF6QixzQkFBVSxHQUFHLEVBQUU7Ozs7O3dCQUVJLFVBQVU7Ozs7Ozs7O0FBQXhCLHNCQUFVO0FBQ2YsdUJBQVcsR0FBRyxDQUFDOzs7Ozt5QkFFRixVQUFVLENBQUMsR0FBRzs7Ozs7Ozs7QUFBcEIsY0FBRTs7NENBQ1csSUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUM7QUFDMUMsaUJBQUcsRUFBRSxFQUFFO2FBQ1IsRUFBRTtBQUNELHdCQUFVLEVBQUU7QUFDVixxQkFBSyxFQUFFLENBQUM7ZUFDVDthQUNGLENBQUM7OztBQU5JLG1CQUFPO0FBT1Asc0JBQVUsR0FBRyxPQUFPLENBQUMsS0FBSzs7Ozs7OztBQUdoQyw4QkFBb0IsVUFBVTtBQUFuQixtQkFBSztBQUFnQix5QkFBVyxJQUFJLEtBQUssQ0FBQyxRQUFRLENBQUM7YUFBQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSWhFLHNCQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJdEQsb0JBQVEsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsVUFBVSxDQUFDO2dEQUUxQyxRQUFROzs7Ozs7O0tBQ2hCOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O1dBdUJhLGtCQUFDLFFBQVEsRUFBRSxLQUFLO1VBQUUsTUFBTSx5REFBRyxJQUFJO1VBQUUsTUFBTSx5REFBRyxJQUFJO1VBRXBELE1BQU0sRUFLTixNQUFNLEVBS04sR0FBRzs7OztBQVZILGtCQUFNLEdBQUcscUJBQVEsSUFBSSxDQUFDO0FBQzFCLHNCQUFRLEVBQVIsUUFBUTthQUNULENBQUMsQ0FBQyxLQUFLLEVBQUUsQ0FBQyxHQUFHLENBQUMsV0FBQztxQkFBSSxDQUFDLENBQUMsZ0JBQWdCO2FBQUEsQ0FBQztBQUdqQyxrQkFBTSxHQUFHLEVBQUU7O0FBQ2pCLGtCQUFNLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztBQUNyQixnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7QUFDekMsZ0JBQUksTUFBTSxFQUFFLE1BQU0sQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDOzs7NENBRXZCLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUNyQyxNQUFNLEVBQUU7QUFDTixtQkFBSyxFQUFFO0FBQ0wsc0JBQU0sRUFBRTtBQUNOLHVCQUFLLEVBQUUsTUFBTTtpQkFDZDtlQUNGO2FBQ0YsQ0FDRjs7O0FBUkssZUFBRztnREFXRixNQUFNOzs7Ozs7O0tBQ2Q7Ozs7Ozs7Ozs7OztXQVVlLG9CQUFDLEtBQUs7VUFBRSxNQUFNLHlEQUFHLElBQUk7VUFBRSxNQUFNLHlEQUFHLElBQUk7VUFFNUMsTUFBTSxFQUtOLEdBQUc7Ozs7QUFMSCxrQkFBTSxHQUFHLEVBQUU7O0FBQ2pCLGtCQUFNLENBQUMsS0FBSyxHQUFHLEtBQUssQ0FBQztBQUNyQixnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNLENBQUM7QUFDekMsZ0JBQUksTUFBTSxFQUFFLE1BQU0sQ0FBQyxZQUFZLEdBQUcsTUFBTSxDQUFDOzs7NENBRXZCLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUNyQyxNQUFNLEVBQUU7QUFDTixrQkFBSSxFQUFFO0FBQ0osc0JBQU0sRUFBRSxFQUFFO2VBQ1g7YUFDRixDQUNGOzs7QUFOSyxlQUFHOzs7Ozs7O0tBT1Y7Ozs7Ozs7Ozs7Ozs7Ozs7OztXQWdCaUIsc0JBQUMsSUFBSSxFQUFFLE9BQU87VUFTeEIsR0FBRyxFQW1DSCxLQUFLLHVGQUVBLENBQUMsdUZBc0JELElBQUksdUZBQXNCLENBQUM7Ozs7O0FBM0RoQyxlQUFHLEdBQUcsQ0FBQztBQUNYLG1CQUFLLEVBQUUsTUFBTTtBQUNiLHFCQUFPLEVBQUUsSUFBSSxDQUFDLFFBQVE7QUFDdEIscUJBQU8sRUFBRTtBQUNQLHFCQUFLLEVBQUUsV0FBVztlQUNuQjtBQUNELG1CQUFLLEVBQUU7QUFDTCw0QkFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO0FBQy9CLDRCQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7ZUFDaEM7YUFDRixFQUNEO0FBQ0UsbUJBQUssRUFBRSxJQUFJLENBQUMsV0FBVztBQUN2QixxQkFBTyxFQUFFLElBQUksQ0FBQyxZQUFZO0FBQzFCLHFCQUFPLEVBQUU7QUFDUCxxQkFBSyxFQUFFLGVBQWU7ZUFDdkI7QUFDRCxtQkFBSyxFQUFFO0FBQ0wsd0JBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtBQUN2Qiw0QkFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO2VBQ2hDO2FBQ0YsRUFDRDtBQUNFLG1CQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVc7QUFDdkIscUJBQU8sRUFBRSxJQUFJLENBQUMsWUFBWTtBQUMxQixxQkFBTyxFQUFFO0FBQ1AscUJBQUssRUFBRSxlQUFlO2VBQ3ZCO0FBQ0QsbUJBQUssRUFBRTtBQUNMLHdCQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7QUFDdkIsNEJBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtlQUNoQzthQUNGLENBQ0E7QUFFSyxpQkFBSyxHQUFHLEVBQUU7Ozs7O3lCQUVBLEdBQUc7Ozs7Ozs7O0FBQVIsYUFBQzs2QkFDVixLQUFLOzs0Q0FDZSxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDcEMsQ0FBQztBQUNDLG9CQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFO0FBQzdCLHFCQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7ZUFDbEIsQ0FBQzthQUNILEVBQ0Q7QUFDRSxzQkFBUSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLE9BQU8sRUFBRSxPQUFPLENBQUM7YUFDNUMsRUFDRDtBQUNFLG1CQUFLLEVBQUU7QUFDTCxtQkFBRyxFQUFFLENBQUM7ZUFDUDthQUNGLENBQ0EsQ0FDRixDQUFDLE9BQU8sRUFBRTs7Ozs2QkFDSixDQUFDOztBQWhCUix3QkFBVTtBQWdCVixtQkFBSzs7MkJBakJELElBQUk7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7eUJBcUJPLEtBQUs7Ozs7Ozs7O0FBQWIsZ0JBQUk7Ozs7O3lCQUEyQixJQUFJLENBQUMsVUFBVTs7Ozs7Ozs7QUFBcEIsYUFBQzs7NENBQXFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQzs7O0FBQXBDLGFBQUMsQ0FBQyxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0RBRzNELEtBQUs7Ozs7Ozs7S0FDYjs7Ozs7O1dBSWtCLHVCQUFDLEdBQUc7VUFDakIsSUFBSSxFQUdBLEdBQUcsRUFDSCxHQUFHLEVBV0MsS0FBSyxFQWFYLFVBQVU7Ozs7QUE1QlosZ0JBQUk7O2tCQUVKLE9BQU8sR0FBRyxLQUFLLFFBQVE7Ozs7O0FBQ25CLGVBQUcsR0FBRyxJQUFJLE1BQU0sQ0FBSSxHQUFHLE9BQUk7QUFDM0IsZUFBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLEVBQUUsRUFBRTtBQUM5Qix3QkFBVSxFQUFFO0FBQ1YscUJBQUssRUFBRSxDQUFDO0FBQ1IsNEJBQVksRUFBRSxDQUFDO0FBQ2YsNEJBQVksRUFBRSxDQUFDO2VBQ2hCO2FBQ0YsQ0FBQzs7O2lCQUVLLENBQUM7Ozs7Ozs7NENBRVMsR0FBRyxDQUFDLElBQUksRUFBRTs7O0FBQXZCLGdCQUFJOzs0Q0FDZ0IsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBL0MsaUJBQUs7O2lCQUNQLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFHVCxlQUFHLENBQUMsS0FBSyxFQUFFLENBQUM7Z0RBQ0wsR0FBRzs7Ozs7OztBQUdkLGVBQUcsQ0FBQyxLQUFLLEVBQUUsQ0FBQzs7Ozs7QUFFWixnQkFBSSxHQUFHLEdBQUcsQ0FBQzs7O0FBR1Asc0JBQVUsR0FBRyxFQUFFOztBQUNyQixnQkFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDO0FBQzVDLGdCQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7QUFDMUQsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztnREFDbkQsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7S0FDNUI7OztXQUVxQiwwQkFBQyxnQkFBZ0IsRUFBRSxJQUFJO1VBRXJDLFNBQVMsRUFHVCxTQUFTLEVBQ1QsVUFBVSxFQVNaLGFBQWEsRUFjWCxJQUFJLEVBeUJOLFdBQVcsRUFnQlgsS0FBSyxFQXFCSCxhQUFhLEVBdUJiLGlCQUFpQixFQU1qQixJQUFJOzs7O0FBdEhKLHFCQUFTLEdBQUcsU0FBWixTQUFTLENBQUcsUUFBUTtxQkFBSyxRQUFRLEtBQUssUUFBUSxHQUFHLE9BQU8sR0FBRyxRQUFRO2FBQUM7O0FBR3BFLHFCQUFTLEdBQUcsSUFBSTtBQUNoQixzQkFBVSxHQUFHLEVBQUU7Ozs7QUFJckIsZ0JBQUksSUFBSSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM1QyxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQyxDQUFDO0FBQzFELGdCQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsWUFBWSxDQUFDLENBQUM7OztBQUd0RCx5QkFBYTs2QkFDVCxJQUFJLENBQUMsUUFBUTtrREFDZCxLQUFLLDJCQUdMLFFBQVE7Ozs7QUFGWCx5QkFBYSxHQUFHLENBQUMsQ0FBQzs7OztBQUdsQix5QkFBYSxHQUFHLENBQUMsQ0FBQzs7OztBQUdsQix5QkFBYSxHQUFHLENBQUMsQ0FBQzs7OztBQUtoQixnQkFBSSxHQUFHLEVBQUU7NkJBQ1AsSUFBSSxDQUFDLFFBQVE7a0RBQ2QsS0FBSywyQkFTTCxRQUFROzs7O0FBUlgsZ0JBQUksQ0FBQyxJQUFJLENBQUM7QUFDUixpQkFBRyxFQUFFLENBQUM7QUFDTixpQkFBRyxFQUFFLElBQUk7YUFDVixFQUFFO0FBQ0QsaUJBQUcsRUFBRSxDQUFDO0FBQ04saUJBQUcsRUFBRSxLQUFLO2FBQ1gsQ0FBQyxDQUFDOzs7O0FBR0gsZ0JBQUksQ0FBQyxJQUFJLENBQUM7QUFDUixpQkFBRyxFQUFFLENBQUM7QUFDTixpQkFBRyxFQUFFLElBQUk7YUFDVixFQUFFO0FBQ0QsaUJBQUcsRUFBRSxDQUFDO0FBQ04saUJBQUcsRUFBRSxLQUFLO2FBQ1gsQ0FBQyxDQUFDOzs7Ozs7O0FBT0gsdUJBQVcsR0FBRyxJQUFJOzZCQUNkLElBQUksQ0FBQyxRQUFRO2tEQUNkLEtBQUssMkJBR0wsUUFBUTs7OztBQUZYLHVCQUFXLEdBQUcsSUFBSSxDQUFDOzs7O0FBR25CLHVCQUFXLEdBQUcsR0FBRyxDQUFDOzs7Ozs7Ozs0Q0FVSixJQUFJLENBQUMsWUFBWSxDQUFDLElBQUksRUFBRTtBQUN4Qyx3QkFBVSxFQUFFLDhCQUE4QjthQUMzQyxDQUFDOzs7QUFGRSxpQkFBSzs7Ozs7QUFPVCxpQkFBSyxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQ2YsVUFBQyxJQUFJLEVBQUs7QUFDUixrQkFBSSxDQUFDLEtBQUssQ0FBQyxPQUFPLEdBQUcsU0FBUyxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDLENBQUM7QUFDbkQsa0JBQUksQ0FBQyxVQUFVLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxHQUFHLENBQ25DLFVBQUMsU0FBUyxFQUFLO0FBQ2IseUJBQVMsQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFDLFNBQVMsQ0FBQyxLQUFLLENBQUMsQ0FBQztBQUM3Qyx1QkFBTyxTQUFTLENBQUM7ZUFDbEIsQ0FDRixDQUFDO0FBQ0YscUJBQU8sSUFBSSxDQUFDO2FBQ2IsQ0FDRixDQUFDOzs7QUFHSSx5QkFBYSxHQUFHLEtBQUssQ0FBQyxHQUFHLENBQzdCLGNBQUk7cUJBQUksTUFBRywrQkFBK0IsR0FDdEMsbUJBQW1CLEdBQ25CLGlFQUFpRSxpQkFDdEQsSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLGVBQVcsR0FDdEMsUUFBUSxJQUNWLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUNqQixVQUFDLFNBQVMsRUFBSztBQUNiLG9CQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFNBQVMsQ0FBQyxLQUFLLEVBQUU7O0FBRTFDLG1HQUErRSxTQUFTLENBQUMsS0FBSyx3QkFBcUI7aUJBQ25ILElBQUksU0FBUyxDQUFDLEtBQUssR0FBRyxDQUFDLEVBQUU7O0FBRXpCLHdEQUFvQyxTQUFTLENBQUMsVUFBVSx1RUFBa0UsU0FBUyxDQUFDLEtBQUssbUJBQWdCO2lCQUMxSjs7QUFFRCxxSkFBbUksU0FBUyxDQUFDLEtBQUssZUFBWTtlQUMvSixDQUNGLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxjQUVSLFFBQVE7YUFBQSxDQUNiLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQztBQUVKLDZCQUFpQiw4REFFckIsYUFBYTtBQUlULGdCQUFJLEdBQUc7QUFDWCx3QkFBVSxFQUFFLFNBQVM7QUFDckIsd0JBQVUsRUFBRSxnQkFBZ0IsQ0FBQyxVQUFVO0FBQ3ZDLGtCQUFJLEVBQUssVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsU0FBSSxTQUFTLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxTQUFJLElBQUksQ0FBQyxJQUFJLElBQUcsSUFBSSxDQUFDLFFBQVEsU0FBTyxJQUFJLENBQUMsUUFBUSxHQUFLLEVBQUUsQ0FBRTtBQUNuSCxnQ0FBa0IsRUFBRSxpQkFBaUI7O0FBRXJDLDBCQUFZLEVBQUUsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7QUFDbEMscUJBQU8sRUFBRSxJQUFJLENBQUMsWUFBWTs7O0FBRzFCLDZCQUFlLEVBQUUsYUFBYTtBQUM5QixrQkFBSSxFQUFKLElBQUk7QUFDSiwwQkFBWSxFQUFFLFdBQVc7YUFDMUI7NkJBRUQsTUFBTTs2QkFBUSxJQUFJOzs0Q0FBUSxJQUFJLENBQUMsOEJBQThCLENBQUMsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDOzs7OzJCQUE5RSxNQUFNOzZCQUNiLE1BQU07NkJBQVEsSUFBSTs7NENBQVEsSUFBSSxDQUFDLDZCQUE2QixDQUFDLGdCQUFnQixFQUFFLElBQUksQ0FBQzs7OzsyQkFBN0UsTUFBTTs2QkFDYixNQUFNOzhCQUFRLElBQUk7OzRDQUFRLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUM7Ozs7MkJBQTVFLE1BQU07O0FBRWIsa0JBQU0sQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLENBQUM7O2dEQUVwQyxJQUFJOzs7Ozs7O0tBQ1o7OztXQUVtQyx3Q0FBQyxnQkFBZ0IsRUFBRSxJQUFJO1VBQ3JELFFBQVEsRUFJSCxDQUFDOzs7O0FBSk4sb0JBQVEsR0FBRyxFQUFFOzs7QUFFakIsb0JBQVEsSUFBSSxJQUFJLENBQUMsV0FBVyxDQUFDOztBQUU3QixpQkFBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sRUFBRSxDQUFDLEVBQUU7QUFBRSxzQkFBUSxzQ0FBb0MsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsV0FBUSxDQUFDO2FBQUE7QUFHaEgsb0JBQVEsSUFBSSxHQUFHLENBQUM7Z0RBQ1QsRUFBRSxTQUFTLEVBQUUsUUFBUSxFQUFFOzs7Ozs7O0tBQy9COzs7V0FFa0MsdUNBQUMsZ0JBQWdCLEVBQUUsSUFBSTs7OztnREFFakQsRUFBRSxPQUFPLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxFQUFFOzs7Ozs7O0tBQ2hEOzs7V0FFaUMsc0NBQUMsZ0JBQWdCLEVBQUUsSUFBSTtVQUVqRCxHQUFHOzs7O0FBQUgsZUFBRyxHQUFHLE9BQU8sSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztnREFDbEUsRUFBRSxNQUFNLEVBQUUsR0FBRyxFQUFFOzs7Ozs7O0tBQ3ZCOzs7OztXQUdzQiwyQkFBQyxNQUFNLEVBQUUsSUFBSTtVQUM1QixHQUFHOzs7Ozs0Q0FBUyxJQUFJLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxXQUFRLEVBQUUsSUFBSSxDQUFDOzs7QUFBdkQsZUFBRztnREFDRixHQUFHOzs7Ozs7O0tBQ1g7Ozs7O1dBR3FCLDBCQUFDLEdBQUcsRUFBRSxJQUFJO1VBQ3hCLFFBQVEsRUFDUixXQUFXLEVBRWIsS0FBSyxFQUtILFNBQVMsRUFDTixDQUFDOzs7O0FBVEosb0JBQVEsR0FBRyxFQUFFO0FBQ2IsdUJBQVcsR0FBRyxHQUFHO0FBRW5CLGlCQUFLLEdBQUcsRUFBRTs7O0FBRWQsaUJBQUssR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsQ0FBQyxDQUFDLENBQUM7OztBQUdqRCxxQkFBUyxHQUFHLElBQUk7O0FBQ3RCLGlCQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRTtBQUFFLG1CQUFLLENBQUMsU0FBUyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUM7YUFBQTtBQUl6RixpQkFBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVEsQ0FBQzs7OzRDQUNDLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDOzs7Ozs2QkFBSSxJQUFJLENBQUMsUUFBUTs7OzZCQUFJLElBQUksQ0FBQyxJQUFJOzs2QkFBSSxXQUFXO0FBQS9HLGlCQUFLLENBQUMsTUFBTSxDQUFDLGtCQUFZLE9BQU87O0FBQ2hDLGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQztBQUNqQyxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXLENBQUM7QUFDakMsaUJBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQyxDQUFDO0FBQ3hELGdCQUFJLE9BQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxLQUFLLFFBQVEsRUFBRSxLQUFLLENBQUMsSUFBSSxDQUFDLEdBQU0sSUFBSSxDQUFDLFdBQVcsZ0JBQVcsS0FBSyxDQUFDLElBQUksQ0FBRyxDQUFDLEtBQzFGLEtBQUssQ0FBQyxJQUFJLENBQUMsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDOztBQUVwQyxpQkFBSyxDQUFDLGdCQUFnQixDQUFDLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQzs7Z0RBRWpDLEtBQUs7Ozs7Ozs7S0FDYjs7O1dBRXlDLDhDQUFDLFFBQVE7VUFDM0MsRUFBRSxFQUNGLEdBQUcsRUFDSCxPQUFPLEVBTVAsSUFBSSxFQXVCTixXQUFXLHVGQUNKLEdBQUcsRUFHUixjQUFjLEVBQ1gsQ0FBQyxFQUNGLEdBQUU7Ozs7O0FBckNKLGNBQUUsR0FBRyxxQkFBcUI7QUFDMUIsZUFBRyxHQUFHLFVBQVU7QUFDaEIsbUJBQU8sR0FBRztBQUNkLG9CQUFNLEVBQUUsQ0FBQyxNQUFNLENBQUM7QUFDaEIsaUJBQUcsRUFBRSxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUM7YUFDN0I7OzRDQUdrQixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDckMsQ0FDRTtBQUNFLG9CQUFNLHNCQUNILEVBQUUsRUFBRyxRQUFRLENBQ2Y7YUFDRixFQUNEO0FBQ0Usb0JBQU07QUFDSixtQkFBRyxRQUFNLEVBQUk7aUJBQ1osR0FBRyxFQUFHLEVBQUUsU0FBUyxRQUFNLEdBQUssRUFBRSxDQUNoQzthQUNGLEVBQ0Q7QUFDRSxzQkFBUTtBQUNOLG1CQUFHLEVBQUUsQ0FBQztBQUNOLHdCQUFRLEVBQUUsTUFBTTtpQkFDZixHQUFHLFFBQU8sR0FBRyxDQUNmO2FBQ0YsQ0FDRixDQUNGLENBQUMsT0FBTyxFQUFFOzs7QUFyQkwsZ0JBQUk7QUF1Qk4sdUJBQVcsR0FBRyxFQUFFOzs7Ozs7QUFDcEIsOEJBQWtCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRO0FBQXZCLGlCQUFHO0FBQXNCLHlCQUFXLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLE1BQUksR0FBRyxDQUFHLENBQUMsQ0FBQzthQUFBOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBR2xGLDBCQUFjLEdBQUcsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDOztBQUNuQyxpQkFBUyxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxjQUFjLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ3hDLGlCQUFFLEdBQUcsT0FBTyxXQUFXLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxHQUFHLE1BQU0sR0FBRyxXQUFXLENBQUMsQ0FBQyxDQUFDOztBQUMxRSw0QkFBYyxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsaUJBQWlCLEVBQUUsQ0FBQyxHQUFHLENBQUMsRUFBRSxnQkFBZ0IsRUFBRSxHQUFFLEVBQUUsQ0FBQzthQUN4RTs7Z0RBRU0sRUFBRSxjQUFjLEVBQWQsY0FBYyxFQUFFOzs7Ozs7O0tBQzFCOzs7Ozs7OztXQU00QixnQ0FBQyxJQUFJLEVBQUU7QUFDbEMsYUFBTztBQUNMLGlCQUFTLEVBQUUsR0FBRztBQUNkLGNBQU0sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtBQUM5QixZQUFJLEVBQUUsSUFBSTtBQUNWLFdBQUcsT0FBSyxJQUFJLENBQUMsS0FBSyxJQUFHLElBQUksQ0FBQyxZQUFZLEtBQUssRUFBRSxHQUFHLEVBQUUsU0FBTyxJQUFJLENBQUMsWUFBWSxDQUFFLElBQUcsSUFBSSxDQUFDLFlBQVksS0FBSyxFQUFFLEdBQUcsRUFBRSxTQUFPLElBQUksQ0FBQyxZQUFZLENBQUk7QUFDeEksVUFBRSxFQUFFLElBQUk7T0FDVCxDQUFDO0tBQ0g7Ozs7Ozs7O1dBTThCLGtDQUFDLElBQUksRUFBRTtBQUNwQyxVQUFNLE1BQU0sR0FBRztBQUNiLGlCQUFTLEVBQUUsR0FBRztBQUNkLGNBQU0sRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtBQUM5QixZQUFJLEVBQUUsSUFBSTtBQUNWLGNBQU0sRUFBRSxJQUFJO0FBQ1osZ0JBQVEsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtPQUNqQyxDQUFDOztBQUVGLFVBQU0sS0FBSyxHQUFHLHlCQUFZLElBQUksRUFBRSxDQUFDOztBQUVqQyxXQUFLLENBQUMsT0FBTyxDQUNYLFVBQUMsR0FBRyxFQUFFLEtBQUssRUFBSztBQUNkLFlBQUksS0FBSyxhQUFDO0FBQ1YsWUFBSSxNQUFNLGFBQUM7QUFDWCxZQUFJLE1BQU0sYUFBQztBQUNYLFlBQUk7O0FBRUYsZUFBSyxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksR0FBRyxDQUFDLElBQUksQ0FBRyxNQUFJLEdBQUcsQ0FBQyxTQUFTLENBQUcsQ0FBQztBQUNyRCxlQUFLLEdBQUcsT0FBTyxLQUFLLEtBQUssV0FBVyxHQUFHLEVBQUUsR0FBRyxLQUFLLENBQUM7QUFDbEQsZ0JBQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLEdBQUcsQ0FBQyxJQUFJLENBQUcsTUFBSSxHQUFHLENBQUMsVUFBVSxDQUFHLENBQUM7QUFDdkQsZ0JBQU0sR0FBRyxPQUFPLE1BQU0sS0FBSyxXQUFXLEdBQUcsRUFBRSxHQUFHLE1BQU0sQ0FBQztBQUNyRCxnQkFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksR0FBRyxDQUFDLElBQUksQ0FBRyxNQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUcsQ0FBQztBQUN2RCxnQkFBTSxHQUFHLE9BQU8sTUFBTSxLQUFLLFdBQVcsR0FBRyxFQUFFLEdBQUcsTUFBTSxDQUFDO1NBQ3RELENBQUMsT0FBTyxDQUFDLEVBQUU7Ozs7O0FBS1YsaUJBQU87U0FDUjs7QUFFRCxjQUFNLGFBQVcsS0FBSyxDQUFHLEdBQUcsSUFBSSxDQUFDO0FBQ2pDLGNBQU0sV0FBUyxLQUFLLENBQUcsR0FBRyxHQUFHLENBQUMsTUFBTSxDQUFDLENBQUM7QUFDdEMsY0FBTSxVQUFRLEtBQUssQ0FBRyxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUM7QUFDbEMsY0FBTSxhQUFXLEtBQUssQ0FBRyxRQUFNLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBUSxDQUFDO0FBQ3pELGNBQU0sWUFBVSxLQUFLLENBQUcsR0FBRyxJQUFJLENBQUM7T0FDakMsQ0FDRixDQUFDOztBQUVGLGFBQU8sTUFBTSxDQUFDO0tBQ2Y7Ozs7Ozs7O1dBTWtDLHNDQUFDLElBQUksRUFBRSxJQUFJLEVBQUU7QUFDOUMsVUFBTSxLQUFLLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBSSxJQUFJLENBQUMsSUFBSSxDQUFHLE1BQUksSUFBSSxDQUFDLFNBQVMsQ0FBRyxDQUFDO0FBQzdELFVBQU0sTUFBTSxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksSUFBSSxDQUFDLElBQUksQ0FBRyxNQUFJLElBQUksQ0FBQyxVQUFVLENBQUcsQ0FBQztBQUMvRCxVQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsVUFBVSxDQUFHLENBQUM7O0FBRS9ELGFBQU87QUFDTCxpQkFBUyxFQUFFLEdBQUc7QUFDZCxjQUFNLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7QUFDOUIsY0FBTSxFQUFFLElBQUk7QUFDWixZQUFJLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNsQixXQUFHLEVBQUUsSUFBSTtBQUNULGNBQU0sT0FBSyxLQUFLLEdBQUcsTUFBTSxHQUFHLE1BQVE7QUFDcEMsYUFBSyxFQUFFLElBQUk7T0FDWixDQUFDO0tBQ0g7OztTQWprQmtCLGNBQWM7OztxQkFBZCxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7MkJDRjVCLGNBQWM7O29CQUdkLE1BQU07O3dCQUNRLGNBQWM7Ozs7cUJBQ1IsU0FBUzs7OzsyQkFHN0IsZ0JBQWdCOztJQUVGLE9BQU87QUFDZCxXQURPLE9BQU8sR0FDWDswQkFESSxPQUFPOzs7OztBQUt4QixRQUFJLENBQUMsS0FBSyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDO0dBQ3pDOztlQU5rQixPQUFPOzs7Ozs7OztXQWlCVix5QkFBQyxRQUFRLEVBQUUsS0FBSyxFQUFFOztBQUVoQyxVQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQyxDQUFDO0tBQzFDOzs7Ozs7Ozs7Ozs7Ozs7V0E4RWtCLDZCQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUU7Ozs7O0FBSzFDLFVBQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7QUFjakMsVUFBTSxLQUFLLEdBQUcsT0FBTyxDQUFDLG9CQUFvQixDQUN4QztBQUNFLHFCQUFhLEVBQUUsUUFBUSxDQUFDLEVBQUUsQ0FBQzs7QUFFM0Isc0JBQWMsRUFBRTtBQUNkLGFBQUcsRUFBRSxDQUFDLFdBQVcsRUFBRSxNQUFNLENBQUMsV0FBVyxDQUFDLENBQUM7U0FDeEM7T0FDRjs7QUFFRCxhQUFPLElBQUksQ0FBQyxLQUFLLEtBQUssV0FBVyxHQUFHLElBQUksR0FBRyxJQUFJLENBQUMsS0FBSyxDQUN0RCxDQUFDOzs7Ozs7Ozs7O0FBVUYsVUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7OztBQUd0RCxVQUFNLGVBQWUsR0FBRyxZQUFZLENBQUMsZUFBZSxDQUFDO0FBQ3JELFVBQUksZUFBZSxDQUFDLE1BQU0sR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLE1BQU0sSUFBSSxLQUFLLHNCQUFvQixlQUFlLENBQUMsTUFBTSxXQUFRLENBQUM7OztBQUc3RyxrQkFBWSxTQUFNLENBQUMsT0FBTyxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQ2hDLGdCQUFRLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQyxLQUFLLENBQUM7T0FDOUIsQ0FBQyxDQUFDOzs7QUFHSCxxQkFBZSxDQUFDLE9BQU8sQ0FBQyxVQUFDLENBQUMsRUFBRSxDQUFDLEVBQUs7QUFDaEMsWUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLEVBQUU7QUFDWixrQkFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztTQUN4QixNQUFNOzs7QUFHTCxrQkFBUSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUUsQ0FBQztTQUNsQjtPQUNGLENBQUMsQ0FBQzs7Ozs7Ozs7QUFRSCxhQUFPLFFBQVEsQ0FBQztLQUNqQjs7Ozs7Ozs7O1dBT21CLDhCQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUU7Ozs7O0FBSzNDLFVBQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDOzs7Ozs7Ozs7Ozs7OztBQWMxRCxVQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsb0JBQW9CLENBQ3hDO0FBQ0UscUJBQWEsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDOztBQUVuQyxzQkFBYyxFQUFFO0FBQ2QsYUFBRyxFQUFFLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUN4QztPQUNGOztBQUVELGFBQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQ3RELENBQUM7Ozs7QUFJRixVQUFNLFFBQVEsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQzs7O0FBR3RELFVBQU0sZUFBZSxHQUFHLFlBQVksQ0FBQyxlQUFlLENBQUM7QUFDckQsVUFBSSxlQUFlLENBQUMsTUFBTSxHQUFHLEtBQUssQ0FBQyxNQUFNLEVBQUUsTUFBTSxJQUFJLEtBQUssc0JBQW9CLGVBQWUsQ0FBQyxNQUFNLFdBQVEsQ0FBQzs7O0FBSTdHLHFCQUFlLENBQUMsT0FBTyxDQUFDLFVBQUMsQ0FBQyxFQUFFLENBQUMsRUFBSztBQUNoQyxZQUFJLEtBQUssQ0FBQyxDQUFDLENBQUMsRUFBRTtBQUNaLGtCQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO1NBQ3hCLE1BQU07OztBQUdMLGtCQUFRLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBRSxDQUFDO1NBQ2xCO09BQ0YsQ0FBQyxDQUFDOzs7QUFHSCxjQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQzs7Ozs7OztBQU96QyxhQUFPLFFBQVEsQ0FBQztLQUNqQjs7O1dBRXFCLGdDQUFDLFFBQVEsRUFBRSxZQUFZLEVBQUU7O0FBRTdDLFVBQU0sV0FBVyxHQUFHLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLEVBQUUsQ0FBQyxDQUFDOzs7Ozs7Ozs7OztBQVcxRCxVQUFNLEtBQUssR0FBRyxPQUFPLENBQUMsb0JBQW9CLENBQ3hDO0FBQ0UscUJBQWEsRUFBRSxRQUFRLENBQUMsVUFBVSxDQUFDOztBQUVuQyxzQkFBYyxFQUFFO0FBQ2QsYUFBRyxFQUFFLENBQUMsV0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXLENBQUMsQ0FBQztTQUN4QztPQUNGOztBQUVELGFBQU8sSUFBSSxDQUFDLEtBQUssS0FBSyxXQUFXLEdBQUcsSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQ3RELENBQUM7O0FBRUYsVUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7OztBQUd0RCxjQUFRLENBQUMsT0FBTyxDQUFDLEdBQUcsWUFBWSxDQUFDLE9BQU8sQ0FBQzs7QUFFekMsY0FBUSxDQUFDLE1BQU0sQ0FBQyxHQUFHLEtBQUssQ0FBQyxDQUFDLENBQUMsQ0FBQztBQUM1QixjQUFRLENBQUMsU0FBUyxDQUFDLEdBQUcsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDO0FBQy9CLGNBQVEsQ0FBQyxTQUFTLENBQUMsR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7Ozs7OztBQU0vQixhQUFPLFFBQVEsQ0FBQztLQUNqQjs7O1dBMVF5QiwrQkFBYTtVQUFaLEtBQUsseURBQUcsRUFBRTs7QUFDbkMsYUFBTywyQkFBYyxhQUFhLEVBQUUsQ0FBQyxJQUFJLENBQUMsS0FBSyxFQUFFLEVBQUUsR0FBRyxFQUFFLENBQUMsRUFBRSxPQUFPLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxNQUFNLEVBQUUsQ0FBQztLQUNuRjs7O1dBaUJ1QixxQkFBQyxRQUFRLEVBQUUsT0FBTztVQVFsQyxTQUFTOzs7O0FBQVQscUJBQVMsR0FBRztBQUNoQixxQkFBTyxFQUFFLFFBQVE7YUFDbEI7Ozs7QUFJRCx1Q0FBYyxNQUFNLENBQUM7QUFDbkIsNEJBQWMsRUFBRSxRQUFRLENBQUMsTUFBTSxDQUFDO0FBQ2hDLDRCQUFjLEVBQUUsUUFBUSxDQUFDLE1BQU0sQ0FBQzthQUNqQyxFQUFFO0FBQ0Qsa0JBQUksRUFBRTtBQUNKLHVCQUFPLEVBQUUsUUFBUTtlQUNsQjthQUNGLEVBQUU7QUFDRCxvQkFBTSxFQUFFLElBQUk7YUFDYixDQUFDLENBQUM7Ozs7QUFJSCx1Q0FBYyxNQUFNLENBQUM7QUFDbkIsb0JBQU0sRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7YUFDdkIsRUFBRTtBQUNELGtCQUFJLEVBQUU7QUFDSixzQkFBTSxFQUFFO0FBQ04seUJBQU8sRUFBRSxFQUFFO0FBQ1gsMkJBQVMsRUFBRSxJQUFJO0FBQ2YseUJBQU8sRUFBRSxJQUFJLEVBQ2Q7ZUFDRjthQUNGLENBQUMsQ0FBQzs7Ozs7OztLQUNKOzs7O1dBRTBCLDhCQUFDLEtBQUssRUFBcUI7VUFBbkIsVUFBVSx5REFBRyxJQUFJOzs7QUFFbEQsZ0JBQVUsR0FBRyxVQUFVLEtBQUssSUFBSSxnQ0FBbUIsVUFBVSxDQUFDOzs7QUFHOUQsVUFBTSxHQUFHLEdBQUcsVUFBVSxDQUFDLElBQUksQ0FDekIsS0FBSyxFQUFFO0FBQ0wsY0FBTSxFQUFFO0FBQ04sYUFBRyxFQUFFLENBQUM7QUFDTix5QkFBZSxFQUFFLENBQUM7QUFDbEIsc0JBQVksRUFBRSxDQUFDO1NBQ2hCO09BQ0YsQ0FDRixDQUFDOztBQUVGLFVBQUksQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLEVBQUUsTUFBTSxJQUFJLEtBQUssQ0FBQyxzQ0FBc0MsQ0FBQyxDQUFDOztBQUUxRSxVQUFNLElBQUksR0FBRyxFQUFFLENBQUM7QUFDaEIsU0FBRyxDQUFDLE9BQU8sQ0FBQyxVQUFDLEdBQUcsRUFBSztBQUNuQixZQUFNLENBQUMsR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEVBQUUsSUFBSSxDQUFDLEdBQUcsRUFBRSxTQUFPLEdBQUcsQ0FBQyxPQUFPLENBQUMsRUFBRSxRQUFLLENBQUM7QUFDN0QsWUFBSSxDQUFDLElBQUksQ0FBSSxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssU0FBSSxDQUFDLENBQUcsQ0FBQztPQUN4QyxDQUFDLENBQUM7O0FBRUgsYUFBTyxJQUFJLENBQUM7S0FDYjs7O1NBM0ZrQixPQUFPOzs7cUJBQVAsT0FBTzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzhCQ1pSLGlCQUFpQjs7OztxQkFDWixRQUFROzt5QkFDWCxlQUFlOzs7O0FBRXJDLElBQU0sUUFBUSxHQUFHLHdDQUF3Qzs7SUFFcEMsUUFBUTtBQUNmLFdBRE8sUUFBUSxDQUNkLElBQUksRUFBRSxNQUFNLEVBQUU7MEJBRFIsUUFBUTs7QUFFekIsUUFBSSxDQUFDLElBQUksR0FBRyxJQUFJO0FBQ2hCLFFBQUksQ0FBQyxNQUFNLEdBQUcsTUFBTTtHQUNyQjs7OztlQUprQixRQUFROztXQU9WLG9CQUFDLFdBQVU7VUFDdEIsT0FBTyxFQUVMLEdBQUc7Ozs7QUFGTCxtQkFBTyx5QkFBdUIsSUFBSSxDQUFDLE1BQU0sNkJBQXdCLHFCQUFTLFdBQVUsRUFBRSxFQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUMsQ0FBQzs7OzRDQUV4RixJQUFJLENBQUMsV0FBVyxDQUM5QixnQkFBZ0IsRUFDaEIsT0FBTyxDQUNSOzs7QUFIRyxlQUFHO2dEQUlBLEVBQUMsUUFBUSxFQUFFLEdBQUcsRUFBRSxVQUFVLEVBQUUsT0FBTyxFQUFDOzs7OztrQkFFckMsTUFBTSxDQUFDLE1BQU0sQ0FBQyx1QkFBVSxLQUFLLGdCQUFHLEVBQUUsRUFBQyxVQUFVLEVBQUUsT0FBTyxFQUFDLENBQUM7Ozs7Ozs7S0FFakU7OztXQUVpQixxQkFBQyxNQUFNLEVBQUUsSUFBSTtVQUV6QixVQUFVLEVBU1YsR0FBRzs7OztBQVRILHNCQUFVLEdBQUc7QUFDZixvQkFBTSxFQUFFLE1BQU07QUFDZCxpQkFBRyxFQUFLLFFBQVEsU0FBSSxNQUFRO0FBQzVCLGtCQUFJLEVBQUUsSUFBSTthQUNYOzs7QUFFRCxrQkFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQzs7Ozs0Q0FHcEIsaUNBQVEsVUFBVSxDQUFDOzs7QUFBL0IsZUFBRztnREFFQSxHQUFHOzs7Ozs7O0tBQ1g7OztXQUVpQixxQkFBQyxlQUFlO1VBRTVCLFVBQVUsRUFVVixHQUFHOzs7O0FBVkgsc0JBQVUsR0FBRztBQUNmLG9CQUFNLEVBQUUsTUFBTTtBQUNkLGlCQUFHLEVBQUssUUFBUSxpQkFBYzthQUMvQjs7O0FBRUQsa0JBQU0sQ0FBQyxNQUFNLENBQUMsVUFBVSxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUM7Ozs0Q0FFWixJQUFJLENBQUMsNEJBQTRCLENBQUMsZUFBZSxDQUFDOzs7QUFBMUUsc0JBQVUsQ0FBQyxJQUFJOzs0Q0FHQyxpQ0FBUSxVQUFVLENBQUM7OztBQUEvQixlQUFHO2dEQUVBLEdBQUc7Ozs7Ozs7S0FDWDs7O1dBRWtDLHNDQUFDLGVBQWU7VUFnQjdDLGtCQUFrQixrRkFFYixJQUFJLHVGQUVGLENBQUMsRUFZTixJQUFJLHVGQVVHLFNBQVMsdUZBT1AsR0FBRyxFQVdkLGNBQWM7Ozs7O0FBNUNkLDhCQUFrQixHQUFHLEVBQUU7Ozs7O3dCQUVWLGVBQWU7Ozs7Ozs7O0FBQXZCLGdCQUFJOzs7Ozs7O0FBRVgsOEJBQWMsSUFBSSxDQUFDLFVBQVUsMkhBQUU7QUFBdEIsZUFBQzs7O0FBRVIsa0JBQUksQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHLEVBQUUsQ0FBQyxDQUFDLEtBQUssR0FBRyxHQUFHO2FBQ2pDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFRCw4QkFBa0IsSUFBSSxtQkFBbUI7QUFDekMsOEJBQWtCLG1CQUFpQixJQUFJLENBQUMsUUFBUSxnQkFBYTs7Ozs7O0FBTXpELGdCQUFJLEdBQUcsSUFBSSxDQUFDLFVBQVUsQ0FBQyxDQUFDLENBQUM7O2tCQUN6QixJQUFJLENBQUMsMEJBQTBCLEtBQUssRUFBRSxJQUFJLElBQUksQ0FBQyx3QkFBd0IsS0FBSyxFQUFFOzs7Ozs7QUFFaEYsOEJBQWtCLElBQUksZ0NBQWdDO0FBQ3RELDhCQUFrQixxQkFBbUIsSUFBSSxDQUFDLEtBQUssa0JBQWU7Ozs7OztBQUc5RCw4QkFBa0IsSUFBSSxnQ0FBZ0M7Ozs7Ozs7eUJBR2hDLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUE1QixxQkFBUzs7O0FBRWhCLHFCQUFTLENBQUMsaUJBQWlCLEdBQUcsU0FBUyxDQUFDLEtBQUs7QUFDN0MsbUJBQU8sU0FBUyxDQUFDLEtBQUs7OztBQUd0Qiw4QkFBa0IsSUFBSSxpQkFBaUI7Ozs7O0FBQ3ZDLDhCQUFnQixNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQywySEFBRTtBQUEvQixpQkFBRzs7QUFDVixnQ0FBa0IsVUFBUSxHQUFHLFNBQUksU0FBUyxDQUFDLEdBQUcsQ0FBQyxVQUFLLEdBQUcsTUFBRzthQUMzRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCw4QkFBa0IsSUFBSSxrQkFBa0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJNUMsOEJBQWtCLElBQUksb0JBQW9COzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFJeEMsMEJBQWMscUNBRVIsSUFBSSxDQUFDLE1BQU0sdUJBQ25CLGtCQUFrQjtnREFLYixjQUFjOzs7Ozs7O0tBQ3RCOzs7U0ExSGtCLFFBQVE7OztxQkFBUixRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNOUixTQUFTO1dBQVQsU0FBUzswQkFBVCxTQUFTOzs7ZUFBVCxTQUFTOztXQUNmLGVBQUMsQ0FBQyxFQUFFO0FBQ2YsVUFBSSxHQUFHLEdBQUcsRUFBRTs7QUFFWixVQUFJLENBQUMsWUFBWSxLQUFLLEVBQUU7QUFDdEIsV0FBRyxDQUFDLE9BQU8sR0FBRyxDQUFDLENBQUMsT0FBTztBQUN2QixXQUFHLENBQUMsSUFBSSxHQUFHLENBQUMsQ0FBQyxJQUFJO0FBQ2pCLFdBQUcsQ0FBQyxRQUFRLEdBQUcsQ0FBQyxDQUFDLFFBQVE7QUFDekIsV0FBRyxDQUFDLFVBQVUsR0FBRyxDQUFDLENBQUMsVUFBVTtBQUM3QixXQUFHLENBQUMsWUFBWSxHQUFHLENBQUMsQ0FBQyxZQUFZO0FBQ2pDLFdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxDQUFDLEtBQUs7T0FDcEIsTUFBTTtBQUNMLFdBQUcsR0FBRyxDQUFDO09BQ1I7O0FBRUQsYUFBTyxHQUFHO0tBQ1g7OztTQWhCa0IsU0FBUzs7O3FCQUFULFNBQVM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3VCQ0FGLFNBQVM7O0lBRXhCLGVBQWU7V0FBZixlQUFlOzBCQUFmLGVBQWU7OztlQUFmLGVBQWU7O1dBQ1QsYUFBQyxJQUFJLEVBQUUsVUFBVTtVQUMxQixNQUFNLEVBQ04sRUFBRTs7Ozs7NENBRGEscUJBQVksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLEVBQUUsRUFBRSxlQUFlLEVBQUUsSUFBSSxFQUFFLENBQUM7OztBQUF2RSxrQkFBTTtBQUNOLGNBQUUsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7Z0RBQzVCLEVBQUUsQ0FBQyxVQUFVLENBQUMsVUFBVSxDQUFDOzs7Ozs7O0tBQ2pDOzs7U0FMVSxlQUFlOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztxQkNGVixPQUFPOzs7O3NCQUNOLFFBQVE7Ozs7SUFFTixLQUFLO0FBQ1osV0FETyxLQUFLLENBQ1gsT0FBTyxFQUFFOzBCQURILEtBQUs7OztBQUd0QixRQUFJLENBQUMsSUFBSSxHQUFHLG1CQUFNLFVBQVUsQ0FBQyxPQUFPLENBQUMsQ0FBQzs7O0FBR3RDLFFBQU0sWUFBWSxHQUFHLEVBQUUsa0JBQWtCLEVBQUUsSUFBSSxFQUFFLENBQUM7QUFDbEQsVUFBTSxDQUFDLE1BQU0sQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDLENBQUM7QUFDckMsUUFBSSxDQUFDLFNBQVMsR0FBRyxtQkFBTSxVQUFVLENBQUMsWUFBWSxDQUFDLENBQUM7R0FDakQ7O2VBVGtCLEtBQUs7O1dBV1AscUJBQUMsS0FBSyxFQUFFLFNBQVM7VUFBRSxPQUFPLHlEQUFHLEdBQUc7VUFFekMsV0FBVyxFQUNYLFNBQVMsRUFDVCxhQUFhLEVBRWIsR0FBRzs7OztBQUpILHVCQUFXLEdBQUcsT0FBTztBQUNyQixxQkFBUyxhQUFXLEtBQUs7QUFDekIseUJBQWEsR0FBRyxTQUFTLGNBQVksU0FBUyxHQUFLLEVBQUU7OzRDQUV6QyxJQUFJLENBQUMsS0FBSyxhQUFXLFdBQVcsU0FBSSxTQUFTLFNBQUksYUFBYSxDQUFHOzs7QUFBN0UsZUFBRztnREFHRixJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUM7Ozs7Ozs7S0FDdkM7Ozs7Ozs7O1dBVUssZUFBQyxHQUFHLEVBQUU7OztBQUdWLGFBQU8sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUNqQixJQUFJLENBQ0gsVUFBQyxHQUFHO2VBQUssSUFBSSxPQUFPLENBQ2hCLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSzs7QUFFbkIsYUFBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLEVBQUUsVUFBQyxDQUFDLEVBQUUsR0FBRyxFQUFLOztBQUV6QixlQUFHLENBQUMsT0FBTyxFQUFFO0FBQ2IsZ0JBQUksQ0FBQyxFQUFFO0FBQ0wsb0JBQU0sQ0FBQyxDQUFDLENBQUM7YUFDVixNQUFNLE9BQU8sQ0FBQyxHQUFHLENBQUM7V0FDcEIsQ0FBQztTQUNILENBQ0Y7T0FBQSxDQUNKLFNBQ0ssQ0FBQyxVQUFDLENBQUMsRUFBSztBQUNaLGNBQU0sQ0FBQyxDQUFDO09BQ1QsQ0FBQyxDQUFDO0tBQ047OztXQUVrQixzQkFBQyxHQUFHO1VBQ2YsR0FBRzs7Ozs7NENBQVMsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNGLEdBQUcsQ0FBQyxRQUFROzs7Ozs7O0tBQ3BCOzs7Ozs7Ozs7O1dBUWlCLHFCQUFDLEtBQUs7VUFBRSxJQUFJLHlEQUFHLEVBQUU7VUFBRSxPQUFPLHlEQUFHLEVBQUU7O1VBSTNDLEdBQUcsRUFFRCxHQUFHLGtGQVdFLENBQUMsdUZBUU4sR0FBRzs7Ozs7QUFyQkwsZUFBRyxvQkFBa0IsS0FBSztBQUV4QixlQUFHLEdBQUcsSUFBSSxHQUFHLEVBQUU7Ozs7OztBQUNyQiw2QkFBZ0IsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsdUhBQUU7QUFBeEIsZUFBQzs7QUFDVixrQkFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLEtBQUssSUFBSSxFQUFFO0FBQ3BCLG1CQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsRUFBRSxNQUFNLENBQUMsQ0FBQztlQUNwQixNQUFNLElBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQyxJQUFJLEtBQUssTUFBTSxFQUFFOztBQUU5QyxtQkFBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLFFBQU0sS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsT0FBSSxDQUFDO2VBQzlDLE1BQU07QUFDTCxtQkFBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQUssbUJBQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFHLENBQUM7ZUFDeEM7YUFDRjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0QsOEJBQWdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLDJIQUFFO0FBQTNCLGVBQUM7O0FBQ1YsaUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLEdBQUcsTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDO2FBQ3ZEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFFRCxlQUFHLFdBQVMsNkJBQUksR0FBRyxDQUFDLElBQUksRUFBRSxHQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBSyxDQUFDOztBQUUzQyxlQUFHLGlCQUFlLDZCQUFJLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQUssQ0FBQzs7OzRDQUVqQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0YsR0FBRyxDQUFDLFFBQVE7Ozs7Ozs7S0FDcEI7Ozs7Ozs7Ozs7O1dBU2lCLHFCQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLE9BQU87VUFDekMsR0FBRyxFQUVELE9BQU8sdUZBSUYsQ0FBQyx1RkFPTixHQUFHOzs7OztBQWJMLGVBQUcsZUFBYSxLQUFLO0FBRW5CLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBQ2xCLDhCQUFnQixNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQywySEFBRTtBQUF4QixlQUFDOztBQUNWLHFCQUFPLENBQUMsSUFBSSxDQUFJLENBQUMsU0FBSSxtQkFBTSxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUcsQ0FBQzthQUMvQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0QsOEJBQWdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLDJIQUFFO0FBQTNCLGVBQUM7O0FBQ1YscUJBQU8sQ0FBQyxJQUFJLENBQUksQ0FBQyxTQUFJLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBRyxDQUFDO2FBQ3BDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELGVBQUcsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFDOztBQUV6QixlQUFHLGdCQUFjLE1BQU0sTUFBRyxDQUFDOzs7NENBRVQsSUFBSSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUEzQixlQUFHO2dEQUNGLEdBQUc7Ozs7Ozs7S0FDWDs7Ozs7V0FHZ0Isb0JBQUMsR0FBRztVQUNiLFFBQVEsRUFHTixHQUFHOzs7O0FBSEwsb0JBQVEsR0FBRyxJQUFJLENBQUMsSUFBSTs7QUFDMUIsZ0JBQUksQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQzs7OzRDQUVQLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBM0IsZUFBRztnREFDRixHQUFHOzs7OztBQUVWLGdCQUFJLENBQUMsSUFBSSxHQUFHLFFBQVEsQ0FBQzs7Ozs7Ozs7S0FFeEI7OztXQUVzQjs7Ozs7NENBQ2YsSUFBSSxDQUFDLEtBQUssQ0FBQyxvQkFBb0IsQ0FBQzs7Ozs7OztLQUN2Qzs7O1dBRVk7Ozs7OzRDQUNMLElBQUksQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUFDOzs7Ozs7O0tBQzVCOzs7V0FFYzs7Ozs7NENBQ1AsSUFBSSxDQUFDLEtBQUssQ0FBQyxXQUFXLENBQUM7Ozs7Ozs7S0FDOUI7OztXQUVjLHdCQUFDLEdBQUcsRUFBa0Q7OztVQUFoRCxRQUFRLHlEQUFHLFVBQUMsTUFBTSxFQUFLLEVBQUU7VUFBRSxPQUFPLHlEQUFHLFVBQUMsQ0FBQyxFQUFLLEVBQUU7O0FBQ2pFLGFBQU8sSUFBSSxDQUFDLE1BQU0sRUFBRSxDQUNqQixJQUFJLENBQ0gsVUFBQyxHQUFHO2VBQUssSUFBSSxPQUFPLENBQ2hCLG9CQUFPLE9BQU8sRUFBRSxNQUFNOzs7OztBQUVwQixtQkFBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FDWCxFQUFFLENBQUMsUUFBUSxFQUNWLFVBQUMsTUFBTSxFQUFLO0FBQ1YscUJBQUcsQ0FBQyxLQUFLLEVBQUU7QUFDWCwwQkFBUSxDQUFDLE1BQU0sQ0FBQztBQUNoQixxQkFBRyxDQUFDLE1BQU0sRUFBRTtpQkFDYixDQUFDLENBQ0gsRUFBRSxDQUFDLE9BQU8sRUFBRSxVQUFDLENBQUMsRUFBSztBQUNsQix5QkFBTyxDQUFDLENBQUMsQ0FBQztpQkFDWCxDQUFDLENBQ0QsRUFBRSxDQUFDLEtBQUssRUFBRSxZQUFNO0FBQ2YscUJBQUcsQ0FBQyxPQUFPLEVBQUU7QUFDYix5QkFBTyxFQUFFO2lCQUNWLENBQUM7Ozs7Ozs7U0FDTCxDQUNGO09BQUEsQ0FDSixTQUNLLENBQUMsVUFBQyxDQUFDLEVBQUs7QUFDWixjQUFNLENBQUMsQ0FBQztPQUNULENBQUMsQ0FBQztLQUNOOzs7V0FFTSxrQkFBRzs7O0FBQ1IsYUFBTyxJQUFJLE9BQU8sQ0FDaEIsVUFBQyxPQUFPLEVBQUUsTUFBTSxFQUFLOztBQUVuQixlQUFLLElBQUksQ0FBQyxhQUFhLENBQUMsVUFBQyxDQUFDLEVBQUUsR0FBRyxFQUFLO0FBQ2xDLGNBQUksQ0FBQyxFQUFFO0FBQ0wsa0JBQU0sQ0FBQyxDQUFDLENBQUMsQ0FBQztXQUNYLE1BQU07QUFDTCxtQkFBTyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1dBQ2Q7U0FDRixDQUFDLENBQUM7T0FDSixDQUNGLFNBQ08sQ0FDSixVQUFDLENBQUMsRUFBSztBQUNMLGNBQU0sQ0FBQyxDQUFDO09BQ1QsQ0FDRixDQUFDO0tBQ0w7OztXQXRLaUIsb0JBQUMsSUFBSSxFQUFFO0FBQ3ZCLGFBQU8seUJBQU8sSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQyxDQUFDO0tBQ2pFOzs7U0F6QmtCLEtBQUs7OztxQkFBTCxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0lDSEwsTUFBTTtBQUNiLFdBRE8sTUFBTSxDQUNaLFVBQVUsRUFBRTswQkFETixNQUFNOztBQUV2QixRQUFJLENBQUMsVUFBVSxHQUFHLFVBQVU7QUFDNUIsUUFBSSxDQUFDLGFBQWEsR0FBRyxJQUFJO0FBQ3pCLFFBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSTtBQUNwQixRQUFJLENBQUMsV0FBVyxHQUFHLElBQUk7QUFDdkIsUUFBSSxDQUFDLEtBQUssR0FBRyxDQUFDO0FBQ2QsUUFBSSxDQUFDLFdBQVcsR0FBRyxDQUFDO0dBQ3JCOztlQVJrQixNQUFNOztXQVVaLGdCQUFDLEdBQUc7Ozs7a0JBRVgsSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxLQUFLLENBQUM7Ozs7O2lCQUNoQyxJQUFJLENBQUMsYUFBYTs7Ozs7OzRDQUNkLElBQUksQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQzs7O2lCQUcxQyxJQUFJLENBQUMsUUFBUTs7Ozs7OzRDQUNULElBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDOzs7QUFFMUIsZ0JBQUksQ0FBQyxLQUFLLEVBQUU7O0FBRVosZ0JBQUksSUFBSSxDQUFDLEtBQUssR0FBRyxJQUFJLENBQUMsVUFBVSxLQUFLLENBQUMsRUFBRTtBQUN0QyxrQkFBSSxDQUFDLEtBQUssRUFBRTtBQUNaLGtCQUFJLENBQUMsV0FBVyxFQUFFO2FBQ25COzs7Ozs7O0tBQ0Y7OztXQUNLLGlCQUFHO0FBQ1AsVUFBSSxJQUFJLENBQUMsV0FBVyxFQUFFO0FBQ3BCLFlBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQztPQUNuQztLQUNGOzs7U0EvQmtCLE1BQU07OztxQkFBTixNQUFNOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7cUJDQUwsU0FBUzs7Ozs0QkFDVixlQUFlOzsyQkFDZixnQkFBZ0I7O3NCQUNsQixRQUFROzs7O0lBRU4sTUFBTTtBQUNiLFdBRE8sTUFBTSxHQUNWOzBCQURJLE1BQU07O0FBRXZCLFFBQUksQ0FBQyxNQUFNLEdBQUcsRUFBRTtBQUNoQixRQUFJLENBQUMsU0FBUyxHQUFHLEVBQUU7QUFDbkIsUUFBSSxDQUFDLFFBQVEsR0FBRyxJQUFJO0dBQ3JCOzs7O2VBTGtCLE1BQU07O1dBUVgsdUJBQUMsT0FBTyxFQUFFO0FBQ3RCLFVBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSSxRQUFRLENBQUMsT0FBTyxDQUFDO0FBQ3JDLFVBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7S0FDbkM7OztXQUVXOzs7VUFBQyxJQUFJLHlEQUFHLEVBQUU7VUFBRSxFQUFFLHlEQUFHOzs7Ozs7OztPQUFjO1VBQ3JDLEdBQUcsRUFPRCxHQUFHOzs7O0FBUEwsZUFBRyxHQUFHO0FBQ1IscUJBQU8sRUFBRSwwQkFBUTthQUNsQjs7QUFFRCxnQkFBSSxDQUFDLGFBQWEsQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDOzs7OzRDQUdiLEVBQUUsRUFBRTs7O0FBQWhCLGVBQUc7O0FBRVAsa0JBQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO0FBQ2pCLGtCQUFJLEVBQUUsU0FBUztBQUNmLG1CQUFLLEVBQUUsSUFBSTtBQUNYLG9CQUFNLEVBQUUsR0FBRzthQUNaLENBQUM7Ozs7Ozs7O0FBRUYsa0JBQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO0FBQ2pCLGtCQUFJLEVBQUUsT0FBTztBQUNiLG1CQUFLLEVBQUUsSUFBSTtBQUNYLG9CQUFNLEVBQUUsbUJBQVUsS0FBSyxnQkFBRzthQUMzQixDQUFDOzs7Ozs7QUFHRixnQkFBSSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7QUFDOUIsb0JBQU0sQ0FBQyxNQUFNLENBQUMsR0FBRyxFQUFFO0FBQ2pCLHdCQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNO2VBQy9CLENBQUM7YUFDSDs7QUFFRCxlQUFHLENBQUMsU0FBUyxHQUFHLElBQUksSUFBSSxFQUFFOztBQUUxQiw4QkFBSyxNQUFNLENBQUMsR0FBRyxDQUFDOzs7QUFHaEIsZ0JBQUksQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs7S0FFeEI7Ozs7OztXQUlxQix5QkFBQyxHQUFHLEVBQUUsRUFBRTtVQUV0QixHQUFHLEVBR0QsR0FBRzs7Ozs7NENBSkUsR0FBRyxDQUFDLE9BQU8sRUFBRTs7Ozs7Ozs7OzRDQUNSLEdBQUcsQ0FBQyxJQUFJLEVBQUU7OztBQUF0QixlQUFHOzs7NENBR1csRUFBRSxDQUFDLEdBQUcsQ0FBQzs7O0FBQW5CLGVBQUc7O0FBQ1AsZ0JBQUksQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDOzs7Ozs7OztBQUVsQixnQkFBSSxDQUFDLE1BQU0sZ0JBQUc7Ozs7Ozs7QUFHbEIsZUFBRyxDQUFDLEtBQUssRUFBRTs7Ozs7OztLQUNaOzs7V0FFUSxrQkFBQyxTQUFTLEVBQUU7QUFDbkIsVUFBSSxDQUFDLFFBQVEsQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDO0tBQ2pDOzs7V0FFTSxnQkFBQyxTQUFTLEVBQUU7QUFDakIsVUFBSSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsbUJBQVUsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFDO0tBQ2hEOzs7V0FFWSx3QkFBRztBQUNkLFVBQUksUUFBUSxHQUFHLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFdBQUM7ZUFBSSxDQUFDLENBQUMsWUFBWSxFQUFFO09BQUEsQ0FBQztBQUN6RCxVQUFJLFFBQVEsR0FBRyxLQUFLOzs7Ozs7QUFDcEIsNkJBQWdCLElBQUksQ0FBQyxNQUFNLDhIQUFFO2NBQXBCLEdBQUc7O0FBQ1YsY0FBSSxHQUFHLENBQUMsSUFBSSxLQUFLLE9BQU8sRUFBRTtBQUN4QixvQkFBUSxHQUFHLElBQUk7QUFDZixrQkFBSztXQUNOO1NBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7QUFDRCxhQUFPLFFBQVEsSUFBSSxRQUFRO0tBQzVCOzs7V0FFTyxtQkFBRzs7QUFFVCxVQUFJLElBQUksQ0FBQyxZQUFZLEVBQUUsRUFBRTtBQUN2QixjQUFNLElBQUkscUJBQU8sS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7T0FDcEM7QUFDRCxhQUFPLElBQUksQ0FBQyxNQUFNO0tBQ25COzs7U0E3RmtCLE1BQU07OztxQkFBTixNQUFNOztJQWdHckIsUUFBUTtBQUNBLFdBRFIsUUFBUSxDQUNDLE9BQU8sRUFBRTswQkFEbEIsUUFBUTs7QUFFVixRQUFJLENBQUMsTUFBTSxHQUFHO0FBQ1osV0FBSyxFQUFFLENBQUM7QUFDUixhQUFPLEVBQUUsQ0FBQztBQUNWLFdBQUssRUFBRSxDQUFDO0FBQ1IsYUFBTyxFQUFFLE9BQU87S0FDakI7QUFDRCxRQUFJLENBQUMsU0FBUyxHQUFHLElBQUk7R0FDdEI7O2VBVEcsUUFBUTs7V0FXSixpQkFBQyxTQUFTLEVBQUU7QUFDbEIsVUFBSSxTQUFTLEVBQUU7QUFDYixZQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUM7T0FDMUI7QUFDRCxVQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRTtBQUNyQixVQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssRUFBRTtLQUNwQjs7O1dBRUssZUFBQyxTQUFTLEVBQUU7O0FBRWhCLFVBQUksSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssSUFBSSxDQUFDLFNBQVMsQ0FBQyxTQUFTLENBQUMsRUFBRTtBQUNoRSxZQUFJLFNBQVMsSUFBSSxTQUFTLEtBQUssRUFBRSxJQUFJLFNBQVMsS0FBSyxFQUFFLEVBQUU7QUFDckQsY0FBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsS0FBSyxDQUFDO0FBQzFCLGNBQUksQ0FBQyxTQUFTLEdBQUcsU0FBUztTQUMzQjtPQUNGO0FBQ0QsVUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7QUFDbkIsVUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7S0FDcEI7OztXQUVHLGFBQUMsU0FBUyxFQUFFLFNBQVMsMENBQTBDO0FBQ2pFLFVBQUksR0FBRyxHQUFHO0FBQ1IsZUFBTyxFQUFFLFNBQVM7QUFDbEIsZUFBTyxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTztBQUM1QixlQUFPLEVBQUUsU0FBUztBQUNsQixpQkFBUyxFQUFFLElBQUksSUFBSSxFQUFFO09BQ3RCO0FBQ0Qsd0JBQUssTUFBTSxDQUFDLEdBQUcsQ0FBQztLQUNqQjs7O1dBRVksd0JBQUc7QUFDZCxhQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSztLQUN6Qjs7O1NBM0NHLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7c0JDckdBLFFBQVE7Ozs7Ozs7Ozs7Ozs7cUJBVVAsU0FBZSxVQUFVLENBQ3RDLEdBQUcsRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFTLE9BQU8sRUFBRSxPQUFPO01BQTlCLEtBQUssZ0JBQUwsS0FBSyxHQUFHLElBQUk7TUFFaEIsWUFBWSxFQUNaLFlBQVksRUFFWixjQUFjOzs7Ozs7QUFIZCxvQkFBWSxHQUFHLEVBQUU7QUFDakIsb0JBQVksR0FBRyxFQUFFOztBQUVqQixzQkFBYyxHQUFHLFNBQWpCLGNBQWMsQ0FBSSxJQUFJLEVBQUUsT0FBTyxFQUFLO0FBQ3hDLGNBQU0sUUFBUSxHQUFHLG9CQUFFLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs7QUFFbkMsY0FBSSxvQkFBRSxXQUFXLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FBQyxDQUFDLEtBQUssS0FBSyxFQUFFO0FBQzlDLG1CQUFPLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQztXQUMxQjs7QUFFRCxpQkFBTyxRQUFRLENBQUM7U0FDakI7OztBQUdELFdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBQyxJQUFJLEVBQUs7QUFDcEIsc0JBQVksQ0FBQyxJQUFJLENBQUM7QUFDaEIsa0JBQU0sRUFBRSxjQUFjLENBQUMsSUFBSSxFQUFFLEtBQUssQ0FBQztBQUNuQyxjQUFFLEVBQUUsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUNmLGlCQUFLLEVBQUU7Ozs7O0FBS0wsa0JBQUksRUFBRSxLQUFLO2FBQ1o7V0FDRixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7O0FBRUgsV0FBRyxDQUFDLE9BQU8sQ0FBQyxVQUFDLElBQUksRUFBSztBQUNwQixzQkFBWSxDQUFDLElBQUksQ0FBQztBQUNoQixrQkFBTSxFQUFFLGNBQWMsQ0FBQyxJQUFJLEVBQUUsS0FBSyxDQUFDO0FBQ25DLGNBQUUsRUFBRSxJQUFJLENBQUMsS0FBSyxDQUFDO0FBQ2YsaUJBQUssRUFBRTs7Ozs7QUFLTCxrQkFBSSxFQUFFLEtBQUs7YUFDWjtXQUNGLENBQUMsQ0FBQztTQUNKLENBQUMsQ0FBQzs7O0FBR0gsb0JBQVksQ0FBQyxPQUFPLENBQUMsVUFBQyxPQUFPLEVBQUs7QUFDaEMsc0JBQVksQ0FBQyxPQUFPLENBQUMsVUFBQyxPQUFPLEVBQUs7QUFDaEMsZ0JBQUksb0JBQUUsT0FBTyxDQUFDLE9BQU8sQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLE1BQU0sQ0FBQyxFQUFFOztBQUU3QyxxQkFBTyxDQUFDLEtBQUssQ0FBQyxJQUFJLEdBQUcsSUFBSSxDQUFDO0FBQzFCLHFCQUFPLENBQUMsS0FBSyxDQUFDLElBQUksR0FBRyxJQUFJLENBQUM7YUFDM0I7V0FDRixDQUFDLENBQUM7U0FDSixDQUFDLENBQUM7Ozs7d0NBR0csT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLG9CQUFPLElBQUk7Ozs7c0JBQ3hDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUs7Ozs7OztnREFDckIsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQzs7Ozs7OztTQUV0QyxDQUFDLENBQUM7Ozs7d0NBR0csT0FBTyxDQUFDLEdBQUcsQ0FBQyxZQUFZLENBQUMsR0FBRyxDQUFDLG9CQUFPLElBQUk7Ozs7c0JBQ3hDLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxLQUFLLEtBQUs7Ozs7OztnREFDckIsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQzs7Ozs7OztTQUV0QyxDQUFDLENBQUM7Ozs7Ozs7Q0FDSjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUMvRW9CLFFBQVE7V0FBUixRQUFROzBCQUFSLFFBQVE7OztlQUFSLFFBQVE7Ozs7V0FFWixpQkFBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRTtBQUNyQyxVQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUU7QUFBRSxrQkFBVSxHQUFHLEVBQUU7T0FBRTtBQUNqRCxVQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztBQUM5QixVQUFJLEtBQUssR0FBRyxDQUFDO0FBQ2IsVUFBSSxHQUFHLEdBQUcsRUFBRTtBQUNaLFdBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ3pDLFlBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsWUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFDcEIsS0FBSyxJQUFJLENBQUM7QUFDZixZQUFJLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFDZixpQkFBTyxHQUFHLEdBQUcsVUFBVTtTQUN4QjtBQUNELFdBQUcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztPQUN0QjtBQUNELGFBQU8sSUFBSTtLQUNaOzs7OztXQUdXLGNBQUMsSUFBSSxFQUFFO0FBQ2pCLGFBQU8sa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUMsT0FBTyxDQUFDLFlBQVksRUFBRSxJQUFJLENBQUMsQ0FBQyxNQUFNO0tBQ25FOzs7V0FFZ0IsbUJBQUMsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUU7QUFDdEMsVUFBTSxHQUFHLEdBQUcsR0FBRzs7QUFFZixVQUFNLFNBQVMsR0FBRyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQUMsSUFBSSxFQUFFLE9BQU87ZUFBSyxJQUFJLEdBQUcsTUFBTSxDQUFDLE9BQU8sQ0FBQztPQUFBLEVBQUUsRUFBRSxDQUFDOztBQUU1RSxVQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQztBQUN0QyxVQUFJLE1BQU0sR0FBRyxFQUFFO0FBQ2YsVUFBSSxJQUFJLEdBQUcsRUFBRTs7O0FBR2IsVUFBSTtBQUNGLGlCQUFTLENBQUMsTUFBTSxDQUFDLFVBQUMsSUFBSSxFQUFFLE9BQU8sRUFBSzs7QUFFbEMsY0FBSSxRQUFRLENBQUMsSUFBSSxDQUFDLE9BQU8sQ0FBQyxHQUFHLE1BQU0sRUFBRSxNQUFNLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUM3RCxjQUFNLElBQUksR0FBRyxDQUFDLElBQUksS0FBSyxFQUFFLEdBQUcsSUFBSSxHQUFHLEdBQUcsR0FBRyxFQUFFLElBQUksT0FBTztBQUN0RCxjQUFJLFFBQVEsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEdBQUcsTUFBTSxFQUFFO0FBQ2hDLGtCQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQztBQUNqQixnQkFBSSxHQUFHLE9BQU87QUFDZCxtQkFBTyxFQUFFO1dBQ1YsTUFBTTtBQUNMLGdCQUFJLEdBQUcsSUFBSTtBQUNYLG1CQUFPLElBQUk7V0FDWjtTQUNGLEVBQUUsRUFBRSxDQUFDO09BQ1AsQ0FBQyxPQUFPLENBQUMsRUFBRTs7QUFFVixZQUFJLENBQUMsQ0FBQyxPQUFPLEtBQUssT0FBTyxFQUFFLE9BQU07T0FDbEM7O0FBRUQsWUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7O0FBRWpCLFdBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxJQUFJLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ3BDLGNBQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxNQUFNLENBQUMsQ0FBQyxDQUFDLEdBQUcsTUFBTSxDQUFDLENBQUMsQ0FBQyxHQUFHLEVBQUU7T0FDN0M7S0FDRjs7O1NBMURrQixRQUFROzs7cUJBQVIsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7NEJDQU4sZUFBZTs7MkJBQ2hCLGNBQWM7O0FBRTdCLElBQU0sSUFBSSxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLE1BQU0sRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7QUFDbEUsSUFBTSxPQUFPLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsU0FBUyxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOzs7QUFFeEUsSUFBTSxXQUFXLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsYUFBYSxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOztBQUNoRixJQUFNLGFBQWEsR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxlQUFlLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUM7OztBQUVwRixJQUFNLE9BQU8sR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxTQUFTLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUM7OztBQUUvRSxJQUFJLHFCQUFPLFFBQVEsRUFBRTtBQUNuQix1QkFBTyxPQUFPLENBQUMsU0FBUyxFQUFFLFlBQU07QUFDOUIsV0FBTyxPQUFPLENBQUMsSUFBSSxFQUFFO0dBQ3RCLENBQUMsQ0FBQztBQUNILHVCQUFPLE9BQU8scUJBQ0wsb0JBQW9CLEVBQUM7UUFDcEIsR0FBRzs7Ozs7MENBQVMsYUFBYSxDQUFDLGFBQWEsRUFBRSxDQUFDLFNBQVMsQ0FBQyxDQUN4RDs7QUFFRSxrQkFBTSxFQUFFO0FBQ04saUJBQUcsRUFBRTtBQUNILG9CQUFJLEVBQUMsZUFBZTtBQUNwQixvQkFBSSxFQUFDLGVBQWU7QUFDcEIsbUJBQUcsRUFBRSxjQUFjO0FBQ25CLG9CQUFJLEVBQUUsZUFBZTtlQUN0QjtBQUNELG1CQUFLLEVBQUUsRUFBQyxLQUFLLEVBQUUsRUFBQyxLQUFLLEVBQUUsZ0JBQWdCLEVBQUUsRUFBRSxFQUFFLGFBQWEsRUFBQyxFQUFDO2FBQzdEO1dBQ0YsRUFDRDtBQUNFLG9CQUFRLEVBQUU7QUFDUixpQkFBRyxFQUFDLENBQUM7QUFDTCxrQkFBSSxFQUFDLFdBQVc7QUFDaEIsa0JBQUksRUFBQyxXQUFXO0FBQ2hCLGlCQUFHLEVBQUUsVUFBVTtBQUNmLGtCQUFJLEVBQUUsV0FBVztBQUNqQixtQkFBSyxFQUFFLFFBQVE7YUFDaEI7V0FDRixDQUNGLENBQUMsQ0FBQyxPQUFPLEVBQUU7OztBQXZCTixhQUFHOzhDQXdCRixHQUFHOzs7Ozs7O0dBQ1gsRUFDRCxDQUFDOztBQUVILHVCQUFPLE9BQU8sQ0FBQyxtQkFBbUIsRUFBRTs7Ozs4Q0FDM0IsYUFBYSxDQUFDLElBQUksRUFBRTs7Ozs7OztHQUM1QixDQUFDLENBQUM7Q0FDSjs7QUFFRCxJQUFJLHFCQUFPLFFBQVEsRUFBRTtBQUNuQix1QkFBTyxTQUFTLENBQUMsU0FBUyxDQUFDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIChyZXEsIHJlcywgbmV4dCkgPT4ge1xyXG4vLyAgIHJlcy53cml0ZUhlYWQoMjAwKTtcclxuLy8gICByZXMuZW5kKGBIZWxsbyB3b3JsZCBmcm9tOiAke01ldGVvci5yZWxlYXNlfWApO1xyXG4vLyB9KTtcclxuXHJcbmltcG9ydCBmcyBmcm9tICdmcyc7XHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJztcclxuXHJcbi8vIFJlcXVpcmVzIG11bHRpcGFydHkgXHJcbmltcG9ydCBtdWx0aXBhcnR5IGZyb20gJ2Nvbm5lY3QtbXVsdGlwYXJ0eSc7XHJcbmltcG9ydCB7XHJcbiAgVXBsb2Fkc1xyXG59IGZyb20gJy4uLy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbnMnO1xyXG5sZXQgbXVsdGlwYXJ0eU1pZGRsZXdhcmUgPSBtdWx0aXBhcnR5KCk7XHJcblxyXG5jb25zdCByb3V0ZSA9ICcvdXBsb2FkL2ltYWdlJztcclxuXHJcbi8vIFdlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKCcvdXBsb2FkJywgZnVjLnVwbG9hZEZpbGUgKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIG11bHRpcGFydHlNaWRkbGV3YXJlKTtcclxuV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2Uocm91dGUsIChyZXEsIHJlc3ApID0+IHtcclxuICAvLyBkb24ndCBmb3JnZXQgdG8gZGVsZXRlIGFsbCByZXEuZmlsZXMgd2hlbiBkb25lXHJcblxyXG4gIGNvbnN0IHJlYWRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMucmVhZEZpbGUpO1xyXG4gIGNvbnN0IHdyaXRlciA9IE1ldGVvci53cmFwQXN5bmMoZnMud3JpdGVGaWxlKTtcclxuICBjb25zdCB1cGxvYWRJZCA9IHVuaXFpZCgpO1xyXG5cclxuICBmb3IgKGxldCBmaWxlIG9mIHJlcS5maWxlcy5maWxlKSB7XHJcbiAgICBjb25zdCBkYXRhID0gcmVhZGVyKGZpbGUucGF0aCk7XHJcbiAgICAvLyDjg5XjgqHjgqTjg6vlkI3jga7ph43opIfjgpLpgb/jgZHjgovjgZ/jgoHjgIHkuIDmhI/jga7jg5XjgqHjgqTjg6vlkI3jgpLkvZzmiJDjgZnjgotcclxuICAgIC8vIOalveWkqeOBruODleOCoeOCpOODq+WQjeaWh+Wtl+aVsOWItumZkDIw44Gr5ZCI44KP44Gb44KLXHJcbiAgICBsZXQgZmlsZW5hbWUgPSBgJHt1bmlxaWQoKX0uanBnYFxyXG5cclxuICAgIC8vIHNldCB0aGUgY29ycmVjdCBwYXRoIGZvciB0aGUgZmlsZSBub3QgdGhlIHRlbXBvcmFyeSBvbmUgZnJvbSB0aGUgQVBJOlxyXG4gICAgbGV0IHNhdmVQYXRoID0gcmVxLmJvZHkuaW1hZ2VkaXIgKyAnLycgKyBmaWxlbmFtZTtcclxuXHJcbiAgICAvLyBjb3B5IHRoZSBkYXRhIGZyb20gdGhlIHJlcS5maWxlcy5maWxlLnBhdGggYW5kIHBhc3RlIGl0IHRvIGZpbGUucGF0aFxyXG5cclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiee1kOaenOOCkuiomOmMsuOBmeOCi1xyXG4gICAgbGV0IGRvYyA9IHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgICBjbGllbnRGaWxlTmFtZTogZmlsZS5uYW1lLFxyXG4gICAgICB1cGxvYWRlZEZpbGVOYW1lOiBmaWxlbmFtZVxyXG4gICAgfTtcclxuICAgIFxyXG4gICAgdHJ5e1xyXG4gICAgICB3cml0ZXIoc2F2ZVBhdGgsIGRhdGEpO1xyXG4gICAgfVxyXG4gICAgY2F0Y2goZXJyKXtcclxuICAgICAgZG9jLmVycm9yID0gZXJyO1xyXG4gICAgfVxyXG4gICAgVXBsb2Fkcy5pbnNlcnQoZG9jKTtcclxuXHJcbiAgICBkZWxldGUgZmlsZTtcclxuXHJcbiAgfTtcclxuICByZXNwLndyaXRlSGVhZCgyMDApO1xyXG4gIHJlc3AuZW5kKEpTT04uc3RyaW5naWZ5KHtcclxuICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgIHNhdmVEaXI6IHJlcS5ib2R5LmltYWdlZGlyXHJcbiAgfSkpO1xyXG5cclxufSk7IiwiaW1wb3J0IGNyeXB0byBmcm9tICdjcnlwdG8nXHJcblxyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQgUmVwb3J0IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgR3JvdXAsXHJcbiAgR3JvdXBGYWN0b3J5XHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3VwcydcclxuaW1wb3J0IHtcclxuICBGaWx0ZXJcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycydcclxuXHJcbmxldCB0YWcgPSAnY3ViZW1pZydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ubWlncmF0ZWBdIChjb25maWcpIHtcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICAvLyBzZXR1cCBncm91cFxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IEZpbHRlcihjb25maWcuc3JjRmlsdGVySWQpXHJcbiAgICAvLyBsZXQgcGx1ZyA9IGdyb3VwLmdldFBsdWcoKTtcclxuXHJcbiAgICAvLyBjaGVja2luZyBjb25uZWN0aW9uXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCB0ZXN0UXVlcnkgPSAnU0hPVyBEQVRBQkFTRVMnXHJcblxyXG4gICAgbGV0IGRzdERiID0gbmV3IE15U1FMKGNvbmZpZy5kc3QuY3JlZClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ0Nvbm5lY3QgdG8gRGVzdGluYXRpb24nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgYXdhaXQgZHN0RGIucXVlcnkodGVzdFF1ZXJ5KVxyXG4gICAgICB9KVxyXG5cclxuICAgIC8vIHByb2Nlc3MgZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAgLy9cclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ1NlbGVjdCBsb29wIGluIHNvdXJjZScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgbW9iaWxlTnVsbDogYXN5bmMgKHJlY29yZCkgPT4ge1xyXG4gICAgICAgICAgICAvLyAvLyDlgKTjgpLmlbTnkIZcclxuICAgICAgICAgICAgLy8gZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgLy8gICBpZiAocmVjb3JkW2tleV0gPT09IG51bGwpO1xyXG4gICAgICAgICAgICAvLyAgIGVsc2UgaWYgKHJlY29yZFtrZXldLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgICAgICAvLyAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IE15U1FMLmZvcm1hdERhdGUocmVjb3JkW2tleV0pO1xyXG4gICAgICAgICAgICAvLyAgICAgcmVjb3JkW2tleV0gPSBgXCIke3JlY29yZFtrZXldfVwiYDtcclxuICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lciDjgavkv53lrZhcclxuXHJcbiAgICAgICAgICAgIGxldCBzcWwgPSBgXHJcblxyXG4gICAgICAgICAgICAgICAgSU5TRVJUIGR0Yl9jdXN0b21lclxyXG4gICAgICAgICAgICAgICAgKCBcXGBjdXN0b21lcl9pZFxcYCwgXFxgc3RhdHVzXFxgLCBcXGBzZXhcXGAsIFxcYGpvYlxcYCwgXFxgY291bnRyeV9pZFxcYCwgXFxgcHJlZlxcYCwgXFxgbmFtZTAxXFxgLCBcXGBuYW1lMDJcXGAsIFxcYGthbmEwMVxcYCwgXFxga2FuYTAyXFxgLCBcXGBjb21wYW55X25hbWVcXGAsIFxcYHppcDAxXFxgLCBcXGB6aXAwMlxcYCwgXFxgemlwY29kZVxcYCwgXFxgYWRkcjAxXFxgLCBcXGBhZGRyMDJcXGAsIFxcYGVtYWlsXFxgLCBcXGB0ZWwwMVxcYCwgXFxgdGVsMDJcXGAsIFxcYHRlbDAzXFxgLCBcXGBmYXgwMVxcYCwgXFxgZmF4MDJcXGAsIFxcYGZheDAzXFxgLCBcXGBiaXJ0aFxcYCwgXFxgcGFzc3dvcmRcXGAsIFxcYHNhbHRcXGAsIFxcYHNlY3JldF9rZXlcXGAsIFxcYGZpcnN0X2J1eV9kYXRlXFxgLCBcXGBsYXN0X2J1eV9kYXRlXFxgLCBcXGBidXlfdGltZXNcXGAsIFxcYGJ1eV90b3RhbFxcYCwgXFxgbm90ZVxcYCwgXFxgY3JlYXRlX2RhdGVcXGAsIFxcYHVwZGF0ZV9kYXRlXFxgLCBcXGBkZWxfZmxnXFxgIClcclxuXHJcbiAgICAgICAgICAgICAgICBWQUxVRVMoICR7cmVjb3JkLmN1c3RvbWVyX2lkfSAsICR7cmVjb3JkLnN0YXR1c30gLCAke3JlY29yZC5zZXh9ICwgJHtyZWNvcmQuam9ifSAsICR7cmVjb3JkLmNvdW50cnlfaWR9ICwgJHtyZWNvcmQucHJlZn0gLCAke3JlY29yZC5uYW1lMDF9ICwgJHtyZWNvcmQubmFtZTAyfSAsICR7cmVjb3JkLmthbmEwMX0gLCAke3JlY29yZC5rYW5hMDJ9ICwgJHtyZWNvcmQuY29tcGFueV9uYW1lfSAsICR7cmVjb3JkLnppcDAxfSAsICR7cmVjb3JkLnppcDAyfSAsICR7cmVjb3JkLnppcGNvZGV9ICwgJHtyZWNvcmQuYWRkcjAxfSAsICR7cmVjb3JkLmFkZHIwMn0gLCAke3JlY29yZC5lbWFpbH0gLCAke3JlY29yZC50ZWwwMX0gLCAke3JlY29yZC50ZWwwMn0gLCAke3JlY29yZC50ZWwwM30gLCAke3JlY29yZC5mYXgwMX0gLCAke3JlY29yZC5mYXgwMn0gLCAke3JlY29yZC5mYXgwM30gLCAke3JlY29yZC5iaXJ0aH0gLCAke3JlY29yZC5wYXNzd29yZH0gLCAke3JlY29yZC5zYWx0fSAsICR7cmVjb3JkLnNlY3JldF9rZXl9ICwgJHtyZWNvcmQuZmlyc3RfYnV5X2RhdGV9ICwgJHtyZWNvcmQubGFzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5idXlfdGltZXN9ICwgJHtyZWNvcmQuYnV5X3RvdGFsfSAsICR7cmVjb3JkLm5vdGV9ICwgJHtyZWNvcmQuY3JlYXRlX2RhdGV9ICwgJHtyZWNvcmQudXBkYXRlX2RhdGV9ICwgJHtyZWNvcmQuZGVsX2ZsZ30gKVxyXG4gICAgICAgICAgICAgICAgXHJcbiAgICAgICAgICAgICAgICBgXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgc3RhdHVzOiByZWNvcmQuc3RhdHVzLFxyXG4gICAgICAgICAgICAgICAgICBzZXg6IHJlY29yZC5zZXgsXHJcbiAgICAgICAgICAgICAgICAgIGpvYjogcmVjb3JkLmpvYixcclxuICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICBlbWFpbDogcmVjb3JkLmVtYWlsLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICBiaXJ0aDogcmVjb3JkLmJpcnRoLFxyXG4gICAgICAgICAgICAgICAgICBwYXNzd29yZDogcmVjb3JkLnBhc3N3b3JkLFxyXG4gICAgICAgICAgICAgICAgICBzYWx0OiByZWNvcmQuc2FsdCxcclxuICAgICAgICAgICAgICAgICAgc2VjcmV0X2tleTogcmVjb3JkLnNlY3JldF9rZXksXHJcbiAgICAgICAgICAgICAgICAgIGZpcnN0X2J1eV9kYXRlOiByZWNvcmQuZmlyc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGxhc3RfYnV5X2RhdGU6IHJlY29yZC5sYXN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBidXlfdGltZXM6IHJlY29yZC5idXlfdGltZXMsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90b3RhbDogcmVjb3JkLmJ1eV90b3RhbCxcclxuICAgICAgICAgICAgICAgICAgbm90ZTogcmVjb3JkLm5vdGUsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXJfYWRkcmVzc1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcl9hZGRyZXNzJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9hZGRyZXNzX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjg6Hjg6vjg57jgqzjg5fjg6njgrDjgqTjg7MgcGxnX21haWxtYWdhX2N1c3RvbWVyXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX21haWxtYWdhX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBpZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgbWFpbG1hZ2FfZmxnOiByZWNvcmQubWFpbG1hZ2FfZmxnLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8g44Kv44O844Od44Oz55m66KGM77yIRUNDVUJFMuOBruODneOCpOODs+ODiOmChOWFg++8iVxyXG5cclxuICAgICAgICAgICAgbGV0IGNvdXBvbkNkID0gY3J5cHRvLnJhbmRvbUJ5dGVzKDgpLnRvU3RyaW5nKCdiYXNlNjQnKS5zdWJzdHJpbmcoMCwgMTEpXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uTmFtZSA9IGAke3JlY29yZC5uYW1lMDF9ICR7cmVjb3JkLm5hbWUwMn0g5qeYIOOBlOWEquW+heOCr+ODvOODneODsyDkvJrlk6Hnlarlj7c6JHtyZWNvcmQuY3VzdG9tZXJfaWR9YFxyXG5cclxuICAgICAgICAgICAgbGV0IGRpc2NvdW50UHJpY2UgPSByZWNvcmQucG9pbnQgKyA1MDBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ3BsZ19jb3Vwb24nLCB7XHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2NkOiBjb3Vwb25DZCxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3R5cGU6IDMsIC8vIOWFqOWVhuWTgVxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbmFtZTogY291cG9uTmFtZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfdHlwZTogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3VzZV90aW1lOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fcmVsZWFzZTogMSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcHJpY2U6IGRpc2NvdW50UHJpY2UsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3JhdGU6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGVuYWJsZV9mbGFnOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbWVtYmVyOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fbG93ZXJfbGltaXQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV9mcm9tX2RhdGU6ICcyMDE4LTA0LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX3RvX2RhdGU6ICcyMDE5LTA1LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogMFxyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgfVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgJ2N1YmVtaWcuc2VydmVyQ2hlY2snIChwcm9maWxlKSB7XHJcbiAgICBsZXQgZGIgPSBuZXcgTXlTUUwocHJvZmlsZSlcclxuICAgIGxldCByZXMgPSBhd2FpdCBkYi5xdWVyeSgnU0hPVyBEQVRBQkFTRVMnKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCB7IE1vbmdvQ29sbGVjdGlvbiB9IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9tb25nbydcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLmNvbGxlY3Rpb24nXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmZpbmRgXSAocGx1ZywgcXVlcnkgPSB7fSwgcHJvamVjdGlvbiA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuZmluZChxdWVyeSwge3Byb2plY3Rpb246IHByb2plY3Rpb259KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5hZ2dyZWdhdGVgXSAocGx1ZywgcXVlcnkgPSB7fSkge1xyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbilcclxuICAgIGxldCByZXMgPSBhd2FpdCBjb2xsLmFnZ3JlZ2F0ZShxdWVyeSkudG9BcnJheSgpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uLy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLml0ZW1zJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvKipcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+OCs+ODrOOCr+OCt+ODp+ODs+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOBvuOBmeOAglxyXG4gICAqIEBwYXJhbVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LnNldEltYWdlYF0gKHBsdWcsIHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpXHJcbiAgICBsZXQgdXBsb2FkZWQgPSBhd2FpdCBpdGVtY29uLnNldEltYWdlKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxLCBjbGFzczIpXHJcbiAgICByZXR1cm4gdXBsb2FkZWRcclxuICB9LFxyXG5cclxuICAvKipcclxuICAgKiDjgqLjgqTjg4bjg6Dmg4XloLHjg4fjg7zjgr/jg5njg7zjgrnjga7nlLvlg4/nmbvpjLLjgpLliYrpmaTjgZnjgovvvIjnlLvlg4/oh6rkvZPjga/liYrpmaTjgZfjgarjgYTvvIlcclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5jbGVhbkltYWdlYF0gKHBsdWcsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGF3YWl0IGl0ZW1jb24uY2xlYW5JbWFnZShtb2RlbCwgY2xhc3MxLCBjbGFzczIpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IF8gZnJvbSAnbG9kYXNoJztcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InO1xuaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0JztcbmltcG9ydCB7XG4gIE1vbmdvREJGaWx0ZXIsXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcic7XG5pbXBvcnQge1xuICBDdWJlM0FwaSxcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpJztcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnO1xuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcyc7XG5cblxuY29uc3QgdGFnID0gJ2N1YmUnO1xuXG5NZXRlb3IubWV0aG9kcyh7XG5cbiAgLy9cbiAgLy8g44Kr44OG44K044Oq5pu05pawXG5cbiAgYXN5bmMgW2Ake3RhZ30uY2F0ZWdvcnlgXSAoY29uZmlnKSB7XG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXG4gICAgY29uc3QgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xuXG4gICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKTtcbiAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpO1xuXG4gICAgY29uc3QgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xuICAgIGNvbnN0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XG5cbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXG4gICAgICAn5ZWG5ZOB44Kr44OG44K044Oq44Gu5pu05pawJyxcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xuICAgICAgICAgIFVQREFURTogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcblxuICAgICAgICAgICAgLy8g5ZWG5ZOB44Gr44Kr44OG44K044Oq44O844OH44O844K/44GM6KiY6Yyy44GV44KM44Gm44GE44KM44Gw5Yem55CG44GZ44KLXG4gICAgICAgICAgICBpZiAoXy5pc0FycmF5KGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5jYXRlZ29yaWVzKSkge1xuXG4gICAgICAgICAgICAgIHRyeSB7XG4gICAgICAgICAgICAgICAgLy8g5ZWG5ZOB5oOF5aCx44OH44O844K/44OZ44O844K544Gr6KiY6Yyy44GV44KM44Gf5ZWG5ZOB44Kr44OG44K044Oq44O85oOF5aCx44KS44CB44Oi44O844Or44Gr6YGp55So44GZ44KLXG4gICAgICAgICAgICAgICAgY29uc3QgcmVzdWx0cyA9IGF3YWl0IGFwaS5tb2RpZnlDYXRlZ29yeShcbiAgICAgICAgICAgICAgICAgIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkLFxuICAgICAgICAgICAgICAgICAgaXRlbS5tYWxsLnNoYXJha3VTaG9wLmNhdGVnb3JpZXMsXG4gICAgICAgICAgICAgICAgKTtcblxuICAgICAgICAgICAgICAgIC8vIFNRTOOCr+OCqOODque1kOaenOOCkuiomOmMslxuICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhyZXN1bHRzKTtcbiAgICAgICAgICAgICAgfVxuICAgICAgICAgICAgICBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XG4gICAgICAgICAgICAgIH1cblxuICAgICAgICAgICAgfVxuXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpO1xuXG4gIH0sXG5cbiAgLy9cbiAgLy8g5Zyo5bqr5pu05pawXG5cbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlU3RvY2tgXSAoY29uZmlnKSB7XG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXG4gICAgY29uc3QgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xuXG4gICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKTtcbiAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpO1xuXG4gICAgY29uc3QgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xuICAgIGNvbnN0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XG5cbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXG4gICAgICAn5Zyo5bqr44Gu5pu05pawJyxcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xuXG4gICAgICAgICAgVVBEQVRFOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZCk7XG4gICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5KTtcbiAgICAgICAgICB9LFxuICAgICAgICB9KTtcblxuICAgICAgICByZXR1cm4gcmVzO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XG4gIH0sXG5cbiAgLy9cbiAgLy8g5ZWG5ZOB5oOF5aCx55m76Yyy44Go5pu05pawXG5cbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJJdGVtYF0gKGNvbmZpZykge1xuICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSk7XG4gICAgY29uc3QgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xuICAgIGNvbnN0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XG5cbiAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xuICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpO1xuXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXG4gICAgY29uc3QgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xuXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxuICAgICAgJ0VDQ1VCRTPjgbjjga7llYblk4HnmbvpjLInLFxuICAgICAgYXN5bmMgKCkgPT4ge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XG4gICAgICAgICAgSU5TRVJUOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xuICAgICAgICAgICAgY29uc3QgY29sID0gY29udGV4dC5jb2xsZWN0aW9uO1xuXG4gICAgICAgICAgICB0cnkge1xuICAgICAgICAgICAgICBjb25zdCBjdWJlSXRlbSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnLnVwZGF0ZUl0ZW0sIGl0ZW0pO1xuXG4gICAgICAgICAgICAgIGNvbnN0IGluc2VydFJlcyA9IGF3YWl0IGFwaS5wcm9kdWN0Q3JlYXRlKGN1YmVJdGVtKTtcblxuICAgICAgICAgICAgICAvLyBpdGVtIOODh+ODvOOCv+ODmeODvOOCueOBuOOBrueZu+mMslxuICAgICAgICAgICAgICBhd2FpdCBjb2wudXBkYXRlT25lKHtcbiAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkLFxuICAgICAgICAgICAgICB9LCB7XG4gICAgICAgICAgICAgICAgJHNldDoge1xuICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9pZCc6IGluc2VydFJlcy5yZXMucHJvZHVjdF9pZCxcbiAgICAgICAgICAgICAgICAgICdtYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQnOiBpbnNlcnRSZXMucmVzLnByb2R1Y3RfY2xhc3NfaWQsXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X3N0b2NrX2lkJzogaW5zZXJ0UmVzLnJlcy5wcm9kdWN0X3N0b2NrX2lkLFxuICAgICAgICAgICAgICAgIH0sXG4gICAgICAgICAgICAgIH0pO1xuXG4gICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XG4gICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcbiAgICAgICdFQ0NVQkUz5ZWG5ZOB5oOF5aCx44Gu5pu05pawJyxcbiAgICAgIGFzeW5jICgpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xuICAgICAgICAgIFVQREFURTogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcbiAgICAgICAgICAgIGNvbnN0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvbjtcblxuICAgICAgICAgICAgdHJ5IHtcbiAgICAgICAgICAgICAgY29uc3QgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy51cGRhdGVJdGVtLCBpdGVtKTtcblxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdEltYWdlVXBkYXRlKGN1YmVJdGVtKTtcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RVcGRhdGUoY3ViZUl0ZW0pO1xuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSk7XG5cbiAgICAgICAgICAgICAgY29uc3QgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZCk7XG4gICAgICAgICAgICAgIGF3YWl0IGFwaS51cGRhdGVTdG9jayhpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCwgcXVhbnRpdHkpO1xuXG4gICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xuICAgICAgICAgICAgfVxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XG4gICAgICAgICAgdGhyb3cgZTtcbiAgICAgICAgfSk7XG5cbiAgICAgICAgcmV0dXJuIHJlcztcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpO1xuICB9LFxuXG59KTtcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgY3N2IGZyb20gJ2NzdidcclxuaW1wb3J0IHsgVHJhbnNmb3JtLCBXcml0YWJsZSB9IGZyb20gJ3N0cmVhbSdcclxuXHJcbmltcG9ydCBGaWJlciBmcm9tICdmaWJlcnMnXHJcbmltcG9ydCBSb2JvdGluIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9yb2JvdGluJ1xyXG5cclxuY29uc3QgdGFnID0gJ3JvYm90aW4nXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm9yZGVyLmV4cG9ydGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1JvYm90LWluIOWPl+azqENTViDlh7rlipsnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS8ke2NvbmZpZy5vcmRlci53b3JrZGlyfWA7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpckV4cG9ydCA9IGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyLndvcmtkaXJFeHBvcnR9YDtcclxuICAgICAgICBjb25zdCBvcmRlckNzdkV4cG9ydCA9IGAke2NvbmZpZy5vcmRlci5vcmRlcmNzdkV4cG9ydH0uY3N2YDtcclxuICAgICAgICBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgLy8g6Kqt44G/5Y+W44KK44OV44Kp44Or44OAXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXJFeHBvcnQpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aa5rqW5YKZXHJcbiAgICAgICAgY29uc3QgaXRlbVMgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1TLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOWPl+azqENTVuOCkuWHuuWKm+OBmeOCi1xyXG4gICAgICAgIE1ldGVvci53cmFwQXN5bmMobWNiID0+IHtcclxuICAgICAgICAgIGNvbnN0IHJlYWQgPSBSb2JvdGluLmNyZWF0ZVJlYWRhYmxlT3JkZXIoKVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHsgbWNiKGVycikgfSlcclxuXHJcbiAgICAgICAgICBjb25zdCB0cmFuc2Zvcm0gPSBuZXcgVHJhbnNmb3JtKHtcclxuICAgICAgICAgICAgd3JpdGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICByZWFkYWJsZU9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHRyYW5zZm9ybTogKGNodW5rLCBlbmMsIGNiKT0+e1xyXG4gICAgICAgICAgICAgIGNiKG51bGwsIGNodW5rLnJvYm90aW4pO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgICAgICBjb25zdCB3cml0ZSA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2RpckV4cG9ydH0vJHtvcmRlckNzdkV4cG9ydH1gKVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHsgbWNiKGVycikgfSlcclxuICAgICAgICAgICAgLm9uKCdmaW5pc2gnLCAoKT0+e1xyXG4gICAgICAgICAgICAgIG1jYigpXHJcbiAgICAgICAgICAgIH0pXHJcblxyXG4gICAgICAgICAgcmVhZFxyXG4gICAgICAgICAgICAucGlwZSh0cmFuc2Zvcm0pXHJcbiAgICAgICAgICAgIC5waXBlKGNzdi5zdHJpbmdpZnkoe2hlYWRlcjogdHJ1ZX0pKVxyXG4gICAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgICAucGlwZSh3cml0ZSlcclxuICAgICAgICB9KSgpXHJcblxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5vcmRlci5pbXBvcnRgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdSb2JvdC1pbiDlj5fms6hDU1Yg5Y+W6L6844G/JyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vJHtjb25maWcub3JkZXIud29ya2Rpcn1gO1xyXG4gICAgICAgIGNvbnN0IHdvcmtkaXJJbXBvcnQgPSBgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlci53b3JrZGlySW1wb3J0fWA7XHJcbiAgICAgICAgY29uc3Qgb3JkZXJDc3YgPSBgJHtjb25maWcub3JkZXIub3JkZXJjc3Z9LmNzdmA7XHJcbiAgICAgICAgXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIC8vIOiqreOBv+WPluOCiuODleOCqeODq+ODgFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlySW1wb3J0KVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mua6luWCmVxyXG4gICAgICAgIGNvbnN0IGl0ZW1TID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtUy5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDlj5fms6hDU1bjgpLoqq3jgb/ovrzjgoBcclxuICAgICAgICBNZXRlb3Iud3JhcEFzeW5jKG1jYiA9PiB7XHJcbiAgICAgICAgICBjb25zdCByZWFkID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJJbXBvcnR9LyR7b3JkZXJDc3Z9YClcclxuICAgICAgICAgICAgLm9uKCdlcnJvcicsIGVyciA9PiB7IG1jYihlcnIpIH0pXHJcbiAgICAgICAgICBjb25zdCB3cml0ZSA9IG5ldyBXcml0YWJsZSh7XHJcbiAgICAgICAgICAgIG9iamVjdE1vZGU6IHRydWUsXHJcbiAgICAgICAgICAgIHdyaXRlIChjaHVuaywgZW5jb2RpbmcsIGNhbGxiYWNrKSB7XHJcbiAgICAgICAgICAgICAgRmliZXIoYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgICAgYXdhaXQgUm9ib3Rpbi5pbXBvcnRPcmRlcihjaHVuaywgaXRlbVMpXHJcbiAgICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2F0Y2goZXJyKXtcclxuICAgICAgICAgICAgICAgICAgY2FsbGJhY2soZXJyKVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgY2FsbGJhY2soKVxyXG4gICAgICAgICAgICAgIH0pLnJ1bigpXHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIGZpbmFsIChjYWxsYmFjaykge1xyXG4gICAgICAgICAgICAgIGNhbGxiYWNrKClcclxuICAgICAgICAgICAgICBtY2IoKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHJlcG9ydC5pRXJyb3IoZXJyKSlcclxuXHJcbiAgICAgICAgICByZWFkLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAgIC5waXBlKHdyaXRlKVxyXG4gICAgICAgIH0pKClcclxuXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnBvc3RsYWJlbGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1JvYm90LWluIOmAgeOCiueKtueZuuihjCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9LyR7Y29uZmlnLnBvc3RsYWJlbC53b3JrZGlyfWBcclxuICAgICAgICBjb25zdCB3b3JrZGlyUmVhZCA9IGAke3dvcmtkaXJ9LyR7Y29uZmlnLnBvc3RsYWJlbC53b3JrZGlyUmVhZH1gXHJcbiAgICAgICAgY29uc3Qgd29ya2RpcldyaXRlID0gYCR7d29ya2Rpcn0vJHtjb25maWcucG9zdGxhYmVsLndvcmtkaXJXcml0ZX1gXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIC8vIOiqreOBv+WPluOCiuODleOCqeODq+ODgFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyUmVhZClcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAvLyDmm7jjgY3ovrzjgb/jg5Xjgqnjg6vjg4BcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcldyaXRlKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIHdvcmtkaXIg44GM5rqW5YKZ44GV44KM44Gm44GE44Gf44KJ5a6f6KGM44GZ44KLXHJcbiAgICAgICAgY29uc3QgaXRlbVMgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1TLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOWPl+azqENTVuOCkuiqreOBv+i+vOOCgFxyXG4gICAgICAgIGNvbnN0IHJvYm8gPSBuZXcgUm9ib3RpbigpXHJcbiAgICAgICAgTWV0ZW9yLndyYXBBc3luYyhtY2IgPT4ge1xyXG4gICAgICAgICAgY29uc3QgcmVhZCA9IGZzRXh0cmEuY3JlYXRlUmVhZFN0cmVhbShgJHt3b3JrZGlyUmVhZH0vJHtjb25maWcucG9zdGxhYmVsLm9yZGVyY3N2fS5jc3ZgKVxyXG4gICAgICAgICAgICAub24oJ2Vycm9yJywgZXJyID0+IHsgbWNiKGVycikgfSlcclxuICAgICAgICAgIGNvbnN0IHdyaXRlID0gbmV3IFdyaXRhYmxlKHtcclxuICAgICAgICAgICAgb2JqZWN0TW9kZTogdHJ1ZSxcclxuICAgICAgICAgICAgd3JpdGUgKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgICByb2JvLmltcG9ydE9yZGVyVGVtcChjaHVuaywgaXRlbVMpXHJcbiAgICAgICAgICAgICAgY2FsbGJhY2soKVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICBmaW5hbCAoY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgICBjYWxsYmFjaygpXHJcbiAgICAgICAgICAgICAgbWNiKClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSlcclxuXHJcbiAgICAgICAgICByZWFkLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAgIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAgIC5waXBlKHdyaXRlKVxyXG4gICAgICAgIH0pKClcclxuXHJcbiAgICAgICAgLy8g6YCB44KK54q256iu5Yil44GU44Go44Gr57mw44KK6L+U44GZXHJcbiAgICAgICAgY29uZmlnLnBvc3RsYWJlbC5sYWJlbHR5cGVzLmZvckVhY2gobGFiZWxPcHRpb24gPT4ge1xyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgTWV0ZW9yLndyYXBBc3luYyhtY2IgPT4ge1xyXG4gICAgICAgICAgICAgIGNvbnN0IHJlYWQgPSBmc0V4dHJhLmNyZWF0ZVJlYWRTdHJlYW0oYCR7d29ya2RpclJlYWR9LyR7bGFiZWxPcHRpb24ucmVhZGNzdn0uY3N2YClcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoKSA9PiB7IG1jYigpIH0pIC8vIOODleOCoeOCpOODq+OBjOOBquOBhOWgtOWQiOOBr+eEoeimllxyXG4gICAgICAgICAgICAgIGNvbnN0IHRyYW5zZm9ybSA9IG5ldyBUcmFuc2Zvcm0oe1xyXG4gICAgICAgICAgICAgICAgcmVhZGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgd3JpdGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgICAgdHJhbnNmb3JtOiAoY2h1bmssIGVuY29kaW5nLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBsZXQgcmVjb3JkXHJcbiAgICAgICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICAgICAgRmliZXIoKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgICAgcmVjb3JkID0gcm9ib1tsYWJlbE9wdGlvbi5tZXRob2RdKGNodW5rLCBsYWJlbE9wdGlvbilcclxuICAgICAgICAgICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHJlY29yZClcclxuICAgICAgICAgICAgICAgICAgICB9KS5ydW4oKVxyXG4gICAgICAgICAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICAgICAgICAgIG1jYihlcnJvcilcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgY29uc3Qgd3JpdGUgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke3dvcmtkaXJXcml0ZX0vJHtsYWJlbE9wdGlvbi53cml0ZWNzdn0uY3N2YClcclxuICAgICAgICAgICAgICAgIC5vbignZmluaXNoJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKVxyXG4gICAgICAgICAgICAgICAgICBtY2IoKVxyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCBlcnJvciA9PiB7IG1jYihlcnJvcikgfSlcclxuXHJcbiAgICAgICAgICAgICAgcmVhZFxyXG4gICAgICAgICAgICAgICAgLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAgICAgICAucGlwZShjc3YucGFyc2Uoe2NvbHVtbnM6IGxhYmVsT3B0aW9uLmNvbHVtbnMgPT09IHRydWUgPyB0cnVlIDogbnVsbH0pKVxyXG4gICAgICAgICAgICAgICAgLnBpcGUodHJhbnNmb3JtKVxyXG4gICAgICAgICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiBsYWJlbE9wdGlvbi5jb2x1bW5zfSkpXHJcbiAgICAgICAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgICAgIC5waXBlKHdyaXRlKVxyXG4gICAgICAgICAgICB9KSgpXHJcbiAgICAgICAgICB9IGNhdGNoIChlcnJvcikge1xyXG4gICAgICAgICAgICByZXBvcnQuaUVycm9yKGVycm9yKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gUm9ib3QtaW5cclxuICAvLyDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7dcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uaXRlbWNvZGVgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdSb2JvdC1pbiDlpJbpg6jpgKPmkLrllYblk4Hnlarlj7cnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS8ke2NvbmZpZy5pdGVtY29kZS53b3JrZGlyfWBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgLy8gd29ya2RpciDjgYzmupblgpnjgZXjgozjgabjgYTjgZ/jgonlrp/ooYzjgZnjgotcclxuICAgICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgICAgY29uc3QgcmVhZCA9IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmZpbmQoe21vZGVsOiB7JG5lOiAnJ319KS5zdHJlYW0oKVxyXG5cclxuICAgICAgICAgIGNvbnN0IHdyaXRlQ3N2ID0gKHJlYWQsIHRmLCBmaWxlbmFtZSkgPT4ge1xyXG4gICAgICAgICAgICBjb25zdCByb2JvdGluID0gbmV3IFRyYW5zZm9ybSh7XHJcbiAgICAgICAgICAgICAgcmVhZGFibGVPYmplY3RNb2RlOiB0cnVlLFxyXG4gICAgICAgICAgICAgIHdyaXRhYmxlT2JqZWN0TW9kZTogdHJ1ZSxcclxuICAgICAgICAgICAgICB0cmFuc2Zvcm0gKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spIHtcclxuICAgICAgICAgICAgICAgIEZpYmVyKCgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uc3QgZGF0YSA9IHRmKGNodW5rKVxyXG4gICAgICAgICAgICAgICAgICBjYWxsYmFjayhudWxsLCBkYXRhKVxyXG4gICAgICAgICAgICAgICAgfSkucnVuKClcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIGxldCBjb3VudCA9IDBcclxuICAgICAgICAgICAgY29uc3QgY2xlYXJudW0gPSBuZXcgVHJhbnNmb3JtKHtcclxuICAgICAgICAgICAgICBlbmNvZGluZzogJ3V0ZjgnLFxyXG4gICAgICAgICAgICAgIHRyYW5zZm9ybTogKGNodW5rLCBlbmNvZGluZywgY2FsbGJhY2spID0+IHtcclxuICAgICAgICAgICAgICAgIGxldCBzdHIgPSBjaHVuay50b1N0cmluZygpXHJcbiAgICAgICAgICAgICAgICBpZiAoY291bnQgPT09IDApIHtcclxuICAgICAgICAgICAgICAgICAgc3RyID0gc3RyLnJlcGxhY2UoL19cXGQrPy9nLCAnJylcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIGNvdW50KytcclxuICAgICAgICAgICAgICAgIGNhbGxiYWNrKG51bGwsIHN0cilcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIGNvbnN0IHdyaXRlY3N2ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbShgJHtmaWxlbmFtZX0uY3N2YClcclxuICAgICAgICAgICAgd3JpdGVjc3Yub24oJ2Vycm9yJywgZSA9PiB7IHRocm93IE1ldGVvci5FcnJvcignQ1NW44OV44Kh44Kk44Or5pu444GN6L6844G/44Ko44Op44O8JykgfSlcclxuXHJcbiAgICAgICAgICAgIHJlYWQucGlwZShyb2JvdGluKVxyXG4gICAgICAgICAgICAgIC5waXBlKGNzdi5zdHJpbmdpZnkoe2hlYWRlcjogdHJ1ZX0pKVxyXG4gICAgICAgICAgICAgIC5waXBlKGNsZWFybnVtKVxyXG4gICAgICAgICAgICAgIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgICAgICAucGlwZSh3cml0ZWNzdilcclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICB3cml0ZUNzdihcclxuICAgICAgICAgICAgcmVhZCxcclxuICAgICAgICAgICAgSXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1Sb2JvdGluSXRlbSxcclxuICAgICAgICAgICAgYCR7d29ya2Rpcn0vJHtjb25maWcuaXRlbWNvZGUuY3N2TmFtZUl0ZW19YFxyXG4gICAgICAgICAgKVxyXG5cclxuICAgICAgICAgIHdyaXRlQ3N2KFxyXG4gICAgICAgICAgICByZWFkLFxyXG4gICAgICAgICAgICBJdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVJvYm90aW5TZWxlY3QsXHJcbiAgICAgICAgICAgIGAke3dvcmtkaXJ9LyR7Y29uZmlnLml0ZW1jb2RlLmNzdk5hbWVTZWxlY3R9YFxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihg5q2j44GX44GE5L2c5qWt44OH44Kj44Os44Kv44OI44Oq44GM55So5oSP44GV44KM44Gm44GE44G+44Gb44KT44Gn44GX44Gf44CCXFxuWyR7d29ya2Rpcn1dYClcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICd0b29sJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS50ZXN0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuXHJcbiAgICBjb25zdCBuZXdMb2NhbCA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHt9LCBhc3luYyAoZSkgPT4ge1xyXG4gICAgICB0aHJvdyBlXHJcbiAgICB9KVxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44OV44Kj44Or44K/44O844OG44K544OIJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBuZXdMb2NhbFxyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcblxyXG5pbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0LXByb21pc2UnXHJcbmltcG9ydCBXb3dtYUFwaSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2Uvd293bWFBcGknXHJcbmltcG9ydCB1dGlsRXJyb3IgZnJvbSAnLi4vaW1wb3J0cy91dGlsL2Vycm9yJ1xyXG5cclxuY29uc3QgdGFnID0gJ3dvd21hJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeaDheWgseOBruWkieabtFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVJdGVtLmluZm9gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB5oOF5aCx44KS5pu05paw44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDk0MicgLy8gSkstMTIwXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNTQwMidcclxuICAgICAgICAgICAgICAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA0NzQzJ1xyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihpdGVtLCBjb25maWcuaXRlbUluZm8uZGVmYXVsdClcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZUl0ZW0oaXRlbSlcclxuICAgICAgICAgICAgICByZXR1cm4ge3JlcXVlc3RCb2R5OiBpdGVtLCByZXNwb25zZTogcmVzfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih7cmVxdWVzdEJvZHk6IGl0ZW19LCB1dGlsRXJyb3IucGFyc2UoZSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB44Gu6YWN6YCB5pa55rOV44KS6Kit5a6a44GZ44KLXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZUl0ZW0uZGVsaXZlcnlNZXRob2RgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB44Gu6YWN6YCB5pa55rOV44KS6Kit5a6a44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDk0MicgLy8gSkstMTIwXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgT2JqZWN0LmFzc2lnbihpdGVtLCBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVdvd21hQ3JlYXRlRGVsaXZlcnlNZXRob2QoaXRlbS5pdGVtQ29kZSkpXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS51cGRhdGVJdGVtKGl0ZW0pXHJcbiAgICAgICAgICAgICAgcmV0dXJuIHtyZXF1ZXN0Qm9keTogaXRlbSwgcmVzcG9uc2U6IHJlc31cclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHRocm93IE9iamVjdC5hc3NpZ24oe3JlcXVlc3RCb2R5OiBpdGVtfSwgdXRpbEVycm9yLnBhcnNlKGUpKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueS4iuOBruWVhuWTgeOCkuWFrOmWi+OBmeOCi1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVJdGVtLm9wZW5gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXb3dtYSEg5ZWG5ZOB44OH44O844K/44OZ44O844K55LiK44Gu5ZWG5ZOB44KS5YWs6ZaL44GZ44KLJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8gamxpbmVfZW5naW5lIOWVhuWTgeODh+ODvOOCv+ODmeODvOOCueOBuOOBruaOpee2mlxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWVhuWTgeaDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICRvcjogW1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gfSxcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgXVxyXG4gICAgICAgICAgICAgICAgICAvLyB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Kz44O844OJ44Gu5LiA6Kan44KS5L2c44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckbWFsbC53b3dtYS5pdGVtQ29kZSdcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkcHJvamVjdDoge1xyXG4gICAgICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckX2lkJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8g5b6X44KJ44KM44Gf5ZWG5ZOB44GU44Go44GrQVBJ44Oq44Kv44Ko44K544OI44KS55m66KGMXHJcbiAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgIGF3YWl0IHJlcG9ydC5mb3JFYWNoT25DdXJzb3IoXHJcbiAgICAgICAgICBjdXIsXHJcbiAgICAgICAgICBhc3luYyBpdGVtID0+IHtcclxuICAgICAgICAgICAgaXRlbS5zYWxlU3RhdHVzID0gMVxyXG4gICAgICAgICAgICBpdGVtLmxpbWl0ZWRQYXNzd2QgPSAnTlVMTCdcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZUl0ZW0oaXRlbSlcclxuICAgICAgICAgICAgICByZXR1cm4ge3JlcXVlc3RCb2R5OiBpdGVtLCByZXNwb25zZTogcmVzfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih7cmVxdWVzdEJvZHk6IGl0ZW19LCB1dGlsRXJyb3IucGFyc2UoZSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5Zyo5bqr5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZVN0b2NrYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWcqOW6q+abtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIOWcqOW6q+aDheWgseOBruS9nOaIkFxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICBsZXQgY3VyID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgICAgICAkYW5kOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6IHsgJGV4aXN0czogMSB9XHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8g44OG44K544OI5qSc57Si5p2h5Lu26Kit5a6aXHJcbiAgICAgICAgICAgICAgICAvLyAgICx7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA1NDAyJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnZ2stMTYzJ1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDQ3NDMnXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgXVxyXG4gICAgICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgICAgICBdXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g6YWN6YCB5pa55rOV44Gu6YGV44GE44KS55yB44GPXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IHtcclxuICAgICAgICAgICAgICAgICAgaXRlbUNvZGU6ICckbWFsbC53b3dtYS5pdGVtQ29kZScsXHJcbiAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlOiAnJG1hbGwud293bWEuSENob2ljZU5hbWUnLFxyXG4gICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6ICckbWFsbC53b3dtYS5WQ2hvaWNlTmFtZSdcclxuICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICBpdGVtOiB7XHJcbiAgICAgICAgICAgICAgICAgICRmaXJzdDogJyRfaWQnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgLy8g5ZWG5ZOB44Oa44O844K444GU44Go77yI5ZWG5ZOB44Kz44O844OJ77yJ44Gr44Kw44Or44O844OX5YyW44GZ44KLXHJcbiAgICAgICAgICAgICAgJGdyb3VwOiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6ICckX2lkLml0ZW1Db2RlJyxcclxuICAgICAgICAgICAgICAgIHZhcmlhdGlvbnM6IHtcclxuICAgICAgICAgICAgICAgICAgJHB1c2g6IHtcclxuICAgICAgICAgICAgICAgICAgICBfaWQ6ICckaXRlbScsXHJcbiAgICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGU6ICckX2lkLmNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlJyxcclxuICAgICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGU6ICckX2lkLmNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZSdcclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnLFxyXG4gICAgICAgICAgICAgICAgdmFyaWF0aW9uczogJyR2YXJpYXRpb25zJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgXVxyXG4gICAgICAgIClcclxuXHJcbiAgICAgICAgLy8gbGV0IHJlc01vbmdvID0gYXdhaXQgY3VyLnRvQXJyYXkoKVxyXG4gICAgICAgIC8vIHJldHVybiByZXNNb25nb1xyXG5cclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqNcclxuICAgICAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICAgICAgbGV0IGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpXHJcblxyXG4gICAgICAgICAgLy8g5Zyo5bqr44KS6Kit5a6a44GZ44KLXHJcbiAgICAgICAgICBmb3IgKGxldCBlIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgICAgICBlLnN0b2NrID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soZS5faWQpXHJcbiAgICAgICAgICAgIGRlbGV0ZSBlLl9pZFxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIC8vXHJcbiAgICAgICAgICAvLyDlnKjluqvmm7TmlrDjg6rjgq/jgqjjgrnjg4hcclxuICAgICAgICAgIGxldCBhcGkgPSBuZXcgV293bWFBcGkoY29uZmlnLndvd21hQXBpUG9zdCwgY29uZmlnLnNob3BJZClcclxuICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlU3RvY2soW2l0ZW1dKVxyXG4gICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeaknOe0olxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5zZWFyY2hJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBvcHRpb25zID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShjb25maWcud293bWFBcGkpKVxyXG4gICAgICAgICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hJdGVtSW5mb2BcclxuICAgICAgICAgICAgb3B0aW9ucy5xcy5pdGVtQ29kZSA9IGl0ZW0ubWFsbC53b3dtYS5pdGVtQ29kZVxyXG5cclxuICAgICAgICAgICAgbGV0IHJlcG9zID0gYXdhaXQgcmVxdWVzdChvcHRpb25zKVxyXG4gICAgICAgICAgICBsZXQgZmlsZW5hbWUgPSBgJHt3b3JrZGlyfS8ke2l0ZW0ubW9kZWx9LnhtbGBcclxuXHJcbiAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEud3JpdGVGaWxlKGZpbGVuYW1lLCByZXBvcylcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBXb3dtYUFwaUl0ZW1GaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmNvbnN0IHRhZyA9ICd3b3dtYUFwaSdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQeWVhuWTgeaDheWgseWPluW+l1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5nZXRJdGVtYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV09XTUEhIOWVhuWTgeaDheWgseWPluW+lycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgV293bWFBcGlJdGVtRmlsdGVyKGNvbmZpZy53b3dtYUFwaSwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIC8vIHRyeSB7XHJcbiAgICAgICAgLy8gICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIC8vIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIC8vIEFQSeOBi+OCieWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIC8vIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vaXRlbXNfJHsobmV3IERhdGUoKSkuZ2V0VGltZSgpfWBcclxuICAgICAgICAvLyAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICAvLyB0cnkge1xyXG4gICAgICAgIC8vICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIC8vIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhpdGVtKVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBQYWNrZXQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3BhY2tldCdcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcblxyXG5pbXBvcnQgaWNvbnYgZnJvbSAnaWNvbnYtbGl0ZSdcclxuaW1wb3J0IGFyY2hpdmVyIGZyb20gJ2FyY2hpdmVyJ1xyXG5pbXBvcnQgY3N2IGZyb20gJ2NzdidcclxuaW1wb3J0IHsgUGFzc1Rocm91Z2gsIFRyYW5zZm9ybSB9IGZyb20gJ3N0cmVhbSdcclxuXHJcbmNvbnN0IHByZWZpeCA9ICdwYWNrZXQnXHJcbmNvbnN0IHRhZyA9ICd5YXVjdCdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDjg6Tjg5Xjgqrjgq/lj5fms6jjg5XjgqHjgqTjg6tcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ub3JkZXJgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lj5fms6gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9vcmRlcmBcclxuICAgICAgICBjb25zdCByID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyTG9hZGZpbGV9YClcclxuICAgICAgICBjb25zdCB3ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbShgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlclNhdmVmaWxlfWApXHJcbiAgICAgICAgci5waXBlKGljb252LmRlY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAucGlwZShjc3YudHJhbnNmb3JtKFxyXG4gICAgICAgICAgICBhc3luYyAocmVjb3JkLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgIGxldCBlcnIgPSBudWxsXHJcbiAgICAgICAgICAgICAgLy8g566h55CG55Wq5Y+344KS572u44GN5o+b44GI44KLXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHJlY29yZFsn566h55CG55Wq5Y+3J10gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRNb2RlbENsYXNzKHJlY29yZFsn566h55CG55Wq5Y+3J10pXHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgZXJyID0gZVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBjYWxsYmFjayhlcnIsIHJlY29yZClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKSlcclxuICAgICAgICAgIC5waXBlKGNzdi5zdHJpbmdpZnkoe2hlYWRlcjogdHJ1ZX0pKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAucGlwZSh3KVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyDjg6Tjg5Xjgqrjgq/lh7rlk4Hjg5XjgqHjgqTjg6tcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJpdGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODpOODleOCquOCr+WHuuWTgScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOe5sOOCiui/lOOBl+WHpueQhuOCkuS7u+aEj+OBru+8iHBhY2tldFNpemXvvInjgafliIblibJcclxuICAgICAgICBjb25zdCBwYWNrZXQgPSBuZXcgUGFja2V0KGNvbmZpZy5wYWNrZXRTaXplKVxyXG5cclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgpLkvZzmiJDjgZfnlLvlg4/jg4fjg7zjgr/jgpLlj47pm4bjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L3dvcmtgXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUod29ya2RpcilcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcblxyXG4gICAgICAgIC8vIFpJUOODleOCoeOCpOODq+OCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHVwbG9hZGRpciA9IGAke2NvbmZpZy53b3JrZGlyfS91cGxvYWRgXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUodXBsb2FkZGlyKVxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIodXBsb2FkZGlyKVxyXG5cclxuICAgICAgICBsZXQgY2QgPSBudWxsIC8vIOODkeOCseODg+ODiOODleOCqeODq+ODgFxyXG4gICAgICAgIGxldCBmaWxlbmFtZSA9IG51bGwgLy8gY3N244OV44Kh44Kk44OrXHJcbiAgICAgICAgbGV0IG5hbWUgPSBudWxsIC8vIOODkeOCseODg+ODiOeVquWPt1xyXG5cclxuICAgICAgICAvLyBDU1bjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZfjgIHpoIbnlarjgpLnorrlrprjgZnjgotcclxuICAgICAgICBsZXQgZmllbGRzID0gWyfnrqHnkIbnlarlj7cnLCAn44Kr44OG44K044OqJywgJ+OCv+OCpOODiOODqycsICfoqqzmmI4nLCAn44K544OI44Ki5YaF5ZWG5ZOB5qSc57Si55So44Kt44O844Ov44O844OJJywgJ+mWi+Wni+S+oeagvCcsICfljbPmsbrkvqHmoLwnLCAn5YCk5LiL44GS5Lqk5riJJywgJ+WAi+aVsCcsICflhaXmnK3lgIvmlbDliLbpmZAnLCAn5pyf6ZaTJywgJ+e1guS6huaZgumWkycsICfllYblk4HnmbrpgIHlhYPjga7pg73pgZPlupznnIwnLCAn5ZWG5ZOB55m66YCB5YWD44Gu5biC5Yy655S65p2RJywgJ+mAgeaWmeiyoOaLhScsICfku6Pph5HlhYjmiZXjgYTjgIHlvozmiZXjgYQnLCAn6JC95pyt44OK44OT5rG65riI5pa55rOV6Kit5a6aJywgJ+WVhuWTgeOBrueKtuaFiycsICfllYblk4Hjga7nirbmhYvlgpnogIMnLCAn6L+U5ZOB44Gu5Y+v5ZCmJywgJ+i/lOWTgeOBruWPr+WQpuWCmeiAgycsICfnlLvlg48xJywgJ+eUu+WDjzHjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMicsICfnlLvlg48y44Kz44Oh44Oz44OIJywgJ+eUu+WDjzMnLCAn55S75YOPM+OCs+ODoeODs+ODiCcsICfnlLvlg480JywgJ+eUu+WDjzTjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNScsICfnlLvlg48144Kz44Oh44Oz44OIJywgJ+eUu+WDjzYnLCAn55S75YOPNuOCs+ODoeODs+ODiCcsICfnlLvlg483JywgJ+eUu+WDjzfjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOCcsICfnlLvlg48444Kz44Oh44Oz44OIJywgJ+eUu+WDjzknLCAn55S75YOPOeOCs+ODoeODs+ODiCcsICfnlLvlg48xMCcsICfnlLvlg48xMOOCs+ODoeODs+ODiCcsICfmnIDkvY7oqZXkvqEnLCAn5oKq6KmV5Ymy5ZCI5Yi26ZmQJywgJ+WFpeacreiAheiqjeiovOWItumZkCcsICfoh6rli5Xlu7bplbcnLCAn5pep5pyf57WC5LqGJywgJ+WVhuWTgeOBruiHquWLleWGjeWHuuWTgScsICfoh6rli5XlgKTkuIvjgZInLCAn5pyA5L2O6JC95pyt5L6h5qC8JywgJ+ODgeODo+ODquODhuOCo+ODvCcsICfms6jnm67jga7jgqrjg7zjgq/jgrfjg6fjg7MnLCAn5aSq5a2X44OG44Kt44K544OIJywgJ+iDjOaZr+iJsicsICfjgrnjg4jjgqLjg5vjg4Pjg4jjgqrjg7zjgq/jgrfjg6fjg7MnLCAn55uu56uL44Gh44Ki44Kk44Kz44OzJywgJ+i0iOetlOWTgeOCouOCpOOCs+ODsycsICdU44Od44Kk44Oz44OI44Kq44OX44K344On44OzJywgJ+OCouODleOCo+ODquOCqOOCpOODiOOCquODl+OCt+ODp+ODsycsICfojbfnianjga7lpKfjgY3jgZUnLCAn6I2354mp44Gu6YeN6YePJywgJ+OBr+OBk0JPT04nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMScsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTHlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMicsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTLlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTPlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTTlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNScsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTXlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNicsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTblhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTflhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTjlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOScsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTnlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTAnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTDmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTDlhajlm73kuIDlvovkvqHmoLwnLCAn5rW35aSW55m66YCBJywgJ+mFjemAgeaWueazleODu+mAgeaWmeioreWumicsICfku6PlvJXmiYvmlbDmlpnoqK3lrponLCAn5raI6LK756iO6Kit5a6aJywgJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXVxyXG4gICAgICAgIGxldCBoZWFkZXIgPSBmaWVsZHMubWFwKHYgPT4gYFwiJHt2fVwiYCkuam9pbignLCcpICsgJ1xcbidcclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW6ZaL5aeL5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0U3RhcnQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcclxuICAgICAgICAgIG5hbWUgPSBwcmVmaXggKyAoJzAwMDAwJyArIHBhY2tldENvdW50KS5zbGljZSgtNSlcclxuICAgICAgICAgIGNkID0gYCR7d29ya2Rpcn0vJHtuYW1lfWBcclxuICAgICAgICAgIGZpbGVuYW1lID0gYCR7Y2R9LyR7Y29uZmlnLmNzdkZpbGVOYW1lfWBcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY2QpXHJcbiAgICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgavjg5XjgqPjg7zjg6vjg4njgpLoqK3lrprjgZnjgotcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKGhlYWRlciwgJ1NoaWZ0X0pJUycpKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0ID0gYXN5bmMgKGFyZykgPT4ge1xyXG4gICAgICAgICAgbGV0IHlhdWN0ID0gYXJnLnlhdWN0XHJcbiAgICAgICAgICBsZXQgaXRlbSA9IGFyZy5pdGVtXHJcbiAgICAgICAgICAvLyBjc3bjg5XjgqHjgqTjg6vjgavjg6zjgrPjg7zjg4nvvIjllYblk4Hjg4bjg7Pjg5fjg6zjg7zjg4jvvInjgpLov73liqDjgZnjgotcclxuICAgICAgICAgIGxldCByZWNvcmQgPSBmaWVsZHMubWFwKHYgPT4geyByZXR1cm4geWF1Y3Rbdl0gPyBgXCIke3lhdWN0W3ZdfVwiYCA6ICdcIlwiJyB9KS5qb2luKCcsJykgKyAnXFxuJ1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUocmVjb3JkLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgICAvLyDnlLvlg4/jg5XjgqHjgqTjg6vjgpLjgrPjg5Tjg7xcclxuICAgICAgICAgIGZvciAobGV0IGltZyBvZiBpdGVtLmltYWdlcykge1xyXG4gICAgICAgICAgICBsZXQgaW1nU3JjID0gYCR7Y29uZmlnLmltYWdlZGlyfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIGxldCBpbWdUZ3QgPSBgJHtjZH0vJHtpbWd9YFxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIC8vIOWQjOOBmOODleOCoeOCpOODq+OBjOOBguOCi+WgtOWQiOOBr+OCs+ODlOODvOOBl+OBquOBhFxyXG4gICAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYWNjZXNzKGltZ1RndClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEuY29weUZpbGUoaW1nU3JjLCBpbWdUZ3QpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOe1guS6huaZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldEVuZCA9IGFzeW5jIChwYWNrZXRDb3VudCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgemlwID0gYXJjaGl2ZXIoJ3ppcCcpXHJcbiAgICAgICAgICBjb25zdCB6aXBuYW1lID0gYCR7dXBsb2FkZGlyfS8ke25hbWV9LnppcGBcclxuICAgICAgICAgIGNvbnN0IG91dHB1dCA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oemlwbmFtZSlcclxuICAgICAgICAgIHppcC5waXBlKG91dHB1dClcclxuICAgICAgICAgIHppcC5kaXJlY3RvcnkoY2QsIGZhbHNlKVxyXG4gICAgICAgICAgemlwLmZpbmFsaXplKClcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICAvLyBpdGVt44Gr5a6a576p44GV44KM44Gm44GE44KL5pyA5L2O5b+F6KaB5Zyo5bqr44KI44KK5aSa44GE5ZWG5ZOB44KS5Ye65ZOB44GZ44KLXHJcbiAgICAgICAgICAgIGlmIChxdWFudGl0eSA+PSBpdGVtLm1hbGwueWF1Y3QubWluUXVhbnRpdHkpIHtcclxuICAgICAgICAgICAgICBsZXQgeWF1Y3QgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVlhdWN0KGNvbmZpZy5kZWZhdWx0LCBpdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IHBhY2tldC5zdWJtaXQoe3lhdWN0OiB5YXVjdCwgaXRlbTogaXRlbX0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICBwYWNrZXQuY2xvc2UoKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgJy4uL2ltcG9ydHMvY29sbGVjdGlvbnMnXHJcbmltcG9ydCAnLi9yb3V0ZS91cGxvYWQvaW1hZ2UnXHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0JztcclxuaW1wb3J0IG1vYmplY3QgZnJvbSAnbW9uZ29vYmplY3QnO1xyXG5pbXBvcnQgeyBHcm91cEJhc2UgfSBmcm9tICcuL2dyb3Vwcyc7XHJcblxyXG5jb25zdCBGaWx0ZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2ZpbHRlcnMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEZpbHRlciBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGZpbHRlcklkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBGaWx0ZXJzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGZpbHRlcklkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcblxyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKCBvblJlc3VsdCA9IChyZWNvcmQpPT57fSwgb25FcnJvciA9IChlKT0+e30gKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG5cclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGxhdGZvcm0gdHlwZScpO1xyXG5cclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7eyBmaWx0ZXJUeXBlOiBhc3luYyAocmVjb3JkICkgPT4ge30gfX0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoKGNhbGxiYWNrcyA9IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGUoKTtcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICB0eXBlOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnQgPSB7fTtcclxuICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgY291bnRbZmlsdGVyLnR5cGVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmaWx0ZXIucXVlcnksXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCk9PntcclxuICAgICAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgICAgICBsZXQgcXVlcnkgPSBtb2JqZWN0LnVuZXNjYXBlKGZpbHRlci5xdWVyeSk7XHJcbiAgICAgICAgICBsZXQgZXhhbSA9IHNpZnQoIHF1ZXJ5ICk7XHJcbiAgICAgICAgICBpZiggZXhhbShyZWNvcmQpICl7XHJcbiAgICAgICAgICAgIGNvdW50W2ZpbHRlci50eXBlXS5jb3VudCsrO1xyXG4gICAgICAgICAgICBpZiggdHlwZW9mIGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0gIT09ICd1bmRlZmluZWQnKXtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFja3NbZmlsdGVyLnR5cGVdKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICBvbkVycm9yXHJcbiAgICApO1xyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnQ7XHJcblxyXG4gIH1cclxuXHJcbn1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbmNvbnN0IEdyb3VwcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdncm91cHMnLCB7XHJcbiAgaWRHZW5lcmF0aW9uOiAnTU9OR08nXHJcbn0pO1xyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwQmFzZSB7XHJcblxyXG4gIHByb2ZpbGU7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHByb2ZpbGUpIHtcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBnZXRzICdQbHVnJyB3aXRjaCBpcyBhIHNldCBvZiBwcm9wZXJ0aWVzIG5lZWRlZFxyXG4gICAqIHdoZW4gY29ubmVjdCB0byBzb21lIHBsYXRmb3Jtc1xyXG4gICAqIHRvIGdldCBkYXRhcyhNZW1iZXJzIG9mIHRoZSBHcm91cClcclxuICAgKi9cclxuICBnZXRQbHVnKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZS5wbGF0Zm9ybVBsdWc7XHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZTtcclxuICB9XHJcblxyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge307XHJcblxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXAgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3Rvcihncm91cElkKSB7XHJcblxyXG4gICAgbGV0IHByb2ZpbGUgPSBHcm91cHMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZ3JvdXBJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChwbHVnLmNyZWQpO1xyXG4gICAgICAgIHRoaXMuaW1wb3J0ID0gYXN5bmMgKGRvYykgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX0gV0hFUkUgXFxgJHtkb2Mua2V5fVxcYCA9IFwiJHtkb2MuaWR9XCJgO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKTtcclxuICAgICAgICB9O1xyXG4gICAgICAgIGJyZWFrO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBncm91cCB0eXBlJyk7XHJcbiAgICB9XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIEBwYXJhbSB7YXN5bmMgKHJlY29yZCk9PnZvaWR9IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7XHJcblxyXG4gICAgbGV0IGN1ciA9IEdyb3Vwcy5maW5kKHtcclxuICAgICAgZ3JvdXBJZDogdGhpcy5wcm9maWxlLl9pZFxyXG4gICAgfSwge1xyXG4gICAgICBmaWVsZHM6IHtcclxuICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgaWQ6IDEsXHJcbiAgICAgICAga2V5OiAxXHJcbiAgICAgIH1cclxuICAgIH0pO1xyXG5cclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIFxyXG4gICAgICAgIGN1ci5mb3JFYWNoKFxyXG4gICAgICAgICAgYXN5bmMgKGRvYywgaW5kZXgpID0+IHtcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVjb3JkID0gYXdhaXQgdGhpcy5pbXBvcnQoZG9jKTtcclxuICAgICAgICAgICAgICBhd2FpdCBjYWxsYmFjayhyZWNvcmQpO1xyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgb25FcnJvcihlKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBpZiAoaW5kZXggKyAxID09PSBjdXIuY291bnQoKSkge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcblxyXG4gICAgICB9XHJcbiAgICApLmNhdGNoKFxyXG4gICAgICAoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcbn0iLCJpbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XG5pbXBvcnQgc3luY09iamVjdCBmcm9tICcuLi91dGlsL3N5bmNPYmplY3QnO1xuXG5leHBvcnQgY2xhc3MgQ3ViZTNBcGkge1xuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHtNeVNRTH0gbXlzcWxcbiAgICovXG4gIGNvbnN0cnVjdG9yKG15c3FsKSB7XG4gICAgdGhpcy5teXNxbCA9IG15c3FsO1xuICB9XG5cbiAgYXN5bmMgbW9kaWZ5Q2F0ZWdvcnkocHJvZHVjdElkLCBjYXRlZ29yeUlkQXJyYXkpIHtcbiAgICBjb25zdCB0YWJsZUNhdGVnb3J5ID0gJ2R0Yl9wcm9kdWN0X2NhdGVnb3J5JztcblxuICAgIC8vIOWVhuWTgeaDheWgseODh+ODvOOCv+ODmeODvOOCueOBq+iomOmMsuOBleOCjOOBn+WVhuWTgeOCq+ODhuOCtOODquODvOaDheWgsVxuICAgIGNvbnN0IGNvbFNyYyA9IFtdO1xuICAgIGNhdGVnb3J5SWRBcnJheS5mb3JFYWNoKChlbGVtKSA9PiB7XG4gICAgICBjb2xTcmMucHVzaCh7XG4gICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcbiAgICAgICAgY2F0ZWdvcnlfaWQ6IGVsZW0sXG4gICAgICB9KTtcbiAgICB9KTtcblxuICAgIC8vIOODouODvOODq+ODh+ODvOOCv+ODmeODvOOCueOBi+OCieePvuWcqOOBruWVhuWTgeOCq+ODhuOCtOODquODvOaDheWgseOCkuWPluW+l1xuICAgIGNvbnN0IHNxbCA9IGBcbiAgICBTRUxFQ1QgcHJvZHVjdF9pZCwgY2F0ZWdvcnlfaWRcbiAgICBGUk9NICR7dGFibGVDYXRlZ29yeX1cbiAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtwcm9kdWN0SWR9XG4gICAgYDtcblxuICAgIC8vIGNvbnN0IGNvbERzdCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpKSk7XG4gICAgY29uc3QgY29sRHN0ID0gYXdhaXQgdGhpcy5teXNxbC5xdWVyeVNlbGVjdChcbiAgICAgIHRhYmxlQ2F0ZWdvcnksXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7cHJvZHVjdElkfWAsXG4gICAgICAncHJvZHVjdF9pZCwgY2F0ZWdvcnlfaWQnLFxuICAgICk7XG5cbiAgICAvLyDlkIRTUUzjgq/jgqjjg6rjga7ntZDmnpzjgZnjgbnjgabjgpLoqJjpjLLjgZnjgotcbiAgICBjb25zdCByZXN1bHRzID0gW107XG5cbiAgICBhd2FpdCBzeW5jT2JqZWN0KFxuICAgICAgY29sU3JjLCBjb2xEc3QsIG51bGwsXG4gICAgICBhc3luYyAoaWQsIG9iamVjdCkgPT4ge1xuICAgICAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5SW5zZXJ0KFxuICAgICAgICAgIHRhYmxlQ2F0ZWdvcnksXG4gICAgICAgICAge30sXG4gICAgICAgICAgT2JqZWN0LmFzc2lnbih7IHJhbms6IDEgfSwgb2JqZWN0KSxcbiAgICAgICAgKTtcbiAgICAgICAgcmVzdWx0cy5wdXNoKHJlcyk7XG4gICAgICB9LFxuICAgICAgYXN5bmMgKGlkLCBvYmplY3QpID0+IHtcbiAgICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5teXNxbC5xdWVyeShcbiAgICAgICAgICBgXG4gICAgICAgICAgREVMRVRFIEZST00gJHt0YWJsZUNhdGVnb3J5fVxuICAgICAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke29iamVjdC5wcm9kdWN0X2lkfVxuICAgICAgICAgICAgQU5EIGNhdGVnb3J5X2lkID0gJHtvYmplY3QuY2F0ZWdvcnlfaWR9XG4gICAgICAgICAgYCxcbiAgICAgICAgKTtcbiAgICAgICAgcmVzdWx0cy5wdXNoKHJlcyk7XG4gICAgICB9LFxuICAgICk7XG5cbiAgICByZXR1cm4gcmVzdWx0cztcbiAgfVxuXG4gIGFzeW5jIHVwZGF0ZVN0b2NrKHByb2R1Y3RDbGFzc0lkLCBxdWFudGl0eSA9IDApIHtcbiAgICBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5VXBkYXRlKFxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcbiAgICAgIGBwcm9kdWN0X2NsYXNzX2lkID0gJHtwcm9kdWN0Q2xhc3NJZH1gLFxuICAgICAge30sIHtcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgfSxcbiAgICApO1xuXG4gICAgYXdhaXQgdGhpcy5teXNxbC5xdWVyeVVwZGF0ZShcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcbiAgICAgIHt9LCB7XG4gICAgICAgIHN0b2NrOiBxdWFudGl0eSxcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICB9LFxuICAgICk7XG4gIH1cblxuICBhc3luYyBwcm9kdWN0VGFnVXBkYXRlKGRhdGEpIHtcbiAgICBjb25zdCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWQ7XG5cbiAgICBjb25zdCByZXMgPSBbXTtcblxuICAgIC8vIOWJiumZpOOBmeOCi+OCv+OCsFxuICAgIGNvbnN0IHRhZ29mZiA9IGFzeW5jICh0YWcpID0+IHtcbiAgICAgIGNvbnN0IHNxbCA9IGBcbiAgICAgIERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxuICAgICAgYDtcbiAgICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKSk7XG4gICAgfTtcblxuICAgIC8vIOihqOekuuOBmeOCi+OCv+OCsFxuICAgIGNvbnN0IHRhZ29uID0gYXN5bmMgKHRhZykgPT4ge1xuICAgICAgLy8g44GZ44Gn44Gr6KGo56S644GV44KM44Gm44GE44KL44K/44Kw44GM44GC44KM44Gw5L2V44KC44GX44Gq44GEXG4gICAgICBjb25zdCBzcWwgPSBgXG4gICAgICBTRUxFQ1QgQ09VTlQoKikgRlJPTSBkdGJfcHJvZHVjdF90YWcgXG4gICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9IEFORCB0YWcgPSAke3RhZ31cbiAgICAgIGA7XG4gICAgICBjb25zdCBjb3VudFJlcyA9IGF3YWl0IHRoaXMubXlzcWwucXVlcnkoc3FsKTtcbiAgICAgIGlmIChjb3VudFJlc1swXVsnQ09VTlQoKiknXSkgcmV0dXJuO1xuXG4gICAgICByZXMucHVzaChcbiAgICAgICAgYXdhaXQgdGhpcy5teXNxbC5xdWVyeUluc2VydChcbiAgICAgICAgICAnZHRiX3Byb2R1Y3RfdGFnJyxcbiAgICAgICAgICB7fSxcbiAgICAgICAgICB7XG4gICAgICAgICAgICBwcm9kdWN0X2lkOiBkYXRhLnByb2R1Y3RfaWQsXG4gICAgICAgICAgICB0YWcsXG4gICAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXG4gICAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgICAgICB9LFxuICAgICAgICApLFxuICAgICAgKTtcbiAgICB9O1xuXG4gICAgZm9yIChjb25zdCB0YWdTZXQgb2YgZGF0YS50YWdzKSB7XG4gICAgICBzd2l0Y2ggKHRhZ1NldC5zZXQpIHtcbiAgICAgICAgY2FzZSAnb24nOlxuICAgICAgICAgIGF3YWl0IHRhZ29uKHRhZ1NldC50YWcpO1xuICAgICAgICAgIGJyZWFrO1xuICAgICAgICBjYXNlICdvZmYnOlxuICAgICAgICAgIGF3YWl0IHRhZ29mZih0YWdTZXQudGFnKTtcbiAgICAgICAgICBicmVhaztcbiAgICAgIH1cbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgcmVzLFxuICAgIH07XG4gIH1cblxuICBhc3luYyBwcm9kdWN0SW1hZ2VVcGRhdGUoZGF0YSkge1xuICAgIGNvbnN0IHByb2R1Y3RJZCA9IGRhdGEucHJvZHVjdF9pZDtcbiAgICBjb25zdCBpbWFnZXMgPSBkYXRhLmltYWdlcztcbiAgICBjb25zdCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWQ7XG5cbiAgICBjb25zdCByZXMgPSBbXTtcblxuICAgIC8vIOWVhuWTgeOBq+mWoumAo+OBmeOCi+OBmeOBueOBpuOBrueUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi1xuICAgIGNvbnN0IHNxbCA9IGBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF9pbWFnZSBXSEVSRSBwcm9kdWN0X2lkID0gJHtwcm9kdWN0SWR9YDtcbiAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCkpO1xuICAgIC8vIOaUueOCgeOBpueUu+WDj+OCkueZu+mMsuOBl+OBquOBiuOBmVxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XG4gICAgICBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5SW5zZXJ0KFxuICAgICAgICAnZHRiX3Byb2R1Y3RfaW1hZ2UnLCB7XG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxuICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcbiAgICAgICAgICBmaWxlX25hbWU6IGltYWdlc1tpXSxcbiAgICAgICAgICByYW5rOiBpICsgMSxcbiAgICAgICAgfSwge1xuICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgICB9LFxuICAgICAgKTtcbiAgICB9XG5cbiAgICByZXR1cm4ge1xuICAgICAgcmVzLFxuICAgIH07XG4gIH1cblxuICBhc3luYyBwcm9kdWN0VXBkYXRlKGRhdGEpIHtcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9O1xuICAgIGxldCBrZXlzID0gW107XG5cbiAgICAvLyBkdGJfcHJvZHVjdFxuXG4gICAga2V5cyA9IFtcbiAgICAgICdzdGF0dXMnLFxuICAgICAgJ25hbWUnLFxuICAgICAgJ25vdGUnLFxuICAgICAgJ2Rlc2NyaXB0aW9uX2xpc3QnLFxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXG4gICAgICAnc2VhcmNoX3dvcmQnLFxuICAgICAgJ2ZyZWVfYXJlYScsXG4gICAgXTtcbiAgICBmb3IgKGNvbnN0IGsgb2Yga2V5cykge1xuICAgICAgaWYgKGRhdGFba10pIHtcbiAgICAgICAgdXBkYXRlRGF0YVtrXSA9IGRhdGFba107XG4gICAgICB9XG4gICAgfVxuXG4gICAgLy8gW1xuICAgIC8vICAgJ3N0YXR1cycsXG4gICAgLy8gICAnbmFtZScsXG4gICAgLy8gICAnbm90ZScsXG4gICAgLy8gICAnZGVzY3JpcHRpb25fbGlzdCcsXG4gICAgLy8gICAnZGVzY3JpcHRpb25fZGV0YWlsJyxcbiAgICAvLyAgICdzZWFyY2hfd29yZCcsXG4gICAgLy8gICAnZnJlZV9hcmVhJyxcbiAgICAvLyBdLmZvckVhY2goXG4gICAgLy8gICAodikgPT4ge1xuICAgIC8vICAgICBpZiAoZGF0YVt2XSkge1xuICAgIC8vICAgICAgIHVwZGF0ZURhdGFbdl0gPSBkYXRhW3ZdO1xuICAgIC8vICAgICB9XG4gICAgLy8gICB9LFxuICAgIC8vICk7XG5cbiAgICBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5VXBkYXRlKFxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcbiAgICAgIHVwZGF0ZURhdGEsIHtcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICB9LFxuICAgICk7XG5cbiAgICAvLyBkdGJfcHJvZHVjdF9jbGFzc1xuXG4gICAgdXBkYXRlRGF0YSA9IHt9O1xuICAgIGtleXMgPSBbXG4gICAgICAnZGVsaXZlcnlfZGF0ZV9pZCcsXG4gICAgICAncHJvZHVjdF9jb2RlJyxcbiAgICAgICdzYWxlX2xpbWl0JyxcbiAgICAgICdwcmljZTAxJyxcbiAgICAgICdwcmljZTAyJyxcbiAgICAgICdkZWxpdmVyeV9mZWUnLFxuICAgIF07XG4gICAgZm9yIChjb25zdCBrIG9mIGtleXMpIHsgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdOyB9XG5cblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWwucXVlcnlVcGRhdGUoXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxuICAgICAgdXBkYXRlRGF0YSwge1xuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIHJldHVybiB7XG4gICAgICByZXMsXG4gICAgfTtcbiAgfVxuXG4gIGFzeW5jIHByb2R1Y3RDcmVhdGUoZGF0YSkge1xuICAgIGNvbnN0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZDtcblxuICAgIGNvbnN0IHJlcyA9IHt9O1xuXG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fTtcbiAgICBsZXQga2V5cyA9IFtdO1xuXG4gICAga2V5cyA9IFtcbiAgICAgICduYW1lJyxcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnLFxuICAgIF07XG4gICAgLy8ge1xuICAgIC8vICAgbmFtZTogaXRlbS5uYW1lLFxuICAgIC8vICAgZGVzY3JpcHRpb25fZGV0YWlsOiBpdGVtLmRlc2NyaXB0aW9uLFxuICAgIC8vIH0sXG5cbiAgICBmb3IgKGNvbnN0IGsgb2Yga2V5cykgeyBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba107IH1cblxuXG4gICAgcmVzLnByb2R1Y3RfaWQgPSBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5SW5zZXJ0KFxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcbiAgICAgIHVwZGF0ZURhdGEsIHtcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxuICAgICAgICBzdGF0dXM6IDEsXG4gICAgICAgIG5vdGU6ICdOVUxMJyxcbiAgICAgICAgZGVzY3JpcHRpb25fbGlzdDogJ05VTEwnLFxuICAgICAgICBzZWFyY2hfd29yZDogJ05VTEwnLFxuICAgICAgICBmcmVlX2FyZWE6ICdOVUxMJyxcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgfSxcbiAgICApO1xuXG4gICAgdXBkYXRlRGF0YSA9IHt9O1xuICAgIGtleXMgPSBbXG4gICAgICAncHJvZHVjdF9jb2RlJyxcbiAgICAgICdwcm9kdWN0X3R5cGVfaWQnLFxuICAgICAgJ3ByaWNlMDEnLFxuICAgICAgJ3ByaWNlMDInLFxuICAgICAgJ2RlbGl2ZXJ5X2ZlZScsXG4gICAgXTtcbiAgICAvLyB7XG4gICAgLy8gICBwcm9kdWN0X2NvZGU6IGl0ZW0ubW9kZWwsXG4gICAgLy8gICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcbiAgICAvLyAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UsXG4gICAgLy8gfSxcblxuICAgIGZvciAoY29uc3QgayBvZiBrZXlzKSB7IGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXTsgfVxuXG5cbiAgICByZXMucHJvZHVjdF9jbGFzc19pZCA9IGF3YWl0IHRoaXMubXlzcWwucXVlcnlJbnNlcnQoXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxuICAgICAgdXBkYXRlRGF0YSwge1xuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXG4gICAgICAgIHByb2R1Y3RfaWQ6IHJlcy5wcm9kdWN0X2lkLFxuICAgICAgICBzdG9jazogMCxcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDE6ICdOVUxMJyxcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQyOiAnTlVMTCcsXG4gICAgICAgIGRlbGl2ZXJ5X2RhdGVfaWQ6ICdOVUxMJyxcbiAgICAgICAgc2FsZV9saW1pdDogJ05VTEwnLFxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKScsXG4gICAgICB9LFxuICAgICk7XG5cbiAgICBmb3IgKGNvbnN0IGsgb2Yga2V5cykgeyBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba107IH1cblxuXG4gICAgcmVzLnByb2R1Y3Rfc3RvY2tfaWQgPSBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5SW5zZXJ0KFxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJywge30sIHtcbiAgICAgICAgcHJvZHVjdF9jbGFzc19pZDogcmVzLnByb2R1Y3RfY2xhc3NfaWQsXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcbiAgICAgICAgc3RvY2s6IDAsXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJyxcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIC8vIGZvciB0ZXN0XG4gICAgcmV0dXJuIHtcbiAgICAgIHJlcyxcbiAgICB9O1xuICB9XG59XG4iLCJpbXBvcnQge01vbmdvQ2xpZW50fSBmcm9tICdtb25nb2RiJ1xuaW1wb3J0IHJlcXVlc3QgZnJvbSAncmVxdWVzdC1wcm9taXNlJ1xuXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCdcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0J1xuaW1wb3J0IHsgeG1sMmpzIH0gZnJvbSAneG1sLWpzJ1xuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnXG5cbmV4cG9ydCBjbGFzcyBEQkZpbHRlckZhY3Rvcnkge1xuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xuICAgIGxldCBpbnN0YW5jZTtcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xuICAgICAgY2FzZSAnbXlzcWwnOlxuICAgICAgICBpbnN0YW5jZSA9IG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpO1xuICAgIH1cblxuICAgIHJldHVybiBpbnN0YW5jZTtcbiAgfVxufVxuXG5leHBvcnQgY2xhc3MgREJGaWx0ZXIge1xuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xuICAgIHRoaXMucGx1ZyA9IHBsdWc7XG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZTtcbiAgfVxuXG4gIHN0YXRpYyBmYWN0b3J5IChwbHVnLCBwcm9maWxlKSB7XG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcbiAgICAgIGNhc2UgJ215c3FsJzpcbiAgICAgICAgcmV0dXJuIG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsdWcgdHlwZScpO1xuICAgIH1cbiAgfVxuXG4gIGdldFBsdWdfICgpIHtcbiAgICByZXR1cm4gdGhpcy5wbHVnO1xuICB9XG5cbiAgZ2V0Q3JlZF8gKCkge1xuICAgIHJldHVybiB0aGlzLnBsdWcuY3JlZDtcbiAgfVxuXG4gIGdldFByb2ZpbGVfICgpIHtcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlO1xuICB9XG5cbiAgc2V0SW1wb3J0RnVuY3Rpb25fIChcbiAgICBmbiA9IGFzeW5jIChvblJlc3VsdCA9IChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gKGUpID0+IHt9KSA9PiB7fSxcbiAgKSB7XG4gICAgdGhpcy5pbXBvcnQgPSBmbjtcbiAgfVxuXG4gIC8qKlxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcbiAgICogdXNlYWdlOlxuICAgKlxuICAgKlxuICAgKiBAcGFyYW0geyBPYmplY3QgfSBpdGVyYXRvcnMgeyBmaWx0ZXJOYW1lOiBhc3luYyAoZG9jLGNvbnRleHQpPT57fSwgLi4uIH0gaXRlcmF0b3IgZm9yIGVhY2ggZmlsdGVyc1xuICAgKiBAcGFyYW0geyBhc3luYyBmdW5jdGlvbiB9IG9uRXJyb3IgZXJyb3IgaGFuZGxlciB3aGlsZSBpdGVyYXRpbmdcbiAgICogQHJldHVybnMgeyBPYmplY3QgfSB7IGZpbHRlck5hbWU6IHsgcXVlcnk6IGFueSwgY291bnQ6IG51bWJlciB9LCAuLi4gfVxuICAgKi9cbiAgYXN5bmMgZm9yZWFjaCAoaXRlcmF0b3JzID0ge30pIHtcbiAgICBjb25zdCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlXygpO1xuXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XG4gICAgICBuYW1lOiAnbWlzYycsXG4gICAgICBxdWVyeToge30sXG4gICAgfSk7XG5cbiAgICBjb25zdCBjb3VudGVyID0ge307XG4gICAgZm9yIChjb25zdCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xuICAgIH1cblxuICAgIGNvbnN0IGZpbHRlcnMgPSBbXTtcblxuICAgIGZvciAoY29uc3QgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcbiAgICAgIGNvdW50ZXJbZi5uYW1lXSA9IHtcbiAgICAgICAgcXVlcnk6IGYucXVlcnksXG4gICAgICAgIGxpbWl0OiB0eXBlb2YgZi5saW1pdCAhPT0gJ3VuZGVmaW5lZCcgPyBmLmxpbWl0IDogMCxcbiAgICAgICAgY291bnQ6IDAsXG4gICAgICB9O1xuICAgICAgZmlsdGVycy5wdXNoKFxuICAgICAgICB7XG4gICAgICAgICAgbmFtZTogZi5uYW1lLFxuICAgICAgICAgIGV4YW06IHNpZnQobW9iamVjdC51bmVzY2FwZShmLnF1ZXJ5KSksXG4gICAgICAgIH0sXG4gICAgICApO1xuICAgIH1cblxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxuICAgICAgYXN5bmMgKHJlY29yZCwgY29udGV4dCkgPT4ge1xuICAgICAgICBmb3IgKGNvbnN0IGYgb2YgZmlsdGVycykge1xuICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxuICAgICAgICAgIGNvbnN0IGMgPSBjb3VudGVyW2YubmFtZV07XG4gICAgICAgICAgaWYgKGMubGltaXQpIHtcbiAgICAgICAgICAgIGlmIChjLmNvdW50ID49IGMubGltaXQpIHtcbiAgICAgICAgICAgICAgY29udGludWU7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgfVxuXG4gICAgICAgICAgaWYgKGYuZXhhbShyZWNvcmQpKSB7XG4gICAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcbiAgICAgICAgICAgIGMuY291bnQrKztcblxuICAgICAgICAgICAgLy8gaXRlcmF0b3JcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlcmF0b3JzW2YubmFtZV0gIT09ICd1bmRlZmluZWQnKSB7XG4gICAgICAgICAgICAgIGF3YWl0IGl0ZXJhdG9yc1tmLm5hbWVdKHJlY29yZCwgY29udGV4dCk7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICBicmVhaztcbiAgICAgICAgICB9XG4gICAgICAgIH1cbiAgICAgIH1cbik7XG5cbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xuICAgIHJldHVybiBjb3VudGVyO1xuICB9XG59XG5cbmV4cG9ydCBjbGFzcyBNeXNxbERCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xuXG4gICAgY29uc3QgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcblxuICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwoY3JlZCk7XG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XG4gICAgICBjb25zdCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YDtcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgKGUpID0+IHsgdGhyb3cgZTsgfSk7XG4gICAgICByZXR1cm4gcmVzO1xuICAgIH0pO1xuICB9XG59XG5cbi8vIGltcG9ydCBNb25nb05hdGl2ZSBmcm9tICdtb25nb2RiJztcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gTW9uZ29OYXRpdmUuTW9uZ29DbGllbnQ7XG4vLyBjb25zdCBNb25nb0NsaWVudCA9IHJlcXVpcmUoJ21vbmdvZGInKS5Nb25nb0NsaWVudDtcblxuZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XG5cbiAgICAvLyBtb25nbyDjgbjmjqXntppcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcbiAgICAgIGxldCBjbGllbnQ7XG4gICAgICBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpLCB7IHVzZU5ld1VybFBhcnNlcjogdHJ1ZSB9KTtcblxuICAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5Y+W5b6XXG4gICAgICBjb25zdCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKTtcbiAgICAgIGNvbnN0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XG5cbiAgICAgIGNvbnN0IGNvbnRleHQgPSB7XG4gICAgICAgIGNsaWVudCxcbiAgICAgICAgY29sbGVjdGlvbixcbiAgICAgICAgZGF0YWJhc2U6IGRiLFxuICAgICAgfTtcblxuICAgICAgY29uc3QgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XG5cbiAgICAgIC8vIOOCq+ODvOOCveODq+OBruOCv+OCpOODoOOCouOCpuODiOOCkuino+mZpFxuICAgICAgY3VyLmFkZEN1cnNvckZsYWcoJ25vQ3Vyc29yVGltZW91dCcsIHRydWUpO1xuXG4gICAgICAvLyDjgZnjgbnjgabjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgpLjg6vjg7zjg5dcbiAgICAgIHRyeSB7XG4gICAgICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XG4gICAgICAgICAgY29uc3QgZG9jID0gYXdhaXQgY3VyLm5leHQoKTtcbiAgICAgICAgICBhd2FpdCBvblJlc3VsdChkb2MsIGNvbnRleHQpO1xuICAgICAgICB9XG4gICAgICB9IGZpbmFsbHkge1xuICAgICAgICAvLyDjgqvjg7zjgr3jg6vjgpLplovmlL5cbiAgICAgICAgYXdhaXQgY3VyLmNsb3NlKCk7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn1cblxuZXhwb3J0IGNsYXNzIFdvd21hQXBpSXRlbUZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcblxuICAgIC8vIOWVhuWTgeaDheWgseOBruWPluW+l+ODq+ODvOODl+OCkuWumue+qVxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xuICAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5Y+W5b6XXG4gICAgICBjb25zdCBvcHRpb25zID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShwbHVnKSk7XG4gICAgICBvcHRpb25zLnVyaSA9IGAke29wdGlvbnMudXJpfS9zZWFyY2hTdG9ja3NgO1xuICAgICAgY29uc3QgY29udGV4dCA9IHtcbiAgICAgICAgb3B0aW9ucyxcbiAgICAgIH07XG5cbiAgICAgIHdoaWxlICgxKSB7XG4gICAgICAgIC8vIFdvd21hIEFwaSDjgYvjgonllYblk4Hmg4XloLHjgpLlj5blvpdcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3Qob3B0aW9ucyk7XG4gICAgICAgIHJlcyA9IHhtbDJqcyhyZXMsIHsgY29tcGFjdDogdHJ1ZSB9KTtcblxuICAgICAgICBjb25zdCBtYXhDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0Lm1heENvdW50Ll90ZXh0KTtcbiAgICAgICAgY29uc3QgcmVzdWx0Q291bnQgPSBOdW1iZXIocmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5yZXN1bHRDb3VudC5fdGV4dCk7XG4gICAgICAgIGNvbnN0IHN0YXJ0Q291bnQgPSBOdW1iZXIocmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5zdGFydENvdW50Ll90ZXh0KTtcbiAgICAgICAgY29uc3QgcmVzdWx0U3RvY2tzID0gcmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5yZXN1bHRTdG9ja3M7XG5cbiAgICAgICAgLy8g5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS44Kr44K544K/44Og44OX44Ot44K744K544Gr5rih44GZXG4gICAgICAgIGlmIChyZXN1bHRTdG9ja3MgaW5zdGFuY2VvZiBBcnJheSkge1xuICAgICAgICAgIC8vIOWPluW+l+OBl+OBn+ODh+ODvOOCv+OBjOikh+aVsOWVhuWTgeOBruWgtOWQiFxuICAgICAgICAgIGZvciAobGV0IGkgPSAwOyBpIDwgcmVzdWx0Q291bnQ7IGkrKykge1xuICAgICAgICAgICAgYXdhaXQgb25SZXN1bHQocmVzdWx0U3RvY2tzW2ldLCBjb250ZXh0KTtcbiAgICAgICAgICB9XG4gICAgICAgIH0gZWxzZSB7XG4gICAgICAgICAgLy8g5Y+W5b6X44GX44Gf44OH44O844K/44GM5Y2Y5pWw5ZWG5ZOB44Gu5aC05ZCIXG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQocmVzdWx0U3RvY2tzLCBjb250ZXh0KTtcbiAgICAgICAgfVxuXG4gICAgICAgIGNvbnN0IG5leHQgPSBzdGFydENvdW50ICsgcmVzdWx0Q291bnQ7XG5cbiAgICAgICAgaWYgKG5leHQgPiBtYXhDb3VudCkgYnJlYWs7XG4gICAgICAgIG9wdGlvbnMucXMuc3RhcnRDb3VudCA9IG5leHQ7XG4gICAgICB9XG4gICAgfSk7XG4gIH1cbn1cblxuLy8gaW1wb3J0IG1vbmdvb3NlIGZyb20gJ21vbmdvb3NlJztcblxuLy8gZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XG4vLyAgIGNvbnN0cnVjdG9yKHBsdWcsIHByb2ZpbGUpIHtcbi8vICAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcblxuLy8gICAgIC8vIG1vbmdvIOOBuOaOpee2mlxuLy8gICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpO1xuLy8gICAgIGxldCBjb251cmkgPSBgbW9uZ29kYjovLyR7Y3JlZC5ob3N0fToke2NyZWQucG9ydH0vJHtjcmVkLmRhdGFiYXNlfWA7XG4vLyAgICAgYXdhaXQgbW9uZ29vc2UuY29ubmVjdChjb251cmkpO1xuXG4vLyAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5L2c44KLXG4vLyAgICAgbGV0IGNvbGxlY3Rpb24gPSBtb25nb29zZS5jb25uZWN0aW9uLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKTtcblxuLy8gICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xuLy8gICAgICAgbGV0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpO1xuXG4vLyAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcbi8vICAgICB9KTtcbi8vICAgfVxuLy8gfVxuIiwiaW1wb3J0IHsgTW9uZ29Db2xsZWN0aW9uIH0gZnJvbSAnLi4vdXRpbC9tb25nbyc7XG5pbXBvcnQgeyBVcGxvYWRzLCBSb2JvdGluU2hvcCB9IGZyb20gJy4uL2NvbGxlY3Rpb25zJztcbmltcG9ydCBUZXh0VXRpbCBmcm9tICcuLi91dGlsL3RleHQnO1xuXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtQ29udHJvbGxlciB7XG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0ge3t1cmk6c3RyaW5nLCBkYXRhYmFzZTpzdHJpbmcsIGNvbGxlY3Rpb246c3RyaW5nfX0gcGx1Z1xuICAgKi9cbiAgYXN5bmMgaW5pdChwbHVnKSB7XG4gICAgdGhpcy5JdGVtcyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ2l0ZW1zJyk7XG4gICAgdGhpcy5Qcm9kdWN0cyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ3Byb2R1Y3RzJyk7XG4gIH1cblxuICBhc3luYyBnZXRTdG9jayhpdGVtSWQpIHtcbiAgICBjb25zdCBpdGVtID0gYXdhaXQgdGhpcy5JdGVtcy5maW5kT25lKHtcbiAgICAgIF9pZDogaXRlbUlkLFxuICAgIH0sIHtcbiAgICAgIHByb2plY3Rpb246IHtcbiAgICAgICAgcHJvZHVjdDogMSxcbiAgICAgIH0sXG4gICAgfSk7XG4gICAgY29uc3QgcHJvZHVjdFNldCA9IGl0ZW0ucHJvZHVjdDtcblxuICAgIC8vIHByb2R1Y3QgKiA8LT4gKiBpdGVtXG4gICAgLy8gcHJvZHVjdFtdOiDopIfmlbDjga7llYblk4HjgpIx44OR44OD44Kx44O844K444Go44GX44Gm6LKp5aOyXG4gICAgLy8gcHJvZHVjdFt7aWRzOls8T2JqZWN0SWQ+XSxzZXQ6PE51bWJlcj59XTog55Ww44Gq44KL5rWB6YCa57WM6Lev44CB55Ww44Gq44KL5Y6f5L6h44O75LuV5YWl44KM5YCkXG4gICAgLy8gaXRlbTog55Ww44Gq44KL44K744O844Or44CB6LKp5aOy5b2i5oWLXG4gICAgLy8g4oC7IHByb2R1Y3Qg44GL44KJ44Gv44CB6LKp5aOy5Y+v6IO944Gq5Zyo5bqr44CB5Yip55uK6KiI566X44Gu44Gf44KB44Gu5oOF5aCx44KS5b6X44KLXG5cbiAgICBjb25zdCBxdWFudGl0aWVzID0gW107XG5cbiAgICBmb3IgKGNvbnN0IHByb2R1Y3RSZWYgb2YgcHJvZHVjdFNldCkge1xuICAgICAgbGV0IHByZFF1YW50aXR5ID0gMDtcblxuICAgICAgZm9yIChjb25zdCBpZCBvZiBwcm9kdWN0UmVmLmlkcykge1xuICAgICAgICBjb25zdCBwcm9kdWN0ID0gYXdhaXQgdGhpcy5Qcm9kdWN0cy5maW5kT25lKHtcbiAgICAgICAgICBfaWQ6IGlkLFxuICAgICAgICB9LCB7XG4gICAgICAgICAgcHJvamVjdGlvbjoge1xuICAgICAgICAgICAgc3RvY2s6IDEsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSk7XG4gICAgICAgIGNvbnN0IHN0b2NrQXJyYXkgPSBwcm9kdWN0LnN0b2NrO1xuXG4gICAgICAgIC8vIOWNmOe0lOOBq+OBmeOBueOBpuOBruWcqOW6q+WVhuWTgeOAgeefreacn+mWk+WPluOCiuWvhOOBm+WPr+iDveWVhuWTgeOCkuWQiOeul1xuICAgICAgICBmb3IgKGNvbnN0IHN0b2NrIG9mIHN0b2NrQXJyYXkpIHByZFF1YW50aXR5ICs9IHN0b2NrLnF1YW50aXR5O1xuICAgICAgfVxuXG4gICAgICAvLyDllYblk4EoaXRlbSnjga7lnKjluqvmlbAgPSDoo73lk4HlnKjluqvmlbAocHJkUXVhbnRpdHkpIC8g5b+F6KaB44K744OD44OI5pWwKHByb2R1Y3RSZWYuc2V0KVxuICAgICAgcXVhbnRpdGllcy5wdXNoKE1hdGguZmxvb3IocHJkUXVhbnRpdHkgLyBwcm9kdWN0UmVmLnNldCkpO1xuICAgIH1cblxuICAgIC8vIOOCu+ODg+ODiOWVhuWTgeOBruWgtOWQiOOAgeS4gOeVquWwkeOBquOBhOWVhuWTgeaVsOOBq+WQiOOCj+OBm+OCi1xuICAgIGNvbnN0IHF1YW50aXR5ID0gTWF0aC5taW4uYXBwbHkobnVsbCwgcXVhbnRpdGllcyk7XG5cbiAgICByZXR1cm4gcXVhbnRpdHk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44KL44CCXG4gICAqXG4gICAqIOODoeODvOOCq+ODvOODouODh+ODq+OBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxuICAgKiBjbGFzczHjgIFjbGFzczLlvJXmlbDjgpLmjIflrprjgZvjgZrjgavlrp/ooYzjgZnjgovjgIJcbiAgICpcbiAgICog54m55a6a44Gu5bGe5oCn77yI44Kr44Op44O844Gq44Gp77yJ44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXG4gICAqIGNsYXNzMeOBq+WApOOCkuaMh+WumuOBl+OAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxuICAgKiDjgoLjgZdjbGFzczLjga7jgb/mjIflrprjgZfjgZ/jgYTloLTlkIjjga9jbGFzczHjgatudWxs44KS5oyH5a6a44GZ44KL44CCXG4gICAqXG4gICAqIOS+i++8mkpLLTEwMOOBrkJMQUNL44Gu5ZWG5ZOB55S75YOP44KSXG4gICAqIOOBmeOBueOBpuOBruOCteOCpOOCuu+8iFMsTSxMLFhMLDJYTCwzWEwsNFhM4oCm77yJ44Gr6Zai6YCj5LuY44GR44KL5aC05ZCIXG4gICAqIHNldEltYWdlKCB1cGxvYWRJZCwgJ0pLLTEwMCcsICdCTEFDSycgKTtcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IHVwbG9hZElkIOS4gOWbnuOBruOCouODg+ODl+ODreODvOODieeUu+WDj+OCkuadn+OBreOBpuOBhOOCi0lE44CCbWV0ZW9y44OH44O844K/44OZ44O844K544CBVXBsb2Fkc+OCs+ODrOOCr+OCt+ODp+ODs+WGheODieOCreODpeODoeODs+ODiOOBrnVwbG9hZElk44OX44Ot44OR44OG44KjXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcbiAgICovXG4gIGFzeW5jIHNldEltYWdlKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xuICAgIC8vIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OBruaDheWgseWPluW+l1xuICAgIGNvbnN0IGltYWdlcyA9IFVwbG9hZHMuZmluZCh7XG4gICAgICB1cGxvYWRJZCxcbiAgICB9KS5mZXRjaCgpLm1hcCh2ID0+IHYudXBsb2FkZWRGaWxlTmFtZSk7XG5cbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcbiAgICBjb25zdCBmaWx0ZXIgPSB7fTtcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbDtcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxO1xuICAgIGlmIChjbGFzczIpIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczI7XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXG4gICAgICBmaWx0ZXIsIHtcbiAgICAgICAgJHB1c2g6IHtcbiAgICAgICAgICBpbWFnZXM6IHtcbiAgICAgICAgICAgICRlYWNoOiBpbWFnZXMsXG4gICAgICAgICAgfSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgKTtcblxuICAgIC8vIOeZu+mMsuOBl+OBn+eUu+WDj+ODleOCoeOCpOODq+WQjeS4gOimp1xuICAgIHJldHVybiBpbWFnZXM7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavnmbvpjLLjgZXjgozjgabjgYTjgovnlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgovjgIJcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xuICAgKi9cbiAgYXN5bmMgY2xlYW5JbWFnZShtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxuICAgIGNvbnN0IGZpbHRlciA9IHt9O1xuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsO1xuICAgIGlmIChjbGFzczEpIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczE7XG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMjtcblxuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcbiAgICAgIGZpbHRlciwge1xuICAgICAgICAkc2V0OiB7XG4gICAgICAgICAgaW1hZ2VzOiBbXSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgKTtcbiAgfVxuXG4gIC8qKlxuICAgKiDmjIflrprjga7llYblk4HjgavplqLpgKPjgZnjgovllYblk4HnvqTjga7lsZ7mgKfliKXjga7llYblk4Hmg4XloLHjgpLov5TjgZnjgIJcbiAgICpcbiAgICog5byV5pWw44Go44GX44Gm5Y+X44GR5Y+W44KLaXRlbeOBr+S7u+aEj+OBruWVhuWTgeaDheWgseOAglxuICAgKiBpdGVt44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gr44Gk44GE44Gm5b+F6KaB44Gq5oOF5aCx44KS5pW055CG44GX6L+U44GZ44CCXG4gICAqXG4gICAqIHByb2plY3Tjgavlj4LnhafjgZfjgZ/jgYTllYblk4Hmg4XloLHjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZnjgovjgIJcbiAgICog44Oh44K944OD44OJ44Gu5ZG844Gz5Ye644GX5pmC44Gr5b+F6KaB44Gr5b+c44GY44GmcHJvamVjdOOCkuioreWumuOBmeOCi+OAglxuICAgKlxuICAgKiDkvZXjgavms6jnm67jgZfjgabllYblk4Hjga7plqLpgKPmgKfjgpLmpJzlh7rjgZnjgovjgYvjga/jgIHjgZPjga7jg6Hjgr3jg4Pjg4nlhoXjgaflrprnvqnjgZnjgovjgIJcbiAgICpcbiAgICogQHBhcmFtIHtPYmplY3R9IGl0ZW1cbiAgICogQHBhcmFtIHtPYmplY3R9IHByb2plY3RcbiAgICovXG4gIGFzeW5jIGdldFZhcmlhdGlvbihpdGVtLCBwcm9qZWN0KSB7XG4gICAgLyoqXG4gICAgICogYWdncmVnYXRpb27oqK3lrppcbiAgICAgKlxuICAgICAqIGxhYmVsOiDlsZ7mgKflkI3vvIjphY3pgIHmlrnms5XjgIHjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganvvIlcbiAgICAgKiBjdXJyZW50OiDmjIflrprjgZXjgozjgZ/jgqLjgqTjg4bjg6DvvIhpdGVt77yJ44GM6Kmy5b2T44GZ44KL6aCF55uuXG4gICAgICogcG9yamVjdDog44OQ44Oq44Ko44O844K344On44Oz5qSc57Si44Gu44Kt44O844Go44Gq44KLaXRlbeWGheOBruODleOCo+ODvOODq+ODieWQjSAkW+ODleOCo+ODvOODq+ODieWQjV3lvaLlvI9cbiAgICAgKiBxdWVyeTogYWdncmVnYXRpb27lr77osaHjgajjgZnjgovjg4njgq3jg6Xjg6Hjg7Pjg4jjga7mpJzntKLmnaHku7ZcbiAgICAgKi9cbiAgICBjb25zdCBzZXQgPSBbe1xuICAgICAgbGFiZWw6ICfphY3pgIHmlrnms5UnLFxuICAgICAgY3VycmVudDogaXRlbS5kZWxpdmVyeSxcbiAgICAgIHByb2plY3Q6IHtcbiAgICAgICAgdmFsdWU6ICckZGVsaXZlcnknLFxuICAgICAgfSxcbiAgICAgIHF1ZXJ5OiB7XG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWUsXG4gICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWUsXG4gICAgICB9LFxuICAgIH0sXG4gICAge1xuICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MxX25hbWUsXG4gICAgICBjdXJyZW50OiBpdGVtLmNsYXNzMV92YWx1ZSxcbiAgICAgIHByb2plY3Q6IHtcbiAgICAgICAgdmFsdWU6ICckY2xhc3MxX3ZhbHVlJyxcbiAgICAgIH0sXG4gICAgICBxdWVyeToge1xuICAgICAgICBkZWxpdmVyeTogaXRlbS5kZWxpdmVyeSxcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZSxcbiAgICAgIH0sXG4gICAgfSxcbiAgICB7XG4gICAgICBsYWJlbDogaXRlbS5jbGFzczJfbmFtZSxcbiAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MyX3ZhbHVlLFxuICAgICAgcHJvamVjdDoge1xuICAgICAgICB2YWx1ZTogJyRjbGFzczJfdmFsdWUnLFxuICAgICAgfSxcbiAgICAgIHF1ZXJ5OiB7XG4gICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxuICAgICAgICBjbGFzczFfdmFsdWU6IGl0ZW0uY2xhc3MxX3ZhbHVlLFxuICAgICAgfSxcbiAgICB9LFxuICAgIF07XG5cbiAgICBjb25zdCBhdHRycyA9IFtdO1xuXG4gICAgZm9yIChjb25zdCBzIG9mIHNldCkge1xuICAgICAgYXR0cnMucHVzaCh7XG4gICAgICAgIHZhcmlhdGlvbnM6IGF3YWl0IHRoaXMuSXRlbXMuYWdncmVnYXRlKFxuICAgICAgICAgIFt7XG4gICAgICAgICAgICAkbWF0Y2g6IE9iamVjdC5hc3NpZ24ocy5xdWVyeSwge1xuICAgICAgICAgICAgICBtb2RlbDogaXRlbS5tb2RlbCxcbiAgICAgICAgICAgIH0pLFxuICAgICAgICAgIH0sXG4gICAgICAgICAge1xuICAgICAgICAgICAgJHByb2plY3Q6IE9iamVjdC5hc3NpZ24ocy5wcm9qZWN0LCBwcm9qZWN0KSxcbiAgICAgICAgICB9LFxuICAgICAgICAgIHtcbiAgICAgICAgICAgICRzb3J0OiB7XG4gICAgICAgICAgICAgIF9pZDogMSxcbiAgICAgICAgICAgIH0sXG4gICAgICAgICAgfSxcbiAgICAgICAgICBdLFxuICAgICAgICApLnRvQXJyYXkoKSxcbiAgICAgICAgcHJvcHM6IHMsXG4gICAgICB9KTtcbiAgICB9XG5cbiAgICBmb3IgKGNvbnN0IGF0dHIgb2YgYXR0cnMpIGZvciAoY29uc3QgdiBvZiBhdHRyLnZhcmlhdGlvbnMpIHYuc3RvY2sgPSBhd2FpdCB0aGlzLmdldFN0b2NrKHYuX2lkKTtcblxuXG4gICAgcmV0dXJuIGF0dHJzO1xuICB9XG5cbiAgLy8g44Oi44OH44Or44Kv44Op44K55b2i5byP44KS5L2c44KLXG4gIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cbiAgYXN5bmMgZ2V0TW9kZWxDbGFzcyhhcmcpIHtcbiAgICBsZXQgaXRlbTtcbiAgICAvLyBpdGVtIOOBjOaWh+Wtl+WIl+OBquOCieOAgWl0ZW3jga/ku7vmhI/jga7jgqrjg5bjgrjjgqfjgq/jg4hJROOBruacq+WwvuOBi+OCieS7u+aEj+OBruahgeaVsOOBrjE26YCy5pWwXG4gICAgaWYgKHR5cGVvZiBhcmcgPT09ICdzdHJpbmcnKSB7XG4gICAgICBjb25zdCBleHAgPSBuZXcgUmVnRXhwKGAke2FyZ30kYCk7XG4gICAgICBjb25zdCBjdXIgPSB0aGlzLkl0ZW1zLmZpbmQoe30sIHtcbiAgICAgICAgcHJvamVjdGlvbjoge1xuICAgICAgICAgIG1vZGVsOiAxLFxuICAgICAgICAgIGNsYXNzMV92YWx1ZTogMSxcbiAgICAgICAgICBjbGFzczJfdmFsdWU6IDEsXG4gICAgICAgIH0sXG4gICAgICB9KTtcblxuICAgICAgd2hpbGUgKDEpIHtcbiAgICAgICAgdHJ5IHtcbiAgICAgICAgICBpdGVtID0gYXdhaXQgY3VyLm5leHQoKTtcbiAgICAgICAgICBjb25zdCBtYXRjaCA9IGF3YWl0IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkubWF0Y2goZXhwKTtcbiAgICAgICAgICBpZiAobWF0Y2gpIGJyZWFrO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8g6Kmy5b2T44GZ44KLaXRlbeODh+ODvOOCv+OBjOOBquOBhFxuICAgICAgICAgIGN1ci5jbG9zZSgpO1xuICAgICAgICAgIHJldHVybiBhcmc7XG4gICAgICAgIH1cbiAgICAgIH1cbiAgICAgIGN1ci5jbG9zZSgpO1xuICAgIH0gZWxzZSB7XG4gICAgICBpdGVtID0gYXJnO1xuICAgIH1cblxuICAgIGNvbnN0IG1vZGVsQ2xhc3MgPSBbXTtcbiAgICBpZiAoaXRlbS5tb2RlbCkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0ubW9kZWwpO1xuICAgIGlmIChpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKTtcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSk7XG4gICAgcmV0dXJuIG1vZGVsQ2xhc3Muam9pbignLycpO1xuICB9XG5cbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlMyhjb25maWdVcGxvYWRJdGVtLCBpdGVtKSB7XG4gICAgLy8g5YCk5aSJ5o+bXG4gICAgY29uc3QgY29udkRlbGl2ID0gZGVsaXZlcnkgPT4gKGRlbGl2ZXJ5ID09PSAn44KG44GG44OR44Kx44OD44OIJyA/ICfjg53jgrnjg4jmipXlh70nIDogZGVsaXZlcnkpO1xuXG4gICAgLy8gcHJvZHVjdF9pZFxuICAgIGNvbnN0IHByb2R1Y3RJZCA9IG51bGw7XG4gICAgY29uc3QgbW9kZWxDbGFzcyA9IFtdO1xuXG4gICAgLy8g5LiL6KiY44Gu5b2i5byP44KS5L2c44KLXG4gICAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxuICAgIGlmIChpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbCk7XG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpO1xuICAgIGlmIChpdGVtLmNsYXNzMl92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MyX3ZhbHVlKTtcblxuICAgIC8vIOWVhuWTgeeoruWIpeOCkuWJsuOCiuW9k+OBpuOCi1xuICAgIGxldCBwcm9kdWN0VHlwZUlkO1xuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDE7XG4gICAgICAgIGJyZWFrO1xuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDI7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDE7XG4gICAgICAgIGJyZWFrO1xuICAgIH1cblxuICAgIC8vIOWVhuWTgeOCv+OCsOOCkuioreWumuOBmeOCi1xuICAgIGNvbnN0IHRhZ3MgPSBbXTtcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XG4gICAgICAgIHRhZ3MucHVzaCh7XG4gICAgICAgICAgdGFnOiA0LFxuICAgICAgICAgIHNldDogJ29uJyxcbiAgICAgICAgfSwge1xuICAgICAgICAgIHRhZzogNSxcbiAgICAgICAgICBzZXQ6ICdvZmYnLFxuICAgICAgICB9KTtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxuICAgICAgICB0YWdzLnB1c2goe1xuICAgICAgICAgIHRhZzogNSxcbiAgICAgICAgICBzZXQ6ICdvbicsXG4gICAgICAgIH0sIHtcbiAgICAgICAgICB0YWc6IDQsXG4gICAgICAgICAgc2V0OiAnb2ZmJyxcbiAgICAgICAgfSk7XG4gICAgICAgIGJyZWFrO1xuICAgICAgZGVmYXVsdDpcbiAgICAgICAgYnJlYWs7XG4gICAgfVxuXG4gICAgLy8g5ZWG5ZOB5Yil6YCB5paZ44KS6Kit5a6a44GZ44KLXG4gICAgbGV0IGRlbGl2ZXJ5RmVlID0gbnVsbDtcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XG4gICAgICAgIGRlbGl2ZXJ5RmVlID0gbnVsbDtcbiAgICAgICAgYnJlYWs7XG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxuICAgICAgICBkZWxpdmVyeUZlZSA9IDI0MDtcbiAgICAgICAgYnJlYWs7XG4gICAgICBkZWZhdWx0OlxuICAgICAgICBicmVhaztcbiAgICB9XG5cbiAgICAvL1xuICAgIC8vIOmhp+WuouWQkeOBkeODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgemBuOaKnuapn+iDveOBruWun+ijhVxuICAgIC8vXG5cbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7XG4gICAgICBwcm9kdWN0X2lkOiAnJG1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9pZCcsXG4gICAgfSk7XG5cbiAgICAvLyBIVE1MIOODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgeOBlOOBqOOBruODquODs+OCr+S7mOOBjeODnOOCv+ODs+OCkuihqOekuuOBmeOCi1xuXG4gICAgLy8g5YCk44Gu5aSJ5o+bXG4gICAgYXR0cnMgPSBhdHRycy5tYXAoXG4gICAgICAoYXR0cikgPT4ge1xuICAgICAgICBhdHRyLnByb3BzLmN1cnJlbnQgPSBjb252RGVsaXYoYXR0ci5wcm9wcy5jdXJyZW50KTtcbiAgICAgICAgYXR0ci52YXJpYXRpb25zID0gYXR0ci52YXJpYXRpb25zLm1hcChcbiAgICAgICAgICAodmFyaWF0aW9uKSA9PiB7XG4gICAgICAgICAgICB2YXJpYXRpb24udmFsdWUgPSBjb252RGVsaXYodmFyaWF0aW9uLnZhbHVlKTtcbiAgICAgICAgICAgIHJldHVybiB2YXJpYXRpb247XG4gICAgICAgICAgfSxcbiAgICAgICAgKTtcbiAgICAgICAgcmV0dXJuIGF0dHI7XG4gICAgICB9LFxuICAgICk7XG5cbiAgICAvLyBIVE1M55Sf5oiQXG4gICAgY29uc3QgdmFyaWF0aW9uSHRtbCA9IGF0dHJzLm1hcChcbiAgICAgIGF0dHIgPT4gYCR7JzxkaXYgY2xhc3M9XCJjb250YWluZXItZmx1aWRcIj4nXG4gICAgICAgICsgJzxkaXYgY2xhc3M9XCJyb3dcIj4nXG4gICAgICAgICsgJzxkaXYgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGNsYXNzPVwiYnRuIGJ0bi1pbmZvIGJ0bi1ibG9jayBidG4teHNcIj4nXG4gICAgICAgICsgYDxzdHJvbmc+JHthdHRyLnByb3BzLmxhYmVsfTwvc3Ryb25nPmBcbiAgICAgICAgKyAnPC9kaXY+J30ke1xuICAgICAgICBhdHRyLnZhcmlhdGlvbnMubWFwKFxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcbiAgICAgICAgICAgIGlmIChhdHRyLnByb3BzLmN1cnJlbnQgPT09IHZhcmlhdGlvbi52YWx1ZSkge1xuICAgICAgICAgICAgICAvLyDooajnpLrkuK3jga7llYblk4Hjg5zjgr/jg7NcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zdWNjZXNzIGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj48c3Ryb25nPiR7dmFyaWF0aW9uLnZhbHVlfTwvc3Ryb25nPjwvYnV0dG9uPmA7XG4gICAgICAgICAgICB9IGlmICh2YXJpYXRpb24uc3RvY2sgPiAwKSB7XG4gICAgICAgICAgICAgIC8vIOiyqeWjsuWPr+iDveWVhuWTgeOBruODnOOCv+ODs1xuICAgICAgICAgICAgICByZXR1cm4gYDxhIGhyZWY9XCIvcHJvZHVjdHMvZGV0YWlsLyR7dmFyaWF0aW9uLnByb2R1Y3RfaWR9XCI+PGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+PC9hPmA7XG4gICAgICAgICAgICB9XG4gICAgICAgICAgICAvLyDosqnlo7LkuI3lj6/og73llYblk4Hjga7jg5zjgr/jg7PvvIjlnKjluqvjgarjgZfvvIlcbiAgICAgICAgICAgIHJldHVybiBgPGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCIgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGRhdGEtdG9nZ2xlPVwidG9vbHRpcFwiIHRpdGxlPVwi5Zyo5bqr44GM44GU44GW44GE44G+44Gb44KTXCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+YDtcbiAgICAgICAgICB9LFxuICAgICAgICApLmpvaW4oJycpXG4gICAgICB9PC9kaXY+YFxuICAgICAgICArICc8L2Rpdj4nLFxuICAgICkuam9pbignJyk7XG5cbiAgICBjb25zdCBkZXNjcmlwdGlvbkRldGFpbCA9IGBcbiAgICA8c21hbGw+4oC7IOmFjemAgeaWueazleODu+OCq+ODqeODvOODu+OCteOCpOOCuuOBr+S4i+iomOOBi+OCieOBiumBuOOBs+OBj+OBoOOBleOBhOOAgjwvc21hbGw+XG4gICAgJHt2YXJpYXRpb25IdG1sfVxuICAgIGA7XG5cbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcbiAgICBjb25zdCBkYXRhID0ge1xuICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxuICAgICAgY3JlYXRvcl9pZDogY29uZmlnVXBsb2FkSXRlbS5jcmVhdG9yX2lkLFxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7Y29udkRlbGl2KGl0ZW0uZGVsaXZlcnkpfSAke2l0ZW0ubmFtZX0ke2l0ZW0uamFuX2NvZGUgPyBgICR7aXRlbS5qYW5fY29kZX1gIDogJyd9YCxcbiAgICAgIGRlc2NyaXB0aW9uX2RldGFpbDogZGVzY3JpcHRpb25EZXRhaWwsXG4gICAgICAvLyBmcmVlX2FyZWE6IGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZUZyZWVBcmVhKGl0ZW0pLFxuICAgICAgcHJvZHVjdF9jb2RlOiBtb2RlbENsYXNzLmpvaW4oJy8nKSxcbiAgICAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxuICAgICAgLy8gcHJpY2UwMjogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlUHJpY2UwMihpdGVtKSxcbiAgICAgIC8vIGltYWdlczogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlSW1hZ2VzKGl0ZW0pLFxuICAgICAgcHJvZHVjdF90eXBlX2lkOiBwcm9kdWN0VHlwZUlkLFxuICAgICAgdGFncyxcbiAgICAgIGRlbGl2ZXJ5X2ZlZTogZGVsaXZlcnlGZWUsXG4gICAgfTtcblxuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlRnJlZUFyZWEoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkpO1xuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlUHJpY2UwMihjb25maWdVcGxvYWRJdGVtLCBpdGVtKSk7XG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVJbWFnZXMoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkpO1xuXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBpdGVtLm1hbGwuc2hhcmFrdVNob3ApO1xuXG4gICAgcmV0dXJuIGRhdGE7XG4gIH1cblxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzY3JlYXRlRnJlZUFyZWEoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkge1xuICAgIGxldCBmcmVlQXJlYSA9ICcnO1xuICAgIC8vIOWVhuWTgeaDheWgseODhuOCreOCueODiOOCkuiomOi8ieOBmeOCi1xuICAgIGZyZWVBcmVhICs9IGl0ZW0uZGVzY3JpcHRpb247XG4gICAgLy8gMueVquebruS7pemZjeOBrueUu+WDj+OCkuODleODquODvOOCqOODquOCouOBq+iomOi8ieOBmeOCi1xuICAgIGZvciAobGV0IGkgPSAxOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIGZyZWVBcmVhICs9IGA8aW1nIHNyYz1cIi91cGxvYWQvc2F2ZV9pbWFnZS8ke2l0ZW0uaW1hZ2VzW2ldfVwiPjxicj5gO1xuXG4gICAgLy8g5oOF5aCx44Gu44Kv44Oq44KiXG4gICAgZnJlZUFyZWEgKz0gJyAnO1xuICAgIHJldHVybiB7IGZyZWVfYXJlYTogZnJlZUFyZWEgfTtcbiAgfVxuXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyKGNvbmZpZ1VwbG9hZEl0ZW0sIGl0ZW0pIHtcbiAgICAvLyDkvqHmoLzjgpLov5TjgZlcbiAgICByZXR1cm4geyBwcmljZTAyOiBpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJpY2UgfTtcbiAgfVxuXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVJbWFnZXMoY29uZmlnVXBsb2FkSXRlbSwgaXRlbSkge1xuICAgIC8vIOeUu+WDj+ODquOCueODiOOBruOBhuOBoTHjgaTjgoHjgaDjgZHjgpLov5TjgZlcbiAgICBjb25zdCBhcnIgPSB0eXBlb2YgaXRlbS5pbWFnZXNbMF0gPT09ICd1bmRlZmluZWQnID8gW10gOiBbaXRlbS5pbWFnZXNbMF1dO1xuICAgIHJldHVybiB7IGltYWdlczogYXJyIH07XG4gIH1cblxuICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjgbjjga7lpInmj5tcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdDEoY29uZmlnLCBpdGVtKSB7XG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5jb252ZXJ0SXRlbVlhdWN0KGNvbmZpZy5kZWZhdWx0LCBpdGVtKTtcbiAgICByZXR1cm4gcmVzO1xuICB9XG5cbiAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44G444Gu5aSJ5o+bXG4gIGFzeW5jIGNvbnZlcnRJdGVtWWF1Y3QoZGVmLCBpdGVtKSB7XG4gICAgY29uc3QgaWRMZW5ndGggPSAyMDtcbiAgICBjb25zdCB0aXRsZUxlbmd0aCA9IDEzMDtcblxuICAgIGxldCB5YXVjdCA9IHt9O1xuICAgIC8vIOODpOODleOCquOCr+ODhuODs+ODl+ODrOODvOODiOOBruWIneacn+WApO+8iOOChuOBhuODkeOCseODg+ODiOODu+WuhemFjeS+v+OBp+eVsOOBquOCi++8iVxuICAgIHlhdWN0ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkZWZbaXRlbS5kZWxpdmVyeV0pKTtcblxuICAgIC8vIOeUu+WDj+OBruiomOi/sFxuICAgIGNvbnN0IGltZ1ByZWZpeCA9ICfnlLvlg48nO1xuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIHlhdWN0W2ltZ1ByZWZpeCArIChpICsgMSldID0gaXRlbS5pbWFnZXNbaV07XG5cblxuICAgIC8vIOOCv+OCpOODiOODq1xuICAgIHlhdWN0Wyfjgqvjg4bjgrTjg6onXSA9IGl0ZW0ubWFsbC55YXVjdC5jYXRlZ29yeTtcbiAgICB5YXVjdFsn44K/44Kk44OI44OrJ10gPSBUZXh0VXRpbC5zdWJzdHI4KGAke2F3YWl0IHRoaXMuZ2V0TW9kZWxDbGFzcyhpdGVtKX0gJHtpdGVtLmRlbGl2ZXJ5fSAke2l0ZW0ubmFtZX1gLCB0aXRsZUxlbmd0aCk7XG4gICAgeWF1Y3RbJ+mWi+Wni+S+oeagvCddID0gaXRlbS5zYWxlc19wcmljZTtcbiAgICB5YXVjdFsn5Y2z5rG65L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlO1xuICAgIHlhdWN0WyfnrqHnkIbnlarlj7cnXSA9IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkuc2xpY2UoLWlkTGVuZ3RoKTtcbiAgICBpZiAodHlwZW9mIHlhdWN0WyfoqqzmmI4nXSA9PT0gJ3N0cmluZycpIHlhdWN0WyfoqqzmmI4nXSA9IGAke2l0ZW0uZGVzY3JpcHRpb259PGJyPjxicj4ke3lhdWN0WyfoqqzmmI4nXX1gO1xuICAgIGVsc2UgeWF1Y3RbJ+iqrOaYjiddID0gaXRlbS5kZXNjcmlwdGlvbjtcblxuICAgIHlhdWN0WydKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ10gPSBpdGVtLmphbl9jb2RlO1xuXG4gICAgcmV0dXJuIHlhdWN0O1xuICB9XG5cbiAgYXN5bmMgY29udmVydEl0ZW1Xb3dtYUNyZWF0ZURlbGl2ZXJ5TWV0aG9kKGl0ZW1Db2RlKSB7XG4gICAgY29uc3QgaWQgPSAnbWFsbC53b3dtYS5pdGVtQ29kZSc7XG4gICAgY29uc3Qgc2V0ID0gJ2RlbGl2ZXJ5JztcbiAgICBjb25zdCBtZXRyaWNzID0ge1xuICAgICAg44KG44GG44OR44Kx44OD44OIOiBbJ1Bvc3QnXSxcbiAgICAgIOWuhemFjeS+vzogWydZVS1QYWNrJywgJ0thbmdhcm9vJ10sXG4gICAgfTtcbiAgICAvLyBkZWxpdmVyeU1ldGhvZFNlcVxuXG4gICAgY29uc3QgYWdnciA9IGF3YWl0IHRoaXMuSXRlbXMuYWdncmVnYXRlKFxuICAgICAgW1xuICAgICAgICB7XG4gICAgICAgICAgJG1hdGNoOiB7XG4gICAgICAgICAgICBbaWRdOiBpdGVtQ29kZSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgJGdyb3VwOiB7XG4gICAgICAgICAgICBfaWQ6IGAkJHtpZH1gLFxuICAgICAgICAgICAgW3NldF06IHsgJGFkZFRvU2V0OiBgJCR7c2V0fWAgfSxcbiAgICAgICAgICB9LFxuICAgICAgICB9LFxuICAgICAgICB7XG4gICAgICAgICAgJHByb2plY3Q6IHtcbiAgICAgICAgICAgIF9pZDogMCxcbiAgICAgICAgICAgIGl0ZW1Db2RlOiAnJF9pZCcsXG4gICAgICAgICAgICBbc2V0XTogYCQke3NldH1gLFxuICAgICAgICAgIH0sXG4gICAgICAgIH0sXG4gICAgICBdLFxuICAgICkudG9BcnJheSgpO1xuXG4gICAgbGV0IGFjY2VwdERlbGl2ID0gW107XG4gICAgZm9yIChjb25zdCBkZWwgb2YgYWdnclswXS5kZWxpdmVyeSkgYWNjZXB0RGVsaXYgPSBhY2NlcHREZWxpdi5jb25jYXQobWV0cmljc1tgJHtkZWx9YF0pO1xuXG5cbiAgICBjb25zdCBkZWxpdmVyeU1ldGhvZCA9IG5ldyBBcnJheSg1KTtcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGRlbGl2ZXJ5TWV0aG9kLmxlbmd0aDsgaSsrKSB7XG4gICAgICBjb25zdCBpZCA9IHR5cGVvZiBhY2NlcHREZWxpdltpXSA9PT0gJ3VuZGVmaW5lZCcgPyAnTlVMTCcgOiBhY2NlcHREZWxpdltpXTtcbiAgICAgIGRlbGl2ZXJ5TWV0aG9kW2ldID0geyBkZWxpdmVyeU1ldGhvZFNlcTogaSArIDEsIGRlbGl2ZXJ5TWV0aG9kSWQ6IGlkIH07XG4gICAgfVxuXG4gICAgcmV0dXJuIHsgZGVsaXZlcnlNZXRob2QgfTtcbiAgfVxuXG4gIC8vXG4gIC8vIFJvYm90LWluIOWklumDqOmAo+aQuuWVhuWTgeeVquWPt+OBrueZu+mMsuOBruOBn+OCgeOBruODh+ODvOOCv+OCkuS9nOOCi1xuICAvLyDjgZ3jga4xIGl0ZW0uY3N2XG5cbiAgc3RhdGljIGNvbnZlcnRJdGVtUm9ib3Rpbkl0ZW0oaXRlbSkge1xuICAgIHJldHVybiB7XG4gICAgICDjgrPjg7Pjg4jjg63jg7zjg6vjgqvjg6njg6A6ICduJyxcbiAgICAgIOaWsOimj+eZu+mMsklEOiBpdGVtLl9pZC50b0hleFN0cmluZygpLFxuICAgICAg5ZWG5ZOBSUQ6IG51bGwsXG4gICAgICDllYblk4HlkI06IGAke2l0ZW0ubW9kZWx9JHtpdGVtLmNsYXNzMV92YWx1ZSA9PT0gJycgPyAnJyA6IGAvJHtpdGVtLmNsYXNzMV92YWx1ZX1gfSR7aXRlbS5jbGFzczJfdmFsdWUgPT09ICcnID8gJycgOiBgLyR7aXRlbS5jbGFzczJfdmFsdWV9YH1gLFxuICAgICAg6KaP5qC8OiAn44Gq44GXJyxcbiAgICB9O1xuICB9XG5cbiAgLy9cbiAgLy8gUm9ib3QtaW4g5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+344Gu55m76Yyy44Gu44Gf44KB44Gu44OH44O844K/44KS5L2c44KLXG4gIC8vIOOBneOBrjIgc2VsZWN0LmNzdlxuXG4gIHN0YXRpYyBjb252ZXJ0SXRlbVJvYm90aW5TZWxlY3QoaXRlbSkge1xuICAgIGNvbnN0IHNlbGVjdCA9IHtcbiAgICAgIOOCs+ODs+ODiOODreODvOODq+OCq+ODqeODoDogJ24nLFxuICAgICAg5paw6KaP55m76YyySUQ6IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCksXG4gICAgICDllYblk4FJRDogbnVsbCxcbiAgICAgIOWklumDqOmAo+aQuklEOiBudWxsLFxuICAgICAg5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+3OiBpdGVtLl9pZC50b0hleFN0cmluZygpLFxuICAgIH07XG5cbiAgICBjb25zdCBzaG9wcyA9IFJvYm90aW5TaG9wLmZpbmQoKTtcblxuICAgIHNob3BzLmZvckVhY2goXG4gICAgICAoZG9jLCBpbmRleCkgPT4ge1xuICAgICAgICBsZXQgbW9kZWw7XG4gICAgICAgIGxldCBjbGFzczE7XG4gICAgICAgIGxldCBjbGFzczI7XG4gICAgICAgIHRyeSB7XG4gICAgICAgICAgLy8g44Oi44O844Or44Gu5ZWG5ZOB55Wq5Y+344KS54m55a6a44GZ44KLXG4gICAgICAgICAgbW9kZWwgPSBpdGVtLm1hbGxbYCR7ZG9jLm5hbWV9YF1bYCR7ZG9jLm1vZGVsUGF0aH1gXTtcbiAgICAgICAgICBtb2RlbCA9IHR5cGVvZiBtb2RlbCA9PT0gJ3VuZGVmaW5lZCcgPyAnJyA6IG1vZGVsO1xuICAgICAgICAgIGNsYXNzMSA9IGl0ZW0ubWFsbFtgJHtkb2MubmFtZX1gXVtgJHtkb2MuY2xhc3MxUGF0aH1gXTtcbiAgICAgICAgICBjbGFzczEgPSB0eXBlb2YgY2xhc3MxID09PSAndW5kZWZpbmVkJyA/ICcnIDogY2xhc3MxO1xuICAgICAgICAgIGNsYXNzMiA9IGl0ZW0ubWFsbFtgJHtkb2MubmFtZX1gXVtgJHtkb2MuY2xhc3MyUGF0aH1gXTtcbiAgICAgICAgICBjbGFzczIgPSB0eXBlb2YgY2xhc3MyID09PSAndW5kZWZpbmVkJyA/ICcnIDogY2xhc3MyO1xuICAgICAgICB9IGNhdGNoIChlKSB7XG4gICAgICAgICAgLy8g5ZWG5ZOB44Gu44Oi44O844Or5oOF5aCx44Gu5Y+W5b6X44Gr5aSx5pWX44GX44Gf77yI44OH44O844K/44GM6Kit5a6a44GV44KM44Gm44GE44Gq44GE44Gq44Gp77yJXG4gICAgICAgICAgLy8gbW9kZWwgPSBpdGVtLm1vZGVsXG4gICAgICAgICAgLy8gY2xhc3MxID0gaXRlbS5jbGFzczFfdmFsdWVcbiAgICAgICAgICAvLyBjbGFzczIgPSBpdGVtLmNsYXNzMl92YWx1ZVxuICAgICAgICAgIHJldHVybjtcbiAgICAgICAgfVxuXG4gICAgICAgIHNlbGVjdFtg5Y+X5rOo5ZWG5ZOBSURfJHtpbmRleH1gXSA9IG51bGw7XG4gICAgICAgIHNlbGVjdFtg5bqX6IiXSURfJHtpbmRleH1gXSA9IGRvY1sn5bqX6IiXSUQnXTtcbiAgICAgICAgc2VsZWN0W2DlupfoiJflkI1fJHtpbmRleH1gXSA9IGRvYy5uYW1lO1xuICAgICAgICBzZWxlY3RbYOWPl+azqOWVhuWTgeeVquWPt18ke2luZGV4fWBdID0gYCR7bW9kZWx9JHtjbGFzczF9JHtjbGFzczJ9YDtcbiAgICAgICAgc2VsZWN0W2DmnInlirnjg5Xjg6njgrBfJHtpbmRleH1gXSA9ICfmnInlirknO1xuICAgICAgfSxcbiAgICApO1xuXG4gICAgcmV0dXJuIHNlbGVjdDtcbiAgfVxuXG4gIC8vXG4gIC8vIFJvYm90LWluIOWklumDqOmAo+aQuuWVhuWTgeeVquWPt+OBrueZu+mMsuOBruOBn+OCgeOBruODh+ODvOOCv+OCkuS9nOOCi1xuICAvLyDjgZ3jga4zIHNlbGVjdFNob3AuY3N2XG5cbiAgc3RhdGljIGNvbnZlcnRJdGVtUm9ib3RpblNlbGVjdFNob3Aoc2hvcCwgaXRlbSkge1xuICAgIGNvbnN0IG1vZGVsID0gaXRlbS5tYWxsW2Ake3Nob3AubmFtZX1gXVtgJHtzaG9wLm1vZGVsUGF0aH1gXTtcbiAgICBjb25zdCBjbGFzczEgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AuY2xhc3MxUGF0aH1gXTtcbiAgICBjb25zdCBjbGFzczIgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AuY2xhc3MyUGF0aH1gXTtcblxuICAgIHJldHVybiB7XG4gICAgICDjgrPjg7Pjg4jjg63jg7zjg6vjgqvjg6njg6A6ICd1JyxcbiAgICAgIOaWsOimj+eZu+mMsklEOiBpdGVtLl9pZC50b0hleFN0cmluZygpLFxuICAgICAg5Y+X5rOo5ZWG5ZOBSUQ6IG51bGwsXG4gICAgICDlupfoiJdJRDogc2hvcFsn5bqX6IiXSUQnXSxcbiAgICAgIOW6l+iIl+WQjTogbnVsbCxcbiAgICAgIOWPl+azqOWVhuWTgeeVquWPtzogYCR7bW9kZWx9JHtjbGFzczF9JHtjbGFzczJ9YCxcbiAgICAgIOacieWKueODleODqeOCsDogJ+acieWKuScsXG4gICAgfTtcbiAgfVxufVxuIiwiaW1wb3J0IHtcbiAgTW9uZ28sXG59IGZyb20gJ21ldGVvci9tb25nbyc7XG5pbXBvcnQge1xuICBPYmplY3RJRCxcbn0gZnJvbSAnYnNvbic7XG5pbXBvcnQgVGV4dFV0aWwgZnJvbSAnLi4vdXRpbC90ZXh0JztcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuL2l0ZW1zJztcbmltcG9ydCB7XG4gIFJvYm90aW5PcmRlcnMsXG59IGZyb20gJy4uL2NvbGxlY3Rpb25zJztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUm9ib3RpbiB7XG4gIGNvbnN0cnVjdG9yICgpIHtcbiAgICAvLyBpbXBvcnRPcmRlclRlbXAg44Gr6Zai6YCjXG4gICAgLy8g5Y+X55m65rOo44K344K544OG44Og44Gn44Gv5Yem55CG44Gn44GN44Gq44GE5L6L5aSW55qE5Y+X5rOo5Yem55CG44Gr5a++44GX44GmXG4gICAgLy8g5YCL5Yil44Gu6YCB44KK54q255m66KGM44Gq44Gp44KS6KGM44GGXG4gICAgdGhpcy5PcmRlciA9IG5ldyBNb25nby5Db2xsZWN0aW9uKG51bGwpO1xuICB9XG5cbiAgc3RhdGljIGNyZWF0ZVJlYWRhYmxlT3JkZXIocXVlcnkgPSB7fSkge1xuICAgIHJldHVybiBSb2JvdGluT3JkZXJzLnJhd0NvbGxlY3Rpb24oKS5maW5kKHF1ZXJ5LCB7IF9pZDogMCwgcm9ib3RpbjogMSB9KS5zdHJlYW0oKTtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0geyp9IGRvY09yZGVyXG4gICAqIEBwYXJhbSB7SXRlbUNvbnRyb2xsZXJ9IGl0ZW1TXG4gICAqL1xuICBpbXBvcnRPcmRlclRlbXAgKGRvY09yZGVyLCBpdGVtUykge1xuICAgIC8vIOWPl+azqOODh+ODvOOCv+OCkuODh+ODvOOCv+ODmeODvOOCueOBq+S/neWtmFxuICAgIHRoaXMuT3JkZXIuaW5zZXJ0KHsgcm9ib3RpbjogZG9jT3JkZXIgfSk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHsqfSBkb2NPcmRlclxuICAgKiBAcGFyYW0ge0l0ZW1Db250cm9sbGVyfSBpdGVtQ29uXG4gICAqL1xuICBzdGF0aWMgYXN5bmMgaW1wb3J0T3JkZXIoZG9jT3JkZXIsIGl0ZW1Db24pIHtcbiAgICAvLyDllYblk4Hnlarlj7fjgpJtb25nb0lk44Go44GX44Gm5qSc57Si44GX44CB6Kmy5b2T44GZ44KLaXRlbeOBjOOBguOCjOOBsOabuOOBjeaPm+OBiOOCi1xuICAgIC8vIGlmIChPYmplY3RJRC5pc1ZhbGlkKGRvY09yZGVyWyfllYblk4HjgrPjg7zjg4knXSkpIHtcbiAgICAvLyAgIGNvbnN0IGl0ZW0gPSBhd2FpdCBpdGVtQ29uLkl0ZW1zLmZpbmRPbmUoeyBfaWQ6IG5ldyBPYmplY3RJRChkb2NPcmRlclsn5ZWG5ZOB44Kz44O844OJJ10pIH0pO1xuICAgIC8vICAgaWYgKGl0ZW0pIGRvY09yZGVyWyfllYblk4HjgrPjg7zjg4knXSA9IGF3YWl0IGl0ZW1Db24uZ2V0TW9kZWxDbGFzcyhpdGVtKTtcbiAgICAvLyB9XG5cbiAgICAvLyDlj5fms6jjg4fjg7zjgr/jgpLjg4fjg7zjgr/jg5njg7zjgrnjgavkv53lrZhcbiAgICBjb25zdCBpbnNlcnREb2MgPSB7XG4gICAgICByb2JvdGluOiBkb2NPcmRlcixcbiAgICB9O1xuXG4gICAgLy8g44GZ44Gn44Gr5Y+X5rOo44GM5Y+W44KK6L6844G+44KM44Gm44GE44Gf5aC05ZCI44Gv44CBZG9jT3JkZXLjga7lhoXlrrnjgavmm7TmlrDjgZnjgotcbiAgICAvLyDlj5bjgorovrzjgb7jgozjgabjgYTjgarjgYTlj5fms6jjga7loLTlkIjjga/mlrDopo/nmbvpjLLjgZnjgotcbiAgICBSb2JvdGluT3JkZXJzLnVwZGF0ZSh7XG4gICAgICAncm9ib3Rpbi7lj5fms6hJRCc6IGRvY09yZGVyWyflj5fms6hJRCddLFxuICAgICAgJ3JvYm90aW4u5piO57SwSUQnOiBkb2NPcmRlclsn5piO57SwSUQnXSxcbiAgICB9LCB7XG4gICAgICAkc2V0OiB7XG4gICAgICAgIHJvYm90aW46IGRvY09yZGVyLFxuICAgICAgfSxcbiAgICB9LCB7XG4gICAgICB1cHNlcnQ6IHRydWUsXG4gICAgfSk7XG5cbiAgICAvLyDnmbrms6jjgrnjg4bjg7zjgr/jgrnjgYzoqK3lrprjgZXjgozjgabjgYTjgarjgYTjg4njgq3jg6Xjg6Hjg7Pjg4jvvIjmlrDopo/nmbvpjLLlj5fms6jvvIlcbiAgICAvLyDnmbrms6jjgrnjg4bjg7zjgr/jgrnjga7liJ3mnJ/lgKTjgpLoqK3lrprjgZnjgotcbiAgICBSb2JvdGluT3JkZXJzLnVwZGF0ZSh7XG4gICAgICB2ZW5kb3I6IHsgJGV4aXN0czogMCB9LFxuICAgIH0sIHtcbiAgICAgICRzZXQ6IHtcbiAgICAgICAgdmVuZG9yOiB7IC8vIOeZuuazqOOCueODhuODvOOCv+OCueOBruWIneacn+WApFxuICAgICAgICAgIG9yZGVydG86ICcnLCAvLyDnmbrms6jlhYhcbiAgICAgICAgICBvcmRlckRhdGU6IG51bGwsIC8vIOeZuuazqOaXpVxuICAgICAgICAgIHByb21pc2U6IG51bGwsIC8vIOeZuumAgeS6iOWumuaXpVxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICB9KTtcbiAgfVxuXG4gIHN0YXRpYyBsaXN0SXRlbUNvZGVGb3JMYWJlbChxdWVyeSwgY29sbGVjdGlvbiA9IG51bGwpIHtcbiAgICAvLyDlj5fms6jjgrfjgrnjg4bjg6DkvovlpJbjga7loLTlkIjjgIHku7vmhI/jga7jgrPjg6zjgq/jgrfjg6fjg7PvvIhtaW5pbW9uZ2/jga7kuIDmmYLjg4fjg7zjgr/jg5njg7zjgrnvvInjgYzpgbjmip7jgafjgY3jgotcbiAgICBjb2xsZWN0aW9uID0gY29sbGVjdGlvbiA9PT0gbnVsbCA/IFJvYm90aW5PcmRlcnMgOiBjb2xsZWN0aW9uO1xuXG4gICAgLy8g5qSc57Si5p2h5Lu244Gr6Kmy5b2T44GZ44KL5Y+X5rOo44KS6Kq/44G544KLXG4gICAgY29uc3QgY3VyID0gY29sbGVjdGlvbi5maW5kKFxuICAgICAgcXVlcnksIHtcbiAgICAgICAgZmllbGRzOiB7XG4gICAgICAgICAgX2lkOiAwLFxuICAgICAgICAgICdyb2JvdGluLuWVhuWTgeOCs+ODvOODiSc6IDEsXG4gICAgICAgICAgJ3JvYm90aW4u5pWw6YePJzogMSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgKTtcbiAgICAvLyDpgIHjgornirbjg6zjgrPjg7zjg4njgavoqbLlvZPjgZnjgovlj5fms6jjg6zjgrPjg7zjg4njgYzopovjgaTjgYvjgonjgarjgYTloLTlkIhcbiAgICBpZiAoIWN1ci5jb3VudCgpKSB0aHJvdyBuZXcgRXJyb3IoJ+mAgeOCiueKtuOBq+WvvuW/nOOBmeOCi+WPl+azqOOBjOimi+OBpOOBi+OCiuOBvuOBm+OCk+OAgkNTVuODleOCoeOCpOODq+OCkueiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuICAgIC8vIOWVhuWTgeODquOCueODiOOCkuS9nOaIkOOBmeOCi1xuICAgIGNvbnN0IGxpc3QgPSBbXTtcbiAgICBjdXIuZm9yRWFjaCgoZG9jKSA9PiB7XG4gICAgICBjb25zdCBxID0gZG9jLnJvYm90aW4u5pWw6YePID09IDEgPyAnJyA6IGBbJHtkb2Mucm9ib3Rpbi7mlbDph499RUFdYDtcbiAgICAgIGxpc3QucHVzaChgJHtkb2Mucm9ib3Rpbi7llYblk4HjgrPjg7zjg4l9ICR7cX1gKTtcbiAgICB9KTtcbiAgICAvLyDllYblk4Hjg6rjgrnjg4jjgpLov5TjgZlcbiAgICByZXR1cm4gbGlzdDtcbiAgfVxuXG4gIC8qKlxuICAgKlxuICAgKiBAcGFyYW0geyp9IGRvY0xhYmVsXG4gICAqIEBwYXJhbSB7QXJyYXl9IHdyaXRlSXRlbUNvZGVUb1xuICAgKi9cbiAgdHJhbnNmb3JtTGFiZWxTZWlubyhkb2NMYWJlbCwgbGFiZWxPcHRpb25zKSB7XG4gICAgLy8g5ZWG5ZOB44Kz44O844OJ44KS6YCB44KK54q2Q1NW44Gr5Z+L44KB6L6844KAXG4gICAgLy9cblxuICAgIC8vIOWPl+azqOeVquWPt+OCkuaKveWHulxuICAgIGNvbnN0IG9yZGVyTnVtYmVyID0gZG9jTGFiZWxbMzJdOyAvLyAzM+eVquebruOBrumgheebruOAjOiomOS6i++8keOAjVxuXG4gICAgLy8gLy8g5Y+X5rOoQ1NW44GL44KJ5bqX6IiX5ZCN44Go5Y+X5rOo55Wq5Y+344KS44Kt44O844Gr5ZWG5ZOB44Kz44O844OJ5LiA6Kan44KS5Y+W5b6X44GZ44KLXG4gICAgLy8gY29uc3QgY3VyID0gUm9ib3Rpbk9yZGVycy5maW5kKHtcbiAgICAvLyAgIOW6l+iIl+WQjTogZG9jTGFiZWxbMTFdLCAvLyAxMueVquebruOBrumgheebruOAjOiNt+mAgeS6uuWQjeensOOAjVxuICAgIC8vICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXG4gICAgLy8gICDlj5fms6jnlarlj7c6IHsgJGluOiBbb3JkZXJOdW1iZXIsIE51bWJlcihvcmRlck51bWJlcildIH1cbiAgICAvLyB9LCB7XG4gICAgLy8gICBmaWVsZHM6IHtcbiAgICAvLyAgICAgX2lkOiAwLFxuICAgIC8vICAgICDllYblk4HjgrPjg7zjg4k6IDFcbiAgICAvLyAgIH1cbiAgICAvLyB9KTtcblxuICAgIGNvbnN0IGl0ZW1zID0gUm9ib3Rpbi5saXN0SXRlbUNvZGVGb3JMYWJlbChcbiAgICAgIHtcbiAgICAgICAgJ3JvYm90aW4u5bqX6IiX5ZCNJzogZG9jTGFiZWxbMTFdLCAvLyAxMueVquebruOBrumgheebruOAjOiNt+mAgeS6uuWQjeensOOAjVxuICAgICAgICAvLyDlj5fms6hDU1blh7rlipvjgZXjgozjgabjgYTjgovlj5fms6jnlarlj7fjgYzmloflrZfliJflvaLlvI/jgafjgoLmlbDlgKTlvaLlvI/jgafjgoLlvJXjgaPjgYvjgYvjgovjgojjgYbjgavjgZnjgovvvIgkaW7vvIlcbiAgICAgICAgJ3JvYm90aW4u5Y+X5rOo55Wq5Y+3Jzoge1xuICAgICAgICAgICRpbjogW29yZGVyTnVtYmVyLCBOdW1iZXIob3JkZXJOdW1iZXIpXSxcbiAgICAgICAgfSxcbiAgICAgIH0sXG4gICAgICAvLyDlj5fms6jjgrfjgrnjg4bjg6DkvovlpJbjga7loLTlkIjjgIHku7vmhI/jga7jgrPjg6zjgq/jgrfjg6fjg7PvvIhtaW5pbW9uZ2/jga7kuIDmmYLjg4fjg7zjgr/jg5njg7zjgrnvvInjgYzpgbjmip7jgafjgY3jgotcbiAgICAgIHR5cGVvZiB0aGlzLk9yZGVyID09PSAndW5kZWZpbmVkJyA/IG51bGwgOiB0aGlzLk9yZGVyLFxuICAgICk7XG5cbiAgICAvLyAvLyDpgIHjgornirbjg6zjgrPjg7zjg4njgavoqbLlvZPjgZnjgovlj5fms6jjg6zjgrPjg7zjg4njgYzopovjgaTjgYvjgonjgarjgYTloLTlkIhcbiAgICAvLyBpZiAoIWN1ci5jb3VudCgpKSB0aHJvdyBuZXcgRXJyb3IoJ+mAgeOCiueKtuOBq+WvvuW/nOOBmeOCi+WPl+azqOOBjOimi+OBpOOBi+OCiuOBvuOBm+OCk+OAgkNTVuODleOCoeOCpOODq+OCkueiuuiqjeOBl+OBpuOBj+OBoOOBleOBhOOAgicpO1xuXG4gICAgLy8gLy8g6YCB44KK54q244Gu55m66YCB5ZWG5ZOB44Kz44O844OJ5LiA6Kan44KS6YWN5YiX44Gr44GZ44KLXG4gICAgLy8gY29uc3QgaXRlbXMgPSBjdXIuZmV0Y2goKTtcblxuICAgIC8vIGRvY0xhYmVsIDog5YWl5Yqb6YCB44KK54q244OH44O844K/XG4gICAgLy8gY29uTGFiZWwgOiDlh7rlipvnlKjpgIHjgornirbjg4fjg7zjgr9cbiAgICBjb25zdCBjb25MYWJlbCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZG9jTGFiZWwpKTtcblxuICAgIC8vIHdyaXRlSXRlbUNvZGVUbyDvvIjkuIDjgaTjga7pgIHjgornirbjgavoqJjovInjgafjgY3jgovllYblk4HjgrPjg7zjg4njga7mnIDlpKfmlbDvvInjga7nt4/mlbDjgojjgorjgIHlj5fms6jjg4fjg7zjgr/jga7llYblk4HmlbDjgYzlpJrjgYTloLTlkIjjga/jgqjjg6njg7xcbiAgICBjb25zdCB3cml0ZUl0ZW1Db2RlVG8gPSBsYWJlbE9wdGlvbnMud3JpdGVJdGVtQ29kZVRvO1xuICAgIGlmICh3cml0ZUl0ZW1Db2RlVG8ubGVuZ3RoIDwgaXRlbXMubGVuZ3RoKSB0aHJvdyBuZXcgRXJyb3IoYOmAgeOCiueKtuODh+ODvOOCv+OBq+iomOi8ieOBp+OBjeOCi+WVhuWTgeaVsOOBryR7d3JpdGVJdGVtQ29kZVRvLmxlbmd0aH3lgIvjgb7jgafjgafjgZlgKTtcblxuICAgIC8vIOWumuaVsOOBruWfi+OCgei+vOOBv1xuICAgIGxhYmVsT3B0aW9ucy5jb25zdC5mb3JFYWNoKChlKSA9PiB7XG4gICAgICBjb25MYWJlbFtlLmNvbHVtbl0gPSBlLnZhbHVlO1xuICAgIH0pO1xuXG4gICAgLy8g6YCB44KK54q244OH44O844K/44Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6Yyy44GZ44KLXG4gICAgd3JpdGVJdGVtQ29kZVRvLmZvckVhY2goKGUsIGkpID0+IHtcbiAgICAgIGlmIChpdGVtc1tpXSkge1xuICAgICAgICBjb25MYWJlbFtlXSA9IGl0ZW1zW2ldO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8g6YCB44KK54q244Gu5ZWG5ZOB44Kz44O844OJ5qyE44Gv44GZ44G544Gm5Z+L44KB44KLXG4gICAgICAgIC8vIOOBk+OCjOOBq+OCiOOCiuWIl+OBruasoOiQveOCkumYsuOBkFxuICAgICAgICBjb25MYWJlbFtlXSA9ICcnO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8g5L2P5omA5paH5a2X5YiX44Gu5YiG5Ymy44KS5L+u5q2j44GZ44KLXG4gICAgLy8ga2V5UyDjgafmjIflrprjgZXjgozjgZ8gdGFyZ2V0IOWGheOBruimgee0oOOBruWApOOCkuOAgWxlbmd0aO+8iOODkOOCpOODiOmVt++8ieOBp+WIhuWJsuOBl+WGjeani+evieOBmeOCi1xuICAgIC8vIGxlbmd0aO+8iOODkOOCpOODiOmVt++8ieOCkui2heOBiOOCi+aWh+Wtl+WIl+OBr+OAgeWNiuinkuOCueODmuODvOOCueOBp+WIhuWJsuOBmeOCi1xuICAgIC8vIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWzEyLCAxM10sIDQwKTsgLy8g6aCF55uuMTPjgIzojbfpgIHkurrkvY/miYDvvJHjgI3jgIHpoIXnm64xNOOAjOiNt+mAgeS6uuS9j+aJgO+8kuOAjVxuICAgIC8vIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWzIxLCAyMl0sIDYwKTsgLy8g6aCF55uuMjLjgIzjgYrlsYrjgZHlhYjkvY/miYDvvJHjgI3jgIHpoIXnm64yM+OAjOOBiuWxiuOBkeWFiOS9j+aJgO+8kuOAjVxuXG4gICAgcmV0dXJuIGNvbkxhYmVsO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7Kn0gZG9jTGFiZWxcbiAgICogQHBhcmFtIHtBcnJheX0gd3JpdGVJdGVtQ29kZVRvXG4gICAqL1xuICB0cmFuc2Zvcm1MYWJlbFl1cGFjayhkb2NMYWJlbCwgbGFiZWxPcHRpb25zKSB7XG4gICAgLy8g5ZWG5ZOB44Kz44O844OJ44KS6YCB44KK54q2Q1NW44Gr5Z+L44KB6L6844KAXG4gICAgLy9cblxuICAgIC8vIOWPl+azqOeVquWPt+OCkuaKveWHulxuICAgIGNvbnN0IG9yZGVyTnVtYmVyID0gZG9jTGFiZWxbJ+iomOS6i+WQje+8kSddLnJlcGxhY2UoJ+WPl+azqOeVquWPt++8micsICcnKTtcblxuICAgIC8vIC8vIOWPl+azqENTVuOBi+OCieW6l+iIl+WQjeOBqOWPl+azqOeVquWPt+OCkuOCreODvOOBq+WVhuWTgeOCs+ODvOODieS4gOimp+OCkuWPluW+l+OBmeOCi1xuICAgIC8vIGNvbnN0IGN1ciA9IFJvYm90aW5PcmRlcnMuZmluZCh7XG4gICAgLy8gICDlupfoiJflkI06IGRvY0xhYmVsWyfjgZTkvp3poLzkuLsg5ZCN56ewMSddLFxuICAgIC8vICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXG4gICAgLy8gICDlj5fms6jnlarlj7c6IHsgJGluOiBbb3JkZXJOdW1iZXIsIE51bWJlcihvcmRlck51bWJlcildIH1cbiAgICAvLyB9LCB7XG4gICAgLy8gICBmaWVsZHM6IHtcbiAgICAvLyAgICAgX2lkOiAwLFxuICAgIC8vICAgICDllYblk4HjgrPjg7zjg4k6IDFcbiAgICAvLyAgIH1cbiAgICAvLyB9KTtcblxuICAgIGNvbnN0IGl0ZW1zID0gUm9ib3Rpbi5saXN0SXRlbUNvZGVGb3JMYWJlbChcbiAgICAgIHtcbiAgICAgICAgJ3JvYm90aW4u5bqX6IiX5ZCNJzogZG9jTGFiZWxbJ+OBlOS+nemgvOS4uyDlkI3np7AxJ10sXG4gICAgICAgIC8vIOWPl+azqENTVuWHuuWKm+OBleOCjOOBpuOBhOOCi+WPl+azqOeVquWPt+OBjOaWh+Wtl+WIl+W9ouW8j+OBp+OCguaVsOWApOW9ouW8j+OBp+OCguW8leOBo+OBi+OBi+OCi+OCiOOBhuOBq+OBmeOCi++8iCRpbu+8iVxuICAgICAgICAncm9ib3Rpbi7lj5fms6jnlarlj7cnOiB7XG4gICAgICAgICAgJGluOiBbb3JkZXJOdW1iZXIsIE51bWJlcihvcmRlck51bWJlcildLFxuICAgICAgICB9LFxuICAgICAgfSxcbiAgICAgIC8vIOWPl+azqOOCt+OCueODhuODoOS+i+WkluOBruWgtOWQiOOAgeS7u+aEj+OBruOCs+ODrOOCr+OCt+ODp+ODs++8iG1pbmltb25nb+OBruS4gOaZguODh+ODvOOCv+ODmeODvOOCue+8ieOBjOmBuOaKnuOBp+OBjeOCi1xuICAgICAgdHlwZW9mIHRoaXMuT3JkZXIgPT09ICd1bmRlZmluZWQnID8gbnVsbCA6IHRoaXMuT3JkZXIsXG4gICAgKTtcblxuICAgIC8vIGRvY0xhYmVsIDog5YWl5Yqb6YCB44KK54q244OH44O844K/XG4gICAgLy8gY29uTGFiZWwgOiDlh7rlipvnlKjpgIHjgornirbjg4fjg7zjgr9cbiAgICBjb25zdCBjb25MYWJlbCA9IEpTT04ucGFyc2UoSlNPTi5zdHJpbmdpZnkoZG9jTGFiZWwpKTtcblxuICAgIC8vIHdyaXRlSXRlbUNvZGVUbyDvvIjkuIDjgaTjga7pgIHjgornirbjgavoqJjovInjgafjgY3jgovllYblk4HjgrPjg7zjg4njga7mnIDlpKfmlbDvvInjga7nt4/mlbDjgojjgorjgIHlj5fms6jjg4fjg7zjgr/jga7llYblk4HmlbDjgYzlpJrjgYTloLTlkIjjga/jgqjjg6njg7xcbiAgICBjb25zdCB3cml0ZUl0ZW1Db2RlVG8gPSBsYWJlbE9wdGlvbnMud3JpdGVJdGVtQ29kZVRvO1xuICAgIGlmICh3cml0ZUl0ZW1Db2RlVG8ubGVuZ3RoIDwgaXRlbXMubGVuZ3RoKSB0aHJvdyBuZXcgRXJyb3IoYOmAgeOCiueKtuODh+ODvOOCv+OBq+iomOi8ieOBp+OBjeOCi+WVhuWTgeaVsOOBryR7d3JpdGVJdGVtQ29kZVRvLmxlbmd0aH3lgIvjgb7jgafjgafjgZlgKTtcblxuXG4gICAgLy8g6YCB44KK54q244OH44O844K/44Gr5ZWG5ZOB44Kz44O844OJ44KS6KiY6Yyy44GZ44KLXG4gICAgd3JpdGVJdGVtQ29kZVRvLmZvckVhY2goKGUsIGkpID0+IHtcbiAgICAgIGlmIChpdGVtc1tpXSkge1xuICAgICAgICBjb25MYWJlbFtlXSA9IGl0ZW1zW2ldO1xuICAgICAgfSBlbHNlIHtcbiAgICAgICAgLy8g6YCB44KK54q244Gu5ZWG5ZOB44Kz44O844OJ5qyE44Gv44GZ44G544Gm5Z+L44KB44KLXG4gICAgICAgIC8vIOOBk+OCjOOBq+OCiOOCiuWIl+OBruasoOiQveOCkumYsuOBkFxuICAgICAgICBjb25MYWJlbFtlXSA9ICcnO1xuICAgICAgfVxuICAgIH0pO1xuXG4gICAgLy8g6YCB44KK54q256iu5Yil44KS6Kit5a6aXG4gICAgY29uTGFiZWxbJ+mAgeOCiueKtueoruWIpSddID0gbGFiZWxPcHRpb25zLmxhYmVsSWQ7XG5cbiAgICAvLyDkvY/miYDmloflrZfliJfjga7liIblibLjgpLkv67mraPjgZnjgotcbiAgICAvLyBrZXlTIOOBp+aMh+WumuOBleOCjOOBnyB0YXJnZXQg5YaF44Gu6KaB57Sg44Gu5YCk44KS44CBbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44Gn5YiG5Ymy44GX5YaN5qeL56+J44GZ44KLXG4gICAgLy8gLy8gbGVuZ3Ro77yI44OQ44Kk44OI6ZW377yJ44KS6LaF44GI44KL5paH5a2X5YiX44Gv44CB5Y2K6KeS44K544Oa44O844K544Gn5YiG5Ymy44GZ44KLXG4gICAgLy8gVGV4dFV0aWwuc3BsaXRsZW5iKGNvbkxhYmVsLCBbJ+OBlOS+nemgvOS4uyDkvY/miYAxJywgJ+OBlOS+nemgvOS4uyDkvY/miYAyJywgJ+OBlOS+nemgvOS4uyDkvY/miYAzJ10sIDUwKTtcbiAgICAvLyBUZXh0VXRpbC5zcGxpdGxlbmIoY29uTGFiZWwsIFsn44GK5bGK44GR5YWIIOS9j+aJgDEnLCAn44GK5bGK44GR5YWIIOS9j+aJgDInLCAn44GK5bGK44GR5YWIIOS9j+aJgDMnXSwgNTApO1xuICAgIHJldHVybiBjb25MYWJlbDtcbiAgfVxuXG4gIHRyYW5zZm9ybUxhYmVsWXVwYWNrZXQoZG9jTGFiZWwsIGxhYmVsT3B0aW9ucykge1xuICAgIC8vIOWVhuWTgeOCs+ODvOODieOCkumAgeOCiueKtkNTVuOBq+Wfi+OCgei+vOOCgFxuICAgIGNvbnN0IG9yZGVyTnVtYmVyID0gZG9jTGFiZWxbJ+iomOS6i+WQje+8kSddLnJlcGxhY2UoJ+WPl+azqOeVquWPt++8micsICcnKTtcbiAgICAvLyBjb25zdCBjdXIgPSBSb2JvdGluT3JkZXJzLmZpbmQoe1xuICAgIC8vICAg5bqX6IiX5ZCNOiBkb2NMYWJlbFsn44GU5L6d6aC85Li7IOWQjeensDEnXSxcbiAgICAvLyAgIC8vIOWPl+azqENTVuWHuuWKm+OBleOCjOOBpuOBhOOCi+WPl+azqOeVquWPt+OBjOaWh+Wtl+WIl+W9ouW8j+OBp+OCguaVsOWApOW9ouW8j+OBp+OCguW8leOBo+OBi+OBi+OCi+OCiOOBhuOBq+OBmeOCi++8iCRpbu+8iVxuICAgIC8vICAg5Y+X5rOo55Wq5Y+3OiB7ICRpbjogW29yZGVyTnVtYmVyLCBOdW1iZXIob3JkZXJOdW1iZXIpXSB9XG4gICAgLy8gfSwge1xuICAgIC8vICAgZmllbGRzOiB7XG4gICAgLy8gICAgIF9pZDogMCxcbiAgICAvLyAgICAg5ZWG5ZOB44Kz44O844OJOiAxXG4gICAgLy8gICB9XG4gICAgLy8gfSk7XG4gICAgY29uc3QgaXRlbXMgPSBSb2JvdGluLmxpc3RJdGVtQ29kZUZvckxhYmVsKFxuICAgICAge1xuICAgICAgICAncm9ib3Rpbi7lupfoiJflkI0nOiBkb2NMYWJlbFsn44GU5L6d6aC85Li7IOWQjeensDEnXSxcbiAgICAgICAgLy8g5Y+X5rOoQ1NW5Ye65Yqb44GV44KM44Gm44GE44KL5Y+X5rOo55Wq5Y+344GM5paH5a2X5YiX5b2i5byP44Gn44KC5pWw5YCk5b2i5byP44Gn44KC5byV44Gj44GL44GL44KL44KI44GG44Gr44GZ44KL77yIJGlu77yJXG4gICAgICAgICdyb2JvdGluLuWPl+azqOeVquWPtyc6IHtcbiAgICAgICAgICAkaW46IFtvcmRlck51bWJlciwgTnVtYmVyKG9yZGVyTnVtYmVyKV0sXG4gICAgICAgIH0sXG4gICAgICB9LFxuICAgICAgLy8g5Y+X5rOo44K344K544OG44Og5L6L5aSW44Gu5aC05ZCI44CB5Lu75oSP44Gu44Kz44Os44Kv44K344On44Oz77yIbWluaW1vbmdv44Gu5LiA5pmC44OH44O844K/44OZ44O844K577yJ44GM6YG45oqe44Gn44GN44KLXG4gICAgICB0eXBlb2YgdGhpcy5PcmRlciA9PT0gJ3VuZGVmaW5lZCcgPyBudWxsIDogdGhpcy5PcmRlcixcbiAgICApO1xuXG4gICAgY29uc3QgY29uTGFiZWwgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGRvY0xhYmVsKSk7XG5cbiAgICAvLyDpgIHjgornirbnqK7liKXjgpLoqK3lrppcbiAgICBjb25MYWJlbFsn6YCB44KK54q256iu5YilJ10gPSBsYWJlbE9wdGlvbnMubGFiZWxJZDtcblxuICAgIGNvbkxhYmVsWyfoqJjkuovlkI3vvJEnXSA9IGl0ZW1zWzBdO1xuICAgIGNvbkxhYmVsWyfjg5Xjg6rjg7zpoIXnm67vvJDvvJEnXSA9IGl0ZW1zWzFdO1xuICAgIGNvbkxhYmVsWyfjg5Xjg6rjg7zpoIXnm67vvJDvvJUnXSA9IGl0ZW1zWzJdO1xuXG4gICAgLy8ga2V5UyDjgafmjIflrprjgZXjgozjgZ8gdGFyZ2V0IOWGheOBruimgee0oOOBruWApOOCkuOAgWxlbmd0aO+8iOODkOOCpOODiOmVt++8ieOBp+WIhuWJsuOBl+WGjeani+evieOBmeOCi1xuICAgIC8vIGxlbmd0aO+8iOODkOOCpOODiOmVt++8ieOCkui2heOBiOOCi+aWh+Wtl+WIl+OBr+OAgeWNiuinkuOCueODmuODvOOCueOBp+WIhuWJsuOBmeOCi1xuICAgIC8vIFRleHRVdGlsLnNwbGl0bGVuYihjb25MYWJlbCwgWyfjgZTkvp3poLzkuLsg5L2P5omAMScsICfjgZTkvp3poLzkuLsg5L2P5omAMicsICfjgZTkvp3poLzkuLsg5L2P5omAMyddLCA1MCk7XG4gICAgLy8gVGV4dFV0aWwuc3BsaXRsZW5iKGNvbkxhYmVsLCBbJ+OBiuWxiuOBkeWFiCDkvY/miYAxJywgJ+OBiuWxiuOBkeWFiCDkvY/miYAyJywgJ+OBiuWxiuOBkeWFiCDkvY/miYAzJ10sIDUwKTtcbiAgICByZXR1cm4gY29uTGFiZWw7XG4gIH1cbn1cbiIsImltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QtcHJvbWlzZSdcclxuaW1wb3J0IHsganNvbjJ4bWwgfSBmcm9tICd4bWwtanMnXHJcbmltcG9ydCB1dGlsRXJyb3IgZnJvbSAnLi4vdXRpbC9lcnJvcidcclxuXHJcbmNvbnN0IEJBU0VfVVJJID0gJ2h0dHBzOi8vYXBpLm1hbmFnZXIud293bWEuanAvd21zaG9wYXBpJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgV293bWFBcGkge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBzaG9wSWQpIHtcclxuICAgIHRoaXMucGx1ZyA9IHBsdWdcclxuICAgIHRoaXMuc2hvcElkID0gc2hvcElkXHJcbiAgfVxyXG5cclxuICAvLyDllYblk4Hmg4XloLHmm7TmlrBcclxuICBhc3luYyB1cGRhdGVJdGVtICh1cGRhdGVJdGVtKSB7XHJcbiAgICBsZXQgcmVxdWVzdCA9IGA8cmVxdWVzdD48c2hvcElkPiR7dGhpcy5zaG9wSWR9PC9zaG9wSWQ+PHVwZGF0ZUl0ZW0+JHtqc29uMnhtbCh1cGRhdGVJdGVtLCB7Y29tcGFjdDogdHJ1ZX0pfTwvdXBkYXRlSXRlbT48L3JlcXVlc3Q+YFxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucmVxdWVzdFBvc3QoXHJcbiAgICAgICAgJ3VwZGF0ZUl0ZW1JbmZvJyxcclxuICAgICAgICByZXF1ZXN0XHJcbiAgICAgIClcclxuICAgICAgcmV0dXJuIHtyZXNwb25zZTogcmVzLCByZXF1ZXN0WE1MOiByZXF1ZXN0fVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICB0aHJvdyBPYmplY3QuYXNzaWduKHV0aWxFcnJvci5wYXJzZShlKSwge3JlcXVlc3RYTUw6IHJlcXVlc3R9KVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcmVxdWVzdFBvc3QgKG1ldGhvZCwgYm9keSkge1xyXG4gICAgLy8g5o6l57aa44Kq44OX44K344On44Oz44Gu5L2c5oiQXHJcbiAgICBsZXQgYXBpUmVxdWVzdCA9IHtcclxuICAgICAgbWV0aG9kOiAnUE9TVCcsXHJcbiAgICAgIHVyaTogYCR7QkFTRV9VUkl9LyR7bWV0aG9kfWAsXHJcbiAgICAgIGJvZHk6IGJvZHlcclxuICAgIH1cclxuICAgIC8vIOWFsemAmuOBruaOpee2muioreWumuOBqOe1kOWQiOOBmeOCi1xyXG4gICAgT2JqZWN0LmFzc2lnbihhcGlSZXF1ZXN0LCB0aGlzLnBsdWcpXHJcblxyXG4gICAgLy8g44Oq44Kv44Ko44K544OI55m66KGMXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgcmVxdWVzdChhcGlSZXF1ZXN0KVxyXG5cclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZVN0b2NrIChzdG9ja1VwZGF0ZUl0ZW0pIHtcclxuICAgIC8vIOaOpee2muOCquODl+OCt+ODp+ODs+OBruS9nOaIkFxyXG4gICAgbGV0IGFwaVJlcXVlc3QgPSB7XHJcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICB1cmk6IGAke0JBU0VfVVJJfS91cGRhdGVTdG9ja2BcclxuICAgIH1cclxuICAgIC8vIOWFsemAmuOBruaOpee2muioreWumuOBqOe1kOWQiOOBmeOCi1xyXG4gICAgT2JqZWN0LmFzc2lnbihhcGlSZXF1ZXN0LCB0aGlzLnBsdWcpXHJcblxyXG4gICAgYXBpUmVxdWVzdC5ib2R5ID0gYXdhaXQgdGhpcy51cGRhdGVTdG9ja0NyZWF0ZVJlcXVlc3RCb2R5KHN0b2NrVXBkYXRlSXRlbSlcclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgIGxldCByZXMgPSBhd2FpdCByZXF1ZXN0KGFwaVJlcXVlc3QpXHJcblxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2tDcmVhdGVSZXF1ZXN0Qm9keSAoc3RvY2tVcGRhdGVJdGVtKSB7XHJcbiAgICAvL1xyXG4gICAgLy8gc3RvY2tVcGRhdGVJdGVtID1cclxuICAgIC8vIFtcclxuICAgIC8vICAge1xyXG4gICAgLy8gICAgIGl0ZW1Db2RlOiA8U3RyaW5nPixcclxuICAgIC8vICAgICB2YXJpYXRpb25zOiBbXHJcbiAgICAvLyAgICAgICAge1xyXG4gICAgLy8gICAgICAgICAgY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGU6IDxTdHJpbmc+LFxyXG4gICAgLy8gICAgICAgICAgY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlOiA8U3RyaW5nPixcclxuICAgIC8vICAgICAgICAgIHN0b2NrOiA8TnVtYmVyPlxyXG4gICAgLy8gICAgICAgIH1cclxuICAgIC8vICAgICBdXHJcbiAgICAvLyAgIH1cclxuICAgIC8vIF1cclxuXHJcbiAgICBsZXQgc3RvY2tVcGRhdGVJdGVtWE1MID0gJydcclxuXHJcbiAgICBmb3IgKGxldCBpdGVtIG9mIHN0b2NrVXBkYXRlSXRlbSkge1xyXG4gICAgICAvLyDlgKTjga7jg4Hjgqfjg4Pjgq9cclxuICAgICAgZm9yIChsZXQgZSBvZiBpdGVtLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICAvLyDlnKjluqvmlbDjga7kuIrpmZAxMDBcclxuICAgICAgICBpZiAoZS5zdG9jayA+IDEwMCkgZS5zdG9jayA9IDEwMFxyXG4gICAgICB9XHJcblxyXG4gICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxzdG9ja1VwZGF0ZUl0ZW0+J1xyXG4gICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gYDxpdGVtQ29kZT4ke2l0ZW0uaXRlbUNvZGV9PC9pdGVtQ29kZT5gXHJcblxyXG4gICAgICAvLyDllYblk4HlnKjluqvnqK7liKXjgpLmjK/jgorliIbjgZFcclxuICAgICAgLy8gMSAtPiDpgJrluLjllYblk4FcclxuICAgICAgLy8gMiAtPiDpgbjmip7ogqLliKXlnKjluqtcclxuXHJcbiAgICAgIGxldCB2YXIwID0gaXRlbS52YXJpYXRpb25zWzBdXHJcbiAgICAgIGlmICh2YXIwLmNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlID09PSAnJyAmJiB2YXIwLmNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZSA9PT0gJycpIHtcclxuICAgICAgICAvLyDpgJrluLjllYblk4FcclxuICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxzdG9ja1NlZ21lbnQ+MTwvc3RvY2tTZWdtZW50PidcclxuICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gYDxzdG9ja0NvdW50PiR7dmFyMC5zdG9ja308L3N0b2NrQ291bnQ+YFxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIC8vIOmBuOaKnuiCouWIpeWcqOW6q1xyXG4gICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPHN0b2NrU2VnbWVudD4yPC9zdG9ja1NlZ21lbnQ+J1xyXG5cclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqPjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICBmb3IgKGxldCB2YXJpYXRpb24gb2YgaXRlbS52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgICAvLyDlnKjluqvoqK3lrprjgr/jgrDjga7lkI3liY3jgpLlt67jgZfmm7/jgYjjgotcclxuICAgICAgICAgIHZhcmlhdGlvbi5jaG9pY2VzU3RvY2tDb3VudCA9IHZhcmlhdGlvbi5zdG9ja1xyXG4gICAgICAgICAgZGVsZXRlIHZhcmlhdGlvbi5zdG9ja1xyXG5cclxuICAgICAgICAgIC8vIHhtbOOCkuani+aIkOOBmeOCi1xyXG4gICAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8Y2hvaWNlc1N0b2Nrcz4nXHJcbiAgICAgICAgICBmb3IgKGxldCBrZXkgb2YgT2JqZWN0LmtleXModmFyaWF0aW9uKSkge1xyXG4gICAgICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gYDwke2tleX0+JHt2YXJpYXRpb25ba2V5XX08LyR7a2V5fT5gXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzwvY2hvaWNlc1N0b2Nrcz4nXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcblxyXG4gICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzwvc3RvY2tVcGRhdGVJdGVtPidcclxuICAgIH1cclxuXHJcbiAgICAvLyDjg6rjgq/jgqjjgrnjg4jjg5zjg4fjgqPjga7kvZzmiJBcclxuICAgIGxldCBhcGlSZXF1ZXN0Qm9keSA9IGBcclxuICAgIDxyZXF1ZXN0PlxyXG4gICAgPHNob3BJZD4ke3RoaXMuc2hvcElkfTwvc2hvcElkPlxyXG4gICAgJHtzdG9ja1VwZGF0ZUl0ZW1YTUx9XHJcbiAgICA8L3JlcXVlc3Q+XHJcbiAgICBgXHJcblxyXG4gICAgLy8g44Oq44Kv44Ko44K544OI44Oc44OH44Kj44KS6L+U44GZXHJcbiAgICByZXR1cm4gYXBpUmVxdWVzdEJvZHlcclxuICB9XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgdXRpbEVycm9yIHtcclxuICBzdGF0aWMgcGFyc2UgKGUpIHtcclxuICAgIGxldCByZXMgPSB7fVxyXG5cclxuICAgIGlmIChlIGluc3RhbmNlb2YgRXJyb3IpIHtcclxuICAgICAgcmVzLm1lc3NhZ2UgPSBlLm1lc3NhZ2VcclxuICAgICAgcmVzLm5hbWUgPSBlLm5hbWVcclxuICAgICAgcmVzLmZpbGVOYW1lID0gZS5maWxlTmFtZVxyXG4gICAgICByZXMubGluZU51bWJlciA9IGUubGluZU51bWJlclxyXG4gICAgICByZXMuY29sdW1uTnVtYmVyID0gZS5jb2x1bW5OdW1iZXJcclxuICAgICAgcmVzLnN0YWNrID0gZS5zdGFja1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmVzID0gZVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiByZXNcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tICdtb25nb2RiJztcblxuZXhwb3J0IGNsYXNzIE1vbmdvQ29sbGVjdGlvbiB7XG4gIHN0YXRpYyBhc3luYyBnZXQgKHBsdWcsIGNvbGxlY3Rpb24pIHtcbiAgICBjb25zdCBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpLCB7IHVzZU5ld1VybFBhcnNlcjogdHJ1ZSB9KTtcbiAgICBjb25zdCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKTtcbiAgICByZXR1cm4gZGIuY29sbGVjdGlvbihjb2xsZWN0aW9uKTtcbiAgfVxufVxuIiwiaW1wb3J0IG15c3FsIGZyb20gJ215c3FsJztcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50JztcblxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlTUUwge1xuICBjb25zdHJ1Y3RvciAocHJvZmlsZSkge1xuICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+ODl+ODvOODq+WIneacn+WMllxuICAgIHRoaXMucG9vbCA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZSk7XG5cbiAgICAvLyDopIfmlbDooYzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jlr77lv5xcbiAgICBjb25zdCBwcm9maWxlTXVsdGkgPSB7IG11bHRpcGxlU3RhdGVtZW50czogdHJ1ZSB9O1xuICAgIE9iamVjdC5hc3NpZ24ocHJvZmlsZU11bHRpLCBwcm9maWxlKTtcbiAgICB0aGlzLnBvb2xNdWx0aSA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZU11bHRpKTtcbiAgfVxuXG4gIGFzeW5jIHF1ZXJ5U2VsZWN0KHRhYmxlLCBjb25kaXRpb24sIHByb2R1Y3QgPSAnKicpIHtcblxuICAgIGNvbnN0IHByb2R1Y3RQYXJ0ID0gcHJvZHVjdDtcbiAgICBjb25zdCB0YWJsZVBhcnQgPSBgRlJPTSAke3RhYmxlfWA7XG4gICAgY29uc3QgY29uZGl0aW9uUGFydCA9IGNvbmRpdGlvbiA/IGBXSEVSRSAke2NvbmRpdGlvbn1gIDogJyc7XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KGBTRUxFQ1QgJHtwcm9kdWN0UGFydH0gJHt0YWJsZVBhcnR9ICR7Y29uZGl0aW9uUGFydH1gKTtcblxuICAgIC8vIFNFTEVDVOOBrue1kOaenOOBr+ODh+OCo+ODvOODl+OCs+ODlOODvOOBmeOCi+OBk+OBqOOBpyByb3dkYXRhcGFja2V0IOOCkuWkluOBmVxuICAgIHJldHVybiBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KHJlcykpO1xuICB9XG5cbiAgc3RhdGljIGZvcm1hdERhdGUgKGRhdGUpIHtcbiAgICByZXR1cm4gbW9tZW50KGRhdGUpLmZvcm1hdCgpLnN1YnN0cmluZygwLCAxOSkucmVwbGFjZSgnVCcsICcgJyk7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNxbFxuICAgKi9cbiAgcXVlcnkgKHNxbCkge1xuICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+eiuueri1xuICAgIC8vIGxldCBjb24gPSBhd2FpdCB0aGlzLmdldENvbigpO1xuICAgIHJldHVybiB0aGlzLmdldENvbigpXG4gICAgICAudGhlbihcbiAgICAgICAgKGNvbikgPT4gbmV3IFByb21pc2UoXG4gICAgICAgICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsLCAoZSwgcmVzKSA9PiB7XG4gICAgICAgICAgICAgICAgLy8g44Kz44ON44Kv44K344On44Oz6ZaL5pS+XG4gICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxuICAgICAgICAgICAgICAgIGlmIChlKSB7XG4gICAgICAgICAgICAgICAgICByZWplY3QoZSlcbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXMpXG4gICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICB9XG4gICAgICAgICAgKSxcbiAgICAgIClcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xuICAgICAgICB0aHJvdyBlO1xuICAgICAgfSk7XG4gIH1cblxuICBhc3luYyBxdWVyeUluc2VydF8gKHNxbCkge1xuICAgIGNvbnN0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcbiAgICByZXR1cm4gcmVzLmluc2VydElkO1xuICB9XG5cbiAgLyoqXG4gICAqXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB0YWJsZVxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7zjgIFudWxs44CBamF2YXNjcmlwdC0+bXlzcWzml6Xku5jlpInmj5vjgavjgoLlr77lv5xcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XG4gICAqL1xuICBhc3luYyBxdWVyeUluc2VydCAodGFibGUsIGRhdGEgPSB7fSwgZGF0YVNxbCA9IHt9KSB7XG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcbiAgICAvLyByZXR1cm4gcmVzLmluc2VydElkO1xuXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgO1xuXG4gICAgY29uc3QgbWFwID0gbmV3IE1hcCgpO1xuICAgIGZvciAoY29uc3QgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xuICAgICAgaWYgKGRhdGFba10gPT09IG51bGwpIHtcbiAgICAgICAgbWFwLnNldChrLCAnTlVMTCcpO1xuICAgICAgfSBlbHNlIGlmIChkYXRhW2tdLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xuICAgICAgICAvLyDml6Xku5jjgpLlpInmj5tcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKTtcbiAgICAgIH0gZWxzZSB7XG4gICAgICAgIG1hcC5zZXQoaywgYCR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApO1xuICAgICAgfVxuICAgIH1cbiAgICBmb3IgKGNvbnN0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcbiAgICAgIG1hcC5zZXQoaywgZGF0YVNxbFtrXSA9PT0gbnVsbCA/ICdOVUxMJyA6IGRhdGFTcWxba10pO1xuICAgIH1cblxuICAgIHNxbCArPSBgKCAke1suLi5tYXAua2V5cygpXS5qb2luKCcsJyl9ICkgYDtcblxuICAgIHNxbCArPSBgVkFMVUVTKCAke1suLi5tYXAudmFsdWVzKCldLmpvaW4oJywnKX0gKSBgO1xuXG4gICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xuICAgIHJldHVybiByZXMuaW5zZXJ0SWQ7XG4gIH1cblxuICAvKipcbiAgICpcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBmaWx0ZXIgU1FMIFVQREFUReOCueODhuODvOODiOODoeODs+ODiOOBrldIRVJF5Y+lXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvFxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cbiAgICovXG4gIGFzeW5jIHF1ZXJ5VXBkYXRlICh0YWJsZSwgZmlsdGVyLCBkYXRhLCBkYXRhU3FsKSB7XG4gICAgbGV0IHNxbCA9IGBVUERBVEUgJHt0YWJsZX0gU0VUIGA7XG5cbiAgICBjb25zdCB1cGRhdGVzID0gW107XG4gICAgZm9yIChjb25zdCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtteXNxbC5lc2NhcGUoZGF0YVtrXSl9YCk7XG4gICAgfVxuICAgIGZvciAoY29uc3QgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xuICAgICAgdXBkYXRlcy5wdXNoKGAke2t9PSR7ZGF0YVNxbFtrXX1gKTtcbiAgICB9XG4gICAgc3FsICs9IHVwZGF0ZXMuam9pbignLCcpO1xuXG4gICAgc3FsICs9IGAgV0hFUkUgJHtmaWx0ZXJ9IGA7XG5cbiAgICBjb25zdCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XG4gICAgcmV0dXJuIHJlcztcbiAgfVxuXG4gIC8vIGVuYWJsZSB0byB1c2UgbXVsdGlwbGUgc3RhdGVtZW50c1xuICBhc3luYyBxdWVyeU11bHRpIChzcWwpIHtcbiAgICBjb25zdCBwb29sU3dhcCA9IHRoaXMucG9vbDtcbiAgICB0aGlzLnBvb2wgPSB0aGlzLnBvb2xNdWx0aTtcbiAgICB0cnkge1xuICAgICAgY29uc3QgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xuICAgICAgcmV0dXJuIHJlcztcbiAgICB9IGZpbmFsbHkge1xuICAgICAgdGhpcy5wb29sID0gcG9vbFN3YXA7XG4gICAgfVxuICB9XG5cbiAgYXN5bmMgc3RhcnRUcmFuc2FjdGlvbiAoKSB7XG4gICAgYXdhaXQgdGhpcy5xdWVyeSgnU1RBUlQgVFJBTlNBQ1RJT047Jyk7XG4gIH1cblxuICBhc3luYyBjb21taXQgKCkge1xuICAgIGF3YWl0IHRoaXMucXVlcnkoJ0NPTU1JVDsnKTtcbiAgfVxuXG4gIGFzeW5jIHJvbGxiYWNrICgpIHtcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KCdST0xMQkFDSzsnKTtcbiAgfVxuXG4gIHN0cmVhbWluZ1F1ZXJ5IChzcWwsIG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pIHtcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxuICAgICAgLnRoZW4oXG4gICAgICAgIChjb24pID0+IG5ldyBQcm9taXNlKFxuICAgICAgICAgICAgYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcbiAgICAgICAgICAgICAgY29uLnF1ZXJ5KHNxbClcbiAgICAgICAgICAgICAgICAub24oJ3Jlc3VsdCcsXG4gICAgICAgICAgICAgICAgICAocmVjb3JkKSA9PiB7XG4gICAgICAgICAgICAgICAgICAgIGNvbi5wYXVzZSgpXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0KHJlY29yZClcbiAgICAgICAgICAgICAgICAgICAgY29uLnJlc3VtZSgpXG4gICAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoZSkgPT4ge1xuICAgICAgICAgICAgICAgICAgb25FcnJvcihlKVxuICAgICAgICAgICAgICAgIH0pXG4gICAgICAgICAgICAgICAgLm9uKCdlbmQnLCAoKSA9PiB7XG4gICAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpXG4gICAgICAgICAgICAgICAgICByZXNvbHZlKClcbiAgICAgICAgICAgICAgICB9KVxuICAgICAgICAgICAgfVxuICAgICAgICAgICksXG4gICAgICApXG4gICAgICAuY2F0Y2goKGUpID0+IHtcbiAgICAgICAgdGhyb3cgZTtcbiAgICAgIH0pO1xuICB9XG5cbiAgZ2V0Q29uICgpIHtcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XG4gICAgICAgIC8vIOODl+ODvOODq+OBi+OCieOBruOCs+ODjeOCr+OCt+ODp+ODs+eNsuW+l1xuICAgICAgICB0aGlzLnBvb2wuZ2V0Q29ubmVjdGlvbigoZSwgY29uKSA9PiB7XG4gICAgICAgICAgaWYgKGUpIHtcbiAgICAgICAgICAgIHJlamVjdChlKTtcbiAgICAgICAgICB9IGVsc2Uge1xuICAgICAgICAgICAgcmVzb2x2ZShjb24pO1xuICAgICAgICAgIH1cbiAgICAgICAgfSk7XG4gICAgICB9LFxuICAgIClcbiAgICAgIC5jYXRjaChcbiAgICAgICAgKGUpID0+IHtcbiAgICAgICAgICB0aHJvdyBlO1xuICAgICAgICB9LFxuICAgICAgKTtcbiAgfVxufVxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgUGFja2V0IHtcclxuICBjb25zdHJ1Y3RvciAocGFja2V0U2l6ZSkge1xyXG4gICAgdGhpcy5wYWNrZXRTaXplID0gcGFja2V0U2l6ZVxyXG4gICAgdGhpcy5vblBhY2tldFN0YXJ0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldCA9IG51bGxcclxuICAgIHRoaXMub25QYWNrZXRFbmQgPSBudWxsXHJcbiAgICB0aGlzLmNvdW50ID0gMFxyXG4gICAgdGhpcy5wYWNrZXRDb3VudCA9IDBcclxuICB9XHJcblxyXG4gIGFzeW5jIHN1Ym1pdCAoYXJnKSB7XHJcbiAgICAvLyBwYWNrZXRTaXpl44Gu5Zue5pWw44GU44Go44Gr44CB5Yid5pyf5YyW44KS5ZG844Gz5Ye644GZXHJcbiAgICBpZiAodGhpcy5jb3VudCAlIHRoaXMucGFja2V0U2l6ZSA9PT0gMCkge1xyXG4gICAgICBpZiAodGhpcy5vblBhY2tldFN0YXJ0KSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5vblBhY2tldFN0YXJ0KHRoaXMucGFja2V0Q291bnQpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGlmICh0aGlzLm9uUGFja2V0KSB7XHJcbiAgICAgIGF3YWl0IHRoaXMub25QYWNrZXQoYXJnKVxyXG4gICAgfVxyXG4gICAgdGhpcy5jb3VudCsrXHJcbiAgICAvLyBwYWNrZXRTaXpl44Gu5Zue5pWw44GU44Go44Gr44CB57WC5LqG5Yem55CG44KS5ZG844Gz5Ye644GZXHJcbiAgICBpZiAodGhpcy5jb3VudCAlIHRoaXMucGFja2V0U2l6ZSA9PT0gMCkge1xyXG4gICAgICB0aGlzLmNsb3NlKClcclxuICAgICAgdGhpcy5wYWNrZXRDb3VudCsrXHJcbiAgICB9XHJcbiAgfVxyXG4gIGNsb3NlICgpIHtcclxuICAgIGlmICh0aGlzLm9uUGFja2V0RW5kKSB7XHJcbiAgICAgIHRoaXMub25QYWNrZXRFbmQodGhpcy5wYWNrZXRDb3VudClcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHV0aWxFcnJvciBmcm9tICcuL2Vycm9yJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IHsgTG9ncyB9IGZyb20gJy4uL2NvbGxlY3Rpb25zJ1xyXG5pbXBvcnQgdW5pcWlkIGZyb20gJ3VuaXFpZCdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFJlcG9ydCB7XHJcbiAgY29uc3RydWN0b3IgKCkge1xyXG4gICAgdGhpcy5yZWNvcmQgPSBbXVxyXG4gICAgdGhpcy5pdGVyYXRvcnMgPSBbXVxyXG4gICAgdGhpcy5pdGVyYXRvciA9IG51bGxcclxuICB9XHJcblxyXG4gIC8vIHByaXZhdGVcclxuICBzZXR1cEl0ZXJhdG9yIChwaGFzZUlkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbmV3IEl0ZXJhdG9yKHBoYXNlSWQpXHJcbiAgICB0aGlzLml0ZXJhdG9ycy5wdXNoKHRoaXMuaXRlcmF0b3IpXHJcbiAgfVxyXG5cclxuICBhc3luYyBwaGFzZSAobmFtZSA9ICcnLCBmbiA9IGFzeW5jICgpID0+IHt9KSB7XHJcbiAgICBsZXQgcmVjID0ge1xyXG4gICAgICBwaGFzZUlkOiB1bmlxaWQoKVxyXG4gICAgfVxyXG5cclxuICAgIHRoaXMuc2V0dXBJdGVyYXRvcihyZWMucGhhc2VJZClcclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgZm4oKVxyXG5cclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnc3VjY2VzcycsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiByZXNcclxuICAgICAgfSlcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogdXRpbEVycm9yLnBhcnNlKGUpXHJcbiAgICAgIH0pXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICAvLyDjg6vjg7zjg5flh6bnkIbjga7jg6zjg53jg7zjg4jjgpLkvZzmiJBcclxuICAgICAgaWYgKHRoaXMuaXRlcmF0b3IubWV0cmljLnRvdGFsKSB7XHJcbiAgICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICAgIGl0ZXJhdG9yOiB0aGlzLml0ZXJhdG9yLm1ldHJpY1xyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICAgLy8g44K/44Kk44Og44K544K/44Oz44OXXHJcbiAgICAgIHJlYy50aW1lU3RhbXAgPSBuZXcgRGF0ZSgpXHJcbiAgICAgIC8vIOODrOODneODvOODiOOCkuODh+ODvOOCv+ODmeODvOOCueOBq+iomOmMslxyXG4gICAgICBMb2dzLmluc2VydChyZWMpXHJcblxyXG4gICAgICAvLyDlkbzjgbPlh7rjgZflhYPnlKjjg6zjg53jg7zjg4jjgavov73liqBcclxuICAgICAgdGhpcy5yZWNvcmQucHVzaChyZWMpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvLyDjgqvjg7zjgr3jg6vjgpLjg6vjg7zjg5fjgZfjgIHkuI7jgYjjgonjgozjgZ/plqLmlbDjgpLlrp/ooYxcclxuICAvLyDlkbzjgbPlh7rjgZnplqLmlbDjga7lvJXmlbDjgavjga/jgqvjg7zjgr3jg6vjgYvjgonlvpfjgonjgozjgZ/jg4njgq3jg6Xjg6Hjg7Pjg4jjgpLmuKHjgZlcclxuICBhc3luYyBmb3JFYWNoT25DdXJzb3IgKGN1ciwgZm4pIHtcclxuICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XHJcbiAgICAgIGxldCBkb2MgPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgLy8g44Oq44Kv44Ko44K544OI55m66KGMXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZuKGRvYylcclxuICAgICAgICB0aGlzLmlTdWNjZXNzKHJlcylcclxuICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgIHRoaXMuaUVycm9yKGUpXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGN1ci5jbG9zZSgpXHJcbiAgfVxyXG5cclxuICBpU3VjY2VzcyAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLnN1Y2Nlc3MobmV3UmVjb3JkKVxyXG4gIH1cclxuXHJcbiAgaUVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IuZXJyb3IodXRpbEVycm9yLnBhcnNlKG5ld1JlY29yZCkpXHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQgKCkge1xyXG4gICAgbGV0IGl0ZUVycm9yID0gdGhpcy5pdGVyYXRvcnMuZmluZChlID0+IGUuZXJyb3JPY3VycmVkKCkpXHJcbiAgICBsZXQgcGhhRXJyb3IgPSBmYWxzZVxyXG4gICAgZm9yIChsZXQgcmVjIG9mIHRoaXMucmVjb3JkKSB7XHJcbiAgICAgIGlmIChyZWMudHlwZSA9PT0gJ2Vycm9yJykge1xyXG4gICAgICAgIHBoYUVycm9yID0gdHJ1ZVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBpdGVFcnJvciB8fCBwaGFFcnJvclxyXG4gIH1cclxuXHJcbiAgcHVibGlzaCAoKSB7XHJcbiAgICAvLyDlkbzjgbPlh7rjgZflhYPjgbjjg6zjg53jg7zjg4hcclxuICAgIGlmICh0aGlzLmVycm9yT2N1cnJlZCgpKSB7XHJcbiAgICAgIHRocm93IG5ldyBNZXRlb3IuRXJyb3IodGhpcy5yZWNvcmQpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5yZWNvcmRcclxuICB9XHJcbn1cclxuXHJcbmNsYXNzIEl0ZXJhdG9yIHtcclxuICBjb25zdHJ1Y3RvciAocGhhc2VJZCkge1xyXG4gICAgdGhpcy5tZXRyaWMgPSB7XHJcbiAgICAgIHRvdGFsOiAwLFxyXG4gICAgICBzdWNjZXNzOiAwLFxyXG4gICAgICBlcnJvcjogMCxcclxuICAgICAgcGhhc2VJZDogcGhhc2VJZFxyXG4gICAgfVxyXG4gICAgdGhpcy5sYXN0RXJyb3IgPSBudWxsXHJcbiAgfVxyXG5cclxuICBzdWNjZXNzIChuZXdSZWNvcmQpIHtcclxuICAgIGlmIChuZXdSZWNvcmQpIHtcclxuICAgICAgdGhpcy5sb2cobmV3UmVjb3JkLCB0cnVlKVxyXG4gICAgfVxyXG4gICAgdGhpcy5tZXRyaWMuc3VjY2VzcysrXHJcbiAgICB0aGlzLm1ldHJpYy50b3RhbCsrXHJcbiAgfVxyXG5cclxuICBlcnJvciAobmV3UmVjb3JkKSB7XHJcbiAgICAvLyDnm7TliY3jgajlkIzjgZjjgqjjg6njg7zjga/nnIHjgY9cclxuICAgIGlmIChKU09OLnN0cmluZ2lmeSh0aGlzLmxhc3RFcnJvcikgIT09IEpTT04uc3RyaW5naWZ5KG5ld1JlY29yZCkpIHtcclxuICAgICAgaWYgKG5ld1JlY29yZCAmJiBuZXdSZWNvcmQgIT09IHt9ICYmIG5ld1JlY29yZCAhPT0gJycpIHtcclxuICAgICAgICB0aGlzLmxvZyhuZXdSZWNvcmQsIGZhbHNlKVxyXG4gICAgICAgIHRoaXMubGFzdEVycm9yID0gbmV3UmVjb3JkXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHRoaXMubWV0cmljLmVycm9yKytcclxuICAgIHRoaXMubWV0cmljLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGxvZyAobmV3UmVjb3JkLCBpc1N1Y2Nlc3MgLyogdHJ1ZSA9PiBzdWNjZXNzIG9yIGZhbHNlID0+IGVycm9yICovKSB7XHJcbiAgICBsZXQgcmVjID0ge1xyXG4gICAgICBzdWNjZXNzOiBpc1N1Y2Nlc3MsXHJcbiAgICAgIHBoYXNlSWQ6IHRoaXMubWV0cmljLnBoYXNlSWQsXHJcbiAgICAgIG1lc3NhZ2U6IG5ld1JlY29yZCxcclxuICAgICAgdGltZVN0YW1wOiBuZXcgRGF0ZSgpXHJcbiAgICB9XHJcbiAgICBMb2dzLmluc2VydChyZWMpXHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQgKCkge1xyXG4gICAgcmV0dXJuIHRoaXMubWV0cmljLmVycm9yXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCBfIGZyb20gJ2xvZGFzaCc7XG5cbi8qKlxuICpcbiAqIEBwYXJhbSB7W09iamVjdF19IHNyY1xuICogQHBhcmFtIHtbT2JqZWN0XX0gZHN0XG4gKiBAcGFyYW0ge3N0cmluZ30gaWRrZXlcbiAqIEBwYXJhbSB7ZnVuY3Rpb24oYW55LCBPYmplY3QpfSBjcmVhdGVcbiAqIEBwYXJhbSB7ZnVuY3Rpb24oYW55LCBPYmplY3QpfSByZW1vdmVcbiAqL1xuZXhwb3J0IGRlZmF1bHQgYXN5bmMgZnVuY3Rpb24gc3luY09iamVjdChcbiAgc3JjLCBkc3QsIGlka2V5ID0gbnVsbCwgYWRkRnVuYywgcmVtRnVuYyxcbikge1xuICBjb25zdCBzcmNDb250YWluZXIgPSBbXTtcbiAgY29uc3QgZHN0Q29udGFpbmVyID0gW107XG5cbiAgY29uc3QgaWREZWxldGVkQ2xvbmUgPSAoZWxlbSwgaWRrZXlBUCkgPT4ge1xuICAgIGNvbnN0IGVsZW1TYXZlID0gXy5jbG9uZURlZXAoZWxlbSk7XG4gICAgLy8gaWQg44KS5q+U6LyD5a++6LGh44GL44KJ5aSW44GZXG4gICAgaWYgKF8uaXNVbmRlZmluZWQoZWxlbVNhdmVbaWRrZXlBUF0pID09PSBmYWxzZSkge1xuICAgICAgZGVsZXRlIGVsZW1TYXZlW2lka2V5QVBdO1xuICAgIH1cbiAgICAvLyDjg4fjgqPjg7zjg5fjgq/jg63jg7zjg7PjgZfjgZ/jgqrjg5bjgrjjgqfjgq/jg4jjgpLov5TjgZlcbiAgICByZXR1cm4gZWxlbVNhdmU7XG4gIH07XG5cbiAgLy8g44Kq44OW44K444Kn44Kv44OI5q+U6LyD44Gu5YmN5rqW5YKZXG4gIHNyYy5mb3JFYWNoKChlbGVtKSA9PiB7XG4gICAgc3JjQ29udGFpbmVyLnB1c2goe1xuICAgICAgb2JqZWN0OiBpZERlbGV0ZWRDbG9uZShlbGVtLCBpZGtleSksXG4gICAgICBpZDogZWxlbVtpZGtleV0sXG4gICAgICBzdGF0ZToge1xuICAgICAgICAvKipcbiAgICAgICAgICogdHJ1ZSDkvZXjgoLjgZfjgarjgYRcbiAgICAgICAgICogZmFsc2Ug5paw6KaP44Gr5L2c5oiQXG4gICAgICAgICAqL1xuICAgICAgICBmaW5kOiBmYWxzZSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIGRzdC5mb3JFYWNoKChlbGVtKSA9PiB7XG4gICAgZHN0Q29udGFpbmVyLnB1c2goe1xuICAgICAgb2JqZWN0OiBpZERlbGV0ZWRDbG9uZShlbGVtLCBpZGtleSksXG4gICAgICBpZDogZWxlbVtpZGtleV0sXG4gICAgICBzdGF0ZToge1xuICAgICAgICAvKipcbiAgICAgICAgICogdHJ1ZSDkvZXjgoLjgZfjgarjgYRcbiAgICAgICAgICogZmFsc2Ug5YmK6Zmk44GZ44KLXG4gICAgICAgICAqL1xuICAgICAgICBmaW5kOiBmYWxzZSxcbiAgICAgIH0sXG4gICAgfSk7XG4gIH0pO1xuXG4gIC8vIOOCquODluOCuOOCp+OCr+ODiOOCkuavlOi8g1xuICBzcmNDb250YWluZXIuZm9yRWFjaCgoc3JjRWxlbSkgPT4ge1xuICAgIGRzdENvbnRhaW5lci5mb3JFYWNoKChkc3RFbGVtKSA9PiB7XG4gICAgICBpZiAoXy5pc0VxdWFsKHNyY0VsZW0ub2JqZWN0LCBkc3RFbGVtLm9iamVjdCkpIHtcbiAgICAgICAgLy8g5ZCM44GY44Kq44OW44K444Kn44Kv44OI44GM6KaL44Gk44GL44Gj44Gf5aC05ZCIXG4gICAgICAgIHNyY0VsZW0uc3RhdGUuZmluZCA9IHRydWU7XG4gICAgICAgIGRzdEVsZW0uc3RhdGUuZmluZCA9IHRydWU7XG4gICAgICB9XG4gICAgfSk7XG4gIH0pO1xuXG4gIC8vIOODh+ODvOOCv+OBruaMv+WFpVxuICBhd2FpdCBQcm9taXNlLmFsbChzcmNDb250YWluZXIubWFwKGFzeW5jIChlbGVtKSA9PiB7XG4gICAgaWYgKGVsZW0uc3RhdGUuZmluZCA9PT0gZmFsc2UpIHtcbiAgICAgIGF3YWl0IGFkZEZ1bmMoZWxlbS5pZCwgZWxlbS5vYmplY3QpO1xuICAgIH1cbiAgfSkpO1xuXG4gIC8vIOODh+ODvOOCv+OBruWJiumZpFxuICBhd2FpdCBQcm9taXNlLmFsbChkc3RDb250YWluZXIubWFwKGFzeW5jIChlbGVtKSA9PiB7XG4gICAgaWYgKGVsZW0uc3RhdGUuZmluZCA9PT0gZmFsc2UpIHtcbiAgICAgIGF3YWl0IHJlbUZ1bmMoZWxlbS5pZCwgZWxlbS5vYmplY3QpO1xuICAgIH1cbiAgfSkpO1xufVxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGV4dFV0aWwge1xyXG4gIC8vIDjjg5Pjg4Pjg4jjgafmloflrZfliJfliIfjgorlj5bjgotcclxuICBzdGF0aWMgc3Vic3RyOCAodGV4dCwgbGVuLCB0cnVuY2F0aW9uKSB7XHJcbiAgICBpZiAodHJ1bmNhdGlvbiA9PT0gdW5kZWZpbmVkKSB7IHRydW5jYXRpb24gPSAnJyB9XHJcbiAgICB2YXIgdGV4dEFycmF5ID0gdGV4dC5zcGxpdCgnJylcclxuICAgIHZhciBjb3VudCA9IDBcclxuICAgIHZhciBzdHIgPSAnJ1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCB0ZXh0QXJyYXkubGVuZ3RoOyBpKyspIHtcclxuICAgICAgdmFyIG4gPSBlc2NhcGUodGV4dEFycmF5W2ldKVxyXG4gICAgICBpZiAobi5sZW5ndGggPCA0KSBjb3VudCsrXHJcbiAgICAgIGVsc2UgY291bnQgKz0gMlxyXG4gICAgICBpZiAoY291bnQgPiBsZW4pIHtcclxuICAgICAgICByZXR1cm4gc3RyICsgdHJ1bmNhdGlvblxyXG4gICAgICB9XHJcbiAgICAgIHN0ciArPSB0ZXh0LmNoYXJBdChpKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRleHRcclxuICB9XHJcblxyXG4gIC8vIOaWh+Wtl+WIl+OBruODkOOCpOODiOaVsOOCkuaVsOOBiOOCi1xyXG4gIHN0YXRpYyBsZW5iICh0ZXh0KSB7XHJcbiAgICByZXR1cm4gZW5jb2RlVVJJQ29tcG9uZW50KHRleHQpLnJlcGxhY2UoLyUuLiUuLiUuLi9nLCAneHgnKS5sZW5ndGhcclxuICB9XHJcblxyXG4gIHN0YXRpYyBzcGxpdGxlbmIgKHRhcmdldCwga2V5UywgbGVuZ3RoKSB7XHJcbiAgICBjb25zdCBzZXAgPSAnICdcclxuICAgIC8vIGtleVMg44Gn5oyH5a6a44GV44KM44GfIHRhcmdldCDlhoXjga7opoHntKDjga7lgKTjgpLjgZnjgbnjgabntZDlkIjjgZfjgZ/mloflrZfliJfjgpLkvZzjgotcclxuICAgIGNvbnN0IHN0ckVudGlyZSA9IGtleVMucmVkdWNlKChwcmV2LCBjdXJyZW50KSA9PiBwcmV2ICsgdGFyZ2V0W2N1cnJlbnRdLCAnJylcclxuICAgIC8vIOe1kOWQiOOBl+OBn+aWh+Wtl+WIl+OCkuWNiuinkuOCueODmuODvOOCueOBp+WIhuWJsuOBmeOCi1xyXG4gICAgY29uc3QgYXJyRW50aXJlID0gc3RyRW50aXJlLnNwbGl0KHNlcClcclxuICAgIGxldCBhcnJSZXMgPSBbXVxyXG4gICAgbGV0IGxhc3QgPSAnJ1xyXG4gICAgLy8g44OQ44Kk44OI6ZW344GMbGVuZ3Ro44KS6LaF44GI44Gq44GE6ZmQ44KK5YmN5b6M44Gu5YiG5Ymy5paH5a2X5YiX44KS57WQ5ZCI44GX44Gm44GE44GPXHJcbiAgICAvLyDjg5DjgqTjg4jplbfjgYxsZW5ndGjjgpLotoXjgYjjgZ/jgonjgIHjgbLjgajjgaTjgb7jgYjjga7ntZDlkIjmloflrZfliJfjgpLphY3liJfnmbvpjLLjgZnjgotcclxuICAgIHRyeSB7XHJcbiAgICAgIGFyckVudGlyZS5yZWR1Y2UoKHByZXYsIGN1cnJlbnQpID0+IHtcclxuICAgICAgICAvLyBsZW5ndGgg44KS6LaF44GI44KL44OQ44Kk44OI6ZW344Gu5YiG5Ymy5paH5a2X5YiX44GM44GC44KL5aC05ZCI44Gv5L2V44KC44GX44Gq44GEXHJcbiAgICAgICAgaWYgKFRleHRVdGlsLmxlbmIoY3VycmVudCkgPiBsZW5ndGgpIHRocm93IG5ldyBFcnJvcign5paH5a2X5YiX6LaF6YGOJylcclxuICAgICAgICBjb25zdCBleGFtID0gKHByZXYgIT09ICcnID8gcHJldiArIHNlcCA6ICcnKSArIGN1cnJlbnRcclxuICAgICAgICBpZiAoVGV4dFV0aWwubGVuYihleGFtKSA+IGxlbmd0aCkge1xyXG4gICAgICAgICAgYXJyUmVzLnB1c2gocHJldilcclxuICAgICAgICAgIGxhc3QgPSBjdXJyZW50IC8vIOacgOW+jOOBruaWh+Wtl+WIl1xyXG4gICAgICAgICAgcmV0dXJuICcnXHJcbiAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgIGxhc3QgPSBleGFtIC8vIOacgOW+jOOBruaWh+Wtl+WIl1xyXG4gICAgICAgICAgcmV0dXJuIGV4YW1cclxuICAgICAgICB9XHJcbiAgICAgIH0sICcnKVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAvLyBsZW5ndGgg44KS6LaF44GI44KL44OQ44Kk44OI6ZW344Gu5YiG5Ymy5paH5a2X5YiX44GM44GC44KL5aC05ZCI44Gv5L2V44KC44GX44Gq44GEXHJcbiAgICAgIGlmIChlLm1lc3NhZ2UgPT09ICfmloflrZfliJfotoXpgY4nKSByZXR1cm5cclxuICAgIH1cclxuXHJcbiAgICBhcnJSZXMucHVzaChsYXN0KSAvLyDmnIDlvozjga7mloflrZfliJfjgpLphY3liJfnmbvpjLLjgZnjgotcclxuICAgIC8vIGtleVMg44Gn5oyH5a6a44GV44KM44GfIHRhcmdldCDlhoXjga7opoHntKDjga7lgKTjgpLkv67mraPjgZnjgotcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwga2V5Uy5sZW5ndGg7IGkrKykge1xyXG4gICAgICB0YXJnZXRba2V5U1tpXV0gPSBhcnJSZXNbaV0gPyBhcnJSZXNbaV0gOiAnJ1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2xvZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2FkcycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5cclxuZXhwb3J0IGNvbnN0IFJvYm90aW5TaG9wID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3JvYm90aW5TaG9wJywge2lkR2VuZXJhdGlvbjogJ01PTkdPJ30pXHJcbmV4cG9ydCBjb25zdCBSb2JvdGluT3JkZXJzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3JvYm90aW5PcmRlcnMnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuXHJcbmV4cG9ydCBjb25zdCBDb25maWdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NvbmZpZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuICBNZXRlb3IucHVibGlzaCgnY29uZmlncycsICgpID0+IHtcclxuICAgIHJldHVybiBDb25maWdzLmZpbmQoKVxyXG4gIH0pO1xyXG4gIE1ldGVvci5tZXRob2RzKHtcclxuICAgIGFzeW5jIFsncm9ib3Rpbk9yZGVyR3JvdXBzJ10oKSB7XHJcbiAgICAgIGNvbnN0IHJlcyA9IGF3YWl0IFJvYm90aW5PcmRlcnMucmF3Q29sbGVjdGlvbigpLmFnZ3JlZ2F0ZShbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgLy8g5Y+X5rOoSUTjgZTjgajjgavjgrDjg6vjg7zjg5fljJZcclxuICAgICAgICAgICRncm91cDoge1xyXG4gICAgICAgICAgICBfaWQ6IHtcclxuICAgICAgICAgICAgICDlj5fms6hJRDonJHJvYm90aW4u5Y+X5rOoSUQnLFxyXG4gICAgICAgICAgICAgIOWPl+azqOaXpeaZgjonJHJvYm90aW4u5Y+X5rOo5pel5pmCJyxcclxuICAgICAgICAgICAgICDlupfoiJflkI06ICckcm9ib3Rpbi7lupfoiJflkI0nLFxyXG4gICAgICAgICAgICAgIOWPl+azqOeVquWPtzogJyRyb2JvdGluLuWPl+azqOeVquWPtydcclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgaXRlbXM6IHskcHVzaDoge+WVhuWTgeOCs+ODvOODiTogJyRyb2JvdGluLuWVhuWTgeOCs+ODvOODiScsIOaVsOmHjzogJyRyb2JvdGluLuaVsOmHjyd9fVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgJHByb2plY3Q6IHtcclxuICAgICAgICAgICAgX2lkOjAsXHJcbiAgICAgICAgICAgIOWPl+azqElEOickX2lkLuWPl+azqElEJyxcclxuICAgICAgICAgICAg5Y+X5rOo5pel5pmCOickX2lkLuWPl+azqOaXpeaZgicsXHJcbiAgICAgICAgICAgIOW6l+iIl+WQjTogJyRfaWQu5bqX6IiX5ZCNJyxcclxuICAgICAgICAgICAg5Y+X5rOo55Wq5Y+3OiAnJF9pZC7lj5fms6jnlarlj7cnLFxyXG4gICAgICAgICAgICBpdGVtczogJyRpdGVtcydcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIF0pLnRvQXJyYXkoKTtcclxuICAgICAgcmV0dXJuIHJlcztcclxuICAgIH1cclxuICB9KTtcclxuXHJcbiAgTWV0ZW9yLnB1Ymxpc2goJ3JvYm90aW5PcmRlckl0ZW1zJywgYXN5bmMgKCk9PntcclxuICAgIHJldHVybiBSb2JvdGluT3JkZXJzLmZpbmQoKTtcclxuICB9KTtcclxufVxyXG5cclxuaWYgKE1ldGVvci5pc0NsaWVudCkge1xyXG4gIE1ldGVvci5zdWJzY3JpYmUoJ2NvbmZpZ3MnKVxyXG59XHJcbiJdfQ==
