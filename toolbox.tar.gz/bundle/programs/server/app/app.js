var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/route/upload/image.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube/cubemig.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 2);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 3);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 4);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let coupon_cd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let coupon_name = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discount_price = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: coupon_cd,
                coupon_type: 3,
                // 全商品
                coupon_name: coupon_name,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discount_price,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/collection.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      return Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      return Promise.await(coll.aggregate(query).toArray());
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let ItemController;
module.watch(require("../../imports/core/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param  
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/core/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/core/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
      })));
      return report.publish();
    });
  },

  //
  // 商品情報更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/tooltest.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/configs.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/filters.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/groups.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/uploads.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"core":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/core/cube3api.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 1);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  updateStock(product_class_id, quantity = 0) {
    return Promise.asyncApply(() => {
      this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${product_class_id}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      });
      this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${product_class_id}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      });
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creator_id = data.creator_id;
      let res = [];

      let tagon = tag => Promise.asyncApply(() => {
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creator_id
        })));
      });

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let product_id = data.product_id;
      let images = data.images;
      let creator_id = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${product_id}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        this.mysql_.queryInsert('dtb_product_image', {
          product_id: product_id,
          creator_id: creator_id,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        });
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let update_data = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, update_data, {
        update_date: 'NOW()'
      }); // dtb_product_class

      update_data = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      let res = this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, update_data, {
        update_date: 'NOW()'
      });
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creator_id = data.creator_id;
      let res = {};
      let update_data = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', update_data, {
        creator_id: creator_id,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      update_data = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', update_data, {
        creator_id: creator_id,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creator_id,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/core/dbfilter.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 2);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 3);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 4);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case "mysql":
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  // DB からデータを取得するプロセス
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    let instance;

    switch (plug.type) {
      case "mysql":
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error("invalid plug type");
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   * 
   * 
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters 
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== "undefined") {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      return Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find();

      while (Promise.await(cur.hasNext())) {
        let doc = Promise.await(cur.next());
        Promise.await(onResult(doc, context));
      }

      ;
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/core/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(item_id) {
    return Promise.asyncApply(() => {
      let project = Promise.await(this.Items.findOne({
        _id: item_id
      }, {
        projection: {
          'product': 1
        }
      }));
      let product_pack = project.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[[]]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let product_sku of product_pack) {
        let quantity_sku = 0;

        for (let product_id of product_sku) {
          let project = Promise.await(this.Products.findOne({
            _id: product_id
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stock_array = project.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stock_array) {
            quantity_sku += stock.quantity;
          }
        }

        quantities.push(quantity_sku);
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   * 
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   * 
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   * 
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   * 
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   * 
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   * 
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   * 
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }

  getVariation(item, project) {
    return Promise.asyncApply(() => {
      // ループ用の設定
      let set = [{
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }]).toArray()),
          props: s
        });
      }

      return attrs;
    });
  }

  convertItemCube3(creator_id, item) {
    return Promise.asyncApply(() => {
      // product_id
      let product_id = null; // 下記の形式を作る
      // メーカーコード/属性1（カラーなど）/属性2（サイズなど）

      let modelClass = [];
      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let product_type_id;

      switch (item.delivery) {
        case '宅配便':
          product_type_id = 1;
          break;

        case 'ゆうパケット':
          product_type_id = 2;
          break;

        default:
          product_type_id = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let delivery_fee = null;

      switch (item.delivery) {
        case '宅配便':
          delivery_fee = null;
          break;

        case 'ゆうパケット':
          delivery_fee = 240;
          break;
      } // 商品情報詳細に、商品バリエーションのリンクをつける


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      }));
      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row"><p>&#8226; ${attr.props.label}</p></div>` + '<div class="row">' + attr.variations.map(variation => `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-block btn-xs">${variation.value}</button></a>`).join('') + '</div>' + '</div>').join(''); // 商品データを作る

      let data = {
        product_id: product_id,
        creator_id: creator_id,
        name: `${modelClass.join('/')} ${item.name} ${item.jan_code}`,
        description_detail: variationHtml + item.description,
        product_code: item.model,
        price01: item.retail_price,
        price02: item.sales_price,
        images: item.images,
        product_type_id: product_type_id,
        tags: tags,
        delivery_fee: delivery_fee
      };
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/error.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mongo.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mysql.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   * 
   * @param {String} sql 
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   * 
   * @param {String} table 
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} data_sql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, data_sql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(data_sql)) {
        map.set(k, data_sql[k] === null ? 'NULL' : data_sql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   * 
   * @param {String} table 
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} data_sql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, data_sql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(data_sql)) {
        updates.push(`${k}=${data_sql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/report.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  setupIterator() {
    this.iterator = new Iterator();
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.setupIterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    // 直前のエラーを取得
    let lastError = null;
    let index = this.trace.error.records.length;

    if (index) {
      lastError = this.trace.error.records[index - 1];
    } // 直前と同じエラーは省く


    if (JSON.stringify(lastError) !== JSON.stringify(newRecord)) if (newRecord && newRecord !== {} && newRecord !== '') {
      this.trace.error.records.push(newRecord);
    }
    this.trace.error.total++;
    this.total++;
  }

  errorOcurred() {
    return this.trace.error.total;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90b29sdGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL21haW4uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9jb25maWdzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3Vwcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL3VwbG9hZHMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29yZS9jdWJlM2FwaS5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb3JlL2RiZmlsdGVyLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvcmUvaXRlbXMuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9lcnJvci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL21vbmdvLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbXlzcWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9yZXBvcnQuanMiXSwibmFtZXMiOlsiZnMiLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJkZWZhdWx0IiwidiIsInVuaXFpZCIsIm11bHRpcGFydHkiLCJVcGxvYWRzIiwibXVsdGlwYXJ0eU1pZGRsZXdhcmUiLCJyb3V0ZSIsIldlYkFwcCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsInJlcSIsInJlc3AiLCJyZWFkZXIiLCJNZXRlb3IiLCJ3cmFwQXN5bmMiLCJyZWFkRmlsZSIsIndyaXRlciIsIndyaXRlRmlsZSIsInVwbG9hZElkIiwiZmlsZSIsImZpbGVzIiwiZGF0YSIsInBhdGgiLCJmaWxlbmFtZSIsInNhdmVQYXRoIiwiYm9keSIsImltYWdlZGlyIiwiZG9jIiwiY2xpZW50RmlsZU5hbWUiLCJuYW1lIiwidXBsb2FkZWRGaWxlTmFtZSIsImVyciIsImVycm9yIiwiaW5zZXJ0Iiwid3JpdGVIZWFkIiwiZW5kIiwiSlNPTiIsInN0cmluZ2lmeSIsInNhdmVEaXIiLCJjcnlwdG8iLCJNeVNRTCIsIlJlcG9ydCIsIkdyb3VwIiwiR3JvdXBGYWN0b3J5IiwiRmlsdGVyIiwidGFnIiwibWV0aG9kcyIsImNvbmZpZyIsInJlcG9ydCIsImZpbHRlciIsInNyY0ZpbHRlcklkIiwidGVzdFF1ZXJ5IiwiZHN0RGIiLCJkc3QiLCJjcmVkIiwicGhhc2UiLCJxdWVyeSIsImZvcmVhY2giLCJtb2JpbGVOdWxsIiwicmVjb3JkIiwic3FsIiwiY3VzdG9tZXJfaWQiLCJzdGF0dXMiLCJzZXgiLCJqb2IiLCJjb3VudHJ5X2lkIiwicHJlZiIsIm5hbWUwMSIsIm5hbWUwMiIsImthbmEwMSIsImthbmEwMiIsImNvbXBhbnlfbmFtZSIsInppcDAxIiwiemlwMDIiLCJ6aXBjb2RlIiwiYWRkcjAxIiwiYWRkcjAyIiwiZW1haWwiLCJ0ZWwwMSIsInRlbDAyIiwidGVsMDMiLCJmYXgwMSIsImZheDAyIiwiZmF4MDMiLCJiaXJ0aCIsInBhc3N3b3JkIiwic2FsdCIsInNlY3JldF9rZXkiLCJmaXJzdF9idXlfZGF0ZSIsImxhc3RfYnV5X2RhdGUiLCJidXlfdGltZXMiLCJidXlfdG90YWwiLCJub3RlIiwiY3JlYXRlX2RhdGUiLCJ1cGRhdGVfZGF0ZSIsImRlbF9mbGciLCJxdWVyeUluc2VydCIsImUiLCJpRXJyb3IiLCJjdXN0b21lcl9hZGRyZXNzX2lkIiwiaWQiLCJtYWlsbWFnYV9mbGciLCJjb3Vwb25fY2QiLCJyYW5kb21CeXRlcyIsInRvU3RyaW5nIiwic3Vic3RyaW5nIiwiY291cG9uX25hbWUiLCJkaXNjb3VudF9wcmljZSIsInBvaW50IiwicmVzIiwiY291cG9uX2lkIiwiY291cG9uX3R5cGUiLCJkaXNjb3VudF90eXBlIiwiY291cG9uX3VzZV90aW1lIiwiY291cG9uX3JlbGVhc2UiLCJkaXNjb3VudF9yYXRlIiwiZW5hYmxlX2ZsYWciLCJjb3Vwb25fbWVtYmVyIiwiY291cG9uX2xvd2VyX2xpbWl0IiwiYXZhaWxhYmxlX2Zyb21fZGF0ZSIsImF2YWlsYWJsZV90b19kYXRlIiwicHVibGlzaCIsInByb2ZpbGUiLCJkYiIsIk1vbmdvQ29sbGVjdGlvbiIsInBsdWciLCJwcm9qZWN0aW9uIiwiY29sbCIsImdldCIsImNvbGxlY3Rpb24iLCJmaW5kIiwidG9BcnJheSIsImFnZ3JlZ2F0ZSIsIkl0ZW1Db250cm9sbGVyIiwibW9kZWwiLCJjbGFzczEiLCJjbGFzczIiLCJpdGVtY29uIiwiaW5pdCIsInVwbG9hZGVkIiwic2V0SW1hZ2UiLCJjbGVhbkltYWdlIiwiTW9uZ29EQkZpbHRlciIsIkN1YmUzQXBpIiwiaXRlbXNEQiIsIml0ZW1Db250cm9sbGVyIiwidGFyZ2V0REIiLCJjdWJlM0RCIiwiYXBpIiwiaXRlbSIsImNvbnRleHQiLCJxdWFudGl0eSIsImdldFN0b2NrIiwiX2lkIiwidXBkYXRlU3RvY2siLCJtYWxsIiwic2hhcmFrdVNob3AiLCJwcm9kdWN0X2NsYXNzX2lkIiwiY29sIiwiY3ViZUl0ZW0iLCJjb252ZXJ0SXRlbUN1YmUzIiwiY3JlYXRvcl9pZCIsImluc2VydFJlcyIsInByb2R1Y3RDcmVhdGUiLCJ1cGRhdGUiLCIkc2V0IiwiaVN1Y2Nlc3MiLCJwcm9kdWN0SW1hZ2VVcGRhdGUiLCJwcm9kdWN0VXBkYXRlIiwicHJvZHVjdFRhZ1VwZGF0ZSIsImV4cG9ydCIsIkNvbmZpZ3MiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJpZEdlbmVyYXRpb24iLCJzaWZ0IiwibW9iamVjdCIsIkdyb3VwQmFzZSIsIkZpbHRlcnMiLCJjb25zdHJ1Y3RvciIsImZpbHRlcklkIiwiZmluZE9uZSIsImdldFBsdWciLCJ0eXBlIiwibXlzcWwiLCJpbXBvcnQiLCJvblJlc3VsdCIsIm9uRXJyb3IiLCJ0YWJsZSIsInN0cmVhbWluZ1F1ZXJ5IiwiRXJyb3IiLCJjYWxsYmFja3MiLCJnZXRQcm9maWxlIiwiZmlsdGVycyIsInB1c2giLCJjb3VudCIsInVuZXNjYXBlIiwiZXhhbSIsIkdyb3VwcyIsInBsYXRmb3JtUGx1ZyIsImNhbGxiYWNrIiwiZ3JvdXBJZCIsImtleSIsImN1ciIsImZpZWxkcyIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiZm9yRWFjaCIsImluZGV4IiwiY2F0Y2giLCJNb25nb0NsaWVudCIsIm15c3FsXyIsInF1ZXJ5VXBkYXRlIiwic3RvY2siLCJzdG9ja191bmxpbWl0ZWQiLCJ0YWdvbiIsInByb2R1Y3RfaWQiLCJ0YWdvZmYiLCJ0YWdTZXQiLCJ0YWdzIiwic2V0IiwiaW1hZ2VzIiwiaSIsImxlbmd0aCIsImZpbGVfbmFtZSIsInJhbmsiLCJ1cGRhdGVfZGF0YSIsImtleXMiLCJrIiwiZGVzY3JpcHRpb25fbGlzdCIsInNlYXJjaF93b3JkIiwiZnJlZV9hcmVhIiwiY2xhc3NfY2F0ZWdvcnlfaWQxIiwiY2xhc3NfY2F0ZWdvcnlfaWQyIiwiZGVsaXZlcnlfZGF0ZV9pZCIsInNhbGVfbGltaXQiLCJwcm9kdWN0X3N0b2NrX2lkIiwiREJGaWx0ZXJGYWN0b3J5IiwiREJGaWx0ZXIiLCJNeXNxbERCRmlsdGVyIiwiaW5zdGFuY2UiLCJmYWN0b3J5IiwiZ2V0UGx1Z18iLCJnZXRDcmVkXyIsImdldFByb2ZpbGVfIiwic2V0SW1wb3J0RnVuY3Rpb25fIiwiZm4iLCJpdGVyYXRvcnMiLCJjb3VudGVyIiwiZiIsImxpbWl0IiwiYyIsImNsaWVudCIsImNvbm5lY3QiLCJ1cmkiLCJkYXRhYmFzZSIsImhhc05leHQiLCJuZXh0IiwiSXRlbXMiLCJQcm9kdWN0cyIsIml0ZW1faWQiLCJwcm9qZWN0IiwicHJvZHVjdF9wYWNrIiwicHJvZHVjdCIsInF1YW50aXRpZXMiLCJwcm9kdWN0X3NrdSIsInF1YW50aXR5X3NrdSIsInN0b2NrX2FycmF5IiwiTWF0aCIsIm1pbiIsImFwcGx5IiwiZmV0Y2giLCJtYXAiLCJjbGFzczFfdmFsdWUiLCJjbGFzczJfdmFsdWUiLCJ1cGRhdGVNYW55IiwiJHB1c2giLCIkZWFjaCIsImdldFZhcmlhdGlvbiIsImxhYmVsIiwiY2xhc3MxX25hbWUiLCJjdXJyZW50IiwidmFsdWUiLCJjbGFzczJfbmFtZSIsImF0dHJzIiwicyIsInZhcmlhdGlvbnMiLCIkbWF0Y2giLCJPYmplY3QiLCJhc3NpZ24iLCIkcHJvamVjdCIsInByb3BzIiwibW9kZWxDbGFzcyIsInByb2R1Y3RfdHlwZV9pZCIsImRlbGl2ZXJ5IiwiZGVsaXZlcnlfZmVlIiwidmFyaWF0aW9uSHRtbCIsImF0dHIiLCJ2YXJpYXRpb24iLCJqb2luIiwiamFuX2NvZGUiLCJkZXNjcmlwdGlvbl9kZXRhaWwiLCJkZXNjcmlwdGlvbiIsInByb2R1Y3RfY29kZSIsInByaWNlMDEiLCJyZXRhaWxfcHJpY2UiLCJwcmljZTAyIiwic2FsZXNfcHJpY2UiLCJ1dGlsRXJyb3IiLCJwYXJzZSIsIm1lc3NhZ2UiLCJmaWxlTmFtZSIsImxpbmVOdW1iZXIiLCJjb2x1bW5OdW1iZXIiLCJzdGFjayIsIm1vbWVudCIsInBvb2wiLCJjcmVhdGVQb29sIiwicHJvZmlsZU11bHRpIiwibXVsdGlwbGVTdGF0ZW1lbnRzIiwicG9vbE11bHRpIiwiZm9ybWF0RGF0ZSIsImRhdGUiLCJmb3JtYXQiLCJyZXBsYWNlIiwiZ2V0Q29uIiwidGhlbiIsImNvbiIsInJlbGVhc2UiLCJxdWVyeUluc2VydF8iLCJpbnNlcnRJZCIsImRhdGFfc3FsIiwiTWFwIiwiZXNjYXBlIiwidmFsdWVzIiwidXBkYXRlcyIsInF1ZXJ5TXVsdGkiLCJwb29sU3dhcCIsInN0YXJ0VHJhbnNhY3Rpb24iLCJjb21taXQiLCJyb2xsYmFjayIsIm9uIiwicGF1c2UiLCJyZXN1bWUiLCJnZXRDb25uZWN0aW9uIiwiaXRlcmF0b3IiLCJzZXR1cEl0ZXJhdG9yIiwiSXRlcmF0b3IiLCJyZWMiLCJyZXN1bHQiLCJ0b3RhbCIsIm5ld1JlY29yZCIsInN1Y2Nlc3MiLCJlcnJvck9jdXJyZWQiLCJpdGVFcnJvciIsInBoYUVycm9yIiwidHJhY2UiLCJyZWNvcmRzIiwibGFzdEVycm9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLEVBQUo7QUFBT0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0wsU0FBR0ssQ0FBSDtBQUFLOztBQUFqQixDQUEzQixFQUE4QyxDQUE5QztBQUFpRCxJQUFJQyxNQUFKO0FBQVdMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUUsVUFBSjtBQUFlTixPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYixFQUEyQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0UsaUJBQVdGLENBQVg7QUFBYTs7QUFBekIsQ0FBM0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSUcsT0FBSjtBQUFZUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUNBQVIsQ0FBYixFQUE0RDtBQUFDSyxVQUFRSCxDQUFSLEVBQVU7QUFBQ0csY0FBUUgsQ0FBUjtBQUFVOztBQUF0QixDQUE1RCxFQUFvRixDQUFwRjtBQWFoTyxJQUFJSSx1QkFBdUJGLFlBQTNCO0FBRUEsTUFBTUcsUUFBUSxlQUFkLEMsQ0FFQTs7QUFDQUMsT0FBT0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJILEtBQTNCLEVBQWtDRCxvQkFBbEM7QUFDQUUsT0FBT0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJILEtBQTNCLEVBQWtDLENBQUNJLEdBQUQsRUFBTUMsSUFBTixLQUFlO0FBQy9DO0FBRUEsUUFBTUMsU0FBU0MsT0FBT0MsU0FBUCxDQUFpQmxCLEdBQUdtQixRQUFwQixDQUFmO0FBQ0EsUUFBTUMsU0FBU0gsT0FBT0MsU0FBUCxDQUFpQmxCLEdBQUdxQixTQUFwQixDQUFmO0FBQ0EsUUFBTUMsV0FBV2hCLFFBQWpCOztBQUVBLE9BQUssSUFBSWlCLElBQVQsSUFBaUJULElBQUlVLEtBQUosQ0FBVUQsSUFBM0IsRUFBaUM7QUFDL0IsVUFBTUUsT0FBT1QsT0FBT08sS0FBS0csSUFBWixDQUFiLENBRCtCLENBRS9CO0FBQ0E7O0FBQ0EsUUFBSUMsV0FBWSxHQUFFckIsUUFBUyxNQUEzQixDQUorQixDQU0vQjs7QUFDQSxRQUFJc0IsV0FBV2QsSUFBSWUsSUFBSixDQUFTQyxRQUFULEdBQW9CLEdBQXBCLEdBQTBCSCxRQUF6QyxDQVArQixDQVMvQjtBQUVBOztBQUNBLFFBQUlJLE1BQU07QUFDUlQsZ0JBQVVBLFFBREY7QUFFUlUsc0JBQWdCVCxLQUFLVSxJQUZiO0FBR1JDLHdCQUFrQlA7QUFIVixLQUFWOztBQU1BLFFBQUc7QUFDRFAsYUFBT1EsUUFBUCxFQUFpQkgsSUFBakI7QUFDRCxLQUZELENBR0EsT0FBTVUsR0FBTixFQUFVO0FBQ1JKLFVBQUlLLEtBQUosR0FBWUQsR0FBWjtBQUNEOztBQUNEM0IsWUFBUTZCLE1BQVIsQ0FBZU4sR0FBZjtBQUVBLFdBQU9SLElBQVA7QUFFRDs7QUFBQTtBQUNEUixPQUFLdUIsU0FBTCxDQUFlLEdBQWY7QUFDQXZCLE9BQUt3QixHQUFMLENBQVNDLEtBQUtDLFNBQUwsQ0FBZTtBQUN0Qm5CLGNBQVVBLFFBRFk7QUFFdEJvQixhQUFTNUIsSUFBSWUsSUFBSixDQUFTQztBQUZJLEdBQWYsQ0FBVDtBQUtELENBMUNELEU7Ozs7Ozs7Ozs7O0FDbkJBLElBQUlhLE1BQUo7QUFBVzFDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzQyxhQUFPdEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJd0MsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUFsRCxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJeUMsS0FBSixFQUFVQyxZQUFWO0FBQXVCOUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlDQUFSLENBQWIsRUFBd0Q7QUFBQzJDLFFBQU16QyxDQUFOLEVBQVE7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CMEMsZUFBYTFDLENBQWIsRUFBZTtBQUFDMEMsbUJBQWExQyxDQUFiO0FBQWU7O0FBQWxELENBQXhELEVBQTRHLENBQTVHO0FBQStHLElBQUkyQyxNQUFKO0FBQVcvQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0NBQVIsQ0FBYixFQUF5RDtBQUFDNkMsU0FBTzNDLENBQVAsRUFBUztBQUFDMkMsYUFBTzNDLENBQVA7QUFBUzs7QUFBcEIsQ0FBekQsRUFBK0UsQ0FBL0U7QUFZaFksSUFBSTRDLE1BQU0sU0FBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxVQUFkLEVBQXlCRSxNQUF6QjtBQUFBLG9DQUFpQztBQUUvQixVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYixDQUYrQixDQUkvQjtBQUNBOztBQUVBLFVBQUlRLFNBQVMsSUFBSUwsTUFBSixDQUFXRyxPQUFPRyxXQUFsQixDQUFiLENBUCtCLENBUS9CO0FBRUE7QUFDQTs7QUFFQSxVQUFJQyxZQUFZLGdCQUFoQjtBQUVBLFVBQUlDLFFBQVEsSUFBSVosS0FBSixDQUFVTyxPQUFPTSxHQUFQLENBQVdDLElBQXJCLENBQVo7QUFFQSxvQkFBTU4sT0FBT08sS0FBUCxDQUFhLHdCQUFiLEVBQ0osK0JBQVk7QUFDVixzQkFBTUgsTUFBTUksS0FBTixDQUFZTCxTQUFaLENBQU47QUFDRCxPQUZELENBREksQ0FBTixFQWpCK0IsQ0F1Qi9CO0FBQ0E7O0FBRUEsb0JBQU1ILE9BQU9PLEtBQVAsQ0FBYSx1QkFBYixFQUNKLCtCQUFZO0FBQ1YsNkJBQWFOLE9BQU9RLE9BQVAsQ0FBZTtBQUN4QkMsc0JBQW1CQyxNQUFQLDZCQUFrQjtBQUU1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLGdCQUFJQyxNQUFPOzs7OzswQkFLRUQsT0FBT0UsV0FBYSxNQUFNRixPQUFPRyxNQUFRLE1BQU1ILE9BQU9JLEdBQUssTUFBTUosT0FBT0ssR0FBSyxNQUFNTCxPQUFPTSxVQUFZLE1BQU1OLE9BQU9PLElBQU0sTUFBTVAsT0FBT1EsTUFBUSxNQUFNUixPQUFPUyxNQUFRLE1BQU1ULE9BQU9VLE1BQVEsTUFBTVYsT0FBT1csTUFBUSxNQUFNWCxPQUFPWSxZQUFjLE1BQU1aLE9BQU9hLEtBQU8sTUFBTWIsT0FBT2MsS0FBTyxNQUFNZCxPQUFPZSxPQUFTLE1BQU1mLE9BQU9nQixNQUFRLE1BQU1oQixPQUFPaUIsTUFBUSxNQUFNakIsT0FBT2tCLEtBQU8sTUFBTWxCLE9BQU9tQixLQUFPLE1BQU1uQixPQUFPb0IsS0FBTyxNQUFNcEIsT0FBT3FCLEtBQU8sTUFBTXJCLE9BQU9zQixLQUFPLE1BQU10QixPQUFPdUIsS0FBTyxNQUFNdkIsT0FBT3dCLEtBQU8sTUFBTXhCLE9BQU95QixLQUFPLE1BQU16QixPQUFPMEIsUUFBVSxNQUFNMUIsT0FBTzJCLElBQU0sTUFBTTNCLE9BQU80QixVQUFZLE1BQU01QixPQUFPNkIsY0FBZ0IsTUFBTTdCLE9BQU84QixhQUFlLE1BQU05QixPQUFPK0IsU0FBVyxNQUFNL0IsT0FBT2dDLFNBQVcsTUFBTWhDLE9BQU9pQyxJQUFNLE1BQU1qQyxPQUFPa0MsV0FBYSxNQUFNbEMsT0FBT21DLFdBQWEsTUFBTW5DLE9BQU9vQyxPQUFTOztpQkFMdHdCOztBQVNBLGdCQUFJO0FBQ0YsNEJBQU0zQyxNQUFNNEMsV0FBTixDQUNKLGNBREksRUFFSjtBQUNFbkMsNkJBQWFGLE9BQU9FLFdBRHRCO0FBRUVDLHdCQUFRSCxPQUFPRyxNQUZqQjtBQUdFQyxxQkFBS0osT0FBT0ksR0FIZDtBQUlFQyxxQkFBS0wsT0FBT0ssR0FKZDtBQUtFQyw0QkFBWU4sT0FBT00sVUFMckI7QUFNRUMsc0JBQU1QLE9BQU9PLElBTmY7QUFPRUMsd0JBQVFSLE9BQU9RLE1BUGpCO0FBUUVDLHdCQUFRVCxPQUFPUyxNQVJqQjtBQVNFQyx3QkFBUVYsT0FBT1UsTUFUakI7QUFVRUMsd0JBQVFYLE9BQU9XLE1BVmpCO0FBV0VDLDhCQUFjWixPQUFPWSxZQVh2QjtBQVlFQyx1QkFBT2IsT0FBT2EsS0FaaEI7QUFhRUMsdUJBQU9kLE9BQU9jLEtBYmhCO0FBY0VDLHlCQUFTZixPQUFPZSxPQWRsQjtBQWVFQyx3QkFBUWhCLE9BQU9nQixNQWZqQjtBQWdCRUMsd0JBQVFqQixPQUFPaUIsTUFoQmpCO0FBaUJFQyx1QkFBT2xCLE9BQU9rQixLQWpCaEI7QUFrQkVDLHVCQUFPbkIsT0FBT21CLEtBbEJoQjtBQW1CRUMsdUJBQU9wQixPQUFPb0IsS0FuQmhCO0FBb0JFQyx1QkFBT3JCLE9BQU9xQixLQXBCaEI7QUFxQkVDLHVCQUFPdEIsT0FBT3NCLEtBckJoQjtBQXNCRUMsdUJBQU92QixPQUFPdUIsS0F0QmhCO0FBdUJFQyx1QkFBT3hCLE9BQU93QixLQXZCaEI7QUF3QkVDLHVCQUFPekIsT0FBT3lCLEtBeEJoQjtBQXlCRUMsMEJBQVUxQixPQUFPMEIsUUF6Qm5CO0FBMEJFQyxzQkFBTTNCLE9BQU8yQixJQTFCZjtBQTJCRUMsNEJBQVk1QixPQUFPNEIsVUEzQnJCO0FBNEJFQyxnQ0FBZ0I3QixPQUFPNkIsY0E1QnpCO0FBNkJFQywrQkFBZTlCLE9BQU84QixhQTdCeEI7QUE4QkVDLDJCQUFXL0IsT0FBTytCLFNBOUJwQjtBQStCRUMsMkJBQVdoQyxPQUFPZ0MsU0EvQnBCO0FBZ0NFQyxzQkFBTWpDLE9BQU9pQyxJQWhDZjtBQWlDRUMsNkJBQWFsQyxPQUFPa0MsV0FqQ3RCO0FBa0NFQyw2QkFBYW5DLE9BQU9tQyxXQWxDdEI7QUFtQ0VDLHlCQUFTcEMsT0FBT29DO0FBbkNsQixlQUZJLENBQU47QUF3Q0QsYUF6Q0QsQ0F5Q0UsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZqRCxxQkFBT2tELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBbEUyQixDQW9FNUI7OztBQUNBLGdCQUFJO0FBQ0YsNEJBQU03QyxNQUFNNEMsV0FBTixDQUNKLHNCQURJLEVBQ29CO0FBQ3RCRyxxQ0FBcUIsSUFEQztBQUV0QnRDLDZCQUFhRixPQUFPRSxXQUZFO0FBR3RCSSw0QkFBWU4sT0FBT00sVUFIRztBQUl0QkMsc0JBQU1QLE9BQU9PLElBSlM7QUFLdEJDLHdCQUFRUixPQUFPUSxNQUxPO0FBTXRCQyx3QkFBUVQsT0FBT1MsTUFOTztBQU90QkMsd0JBQVFWLE9BQU9VLE1BUE87QUFRdEJDLHdCQUFRWCxPQUFPVyxNQVJPO0FBU3RCQyw4QkFBY1osT0FBT1ksWUFUQztBQVV0QkMsdUJBQU9iLE9BQU9hLEtBVlE7QUFXdEJDLHVCQUFPZCxPQUFPYyxLQVhRO0FBWXRCQyx5QkFBU2YsT0FBT2UsT0FaTTtBQWF0QkMsd0JBQVFoQixPQUFPZ0IsTUFiTztBQWN0QkMsd0JBQVFqQixPQUFPaUIsTUFkTztBQWV0QkUsdUJBQU9uQixPQUFPbUIsS0FmUTtBQWdCdEJDLHVCQUFPcEIsT0FBT29CLEtBaEJRO0FBaUJ0QkMsdUJBQU9yQixPQUFPcUIsS0FqQlE7QUFrQnRCQyx1QkFBT3RCLE9BQU9zQixLQWxCUTtBQW1CdEJDLHVCQUFPdkIsT0FBT3VCLEtBbkJRO0FBb0J0QkMsdUJBQU94QixPQUFPd0IsS0FwQlE7QUFxQnRCVSw2QkFBYWxDLE9BQU9rQyxXQXJCRTtBQXNCdEJDLDZCQUFhbkMsT0FBT21DLFdBdEJFO0FBdUJ0QkMseUJBQVNwQyxPQUFPb0M7QUF2Qk0sZUFEcEIsQ0FBTjtBQTJCRCxhQTVCRCxDQTRCRSxPQUFPRSxDQUFQLEVBQVU7QUFDVmpELHFCQUFPa0QsTUFBUCxDQUFjRCxDQUFkO0FBQ0QsYUFuRzJCLENBcUc1Qjs7O0FBQ0EsZ0JBQUk7QUFDRiw0QkFBTTdDLE1BQU00QyxXQUFOLENBQ0osdUJBREksRUFDcUI7QUFDdkJJLG9CQUFJLElBRG1CO0FBRXZCdkMsNkJBQWFGLE9BQU9FLFdBRkc7QUFHdkJ3Qyw4QkFBYzFDLE9BQU8wQyxZQUhFO0FBSXZCUiw2QkFBYWxDLE9BQU9rQyxXQUpHO0FBS3ZCQyw2QkFBYW5DLE9BQU9tQyxXQUxHO0FBTXZCQyx5QkFBU3BDLE9BQU9vQztBQU5PLGVBRHJCLENBQU47QUFVRCxhQVhELENBV0UsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZqRCxxQkFBT2tELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBbkgyQixDQXFINUI7OztBQUVBLGdCQUFJSyxZQUFZL0QsT0FBT2dFLFdBQVAsQ0FBbUIsQ0FBbkIsRUFBc0JDLFFBQXRCLENBQStCLFFBQS9CLEVBQXlDQyxTQUF6QyxDQUFtRCxDQUFuRCxFQUFxRCxFQUFyRCxDQUFoQjtBQUVBLGdCQUFJQyxjQUFlLEdBQUUvQyxPQUFPUSxNQUFPLElBQUdSLE9BQU9TLE1BQU8sbUJBQWtCVCxPQUFPRSxXQUFZLEVBQXpGO0FBRUEsZ0JBQUk4QyxpQkFBaUJoRCxPQUFPaUQsS0FBUCxHQUFlLEdBQXBDOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUlDLG9CQUFZekQsTUFBTTRDLFdBQU4sQ0FDZCxZQURjLEVBQ0E7QUFDWmMsMkJBQVcsSUFEQztBQUVaUiwyQkFBV0EsU0FGQztBQUdaUyw2QkFBYSxDQUhEO0FBR0k7QUFDaEJMLDZCQUFhQSxXQUpEO0FBS1pNLCtCQUFlLENBTEg7QUFNWkMsaUNBQWlCLENBTkw7QUFPWkMsZ0NBQWdCLENBUEo7QUFRWlAsZ0NBQWdCQSxjQVJKO0FBU1pRLCtCQUFlLElBVEg7QUFVWkMsNkJBQWEsQ0FWRDtBQVdaQywrQkFBZSxDQVhIO0FBWVpDLG9DQUFvQixJQVpSO0FBYVpDLHFDQUFxQixxQkFiVDtBQWNaQyxtQ0FBbUIscUJBZFA7QUFlWnpCLHlCQUFTO0FBZkcsZUFEQSxFQWlCWjtBQUNBRiw2QkFBYSxPQURiO0FBRUFDLDZCQUFhO0FBRmIsZUFqQlksQ0FBWixDQUFKO0FBc0JELGFBdkJELENBdUJFLE9BQU9HLENBQVAsRUFBVTtBQUNWakQscUJBQU9rRCxNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBdkpXO0FBRFksU0FBZixFQTBKSkEsQ0FBUCw2QkFBYTtBQUNYakQsaUJBQU9rRCxNQUFQLENBQWNELENBQWQ7QUFDRCxTQUZELENBMUpXLENBQWI7QUE4SkQsT0EvSkQsQ0FESSxDQUFOO0FBa0tBLGFBQU9qRCxPQUFPeUUsT0FBUCxFQUFQO0FBQ0QsS0E3TEQ7QUFBQSxHQUZhOztBQWlNUCx1QkFBTixDQUE2QkMsT0FBN0I7QUFBQSxvQ0FBc0M7QUFFcEMsVUFBSUMsS0FBSyxJQUFJbkYsS0FBSixDQUFVa0YsT0FBVixDQUFUO0FBQ0EsVUFBSWIsb0JBQVljLEdBQUduRSxLQUFILENBQVMsZ0JBQVQsQ0FBWixDQUFKO0FBQ0EsYUFBT3FELEdBQVA7QUFDRCxLQUxEO0FBQUE7O0FBak1hLENBQWYsRTs7Ozs7Ozs7Ozs7QUNkQSxJQUFJZSxlQUFKO0FBQW9CL0gsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQzZILGtCQUFnQjNILENBQWhCLEVBQWtCO0FBQUMySCxzQkFBZ0IzSCxDQUFoQjtBQUFrQjs7QUFBdEMsQ0FBakQsRUFBeUYsQ0FBekY7QUFFcEIsSUFBSTRDLE1BQU0sa0JBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYixHQUFRLEdBQUVELEdBQUksT0FBZCxFQUF1QmdGLElBQXZCLEVBQTZCckUsUUFBTSxFQUFuQyxFQUF1Q3NFLGFBQVcsRUFBbEQ7QUFBQSxvQ0FBdUQ7QUFFckQsVUFBSUMscUJBQWFILGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCQSxLQUFLSSxVQUEvQixDQUFiLENBQUo7QUFDQSwyQkFBYUYsS0FBS0csSUFBTCxDQUFVMUUsS0FBVixFQUFnQjtBQUFDc0Usb0JBQVdBO0FBQVosT0FBaEIsRUFBeUNLLE9BQXpDLEVBQWI7QUFFRCxLQUxEO0FBQUEsR0FGYTs7QUFTYixHQUFRLEdBQUV0RixHQUFJLFlBQWQsRUFBNEJnRixJQUE1QixFQUFrQ3JFLFFBQU0sRUFBeEM7QUFBQSxvQ0FBNkM7QUFFM0MsVUFBSXVFLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQkEsS0FBS0ksVUFBL0IsQ0FBYixDQUFKO0FBQ0EsMkJBQWFGLEtBQUtLLFNBQUwsQ0FBZTVFLEtBQWYsRUFBc0IyRSxPQUF0QixFQUFiO0FBRUQsS0FMRDtBQUFBOztBQVRhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNKQSxJQUFJRSxjQUFKO0FBQW1CeEksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNvSSxxQkFBZXBJLENBQWY7QUFBaUI7O0FBQTdCLENBQWpELEVBQWdGLENBQWhGO0FBRW5CLElBQUk0QyxNQUFNLGFBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjs7Ozs7QUFLQSxHQUFRLEdBQUVELEdBQUksV0FBZCxFQUEyQmdGLElBQTNCLEVBQWlDM0csUUFBakMsRUFBMkNvSCxLQUEzQyxFQUFrREMsU0FBUyxJQUEzRCxFQUFpRUMsU0FBUyxJQUExRTtBQUFBLG9DQUFpRjtBQUMvRSxVQUFJQyxVQUFVLElBQUlKLGNBQUosRUFBZDtBQUNBLG9CQUFNSSxRQUFRQyxJQUFSLENBQWFiLElBQWIsQ0FBTjtBQUNBLFVBQUljLHlCQUFpQkYsUUFBUUcsUUFBUixDQUFrQjFILFFBQWxCLEVBQTRCb0gsS0FBNUIsRUFBbUNDLE1BQW5DLEVBQTJDQyxNQUEzQyxDQUFqQixDQUFKO0FBQ0EsYUFBT0csUUFBUDtBQUNELEtBTEQ7QUFBQSxHQVBhOztBQWNiOzs7QUFHQSxHQUFRLEdBQUU5RixHQUFJLGFBQWQsRUFBNkJnRixJQUE3QixFQUFtQ1MsS0FBbkMsRUFBMENDLFNBQVMsSUFBbkQsRUFBeURDLFNBQVMsSUFBbEU7QUFBQSxvQ0FBeUU7QUFDdkUsVUFBSUMsVUFBVSxJQUFJSixjQUFKLEVBQWQ7QUFDQSxvQkFBTUksUUFBUUMsSUFBUixDQUFhYixJQUFiLENBQU47QUFDQSxvQkFBTVksUUFBUUksVUFBUixDQUFvQlAsS0FBcEIsRUFBMkJDLE1BQTNCLEVBQW1DQyxNQUFuQyxDQUFOO0FBQ0QsS0FKRDtBQUFBOztBQWpCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDSkEsSUFBSS9GLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSTZJLGFBQUo7QUFBa0JqSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDK0ksZ0JBQWM3SSxDQUFkLEVBQWdCO0FBQUM2SSxvQkFBYzdJLENBQWQ7QUFBZ0I7O0FBQWxDLENBQWpELEVBQXFGLENBQXJGO0FBQXdGLElBQUk4SSxRQUFKO0FBQWFsSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDZ0osV0FBUzlJLENBQVQsRUFBVztBQUFDOEksZUFBUzlJLENBQVQ7QUFBVzs7QUFBeEIsQ0FBakQsRUFBMkUsQ0FBM0U7QUFBOEUsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSW9JLGNBQUo7QUFBbUJ4SSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ29JLHFCQUFlcEksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBOUMsRUFBNkUsQ0FBN0U7QUFVN1gsSUFBSTRDLE1BQU0sTUFBVjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksY0FBZCxFQUE2QkUsTUFBN0I7QUFBQSxvQ0FBcUM7QUFFbkM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLFVBQUlRLFNBQVMsSUFBSTZGLGFBQUosQ0FBa0IvRixPQUFPaUcsT0FBekIsRUFBa0NqRyxPQUFPMkUsT0FBekMsQ0FBYjtBQUNBLFVBQUl1QixpQkFBaUIsSUFBSVosY0FBSixFQUFyQjtBQUNBLG9CQUFNWSxlQUFlUCxJQUFmLENBQW9CM0YsT0FBT2lHLE9BQTNCLENBQU47QUFFQSxVQUFJRSxXQUFXLElBQUkxRyxLQUFKLENBQVVPLE9BQU9vRyxPQUFqQixDQUFmO0FBQ0EsVUFBSUMsTUFBTSxJQUFJTCxRQUFKLENBQWFHLFFBQWIsQ0FBVjtBQUVBLG9CQUFNbEcsT0FBT08sS0FBUCxDQUNKLE9BREksRUFFSiwrQkFBWTtBQUNWLDZCQUFhTixPQUFPUSxPQUFQLENBQWU7QUFDMUIsb0JBQVUsQ0FBTzRGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFFakMsZ0JBQUlDLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF5QkgsS0FBS0ksR0FBOUIsQ0FBakIsQ0FBSjtBQUNBLDBCQUFNTCxJQUFJTSxXQUFKLENBQWlCTCxLQUFLTSxJQUFMLENBQVVDLFdBQVYsQ0FBc0JDLGdCQUF2QyxFQUF5RE4sUUFBekQsQ0FBTjtBQUNELFdBSlM7QUFEZ0IsU0FBZixDQUFiO0FBT0QsT0FSRCxDQUZJLENBQU47QUFZQSxhQUFPdkcsT0FBT3lFLE9BQVAsRUFBUDtBQUVELEtBMUJEO0FBQUEsR0FMYTs7QUFrQ2I7QUFDQTtBQUVBLEdBQVEsR0FBRTVFLEdBQUksWUFBZCxFQUEyQkUsTUFBM0I7QUFBQSxvQ0FBbUM7QUFFakMsVUFBSUUsU0FBUyxJQUFJNkYsYUFBSixDQUFrQi9GLE9BQU9pRyxPQUF6QixFQUFrQ2pHLE9BQU8yRSxPQUF6QyxDQUFiO0FBQ0EsVUFBSXdCLFdBQVcsSUFBSTFHLEtBQUosQ0FBVU8sT0FBT29HLE9BQWpCLENBQWY7QUFDQSxVQUFJQyxNQUFNLElBQUlMLFFBQUosQ0FBYUcsUUFBYixDQUFWO0FBRUEsVUFBSUQsaUJBQWlCLElBQUlaLGNBQUosRUFBckI7QUFDQSxvQkFBTVksZUFBZVAsSUFBZixDQUFxQjNGLE9BQU9pRyxPQUE1QixDQUFOLEVBUGlDLENBU2pDOztBQUNBLFVBQUloRyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osZUFESSxFQUVKLCtCQUFZO0FBQ1YsNkJBQWFOLE9BQU9RLE9BQVAsQ0FBZTtBQUN4QixvQkFBVSxDQUFPNEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUVqQyxnQkFBSVEsTUFBTVIsUUFBUXJCLFVBQWxCOztBQUVBLGdCQUFJO0FBRUYsa0JBQUk4Qix5QkFBaUJkLGVBQWVlLGdCQUFmLENBQWdDakgsT0FBT2tILFVBQXZDLEVBQW1EWixJQUFuRCxDQUFqQixDQUFKO0FBRUEsa0JBQUlhLDBCQUFrQmQsSUFBSWUsYUFBSixDQUFrQkosUUFBbEIsQ0FBbEIsQ0FBSixDQUpFLENBTUY7O0FBQ0EsNEJBQU1ELElBQUlNLE1BQUosQ0FBVztBQUNmWCxxQkFBS0osS0FBS0k7QUFESyxlQUFYLEVBRUg7QUFDRFksc0JBQU07QUFDSixzQ0FBb0JILFVBQVVyRDtBQUQxQjtBQURMLGVBRkcsQ0FBTjtBQVFBN0QscUJBQU9zSCxRQUFQO0FBRUQsYUFqQkQsQ0FpQkUsT0FBT3JFLENBQVAsRUFBVTtBQUVWakQscUJBQU9rRCxNQUFQLENBQWNELENBQWQ7QUFFRDtBQUNGLFdBMUJTO0FBRGMsU0FBZixFQTZCSkEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQTdCVyxDQUFiO0FBZ0NELE9BakNELENBRkksQ0FBTjtBQXFDQSxvQkFBTWpELE9BQU9PLEtBQVAsQ0FDSixnQkFESSxFQUVKLCtCQUFZO0FBQ1YsNkJBQWFOLE9BQU9RLE9BQVAsQ0FBZTtBQUN4QixvQkFBVSxDQUFPNEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUVqQyxnQkFBSVEsTUFBTVIsUUFBUXJCLFVBQWxCOztBQUVBLGdCQUFJO0FBRUYsa0JBQUk4Qix5QkFBaUJkLGVBQWVlLGdCQUFmLENBQWdDakgsT0FBT2tILFVBQXZDLEVBQW1EWixJQUFuRCxDQUFqQixDQUFKO0FBRUEsNEJBQU1ELElBQUltQixrQkFBSixDQUF1QlIsUUFBdkIsQ0FBTjtBQUNBLDRCQUFNWCxJQUFJb0IsYUFBSixDQUFrQlQsUUFBbEIsQ0FBTjtBQUNBLDRCQUFNWCxJQUFJcUIsZ0JBQUosQ0FBcUJWLFFBQXJCLENBQU47QUFFQS9HLHFCQUFPc0gsUUFBUDtBQUVELGFBVkQsQ0FVRSxPQUFPckUsQ0FBUCxFQUFVO0FBRVZqRCxxQkFBT2tELE1BQVAsQ0FBY0QsQ0FBZDtBQUVEO0FBQ0YsV0FuQlM7QUFEYyxTQUFmLEVBc0JKQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBdEJXLENBQWI7QUF5QkQsT0ExQkQsQ0FGSSxDQUFOO0FBOEJBLGFBQU9qRCxPQUFPeUUsT0FBUCxFQUFQO0FBRUQsS0FqRkQ7QUFBQTs7QUFyQ2EsQ0FBZixFOzs7Ozs7Ozs7OztBQ1pBLElBQUloRixNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUk2SSxhQUFKO0FBQWtCakosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQytJLGdCQUFjN0ksQ0FBZCxFQUFnQjtBQUFDNkksb0JBQWM3SSxDQUFkO0FBQWdCOztBQUFsQyxDQUFqRCxFQUFxRixDQUFyRjtBQUF3RixJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUE5QyxFQUFvRSxDQUFwRTtBQU14TSxJQUFJNEMsTUFBTSxNQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXNCRSxNQUF0QjtBQUFBLG9DQUE4QjtBQUU1QjtBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsVUFBSVEsU0FBUyxJQUFJNkYsYUFBSixDQUFrQi9GLE9BQU9pRyxPQUF6QixFQUFrQ2pHLE9BQU8yRSxPQUF6QyxDQUFiO0FBRUEsb0JBQU0xRSxPQUFPTyxLQUFQLENBQ0osVUFESSxFQUVKLCtCQUFZO0FBQ1YsNkJBQWFOLE9BQU9RLE9BQVAsQ0FDWCxFQURXLEVBRUp3QyxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBRlcsQ0FBYjtBQUtELE9BTkQsQ0FGSSxDQUFOO0FBVUEsYUFBT2pELE9BQU95RSxPQUFQLEVBQVA7QUFFRCxLQW5CRDtBQUFBOztBQUxhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNSQTVILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwrQkFBUixDQUFiO0FBQXVERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0F2REYsT0FBTzZLLE1BQVAsQ0FBYztBQUFDQyxXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJQyxLQUFKO0FBQVUvSyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM2SyxRQUFNM0ssQ0FBTixFQUFRO0FBQUMySyxZQUFNM0ssQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUV4QyxNQUFNMEssVUFBVSxJQUFJQyxNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQStCO0FBQUNDLGdCQUFhO0FBQWQsQ0FBL0IsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNGUGpMLE9BQU82SyxNQUFQLENBQWM7QUFBQzlILFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUlnSSxLQUFKO0FBQVUvSyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM2SyxRQUFNM0ssQ0FBTixFQUFRO0FBQUMySyxZQUFNM0ssQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSThLLElBQUo7QUFBU2xMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM4SyxXQUFLOUssQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJK0ssT0FBSjtBQUFZbkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQytLLGNBQVEvSyxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEO0FBQStELElBQUlnTCxTQUFKO0FBQWNwTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNrTCxZQUFVaEwsQ0FBVixFQUFZO0FBQUNnTCxnQkFBVWhMLENBQVY7QUFBWTs7QUFBMUIsQ0FBakMsRUFBNkQsQ0FBN0Q7QUFhblosTUFBTWlMLFVBQVUsSUFBSU4sTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUFnQztBQUM5Q0MsZ0JBQWM7QUFEZ0MsQ0FBaEMsQ0FBaEI7O0FBSU8sTUFBTWxJLE1BQU4sU0FBcUJxSSxTQUFyQixDQUErQjtBQUVwQ0UsY0FBWUMsUUFBWixFQUFzQjtBQUVwQixRQUFJMUQsVUFBVXdELFFBQVFHLE9BQVIsQ0FBZ0I7QUFDNUI1QixXQUFLMkI7QUFEdUIsS0FBaEIsQ0FBZDtBQUlBLFVBQU0xRCxPQUFOO0FBRUEsUUFBSUcsT0FBTyxLQUFLeUQsT0FBTCxFQUFYOztBQUVBLFlBQVF6RCxLQUFLMEQsSUFBYjtBQUVFLFdBQUssT0FBTDtBQUNFLGFBQUtDLEtBQUwsR0FBYSxJQUFJaEosS0FBSixDQUFVcUYsS0FBS3ZFLElBQWYsQ0FBYjs7QUFDQSxhQUFLbUksTUFBTCxHQUFjLENBQVFDLFdBQVkvSCxNQUFELElBQVUsQ0FBRSxDQUEvQixFQUFpQ2dJLFVBQVcxRixDQUFELElBQUssQ0FBRSxDQUFsRCw4QkFBd0Q7QUFDcEUsY0FBSXJDLE1BQU8saUJBQWdCaUUsS0FBSytELEtBQU0sRUFBdEM7QUFDQSwrQkFBYSxLQUFLSixLQUFMLENBQVdLLGNBQVgsQ0FBMEJqSSxHQUExQixFQUErQjhILFFBQS9CLEVBQXlDQyxPQUF6QyxDQUFiO0FBQ0QsU0FIYSxDQUFkOztBQUlBOztBQUVGO0FBQ0UsY0FBTSxJQUFJRyxLQUFKLENBQVUsdUJBQVYsQ0FBTjtBQVhKO0FBY0Q7QUFFRDs7Ozs7O0FBSU1ySSxTQUFOLENBQWNzSSxZQUFZLEVBQTFCLEVBQThCSixVQUFpQjFGLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQXhDO0FBQUEsb0NBQXlEO0FBRXZELFVBQUl5QixVQUFVLEtBQUtzRSxVQUFMLEVBQWQsQ0FGdUQsQ0FJdkQ7O0FBQ0F0RSxjQUFRdUUsT0FBUixDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJYLGNBQU0sTUFEYTtBQUVuQi9ILGVBQU87QUFGWSxPQUFyQjtBQUtBLFVBQUkySSxRQUFRLEVBQVo7O0FBQ0EsV0FBSyxJQUFJbEosTUFBVCxJQUFtQnlFLFFBQVF1RSxPQUEzQixFQUFvQztBQUNsQ0UsY0FBTWxKLE9BQU9zSSxJQUFiLElBQXFCO0FBQ25CL0gsaUJBQU9QLE9BQU9PLEtBREs7QUFFbkIySSxpQkFBTztBQUZZLFNBQXJCO0FBSUQ7O0FBRUQsb0JBQU0sS0FBS1YsTUFBTCxDQUNHOUgsTUFBUCw2QkFBZ0I7QUFDZCxhQUFLLElBQUlWLE1BQVQsSUFBbUJ5RSxRQUFRdUUsT0FBM0IsRUFBb0M7QUFDbEMsY0FBSXpJLFFBQVF3SCxRQUFRb0IsUUFBUixDQUFpQm5KLE9BQU9PLEtBQXhCLENBQVo7QUFDQSxjQUFJNkksT0FBT3RCLEtBQU12SCxLQUFOLENBQVg7O0FBQ0EsY0FBSTZJLEtBQUsxSSxNQUFMLENBQUosRUFBa0I7QUFDaEJ3SSxrQkFBTWxKLE9BQU9zSSxJQUFiLEVBQW1CWSxLQUFuQjs7QUFDQSxnQkFBSSxPQUFPSixVQUFVOUksT0FBT3NJLElBQWpCLENBQVAsS0FBa0MsV0FBdEMsRUFBa0Q7QUFDaEQsNEJBQU1RLFVBQVU5SSxPQUFPc0ksSUFBakIsRUFBdUI1SCxNQUF2QixDQUFOO0FBQ0Q7O0FBQ0Q7QUFDRDtBQUNGO0FBQ0YsT0FaRCxDQURJLEVBY0pnSSxPQWRJLENBQU4sRUFsQnVELENBbUN2RDs7QUFDQSxhQUFPUSxLQUFQO0FBRUQsS0F0Q0Q7QUFBQTs7QUFoQ29DLEM7Ozs7Ozs7Ozs7O0FDakJ0Q3RNLE9BQU82SyxNQUFQLENBQWM7QUFBQ08sYUFBVSxNQUFJQSxTQUFmO0FBQXlCdkksU0FBTSxNQUFJQTtBQUFuQyxDQUFkO0FBQXlELElBQUlrSSxLQUFKO0FBQVUvSyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUM2SyxRQUFNM0ssQ0FBTixFQUFRO0FBQUMySyxZQUFNM0ssQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFRbk4sTUFBTXFNLFNBQVMsSUFBSTFCLE1BQU1DLFVBQVYsQ0FBcUIsUUFBckIsRUFBK0I7QUFDNUNDLGdCQUFjO0FBRDhCLENBQS9CLENBQWY7O0FBSU8sTUFBTUcsU0FBTixDQUFnQjtBQUlyQkUsY0FBWXpELE9BQVosRUFBcUI7QUFDbkIsU0FBS0EsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBNEQsWUFBVTtBQUNSLFdBQU8sS0FBSzVELE9BQUwsQ0FBYTZFLFlBQXBCO0FBQ0Q7O0FBRURQLGVBQWE7QUFDWCxXQUFPLEtBQUt0RSxPQUFaO0FBQ0Q7O0FBRURqRSxVQUFRK0ksV0FBa0I3SSxNQUFQLDZCQUFrQixDQUFFLENBQXBCLENBQW5CLEVBQXlDZ0ksVUFBaUIxRixDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUFuRCxFQUFvRSxDQUFFOztBQXJCakQ7O0FBeUJoQixNQUFNdkQsS0FBTixTQUFvQnVJLFNBQXBCLENBQThCO0FBRW5DRSxjQUFZc0IsT0FBWixFQUFxQjtBQUVuQixRQUFJL0UsVUFBVTRFLE9BQU9qQixPQUFQLENBQWU7QUFDM0I1QixXQUFLZ0Q7QUFEc0IsS0FBZixDQUFkO0FBSUEsVUFBTS9FLE9BQU47QUFFQSxRQUFJRyxPQUFPLEtBQUt5RCxPQUFMLEVBQVg7O0FBRUEsWUFBUXpELEtBQUswRCxJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UsYUFBS0MsS0FBTCxHQUFhLElBQUloSixLQUFKLENBQVVxRixLQUFLdkUsSUFBZixDQUFiOztBQUNBLGFBQUttSSxNQUFMLEdBQXFCOUosR0FBUCw2QkFBZTtBQUMzQixjQUFJaUMsTUFBTyxpQkFBZ0JpRSxLQUFLK0QsS0FBTSxZQUFXakssSUFBSStLLEdBQUksU0FBUS9LLElBQUl5RSxFQUFHLEdBQXhFO0FBQ0EsK0JBQWEsS0FBS29GLEtBQUwsQ0FBV2hJLEtBQVgsQ0FBaUJJLEdBQWpCLENBQWI7QUFDRCxTQUhhLENBQWQ7O0FBSUE7O0FBQ0Y7QUFDRSxjQUFNLElBQUlrSSxLQUFKLENBQVUsb0JBQVYsQ0FBTjtBQVRKO0FBWUQ7QUFHRDs7Ozs7O0FBSUFySSxVQUFRK0ksV0FBa0I3SSxNQUFQLDZCQUFrQixDQUFFLENBQXBCLENBQW5CLEVBQXlDZ0ksVUFBaUIxRixDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUFuRCxFQUFvRTtBQUVsRSxRQUFJMEcsTUFBTUwsT0FBT3BFLElBQVAsQ0FBWTtBQUNwQnVFLGVBQVMsS0FBSy9FLE9BQUwsQ0FBYStCO0FBREYsS0FBWixFQUVQO0FBQ0RtRCxjQUFRO0FBQ05uRCxhQUFLLENBREM7QUFFTnJELFlBQUksQ0FGRTtBQUdOc0csYUFBSztBQUhDO0FBRFAsS0FGTyxDQUFWO0FBVUEsV0FBTyxJQUFJRyxPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBRW5CSixVQUFJSyxPQUFKLENBQ0UsQ0FBT3JMLEdBQVAsRUFBWXNMLEtBQVosOEJBQXNCO0FBQ3BCLFlBQUk7QUFDRixjQUFJdEosdUJBQWUsS0FBSzhILE1BQUwsQ0FBWTlKLEdBQVosQ0FBZixDQUFKO0FBQ0Esd0JBQU02SyxTQUFTN0ksTUFBVCxDQUFOO0FBQ0QsU0FIRCxDQUdFLE9BQU9zQyxDQUFQLEVBQVU7QUFDVjBGLGtCQUFRMUYsQ0FBUjtBQUNEOztBQUNELFlBQUlnSCxRQUFRLENBQVIsS0FBY04sSUFBSVIsS0FBSixFQUFsQixFQUErQjtBQUM3Qlc7QUFDRDtBQUNGLE9BVkQsQ0FERjtBQWFELEtBaEJJLEVBaUJMSSxLQWpCSyxDQWtCSmpILENBQUQsSUFBTztBQUNMLFlBQU1BLENBQU47QUFDRCxLQXBCSSxDQUFQO0FBdUJEOztBQWxFa0MsQzs7Ozs7Ozs7Ozs7QUNyQ3JDcEcsT0FBTzZLLE1BQVAsQ0FBYztBQUFDdEssV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSXdLLEtBQUo7QUFBVS9LLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQzZLLFFBQU0zSyxDQUFOLEVBQVE7QUFBQzJLLFlBQU0zSyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRXhDLE1BQU1HLFVBQVUsSUFBSXdLLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBK0I7QUFBQ0MsZ0JBQWE7QUFBZCxDQUEvQixDQUFoQixDOzs7Ozs7Ozs7OztBQ0ZQakwsT0FBTzZLLE1BQVAsQ0FBYztBQUFDM0IsWUFBUyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSXZHLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBakQsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSWtOLFdBQUo7QUFBZ0J0TixPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNvTixjQUFZbE4sQ0FBWixFQUFjO0FBQUNrTixrQkFBWWxOLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7O0FBS3BJLE1BQU04SSxRQUFOLENBQWU7QUFFcEJvQyxjQUFZSyxRQUFRLElBQUloSixLQUFKLEVBQXBCLEVBQWlDO0FBQy9CLFNBQUs0SyxNQUFMLEdBQWM1QixLQUFkO0FBQ0Q7O0FBRUs5QixhQUFOLENBQW1CRyxnQkFBbkIsRUFBcUNOLFdBQVcsQ0FBaEQ7QUFBQSxvQ0FBbUQ7QUFFakQsV0FBSzZELE1BQUwsQ0FBWUMsV0FBWixDQUNFLG1CQURGLEVBRUcsc0JBQXFCeEQsZ0JBQWlCLEVBRnpDLEVBR0UsRUFIRixFQUdLO0FBQ0R5RCxlQUFPL0QsUUFETjtBQUVEZ0UseUJBQWlCLENBRmhCO0FBR0R6SCxxQkFBYTtBQUhaLE9BSEw7QUFVQSxXQUFLc0gsTUFBTCxDQUFZQyxXQUFaLENBQ0UsbUJBREYsRUFFRyxzQkFBcUJ4RCxnQkFBaUIsRUFGekMsRUFHRSxFQUhGLEVBR0s7QUFDRHlELGVBQU8vRCxRQUROO0FBRUR6RCxxQkFBYTtBQUZaLE9BSEw7QUFTRCxLQXJCRDtBQUFBOztBQXdCTTJFLGtCQUFOLENBQXVCcEosSUFBdkI7QUFBQSxvQ0FBNkI7QUFFM0IsVUFBSTRJLGFBQWE1SSxLQUFLNEksVUFBdEI7QUFFQSxVQUFJcEQsTUFBTSxFQUFWOztBQUVBLFVBQUkyRyxRQUFlM0ssR0FBUCw2QkFBZTtBQUN6QmdFLFlBQUlxRixJQUFKLGVBQ1EsS0FBS2tCLE1BQUwsQ0FBWXBILFdBQVosQ0FDSixpQkFESSxFQUVKLEVBRkksRUFHSjtBQUNFeUgsc0JBQVlwTSxLQUFLb00sVUFEbkI7QUFFRTVLLGVBQUtBLEdBRlA7QUFHRW9ILHNCQUFZQTtBQUhkLFNBSEksQ0FEUjtBQVNNLE9BVkksQ0FBWjs7QUFZQSxVQUFJeUQsU0FBZ0I3SyxHQUFQLDZCQUFlO0FBQzFCLFlBQUllLE1BQU87OzJCQUVVdkMsS0FBS29NLFVBQVcsY0FBYTVLLEdBQUk7T0FGdEQ7QUFJQWdFLFlBQUlxRixJQUFKLGVBQWdCLEtBQUtrQixNQUFMLENBQVk1SixLQUFaLENBQWtCSSxHQUFsQixDQUFoQjtBQUNELE9BTlksQ0FBYjs7QUFRQSxXQUFLLElBQUkrSixNQUFULElBQW1CdE0sS0FBS3VNLElBQXhCLEVBQThCO0FBQzVCLGdCQUFRRCxPQUFPRSxHQUFmO0FBQ0UsZUFBSyxJQUFMO0FBQ0UsMEJBQU1MLE1BQU1HLE9BQU85SyxHQUFiLENBQU47QUFDQTs7QUFDRixlQUFLLEtBQUw7QUFDRSwwQkFBTTZLLE9BQU9DLE9BQU85SyxHQUFkLENBQU47QUFDQTtBQU5KO0FBUUQ7O0FBRUQsYUFBTztBQUNMZ0UsYUFBS0E7QUFEQSxPQUFQO0FBSUQsS0F6Q0Q7QUFBQTs7QUEyQ00wRCxvQkFBTixDQUF5QmxKLElBQXpCO0FBQUEsb0NBQStCO0FBRTdCLFVBQUlvTSxhQUFhcE0sS0FBS29NLFVBQXRCO0FBQ0EsVUFBSUssU0FBU3pNLEtBQUt5TSxNQUFsQjtBQUNBLFVBQUk3RCxhQUFhNUksS0FBSzRJLFVBQXRCO0FBRUEsVUFBSXBELE1BQU0sRUFBVixDQU42QixDQVE3Qjs7QUFDQSxVQUFJakQsTUFBTyxvREFBbUQ2SixVQUFXLEVBQXpFO0FBQ0E1RyxVQUFJcUYsSUFBSixlQUFlLEtBQUtrQixNQUFMLENBQVk1SixLQUFaLENBQWtCSSxHQUFsQixDQUFmLEdBVjZCLENBWTdCOztBQUNBLFdBQUssSUFBSW1LLElBQUksQ0FBYixFQUFnQkEsSUFBSUQsT0FBT0UsTUFBM0IsRUFBbUNELEdBQW5DLEVBQXdDO0FBRXRDLGFBQUtYLE1BQUwsQ0FBWXBILFdBQVosQ0FDRSxtQkFERixFQUN1QjtBQUNuQnlILHNCQUFZQSxVQURPO0FBRW5CeEQsc0JBQVlBLFVBRk87QUFHbkJnRSxxQkFBV0gsT0FBT0MsQ0FBUCxDQUhRO0FBSW5CRyxnQkFBTUgsSUFBSTtBQUpTLFNBRHZCLEVBTUs7QUFDRGxJLHVCQUFhO0FBRFosU0FOTDtBQVVEOztBQUVELGFBQU87QUFDTGdCLGFBQUtBO0FBREEsT0FBUDtBQUlELEtBL0JEO0FBQUE7O0FBaUNNMkQsZUFBTixDQUFvQm5KLElBQXBCO0FBQUEsb0NBQTBCO0FBRXhCLFVBQUk4TSxjQUFjLEVBQWxCO0FBQ0EsVUFBSUMsT0FBTyxFQUFYLENBSHdCLENBS3hCOztBQUVBQSxhQUFPLENBQ0wsUUFESyxFQUVMLE1BRkssRUFHTCxNQUhLLEVBSUwsa0JBSkssRUFLTCxvQkFMSyxFQU1MLGFBTkssRUFPTCxXQVBLLENBQVA7O0FBU0EsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSS9NLEtBQUtnTixDQUFMLENBQUosRUFBYUYsWUFBWUUsQ0FBWixJQUFpQmhOLEtBQUtnTixDQUFMLENBQWpCO0FBQ2Q7O0FBRUQsV0FBS2pCLE1BQUwsQ0FBWUMsV0FBWixDQUNFLGFBREYsRUFFRyxnQkFBZWhNLEtBQUtvTSxVQUFXLEVBRmxDLEVBR0VVLFdBSEYsRUFHZTtBQUNYckkscUJBQWE7QUFERixPQUhmLEVBcEJ3QixDQTRCeEI7O0FBRUFxSSxvQkFBYyxFQUFkO0FBQ0FDLGFBQU8sQ0FDTCxrQkFESyxFQUVMLGNBRkssRUFHTCxZQUhLLEVBSUwsU0FKSyxFQUtMLFNBTEssRUFNTCxjQU5LLENBQVA7O0FBUUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSS9NLEtBQUtnTixDQUFMLENBQUosRUFBYUYsWUFBWUUsQ0FBWixJQUFpQmhOLEtBQUtnTixDQUFMLENBQWpCO0FBQ2Q7O0FBRUQsVUFBSXhILE1BQU0sS0FBS3VHLE1BQUwsQ0FBWUMsV0FBWixDQUNSLG1CQURRLEVBRVAsZ0JBQWVoTSxLQUFLb00sVUFBVyxFQUZ4QixFQUdSVSxXQUhRLEVBR0s7QUFDWHJJLHFCQUFhO0FBREYsT0FITCxDQUFWO0FBUUEsYUFBTztBQUNMZSxhQUFLQTtBQURBLE9BQVA7QUFJRCxLQXZERDtBQUFBOztBQXlETXNELGVBQU4sQ0FBb0I5SSxJQUFwQjtBQUFBLG9DQUEwQjtBQUV4QixVQUFJNEksYUFBYTVJLEtBQUs0SSxVQUF0QjtBQUVBLFVBQUlwRCxNQUFNLEVBQVY7QUFFQSxVQUFJc0gsY0FBYyxFQUFsQjtBQUNBLFVBQUlDLE9BQU8sRUFBWDtBQUVBQSxhQUFPLENBQ0wsTUFESyxFQUVMLG9CQUZLLENBQVAsQ0FUd0IsQ0FheEI7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSS9NLEtBQUtnTixDQUFMLENBQUosRUFBYUYsWUFBWUUsQ0FBWixJQUFpQmhOLEtBQUtnTixDQUFMLENBQWpCO0FBQ2Q7O0FBRUR4SCxVQUFJNEcsVUFBSixpQkFBdUIsS0FBS0wsTUFBTCxDQUFZcEgsV0FBWixDQUNyQixhQURxQixFQUVyQm1JLFdBRnFCLEVBRVI7QUFDWGxFLG9CQUFZQSxVQUREO0FBRVhuRyxnQkFBUSxDQUZHO0FBR1g4QixjQUFNLE1BSEs7QUFJWDBJLDBCQUFrQixNQUpQO0FBS1hDLHFCQUFhLE1BTEY7QUFNWEMsbUJBQVcsTUFOQTtBQU9YM0kscUJBQWEsT0FQRjtBQVFYQyxxQkFBYTtBQVJGLE9BRlEsQ0FBdkI7QUFlQXFJLG9CQUFjLEVBQWQ7QUFDQUMsYUFBTyxDQUNMLGNBREssRUFFTCxpQkFGSyxFQUdMLFNBSEssRUFJTCxTQUpLLEVBS0wsY0FMSyxDQUFQLENBdEN3QixDQTZDeEI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJL00sS0FBS2dOLENBQUwsQ0FBSixFQUFhRixZQUFZRSxDQUFaLElBQWlCaE4sS0FBS2dOLENBQUwsQ0FBakI7QUFDZDs7QUFFRHhILFVBQUlnRCxnQkFBSixpQkFBNkIsS0FBS3VELE1BQUwsQ0FBWXBILFdBQVosQ0FDM0IsbUJBRDJCLEVBRTNCbUksV0FGMkIsRUFFZDtBQUNYbEUsb0JBQVlBLFVBREQ7QUFFWHdELG9CQUFZNUcsSUFBSTRHLFVBRkw7QUFHWEgsZUFBTyxDQUhJO0FBSVhDLHlCQUFpQixDQUpOO0FBS1hrQiw0QkFBb0IsTUFMVDtBQU1YQyw0QkFBb0IsTUFOVDtBQU9YQywwQkFBa0IsTUFQUDtBQVFYQyxvQkFBWSxNQVJEO0FBU1gvSSxxQkFBYSxPQVRGO0FBVVhDLHFCQUFhO0FBVkYsT0FGYyxDQUE3Qjs7QUFnQkEsV0FBSyxJQUFJdUksQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUkvTSxLQUFLZ04sQ0FBTCxDQUFKLEVBQWFGLFlBQVlFLENBQVosSUFBaUJoTixLQUFLZ04sQ0FBTCxDQUFqQjtBQUNkOztBQUVEeEgsVUFBSWdJLGdCQUFKLGlCQUE2QixLQUFLekIsTUFBTCxDQUFZcEgsV0FBWixDQUMzQixtQkFEMkIsRUFDTixFQURNLEVBQ0Y7QUFDdkI2RCwwQkFBa0JoRCxJQUFJZ0QsZ0JBREM7QUFFdkJJLG9CQUFZQSxVQUZXO0FBR3ZCcUQsZUFBTyxDQUhnQjtBQUl2QnpILHFCQUFhLE9BSlU7QUFLdkJDLHFCQUFhO0FBTFUsT0FERSxDQUE3QixFQTNFd0IsQ0FxRnhCOztBQUNBLGFBQU87QUFDTGUsYUFBS0E7QUFEQSxPQUFQO0FBSUQsS0ExRkQ7QUFBQTs7QUFuS29CLEM7Ozs7Ozs7Ozs7O0FDTHRCaEgsT0FBTzZLLE1BQVAsQ0FBYztBQUFDb0UsbUJBQWdCLE1BQUlBLGVBQXJCO0FBQXFDQyxZQUFTLE1BQUlBLFFBQWxEO0FBQTJEQyxpQkFBYyxNQUFJQSxhQUE3RTtBQUEyRmxHLGlCQUFjLE1BQUlBO0FBQTdHLENBQWQ7QUFBMkksSUFBSThCLEtBQUo7QUFBVS9LLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQzZLLFFBQU0zSyxDQUFOLEVBQVE7QUFBQzJLLFlBQU0zSyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSThLLElBQUo7QUFBU2xMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM4SyxXQUFLOUssQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJK0ssT0FBSjtBQUFZbkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQytLLGNBQVEvSyxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEO0FBQStELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSWtOLFdBQUo7QUFBZ0J0TixPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNvTixjQUFZbE4sQ0FBWixFQUFjO0FBQUNrTixrQkFBWWxOLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7O0FBT3RmLE1BQU02TyxlQUFOLENBQXNCO0FBQzNCM0QsY0FBWXRELElBQVosRUFBa0JILE9BQWxCLEVBQTJCO0FBQ3pCLFFBQUl1SCxRQUFKOztBQUNBLFlBQVFwSCxLQUFLMEQsSUFBYjtBQUNFLFdBQUssT0FBTDtBQUNFMEQsbUJBQVcsSUFBSUQsYUFBSixDQUFrQm5ILElBQWxCLEVBQXdCSCxPQUF4QixDQUFYO0FBRko7O0FBS0EsV0FBT3VILFFBQVA7QUFDRDs7QUFUMEI7O0FBWXRCLE1BQU1GLFFBQU4sQ0FBZTtBQUNwQjtBQUdBNUQsY0FBWXRELElBQVosRUFBa0JILE9BQWxCLEVBQTJCO0FBQ3pCLFNBQUtHLElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUtILE9BQUwsR0FBZUEsT0FBZjtBQUNEOztBQUVELFNBQU93SCxPQUFQLENBQWVySCxJQUFmLEVBQXFCSCxPQUFyQixFQUE4QjtBQUM1QixRQUFJdUgsUUFBSjs7QUFDQSxZQUFRcEgsS0FBSzBELElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxlQUFPLElBQUl5RCxhQUFKLENBQWtCbkgsSUFBbEIsRUFBd0JILE9BQXhCLENBQVA7O0FBQ0Y7QUFDRSxjQUFNLElBQUlvRSxLQUFKLENBQVUsbUJBQVYsQ0FBTjtBQUpKO0FBTUQ7O0FBRURxRCxhQUFXO0FBQ1QsV0FBTyxLQUFLdEgsSUFBWjtBQUNEOztBQUVEdUgsYUFBVztBQUNULFdBQU8sS0FBS3ZILElBQUwsQ0FBVXZFLElBQWpCO0FBQ0Q7O0FBRUQrTCxnQkFBYztBQUNaLFdBQU8sS0FBSzNILE9BQVo7QUFDRDs7QUFFRDRILHFCQUNFQyxLQUFLLENBQU83RCxXQUFXL0gsVUFBVSxDQUFFLENBQTlCLEVBQWdDZ0ksVUFBVTFGLEtBQUssQ0FBRSxDQUFqRCw4QkFBc0QsQ0FBRSxDQUF4RCxDQURQLEVBRUU7QUFDQSxTQUFLd0YsTUFBTCxHQUFjOEQsRUFBZDtBQUNEO0FBRUQ7Ozs7Ozs7Ozs7O0FBU005TCxTQUFOLENBQWMrTCxZQUFZLEVBQTFCO0FBQUEsb0NBQThCO0FBQzVCLFVBQUk5SCxVQUFVLEtBQUsySCxXQUFMLEVBQWQsQ0FENEIsQ0FHNUI7O0FBQ0EzSCxjQUFRdUUsT0FBUixDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJySyxjQUFNLE1BRGE7QUFFbkIyQixlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJaU0sVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSUMsQ0FBVCxJQUFjaEksUUFBUXVFLE9BQXRCLEVBQStCLENBQzlCOztBQUVELFVBQUlBLFVBQVUsRUFBZDs7QUFFQSxXQUFLLElBQUl5RCxDQUFULElBQWNoSSxRQUFRdUUsT0FBdEIsRUFBK0I7QUFDN0J3RCxnQkFBUUMsRUFBRTdOLElBQVYsSUFBa0I7QUFDaEIyQixpQkFBT2tNLEVBQUVsTSxLQURPO0FBRWhCbU0saUJBQU8sT0FBT0QsRUFBRUMsS0FBVCxLQUFtQixXQUFuQixHQUFpQ0QsRUFBRUMsS0FBbkMsR0FBMkMsQ0FGbEM7QUFHaEJ4RCxpQkFBTztBQUhTLFNBQWxCO0FBS0FGLGdCQUFRQyxJQUFSLENBQ0U7QUFDRXJLLGdCQUFNNk4sRUFBRTdOLElBRFY7QUFFRXdLLGdCQUFNdEIsS0FBTUMsUUFBUW9CLFFBQVIsQ0FBaUJzRCxFQUFFbE0sS0FBbkIsQ0FBTjtBQUZSLFNBREY7QUFNRDs7QUFFRCxvQkFBTSxLQUFLaUksTUFBTCxDQUNKLENBQU85SCxNQUFQLEVBQWUyRixPQUFmLDhCQUEyQjtBQUV6QixhQUFLLElBQUlvRyxDQUFULElBQWN6RCxPQUFkLEVBQXVCO0FBRXJCO0FBQ0EsY0FBSTJELElBQUlILFFBQVFDLEVBQUU3TixJQUFWLENBQVI7O0FBQ0EsY0FBSStOLEVBQUVELEtBQU4sRUFBYTtBQUNYLGdCQUFJQyxFQUFFekQsS0FBRixJQUFXeUQsRUFBRUQsS0FBakIsRUFBd0I7QUFDdEI7QUFDRDtBQUNGOztBQUVELGNBQUlELEVBQUVyRCxJQUFGLENBQU8xSSxNQUFQLENBQUosRUFBb0I7QUFFbEI7QUFDQWlNLGNBQUV6RCxLQUFGLEdBSGtCLENBS2xCOztBQUNBLGdCQUFJLE9BQU9xRCxVQUFVRSxFQUFFN04sSUFBWixDQUFQLEtBQTZCLFdBQWpDLEVBQThDO0FBQzVDLDRCQUFNMk4sVUFBVUUsRUFBRTdOLElBQVosRUFBa0I4QixNQUFsQixFQUEwQjJGLE9BQTFCLENBQU47QUFDRDs7QUFDRDtBQUVEO0FBQ0Y7QUFDRixPQXpCRCxDQURJLENBQU4sRUE3QjRCLENBeUQ1Qjs7QUFDQSxhQUFPbUcsT0FBUDtBQUNELEtBM0REO0FBQUE7O0FBOUNvQjs7QUE4R2YsTUFBTVQsYUFBTixTQUE0QkQsUUFBNUIsQ0FBcUM7QUFDMUM1RCxjQUFZdEQsSUFBWixFQUFrQkgsT0FBbEIsRUFBMkI7QUFDekIsVUFBTUcsSUFBTixFQUFZSCxPQUFaO0FBRUEsUUFBSXBFLE9BQU8sS0FBSzhMLFFBQUwsRUFBWDtBQUVBLFNBQUs1RCxLQUFMLEdBQWEsSUFBSWhKLEtBQUosQ0FBVWMsSUFBVixDQUFiO0FBQ0EsU0FBS2dNLGtCQUFMLENBQXdCLENBQU81RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQsVUFBSS9ILE1BQU8saUJBQWdCaUUsS0FBSytELEtBQU0sRUFBdEM7QUFDQSwyQkFBYSxLQUFLSixLQUFMLENBQVdLLGNBQVgsQ0FBMEJqSSxHQUExQixFQUErQjhILFFBQS9CLEVBQTBDekYsQ0FBRCxJQUFLO0FBQUMsY0FBTUEsQ0FBTjtBQUFRLE9BQXZELENBQWI7QUFDRCxLQUh1QixDQUF4QjtBQUlEOztBQVh5Qzs7QUFtQnJDLE1BQU02QyxhQUFOLFNBQTRCaUcsUUFBNUIsQ0FBcUM7QUFDMUM1RCxjQUFZdEQsSUFBWixFQUFrQkgsT0FBbEIsRUFBMkI7QUFDekIsVUFBTUcsSUFBTixFQUFZSCxPQUFaLEVBRHlCLENBR3pCOztBQUNBLFNBQUs0SCxrQkFBTCxDQUF3QixDQUFPNUQsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBRW5ELFVBQUlrRSxNQUFKO0FBQ0FBLDZCQUFlMUMsWUFBWTJDLE9BQVosQ0FBb0JqSSxLQUFLa0ksR0FBekIsQ0FBZixFQUhtRCxDQUtuRDs7QUFDQSxVQUFJcEksS0FBS2tJLE9BQU9sSSxFQUFQLENBQVVFLEtBQUttSSxRQUFmLENBQVQ7QUFDQSxVQUFJL0gsYUFBYU4sR0FBR00sVUFBSCxDQUFjSixLQUFLSSxVQUFuQixDQUFqQjtBQUVBLFVBQUlxQixVQUFVO0FBQ1p1RyxnQkFBUUEsTUFESTtBQUVaNUgsb0JBQVlBLFVBRkE7QUFHWitILGtCQUFVckk7QUFIRSxPQUFkO0FBTUEsVUFBSWdGLE1BQU0xRSxXQUFXQyxJQUFYLEVBQVY7O0FBRUEsMkJBQWF5RSxJQUFJc0QsT0FBSixFQUFiLEdBQTRCO0FBQzFCLFlBQUl0TyxvQkFBWWdMLElBQUl1RCxJQUFKLEVBQVosQ0FBSjtBQUNBLHNCQUFNeEUsU0FBUy9KLEdBQVQsRUFBYzJILE9BQWQsQ0FBTjtBQUNEOztBQUFBO0FBRUYsS0F0QnVCLENBQXhCO0FBd0JEOztBQTdCeUMsQzs7Ozs7Ozs7Ozs7QUNwSjVDekosT0FBTzZLLE1BQVAsQ0FBYztBQUFDMUssV0FBUSxNQUFJcUk7QUFBYixDQUFkO0FBQTRDLElBQUlULGVBQUo7QUFBb0IvSCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUM2SCxrQkFBZ0IzSCxDQUFoQixFQUFrQjtBQUFDMkgsc0JBQWdCM0gsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXRDLEVBQThFLENBQTlFO0FBQWlGLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBOUMsRUFBc0UsQ0FBdEU7O0FBRzlJLE1BQU1vSSxjQUFOLENBQW9CO0FBRTNCSyxNQUFOLENBQVdiLElBQVg7QUFBQSxvQ0FBZ0I7QUFFZCxXQUFLc0ksS0FBTCxpQkFBbUJ2SSxnQkFBZ0JJLEdBQWhCLENBQXFCSCxJQUFyQixFQUEyQixPQUEzQixDQUFuQjtBQUNBLFdBQUt1SSxRQUFMLGlCQUFzQnhJLGdCQUFnQkksR0FBaEIsQ0FBcUJILElBQXJCLEVBQTJCLFVBQTNCLENBQXRCO0FBRUQsS0FMRDtBQUFBOztBQU9NMkIsVUFBTixDQUFnQjZHLE9BQWhCO0FBQUEsb0NBQXlCO0FBRXZCLFVBQUlDLHdCQUFnQixLQUFLSCxLQUFMLENBQVc5RSxPQUFYLENBQW1CO0FBQUU1QixhQUFLNEc7QUFBUCxPQUFuQixFQUFvQztBQUFDdkksb0JBQVk7QUFBQyxxQkFBVTtBQUFYO0FBQWIsT0FBcEMsQ0FBaEIsQ0FBSjtBQUNBLFVBQUl5SSxlQUFlRCxRQUFRRSxPQUEzQixDQUh1QixDQUt2QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQUlDLGFBQWEsRUFBakI7O0FBRUEsV0FBSyxJQUFJQyxXQUFULElBQXdCSCxZQUF4QixFQUFzQztBQUVwQyxZQUFJSSxlQUFlLENBQW5COztBQUVBLGFBQUssSUFBSWxELFVBQVQsSUFBdUJpRCxXQUF2QixFQUFvQztBQUVsQyxjQUFJSix3QkFBZ0IsS0FBS0YsUUFBTCxDQUFjL0UsT0FBZCxDQUFzQjtBQUFDNUIsaUJBQUtnRTtBQUFOLFdBQXRCLEVBQXdDO0FBQUMzRix3QkFBVztBQUFDLHVCQUFRO0FBQVQ7QUFBWixXQUF4QyxDQUFoQixDQUFKO0FBQ0EsY0FBSThJLGNBQWNOLFFBQVFoRCxLQUExQixDQUhrQyxDQUtsQzs7QUFDQSxlQUFLLElBQUlBLEtBQVQsSUFBa0JzRCxXQUFsQixFQUErQjtBQUM3QkQsNEJBQWdCckQsTUFBTS9ELFFBQXRCO0FBQ0Q7QUFFRjs7QUFFRGtILG1CQUFXdkUsSUFBWCxDQUFnQnlFLFlBQWhCO0FBRUQsT0EvQnNCLENBaUN2Qjs7O0FBQ0EsVUFBSXBILFdBQVdzSCxLQUFLQyxHQUFMLENBQVNDLEtBQVQsQ0FBZ0IsSUFBaEIsRUFBc0JOLFVBQXRCLENBQWY7QUFFQSxhQUFPbEgsUUFBUDtBQUNELEtBckNEO0FBQUE7QUF1Q0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJNWCxVQUFOLENBQWdCMUgsUUFBaEIsRUFBMEJvSCxLQUExQixFQUFpQ0MsU0FBUyxJQUExQyxFQUFnREMsU0FBUyxJQUF6RDtBQUFBLG9DQUErRDtBQUU3RDtBQUNBLFVBQUlzRixTQUFTMU4sUUFBUThILElBQVIsQ0FBYTtBQUFDaEgsa0JBQVNBO0FBQVYsT0FBYixFQUFrQzhQLEtBQWxDLEdBQTBDQyxHQUExQyxDQUErQ2hSLEtBQUtBLEVBQUU2QixnQkFBdEQsQ0FBYixDQUg2RCxDQUs3RDs7QUFDQSxVQUFJbUIsU0FBUyxFQUFiO0FBQ0FBLGFBQU9xRixLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQWF0RixPQUFPaU8sWUFBUCxHQUFzQjNJLE1BQXRCO0FBQ2IsVUFBSUMsTUFBSixFQUFhdkYsT0FBT2tPLFlBQVAsR0FBc0IzSSxNQUF0QjtBQUViLFVBQUkzQixvQkFBWSxLQUFLc0osS0FBTCxDQUFXaUIsVUFBWCxDQUNkbk8sTUFEYyxFQUVkO0FBQ0VvTyxlQUFNO0FBQ0p2RCxrQkFBUTtBQUNOd0QsbUJBQU94RDtBQUREO0FBREo7QUFEUixPQUZjLENBQVosQ0FBSixDQVg2RCxDQXNCN0Q7O0FBQ0EsYUFBT0EsTUFBUDtBQUNELEtBeEJEO0FBQUE7QUEwQkE7Ozs7Ozs7Ozs7QUFRTWpGLFlBQU4sQ0FBa0JQLEtBQWxCLEVBQXlCQyxTQUFTLElBQWxDLEVBQXdDQyxTQUFTLElBQWpEO0FBQUEsb0NBQXVEO0FBRXJEO0FBQ0EsVUFBSXZGLFNBQVMsRUFBYjtBQUNBQSxhQUFPcUYsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFhdEYsT0FBT2lPLFlBQVAsR0FBc0IzSSxNQUF0QjtBQUNiLFVBQUlDLE1BQUosRUFBYXZGLE9BQU9rTyxZQUFQLEdBQXNCM0ksTUFBdEI7QUFFYixVQUFJM0Isb0JBQVksS0FBS3NKLEtBQUwsQ0FBV2lCLFVBQVgsQ0FDZG5PLE1BRGMsRUFFZDtBQUNFb0gsY0FBSztBQUNIeUQsa0JBQVE7QUFETDtBQURQLE9BRmMsQ0FBWixDQUFKO0FBU0QsS0FqQkQ7QUFBQTs7QUFtQk15RCxjQUFOLENBQW9CbEksSUFBcEIsRUFBMEJpSCxPQUExQjtBQUFBLG9DQUFtQztBQUVqQztBQUNBLFVBQUl6QyxNQUFNLENBQ1I7QUFDRTJELGVBQU9uSSxLQUFLb0ksV0FEZDtBQUVFQyxpQkFBU3JJLEtBQUs2SCxZQUZoQjtBQUdFWixpQkFBUztBQUNQcUIsaUJBQU07QUFEQyxTQUhYO0FBTUVuTyxlQUFNO0FBQ0oyTix3QkFBYzlILEtBQUs4SDtBQURmO0FBTlIsT0FEUSxFQVdSO0FBQ0VLLGVBQU9uSSxLQUFLdUksV0FEZDtBQUVFRixpQkFBU3JJLEtBQUs4SCxZQUZoQjtBQUdFYixpQkFBUztBQUNQcUIsaUJBQU07QUFEQyxTQUhYO0FBTUVuTyxlQUFNO0FBQ0owTix3QkFBYzdILEtBQUs2SDtBQURmO0FBTlIsT0FYUSxDQUFWO0FBdUJBLFVBQUlXLFFBQVEsRUFBWjs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY2pFLEdBQWQsRUFBbUI7QUFDakJnRSxjQUFNM0YsSUFBTixDQUFXO0FBQ1Q2RixvQ0FDUSxLQUFLNUIsS0FBTCxDQUFXL0gsU0FBWCxDQUNKLENBQ0U7QUFBRTRKLG9CQUFRQyxPQUFPQyxNQUFQLENBQWVKLEVBQUV0TyxLQUFqQixFQUF3QjtBQUFFOEUscUJBQU9lLEtBQUtmO0FBQWQsYUFBeEI7QUFBVixXQURGLEVBRUU7QUFBRTZKLHNCQUFVRixPQUFPQyxNQUFQLENBQWVKLEVBQUV4QixPQUFqQixFQUEwQkEsT0FBMUI7QUFBWixXQUZGLENBREksRUFLSm5JLE9BTEksRUFEUixDQURTO0FBUVRpSyxpQkFBT047QUFSRSxTQUFYO0FBVUQ7O0FBRUQsYUFBT0QsS0FBUDtBQUVELEtBM0NEO0FBQUE7O0FBNkNNN0gsa0JBQU4sQ0FBdUJDLFVBQXZCLEVBQW1DWixJQUFuQztBQUFBLG9DQUF3QztBQUV0QztBQUNBLFVBQUlvRSxhQUFhLElBQWpCLENBSHNDLENBS3RDO0FBQ0E7O0FBQ0EsVUFBSTRFLGFBQWEsRUFBakI7QUFDQSxVQUFHaEosS0FBS2YsS0FBUixFQUFlK0osV0FBV25HLElBQVgsQ0FBZ0I3QyxLQUFLZixLQUFyQjtBQUNmLFVBQUdlLEtBQUs2SCxZQUFSLEVBQXNCbUIsV0FBV25HLElBQVgsQ0FBZ0I3QyxLQUFLNkgsWUFBckI7QUFDdEIsVUFBRzdILEtBQUs4SCxZQUFSLEVBQXNCa0IsV0FBV25HLElBQVgsQ0FBZ0I3QyxLQUFLOEgsWUFBckIsRUFWZ0IsQ0FZdEM7O0FBQ0EsVUFBSW1CLGVBQUo7O0FBQ0EsY0FBT2pKLEtBQUtrSixRQUFaO0FBQ0UsYUFBSyxLQUFMO0FBQVlELDRCQUFrQixDQUFsQjtBQUFxQjs7QUFDakMsYUFBSyxRQUFMO0FBQWVBLDRCQUFpQixDQUFqQjtBQUFvQjs7QUFDbkM7QUFBVUEsNEJBQWtCLENBQWxCO0FBQXFCO0FBSGpDLE9BZHNDLENBb0J0Qzs7O0FBQ0EsVUFBSTFFLE9BQU8sRUFBWDs7QUFDQSxjQUFPdkUsS0FBS2tKLFFBQVo7QUFDRSxhQUFLLEtBQUw7QUFBWTNFLGVBQUsxQixJQUFMLENBQVU7QUFBQ3JKLGlCQUFJLENBQUw7QUFBT2dMLGlCQUFJO0FBQVgsV0FBVixFQUEyQjtBQUFDaEwsaUJBQUksQ0FBTDtBQUFPZ0wsaUJBQUk7QUFBWCxXQUEzQjtBQUErQzs7QUFDM0QsYUFBSyxRQUFMO0FBQWVELGVBQUsxQixJQUFMLENBQVU7QUFBQ3JKLGlCQUFJLENBQUw7QUFBT2dMLGlCQUFJO0FBQVgsV0FBVixFQUEyQjtBQUFDaEwsaUJBQUksQ0FBTDtBQUFPZ0wsaUJBQUk7QUFBWCxXQUEzQjtBQUErQztBQUZoRSxPQXRCc0MsQ0EyQnRDOzs7QUFDQSxVQUFJMkUsZUFBZSxJQUFuQjs7QUFDQSxjQUFPbkosS0FBS2tKLFFBQVo7QUFDRSxhQUFLLEtBQUw7QUFBWUMseUJBQWUsSUFBZjtBQUFxQjs7QUFDakMsYUFBSyxRQUFMO0FBQWVBLHlCQUFlLEdBQWY7QUFBb0I7QUFGckMsT0E3QnNDLENBa0N0Qzs7O0FBQ0EsVUFBSVgsc0JBQWMsS0FBS04sWUFBTCxDQUFrQmxJLElBQWxCLEVBQXdCO0FBQUNvRSxvQkFBVztBQUFaLE9BQXhCLENBQWQsQ0FBSjtBQUVBLFVBQUlnRixnQkFDSlosTUFBTVosR0FBTixDQUNFeUIsUUFDRSxrQ0FDRywrQkFBOEJBLEtBQUtOLEtBQUwsQ0FBV1osS0FBTSxZQURsRCxHQUVFLG1CQUZGLEdBR0lrQixLQUFLWCxVQUFMLENBQWdCZCxHQUFoQixDQUNBMEIsYUFDRyw2QkFBNEJBLFVBQVVsRixVQUFXLHNEQUFxRGtGLFVBQVVoQixLQUFNLGVBRnpILEVBR0VpQixJQUhGLENBR08sRUFIUCxDQUhKLEdBT0UsUUFQRixHQVFFLFFBVk4sRUFZRUEsSUFaRixDQVlPLEVBWlAsQ0FEQSxDQXJDc0MsQ0FvRHRDOztBQUNBLFVBQUl2UixPQUFPO0FBQ1RvTSxvQkFBWUEsVUFESDtBQUVUeEQsb0JBQVlBLFVBRkg7QUFHVHBJLGNBQU8sR0FBRXdRLFdBQVdPLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBcUIsSUFBR3ZKLEtBQUt4SCxJQUFLLElBQUd3SCxLQUFLd0osUUFBUyxFQUhuRDtBQUlUQyw0QkFBb0JMLGdCQUFnQnBKLEtBQUswSixXQUpoQztBQUtUQyxzQkFBYzNKLEtBQUtmLEtBTFY7QUFNVDJLLGlCQUFTNUosS0FBSzZKLFlBTkw7QUFPVEMsaUJBQVM5SixLQUFLK0osV0FQTDtBQVFUdEYsZ0JBQVF6RSxLQUFLeUUsTUFSSjtBQVNUd0UseUJBQWlCQSxlQVRSO0FBVVQxRSxjQUFNQSxJQVZHO0FBV1Q0RSxzQkFBY0E7QUFYTCxPQUFYO0FBY0FQLGFBQU9DLE1BQVAsQ0FBZTdRLElBQWYsRUFBcUJnSSxLQUFLTSxJQUFMLENBQVVDLFdBQS9CO0FBRUEsYUFBT3ZJLElBQVA7QUFFRCxLQXZFRDtBQUFBOztBQXZLaUMsQzs7Ozs7Ozs7Ozs7QUNIbkN4QixPQUFPNkssTUFBUCxDQUFjO0FBQUMxSyxXQUFRLE1BQUlxVDtBQUFiLENBQWQ7O0FBQWUsTUFBTUEsU0FBTixDQUFlO0FBRTVCLFNBQU9DLEtBQVAsQ0FBYXJOLENBQWIsRUFBZTtBQUViLFFBQUlZLE1BQU0sRUFBVjs7QUFFQSxRQUFHWixhQUFhNkYsS0FBaEIsRUFBc0I7QUFDcEJqRixVQUFJME0sT0FBSixHQUFjdE4sRUFBRXNOLE9BQWhCO0FBQ0ExTSxVQUFJaEYsSUFBSixHQUFXb0UsRUFBRXBFLElBQWI7QUFDQWdGLFVBQUkyTSxRQUFKLEdBQWV2TixFQUFFdU4sUUFBakI7QUFDQTNNLFVBQUk0TSxVQUFKLEdBQWlCeE4sRUFBRXdOLFVBQW5CO0FBQ0E1TSxVQUFJNk0sWUFBSixHQUFtQnpOLEVBQUV5TixZQUFyQjtBQUNBN00sVUFBSThNLEtBQUosR0FBWTFOLEVBQUUwTixLQUFkO0FBQ0QsS0FQRCxNQVFJO0FBQ0Y5TSxZQUFNWixDQUFOO0FBQ0Q7O0FBRUQsV0FBT1ksR0FBUDtBQUVEOztBQXBCMkIsQzs7Ozs7Ozs7Ozs7QUNBOUJoSCxPQUFPNkssTUFBUCxDQUFjO0FBQUM5QyxtQkFBZ0IsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJdUYsV0FBSjtBQUFnQnROLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ29OLGNBQVlsTixDQUFaLEVBQWM7QUFBQ2tOLGtCQUFZbE4sQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTs7QUFFOUQsTUFBTTJILGVBQU4sQ0FBcUI7QUFDMUIsU0FBYUksR0FBYixDQUFpQkgsSUFBakIsRUFBc0JJLFVBQXRCO0FBQUEsb0NBQWlDO0FBQy9CLFVBQUk0SCx1QkFBZTFDLFlBQVkyQyxPQUFaLENBQW9CakksS0FBS2tJLEdBQXpCLENBQWYsQ0FBSjtBQUNBLFVBQUlwSSxLQUFLa0ksT0FBT2xJLEVBQVAsQ0FBVUUsS0FBS21JLFFBQWYsQ0FBVDtBQUNBLGFBQU9ySSxHQUFHTSxVQUFILENBQWNBLFVBQWQsQ0FBUDtBQUNELEtBSkQ7QUFBQTs7QUFEMEIsQzs7Ozs7Ozs7Ozs7QUNGNUJwSSxPQUFPNkssTUFBUCxDQUFjO0FBQUMxSyxXQUFRLE1BQUl3QztBQUFiLENBQWQ7QUFBbUMsSUFBSWdKLEtBQUo7QUFBVTNMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxPQUFSLENBQWIsRUFBOEI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1TCxZQUFNdkwsQ0FBTjtBQUFROztBQUFwQixDQUE5QixFQUFvRCxDQUFwRDtBQUF1RCxJQUFJMlQsTUFBSjtBQUFXL1QsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzJULGFBQU8zVCxDQUFQO0FBQVM7O0FBQXJCLENBQS9CLEVBQXNELENBQXREOztBQUloRyxNQUFNdUMsS0FBTixDQUFZO0FBRXpCMkksY0FBWXpELE9BQVosRUFBcUI7QUFDbkI7QUFDQSxTQUFLbU0sSUFBTCxHQUFZckksTUFBTXNJLFVBQU4sQ0FBaUJwTSxPQUFqQixDQUFaLENBRm1CLENBSW5COztBQUNBLFFBQUlxTSxlQUFlO0FBQUNDLDBCQUFtQjtBQUFwQixLQUFuQjtBQUNBL0IsV0FBT0MsTUFBUCxDQUFlNkIsWUFBZixFQUE2QnJNLE9BQTdCO0FBQ0EsU0FBS3VNLFNBQUwsR0FBaUJ6SSxNQUFNc0ksVUFBTixDQUFpQkMsWUFBakIsQ0FBakI7QUFDRDs7QUFFRCxTQUFPRyxVQUFQLENBQW1CQyxJQUFuQixFQUF5QjtBQUN2QixXQUFPUCxPQUFPTyxJQUFQLEVBQWFDLE1BQWIsR0FBc0IzTixTQUF0QixDQUFnQyxDQUFoQyxFQUFrQyxFQUFsQyxFQUFzQzROLE9BQXRDLENBQThDLEdBQTlDLEVBQW1ELEdBQW5ELENBQVA7QUFDRDtBQUVEOzs7Ozs7QUFJQTdRLFFBQU1JLEdBQU4sRUFBVztBQUVUO0FBQ0E7QUFDQSxXQUFPLEtBQUswUSxNQUFMLEdBQ0pDLElBREksQ0FFRkMsR0FBRCxJQUFTO0FBQ1AsYUFBTyxJQUFJM0gsT0FBSixDQUNMLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUNuQjtBQUNBeUgsWUFBSWhSLEtBQUosQ0FBVUksR0FBVixFQUFlLENBQUNxQyxDQUFELEVBQUlZLEdBQUosS0FBWTtBQUN6QjtBQUNBMk4sY0FBSUMsT0FBSjs7QUFDQSxjQUFJeE8sQ0FBSixFQUFPO0FBQ0w4RyxtQkFBTzlHLENBQVA7QUFDRCxXQUZELE1BRU82RyxRQUFRakcsR0FBUjtBQUNSLFNBTkQ7QUFPRCxPQVZJLENBQVA7QUFZRCxLQWZFLEVBaUJKcUcsS0FqQkksQ0FpQkdqSCxDQUFELElBQU87QUFDWixZQUFNQSxDQUFOO0FBQ0QsS0FuQkksQ0FBUDtBQW9CRDs7QUFFS3lPLGNBQU4sQ0FBbUI5USxHQUFuQjtBQUFBLG9DQUF1QjtBQUNyQixVQUFJaUQsb0JBQVksS0FBS3JELEtBQUwsQ0FBV0ksR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPaUQsSUFBSThOLFFBQVg7QUFDRCxLQUhEO0FBQUE7QUFLQTs7Ozs7Ozs7QUFNTzNPLGFBQU4sQ0FBa0I0RixLQUFsQixFQUF5QnZLLE9BQU8sRUFBaEMsRUFBb0N1VCxXQUFXLEVBQS9DO0FBQUEsb0NBQWtEO0FBRWpEO0FBQ0E7QUFFQSxVQUFJaFIsTUFBTyxlQUFjZ0ksS0FBTSxHQUEvQjtBQUVBLFVBQUlxRixNQUFNLElBQUk0RCxHQUFKLEVBQVY7O0FBQ0EsV0FBSyxJQUFJeEcsQ0FBVCxJQUFjNEQsT0FBTzdELElBQVAsQ0FBWS9NLElBQVosQ0FBZCxFQUFpQztBQUUvQixZQUFJQSxLQUFLZ04sQ0FBTCxNQUFZLElBQWhCLEVBQXFCO0FBQ25CNEMsY0FBSXBELEdBQUosQ0FBUVEsQ0FBUixFQUFXLE1BQVg7QUFDRCxTQUZELE1BR0ssSUFBSWhOLEtBQUtnTixDQUFMLEVBQVFsRCxXQUFSLENBQW9CdEosSUFBcEIsS0FBNkIsTUFBakMsRUFBeUM7QUFDNUM7QUFDQW9QLGNBQUlwRCxHQUFKLENBQVFRLENBQVIsRUFBWSxJQUFHN0wsTUFBTTBSLFVBQU4sQ0FBaUI3UyxLQUFLZ04sQ0FBTCxDQUFqQixDQUEwQixHQUF6QztBQUNELFNBSEksTUFJRDtBQUNGNEMsY0FBSXBELEdBQUosQ0FBUVEsQ0FBUixFQUFZLEdBQUU3QyxNQUFNc0osTUFBTixDQUFhelQsS0FBS2dOLENBQUwsQ0FBYixDQUFzQixFQUFwQztBQUNEO0FBRUY7O0FBQ0QsV0FBSyxJQUFJQSxDQUFULElBQWM0RCxPQUFPN0QsSUFBUCxDQUFZd0csUUFBWixDQUFkLEVBQXFDO0FBQ25DM0QsWUFBSXBELEdBQUosQ0FBUVEsQ0FBUixFQUFXdUcsU0FBU3ZHLENBQVQsTUFBZ0IsSUFBaEIsR0FBdUIsTUFBdkIsR0FBZ0N1RyxTQUFTdkcsQ0FBVCxDQUEzQztBQUNEOztBQUVEekssYUFBUSxLQUFJLENBQUMsR0FBR3FOLElBQUk3QyxJQUFKLEVBQUosRUFBZ0J3RSxJQUFoQixDQUFxQixHQUFyQixDQUEwQixLQUF0QztBQUVBaFAsYUFBUSxXQUFVLENBQUMsR0FBR3FOLElBQUk4RCxNQUFKLEVBQUosRUFBa0JuQyxJQUFsQixDQUF1QixHQUF2QixDQUE0QixLQUE5QztBQUVBLFVBQUkvTCxvQkFBWSxLQUFLckQsS0FBTCxDQUFXSSxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9pRCxJQUFJOE4sUUFBWDtBQUVELEtBakNBO0FBQUE7QUFtQ0Q7Ozs7Ozs7OztBQU9NdEgsYUFBTixDQUFrQnpCLEtBQWxCLEVBQXlCM0ksTUFBekIsRUFBaUM1QixJQUFqQyxFQUF1Q3VULFFBQXZDO0FBQUEsb0NBQWdEO0FBQzlDLFVBQUloUixNQUFPLFVBQVNnSSxLQUFNLE9BQTFCO0FBRUEsVUFBSW9KLFVBQVUsRUFBZDs7QUFDQSxXQUFLLElBQUkzRyxDQUFULElBQWM0RCxPQUFPN0QsSUFBUCxDQUFZL00sSUFBWixDQUFkLEVBQWlDO0FBQy9CMlQsZ0JBQVE5SSxJQUFSLENBQWMsR0FBRW1DLENBQUUsSUFBRzdDLE1BQU1zSixNQUFOLENBQWF6VCxLQUFLZ04sQ0FBTCxDQUFiLENBQXNCLEVBQTNDO0FBQ0Q7O0FBQ0QsV0FBSyxJQUFJQSxDQUFULElBQWM0RCxPQUFPN0QsSUFBUCxDQUFZd0csUUFBWixDQUFkLEVBQXFDO0FBQ25DSSxnQkFBUTlJLElBQVIsQ0FBYyxHQUFFbUMsQ0FBRSxJQUFHdUcsU0FBU3ZHLENBQVQsQ0FBWSxFQUFqQztBQUNEOztBQUNEekssYUFBT29SLFFBQVFwQyxJQUFSLENBQWEsR0FBYixDQUFQO0FBRUFoUCxhQUFRLFVBQVNYLE1BQU8sR0FBeEI7QUFFQSxVQUFJNEQsb0JBQVksS0FBS3JELEtBQUwsQ0FBV0ksR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPaUQsR0FBUDtBQUNELEtBaEJEO0FBQUEsR0FuR3lCLENBcUh6Qjs7O0FBQ01vTyxZQUFOLENBQWlCclIsR0FBakI7QUFBQSxvQ0FBc0I7QUFDcEIsVUFBSXNSLFdBQVcsS0FBS3JCLElBQXBCO0FBQ0EsV0FBS0EsSUFBTCxHQUFZLEtBQUtJLFNBQWpCOztBQUNBLFVBQUc7QUFDRCxZQUFJcE4sb0JBQVksS0FBS3JELEtBQUwsQ0FBV0ksR0FBWCxDQUFaLENBQUo7QUFDQSxlQUFPaUQsR0FBUDtBQUNELE9BSEQsU0FJTztBQUNMLGFBQUtnTixJQUFMLEdBQVlxQixRQUFaO0FBQ0Q7QUFDRixLQVZEO0FBQUE7O0FBWU1DLGtCQUFOO0FBQUEsb0NBQXdCO0FBQ3RCLG9CQUFNLEtBQUszUixLQUFMLENBQVksb0JBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJTTRSLFFBQU47QUFBQSxvQ0FBYztBQUNaLG9CQUFNLEtBQUs1UixLQUFMLENBQVksU0FBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNNlIsVUFBTjtBQUFBLG9DQUFnQjtBQUNkLG9CQUFNLEtBQUs3UixLQUFMLENBQVksV0FBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlBcUksaUJBQWVqSSxHQUFmLEVBQW9COEgsV0FBWS9ILE1BQUQsSUFBWSxDQUFFLENBQTdDLEVBQStDZ0ksVUFBVzFGLENBQUQsSUFBTyxDQUFFLENBQWxFLEVBQW9FO0FBQ2xFLFdBQU8sS0FBS3FPLE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUkzSCxPQUFKLENBQ0wsQ0FBT0MsT0FBUCxFQUFnQkMsTUFBaEIsOEJBQTJCO0FBQ3pCO0FBQ0F5SCxZQUFJaFIsS0FBSixDQUFVSSxHQUFWLEVBQ0cwUixFQURILENBQ00sUUFETixFQUVLM1IsTUFBRCxJQUFZO0FBQ1Y2USxjQUFJZSxLQUFKO0FBQ0E3SixtQkFBUy9ILE1BQVQ7QUFDQTZRLGNBQUlnQixNQUFKO0FBQ0QsU0FOTCxFQU9HRixFQVBILENBT00sT0FQTixFQU9nQnJQLENBQUQsSUFBTztBQUNsQjBGLGtCQUFRMUYsQ0FBUjtBQUNELFNBVEgsRUFVR3FQLEVBVkgsQ0FVTSxLQVZOLEVBVWEsTUFBTTtBQUNmZCxjQUFJQyxPQUFKO0FBQ0EzSDtBQUNELFNBYkg7QUFjRCxPQWhCRCxDQURLLENBQVA7QUFvQkQsS0F2QkUsRUF5QkpJLEtBekJJLENBeUJHakgsQ0FBRCxJQUFPO0FBQ1osWUFBTUEsQ0FBTjtBQUNELEtBM0JJLENBQVA7QUE2QkQ7O0FBR0RxTyxXQUFTO0FBQ1AsV0FBTyxJQUFJekgsT0FBSixDQUNILENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUNuQjtBQUNBLFdBQUs4RyxJQUFMLENBQVU0QixhQUFWLENBQXdCLENBQUN4UCxDQUFELEVBQUl1TyxHQUFKLEtBQVk7QUFDbEMsWUFBSXZPLENBQUosRUFBTztBQUNMOEcsaUJBQU85RyxDQUFQO0FBQ0QsU0FGRCxNQUVPO0FBQ0w2RyxrQkFBUTBILEdBQVI7QUFDRDtBQUNGLE9BTkQ7QUFPRCxLQVZFLEVBWUp0SCxLQVpJLENBYUZqSCxDQUFELElBQU87QUFDTCxZQUFNQSxDQUFOO0FBQ0QsS0FmRSxDQUFQO0FBaUJEOztBQWpNd0IsQzs7Ozs7Ozs7Ozs7QUNKM0JwRyxPQUFPNkssTUFBUCxDQUFjO0FBQUMxSyxXQUFRLE1BQUl5QztBQUFiLENBQWQ7QUFBb0MsSUFBSTRRLFNBQUo7QUFBY3hULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNvVCxnQkFBVXBULENBQVY7QUFBWTs7QUFBeEIsQ0FBaEMsRUFBMEQsQ0FBMUQ7O0FBRW5DLE1BQU13QyxNQUFOLENBQWE7QUFFMUIwSSxnQkFBYztBQUNaLFNBQUt4SCxNQUFMLEdBQWMsRUFBZDtBQUNBLFNBQUs2TCxTQUFMLEdBQWlCLEVBQWpCO0FBQ0EsU0FBS2tHLFFBQUwsR0FBZ0IsSUFBaEI7QUFDRDs7QUFFREMsa0JBQWU7QUFDYixTQUFLRCxRQUFMLEdBQWdCLElBQUlFLFFBQUosRUFBaEI7QUFDQSxTQUFLcEcsU0FBTCxDQUFldEQsSUFBZixDQUFxQixLQUFLd0osUUFBMUI7QUFDRDs7QUFFS25TLE9BQU4sQ0FBWTFCLE9BQU8sRUFBbkIsRUFBdUIwTixLQUFLLCtCQUFZLENBQUUsQ0FBZCxDQUE1QjtBQUFBLG9DQUE0QztBQUUxQyxXQUFLb0csYUFBTDtBQUVBLFVBQUlFLE1BQU0sRUFBVjs7QUFFQSxVQUFJO0FBRUYsWUFBSWhQLG9CQUFZMEksSUFBWixDQUFKO0FBRUEwQyxlQUFPQyxNQUFQLENBQWMyRCxHQUFkLEVBQW1CO0FBQ2pCdEssZ0JBQU0sU0FEVztBQUVqQmhJLGlCQUFPMUIsSUFGVTtBQUdqQmlVLGtCQUFRalA7QUFIUyxTQUFuQjtBQU1ELE9BVkQsQ0FVRSxPQUFPWixDQUFQLEVBQVU7QUFFVmdNLGVBQU9DLE1BQVAsQ0FBYzJELEdBQWQsRUFBbUI7QUFDakJ0SyxnQkFBTSxPQURXO0FBRWpCaEksaUJBQU8xQixJQUZVO0FBR2pCaVUsa0JBQVF6QyxVQUFVQyxLQUFWLENBQWdCck4sQ0FBaEI7QUFIUyxTQUFuQjtBQU1ELE9BbEJELFNBa0JVO0FBRVIsWUFBSSxLQUFLeVAsUUFBTCxDQUFjSyxLQUFsQixFQUF5QjtBQUN2QjlELGlCQUFPQyxNQUFQLENBQWMyRCxHQUFkLEVBQW1CO0FBQ2pCSCxzQkFBVSxLQUFLQTtBQURFLFdBQW5CO0FBR0Q7O0FBQ0QsYUFBSy9SLE1BQUwsQ0FBWXVJLElBQVosQ0FBaUIySixHQUFqQjtBQUVEO0FBRUYsS0FuQ0Q7QUFBQTs7QUFxQ0F2TCxXQUFTMEwsU0FBVCxFQUFvQjtBQUNsQixTQUFLTixRQUFMLENBQWNPLE9BQWQsQ0FBc0JELFNBQXRCO0FBQ0Q7O0FBRUQ5UCxTQUFPOFAsU0FBUCxFQUFrQjtBQUNoQixTQUFLTixRQUFMLENBQWMxVCxLQUFkLENBQW9CcVIsVUFBVUMsS0FBVixDQUFnQjBDLFNBQWhCLENBQXBCO0FBQ0Q7O0FBRURFLGlCQUFjO0FBRVosUUFBSUMsV0FBVyxLQUFLM0csU0FBTCxDQUFldEgsSUFBZixDQUFvQmpDLEtBQUdBLEVBQUVpUSxZQUFGLEVBQXZCLENBQWY7QUFDQSxRQUFJRSxXQUFXLEtBQWY7O0FBQ0EsU0FBSyxJQUFJUCxHQUFULElBQWdCLEtBQUtsUyxNQUFyQixFQUE2QjtBQUMzQixVQUFJa1MsSUFBSXRLLElBQUosS0FBYSxPQUFqQixFQUF5QjtBQUN2QjZLLG1CQUFXLElBQVg7QUFDQTtBQUNEO0FBQ0Y7O0FBQ0QsV0FBT0QsWUFBWUMsUUFBbkI7QUFDRDs7QUFFRDNPLFlBQVU7QUFDUixRQUFHLEtBQUt5TyxZQUFMLEVBQUgsRUFBdUI7QUFDckIsWUFBTSxJQUFJclYsT0FBT2lMLEtBQVgsQ0FBaUIsS0FBS25JLE1BQXRCLENBQU47QUFDRDs7QUFDRCxXQUFPLEtBQUtBLE1BQVo7QUFDRDs7QUE1RXlCOztBQWlGNUIsTUFBTWlTLFFBQU4sQ0FBZTtBQUViekssZ0JBQWM7QUFDWixTQUFLNEssS0FBTCxHQUFZLENBQVo7QUFDQSxTQUFLTSxLQUFMLEdBQWE7QUFDWEosZUFBUztBQUNQRixlQUFPLENBREE7QUFFUE8saUJBQVM7QUFGRixPQURFO0FBS1h0VSxhQUFPO0FBQ0wrVCxlQUFPLENBREY7QUFFTE8saUJBQVM7QUFGSjtBQUxJLEtBQWI7QUFVRDs7QUFFREwsVUFBUUQsU0FBUixFQUFtQjtBQUNqQixRQUFHQSxTQUFILEVBQWE7QUFDWCxXQUFLSyxLQUFMLENBQVdKLE9BQVgsQ0FBbUJLLE9BQW5CLENBQTJCcEssSUFBM0IsQ0FBZ0M4SixTQUFoQztBQUNEOztBQUNELFNBQUtLLEtBQUwsQ0FBV0osT0FBWCxDQUFtQkYsS0FBbkI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBQ0QvVCxRQUFNZ1UsU0FBTixFQUFpQjtBQUVmO0FBQ0EsUUFBSU8sWUFBWSxJQUFoQjtBQUNBLFFBQUl0SixRQUFRLEtBQUtvSixLQUFMLENBQVdyVSxLQUFYLENBQWlCc1UsT0FBakIsQ0FBeUJ0SSxNQUFyQzs7QUFDQSxRQUFHZixLQUFILEVBQVM7QUFDUHNKLGtCQUFZLEtBQUtGLEtBQUwsQ0FBV3JVLEtBQVgsQ0FBaUJzVSxPQUFqQixDQUF5QnJKLFFBQU0sQ0FBL0IsQ0FBWjtBQUNELEtBUGMsQ0FTZjs7O0FBQ0EsUUFBSTdLLEtBQUtDLFNBQUwsQ0FBZWtVLFNBQWYsTUFBOEJuVSxLQUFLQyxTQUFMLENBQWUyVCxTQUFmLENBQWxDLEVBQ0EsSUFBSUEsYUFBYUEsY0FBYyxFQUEzQixJQUFpQ0EsY0FBYSxFQUFsRCxFQUFzRDtBQUNwRCxXQUFLSyxLQUFMLENBQVdyVSxLQUFYLENBQWlCc1UsT0FBakIsQ0FBeUJwSyxJQUF6QixDQUE4QjhKLFNBQTlCO0FBQ0Q7QUFDRCxTQUFLSyxLQUFMLENBQVdyVSxLQUFYLENBQWlCK1QsS0FBakI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBRURHLGlCQUFjO0FBQ1osV0FBTyxLQUFLRyxLQUFMLENBQVdyVSxLQUFYLENBQWlCK1QsS0FBeEI7QUFDRDs7QUEzQ1ksQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCAocmVxLCByZXMsIG5leHQpID0+IHtcclxuLy8gICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbi8vICAgcmVzLmVuZChgSGVsbG8gd29ybGQgZnJvbTogJHtNZXRlb3IucmVsZWFzZX1gKTtcclxuLy8gfSk7XHJcblxyXG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xyXG5pbXBvcnQgdW5pcWlkIGZyb20gJ3VuaXFpZCc7XHJcblxyXG4vLyBSZXF1aXJlcyBtdWx0aXBhcnR5IFxyXG5pbXBvcnQgbXVsdGlwYXJ0eSBmcm9tICdjb25uZWN0LW11bHRpcGFydHknO1xyXG5pbXBvcnQge1xyXG4gIFVwbG9hZHNcclxufSBmcm9tICcuLi8uLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcyc7XHJcbmxldCBtdWx0aXBhcnR5TWlkZGxld2FyZSA9IG11bHRpcGFydHkoKTtcclxuXHJcbmNvbnN0IHJvdXRlID0gJy91cGxvYWQvaW1hZ2UnO1xyXG5cclxuLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCBmdWMudXBsb2FkRmlsZSApO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgbXVsdGlwYXJ0eU1pZGRsZXdhcmUpO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgKHJlcSwgcmVzcCkgPT4ge1xyXG4gIC8vIGRvbid0IGZvcmdldCB0byBkZWxldGUgYWxsIHJlcS5maWxlcyB3aGVuIGRvbmVcclxuXHJcbiAgY29uc3QgcmVhZGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy5yZWFkRmlsZSk7XHJcbiAgY29uc3Qgd3JpdGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy53cml0ZUZpbGUpO1xyXG4gIGNvbnN0IHVwbG9hZElkID0gdW5pcWlkKCk7XHJcblxyXG4gIGZvciAobGV0IGZpbGUgb2YgcmVxLmZpbGVzLmZpbGUpIHtcclxuICAgIGNvbnN0IGRhdGEgPSByZWFkZXIoZmlsZS5wYXRoKTtcclxuICAgIC8vIOODleOCoeOCpOODq+WQjeOBrumHjeikh+OCkumBv+OBkeOCi+OBn+OCgeOAgeS4gOaEj+OBruODleOCoeOCpOODq+WQjeOCkuS9nOaIkOOBmeOCi1xyXG4gICAgLy8g5qW95aSp44Gu44OV44Kh44Kk44Or5ZCN5paH5a2X5pWw5Yi26ZmQMjDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBmaWxlbmFtZSA9IGAke3VuaXFpZCgpfS5qcGdgXHJcblxyXG4gICAgLy8gc2V0IHRoZSBjb3JyZWN0IHBhdGggZm9yIHRoZSBmaWxlIG5vdCB0aGUgdGVtcG9yYXJ5IG9uZSBmcm9tIHRoZSBBUEk6XHJcbiAgICBsZXQgc2F2ZVBhdGggPSByZXEuYm9keS5pbWFnZWRpciArICcvJyArIGZpbGVuYW1lO1xyXG5cclxuICAgIC8vIGNvcHkgdGhlIGRhdGEgZnJvbSB0aGUgcmVxLmZpbGVzLmZpbGUucGF0aCBhbmQgcGFzdGUgaXQgdG8gZmlsZS5wYXRoXHJcblxyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ57WQ5p6c44KS6KiY6Yyy44GZ44KLXHJcbiAgICBsZXQgZG9jID0ge1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICAgIGNsaWVudEZpbGVOYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgIHVwbG9hZGVkRmlsZU5hbWU6IGZpbGVuYW1lXHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICB0cnl7XHJcbiAgICAgIHdyaXRlcihzYXZlUGF0aCwgZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaChlcnIpe1xyXG4gICAgICBkb2MuZXJyb3IgPSBlcnI7XHJcbiAgICB9XHJcbiAgICBVcGxvYWRzLmluc2VydChkb2MpO1xyXG5cclxuICAgIGRlbGV0ZSBmaWxlO1xyXG5cclxuICB9O1xyXG4gIHJlc3Aud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgc2F2ZURpcjogcmVxLmJvZHkuaW1hZ2VkaXJcclxuICB9KSk7XHJcblxyXG59KTsiLCJpbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0byc7XHJcblxyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJztcclxuaW1wb3J0IFJlcG9ydCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvcmVwb3J0JztcclxuaW1wb3J0IHtcclxuICBHcm91cCxcclxuICBHcm91cEZhY3RvcnlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzJztcclxuaW1wb3J0IHtcclxuICBGaWx0ZXJcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycyc7XHJcblxyXG5sZXQgdGFnID0gJ2N1YmVtaWcnO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5taWdyYXRlYF0oY29uZmlnKSB7XHJcblxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKTtcclxuXHJcbiAgICAvLyBzZXR1cCBncm91cFxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IEZpbHRlcihjb25maWcuc3JjRmlsdGVySWQpO1xyXG4gICAgLy8gbGV0IHBsdWcgPSBncm91cC5nZXRQbHVnKCk7XHJcblxyXG4gICAgLy8gY2hlY2tpbmcgY29ubmVjdGlvblxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgdGVzdFF1ZXJ5ID0gJ1NIT1cgREFUQUJBU0VTJztcclxuXHJcbiAgICBsZXQgZHN0RGIgPSBuZXcgTXlTUUwoY29uZmlnLmRzdC5jcmVkKTtcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ0Nvbm5lY3QgdG8gRGVzdGluYXRpb24nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgYXdhaXQgZHN0RGIucXVlcnkodGVzdFF1ZXJ5KTtcclxuICAgICAgfSk7XHJcblxyXG5cclxuICAgIC8vIHByb2Nlc3MgZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAgLy9cclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ1NlbGVjdCBsb29wIGluIHNvdXJjZScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgICBtb2JpbGVOdWxsOiBhc3luYyAocmVjb3JkKSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgIC8vIC8vIOWApOOCkuaVtOeQhlxyXG4gICAgICAgICAgICAgIC8vIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgICAgLy8gICBpZiAocmVjb3JkW2tleV0gPT09IG51bGwpO1xyXG4gICAgICAgICAgICAgIC8vICAgZWxzZSBpZiAocmVjb3JkW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgICAgICAgLy8gICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IE15U1FMLmZvcm1hdERhdGUocmVjb3JkW2tleV0pO1xyXG4gICAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IGBcIiR7cmVjb3JkW2tleV19XCJgO1xyXG4gICAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyIOOBq+S/neWtmFxyXG5cclxuICAgICAgICAgICAgICBsZXQgc3FsID0gYFxyXG5cclxuICAgICAgICAgICAgICAgIElOU0VSVCBkdGJfY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICggXFxgY3VzdG9tZXJfaWRcXGAsIFxcYHN0YXR1c1xcYCwgXFxgc2V4XFxgLCBcXGBqb2JcXGAsIFxcYGNvdW50cnlfaWRcXGAsIFxcYHByZWZcXGAsIFxcYG5hbWUwMVxcYCwgXFxgbmFtZTAyXFxgLCBcXGBrYW5hMDFcXGAsIFxcYGthbmEwMlxcYCwgXFxgY29tcGFueV9uYW1lXFxgLCBcXGB6aXAwMVxcYCwgXFxgemlwMDJcXGAsIFxcYHppcGNvZGVcXGAsIFxcYGFkZHIwMVxcYCwgXFxgYWRkcjAyXFxgLCBcXGBlbWFpbFxcYCwgXFxgdGVsMDFcXGAsIFxcYHRlbDAyXFxgLCBcXGB0ZWwwM1xcYCwgXFxgZmF4MDFcXGAsIFxcYGZheDAyXFxgLCBcXGBmYXgwM1xcYCwgXFxgYmlydGhcXGAsIFxcYHBhc3N3b3JkXFxgLCBcXGBzYWx0XFxgLCBcXGBzZWNyZXRfa2V5XFxgLCBcXGBmaXJzdF9idXlfZGF0ZVxcYCwgXFxgbGFzdF9idXlfZGF0ZVxcYCwgXFxgYnV5X3RpbWVzXFxgLCBcXGBidXlfdG90YWxcXGAsIFxcYG5vdGVcXGAsIFxcYGNyZWF0ZV9kYXRlXFxgLCBcXGB1cGRhdGVfZGF0ZVxcYCwgXFxgZGVsX2ZsZ1xcYCApXHJcblxyXG4gICAgICAgICAgICAgICAgVkFMVUVTKCAkeyByZWNvcmQuY3VzdG9tZXJfaWQgfSAsICR7IHJlY29yZC5zdGF0dXMgfSAsICR7IHJlY29yZC5zZXggfSAsICR7IHJlY29yZC5qb2IgfSAsICR7IHJlY29yZC5jb3VudHJ5X2lkIH0gLCAkeyByZWNvcmQucHJlZiB9ICwgJHsgcmVjb3JkLm5hbWUwMSB9ICwgJHsgcmVjb3JkLm5hbWUwMiB9ICwgJHsgcmVjb3JkLmthbmEwMSB9ICwgJHsgcmVjb3JkLmthbmEwMiB9ICwgJHsgcmVjb3JkLmNvbXBhbnlfbmFtZSB9ICwgJHsgcmVjb3JkLnppcDAxIH0gLCAkeyByZWNvcmQuemlwMDIgfSAsICR7IHJlY29yZC56aXBjb2RlIH0gLCAkeyByZWNvcmQuYWRkcjAxIH0gLCAkeyByZWNvcmQuYWRkcjAyIH0gLCAkeyByZWNvcmQuZW1haWwgfSAsICR7IHJlY29yZC50ZWwwMSB9ICwgJHsgcmVjb3JkLnRlbDAyIH0gLCAkeyByZWNvcmQudGVsMDMgfSAsICR7IHJlY29yZC5mYXgwMSB9ICwgJHsgcmVjb3JkLmZheDAyIH0gLCAkeyByZWNvcmQuZmF4MDMgfSAsICR7IHJlY29yZC5iaXJ0aCB9ICwgJHsgcmVjb3JkLnBhc3N3b3JkIH0gLCAkeyByZWNvcmQuc2FsdCB9ICwgJHsgcmVjb3JkLnNlY3JldF9rZXkgfSAsICR7IHJlY29yZC5maXJzdF9idXlfZGF0ZSB9ICwgJHsgcmVjb3JkLmxhc3RfYnV5X2RhdGUgfSAsICR7IHJlY29yZC5idXlfdGltZXMgfSAsICR7IHJlY29yZC5idXlfdG90YWwgfSAsICR7IHJlY29yZC5ub3RlIH0gLCAkeyByZWNvcmQuY3JlYXRlX2RhdGUgfSAsICR7IHJlY29yZC51cGRhdGVfZGF0ZSB9ICwgJHsgcmVjb3JkLmRlbF9mbGcgfSApXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGA7XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcicsXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVjb3JkLnN0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgICBzZXg6IHJlY29yZC5zZXgsXHJcbiAgICAgICAgICAgICAgICAgICAgam9iOiByZWNvcmQuam9iLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgZW1haWw6IHJlY29yZC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgICBiaXJ0aDogcmVjb3JkLmJpcnRoLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiByZWNvcmQucGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICAgICAgc2FsdDogcmVjb3JkLnNhbHQsXHJcbiAgICAgICAgICAgICAgICAgICAgc2VjcmV0X2tleTogcmVjb3JkLnNlY3JldF9rZXksXHJcbiAgICAgICAgICAgICAgICAgICAgZmlyc3RfYnV5X2RhdGU6IHJlY29yZC5maXJzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBsYXN0X2J1eV9kYXRlOiByZWNvcmQubGFzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBidXlfdGltZXM6IHJlY29yZC5idXlfdGltZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgYnV5X3RvdGFsOiByZWNvcmQuYnV5X3RvdGFsLFxyXG4gICAgICAgICAgICAgICAgICAgIG5vdGU6IHJlY29yZC5ub3RlLFxyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXJfYWRkcmVzc1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcl9hZGRyZXNzJywge1xyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2FkZHJlc3NfaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIC8vIOODoeODq+ODnuOCrOODl+ODqeOCsOOCpOODsyBwbGdfbWFpbG1hZ2FfY3VzdG9tZXJcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAgICdwbGdfbWFpbG1hZ2FfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgICBtYWlsbWFnYV9mbGc6IHJlY29yZC5tYWlsbWFnYV9mbGcsXHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgLy8g44Kv44O844Od44Oz55m66KGM77yIRUNDVUJFMuOBruODneOCpOODs+ODiOmChOWFg++8iVxyXG5cclxuICAgICAgICAgICAgICBsZXQgY291cG9uX2NkID0gY3J5cHRvLnJhbmRvbUJ5dGVzKDgpLnRvU3RyaW5nKCdiYXNlNjQnKS5zdWJzdHJpbmcoMCwxMSk7XHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb3Vwb25fbmFtZSA9IGAke3JlY29yZC5uYW1lMDF9ICR7cmVjb3JkLm5hbWUwMn0g5qeYIOOBlOWEquW+heOCr+ODvOODneODsyDkvJrlk6Hnlarlj7c6JHtyZWNvcmQuY3VzdG9tZXJfaWR9YDtcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGRpc2NvdW50X3ByaWNlID0gcmVjb3JkLnBvaW50ICsgNTAwO1xyXG5cclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgICAncGxnX2NvdXBvbicsIHtcclxuICAgICAgICAgICAgICAgICAgICBjb3Vwb25faWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgY291cG9uX2NkOiBjb3Vwb25fY2QsXHJcbiAgICAgICAgICAgICAgICAgICAgY291cG9uX3R5cGU6IDMsIC8vIOWFqOWVhuWTgVxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl9uYW1lOiBjb3Vwb25fbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBkaXNjb3VudF90eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl91c2VfdGltZTogMSxcclxuICAgICAgICAgICAgICAgICAgICBjb3Vwb25fcmVsZWFzZTogMSxcclxuICAgICAgICAgICAgICAgICAgICBkaXNjb3VudF9wcmljZTogZGlzY291bnRfcHJpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzY291bnRfcmF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBlbmFibGVfZmxhZzogMSxcclxuICAgICAgICAgICAgICAgICAgICBjb3Vwb25fbWVtYmVyOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl9sb3dlcl9saW1pdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBhdmFpbGFibGVfZnJvbV9kYXRlOiAnMjAxOC0wNC0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX3RvX2RhdGU6ICcyMDE5LTA1LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgICBkZWxfZmxnOiAwXHJcbiAgICAgICAgICAgICAgICAgIH0se1xyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgJ2N1YmVtaWcuc2VydmVyQ2hlY2snIChwcm9maWxlKSB7XHJcblxyXG4gICAgbGV0IGRiID0gbmV3IE15U1FMKHByb2ZpbGUpO1xyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGRiLnF1ZXJ5KCdTSE9XIERBVEFCQVNFUycpO1xyXG4gICAgcmV0dXJuIHJlcztcclxuICB9XHJcblxyXG59KTsiLCJpbXBvcnQgeyBNb25nb0NvbGxlY3Rpb24gfSBmcm9tIFwiLi4vLi4vaW1wb3J0cy91dGlsL21vbmdvXCI7XHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLmNvbGxlY3Rpb24nO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5maW5kYF0oIHBsdWcsIHF1ZXJ5PXt9LCBwcm9qZWN0aW9uPXt9ICkge1xyXG5cclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pO1xyXG4gICAgcmV0dXJuIGF3YWl0IGNvbGwuZmluZChxdWVyeSx7cHJvamVjdGlvbjpwcm9qZWN0aW9ufSkudG9BcnJheSgpO1xyXG5cclxuICB9LFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5hZ2dyZWdhdGVgXSggcGx1ZywgcXVlcnk9e30gKSB7XHJcblxyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbik7XHJcbiAgICByZXR1cm4gYXdhaXQgY29sbC5hZ2dyZWdhdGUocXVlcnkpLnRvQXJyYXkoKTtcclxuXHJcbiAgfVxyXG5cclxufSk7IiwiaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gXCIuLi8uLi9pbXBvcnRzL2NvcmUvaXRlbXNcIjtcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuaXRlbXMnO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvKipcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+OCs+ODrOOCr+OCt+ODp+ODs+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOBvuOBmeOAglxyXG4gICAqIEBwYXJhbSAgXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uc2V0SW1hZ2VgXSggcGx1ZywgdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsICkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKTtcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKTtcclxuICAgIGxldCB1cGxvYWRlZCA9IGF3YWl0IGl0ZW1jb24uc2V0SW1hZ2UoIHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxLCBjbGFzczIgKTtcclxuICAgIHJldHVybiB1cGxvYWRlZDtcclxuICB9LFxyXG5cclxuICAvKipcclxuICAgKiDjgqLjgqTjg4bjg6Dmg4XloLHjg4fjg7zjgr/jg5njg7zjgrnjga7nlLvlg4/nmbvpjLLjgpLliYrpmaTjgZnjgovvvIjnlLvlg4/oh6rkvZPjga/liYrpmaTjgZfjgarjgYTvvIlcclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5jbGVhbkltYWdlYF0oIHBsdWcsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsICkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKTtcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKTtcclxuICAgIGF3YWl0IGl0ZW1jb24uY2xlYW5JbWFnZSggbW9kZWwsIGNsYXNzMSwgY2xhc3MyICk7XHJcbiAgfVxyXG5cclxufSk7IiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0JztcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9jb3JlL2RiZmlsdGVyJztcclxuaW1wb3J0IHtcclxuICBDdWJlM0FwaVxyXG59IGZyb20gJy4uL2ltcG9ydHMvY29yZS9jdWJlM2FwaSc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9jb3JlL2l0ZW1zJztcclxuXHJcbmxldCB0YWcgPSAnY3ViZSc7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5Zyo5bqr5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZVN0b2NrYF0oY29uZmlnKSB7XHJcblxyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpO1xyXG4gICAgbGV0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKCk7XHJcbiAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKTtcclxuXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpO1xyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQik7XHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn5Zyo5bqr44Gu5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnVVBEQVRFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuXHJcbiAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKCBpdGVtLl9pZCApO1xyXG4gICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSApO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKTtcclxuXHJcbiAgfSxcclxuXHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliSXRlbWBdKGNvbmZpZykge1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpO1xyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKTtcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpO1xyXG5cclxuICAgIGxldCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdCggY29uZmlnLml0ZW1zREIgKTtcclxuXHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnRUNDVUJFM+OBuOOBruWVhuWTgeeZu+mMsicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgICAnSU5TRVJUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvbjtcclxuXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKTtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgaW5zZXJ0UmVzID0gYXdhaXQgYXBpLnByb2R1Y3RDcmVhdGUoY3ViZUl0ZW0pO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIGl0ZW0g44OH44O844K/44OZ44O844K544G444Gu55m76YyyXHJcbiAgICAgICAgICAgICAgICBhd2FpdCBjb2wudXBkYXRlKHtcclxuICAgICAgICAgICAgICAgICAgX2lkOiBpdGVtLl9pZFxyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AnOiBpbnNlcnRSZXMucmVzXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xyXG5cclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0VDQ1VCRTPllYblk4Hmg4XloLHjga7mm7TmlrAnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb247XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuY29udmVydEl0ZW1DdWJlMyhjb25maWcuY3JlYXRvcl9pZCwgaXRlbSk7XHJcblxyXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RJbWFnZVVwZGF0ZShjdWJlSXRlbSk7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFVwZGF0ZShjdWJlSXRlbSk7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdFRhZ1VwZGF0ZShjdWJlSXRlbSk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKCk7XHJcblxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XHJcblxyXG4gIH1cclxuXHJcbn0pOyIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCc7XHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvY29yZS9kYmZpbHRlcic7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnO1xyXG5cclxubGV0IHRhZyA9ICd0b29sJztcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udGVzdGBdKGNvbmZpZykge1xyXG5cclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKTtcclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKTtcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg5XjgqPjg6vjgr/jg7zjg4bjgrnjg4gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZpbHRlci5mb3JlYWNoKFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgICB9KTtcclxuICAgICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XHJcblxyXG4gIH1cclxuXHJcbn0pOyIsImltcG9ydCAnLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MnO1xyXG5cclxuaW1wb3J0ICcuL3JvdXRlL3VwbG9hZC9pbWFnZSc7IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG4gXHJcbmV4cG9ydCBjb25zdCBDb25maWdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NvbmZpZ3MnLHtpZEdlbmVyYXRpb246J01PTkdPJ30pO1xyXG5cclxuLy8gTWV0ZW9yLm1ldGhvZHMoeyBcclxuLy8gICBhc3luYyAnbXlzcWxTZXJ2ZXJzLmluc2VydCcgKCBuZXdTZXJ2ZXIgKXtcclxuLy8gICAgIHJldHVybiBhd2FpdCBNeXNxbFNlcnZlcnMuaW5zZXJ0KG5ld1NlcnZlcik7XHJcbi8vICAgfVxyXG4vLyB9KTtcclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXHJcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnO1xyXG5pbXBvcnQgbW9iamVjdCBmcm9tICdtb25nb29iamVjdCc7XHJcbmltcG9ydCB7IEdyb3VwQmFzZSB9IGZyb20gJy4vZ3JvdXBzJztcclxuXHJcbmNvbnN0IEZpbHRlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZmlsdGVycycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgRmlsdGVyIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZmlsdGVySWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEZpbHRlcnMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZmlsdGVySWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuXHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoIG9uUmVzdWx0ID0gKHJlY29yZCk9Pnt9LCBvbkVycm9yID0gKGUpPT57fSApID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbGF0Zm9ybSB0eXBlJyk7XHJcblxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHt7IGZpbHRlclR5cGU6IGFzeW5jIChyZWNvcmQgKSA9PiB7fSB9fSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGFzeW5jIGZvcmVhY2goY2FsbGJhY2tzID0ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZSgpO1xyXG5cclxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXHJcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XHJcbiAgICAgIHR5cGU6ICdtaXNjJyxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBjb3VudCA9IHt9O1xyXG4gICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICBjb3VudFtmaWx0ZXIudHlwZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGZpbHRlci5xdWVyeSxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkKT0+e1xyXG4gICAgICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgICAgIGxldCBxdWVyeSA9IG1vYmplY3QudW5lc2NhcGUoZmlsdGVyLnF1ZXJ5KTtcclxuICAgICAgICAgIGxldCBleGFtID0gc2lmdCggcXVlcnkgKTtcclxuICAgICAgICAgIGlmKCBleGFtKHJlY29yZCkgKXtcclxuICAgICAgICAgICAgY291bnRbZmlsdGVyLnR5cGVdLmNvdW50Kys7XHJcbiAgICAgICAgICAgIGlmKCB0eXBlb2YgY2FsbGJhY2tzW2ZpbHRlci50eXBlXSAhPT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0ocmVjb3JkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIG9uRXJyb3JcclxuICAgICk7XHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudDtcclxuXHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuY29uc3QgR3JvdXBzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2dyb3VwcycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXBCYXNlIHtcclxuXHJcbiAgcHJvZmlsZTtcclxuXHJcbiAgY29uc3RydWN0b3IocHJvZmlsZSkge1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGdldHMgJ1BsdWcnIHdpdGNoIGlzIGEgc2V0IG9mIHByb3BlcnRpZXMgbmVlZGVkXHJcbiAgICogd2hlbiBjb25uZWN0IHRvIHNvbWUgcGxhdGZvcm1zXHJcbiAgICogdG8gZ2V0IGRhdGFzKE1lbWJlcnMgb2YgdGhlIEdyb3VwKVxyXG4gICAqL1xyXG4gIGdldFBsdWcoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlLnBsYXRmb3JtUGx1ZztcclxuICB9XHJcblxyXG4gIGdldFByb2ZpbGUoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7fTtcclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cCBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGdyb3VwSWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEdyb3Vwcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBncm91cElkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoZG9jKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfSBXSEVSRSBcXGAke2RvYy5rZXl9XFxgID0gXCIke2RvYy5pZH1cImA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIGdyb3VwIHR5cGUnKTtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHthc3luYyAocmVjb3JkKT0+dm9pZH0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgY3VyID0gR3JvdXBzLmZpbmQoe1xyXG4gICAgICBncm91cElkOiB0aGlzLnByb2ZpbGUuX2lkXHJcbiAgICB9LCB7XHJcbiAgICAgIGZpZWxkczoge1xyXG4gICAgICAgIF9pZDogMCxcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICBrZXk6IDFcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY3VyLmZvckVhY2goXHJcbiAgICAgICAgICBhc3luYyAoZG9jLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZWNvcmQgPSBhd2FpdCB0aGlzLmltcG9ydChkb2MpO1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBvbkVycm9yKGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpbmRleCArIDEgPT09IGN1ci5jb3VudCgpKSB7XHJcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgIH1cclxuICAgICkuY2F0Y2goXHJcbiAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgfVxyXG5cclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuIFxyXG5leHBvcnQgY29uc3QgVXBsb2FkcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1cGxvYWRzJyx7aWRHZW5lcmF0aW9uOidNT05HTyd9KTtcclxuXHJcbiIsImltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvQ2xpZW50XHJcbn0gZnJvbSAnbW9uZ29kYic7XHJcblxyXG5leHBvcnQgY2xhc3MgQ3ViZTNBcGkge1xyXG5cclxuICBjb25zdHJ1Y3RvcihteXNxbCA9IG5ldyBNeVNRTCgpKSB7XHJcbiAgICB0aGlzLm15c3FsXyA9IG15c3FsO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgdXBkYXRlU3RvY2soIHByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5ID0gMCApe1xyXG5cclxuICAgIHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdF9jbGFzc19pZH1gLFxyXG4gICAgICB7fSx7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdF9jbGFzc19pZH1gLFxyXG4gICAgICB7fSx7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gIH1cclxuXHJcblxyXG4gIGFzeW5jIHByb2R1Y3RUYWdVcGRhdGUoZGF0YSkge1xyXG5cclxuICAgIGxldCBjcmVhdG9yX2lkID0gZGF0YS5jcmVhdG9yX2lkO1xyXG4gICAgXHJcbiAgICBsZXQgcmVzID0gW107XHJcblxyXG4gICAgbGV0IHRhZ29uID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICByZXMucHVzaChcclxuICAgICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAgICdkdGJfcHJvZHVjdF90YWcnLFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGRhdGEucHJvZHVjdF9pZCxcclxuICAgICAgICAgICAgdGFnOiB0YWcsXHJcbiAgICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JfaWRcclxuICAgICAgICAgIH1cclxuICAgICAgICApKTt9O1xyXG5cclxuICAgIGxldCB0YWdvZmYgPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGA7XHJcbiAgICAgIHJlcy5wdXNoKCBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpICk7XHJcbiAgICB9O1xyXG5cclxuICAgIGZvciAobGV0IHRhZ1NldCBvZiBkYXRhLnRhZ3MpIHtcclxuICAgICAgc3dpdGNoICh0YWdTZXQuc2V0KSB7XHJcbiAgICAgICAgY2FzZSAnb24nOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb24odGFnU2V0LnRhZyk7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlICdvZmYnOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb2ZmKHRhZ1NldC50YWcpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfTtcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0SW1hZ2VVcGRhdGUoZGF0YSkge1xyXG5cclxuICAgIGxldCBwcm9kdWN0X2lkID0gZGF0YS5wcm9kdWN0X2lkO1xyXG4gICAgbGV0IGltYWdlcyA9IGRhdGEuaW1hZ2VzO1xyXG4gICAgbGV0IGNyZWF0b3JfaWQgPSBkYXRhLmNyZWF0b3JfaWQ7XHJcblxyXG4gICAgbGV0IHJlcyA9IFtdO1xyXG5cclxuICAgIC8vIOWVhuWTgeOBq+mWoumAo+OBmeOCi+OBmeOBueOBpuOBrueUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi1xyXG4gICAgbGV0IHNxbCA9IGBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF9pbWFnZSBXSEVSRSBwcm9kdWN0X2lkID0gJHtwcm9kdWN0X2lkfWA7XHJcbiAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpKTtcclxuXHJcbiAgICAvLyDmlLnjgoHjgabnlLvlg4/jgpLnmbvpjLLjgZfjgarjgYrjgZlcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcblxyXG4gICAgICB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAnZHRiX3Byb2R1Y3RfaW1hZ2UnLCB7XHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0X2lkLFxyXG4gICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcl9pZCxcclxuICAgICAgICAgIGZpbGVfbmFtZTogaW1hZ2VzW2ldLFxyXG4gICAgICAgICAgcmFuazogaSArIDFcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfTtcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VXBkYXRlKGRhdGEpIHtcclxuXHJcbiAgICBsZXQgdXBkYXRlX2RhdGEgPSB7fTtcclxuICAgIGxldCBrZXlzID0gW107XHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RcclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnc3RhdHVzJyxcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnbm90ZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9saXN0JyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXHJcbiAgICAgICdzZWFyY2hfd29yZCcsXHJcbiAgICAgICdmcmVlX2FyZWEnXHJcbiAgICBdO1xyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVfZGF0YVtrXSA9IGRhdGFba107XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlX2RhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0X2NsYXNzXHJcblxyXG4gICAgdXBkYXRlX2RhdGEgPSB7fTtcclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdkZWxpdmVyeV9kYXRlX2lkJyxcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdzYWxlX2xpbWl0JyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdO1xyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVfZGF0YVtrXSA9IGRhdGFba107XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHJlcyA9IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZV9kYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfTtcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0Q3JlYXRlKGRhdGEpIHtcclxuXHJcbiAgICBsZXQgY3JlYXRvcl9pZCA9IGRhdGEuY3JlYXRvcl9pZDtcclxuXHJcbiAgICBsZXQgcmVzID0ge307XHJcblxyXG4gICAgbGV0IHVwZGF0ZV9kYXRhID0ge307XHJcbiAgICBsZXQga2V5cyA9IFtdO1xyXG5cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCdcclxuICAgIF07XHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgIC8vICAgZGVzY3JpcHRpb25fZGV0YWlsOiBpdGVtLmRlc2NyaXB0aW9uLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZV9kYXRhW2tdID0gZGF0YVtrXTtcclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICB1cGRhdGVfZGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JfaWQsXHJcbiAgICAgICAgc3RhdHVzOiAxLFxyXG4gICAgICAgIG5vdGU6ICdOVUxMJyxcclxuICAgICAgICBkZXNjcmlwdGlvbl9saXN0OiAnTlVMTCcsXHJcbiAgICAgICAgc2VhcmNoX3dvcmQ6ICdOVUxMJyxcclxuICAgICAgICBmcmVlX2FyZWE6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuXHJcbiAgICB1cGRhdGVfZGF0YSA9IHt9O1xyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdwcm9kdWN0X3R5cGVfaWQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJyxcclxuICAgICAgJ2RlbGl2ZXJ5X2ZlZSdcclxuICAgIF07XHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIHByb2R1Y3RfY29kZTogaXRlbS5tb2RlbCxcclxuICAgIC8vICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAvLyAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlX2RhdGFba10gPSBkYXRhW2tdO1xyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2NsYXNzX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIHVwZGF0ZV9kYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcl9pZCxcclxuICAgICAgICBwcm9kdWN0X2lkOiByZXMucHJvZHVjdF9pZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQxOiAnTlVMTCcsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQyOiAnTlVMTCcsXHJcbiAgICAgICAgZGVsaXZlcnlfZGF0ZV9pZDogJ05VTEwnLFxyXG4gICAgICAgIHNhbGVfbGltaXQ6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlX2RhdGFba10gPSBkYXRhW2tdO1xyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X3N0b2NrX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsIHt9LCB7XHJcbiAgICAgICAgcHJvZHVjdF9jbGFzc19pZDogcmVzLnByb2R1Y3RfY2xhc3NfaWQsXHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcl9pZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIC8vIGZvciB0ZXN0XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfTtcclxuXHJcbiAgfVxyXG5cclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSBcIm1ldGVvci9tb25nb1wiO1xyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tIFwibWV0ZW9yL21ldGVvclwiO1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSBcInNpZnRcIjtcclxuaW1wb3J0IG1vYmplY3QgZnJvbSBcIm1vbmdvb2JqZWN0XCI7XHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXJGYWN0b3J5IHtcclxuICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBsZXQgaW5zdGFuY2U7XHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlIFwibXlzcWxcIjpcclxuICAgICAgICBpbnN0YW5jZSA9IG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpO1xyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBpbnN0YW5jZTtcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlciB7XHJcbiAgLy8gREIg44GL44KJ44OH44O844K/44KS5Y+W5b6X44GZ44KL44OX44Ot44K744K5XHJcbiAgaW1wb3J0O1xyXG5cclxuICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnO1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZTtcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmYWN0b3J5KHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIGxldCBpbnN0YW5jZTtcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgXCJteXNxbFwiOlxyXG4gICAgICAgIHJldHVybiBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKTtcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoXCJpbnZhbGlkIHBsdWcgdHlwZVwiKTtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldFBsdWdfKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1ZztcclxuICB9XHJcblxyXG4gIGdldENyZWRfKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Zy5jcmVkO1xyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZV8oKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgc2V0SW1wb3J0RnVuY3Rpb25fKFxyXG4gICAgZm4gPSBhc3luYyAob25SZXN1bHQgPSByZWNvcmQgPT4ge30sIG9uRXJyb3IgPSBlID0+IHt9KSA9PiB7fVxyXG4gICkge1xyXG4gICAgdGhpcy5pbXBvcnQgPSBmbjtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIHVzZWFnZTpcclxuICAgKiBcclxuICAgKiBcclxuICAgKiBAcGFyYW0geyBPYmplY3QgfSBpdGVyYXRvcnMgeyBmaWx0ZXJOYW1lOiBhc3luYyAoZG9jLGNvbnRleHQpPT57fSwgLi4uIH0gaXRlcmF0b3IgZm9yIGVhY2ggZmlsdGVycyBcclxuICAgKiBAcGFyYW0geyBhc3luYyBmdW5jdGlvbiB9IG9uRXJyb3IgZXJyb3IgaGFuZGxlciB3aGlsZSBpdGVyYXRpbmdcclxuICAgKiBAcmV0dXJucyB7IE9iamVjdCB9IHsgZmlsdGVyTmFtZTogeyBxdWVyeTogYW55LCBjb3VudDogbnVtYmVyIH0sIC4uLiB9XHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaChpdGVyYXRvcnMgPSB7fSkge1xyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGVfKCk7XHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgbmFtZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pO1xyXG5cclxuICAgIGxldCBjb3VudGVyID0ge307XHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBmaWx0ZXJzID0gW107XHJcblxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgICAgY291bnRlcltmLm5hbWVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmLnF1ZXJ5LFxyXG4gICAgICAgIGxpbWl0OiB0eXBlb2YgZi5saW1pdCAhPT0gJ3VuZGVmaW5lZCcgPyBmLmxpbWl0IDogMCAsXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfTtcclxuICAgICAgZmlsdGVycy5wdXNoKFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6IGYubmFtZSxcclxuICAgICAgICAgIGV4YW06IHNpZnQoIG1vYmplY3QudW5lc2NhcGUoZi5xdWVyeSkgKVxyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCwgY29udGV4dCkgPT4ge1xyXG5cclxuICAgICAgICBmb3IgKGxldCBmIG9mIGZpbHRlcnMpIHtcclxuXHJcbiAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgIGxldCBjID0gY291bnRlcltmLm5hbWVdO1xyXG4gICAgICAgICAgaWYoIGMubGltaXQgKXtcclxuICAgICAgICAgICAgaWYoIGMuY291bnQgPj0gYy5saW1pdCApe1xyXG4gICAgICAgICAgICAgIGNvbnRpbnVlO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKGYuZXhhbShyZWNvcmQpKSB7XHJcblxyXG4gICAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgICAgYy5jb3VudCsrO1xyXG5cclxuICAgICAgICAgICAgLy8gaXRlcmF0b3JcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVyYXRvcnNbZi5uYW1lXSAhPT0gXCJ1bmRlZmluZWRcIikge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGl0ZXJhdG9yc1tmLm5hbWVdKHJlY29yZCwgY29udGV4dCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSk7XHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudGVyO1xyXG4gIH1cclxufVxyXG5cclxuaW1wb3J0IE15U1FMIGZyb20gXCIuLi91dGlsL215c3FsXCI7XHJcblxyXG5leHBvcnQgY2xhc3MgTXlzcWxEQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuXHJcbiAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKGNyZWQpO1xyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YDtcclxuICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgKGUpPT57dGhyb3cgZX0pO1xyXG4gICAgfSk7XHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgTW9uZ29OYXRpdmUgZnJvbSAnbW9uZ29kYic7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gTW9uZ29OYXRpdmUuTW9uZ29DbGllbnQ7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gcmVxdWlyZSgnbW9uZ29kYicpLk1vbmdvQ2xpZW50O1xyXG5pbXBvcnQge01vbmdvQ2xpZW50fSBmcm9tICdtb25nb2RiJztcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xyXG5cclxuICAgIC8vIG1vbmdvIOOBuOaOpee2mlxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcblxyXG4gICAgICBsZXQgY2xpZW50O1xyXG4gICAgICBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKTtcclxuXHJcbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xyXG4gICAgICBsZXQgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSk7XHJcbiAgICAgIGxldCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG4gIFxyXG4gICAgICBsZXQgY29udGV4dCA9IHtcclxuICAgICAgICBjbGllbnQ6IGNsaWVudCxcclxuICAgICAgICBjb2xsZWN0aW9uOiBjb2xsZWN0aW9uLFxyXG4gICAgICAgIGRhdGFiYXNlOiBkYlxyXG4gICAgICB9O1xyXG5cclxuICAgICAgbGV0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpO1xyXG4gICAgICBcclxuICAgICAgd2hpbGUoIGF3YWl0IGN1ci5oYXNOZXh0KCkgKXtcclxuICAgICAgICBsZXQgZG9jID0gYXdhaXQgY3VyLm5leHQoKTtcclxuICAgICAgICBhd2FpdCBvblJlc3VsdChkb2MsIGNvbnRleHQpO1xyXG4gICAgICB9O1xyXG5cclxuICAgIH0pO1xyXG5cclxuICB9XHJcbn1cclxuXHJcblxyXG4vLyBpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbi8vICAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xyXG4vLyAgICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XHJcblxyXG4vLyAgICAgLy8gbW9uZ28g44G45o6l57aaXHJcbi8vICAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuLy8gICAgIGxldCBjb251cmkgPSBgbW9uZ29kYjovLyR7Y3JlZC5ob3N0fToke2NyZWQucG9ydH0vJHtjcmVkLmRhdGFiYXNlfWA7XHJcbi8vICAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KGNvbnVyaSk7XHJcblxyXG4vLyAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5L2c44KLXHJcbi8vICAgICBsZXQgY29sbGVjdGlvbiA9IG1vbmdvb3NlLmNvbm5lY3Rpb24uY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG5cclxuLy8gICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4vLyAgICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XHJcbiAgICAgIFxyXG4vLyAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH1cclxuLy8gfVxyXG5cclxuXHJcbiIsImltcG9ydCB7IE1vbmdvQ29sbGVjdGlvbiB9IGZyb20gXCIuLi91dGlsL21vbmdvXCI7XHJcbmltcG9ydCB7IFVwbG9hZHMgfSBmcm9tIFwiLi4vY29sbGVjdGlvbi91cGxvYWRzXCI7XHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtQ29udHJvbGxlcntcclxuXHJcbiAgYXN5bmMgaW5pdChwbHVnKXtcclxuXHJcbiAgICB0aGlzLkl0ZW1zID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldCggcGx1ZywgJ2l0ZW1zJyApO1xyXG4gICAgdGhpcy5Qcm9kdWN0cyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQoIHBsdWcsICdwcm9kdWN0cycgKTtcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTdG9jayggaXRlbV9pZCApe1xyXG4gICAgXHJcbiAgICBsZXQgcHJvamVjdCA9IGF3YWl0IHRoaXMuSXRlbXMuZmluZE9uZSh7IF9pZDogaXRlbV9pZCB9LHtwcm9qZWN0aW9uOiB7J3Byb2R1Y3QnOjF9fSk7XHJcbiAgICBsZXQgcHJvZHVjdF9wYWNrID0gcHJvamVjdC5wcm9kdWN0O1xyXG5cclxuICAgIC8vIHByb2R1Y3QgKiA8LT4gKiBpdGVtXHJcbiAgICAvLyBwcm9kdWN0W106IOikh+aVsOOBruWVhuWTgeOCkjHjg5Hjg4PjgrHjg7zjgrjjgajjgZfjgabosqnlo7JcclxuICAgIC8vIHByb2R1Y3RbW11dOiDnlbDjgarjgovmtYHpgJrntYzot6/jgIHnlbDjgarjgovljp/kvqHjg7vku5XlhaXjgozlgKRcclxuICAgIC8vIGl0ZW06IOeVsOOBquOCi+OCu+ODvOODq+OAgeiyqeWjsuW9ouaFi1xyXG4gICAgLy8g4oC7IHByb2R1Y3Qg44GL44KJ44Gv44CB6LKp5aOy5Y+v6IO944Gq5Zyo5bqr44CB5Yip55uK6KiI566X44Gu44Gf44KB44Gu5oOF5aCx44KS5b6X44KLXHJcblxyXG4gICAgbGV0IHF1YW50aXRpZXMgPSBbXTtcclxuXHJcbiAgICBmb3IoIGxldCBwcm9kdWN0X3NrdSBvZiBwcm9kdWN0X3BhY2sgKXtcclxuXHJcbiAgICAgIGxldCBxdWFudGl0eV9za3UgPSAwO1xyXG5cclxuICAgICAgZm9yKCBsZXQgcHJvZHVjdF9pZCBvZiBwcm9kdWN0X3NrdSApe1xyXG5cclxuICAgICAgICBsZXQgcHJvamVjdCA9IGF3YWl0IHRoaXMuUHJvZHVjdHMuZmluZE9uZSh7X2lkOiBwcm9kdWN0X2lkfSx7cHJvamVjdGlvbjp7J3N0b2NrJzoxfX0pO1xyXG4gICAgICAgIGxldCBzdG9ja19hcnJheSA9IHByb2plY3Quc3RvY2s7XHJcblxyXG4gICAgICAgIC8vIOWNmOe0lOOBq+OBmeOBueOBpuOBruWcqOW6q+WVhuWTgeOAgeefreacn+mWk+WPluOCiuWvhOOBm+WPr+iDveWVhuWTgeOCkuWQiOeul1xyXG4gICAgICAgIGZvciggbGV0IHN0b2NrIG9mIHN0b2NrX2FycmF5ICl7XHJcbiAgICAgICAgICBxdWFudGl0eV9za3UgKz0gc3RvY2sucXVhbnRpdHk7XHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgfVxyXG5cclxuICAgICAgcXVhbnRpdGllcy5wdXNoKHF1YW50aXR5X3NrdSk7XHJcblxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCu+ODg+ODiOWVhuWTgeOBruWgtOWQiOOAgeS4gOeVquWwkeOBquOBhOWVhuWTgeaVsOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IHF1YW50aXR5ID0gTWF0aC5taW4uYXBwbHkoIG51bGwsIHF1YW50aXRpZXMgKTtcclxuXHJcbiAgICByZXR1cm4gcXVhbnRpdHk7XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOCi+OAglxyXG4gICAqIFxyXG4gICAqIOODoeODvOOCq+ODvOODouODh+ODq+OBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqIFxyXG4gICAqIOeJueWumuOBruWxnuaAp++8iOOCq+ODqeODvOOBquOBqe+8ieOBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOBq+WApOOCkuaMh+WumuOBl+OAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqIOOCguOBl2NsYXNzMuOBruOBv+aMh+WumuOBl+OBn+OBhOWgtOWQiOOBr2NsYXNzMeOBq251bGzjgpLmjIflrprjgZnjgovjgIJcclxuICAgKiBcclxuICAgKiDkvovvvJpKSy0xMDDjga5CTEFDS+OBruWVhuWTgeeUu+WDj+OCklxyXG4gICAqIOOBmeOBueOBpuOBruOCteOCpOOCuu+8iFMsTSxMLFhMLDJYTCwzWEwsNFhM4oCm77yJ44Gr6Zai6YCj5LuY44GR44KL5aC05ZCIXHJcbiAgICogc2V0SW1hZ2UoIHVwbG9hZElkLCAnSkstMTAwJywgJ0JMQUNLJyApO1xyXG4gICAqIFxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB1cGxvYWRJZCDkuIDlm57jga7jgqLjg4Pjg5fjg63jg7zjg4nnlLvlg4/jgpLmnZ/jga3jgabjgYTjgotJROOAgm1ldGVvcuODh+ODvOOCv+ODmeODvOOCueOAgVVwbG9hZHPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjg4njgq3jg6Xjg6Hjg7Pjg4jjga51cGxvYWRJZOODl+ODreODkeODhuOCo1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgc2V0SW1hZ2UoIHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCApe1xyXG5cclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OBruaDheWgseWPluW+l1xyXG4gICAgbGV0IGltYWdlcyA9IFVwbG9hZHMuZmluZCh7dXBsb2FkSWQ6dXBsb2FkSWR9KS5mZXRjaCgpLm1hcCggdiA9PiB2LnVwbG9hZGVkRmlsZU5hbWUgKTtcclxuXHJcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcclxuICAgIGxldCBmaWx0ZXIgPSB7fTtcclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsO1xyXG4gICAgaWYoIGNsYXNzMSApIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczE7XHJcbiAgICBpZiggY2xhc3MyICkgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMjtcclxuICAgIFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLFxyXG4gICAgICB7XHJcbiAgICAgICAgJHB1c2g6e1xyXG4gICAgICAgICAgaW1hZ2VzOiB7XHJcbiAgICAgICAgICAgICRlYWNoOiBpbWFnZXNcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgLy8g55m76Yyy44GX44Gf55S75YOP44OV44Kh44Kk44Or5ZCN5LiA6KanXHJcbiAgICByZXR1cm4gaW1hZ2VzO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavnmbvpjLLjgZXjgozjgabjgYTjgovnlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgovjgIJcclxuICAgKiBcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIGNsZWFuSW1hZ2UoIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsICl7XHJcblxyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge307XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbDtcclxuICAgIGlmKCBjbGFzczEgKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxO1xyXG4gICAgaWYoIGNsYXNzMiApIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczI7XHJcbiAgICBcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlcixcclxuICAgICAge1xyXG4gICAgICAgICRzZXQ6e1xyXG4gICAgICAgICAgaW1hZ2VzOiBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRWYXJpYXRpb24oIGl0ZW0sIHByb2plY3QgKXtcclxuXHJcbiAgICAvLyDjg6vjg7zjg5fnlKjjga7oqK3lrppcclxuICAgIGxldCBzZXQgPSBbXHJcbiAgICAgIHtcclxuICAgICAgICBsYWJlbDogaXRlbS5jbGFzczFfbmFtZSxcclxuICAgICAgICBjdXJyZW50OiBpdGVtLmNsYXNzMV92YWx1ZSxcclxuICAgICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgICB2YWx1ZTonJGNsYXNzMV92YWx1ZSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHF1ZXJ5OntcclxuICAgICAgICAgIGNsYXNzMl92YWx1ZTogaXRlbS5jbGFzczJfdmFsdWVcclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIHtcclxuICAgICAgICBsYWJlbDogaXRlbS5jbGFzczJfbmFtZSxcclxuICAgICAgICBjdXJyZW50OiBpdGVtLmNsYXNzMl92YWx1ZSxcclxuICAgICAgICBwcm9qZWN0OiB7XHJcbiAgICAgICAgICB2YWx1ZTonJGNsYXNzMl92YWx1ZSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHF1ZXJ5OntcclxuICAgICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWVcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIF07XHJcblxyXG4gICAgbGV0IGF0dHJzID0gW107XHJcblxyXG4gICAgZm9yKCBsZXQgcyBvZiBzZXQgKXtcclxuICAgICAgYXR0cnMucHVzaCh7XHJcbiAgICAgICAgdmFyaWF0aW9uczpcclxuICAgICAgICAgIGF3YWl0IHRoaXMuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgICBbXHJcbiAgICAgICAgICAgICAgeyAkbWF0Y2g6IE9iamVjdC5hc3NpZ24oIHMucXVlcnksIHsgbW9kZWw6IGl0ZW0ubW9kZWwgfSApIH0sXHJcbiAgICAgICAgICAgICAgeyAkcHJvamVjdDogT2JqZWN0LmFzc2lnbiggcy5wcm9qZWN0LCBwcm9qZWN0ICkgfVxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgICApLnRvQXJyYXkoKSxcclxuICAgICAgICBwcm9wczogc1xyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBhdHRycztcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBjb252ZXJ0SXRlbUN1YmUzKGNyZWF0b3JfaWQsIGl0ZW0pe1xyXG5cclxuICAgIC8vIHByb2R1Y3RfaWRcclxuICAgIGxldCBwcm9kdWN0X2lkID0gbnVsbDtcclxuXHJcbiAgICAvLyDkuIvoqJjjga7lvaLlvI/jgpLkvZzjgotcclxuICAgIC8vIOODoeODvOOCq+ODvOOCs+ODvOODiS/lsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJL+WxnuaApzLvvIjjgrXjgqTjgrrjgarjganvvIlcclxuICAgIGxldCBtb2RlbENsYXNzID0gW107XHJcbiAgICBpZihpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbCk7XHJcbiAgICBpZihpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKTtcclxuICAgIGlmKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpO1xyXG5cclxuICAgIC8vIOWVhuWTgeeoruWIpeOCkuWJsuOCiuW9k+OBpuOCi1xyXG4gICAgbGV0IHByb2R1Y3RfdHlwZV9pZDtcclxuICAgIHN3aXRjaChpdGVtLmRlbGl2ZXJ5KXtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzogcHJvZHVjdF90eXBlX2lkID0gMTsgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6IHByb2R1Y3RfdHlwZV9pZCA9MjsgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQgOiBwcm9kdWN0X3R5cGVfaWQgPSAxOyBicmVhaztcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCB0YWdzID0gW107XHJcbiAgICBzd2l0Y2goaXRlbS5kZWxpdmVyeSl7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6IHRhZ3MucHVzaCh7dGFnOjQsc2V0Oidvbid9LHt0YWc6NSxzZXQ6J29mZid9KTsgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6IHRhZ3MucHVzaCh7dGFnOjUsc2V0Oidvbid9LHt0YWc6NCxzZXQ6J29mZid9KTsgYnJlYWs7XHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB5Yil6YCB5paZ44KS6Kit5a6a44GZ44KLXHJcbiAgICBsZXQgZGVsaXZlcnlfZmVlID0gbnVsbDtcclxuICAgIHN3aXRjaChpdGVtLmRlbGl2ZXJ5KXtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzogZGVsaXZlcnlfZmVlID0gbnVsbDsgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6IGRlbGl2ZXJ5X2ZlZSA9IDI0MDsgYnJlYWs7XHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB5oOF5aCx6Kmz57Sw44Gr44CB5ZWG5ZOB44OQ44Oq44Ko44O844K344On44Oz44Gu44Oq44Oz44Kv44KS44Gk44GR44KLXHJcbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7cHJvZHVjdF9pZDonJG1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9pZCd9KTtcclxuXHJcbiAgICBsZXQgdmFyaWF0aW9uSHRtbCA9XHJcbiAgICBhdHRycy5tYXAoXHJcbiAgICAgIGF0dHIgPT4gXHJcbiAgICAgICAgJzxkaXYgY2xhc3M9XCJjb250YWluZXItZmx1aWRcIj4nXHJcbiAgICAgICAgKyBgPGRpdiBjbGFzcz1cInJvd1wiPjxwPiYjODIyNjsgJHthdHRyLnByb3BzLmxhYmVsfTwvcD48L2Rpdj5gXHJcbiAgICAgICAgKyAnPGRpdiBjbGFzcz1cInJvd1wiPidcclxuICAgICAgICAgICsgYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICAgdmFyaWF0aW9uID0+XHJcbiAgICAgICAgICAgICAgYDxhIGhyZWY9XCIvcHJvZHVjdHMvZGV0YWlsLyR7dmFyaWF0aW9uLnByb2R1Y3RfaWR9XCI+PGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tYmxvY2sgYnRuLXhzXCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgKS5qb2luKCcnKVxyXG4gICAgICAgICsgJzwvZGl2PidcclxuICAgICAgICArICc8L2Rpdj4nXHJcbiAgICAgIFxyXG4gICAgKS5qb2luKCcnKTtcclxuXHJcbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcclxuICAgIGxldCBkYXRhID0ge1xyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0X2lkLFxyXG4gICAgICBjcmVhdG9yX2lkOiBjcmVhdG9yX2lkLFxyXG4gICAgICBuYW1lOiBgJHttb2RlbENsYXNzLmpvaW4oJy8nKX0gJHtpdGVtLm5hbWV9ICR7aXRlbS5qYW5fY29kZX1gLFxyXG4gICAgICBkZXNjcmlwdGlvbl9kZXRhaWw6IHZhcmlhdGlvbkh0bWwgKyBpdGVtLmRlc2NyaXB0aW9uLFxyXG4gICAgICBwcm9kdWN0X2NvZGU6IGl0ZW0ubW9kZWwsXHJcbiAgICAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxyXG4gICAgICBwcmljZTAyOiBpdGVtLnNhbGVzX3ByaWNlLFxyXG4gICAgICBpbWFnZXM6IGl0ZW0uaW1hZ2VzLFxyXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RfdHlwZV9pZCxcclxuICAgICAgdGFnczogdGFncyxcclxuICAgICAgZGVsaXZlcnlfZmVlOiBkZWxpdmVyeV9mZWVcclxuICAgIH07XHJcblxyXG4gICAgT2JqZWN0LmFzc2lnbiggZGF0YSwgaXRlbS5tYWxsLnNoYXJha3VTaG9wKTtcclxuXHJcbiAgICByZXR1cm4gZGF0YTtcclxuXHJcbiAgfVxyXG4gICAgXHJcbn0iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyB1dGlsRXJyb3J7XHJcblxyXG4gIHN0YXRpYyBwYXJzZShlKXtcclxuXHJcbiAgICBsZXQgcmVzID0ge307XHJcblxyXG4gICAgaWYoZSBpbnN0YW5jZW9mIEVycm9yKXtcclxuICAgICAgcmVzLm1lc3NhZ2UgPSBlLm1lc3NhZ2U7XHJcbiAgICAgIHJlcy5uYW1lID0gZS5uYW1lO1xyXG4gICAgICByZXMuZmlsZU5hbWUgPSBlLmZpbGVOYW1lO1xyXG4gICAgICByZXMubGluZU51bWJlciA9IGUubGluZU51bWJlcjtcclxuICAgICAgcmVzLmNvbHVtbk51bWJlciA9IGUuY29sdW1uTnVtYmVyO1xyXG4gICAgICByZXMuc3RhY2sgPSBlLnN0YWNrO1xyXG4gICAgfVxyXG4gICAgZWxzZXtcclxuICAgICAgcmVzID0gZTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzO1xyXG5cclxuICB9XHJcblxyXG59IiwiaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tICdtb25nb2RiJztcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0NvbGxlY3Rpb257XHJcbiAgc3RhdGljIGFzeW5jIGdldChwbHVnLGNvbGxlY3Rpb24pe1xyXG4gICAgbGV0IGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpO1xyXG4gICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpO1xyXG4gICAgcmV0dXJuIGRiLmNvbGxlY3Rpb24oY29sbGVjdGlvbik7XHJcbiAgfVxyXG59IiwiaW1wb3J0IG15c3FsIGZyb20gJ215c3FsJztcclxuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE15U1FMIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJvZmlsZSkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz44OX44O844Or5Yid5pyf5YyWXHJcbiAgICB0aGlzLnBvb2wgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGUpO1xyXG5cclxuICAgIC8vIOikh+aVsOihjOOCueODhuODvOODiOODoeODs+ODiOWvvuW/nFxyXG4gICAgbGV0IHByb2ZpbGVNdWx0aSA9IHttdWx0aXBsZVN0YXRlbWVudHM6dHJ1ZX07XHJcbiAgICBPYmplY3QuYXNzaWduKCBwcm9maWxlTXVsdGksIHByb2ZpbGUgKTtcclxuICAgIHRoaXMucG9vbE11bHRpID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlTXVsdGkpO1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZvcm1hdERhdGUoIGRhdGUgKXtcclxuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsMTkpLnJlcGxhY2UoJ1QnLCAnICcpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNxbCBcclxuICAgKi9cclxuICBxdWVyeShzcWwpIHtcclxuXHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pnorrnq4tcclxuICAgIC8vIGxldCBjb24gPSBhd2FpdCB0aGlzLmdldENvbigpO1xyXG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcclxuICAgICAgLnRoZW4oXHJcbiAgICAgICAgKGNvbikgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAgICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXHJcbiAgICAgICAgICAgICAgY29uLnF1ZXJ5KHNxbCwgKGUsIHJlcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8g44Kz44ON44Kv44K344On44Oz6ZaL5pS+XHJcbiAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHJlc29sdmUocmVzKTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKTtcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgICAgfSk7XHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnRfKHNxbCl7XHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xyXG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZDtcclxuICB9XHJcbiAgXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlIFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvOOAgW51bGzjgIFqYXZhc2NyaXB0LT5teXNxbOaXpeS7mOWkieaPm+OBq+OCguWvvuW/nFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhX3NxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICAgYXN5bmMgcXVlcnlJbnNlcnQodGFibGUsIGRhdGEgPSB7fSwgZGF0YV9zcWwgPSB7fSl7XHJcblxyXG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgO1xyXG5cclxuICAgIGxldCBtYXAgPSBuZXcgTWFwKCk7XHJcbiAgICBmb3IoIGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpICl7XHJcblxyXG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCl7XHJcbiAgICAgICAgbWFwLnNldChrLCAnTlVMTCcpO1xyXG4gICAgICB9XHJcbiAgICAgIGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKTtcclxuICAgICAgfVxyXG4gICAgICBlbHNle1xyXG4gICAgICAgIG1hcC5zZXQoaywgYCR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApO1xyXG4gICAgICB9XHJcblxyXG4gICAgfVxyXG4gICAgZm9yKCBsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhX3NxbCkgKXtcclxuICAgICAgbWFwLnNldChrLCBkYXRhX3NxbFtrXSA9PT0gbnVsbCA/ICdOVUxMJyA6IGRhdGFfc3FsW2tdKTtcclxuICAgIH1cclxuXHJcbiAgICBzcWwgKz0gYCggJHtbLi4ubWFwLmtleXMoKV0uam9pbignLCcpfSApIGA7XHJcblxyXG4gICAgc3FsICs9IGBWQUxVRVMoICR7Wy4uLm1hcC52YWx1ZXMoKV0uam9pbignLCcpfSApIGA7XHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlIFxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBmaWx0ZXIgU1FMIFVQREFUReOCueODhuODvOODiOODoeODs+ODiOOBrldIRVJF5Y+lXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O8XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFfc3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xyXG4gICAqL1xyXG4gIGFzeW5jIHF1ZXJ5VXBkYXRlKHRhYmxlLCBmaWx0ZXIsIGRhdGEsIGRhdGFfc3FsKXtcclxuICAgIGxldCBzcWwgPSBgVVBEQVRFICR7dGFibGV9IFNFVCBgO1xyXG5cclxuICAgIGxldCB1cGRhdGVzID0gW107XHJcbiAgICBmb3IoIGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpICl7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKTtcclxuICAgIH1cclxuICAgIGZvciggbGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YV9zcWwpICl7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke2RhdGFfc3FsW2tdfWApO1xyXG4gICAgfVxyXG4gICAgc3FsICs9IHVwZGF0ZXMuam9pbignLCcpO1xyXG5cclxuICAgIHNxbCArPSBgIFdIRVJFICR7ZmlsdGVyfSBgO1xyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XHJcbiAgICByZXR1cm4gcmVzO1xyXG4gIH1cclxuXHJcbiAgLy8gZW5hYmxlIHRvIHVzZSBtdWx0aXBsZSBzdGF0ZW1lbnRzXHJcbiAgYXN5bmMgcXVlcnlNdWx0aShzcWwpIHtcclxuICAgIGxldCBwb29sU3dhcCA9IHRoaXMucG9vbDtcclxuICAgIHRoaXMucG9vbCA9IHRoaXMucG9vbE11bHRpO1xyXG4gICAgdHJ5e1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xyXG4gICAgICByZXR1cm4gcmVzO1xyXG4gICAgfVxyXG4gICAgZmluYWxseXtcclxuICAgICAgdGhpcy5wb29sID0gcG9vbFN3YXA7XHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBzdGFydFRyYW5zYWN0aW9uKCl7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBTVEFSVCBUUkFOU0FDVElPTjtgKTtcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbW1pdCgpe1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgQ09NTUlUO2ApO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcm9sbGJhY2soKXtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYFJPTExCQUNLO2ApO1xyXG4gIH1cclxuXHJcbiAgc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCA9IChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gKGUpID0+IHt9KSB7XHJcbiAgICByZXR1cm4gdGhpcy5nZXRDb24oKVxyXG4gICAgICAudGhlbihcclxuICAgICAgICAoY29uKSA9PiB7XHJcbiAgICAgICAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgICAgIGFzeW5jIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgICAgICAvLyDjgq/jgqjjg6rpgIHkv6FcclxuICAgICAgICAgICAgICBjb24ucXVlcnkoc3FsKVxyXG4gICAgICAgICAgICAgICAgLm9uKCdyZXN1bHQnLFxyXG4gICAgICAgICAgICAgICAgICAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgICAgY29uLnBhdXNlKCk7XHJcbiAgICAgICAgICAgICAgICAgICAgb25SZXN1bHQocmVjb3JkKTtcclxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKCk7XHJcbiAgICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2Vycm9yJywgKGUpID0+IHtcclxuICAgICAgICAgICAgICAgICAgb25FcnJvcihlKTtcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2VuZCcsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKTtcclxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICAgICAgfSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICk7XHJcblxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlO1xyXG4gICAgICB9KTtcclxuXHJcbiAgfVxyXG5cclxuXHJcbiAgZ2V0Q29uKCkge1xyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAgIC8vIOODl+ODvOODq+OBi+OCieOBruOCs+ODjeOCr+OCt+ODp+ODs+eNsuW+l1xyXG4gICAgICAgICAgdGhpcy5wb29sLmdldENvbm5lY3Rpb24oKGUsIGNvbikgPT4ge1xyXG4gICAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICAgIHJlamVjdChlKTtcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICByZXNvbHZlKGNvbik7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goXHJcbiAgICAgICAgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGU7XHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG4gIH07XHJcblxyXG59IiwiaW1wb3J0IHV0aWxFcnJvciBmcm9tIFwiLi9lcnJvclwiO1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVwb3J0IHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB0aGlzLnJlY29yZCA9IFtdO1xyXG4gICAgdGhpcy5pdGVyYXRvcnMgPSBbXTtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBudWxsO1xyXG4gIH1cclxuXHJcbiAgc2V0dXBJdGVyYXRvcigpe1xyXG4gICAgdGhpcy5pdGVyYXRvciA9IG5ldyBJdGVyYXRvcigpO1xyXG4gICAgdGhpcy5pdGVyYXRvcnMucHVzaCggdGhpcy5pdGVyYXRvciApO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGhhc2UobmFtZSA9ICcnLCBmbiA9IGFzeW5jICgpID0+IHt9KSB7XHJcblxyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKCk7XHJcblxyXG4gICAgbGV0IHJlYyA9IHt9O1xyXG5cclxuICAgIHRyeSB7XHJcblxyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgZm4oKTtcclxuXHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ3N1Y2Nlc3MnLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogcmVzXHJcbiAgICAgIH0pO1xyXG5cclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuXHJcbiAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgdHlwZTogJ2Vycm9yJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHV0aWxFcnJvci5wYXJzZShlKVxyXG4gICAgICB9KTtcclxuXHJcbiAgICB9IGZpbmFsbHkge1xyXG5cclxuICAgICAgaWYgKHRoaXMuaXRlcmF0b3IudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3JcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICB0aGlzLnJlY29yZC5wdXNoKHJlYyk7XHJcblxyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIGlTdWNjZXNzKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5zdWNjZXNzKG5ld1JlY29yZCk7XHJcbiAgfVxyXG5cclxuICBpRXJyb3IobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLmVycm9yKHV0aWxFcnJvci5wYXJzZShuZXdSZWNvcmQpKTtcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCgpe1xyXG4gICAgXHJcbiAgICBsZXQgaXRlRXJyb3IgPSB0aGlzLml0ZXJhdG9ycy5maW5kKGU9PmUuZXJyb3JPY3VycmVkKCkpO1xyXG4gICAgbGV0IHBoYUVycm9yID0gZmFsc2U7XHJcbiAgICBmb3IoIGxldCByZWMgb2YgdGhpcy5yZWNvcmQgKXtcclxuICAgICAgaWYoIHJlYy50eXBlID09PSAnZXJyb3InKXtcclxuICAgICAgICBwaGFFcnJvciA9IHRydWU7XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBpdGVFcnJvciB8fCBwaGFFcnJvcjtcclxuICB9XHJcblxyXG4gIHB1Ymxpc2goKSB7XHJcbiAgICBpZih0aGlzLmVycm9yT2N1cnJlZCgpKXtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcih0aGlzLnJlY29yZCk7XHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGhpcy5yZWNvcmQ7XHJcbiAgfVxyXG5cclxufVxyXG5cclxuXHJcbmNsYXNzIEl0ZXJhdG9yIHtcclxuXHJcbiAgY29uc3RydWN0b3IoKSB7XHJcbiAgICB0aGlzLnRvdGFsID0wO1xyXG4gICAgdGhpcy50cmFjZSA9IHtcclxuICAgICAgc3VjY2Vzczoge1xyXG4gICAgICAgIHRvdGFsOiAwLFxyXG4gICAgICAgIHJlY29yZHM6IFtdXHJcbiAgICAgIH0sXHJcbiAgICAgIGVycm9yOiB7XHJcbiAgICAgICAgdG90YWw6IDAsXHJcbiAgICAgICAgcmVjb3JkczogW11cclxuICAgICAgfSxcclxuICAgIH07XHJcbiAgfVxyXG5cclxuICBzdWNjZXNzKG5ld1JlY29yZCkge1xyXG4gICAgaWYobmV3UmVjb3JkKXtcclxuICAgICAgdGhpcy50cmFjZS5zdWNjZXNzLnJlY29yZHMucHVzaChuZXdSZWNvcmQpO1xyXG4gICAgfVxyXG4gICAgdGhpcy50cmFjZS5zdWNjZXNzLnRvdGFsKys7XHJcbiAgICB0aGlzLnRvdGFsKys7XHJcbiAgfVxyXG4gIGVycm9yKG5ld1JlY29yZCkge1xyXG5cclxuICAgIC8vIOebtOWJjeOBruOCqOODqeODvOOCkuWPluW+l1xyXG4gICAgbGV0IGxhc3RFcnJvciA9IG51bGw7XHJcbiAgICBsZXQgaW5kZXggPSB0aGlzLnRyYWNlLmVycm9yLnJlY29yZHMubGVuZ3RoO1xyXG4gICAgaWYoaW5kZXgpe1xyXG4gICAgICBsYXN0RXJyb3IgPSB0aGlzLnRyYWNlLmVycm9yLnJlY29yZHNbaW5kZXgtMV07XHJcbiAgICB9XHJcbiAgICBcclxuICAgIC8vIOebtOWJjeOBqOWQjOOBmOOCqOODqeODvOOBr+ecgeOBj1xyXG4gICAgaWYoIEpTT04uc3RyaW5naWZ5KGxhc3RFcnJvcikgIT09IEpTT04uc3RyaW5naWZ5KG5ld1JlY29yZCkpXHJcbiAgICBpZiggbmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PScnICl7XHJcbiAgICAgIHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkcy5wdXNoKG5ld1JlY29yZCk7XHJcbiAgICB9XHJcbiAgICB0aGlzLnRyYWNlLmVycm9yLnRvdGFsKys7XHJcbiAgICB0aGlzLnRvdGFsKys7XHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQoKXtcclxuICAgIHJldHVybiB0aGlzLnRyYWNlLmVycm9yLnRvdGFsO1xyXG4gIH1cclxuXHJcbn1cclxuIl19
