var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/route/upload/image.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube/cubemig.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 3);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 4);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 5);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let couponCd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let couponName = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discountPrice = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: couponCd,
                coupon_type: 3,
                // 全商品
                coupon_name: couponName,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discountPrice,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                customer_id: record.customer_id,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
        return res;
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/collection.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
      return res;
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.aggregate(query).toArray());
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let ItemController;
module.watch(require("../../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/service/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 5);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  //
  // 商品情報登録と更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              let quantity = Promise.await(itemController.getStock(item._id));
              Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/tooltest.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      const newLocal = Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
        throw e;
      })));
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return newLocal;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/yauct.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
const prefix = 'packet';
const tag = 'yauct';
Meteor.methods({
  //
  // ヤフオク出品ファイル
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク出品ファイル', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 繰り返し処理を任意の（packetSize）で分割

        const packet = new Packet(config.packetSize); // 作業フォルダ内をすべてクリアしておく

        Promise.await(fsExtra.remove(config.workdir));
        Promise.await(fsExtra.mkdir(config.workdir));
        let cd = null; // パケットフォルダ

        let filename = null; // csvファイル

        let name = null; // パケット番号
        // CSVフィールドを定義し、順番を確定する

        let fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
        let header = fields.map(v => `"${v}"`).join(',') + '\n'; // パケット化開始時

        packet.onPacketStart = packetCount => Promise.asyncApply(() => {
          name = prefix + ('00000' + packetCount).slice(-5);
          cd = `${config.workdir}/${name}`;
          filename = `${cd}/${config.csvFileName}`;
          Promise.await(fsExtra.mkdir(cd)); // CSVファイルにフィールドを設定する

          Promise.await(fsExtra.appendFile(filename, iconv.encode(header, 'Shift_JIS')));
        }); // パケット化時


        packet.onPacket = arg => Promise.asyncApply(() => {
          let yauct = arg.yauct;
          let item = arg.item; // csvファイルにレコード（商品テンプレート）を追加する

          let record = fields.map(v => {
            return yauct[v] ? `"${yauct[v]}"` : '""';
          }).join(',') + '\n';
          Promise.await(fsExtra.appendFile(filename, iconv.encode(record, 'Shift_JIS'))); // 画像ファイルをコピー

          for (let img of item.images) {
            let imgSrc = `${config.imagedir}/${img}`;
            let imgTgt = `${cd}/${img}`;

            try {
              // 同じファイルがある場合はコピーしない
              Promise.await(fsExtra.access(imgTgt));
            } catch (e) {
              Promise.await(fsExtra.copyFile(imgSrc, imgTgt));
            }
          }
        }); // パケット終了時


        packet.onPacketEnd = packetCount => Promise.asyncApply(() => {
          const zip = archiver('zip');
          const zipname = cd + '.zip';
          const output = fsExtra.createWriteStream(zipname);
          zip.pipe(output);
          zip.directory(cd, false);
          zip.finalize();
        }); // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id)); // itemに定義されている最低必要在庫より多い商品を出品する

            if (quantity >= item.mall.yauct.minQuantity) {
              let yauct = Promise.await(itemController.convertItemYauct(config.default, item));
              Promise.await(packet.submit({
                yauct: yauct,
                item: item
              }));
            }
          })
        }));
        packet.close();
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/configs.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/filters.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/groups.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/uploads.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/cube3api.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  updateStock(productClassId, quantity = 0) {
    return Promise.asyncApply(() => {
      Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      }));
      Promise.await(this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      }));
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = []; // 削除するタグ

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      }); // 表示するタグ


      let tagon = tag => Promise.asyncApply(() => {
        // すでに表示されているタグがあれば何もしない
        let sql = `
      SELECT COUNT(*) FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        let countRes = Promise.await(this.mysql_.query(sql));
        if (countRes[0]['COUNT(*)']) return;
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creatorId,
          create_date: 'NOW()'
        })));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let productId = data.product_id;
      let images = data.images;
      let creatorId = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${productId}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        Promise.await(this.mysql_.queryInsert('dtb_product_image', {
          product_id: productId,
          creator_id: creatorId,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        }));
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let updateData = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      Promise.await(this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      })); // dtb_product_class

      updateData = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      let res = Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      }));
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = {};
      let updateData = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', updateData, {
        creator_id: creatorId,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      updateData = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', updateData, {
        creator_id: creatorId,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creatorId,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/dbfilter.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 3);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 4);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case 'mysql':
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    switch (plug.type) {
      case 'mysql':
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error('invalid plug type');
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   *
   *
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== 'undefined') {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      let res = Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
      return res;
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find(); // カーソルのタイムアウトを解除

      cur.addCursorFlag('noCursorTimeout', true); // すべてのドキュメントをループ

      try {
        while (Promise.await(cur.hasNext())) {
          let doc = Promise.await(cur.next());
          Promise.await(onResult(doc, context));
        }

        ;
      } finally {
        // カーソルを開放
        Promise.await(cur.close());
      }
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/items.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(itemId) {
    return Promise.asyncApply(() => {
      let project = Promise.await(this.Items.findOne({
        _id: itemId
      }, {
        projection: {
          'product': 1
        }
      }));
      let productPack = project.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[[]]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let productSku of productPack) {
        let quantitySku = 0;

        for (let productId of productSku) {
          let project = Promise.await(this.Products.findOne({
            _id: productId
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stockArray = project.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stockArray) {
            quantitySku += stock.quantity;
          }
        }

        quantities.push(quantitySku);
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   *
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   *
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   *
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   *
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   *
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }
  /**
   * 指定の商品に関連する商品群の属性別の商品情報を返す。
   *
   * 引数として受け取るitemは任意の商品情報。
   * itemに関連する商品群について必要な情報を整理し返す。
   *
   * projectに参照したい商品情報フィールドを定義する。
   * メソッドの呼び出し時に必要に応じてprojectを設定する。
   *
   * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
   *
   * @param {Object} item
   * @param {Object} project
   */


  getVariation(item, project) {
    return Promise.asyncApply(() => {
      /**
       * aggregation設定
       *
       * label: 属性名（配送方法、カラー、サイズなど）
       * current: 指定されたアイテム（item）が該当する項目
       * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
       * query: aggregation対象とするドキュメントの検索条件
       */
      let set = [{
        label: '配送方法',
        current: item.delivery,
        project: {
          value: '$delivery'
        },
        query: {
          class1_value: item.class1_value,
          class2_value: item.class2_value
        }
      }, {
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          delivery: item.delivery,
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          delivery: item.delivery,
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }, {
            $sort: {
              _id: 1
            }
          }]).toArray()),
          props: s
        });
      }

      return attrs;
    });
  } // モデルクラス形式を作る
  // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]


  getModelClass(item) {
    let modelClass = [];
    if (item.model) modelClass.push(item.model);
    if (item.class1_value) modelClass.push(item.class1_value);
    if (item.class2_value) modelClass.push(item.class2_value);
    return modelClass.join('/');
  }

  convertItemCube3(creatorId, item) {
    return Promise.asyncApply(() => {
      // 値変換
      let convDeliv = delivery => delivery === 'ゆうパケット' ? 'ポスト投函' : delivery; // product_id


      let productId = null;
      let modelClass = []; // 下記の形式を作る
      // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]

      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let productTypeId;

      switch (item.delivery) {
        case '宅配便':
          productTypeId = 1;
          break;

        case 'ゆうパケット':
          productTypeId = 2;
          break;

        default:
          productTypeId = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let deliveryFee = null;

      switch (item.delivery) {
        case '宅配便':
          deliveryFee = null;
          break;

        case 'ゆうパケット':
          deliveryFee = 240;
          break;
      } //
      // 顧客向けバリエーション商品選択機能の実装
      //


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      })); // HTML バリエーション商品ごとのリンク付きボタンを表示する
      // 値の変換

      attrs = attrs.map(attr => {
        attr.props.current = convDeliv(attr.props.current);
        attr.variations = attr.variations.map(variation => {
          variation.value = convDeliv(variation.value);
          return variation;
        });
        return attr;
      }); // HTML生成

      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row">` + `<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">` + `<strong>${attr.props.label}</strong>` + `</div>` + attr.variations.map(variation => {
        if (attr.props.current === variation.value) {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-success btn-sm btn-item-class-select"><strong>${variation.value}</strong></button></a>`;
        } else {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-sm btn-item-class-select">${variation.value}</button></a>`;
        }
      }).join('') + '</div>' + '</div>').join('');
      let descriptionDetail = `
    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>
    <small class="text-danger">※ 在庫がない商品の場合「ページが見つかりません」と表示されます。</small>
    ${variationHtml}
    `; // 商品データを作る

      let data = {
        product_id: productId,
        creator_id: creatorId,
        name: `${modelClass.join('/')} ${convDeliv(item.delivery)} ${item.name} ${item.jan_code}`,
        description_detail: descriptionDetail,
        free_area: item.description + ' ',
        product_code: modelClass.join('/'),
        price01: item.retail_price,
        price02: item.sales_price * 0.95,
        // 楽天価格から5%値引き
        images: item.images,
        product_type_id: productTypeId,
        tags: tags,
        delivery_fee: deliveryFee
      };
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  } // ヤフオクテンプレートへの変換


  convertItemYauct(def, item) {
    return Promise.asyncApply(() => {
      let yauct = {}; // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）

      yauct = def[item.delivery]; // 画像の記述

      const imgPrefix = '画像';

      for (let i = 0; i < item.images.length; i++) {
        yauct[imgPrefix + (i + 1)] = item.images[i];
      } // タイトル


      yauct['カテゴリ'] = item.mall.yauct.category;
      yauct['タイトル'] = `${this.getModelClass(item)} ${item.delivery} ${item.name}`;
      yauct['開始価格'] = item.sales_price;
      yauct['即決価格'] = item.sales_price;
      yauct['管理番号'] = this.getModelClass(item);
      yauct['説明'] = item.description;
      yauct['JANコード・ISBNコード'] = item.jan_code;
      return yauct;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/error.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mongo.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mysql.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   *
   * @param {String} sql
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, dataSql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(dataSql)) {
        map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, dataSql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(dataSql)) {
        updates.push(`${k}=${dataSql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/packet.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Packet
});

class Packet {
  constructor(packetSize) {
    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  submit(arg) {
    return Promise.asyncApply(() => {
      // packetSizeの回数ごとに、初期化を呼び出す
      if (this.count % this.packetSize === 0) {
        if (this.onPacketStart) {
          Promise.await(this.onPacketStart(this.packetCount));
        }
      }

      if (this.onPacket) {
        Promise.await(this.onPacket(arg));
      }

      this.count++; // packetSizeの回数ごとに、終了処理を呼び出す

      if (this.count % this.packetSize === 0) {
        if (this.onPacketEnd) {
          Promise.await(this.onPacketEnd(this.packetCount));
        }

        this.packetCount++;
      }
    });
  }

  close() {
    this.onPacketEnd(this.packetCount);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/report.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  setupIterator() {
    this.iterator = new Iterator();
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.setupIterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    // 直前のエラーを取得
    let lastError = null;
    let index = this.trace.error.records.length;

    if (index) {
      lastError = this.trace.error.records[index - 1];
    } // 直前と同じエラーは省く


    if (JSON.stringify(lastError) !== JSON.stringify(newRecord)) {
      if (newRecord && newRecord !== {} && newRecord !== '') {
        this.trace.error.records.push(newRecord);
      }
    }

    this.trace.error.total++;
    this.total++;
  }

  errorOcurred() {
    return this.trace.error.total;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90b29sdGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3lhdWN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyJdLCJuYW1lcyI6WyJmcyIsIm1vZHVsZSIsIndhdGNoIiwicmVxdWlyZSIsImRlZmF1bHQiLCJ2IiwidW5pcWlkIiwibXVsdGlwYXJ0eSIsIlVwbG9hZHMiLCJtdWx0aXBhcnR5TWlkZGxld2FyZSIsInJvdXRlIiwiV2ViQXBwIiwiY29ubmVjdEhhbmRsZXJzIiwidXNlIiwicmVxIiwicmVzcCIsInJlYWRlciIsIk1ldGVvciIsIndyYXBBc3luYyIsInJlYWRGaWxlIiwid3JpdGVyIiwid3JpdGVGaWxlIiwidXBsb2FkSWQiLCJmaWxlIiwiZmlsZXMiLCJkYXRhIiwicGF0aCIsImZpbGVuYW1lIiwic2F2ZVBhdGgiLCJib2R5IiwiaW1hZ2VkaXIiLCJkb2MiLCJjbGllbnRGaWxlTmFtZSIsIm5hbWUiLCJ1cGxvYWRlZEZpbGVOYW1lIiwiZXJyIiwiZXJyb3IiLCJpbnNlcnQiLCJ3cml0ZUhlYWQiLCJlbmQiLCJKU09OIiwic3RyaW5naWZ5Iiwic2F2ZURpciIsImNyeXB0byIsIk15U1FMIiwiUmVwb3J0IiwiR3JvdXAiLCJHcm91cEZhY3RvcnkiLCJGaWx0ZXIiLCJ0YWciLCJtZXRob2RzIiwiY29uZmlnIiwicmVwb3J0IiwiZmlsdGVyIiwic3JjRmlsdGVySWQiLCJ0ZXN0UXVlcnkiLCJkc3REYiIsImRzdCIsImNyZWQiLCJwaGFzZSIsInF1ZXJ5IiwicmVzIiwiZm9yZWFjaCIsIm1vYmlsZU51bGwiLCJyZWNvcmQiLCJzcWwiLCJjdXN0b21lcl9pZCIsInN0YXR1cyIsInNleCIsImpvYiIsImNvdW50cnlfaWQiLCJwcmVmIiwibmFtZTAxIiwibmFtZTAyIiwia2FuYTAxIiwia2FuYTAyIiwiY29tcGFueV9uYW1lIiwiemlwMDEiLCJ6aXAwMiIsInppcGNvZGUiLCJhZGRyMDEiLCJhZGRyMDIiLCJlbWFpbCIsInRlbDAxIiwidGVsMDIiLCJ0ZWwwMyIsImZheDAxIiwiZmF4MDIiLCJmYXgwMyIsImJpcnRoIiwicGFzc3dvcmQiLCJzYWx0Iiwic2VjcmV0X2tleSIsImZpcnN0X2J1eV9kYXRlIiwibGFzdF9idXlfZGF0ZSIsImJ1eV90aW1lcyIsImJ1eV90b3RhbCIsIm5vdGUiLCJjcmVhdGVfZGF0ZSIsInVwZGF0ZV9kYXRlIiwiZGVsX2ZsZyIsInF1ZXJ5SW5zZXJ0IiwiZSIsImlFcnJvciIsImN1c3RvbWVyX2FkZHJlc3NfaWQiLCJpZCIsIm1haWxtYWdhX2ZsZyIsImNvdXBvbkNkIiwicmFuZG9tQnl0ZXMiLCJ0b1N0cmluZyIsInN1YnN0cmluZyIsImNvdXBvbk5hbWUiLCJkaXNjb3VudFByaWNlIiwicG9pbnQiLCJjb3Vwb25faWQiLCJjb3Vwb25fY2QiLCJjb3Vwb25fdHlwZSIsImNvdXBvbl9uYW1lIiwiZGlzY291bnRfdHlwZSIsImNvdXBvbl91c2VfdGltZSIsImNvdXBvbl9yZWxlYXNlIiwiZGlzY291bnRfcHJpY2UiLCJkaXNjb3VudF9yYXRlIiwiZW5hYmxlX2ZsYWciLCJjb3Vwb25fbWVtYmVyIiwiY291cG9uX2xvd2VyX2xpbWl0IiwiYXZhaWxhYmxlX2Zyb21fZGF0ZSIsImF2YWlsYWJsZV90b19kYXRlIiwicHVibGlzaCIsInByb2ZpbGUiLCJkYiIsIk1vbmdvQ29sbGVjdGlvbiIsInBsdWciLCJwcm9qZWN0aW9uIiwiY29sbCIsImdldCIsImNvbGxlY3Rpb24iLCJmaW5kIiwidG9BcnJheSIsImFnZ3JlZ2F0ZSIsIkl0ZW1Db250cm9sbGVyIiwibW9kZWwiLCJjbGFzczEiLCJjbGFzczIiLCJpdGVtY29uIiwiaW5pdCIsInVwbG9hZGVkIiwic2V0SW1hZ2UiLCJjbGVhbkltYWdlIiwiTW9uZ29EQkZpbHRlciIsIkN1YmUzQXBpIiwiaXRlbXNEQiIsIml0ZW1Db250cm9sbGVyIiwidGFyZ2V0REIiLCJjdWJlM0RCIiwiYXBpIiwiaXRlbSIsImNvbnRleHQiLCJxdWFudGl0eSIsImdldFN0b2NrIiwiX2lkIiwidXBkYXRlU3RvY2siLCJtYWxsIiwic2hhcmFrdVNob3AiLCJwcm9kdWN0X2NsYXNzX2lkIiwiY29sIiwiY3ViZUl0ZW0iLCJjb252ZXJ0SXRlbUN1YmUzIiwiY3JlYXRvcl9pZCIsImluc2VydFJlcyIsInByb2R1Y3RDcmVhdGUiLCJ1cGRhdGUiLCIkc2V0IiwiaVN1Y2Nlc3MiLCJwcm9kdWN0SW1hZ2VVcGRhdGUiLCJwcm9kdWN0VXBkYXRlIiwicHJvZHVjdFRhZ1VwZGF0ZSIsIm5ld0xvY2FsIiwiUGFja2V0IiwiZnNFeHRyYSIsImljb252IiwiYXJjaGl2ZXIiLCJwcmVmaXgiLCJwYWNrZXQiLCJwYWNrZXRTaXplIiwicmVtb3ZlIiwid29ya2RpciIsIm1rZGlyIiwiY2QiLCJmaWVsZHMiLCJoZWFkZXIiLCJtYXAiLCJqb2luIiwib25QYWNrZXRTdGFydCIsInBhY2tldENvdW50Iiwic2xpY2UiLCJjc3ZGaWxlTmFtZSIsImFwcGVuZEZpbGUiLCJlbmNvZGUiLCJvblBhY2tldCIsImFyZyIsInlhdWN0IiwiaW1nIiwiaW1hZ2VzIiwiaW1nU3JjIiwiaW1nVGd0IiwiYWNjZXNzIiwiY29weUZpbGUiLCJvblBhY2tldEVuZCIsInppcCIsInppcG5hbWUiLCJvdXRwdXQiLCJjcmVhdGVXcml0ZVN0cmVhbSIsInBpcGUiLCJkaXJlY3RvcnkiLCJmaW5hbGl6ZSIsIm1pblF1YW50aXR5IiwiY29udmVydEl0ZW1ZYXVjdCIsInN1Ym1pdCIsImNsb3NlIiwiZXhwb3J0IiwiQ29uZmlncyIsIk1vbmdvIiwiQ29sbGVjdGlvbiIsImlkR2VuZXJhdGlvbiIsInNpZnQiLCJtb2JqZWN0IiwiR3JvdXBCYXNlIiwiRmlsdGVycyIsImNvbnN0cnVjdG9yIiwiZmlsdGVySWQiLCJmaW5kT25lIiwiZ2V0UGx1ZyIsInR5cGUiLCJteXNxbCIsImltcG9ydCIsIm9uUmVzdWx0Iiwib25FcnJvciIsInRhYmxlIiwic3RyZWFtaW5nUXVlcnkiLCJFcnJvciIsImNhbGxiYWNrcyIsImdldFByb2ZpbGUiLCJmaWx0ZXJzIiwicHVzaCIsImNvdW50IiwidW5lc2NhcGUiLCJleGFtIiwiR3JvdXBzIiwicGxhdGZvcm1QbHVnIiwiY2FsbGJhY2siLCJncm91cElkIiwia2V5IiwiY3VyIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJmb3JFYWNoIiwiaW5kZXgiLCJjYXRjaCIsIm15c3FsXyIsInByb2R1Y3RDbGFzc0lkIiwicXVlcnlVcGRhdGUiLCJzdG9jayIsInN0b2NrX3VubGltaXRlZCIsImNyZWF0b3JJZCIsInRhZ29mZiIsInByb2R1Y3RfaWQiLCJ0YWdvbiIsImNvdW50UmVzIiwidGFnU2V0IiwidGFncyIsInNldCIsInByb2R1Y3RJZCIsImkiLCJsZW5ndGgiLCJmaWxlX25hbWUiLCJyYW5rIiwidXBkYXRlRGF0YSIsImtleXMiLCJrIiwiZGVzY3JpcHRpb25fbGlzdCIsInNlYXJjaF93b3JkIiwiZnJlZV9hcmVhIiwiY2xhc3NfY2F0ZWdvcnlfaWQxIiwiY2xhc3NfY2F0ZWdvcnlfaWQyIiwiZGVsaXZlcnlfZGF0ZV9pZCIsInNhbGVfbGltaXQiLCJwcm9kdWN0X3N0b2NrX2lkIiwiREJGaWx0ZXJGYWN0b3J5IiwiREJGaWx0ZXIiLCJNeXNxbERCRmlsdGVyIiwiTW9uZ29DbGllbnQiLCJpbnN0YW5jZSIsImZhY3RvcnkiLCJnZXRQbHVnXyIsImdldENyZWRfIiwiZ2V0UHJvZmlsZV8iLCJzZXRJbXBvcnRGdW5jdGlvbl8iLCJmbiIsIml0ZXJhdG9ycyIsImNvdW50ZXIiLCJmIiwibGltaXQiLCJjIiwiY2xpZW50IiwiY29ubmVjdCIsInVyaSIsImRhdGFiYXNlIiwiYWRkQ3Vyc29yRmxhZyIsImhhc05leHQiLCJuZXh0IiwiSXRlbXMiLCJQcm9kdWN0cyIsIml0ZW1JZCIsInByb2plY3QiLCJwcm9kdWN0UGFjayIsInByb2R1Y3QiLCJxdWFudGl0aWVzIiwicHJvZHVjdFNrdSIsInF1YW50aXR5U2t1Iiwic3RvY2tBcnJheSIsIk1hdGgiLCJtaW4iLCJhcHBseSIsImZldGNoIiwiY2xhc3MxX3ZhbHVlIiwiY2xhc3MyX3ZhbHVlIiwidXBkYXRlTWFueSIsIiRwdXNoIiwiJGVhY2giLCJnZXRWYXJpYXRpb24iLCJsYWJlbCIsImN1cnJlbnQiLCJkZWxpdmVyeSIsInZhbHVlIiwiY2xhc3MxX25hbWUiLCJjbGFzczJfbmFtZSIsImF0dHJzIiwicyIsInZhcmlhdGlvbnMiLCIkbWF0Y2giLCJPYmplY3QiLCJhc3NpZ24iLCIkcHJvamVjdCIsIiRzb3J0IiwicHJvcHMiLCJnZXRNb2RlbENsYXNzIiwibW9kZWxDbGFzcyIsImNvbnZEZWxpdiIsInByb2R1Y3RUeXBlSWQiLCJkZWxpdmVyeUZlZSIsImF0dHIiLCJ2YXJpYXRpb24iLCJ2YXJpYXRpb25IdG1sIiwiZGVzY3JpcHRpb25EZXRhaWwiLCJqYW5fY29kZSIsImRlc2NyaXB0aW9uX2RldGFpbCIsImRlc2NyaXB0aW9uIiwicHJvZHVjdF9jb2RlIiwicHJpY2UwMSIsInJldGFpbF9wcmljZSIsInByaWNlMDIiLCJzYWxlc19wcmljZSIsInByb2R1Y3RfdHlwZV9pZCIsImRlbGl2ZXJ5X2ZlZSIsImRlZiIsImltZ1ByZWZpeCIsImNhdGVnb3J5IiwidXRpbEVycm9yIiwicGFyc2UiLCJtZXNzYWdlIiwiZmlsZU5hbWUiLCJsaW5lTnVtYmVyIiwiY29sdW1uTnVtYmVyIiwic3RhY2siLCJtb21lbnQiLCJwb29sIiwiY3JlYXRlUG9vbCIsInByb2ZpbGVNdWx0aSIsIm11bHRpcGxlU3RhdGVtZW50cyIsInBvb2xNdWx0aSIsImZvcm1hdERhdGUiLCJkYXRlIiwiZm9ybWF0IiwicmVwbGFjZSIsImdldENvbiIsInRoZW4iLCJjb24iLCJyZWxlYXNlIiwicXVlcnlJbnNlcnRfIiwiaW5zZXJ0SWQiLCJkYXRhU3FsIiwiTWFwIiwiZXNjYXBlIiwidmFsdWVzIiwidXBkYXRlcyIsInF1ZXJ5TXVsdGkiLCJwb29sU3dhcCIsInN0YXJ0VHJhbnNhY3Rpb24iLCJjb21taXQiLCJyb2xsYmFjayIsIm9uIiwicGF1c2UiLCJyZXN1bWUiLCJnZXRDb25uZWN0aW9uIiwiaXRlcmF0b3IiLCJzZXR1cEl0ZXJhdG9yIiwiSXRlcmF0b3IiLCJyZWMiLCJyZXN1bHQiLCJ0b3RhbCIsIm5ld1JlY29yZCIsInN1Y2Nlc3MiLCJlcnJvck9jdXJyZWQiLCJpdGVFcnJvciIsInBoYUVycm9yIiwidHJhY2UiLCJyZWNvcmRzIiwibGFzdEVycm9yIl0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLEVBQUo7QUFBT0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0wsU0FBR0ssQ0FBSDtBQUFLOztBQUFqQixDQUEzQixFQUE4QyxDQUE5QztBQUFpRCxJQUFJQyxNQUFKO0FBQVdMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUUsVUFBSjtBQUFlTixPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYixFQUEyQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0UsaUJBQVdGLENBQVg7QUFBYTs7QUFBekIsQ0FBM0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSUcsT0FBSjtBQUFZUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUNBQVIsQ0FBYixFQUE0RDtBQUFDSyxVQUFRSCxDQUFSLEVBQVU7QUFBQ0csY0FBUUgsQ0FBUjtBQUFVOztBQUF0QixDQUE1RCxFQUFvRixDQUFwRjtBQWFoTyxJQUFJSSx1QkFBdUJGLFlBQTNCO0FBRUEsTUFBTUcsUUFBUSxlQUFkLEMsQ0FFQTs7QUFDQUMsT0FBT0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJILEtBQTNCLEVBQWtDRCxvQkFBbEM7QUFDQUUsT0FBT0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJILEtBQTNCLEVBQWtDLENBQUNJLEdBQUQsRUFBTUMsSUFBTixLQUFlO0FBQy9DO0FBRUEsUUFBTUMsU0FBU0MsT0FBT0MsU0FBUCxDQUFpQmxCLEdBQUdtQixRQUFwQixDQUFmO0FBQ0EsUUFBTUMsU0FBU0gsT0FBT0MsU0FBUCxDQUFpQmxCLEdBQUdxQixTQUFwQixDQUFmO0FBQ0EsUUFBTUMsV0FBV2hCLFFBQWpCOztBQUVBLE9BQUssSUFBSWlCLElBQVQsSUFBaUJULElBQUlVLEtBQUosQ0FBVUQsSUFBM0IsRUFBaUM7QUFDL0IsVUFBTUUsT0FBT1QsT0FBT08sS0FBS0csSUFBWixDQUFiLENBRCtCLENBRS9CO0FBQ0E7O0FBQ0EsUUFBSUMsV0FBWSxHQUFFckIsUUFBUyxNQUEzQixDQUorQixDQU0vQjs7QUFDQSxRQUFJc0IsV0FBV2QsSUFBSWUsSUFBSixDQUFTQyxRQUFULEdBQW9CLEdBQXBCLEdBQTBCSCxRQUF6QyxDQVArQixDQVMvQjtBQUVBOztBQUNBLFFBQUlJLE1BQU07QUFDUlQsZ0JBQVVBLFFBREY7QUFFUlUsc0JBQWdCVCxLQUFLVSxJQUZiO0FBR1JDLHdCQUFrQlA7QUFIVixLQUFWOztBQU1BLFFBQUc7QUFDRFAsYUFBT1EsUUFBUCxFQUFpQkgsSUFBakI7QUFDRCxLQUZELENBR0EsT0FBTVUsR0FBTixFQUFVO0FBQ1JKLFVBQUlLLEtBQUosR0FBWUQsR0FBWjtBQUNEOztBQUNEM0IsWUFBUTZCLE1BQVIsQ0FBZU4sR0FBZjtBQUVBLFdBQU9SLElBQVA7QUFFRDs7QUFBQTtBQUNEUixPQUFLdUIsU0FBTCxDQUFlLEdBQWY7QUFDQXZCLE9BQUt3QixHQUFMLENBQVNDLEtBQUtDLFNBQUwsQ0FBZTtBQUN0Qm5CLGNBQVVBLFFBRFk7QUFFdEJvQixhQUFTNUIsSUFBSWUsSUFBSixDQUFTQztBQUZJLEdBQWYsQ0FBVDtBQUtELENBMUNELEU7Ozs7Ozs7Ozs7O0FDbkJBLElBQUlhLE1BQUo7QUFBVzFDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzQyxhQUFPdEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFO0FBQTBFLElBQUl3QyxNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQWxELEVBQXlFLENBQXpFO0FBQTRFLElBQUl5QyxLQUFKLEVBQVVDLFlBQVY7QUFBdUI5QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUNBQVIsQ0FBYixFQUF3RDtBQUFDMkMsUUFBTXpDLENBQU4sRUFBUTtBQUFDeUMsWUFBTXpDLENBQU47QUFBUSxHQUFsQjs7QUFBbUIwQyxlQUFhMUMsQ0FBYixFQUFlO0FBQUMwQyxtQkFBYTFDLENBQWI7QUFBZTs7QUFBbEQsQ0FBeEQsRUFBNEcsQ0FBNUc7QUFBK0csSUFBSTJDLE1BQUo7QUFBVy9DLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQ0FBUixDQUFiLEVBQXlEO0FBQUM2QyxTQUFPM0MsQ0FBUCxFQUFTO0FBQUMyQyxhQUFPM0MsQ0FBUDtBQUFTOztBQUFwQixDQUF6RCxFQUErRSxDQUEvRTtBQWExYyxJQUFJNEMsTUFBTSxTQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLFVBQWQsRUFBMEJFLE1BQTFCO0FBQUEsb0NBQWtDO0FBQ2hDLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiLENBRGdDLENBR2hDO0FBQ0E7O0FBRUEsVUFBSVEsU0FBUyxJQUFJTCxNQUFKLENBQVdHLE9BQU9HLFdBQWxCLENBQWIsQ0FOZ0MsQ0FPaEM7QUFFQTtBQUNBOztBQUVBLFVBQUlDLFlBQVksZ0JBQWhCO0FBRUEsVUFBSUMsUUFBUSxJQUFJWixLQUFKLENBQVVPLE9BQU9NLEdBQVAsQ0FBV0MsSUFBckIsQ0FBWjtBQUVBLG9CQUFNTixPQUFPTyxLQUFQLENBQWEsd0JBQWIsRUFDSiwrQkFBWTtBQUNWLHNCQUFNSCxNQUFNSSxLQUFOLENBQVlMLFNBQVosQ0FBTjtBQUNELE9BRkQsQ0FESSxDQUFOLEVBaEJnQyxDQXFCaEM7QUFDQTs7QUFFQSxvQkFBTUgsT0FBT08sS0FBUCxDQUFhLHVCQUFiLEVBQ0osK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCQyxzQkFBbUJDLE1BQVAsNkJBQWtCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsZ0JBQUlDLE1BQU87Ozs7OzBCQUtHRCxPQUFPRSxXQUFZLE1BQUtGLE9BQU9HLE1BQU8sTUFBS0gsT0FBT0ksR0FBSSxNQUFLSixPQUFPSyxHQUFJLE1BQUtMLE9BQU9NLFVBQVcsTUFBS04sT0FBT08sSUFBSyxNQUFLUCxPQUFPUSxNQUFPLE1BQUtSLE9BQU9TLE1BQU8sTUFBS1QsT0FBT1UsTUFBTyxNQUFLVixPQUFPVyxNQUFPLE1BQUtYLE9BQU9ZLFlBQWEsTUFBS1osT0FBT2EsS0FBTSxNQUFLYixPQUFPYyxLQUFNLE1BQUtkLE9BQU9lLE9BQVEsTUFBS2YsT0FBT2dCLE1BQU8sTUFBS2hCLE9BQU9pQixNQUFPLE1BQUtqQixPQUFPa0IsS0FBTSxNQUFLbEIsT0FBT21CLEtBQU0sTUFBS25CLE9BQU9vQixLQUFNLE1BQUtwQixPQUFPcUIsS0FBTSxNQUFLckIsT0FBT3NCLEtBQU0sTUFBS3RCLE9BQU91QixLQUFNLE1BQUt2QixPQUFPd0IsS0FBTSxNQUFLeEIsT0FBT3lCLEtBQU0sTUFBS3pCLE9BQU8wQixRQUFTLE1BQUsxQixPQUFPMkIsSUFBSyxNQUFLM0IsT0FBTzRCLFVBQVcsTUFBSzVCLE9BQU82QixjQUFlLE1BQUs3QixPQUFPOEIsYUFBYyxNQUFLOUIsT0FBTytCLFNBQVUsTUFBSy9CLE9BQU9nQyxTQUFVLE1BQUtoQyxPQUFPaUMsSUFBSyxNQUFLakMsT0FBT2tDLFdBQVksTUFBS2xDLE9BQU9tQyxXQUFZLE1BQUtuQyxPQUFPb0MsT0FBUTs7aUJBTGxzQjs7QUFTQSxnQkFBSTtBQUNGLDRCQUFNNUMsTUFBTTZDLFdBQU4sQ0FDSixjQURJLEVBQ1k7QUFDZG5DLDZCQUFhRixPQUFPRSxXQUROO0FBRWRDLHdCQUFRSCxPQUFPRyxNQUZEO0FBR2RDLHFCQUFLSixPQUFPSSxHQUhFO0FBSWRDLHFCQUFLTCxPQUFPSyxHQUpFO0FBS2RDLDRCQUFZTixPQUFPTSxVQUxMO0FBTWRDLHNCQUFNUCxPQUFPTyxJQU5DO0FBT2RDLHdCQUFRUixPQUFPUSxNQVBEO0FBUWRDLHdCQUFRVCxPQUFPUyxNQVJEO0FBU2RDLHdCQUFRVixPQUFPVSxNQVREO0FBVWRDLHdCQUFRWCxPQUFPVyxNQVZEO0FBV2RDLDhCQUFjWixPQUFPWSxZQVhQO0FBWWRDLHVCQUFPYixPQUFPYSxLQVpBO0FBYWRDLHVCQUFPZCxPQUFPYyxLQWJBO0FBY2RDLHlCQUFTZixPQUFPZSxPQWRGO0FBZWRDLHdCQUFRaEIsT0FBT2dCLE1BZkQ7QUFnQmRDLHdCQUFRakIsT0FBT2lCLE1BaEJEO0FBaUJkQyx1QkFBT2xCLE9BQU9rQixLQWpCQTtBQWtCZEMsdUJBQU9uQixPQUFPbUIsS0FsQkE7QUFtQmRDLHVCQUFPcEIsT0FBT29CLEtBbkJBO0FBb0JkQyx1QkFBT3JCLE9BQU9xQixLQXBCQTtBQXFCZEMsdUJBQU90QixPQUFPc0IsS0FyQkE7QUFzQmRDLHVCQUFPdkIsT0FBT3VCLEtBdEJBO0FBdUJkQyx1QkFBT3hCLE9BQU93QixLQXZCQTtBQXdCZEMsdUJBQU96QixPQUFPeUIsS0F4QkE7QUF5QmRDLDBCQUFVMUIsT0FBTzBCLFFBekJIO0FBMEJkQyxzQkFBTTNCLE9BQU8yQixJQTFCQztBQTJCZEMsNEJBQVk1QixPQUFPNEIsVUEzQkw7QUE0QmRDLGdDQUFnQjdCLE9BQU82QixjQTVCVDtBQTZCZEMsK0JBQWU5QixPQUFPOEIsYUE3QlI7QUE4QmRDLDJCQUFXL0IsT0FBTytCLFNBOUJKO0FBK0JkQywyQkFBV2hDLE9BQU9nQyxTQS9CSjtBQWdDZEMsc0JBQU1qQyxPQUFPaUMsSUFoQ0M7QUFpQ2RDLDZCQUFhbEMsT0FBT2tDLFdBakNOO0FBa0NkQyw2QkFBYW5DLE9BQU9tQyxXQWxDTjtBQW1DZEMseUJBQVNwQyxPQUFPb0M7QUFuQ0YsZUFEWixDQUFOO0FBdUNELGFBeENELENBd0NFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWhFMkIsQ0FrRTVCOzs7QUFDQSxnQkFBSTtBQUNGLDRCQUFNOUMsTUFBTTZDLFdBQU4sQ0FDSixzQkFESSxFQUNvQjtBQUN0QkcscUNBQXFCLElBREM7QUFFdEJ0Qyw2QkFBYUYsT0FBT0UsV0FGRTtBQUd0QkksNEJBQVlOLE9BQU9NLFVBSEc7QUFJdEJDLHNCQUFNUCxPQUFPTyxJQUpTO0FBS3RCQyx3QkFBUVIsT0FBT1EsTUFMTztBQU10QkMsd0JBQVFULE9BQU9TLE1BTk87QUFPdEJDLHdCQUFRVixPQUFPVSxNQVBPO0FBUXRCQyx3QkFBUVgsT0FBT1csTUFSTztBQVN0QkMsOEJBQWNaLE9BQU9ZLFlBVEM7QUFVdEJDLHVCQUFPYixPQUFPYSxLQVZRO0FBV3RCQyx1QkFBT2QsT0FBT2MsS0FYUTtBQVl0QkMseUJBQVNmLE9BQU9lLE9BWk07QUFhdEJDLHdCQUFRaEIsT0FBT2dCLE1BYk87QUFjdEJDLHdCQUFRakIsT0FBT2lCLE1BZE87QUFldEJFLHVCQUFPbkIsT0FBT21CLEtBZlE7QUFnQnRCQyx1QkFBT3BCLE9BQU9vQixLQWhCUTtBQWlCdEJDLHVCQUFPckIsT0FBT3FCLEtBakJRO0FBa0J0QkMsdUJBQU90QixPQUFPc0IsS0FsQlE7QUFtQnRCQyx1QkFBT3ZCLE9BQU91QixLQW5CUTtBQW9CdEJDLHVCQUFPeEIsT0FBT3dCLEtBcEJRO0FBcUJ0QlUsNkJBQWFsQyxPQUFPa0MsV0FyQkU7QUFzQnRCQyw2QkFBYW5DLE9BQU9tQyxXQXRCRTtBQXVCdEJDLHlCQUFTcEMsT0FBT29DO0FBdkJNLGVBRHBCLENBQU47QUEyQkQsYUE1QkQsQ0E0QkUsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBakcyQixDQW1HNUI7OztBQUNBLGdCQUFJO0FBQ0YsNEJBQU05QyxNQUFNNkMsV0FBTixDQUNKLHVCQURJLEVBQ3FCO0FBQ3ZCSSxvQkFBSSxJQURtQjtBQUV2QnZDLDZCQUFhRixPQUFPRSxXQUZHO0FBR3ZCd0MsOEJBQWMxQyxPQUFPMEMsWUFIRTtBQUl2QlIsNkJBQWFsQyxPQUFPa0MsV0FKRztBQUt2QkMsNkJBQWFuQyxPQUFPbUMsV0FMRztBQU12QkMseUJBQVNwQyxPQUFPb0M7QUFOTyxlQURyQixDQUFOO0FBVUQsYUFYRCxDQVdFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWpIMkIsQ0FtSDVCOzs7QUFFQSxnQkFBSUssV0FBV2hFLE9BQU9pRSxXQUFQLENBQW1CLENBQW5CLEVBQXNCQyxRQUF0QixDQUErQixRQUEvQixFQUF5Q0MsU0FBekMsQ0FBbUQsQ0FBbkQsRUFBc0QsRUFBdEQsQ0FBZjtBQUVBLGdCQUFJQyxhQUFjLEdBQUUvQyxPQUFPUSxNQUFPLElBQUdSLE9BQU9TLE1BQU8sbUJBQWtCVCxPQUFPRSxXQUFZLEVBQXhGO0FBRUEsZ0JBQUk4QyxnQkFBZ0JoRCxPQUFPaUQsS0FBUCxHQUFlLEdBQW5DOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUlwRCxvQkFBWUwsTUFBTTZDLFdBQU4sQ0FDZCxZQURjLEVBQ0E7QUFDWmEsMkJBQVcsSUFEQztBQUVaQywyQkFBV1IsUUFGQztBQUdaUyw2QkFBYSxDQUhEO0FBR0k7QUFDaEJDLDZCQUFhTixVQUpEO0FBS1pPLCtCQUFlLENBTEg7QUFNWkMsaUNBQWlCLENBTkw7QUFPWkMsZ0NBQWdCLENBUEo7QUFRWkMsZ0NBQWdCVCxhQVJKO0FBU1pVLCtCQUFlLElBVEg7QUFVWkMsNkJBQWEsQ0FWRDtBQVdaQywrQkFBZSxDQVhIO0FBWVpDLG9DQUFvQixJQVpSO0FBYVozRCw2QkFBYUYsT0FBT0UsV0FiUjtBQWNaNEQscUNBQXFCLHFCQWRUO0FBZVpDLG1DQUFtQixxQkFmUDtBQWdCWjNCLHlCQUFTO0FBaEJHLGVBREEsRUFrQlg7QUFDREYsNkJBQWEsT0FEWjtBQUVEQyw2QkFBYTtBQUZaLGVBbEJXLENBQVosQ0FBSjtBQXVCRCxhQXhCRCxDQXdCRSxPQUFPRyxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRixXQXRKVztBQURpQixTQUFmLEVBeUpUQSxDQUFQLDZCQUFhO0FBQ1hsRCxpQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELFNBRkQsQ0F6SmdCLENBQVosQ0FBSjtBQThKQSxlQUFPekMsR0FBUDtBQUNELE9BaEtELENBREksQ0FBTjtBQW1LQSxhQUFPVCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0E1TEQ7QUFBQSxHQUZhOztBQWdNUCx1QkFBTixDQUE2QkMsT0FBN0I7QUFBQSxvQ0FBc0M7QUFDcEMsVUFBSUMsS0FBSyxJQUFJdEYsS0FBSixDQUFVcUYsT0FBVixDQUFUO0FBQ0EsVUFBSXBFLG9CQUFZcUUsR0FBR3RFLEtBQUgsQ0FBUyxnQkFBVCxDQUFaLENBQUo7QUFDQSxhQUFPQyxHQUFQO0FBQ0QsS0FKRDtBQUFBOztBQWhNYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSXNFLGVBQUo7QUFBb0JsSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDZ0ksa0JBQWdCOUgsQ0FBaEIsRUFBa0I7QUFBQzhILHNCQUFnQjlILENBQWhCO0FBQWtCOztBQUF0QyxDQUFqRCxFQUF5RixDQUF6RjtBQUE0RixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRzNILElBQUk0QyxNQUFNLGtCQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLE9BQWQsRUFBdUJtRixJQUF2QixFQUE2QnhFLFFBQVEsRUFBckMsRUFBeUN5RSxhQUFhLEVBQXREO0FBQUEsb0NBQTBEO0FBQ3hELFVBQUlDLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQkEsS0FBS0ksVUFBL0IsQ0FBYixDQUFKO0FBQ0EsVUFBSTNFLG9CQUFZeUUsS0FBS0csSUFBTCxDQUFVN0UsS0FBVixFQUFpQjtBQUFDeUUsb0JBQVlBO0FBQWIsT0FBakIsRUFBMkNLLE9BQTNDLEVBQVosQ0FBSjtBQUNBLGFBQU83RSxHQUFQO0FBQ0QsS0FKRDtBQUFBLEdBRmE7O0FBUWIsR0FBUSxHQUFFWixHQUFJLFlBQWQsRUFBNEJtRixJQUE1QixFQUFrQ3hFLFFBQVEsRUFBMUM7QUFBQSxvQ0FBOEM7QUFDNUMsVUFBSTBFLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQkEsS0FBS0ksVUFBL0IsQ0FBYixDQUFKO0FBQ0EsVUFBSTNFLG9CQUFZeUUsS0FBS0ssU0FBTCxDQUFlL0UsS0FBZixFQUFzQjhFLE9BQXRCLEVBQVosQ0FBSjtBQUNBLGFBQU83RSxHQUFQO0FBQ0QsS0FKRDtBQUFBOztBQVJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJK0UsY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFwRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBR3BILElBQUk0QyxNQUFNLGFBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjs7Ozs7QUFLQSxHQUFRLEdBQUVELEdBQUksV0FBZCxFQUEyQm1GLElBQTNCLEVBQWlDOUcsUUFBakMsRUFBMkN1SCxLQUEzQyxFQUFrREMsU0FBUyxJQUEzRCxFQUFpRUMsU0FBUyxJQUExRTtBQUFBLG9DQUFnRjtBQUM5RSxVQUFJQyxVQUFVLElBQUlKLGNBQUosRUFBZDtBQUNBLG9CQUFNSSxRQUFRQyxJQUFSLENBQWFiLElBQWIsQ0FBTjtBQUNBLFVBQUljLHlCQUFpQkYsUUFBUUcsUUFBUixDQUFpQjdILFFBQWpCLEVBQTJCdUgsS0FBM0IsRUFBa0NDLE1BQWxDLEVBQTBDQyxNQUExQyxDQUFqQixDQUFKO0FBQ0EsYUFBT0csUUFBUDtBQUNELEtBTEQ7QUFBQSxHQVBhOztBQWNiOzs7QUFHQSxHQUFRLEdBQUVqRyxHQUFJLGFBQWQsRUFBNkJtRixJQUE3QixFQUFtQ1MsS0FBbkMsRUFBMENDLFNBQVMsSUFBbkQsRUFBeURDLFNBQVMsSUFBbEU7QUFBQSxvQ0FBd0U7QUFDdEUsVUFBSUMsVUFBVSxJQUFJSixjQUFKLEVBQWQ7QUFDQSxvQkFBTUksUUFBUUMsSUFBUixDQUFhYixJQUFiLENBQU47QUFDQSxvQkFBTVksUUFBUUksVUFBUixDQUFtQlAsS0FBbkIsRUFBMEJDLE1BQTFCLEVBQWtDQyxNQUFsQyxDQUFOO0FBQ0QsS0FKRDtBQUFBOztBQWpCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSWxHLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWdKLGFBQUo7QUFBa0JwSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDa0osZ0JBQWNoSixDQUFkLEVBQWdCO0FBQUNnSixvQkFBY2hKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUlpSixRQUFKO0FBQWFySixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDbUosV0FBU2pKLENBQVQsRUFBVztBQUFDaUosZUFBU2pKLENBQVQ7QUFBVzs7QUFBeEIsQ0FBcEQsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSXVJLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQVlqZSxJQUFJNEMsTUFBTSxNQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxjQUFkLEVBQThCRSxNQUE5QjtBQUFBLG9DQUFzQztBQUNwQztBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsVUFBSVEsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBQ0EsVUFBSXVCLGlCQUFpQixJQUFJWixjQUFKLEVBQXJCO0FBQ0Esb0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTjtBQUVBLFVBQUlFLFdBQVcsSUFBSTdHLEtBQUosQ0FBVU8sT0FBT3VHLE9BQWpCLENBQWY7QUFDQSxVQUFJQyxNQUFNLElBQUlMLFFBQUosQ0FBYUcsUUFBYixDQUFWO0FBRUEsb0JBQU1yRyxPQUFPTyxLQUFQLENBQ0osT0FESSxFQUVKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSUMseUJBQWlCTixlQUFlTyxRQUFmLENBQXdCSCxLQUFLSSxHQUE3QixDQUFqQixDQUFKO0FBQ0EsMEJBQU1MLElBQUlNLFdBQUosQ0FBZ0JMLEtBQUtNLElBQUwsQ0FBVUMsV0FBVixDQUFzQkMsZ0JBQXRDLEVBQXdETixRQUF4RCxDQUFOO0FBQ0QsV0FIUztBQUZtQixTQUFmLENBQVosQ0FBSjtBQU9BLGVBQU9qRyxHQUFQO0FBQ0QsT0FURCxDQUZJLENBQU47QUFhQSxhQUFPVCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0F6QkQ7QUFBQSxHQUxhOztBQWdDYjtBQUNBO0FBRUEsR0FBUSxHQUFFL0UsR0FBSSxZQUFkLEVBQTRCRSxNQUE1QjtBQUFBLG9DQUFvQztBQUNsQyxVQUFJRSxTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWI7QUFDQSxVQUFJd0IsV0FBVyxJQUFJN0csS0FBSixDQUFVTyxPQUFPdUcsT0FBakIsQ0FBZjtBQUNBLFVBQUlDLE1BQU0sSUFBSUwsUUFBSixDQUFhRyxRQUFiLENBQVY7QUFFQSxVQUFJRCxpQkFBaUIsSUFBSVosY0FBSixFQUFyQjtBQUNBLG9CQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOa0MsQ0FRbEM7O0FBQ0EsVUFBSW5HLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSixlQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJUSxNQUFNUixRQUFRckIsVUFBbEI7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSThCLHlCQUFpQmQsZUFBZWUsZ0JBQWYsQ0FBZ0NwSCxPQUFPcUgsVUFBdkMsRUFBbURaLElBQW5ELENBQWpCLENBQUo7QUFFQSxrQkFBSWEsMEJBQWtCZCxJQUFJZSxhQUFKLENBQWtCSixRQUFsQixDQUFsQixDQUFKLENBSEUsQ0FLRjs7QUFDQSw0QkFBTUQsSUFBSU0sTUFBSixDQUFXO0FBQ2ZYLHFCQUFLSixLQUFLSTtBQURLLGVBQVgsRUFFSDtBQUNEWSxzQkFBTTtBQUNKLHNDQUFvQkgsVUFBVTVHO0FBRDFCO0FBREwsZUFGRyxDQUFOO0FBUUFULHFCQUFPeUgsUUFBUDtBQUNELGFBZkQsQ0FlRSxPQUFPdkUsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0FyQlM7QUFEbUIsU0FBZixFQXdCVEEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQXhCZ0IsQ0FBWixDQUFKO0FBNEJBLGVBQU96QyxHQUFQO0FBQ0QsT0E5QkQsQ0FGSSxDQUFOO0FBa0NBLG9CQUFNVCxPQUFPTyxLQUFQLENBQ0osZ0JBREksRUFFSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFDN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlRLE1BQU1SLFFBQVFyQixVQUFsQjs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJOEIseUJBQWlCZCxlQUFlZSxnQkFBZixDQUFnQ3BILE9BQU9xSCxVQUF2QyxFQUFtRFosSUFBbkQsQ0FBakIsQ0FBSjtBQUVBLDRCQUFNRCxJQUFJbUIsa0JBQUosQ0FBdUJSLFFBQXZCLENBQU47QUFDQSw0QkFBTVgsSUFBSW9CLGFBQUosQ0FBa0JULFFBQWxCLENBQU47QUFDQSw0QkFBTVgsSUFBSXFCLGdCQUFKLENBQXFCVixRQUFyQixDQUFOO0FBRUEsa0JBQUlSLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF3QkgsS0FBS0ksR0FBN0IsQ0FBakIsQ0FBSjtBQUNBLDRCQUFNTCxJQUFJTSxXQUFKLENBQWdCTCxLQUFLTSxJQUFMLENBQVVDLFdBQVYsQ0FBc0JDLGdCQUF0QyxFQUF3RE4sUUFBeEQsQ0FBTjtBQUVBMUcscUJBQU95SCxRQUFQO0FBQ0QsYUFYRCxDQVdFLE9BQU92RSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRixXQWpCUztBQURtQixTQUFmLEVBb0JUQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBcEJnQixDQUFaLENBQUo7QUF3QkEsZUFBT3pDLEdBQVA7QUFDRCxPQTFCRCxDQUZJLENBQU47QUE4QkEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBNUVEO0FBQUE7O0FBbkNhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNkQSxJQUFJbkYsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQU83UixJQUFJNEMsTUFBTSxNQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXVCRSxNQUF2QjtBQUFBLG9DQUErQjtBQUM3QjtBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsVUFBSVEsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBRUEsWUFBTWdELHlCQUFpQjVILE9BQU9TLE9BQVAsQ0FBZSxFQUFmLEVBQTBCd0MsQ0FBUCw2QkFBYTtBQUNyRCxjQUFNQSxDQUFOO0FBQ0QsT0FGeUMsQ0FBbkIsQ0FBakIsQ0FBTjtBQUdBLG9CQUFNbEQsT0FBT08sS0FBUCxDQUNKLFVBREksRUFFSiwrQkFBWTtBQUNWLGVBQU9zSCxRQUFQO0FBQ0QsT0FGRCxDQUZJLENBQU47QUFNQSxhQUFPN0gsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBaEJEO0FBQUE7O0FBTGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ1RBLElBQUluRixNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk2SyxNQUFKO0FBQVdqTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZLLGFBQU83SyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUk4SyxPQUFKO0FBQVlsTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDOEssY0FBUTlLLENBQVI7QUFBVTs7QUFBdEIsQ0FBakMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSStLLEtBQUo7QUFBVW5MLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMrSyxZQUFNL0ssQ0FBTjtBQUFROztBQUFwQixDQUFuQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJZ0wsUUFBSjtBQUFhcEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2dMLGVBQVNoTCxDQUFUO0FBQVc7O0FBQXZCLENBQWpDLEVBQTBELENBQTFEO0FBYWhtQixNQUFNaUwsU0FBUyxRQUFmO0FBQ0EsTUFBTXJJLE1BQU0sT0FBWjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksVUFBZCxFQUEwQkUsTUFBMUI7QUFBQSxvQ0FBa0M7QUFDaEM7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osWUFESSxFQUVKLCtCQUFZO0FBQ1Y7QUFDQTtBQUVBLGNBQU1OLFNBQVMsSUFBSWdHLGFBQUosQ0FBa0JsRyxPQUFPb0csT0FBekIsRUFBa0NwRyxPQUFPOEUsT0FBekMsQ0FBZjtBQUNBLGNBQU11QixpQkFBaUIsSUFBSVosY0FBSixFQUF2QjtBQUNBLHNCQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOVSxDQVFWOztBQUNBLGNBQU1nQyxTQUFTLElBQUlMLE1BQUosQ0FBVy9ILE9BQU9xSSxVQUFsQixDQUFmLENBVFUsQ0FXVjs7QUFDQSxzQkFBTUwsUUFBUU0sTUFBUixDQUFldEksT0FBT3VJLE9BQXRCLENBQU47QUFDQSxzQkFBTVAsUUFBUVEsS0FBUixDQUFjeEksT0FBT3VJLE9BQXJCLENBQU47QUFFQSxZQUFJRSxLQUFLLElBQVQsQ0FmVSxDQWVJOztBQUNkLFlBQUlqSyxXQUFXLElBQWYsQ0FoQlUsQ0FnQlU7O0FBQ3BCLFlBQUlNLE9BQU8sSUFBWCxDQWpCVSxDQWlCTTtBQUVoQjs7QUFDQSxZQUFJNEosU0FBUyxDQUFDLE1BQUQsRUFBUyxNQUFULEVBQWlCLE1BQWpCLEVBQXlCLElBQXpCLEVBQStCLGdCQUEvQixFQUFpRCxNQUFqRCxFQUF5RCxNQUF6RCxFQUFpRSxPQUFqRSxFQUEwRSxJQUExRSxFQUFnRixRQUFoRixFQUEwRixJQUExRixFQUFnRyxNQUFoRyxFQUF3RyxZQUF4RyxFQUFzSCxZQUF0SCxFQUFvSSxNQUFwSSxFQUE0SSxXQUE1SSxFQUF5SixZQUF6SixFQUF1SyxPQUF2SyxFQUFnTCxTQUFoTCxFQUEyTCxPQUEzTCxFQUFvTSxTQUFwTSxFQUErTSxLQUEvTSxFQUFzTixTQUF0TixFQUFpTyxLQUFqTyxFQUF3TyxTQUF4TyxFQUFtUCxLQUFuUCxFQUEwUCxTQUExUCxFQUFxUSxLQUFyUSxFQUE0USxTQUE1USxFQUF1UixLQUF2UixFQUE4UixTQUE5UixFQUF5UyxLQUF6UyxFQUFnVCxTQUFoVCxFQUEyVCxLQUEzVCxFQUFrVSxTQUFsVSxFQUE2VSxLQUE3VSxFQUFvVixTQUFwVixFQUErVixLQUEvVixFQUFzVyxTQUF0VyxFQUFpWCxNQUFqWCxFQUF5WCxVQUF6WCxFQUFxWSxNQUFyWSxFQUE2WSxRQUE3WSxFQUF1WixTQUF2WixFQUFrYSxNQUFsYSxFQUEwYSxNQUExYSxFQUFrYixVQUFsYixFQUE4YixPQUE5YixFQUF1YyxRQUF2YyxFQUFpZCxRQUFqZCxFQUEyZCxXQUEzZCxFQUF3ZSxRQUF4ZSxFQUFrZixLQUFsZixFQUF5ZixjQUF6ZixFQUF5Z0IsU0FBemdCLEVBQW9oQixTQUFwaEIsRUFBK2hCLFlBQS9oQixFQUE2aUIsY0FBN2lCLEVBQTZqQixRQUE3akIsRUFBdWtCLE9BQXZrQixFQUFnbEIsUUFBaGxCLEVBQTBsQixVQUExbEIsRUFBc21CLG1CQUF0bUIsRUFBMm5CLGdCQUEzbkIsRUFBNm9CLFVBQTdvQixFQUF5cEIsbUJBQXpwQixFQUE4cUIsZ0JBQTlxQixFQUFnc0IsVUFBaHNCLEVBQTRzQixtQkFBNXNCLEVBQWl1QixnQkFBanVCLEVBQW12QixVQUFudkIsRUFBK3ZCLG1CQUEvdkIsRUFBb3hCLGdCQUFweEIsRUFBc3lCLFVBQXR5QixFQUFrekIsbUJBQWx6QixFQUF1MEIsZ0JBQXYwQixFQUF5MUIsVUFBejFCLEVBQXEyQixtQkFBcjJCLEVBQTAzQixnQkFBMTNCLEVBQTQ0QixVQUE1NEIsRUFBdzVCLG1CQUF4NUIsRUFBNjZCLGdCQUE3NkIsRUFBKzdCLFVBQS83QixFQUEyOEIsbUJBQTM4QixFQUFnK0IsZ0JBQWgrQixFQUFrL0IsVUFBbC9CLEVBQTgvQixtQkFBOS9CLEVBQW1oQyxnQkFBbmhDLEVBQXFpQyxXQUFyaUMsRUFBa2pDLG9CQUFsakMsRUFBd2tDLGlCQUF4a0MsRUFBMmxDLE1BQTNsQyxFQUFtbUMsV0FBbm1DLEVBQWduQyxTQUFobkMsRUFBMm5DLE9BQTNuQyxFQUFvb0MsZ0JBQXBvQyxDQUFiO0FBQ0EsWUFBSUMsU0FBU0QsT0FBT0UsR0FBUCxDQUFXMUwsS0FBTSxJQUFHQSxDQUFFLEdBQXRCLEVBQTBCMkwsSUFBMUIsQ0FBK0IsR0FBL0IsSUFBc0MsSUFBbkQsQ0FyQlUsQ0F1QlY7O0FBQ0FULGVBQU9VLGFBQVAsR0FBOEJDLFdBQVAsNkJBQXVCO0FBQzVDakssaUJBQU9xSixTQUFTLENBQUMsVUFBVVksV0FBWCxFQUF3QkMsS0FBeEIsQ0FBOEIsQ0FBQyxDQUEvQixDQUFoQjtBQUNBUCxlQUFNLEdBQUV6SSxPQUFPdUksT0FBUSxJQUFHekosSUFBSyxFQUEvQjtBQUNBTixxQkFBWSxHQUFFaUssRUFBRyxJQUFHekksT0FBT2lKLFdBQVksRUFBdkM7QUFDQSx3QkFBTWpCLFFBQVFRLEtBQVIsQ0FBY0MsRUFBZCxDQUFOLEVBSjRDLENBSzVDOztBQUNBLHdCQUFNVCxRQUFRa0IsVUFBUixDQUFtQjFLLFFBQW5CLEVBQTZCeUosTUFBTWtCLE1BQU4sQ0FBYVIsTUFBYixFQUFxQixXQUFyQixDQUE3QixDQUFOO0FBQ0QsU0FQc0IsQ0FBdkIsQ0F4QlUsQ0FpQ1Y7OztBQUNBUCxlQUFPZ0IsUUFBUCxHQUF5QkMsR0FBUCw2QkFBZTtBQUMvQixjQUFJQyxRQUFRRCxJQUFJQyxLQUFoQjtBQUNBLGNBQUk3QyxPQUFPNEMsSUFBSTVDLElBQWYsQ0FGK0IsQ0FHL0I7O0FBQ0EsY0FBSTVGLFNBQVM2SCxPQUFPRSxHQUFQLENBQVcxTCxLQUFLO0FBQUUsbUJBQU9vTSxNQUFNcE0sQ0FBTixJQUFZLElBQUdvTSxNQUFNcE0sQ0FBTixDQUFTLEdBQXhCLEdBQTZCLElBQXBDO0FBQTBDLFdBQTVELEVBQThEMkwsSUFBOUQsQ0FBbUUsR0FBbkUsSUFBMEUsSUFBdkY7QUFDQSx3QkFBTWIsUUFBUWtCLFVBQVIsQ0FBbUIxSyxRQUFuQixFQUE2QnlKLE1BQU1rQixNQUFOLENBQWF0SSxNQUFiLEVBQXFCLFdBQXJCLENBQTdCLENBQU4sRUFMK0IsQ0FNL0I7O0FBQ0EsZUFBSyxJQUFJMEksR0FBVCxJQUFnQjlDLEtBQUsrQyxNQUFyQixFQUE2QjtBQUMzQixnQkFBSUMsU0FBVSxHQUFFekosT0FBT3JCLFFBQVMsSUFBRzRLLEdBQUksRUFBdkM7QUFDQSxnQkFBSUcsU0FBVSxHQUFFakIsRUFBRyxJQUFHYyxHQUFJLEVBQTFCOztBQUNBLGdCQUFJO0FBQ0Y7QUFDQSw0QkFBTXZCLFFBQVEyQixNQUFSLENBQWVELE1BQWYsQ0FBTjtBQUNELGFBSEQsQ0FHRSxPQUFPdkcsQ0FBUCxFQUFVO0FBQ1YsNEJBQU02RSxRQUFRNEIsUUFBUixDQUFpQkgsTUFBakIsRUFBeUJDLE1BQXpCLENBQU47QUFDRDtBQUNGO0FBQ0YsU0FqQmlCLENBQWxCLENBbENVLENBcURWOzs7QUFDQXRCLGVBQU95QixXQUFQLEdBQTRCZCxXQUFQLDZCQUF1QjtBQUMxQyxnQkFBTWUsTUFBTTVCLFNBQVMsS0FBVCxDQUFaO0FBQ0EsZ0JBQU02QixVQUFVdEIsS0FBSyxNQUFyQjtBQUNBLGdCQUFNdUIsU0FBU2hDLFFBQVFpQyxpQkFBUixDQUEwQkYsT0FBMUIsQ0FBZjtBQUNBRCxjQUFJSSxJQUFKLENBQVNGLE1BQVQ7QUFDQUYsY0FBSUssU0FBSixDQUFjMUIsRUFBZCxFQUFrQixLQUFsQjtBQUNBcUIsY0FBSU0sUUFBSjtBQUNELFNBUG9CLENBQXJCLENBdERVLENBK0RWO0FBQ0E7OztBQUVBLFlBQUkxSixvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBRTdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJQyx5QkFBaUJOLGVBQWVPLFFBQWYsQ0FBd0JILEtBQUtJLEdBQTdCLENBQWpCLENBQUosQ0FEaUMsQ0FFakM7O0FBQ0EsZ0JBQUlGLFlBQVlGLEtBQUtNLElBQUwsQ0FBVXVDLEtBQVYsQ0FBZ0JlLFdBQWhDLEVBQTZDO0FBQzNDLGtCQUFJZixzQkFBY2pELGVBQWVpRSxnQkFBZixDQUFnQ3RLLE9BQU8vQyxPQUF2QyxFQUFnRHdKLElBQWhELENBQWQsQ0FBSjtBQUNBLDRCQUFNMkIsT0FBT21DLE1BQVAsQ0FBYztBQUFDakIsdUJBQU9BLEtBQVI7QUFBZTdDLHNCQUFNQTtBQUFyQixlQUFkLENBQU47QUFDRDtBQUNGLFdBUFM7QUFGbUIsU0FBZixDQUFaLENBQUo7QUFXQTJCLGVBQU9vQyxLQUFQO0FBRUEsZUFBTzlKLEdBQVA7QUFDRCxPQWhGRCxDQUZJLENBQU47QUFvRkEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBekZEO0FBQUE7O0FBTGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ2hCQS9ILE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwrQkFBUixDQUFiO0FBQXVERixPQUFPQyxLQUFQLENBQWFDLFFBQVEsc0JBQVIsQ0FBYixFOzs7Ozs7Ozs7OztBQ0F2REYsT0FBTzJOLE1BQVAsQ0FBYztBQUFDQyxXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJQyxLQUFKO0FBQVU3TixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUMyTixRQUFNek4sQ0FBTixFQUFRO0FBQUN5TixZQUFNek4sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUV4QyxNQUFNd04sVUFBVSxJQUFJQyxNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQStCO0FBQUNDLGdCQUFhO0FBQWQsQ0FBL0IsQ0FBaEIsQzs7Ozs7Ozs7Ozs7QUNGUC9OLE9BQU8yTixNQUFQLENBQWM7QUFBQzVLLFVBQU8sTUFBSUE7QUFBWixDQUFkO0FBQW1DLElBQUk4SyxLQUFKO0FBQVU3TixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUMyTixRQUFNek4sQ0FBTixFQUFRO0FBQUN5TixZQUFNek4sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSTROLElBQUo7QUFBU2hPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM0TixXQUFLNU4sQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNk4sT0FBSjtBQUFZak8sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZOLGNBQVE3TixDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEO0FBQStELElBQUk4TixTQUFKO0FBQWNsTyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNnTyxZQUFVOU4sQ0FBVixFQUFZO0FBQUM4TixnQkFBVTlOLENBQVY7QUFBWTs7QUFBMUIsQ0FBakMsRUFBNkQsQ0FBN0Q7QUFhblosTUFBTStOLFVBQVUsSUFBSU4sTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUFnQztBQUM5Q0MsZ0JBQWM7QUFEZ0MsQ0FBaEMsQ0FBaEI7O0FBSU8sTUFBTWhMLE1BQU4sU0FBcUJtTCxTQUFyQixDQUErQjtBQUVwQ0UsY0FBWUMsUUFBWixFQUFzQjtBQUVwQixRQUFJckcsVUFBVW1HLFFBQVFHLE9BQVIsQ0FBZ0I7QUFDNUJ2RSxXQUFLc0U7QUFEdUIsS0FBaEIsQ0FBZDtBQUlBLFVBQU1yRyxPQUFOO0FBRUEsUUFBSUcsT0FBTyxLQUFLb0csT0FBTCxFQUFYOztBQUVBLFlBQVFwRyxLQUFLcUcsSUFBYjtBQUVFLFdBQUssT0FBTDtBQUNFLGFBQUtDLEtBQUwsR0FBYSxJQUFJOUwsS0FBSixDQUFVd0YsS0FBSzFFLElBQWYsQ0FBYjs7QUFDQSxhQUFLaUwsTUFBTCxHQUFjLENBQVFDLFdBQVk1SyxNQUFELElBQVUsQ0FBRSxDQUEvQixFQUFpQzZLLFVBQVd2SSxDQUFELElBQUssQ0FBRSxDQUFsRCw4QkFBd0Q7QUFDcEUsY0FBSXJDLE1BQU8saUJBQWdCbUUsS0FBSzBHLEtBQU0sRUFBdEM7QUFDQSwrQkFBYSxLQUFLSixLQUFMLENBQVdLLGNBQVgsQ0FBMEI5SyxHQUExQixFQUErQjJLLFFBQS9CLEVBQXlDQyxPQUF6QyxDQUFiO0FBQ0QsU0FIYSxDQUFkOztBQUlBOztBQUVGO0FBQ0UsY0FBTSxJQUFJRyxLQUFKLENBQVUsdUJBQVYsQ0FBTjtBQVhKO0FBY0Q7QUFFRDs7Ozs7O0FBSU1sTCxTQUFOLENBQWNtTCxZQUFZLEVBQTFCLEVBQThCSixVQUFpQnZJLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQXhDO0FBQUEsb0NBQXlEO0FBRXZELFVBQUkyQixVQUFVLEtBQUtpSCxVQUFMLEVBQWQsQ0FGdUQsQ0FJdkQ7O0FBQ0FqSCxjQUFRa0gsT0FBUixDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJYLGNBQU0sTUFEYTtBQUVuQjdLLGVBQU87QUFGWSxPQUFyQjtBQUtBLFVBQUl5TCxRQUFRLEVBQVo7O0FBQ0EsV0FBSyxJQUFJaE0sTUFBVCxJQUFtQjRFLFFBQVFrSCxPQUEzQixFQUFvQztBQUNsQ0UsY0FBTWhNLE9BQU9vTCxJQUFiLElBQXFCO0FBQ25CN0ssaUJBQU9QLE9BQU9PLEtBREs7QUFFbkJ5TCxpQkFBTztBQUZZLFNBQXJCO0FBSUQ7O0FBRUQsb0JBQU0sS0FBS1YsTUFBTCxDQUNHM0ssTUFBUCw2QkFBZ0I7QUFDZCxhQUFLLElBQUlYLE1BQVQsSUFBbUI0RSxRQUFRa0gsT0FBM0IsRUFBb0M7QUFDbEMsY0FBSXZMLFFBQVFzSyxRQUFRb0IsUUFBUixDQUFpQmpNLE9BQU9PLEtBQXhCLENBQVo7QUFDQSxjQUFJMkwsT0FBT3RCLEtBQU1ySyxLQUFOLENBQVg7O0FBQ0EsY0FBSTJMLEtBQUt2TCxNQUFMLENBQUosRUFBa0I7QUFDaEJxTCxrQkFBTWhNLE9BQU9vTCxJQUFiLEVBQW1CWSxLQUFuQjs7QUFDQSxnQkFBSSxPQUFPSixVQUFVNUwsT0FBT29MLElBQWpCLENBQVAsS0FBa0MsV0FBdEMsRUFBa0Q7QUFDaEQsNEJBQU1RLFVBQVU1TCxPQUFPb0wsSUFBakIsRUFBdUJ6SyxNQUF2QixDQUFOO0FBQ0Q7O0FBQ0Q7QUFDRDtBQUNGO0FBQ0YsT0FaRCxDQURJLEVBY0o2SyxPQWRJLENBQU4sRUFsQnVELENBbUN2RDs7QUFDQSxhQUFPUSxLQUFQO0FBRUQsS0F0Q0Q7QUFBQTs7QUFoQ29DLEM7Ozs7Ozs7Ozs7O0FDakJ0Q3BQLE9BQU8yTixNQUFQLENBQWM7QUFBQ08sYUFBVSxNQUFJQSxTQUFmO0FBQXlCckwsU0FBTSxNQUFJQTtBQUFuQyxDQUFkO0FBQXlELElBQUlnTCxLQUFKO0FBQVU3TixPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUMyTixRQUFNek4sQ0FBTixFQUFRO0FBQUN5TixZQUFNek4sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFRbk4sTUFBTW1QLFNBQVMsSUFBSTFCLE1BQU1DLFVBQVYsQ0FBcUIsUUFBckIsRUFBK0I7QUFDNUNDLGdCQUFjO0FBRDhCLENBQS9CLENBQWY7O0FBSU8sTUFBTUcsU0FBTixDQUFnQjtBQUlyQkUsY0FBWXBHLE9BQVosRUFBcUI7QUFDbkIsU0FBS0EsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7QUFFRDs7Ozs7OztBQUtBdUcsWUFBVTtBQUNSLFdBQU8sS0FBS3ZHLE9BQUwsQ0FBYXdILFlBQXBCO0FBQ0Q7O0FBRURQLGVBQWE7QUFDWCxXQUFPLEtBQUtqSCxPQUFaO0FBQ0Q7O0FBRURuRSxVQUFRNEwsV0FBa0IxTCxNQUFQLDZCQUFrQixDQUFFLENBQXBCLENBQW5CLEVBQXlDNkssVUFBaUJ2SSxDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUFuRCxFQUFvRSxDQUFFOztBQXJCakQ7O0FBeUJoQixNQUFNeEQsS0FBTixTQUFvQnFMLFNBQXBCLENBQThCO0FBRW5DRSxjQUFZc0IsT0FBWixFQUFxQjtBQUVuQixRQUFJMUgsVUFBVXVILE9BQU9qQixPQUFQLENBQWU7QUFDM0J2RSxXQUFLMkY7QUFEc0IsS0FBZixDQUFkO0FBSUEsVUFBTTFILE9BQU47QUFFQSxRQUFJRyxPQUFPLEtBQUtvRyxPQUFMLEVBQVg7O0FBRUEsWUFBUXBHLEtBQUtxRyxJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UsYUFBS0MsS0FBTCxHQUFhLElBQUk5TCxLQUFKLENBQVV3RixLQUFLMUUsSUFBZixDQUFiOztBQUNBLGFBQUtpTCxNQUFMLEdBQXFCNU0sR0FBUCw2QkFBZTtBQUMzQixjQUFJa0MsTUFBTyxpQkFBZ0JtRSxLQUFLMEcsS0FBTSxZQUFXL00sSUFBSTZOLEdBQUksU0FBUTdOLElBQUkwRSxFQUFHLEdBQXhFO0FBQ0EsK0JBQWEsS0FBS2lJLEtBQUwsQ0FBVzlLLEtBQVgsQ0FBaUJLLEdBQWpCLENBQWI7QUFDRCxTQUhhLENBQWQ7O0FBSUE7O0FBQ0Y7QUFDRSxjQUFNLElBQUkrSyxLQUFKLENBQVUsb0JBQVYsQ0FBTjtBQVRKO0FBWUQ7QUFHRDs7Ozs7O0FBSUFsTCxVQUFRNEwsV0FBa0IxTCxNQUFQLDZCQUFrQixDQUFFLENBQXBCLENBQW5CLEVBQXlDNkssVUFBaUJ2SSxDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUFuRCxFQUFvRTtBQUVsRSxRQUFJdUosTUFBTUwsT0FBTy9HLElBQVAsQ0FBWTtBQUNwQmtILGVBQVMsS0FBSzFILE9BQUwsQ0FBYStCO0FBREYsS0FBWixFQUVQO0FBQ0Q2QixjQUFRO0FBQ043QixhQUFLLENBREM7QUFFTnZELFlBQUksQ0FGRTtBQUdObUosYUFBSztBQUhDO0FBRFAsS0FGTyxDQUFWO0FBVUEsV0FBTyxJQUFJRSxPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBRW5CSCxVQUFJSSxPQUFKLENBQ0UsQ0FBT2xPLEdBQVAsRUFBWW1PLEtBQVosOEJBQXNCO0FBQ3BCLFlBQUk7QUFDRixjQUFJbE0sdUJBQWUsS0FBSzJLLE1BQUwsQ0FBWTVNLEdBQVosQ0FBZixDQUFKO0FBQ0Esd0JBQU0yTixTQUFTMUwsTUFBVCxDQUFOO0FBQ0QsU0FIRCxDQUdFLE9BQU9zQyxDQUFQLEVBQVU7QUFDVnVJLGtCQUFRdkksQ0FBUjtBQUNEOztBQUNELFlBQUk0SixRQUFRLENBQVIsS0FBY0wsSUFBSVIsS0FBSixFQUFsQixFQUErQjtBQUM3QlU7QUFDRDtBQUNGLE9BVkQsQ0FERjtBQWFELEtBaEJJLEVBaUJMSSxLQWpCSyxDQWtCSjdKLENBQUQsSUFBTztBQUNMLFlBQU1BLENBQU47QUFDRCxLQXBCSSxDQUFQO0FBdUJEOztBQWxFa0MsQzs7Ozs7Ozs7Ozs7QUNyQ3JDckcsT0FBTzJOLE1BQVAsQ0FBYztBQUFDcE4sV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSXNOLEtBQUo7QUFBVTdOLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQzJOLFFBQU16TixDQUFOLEVBQVE7QUFBQ3lOLFlBQU16TixDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRXhDLE1BQU1HLFVBQVUsSUFBSXNOLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBK0I7QUFBQ0MsZ0JBQWE7QUFBZCxDQUEvQixDQUFoQixDOzs7Ozs7Ozs7OztBQ0ZQL04sT0FBTzJOLE1BQVAsQ0FBYztBQUFDdEUsWUFBUyxNQUFJQTtBQUFkLENBQWQ7QUFBdUMsSUFBSTFHLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBakQsRUFBdUUsQ0FBdkU7O0FBRTFDLE1BQU1pSixRQUFOLENBQWU7QUFDcEIrRSxjQUFhSyxRQUFRLElBQUk5TCxLQUFKLEVBQXJCLEVBQWtDO0FBQ2hDLFNBQUt3TixNQUFMLEdBQWMxQixLQUFkO0FBQ0Q7O0FBRUt6RSxhQUFOLENBQW1Cb0csY0FBbkIsRUFBbUN2RyxXQUFXLENBQTlDO0FBQUEsb0NBQWlEO0FBQy9DLG9CQUFNLEtBQUtzRyxNQUFMLENBQVlFLFdBQVosQ0FDSixtQkFESSxFQUVILHNCQUFxQkQsY0FBZSxFQUZqQyxFQUdKLEVBSEksRUFHQTtBQUNGRSxlQUFPekcsUUFETDtBQUVGMEcseUJBQWlCLENBRmY7QUFHRnJLLHFCQUFhO0FBSFgsT0FIQSxDQUFOO0FBVUEsb0JBQU0sS0FBS2lLLE1BQUwsQ0FBWUUsV0FBWixDQUNKLG1CQURJLEVBRUgsc0JBQXFCRCxjQUFlLEVBRmpDLEVBR0osRUFISSxFQUdBO0FBQ0ZFLGVBQU96RyxRQURMO0FBRUYzRCxxQkFBYTtBQUZYLE9BSEEsQ0FBTjtBQVFELEtBbkJEO0FBQUE7O0FBcUJNNkUsa0JBQU4sQ0FBd0J2SixJQUF4QjtBQUFBLG9DQUE4QjtBQUM1QixVQUFJZ1AsWUFBWWhQLEtBQUsrSSxVQUFyQjtBQUVBLFVBQUkzRyxNQUFNLEVBQVYsQ0FINEIsQ0FLNUI7O0FBQ0EsVUFBSTZNLFNBQWdCek4sR0FBUCw2QkFBZTtBQUMxQixZQUFJZ0IsTUFBTzs7MkJBRVV4QyxLQUFLa1AsVUFBVyxjQUFhMU4sR0FBSTtPQUZ0RDtBQUlBWSxZQUFJdUwsSUFBSixlQUFlLEtBQUtnQixNQUFMLENBQVl4TSxLQUFaLENBQWtCSyxHQUFsQixDQUFmO0FBQ0QsT0FOWSxDQUFiLENBTjRCLENBYzVCOzs7QUFDQSxVQUFJMk0sUUFBZTNOLEdBQVAsNkJBQWU7QUFDekI7QUFDQSxZQUFJZ0IsTUFBTzs7MkJBRVV4QyxLQUFLa1AsVUFBVyxjQUFhMU4sR0FBSTtPQUZ0RDtBQUlBLFlBQUk0Tix5QkFBaUIsS0FBS1QsTUFBTCxDQUFZeE0sS0FBWixDQUFrQkssR0FBbEIsQ0FBakIsQ0FBSjtBQUNBLFlBQUk0TSxTQUFTLENBQVQsRUFBWSxVQUFaLENBQUosRUFBNkI7QUFFN0JoTixZQUFJdUwsSUFBSixlQUNRLEtBQUtnQixNQUFMLENBQVkvSixXQUFaLENBQ0osaUJBREksRUFFSixFQUZJLEVBR0o7QUFDRXNLLHNCQUFZbFAsS0FBS2tQLFVBRG5CO0FBRUUxTixlQUFLQSxHQUZQO0FBR0V1SCxzQkFBWWlHLFNBSGQ7QUFJRXZLLHVCQUFhO0FBSmYsU0FISSxDQURSO0FBV0QsT0FwQlcsQ0FBWjs7QUFzQkEsV0FBSyxJQUFJNEssTUFBVCxJQUFtQnJQLEtBQUtzUCxJQUF4QixFQUE4QjtBQUM1QixnQkFBUUQsT0FBT0UsR0FBZjtBQUNFLGVBQUssSUFBTDtBQUNFLDBCQUFNSixNQUFNRSxPQUFPN04sR0FBYixDQUFOO0FBQ0E7O0FBQ0YsZUFBSyxLQUFMO0FBQ0UsMEJBQU15TixPQUFPSSxPQUFPN04sR0FBZCxDQUFOO0FBQ0E7QUFOSjtBQVFEOztBQUVELGFBQU87QUFDTFksYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0FuREQ7QUFBQTs7QUFxRE1pSCxvQkFBTixDQUEwQnJKLElBQTFCO0FBQUEsb0NBQWdDO0FBQzlCLFVBQUl3UCxZQUFZeFAsS0FBS2tQLFVBQXJCO0FBQ0EsVUFBSWhFLFNBQVNsTCxLQUFLa0wsTUFBbEI7QUFDQSxVQUFJOEQsWUFBWWhQLEtBQUsrSSxVQUFyQjtBQUVBLFVBQUkzRyxNQUFNLEVBQVYsQ0FMOEIsQ0FPOUI7O0FBQ0EsVUFBSUksTUFBTyxvREFBbURnTixTQUFVLEVBQXhFO0FBQ0FwTixVQUFJdUwsSUFBSixlQUFlLEtBQUtnQixNQUFMLENBQVl4TSxLQUFaLENBQWtCSyxHQUFsQixDQUFmLEdBVDhCLENBVzlCOztBQUNBLFdBQUssSUFBSWlOLElBQUksQ0FBYixFQUFnQkEsSUFBSXZFLE9BQU93RSxNQUEzQixFQUFtQ0QsR0FBbkMsRUFBd0M7QUFDdEMsc0JBQU0sS0FBS2QsTUFBTCxDQUFZL0osV0FBWixDQUNKLG1CQURJLEVBQ2lCO0FBQ25Cc0ssc0JBQVlNLFNBRE87QUFFbkJ6RyxzQkFBWWlHLFNBRk87QUFHbkJXLHFCQUFXekUsT0FBT3VFLENBQVAsQ0FIUTtBQUluQkcsZ0JBQU1ILElBQUk7QUFKUyxTQURqQixFQU1EO0FBQ0RoTCx1QkFBYTtBQURaLFNBTkMsQ0FBTjtBQVVEOztBQUVELGFBQU87QUFDTHJDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBNUJEO0FBQUE7O0FBOEJNa0gsZUFBTixDQUFxQnRKLElBQXJCO0FBQUEsb0NBQTJCO0FBQ3pCLFVBQUk2UCxhQUFhLEVBQWpCO0FBQ0EsVUFBSUMsT0FBTyxFQUFYLENBRnlCLENBSXpCOztBQUVBQSxhQUFPLENBQ0wsUUFESyxFQUVMLE1BRkssRUFHTCxNQUhLLEVBSUwsa0JBSkssRUFLTCxvQkFMSyxFQU1MLGFBTkssRUFPTCxXQVBLLENBQVA7O0FBU0EsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSTlQLEtBQUsrUCxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQi9QLEtBQUsrUCxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQsb0JBQU0sS0FBS3BCLE1BQUwsQ0FBWUUsV0FBWixDQUNKLGFBREksRUFFSCxnQkFBZTdPLEtBQUtrUCxVQUFXLEVBRjVCLEVBR0pXLFVBSEksRUFHUTtBQUNWbkwscUJBQWE7QUFESCxPQUhSLENBQU4sRUFuQnlCLENBMkJ6Qjs7QUFFQW1MLG1CQUFhLEVBQWI7QUFDQUMsYUFBTyxDQUNMLGtCQURLLEVBRUwsY0FGSyxFQUdMLFlBSEssRUFJTCxTQUpLLEVBS0wsU0FMSyxFQU1MLGNBTkssQ0FBUDs7QUFRQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJOVAsS0FBSytQLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCL1AsS0FBSytQLENBQUwsQ0FBaEI7QUFDZDs7QUFFRCxVQUFJM04sb0JBQVksS0FBS3VNLE1BQUwsQ0FBWUUsV0FBWixDQUNkLG1CQURjLEVBRWIsZ0JBQWU3TyxLQUFLa1AsVUFBVyxFQUZsQixFQUdkVyxVQUhjLEVBR0Y7QUFDVm5MLHFCQUFhO0FBREgsT0FIRSxDQUFaLENBQUo7QUFRQSxhQUFPO0FBQ0x0QyxhQUFLQTtBQURBLE9BQVA7QUFHRCxLQXJERDtBQUFBOztBQXVETTZHLGVBQU4sQ0FBcUJqSixJQUFyQjtBQUFBLG9DQUEyQjtBQUN6QixVQUFJZ1AsWUFBWWhQLEtBQUsrSSxVQUFyQjtBQUVBLFVBQUkzRyxNQUFNLEVBQVY7QUFFQSxVQUFJeU4sYUFBYSxFQUFqQjtBQUNBLFVBQUlDLE9BQU8sRUFBWDtBQUVBQSxhQUFPLENBQ0wsTUFESyxFQUVMLG9CQUZLLENBQVAsQ0FSeUIsQ0FZekI7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSTlQLEtBQUsrUCxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQi9QLEtBQUsrUCxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQzTixVQUFJOE0sVUFBSixpQkFBdUIsS0FBS1AsTUFBTCxDQUFZL0osV0FBWixDQUNyQixhQURxQixFQUVyQmlMLFVBRnFCLEVBRVQ7QUFDVjlHLG9CQUFZaUcsU0FERjtBQUVWdE0sZ0JBQVEsQ0FGRTtBQUdWOEIsY0FBTSxNQUhJO0FBSVZ3TCwwQkFBa0IsTUFKUjtBQUtWQyxxQkFBYSxNQUxIO0FBTVZDLG1CQUFXLE1BTkQ7QUFPVnpMLHFCQUFhLE9BUEg7QUFRVkMscUJBQWE7QUFSSCxPQUZTLENBQXZCO0FBY0FtTCxtQkFBYSxFQUFiO0FBQ0FDLGFBQU8sQ0FDTCxjQURLLEVBRUwsaUJBRkssRUFHTCxTQUhLLEVBSUwsU0FKSyxFQUtMLGNBTEssQ0FBUCxDQXBDeUIsQ0EyQ3pCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSTlQLEtBQUsrUCxDQUFMLENBQUosRUFBYUYsV0FBV0UsQ0FBWCxJQUFnQi9QLEtBQUsrUCxDQUFMLENBQWhCO0FBQ2Q7O0FBRUQzTixVQUFJdUcsZ0JBQUosaUJBQTZCLEtBQUtnRyxNQUFMLENBQVkvSixXQUFaLENBQzNCLG1CQUQyQixFQUUzQmlMLFVBRjJCLEVBRWY7QUFDVjlHLG9CQUFZaUcsU0FERjtBQUVWRSxvQkFBWTlNLElBQUk4TSxVQUZOO0FBR1ZKLGVBQU8sQ0FIRztBQUlWQyx5QkFBaUIsQ0FKUDtBQUtWb0IsNEJBQW9CLE1BTFY7QUFNVkMsNEJBQW9CLE1BTlY7QUFPVkMsMEJBQWtCLE1BUFI7QUFRVkMsb0JBQVksTUFSRjtBQVNWN0wscUJBQWEsT0FUSDtBQVVWQyxxQkFBYTtBQVZILE9BRmUsQ0FBN0I7O0FBZ0JBLFdBQUssSUFBSXFMLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJOVAsS0FBSytQLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCL1AsS0FBSytQLENBQUwsQ0FBaEI7QUFDZDs7QUFFRDNOLFVBQUltTyxnQkFBSixpQkFBNkIsS0FBSzVCLE1BQUwsQ0FBWS9KLFdBQVosQ0FDM0IsbUJBRDJCLEVBQ04sRUFETSxFQUNGO0FBQ3ZCK0QsMEJBQWtCdkcsSUFBSXVHLGdCQURDO0FBRXZCSSxvQkFBWWlHLFNBRlc7QUFHdkJGLGVBQU8sQ0FIZ0I7QUFJdkJySyxxQkFBYSxPQUpVO0FBS3ZCQyxxQkFBYTtBQUxVLE9BREUsQ0FBN0IsRUF6RXlCLENBbUZ6Qjs7QUFDQSxhQUFPO0FBQ0x0QyxhQUFLQTtBQURBLE9BQVA7QUFHRCxLQXZGRDtBQUFBOztBQXBLb0IsQzs7Ozs7Ozs7Ozs7QUNGdEI1RCxPQUFPMk4sTUFBUCxDQUFjO0FBQUNxRSxtQkFBZ0IsTUFBSUEsZUFBckI7QUFBcUNDLFlBQVMsTUFBSUEsUUFBbEQ7QUFBMkRDLGlCQUFjLE1BQUlBLGFBQTdFO0FBQTJGOUksaUJBQWMsTUFBSUE7QUFBN0csQ0FBZDtBQUEySSxJQUFJeUUsS0FBSjtBQUFVN04sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDMk4sUUFBTXpOLENBQU4sRUFBUTtBQUFDeU4sWUFBTXpOLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJdUMsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUkrUixXQUFKO0FBQWdCblMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDaVMsY0FBWS9SLENBQVosRUFBYztBQUFDK1Isa0JBQVkvUixDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFO0FBQW1FLElBQUk0TixJQUFKO0FBQVNoTyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDNE4sV0FBSzVOLENBQUw7QUFBTzs7QUFBbkIsQ0FBN0IsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTZOLE9BQUo7QUFBWWpPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM2TixjQUFRN04sQ0FBUjtBQUFVOztBQUF0QixDQUFwQyxFQUE0RCxDQUE1RDs7QUFTMWYsTUFBTTRSLGVBQU4sQ0FBc0I7QUFDM0I1RCxjQUFhakcsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsUUFBSW9LLFFBQUo7O0FBQ0EsWUFBUWpLLEtBQUtxRyxJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0U0RCxtQkFBVyxJQUFJRixhQUFKLENBQWtCL0osSUFBbEIsRUFBd0JILE9BQXhCLENBQVg7QUFGSjs7QUFLQSxXQUFPb0ssUUFBUDtBQUNEOztBQVQwQjs7QUFZdEIsTUFBTUgsUUFBTixDQUFlO0FBQ3BCN0QsY0FBYWpHLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFNBQUtHLElBQUwsR0FBWUEsSUFBWjtBQUNBLFNBQUtILE9BQUwsR0FBZUEsT0FBZjtBQUNEOztBQUVELFNBQU9xSyxPQUFQLENBQWdCbEssSUFBaEIsRUFBc0JILE9BQXRCLEVBQStCO0FBQzdCLFlBQVFHLEtBQUtxRyxJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UsZUFBTyxJQUFJMEQsYUFBSixDQUFrQi9KLElBQWxCLEVBQXdCSCxPQUF4QixDQUFQOztBQUNGO0FBQ0UsY0FBTSxJQUFJK0csS0FBSixDQUFVLG1CQUFWLENBQU47QUFKSjtBQU1EOztBQUVEdUQsYUFBWTtBQUNWLFdBQU8sS0FBS25LLElBQVo7QUFDRDs7QUFFRG9LLGFBQVk7QUFDVixXQUFPLEtBQUtwSyxJQUFMLENBQVUxRSxJQUFqQjtBQUNEOztBQUVEK08sZ0JBQWU7QUFDYixXQUFPLEtBQUt4SyxPQUFaO0FBQ0Q7O0FBRUR5SyxxQkFDRUMsS0FBSyxDQUFPL0QsV0FBVzVLLFVBQVUsQ0FBRSxDQUE5QixFQUFnQzZLLFVBQVV2SSxLQUFLLENBQUUsQ0FBakQsOEJBQXNELENBQUUsQ0FBeEQsQ0FEUCxFQUVFO0FBQ0EsU0FBS3FJLE1BQUwsR0FBY2dFLEVBQWQ7QUFDRDtBQUVEOzs7Ozs7Ozs7OztBQVNNN08sU0FBTixDQUFlOE8sWUFBWSxFQUEzQjtBQUFBLG9DQUErQjtBQUM3QixVQUFJM0ssVUFBVSxLQUFLd0ssV0FBTCxFQUFkLENBRDZCLENBRzdCOztBQUNBeEssY0FBUWtILE9BQVIsQ0FBZ0JDLElBQWhCLENBQXFCO0FBQ25Cbk4sY0FBTSxNQURhO0FBRW5CMkIsZUFBTztBQUZZLE9BQXJCO0FBS0EsVUFBSWlQLFVBQVUsRUFBZDs7QUFDQSxXQUFLLElBQUlDLENBQVQsSUFBYzdLLFFBQVFrSCxPQUF0QixFQUErQixDQUM5Qjs7QUFFRCxVQUFJQSxVQUFVLEVBQWQ7O0FBRUEsV0FBSyxJQUFJMkQsQ0FBVCxJQUFjN0ssUUFBUWtILE9BQXRCLEVBQStCO0FBQzdCMEQsZ0JBQVFDLEVBQUU3USxJQUFWLElBQWtCO0FBQ2hCMkIsaUJBQU9rUCxFQUFFbFAsS0FETztBQUVoQm1QLGlCQUFPLE9BQU9ELEVBQUVDLEtBQVQsS0FBbUIsV0FBbkIsR0FBaUNELEVBQUVDLEtBQW5DLEdBQTJDLENBRmxDO0FBR2hCMUQsaUJBQU87QUFIUyxTQUFsQjtBQUtBRixnQkFBUUMsSUFBUixDQUNFO0FBQ0VuTixnQkFBTTZRLEVBQUU3USxJQURWO0FBRUVzTixnQkFBTXRCLEtBQUtDLFFBQVFvQixRQUFSLENBQWlCd0QsRUFBRWxQLEtBQW5CLENBQUw7QUFGUixTQURGO0FBTUQ7O0FBRUQsb0JBQU0sS0FBSytLLE1BQUwsQ0FDSixDQUFPM0ssTUFBUCxFQUFlNkYsT0FBZiw4QkFBMkI7QUFDekIsYUFBSyxJQUFJaUosQ0FBVCxJQUFjM0QsT0FBZCxFQUF1QjtBQUNyQjtBQUNBLGNBQUk2RCxJQUFJSCxRQUFRQyxFQUFFN1EsSUFBVixDQUFSOztBQUNBLGNBQUkrUSxFQUFFRCxLQUFOLEVBQWE7QUFDWCxnQkFBSUMsRUFBRTNELEtBQUYsSUFBVzJELEVBQUVELEtBQWpCLEVBQXdCO0FBQ3RCO0FBQ0Q7QUFDRjs7QUFFRCxjQUFJRCxFQUFFdkQsSUFBRixDQUFPdkwsTUFBUCxDQUFKLEVBQW9CO0FBQ2xCO0FBQ0FnUCxjQUFFM0QsS0FBRixHQUZrQixDQUlsQjs7QUFDQSxnQkFBSSxPQUFPdUQsVUFBVUUsRUFBRTdRLElBQVosQ0FBUCxLQUE2QixXQUFqQyxFQUE4QztBQUM1Qyw0QkFBTTJRLFVBQVVFLEVBQUU3USxJQUFaLEVBQWtCK0IsTUFBbEIsRUFBMEI2RixPQUExQixDQUFOO0FBQ0Q7O0FBQ0Q7QUFDRDtBQUNGO0FBQ0YsT0FyQkQsQ0FESSxDQUFOLEVBN0I2QixDQXFEN0I7O0FBQ0EsYUFBT2dKLE9BQVA7QUFDRCxLQXZERDtBQUFBOztBQTFDb0I7O0FBb0dmLE1BQU1WLGFBQU4sU0FBNEJELFFBQTVCLENBQXFDO0FBQzFDN0QsY0FBYWpHLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFVBQU1HLElBQU4sRUFBWUgsT0FBWjtBQUVBLFFBQUl2RSxPQUFPLEtBQUs4TyxRQUFMLEVBQVg7QUFFQSxTQUFLOUQsS0FBTCxHQUFhLElBQUk5TCxLQUFKLENBQVVjLElBQVYsQ0FBYjtBQUNBLFNBQUtnUCxrQkFBTCxDQUF3QixDQUFPOUQsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBQ25ELFVBQUk1SyxNQUFPLGlCQUFnQm1FLEtBQUswRyxLQUFNLEVBQXRDO0FBQ0EsVUFBSWpMLG9CQUFZLEtBQUs2SyxLQUFMLENBQVdLLGNBQVgsQ0FBMEI5SyxHQUExQixFQUErQjJLLFFBQS9CLEVBQTBDdEksQ0FBRCxJQUFPO0FBQUUsY0FBTUEsQ0FBTjtBQUFTLE9BQTNELENBQVosQ0FBSjtBQUNBLGFBQU96QyxHQUFQO0FBQ0QsS0FKdUIsQ0FBeEI7QUFLRDs7QUFaeUM7O0FBbUJyQyxNQUFNd0YsYUFBTixTQUE0QjZJLFFBQTVCLENBQXFDO0FBQzFDN0QsY0FBYWpHLElBQWIsRUFBbUJILE9BQW5CLEVBQTRCO0FBQzFCLFVBQU1HLElBQU4sRUFBWUgsT0FBWixFQUQwQixDQUcxQjs7QUFDQSxTQUFLeUssa0JBQUwsQ0FBd0IsQ0FBTzlELFFBQVAsRUFBaUJDLE9BQWpCLDhCQUE2QjtBQUNuRCxVQUFJb0UsTUFBSjtBQUNBQSw2QkFBZWIsWUFBWWMsT0FBWixDQUFvQjlLLEtBQUsrSyxHQUF6QixDQUFmLEVBRm1ELENBSW5EOztBQUNBLFVBQUlqTCxLQUFLK0ssT0FBTy9LLEVBQVAsQ0FBVUUsS0FBS2dMLFFBQWYsQ0FBVDtBQUNBLFVBQUk1SyxhQUFhTixHQUFHTSxVQUFILENBQWNKLEtBQUtJLFVBQW5CLENBQWpCO0FBRUEsVUFBSXFCLFVBQVU7QUFDWm9KLGdCQUFRQSxNQURJO0FBRVp6SyxvQkFBWUEsVUFGQTtBQUdaNEssa0JBQVVsTDtBQUhFLE9BQWQ7QUFNQSxVQUFJMkgsTUFBTXJILFdBQVdDLElBQVgsRUFBVixDQWRtRCxDQWdCbkQ7O0FBQ0FvSCxVQUFJd0QsYUFBSixDQUFrQixpQkFBbEIsRUFBcUMsSUFBckMsRUFqQm1ELENBbUJuRDs7QUFDQSxVQUFJO0FBQ0YsNkJBQWF4RCxJQUFJeUQsT0FBSixFQUFiLEdBQTRCO0FBQzFCLGNBQUl2UixvQkFBWThOLElBQUkwRCxJQUFKLEVBQVosQ0FBSjtBQUNBLHdCQUFNM0UsU0FBUzdNLEdBQVQsRUFBYzhILE9BQWQsQ0FBTjtBQUNEOztBQUFBO0FBQ0YsT0FMRCxTQUtVO0FBQ1I7QUFDQSxzQkFBTWdHLElBQUlsQyxLQUFKLEVBQU47QUFDRDtBQUNGLEtBN0J1QixDQUF4QjtBQThCRDs7QUFuQ3lDLEM7Ozs7Ozs7Ozs7O0FDNUk1QzFOLE9BQU8yTixNQUFQLENBQWM7QUFBQ3hOLFdBQVEsTUFBSXdJO0FBQWIsQ0FBZDtBQUE0QyxJQUFJVCxlQUFKO0FBQW9CbEksT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDZ0ksa0JBQWdCOUgsQ0FBaEIsRUFBa0I7QUFBQzhILHNCQUFnQjlILENBQWhCO0FBQWtCOztBQUF0QyxDQUF0QyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJRyxPQUFKO0FBQVlQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNLLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTlDLEVBQXNFLENBQXRFOztBQUc5SSxNQUFNdUksY0FBTixDQUFxQjtBQUM1QkssTUFBTixDQUFZYixJQUFaO0FBQUEsb0NBQWtCO0FBQ2hCLFdBQUtvTCxLQUFMLGlCQUFtQnJMLGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLEVBQTBCLE9BQTFCLENBQW5CO0FBQ0EsV0FBS3FMLFFBQUwsaUJBQXNCdEwsZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEIsVUFBMUIsQ0FBdEI7QUFDRCxLQUhEO0FBQUE7O0FBS00yQixVQUFOLENBQWdCMkosTUFBaEI7QUFBQSxvQ0FBd0I7QUFDdEIsVUFBSUMsd0JBQWdCLEtBQUtILEtBQUwsQ0FBV2pGLE9BQVgsQ0FBbUI7QUFBQ3ZFLGFBQUswSjtBQUFOLE9BQW5CLEVBQWtDO0FBQUNyTCxvQkFBWTtBQUFDLHFCQUFXO0FBQVo7QUFBYixPQUFsQyxDQUFoQixDQUFKO0FBQ0EsVUFBSXVMLGNBQWNELFFBQVFFLE9BQTFCLENBRnNCLENBSXRCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsVUFBSUMsYUFBYSxFQUFqQjs7QUFFQSxXQUFLLElBQUlDLFVBQVQsSUFBdUJILFdBQXZCLEVBQW9DO0FBQ2xDLFlBQUlJLGNBQWMsQ0FBbEI7O0FBRUEsYUFBSyxJQUFJL0MsU0FBVCxJQUFzQjhDLFVBQXRCLEVBQWtDO0FBQ2hDLGNBQUlKLHdCQUFnQixLQUFLRixRQUFMLENBQWNsRixPQUFkLENBQXNCO0FBQUN2RSxpQkFBS2lIO0FBQU4sV0FBdEIsRUFBd0M7QUFBQzVJLHdCQUFZO0FBQUMsdUJBQVM7QUFBVjtBQUFiLFdBQXhDLENBQWhCLENBQUo7QUFDQSxjQUFJNEwsYUFBYU4sUUFBUXBELEtBQXpCLENBRmdDLENBSWhDOztBQUNBLGVBQUssSUFBSUEsS0FBVCxJQUFrQjBELFVBQWxCLEVBQThCO0FBQzVCRCwyQkFBZXpELE1BQU16RyxRQUFyQjtBQUNEO0FBQ0Y7O0FBRURnSyxtQkFBVzFFLElBQVgsQ0FBZ0I0RSxXQUFoQjtBQUNELE9BMUJxQixDQTRCdEI7OztBQUNBLFVBQUlsSyxXQUFXb0ssS0FBS0MsR0FBTCxDQUFTQyxLQUFULENBQWUsSUFBZixFQUFxQk4sVUFBckIsQ0FBZjtBQUVBLGFBQU9oSyxRQUFQO0FBQ0QsS0FoQ0Q7QUFBQTtBQWtDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQk1YLFVBQU4sQ0FBZ0I3SCxRQUFoQixFQUEwQnVILEtBQTFCLEVBQWlDQyxTQUFTLElBQTFDLEVBQWdEQyxTQUFTLElBQXpEO0FBQUEsb0NBQStEO0FBQzdEO0FBQ0EsVUFBSTRELFNBQVNuTSxRQUFRaUksSUFBUixDQUFhO0FBQUNuSCxrQkFBVUE7QUFBWCxPQUFiLEVBQW1DK1MsS0FBbkMsR0FBMkN0SSxHQUEzQyxDQUFnRDFMLENBQUQsSUFBT0EsRUFBRTZCLGdCQUF4RCxDQUFiLENBRjZELENBSTdEOztBQUNBLFVBQUltQixTQUFTLEVBQWI7QUFDQUEsYUFBT3dGLEtBQVAsR0FBZUEsS0FBZjtBQUNBLFVBQUlDLE1BQUosRUFBWXpGLE9BQU9pUixZQUFQLEdBQXNCeEwsTUFBdEI7QUFDWixVQUFJQyxNQUFKLEVBQVkxRixPQUFPa1IsWUFBUCxHQUFzQnhMLE1BQXRCO0FBRVosVUFBSWxGLG9CQUFZLEtBQUsyUCxLQUFMLENBQVdnQixVQUFYLENBQ2RuUixNQURjLEVBRWQ7QUFDRW9SLGVBQU87QUFDTDlILGtCQUFRO0FBQ04rSCxtQkFBTy9IO0FBREQ7QUFESDtBQURULE9BRmMsQ0FBWixDQUFKLENBVjZELENBcUI3RDs7QUFDQSxhQUFPQSxNQUFQO0FBQ0QsS0F2QkQ7QUFBQTtBQXlCQTs7Ozs7Ozs7OztBQVFNdkQsWUFBTixDQUFrQlAsS0FBbEIsRUFBeUJDLFNBQVMsSUFBbEMsRUFBd0NDLFNBQVMsSUFBakQ7QUFBQSxvQ0FBdUQ7QUFDckQ7QUFDQSxVQUFJMUYsU0FBUyxFQUFiO0FBQ0FBLGFBQU93RixLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQVl6RixPQUFPaVIsWUFBUCxHQUFzQnhMLE1BQXRCO0FBQ1osVUFBSUMsTUFBSixFQUFZMUYsT0FBT2tSLFlBQVAsR0FBc0J4TCxNQUF0QjtBQUVaLFVBQUlsRixvQkFBWSxLQUFLMlAsS0FBTCxDQUFXZ0IsVUFBWCxDQUNkblIsTUFEYyxFQUVkO0FBQ0V1SCxjQUFNO0FBQ0orQixrQkFBUTtBQURKO0FBRFIsT0FGYyxDQUFaLENBQUo7QUFRRCxLQWZEO0FBQUE7QUFpQkE7Ozs7Ozs7Ozs7Ozs7Ozs7QUFjTWdJLGNBQU4sQ0FBb0IvSyxJQUFwQixFQUEwQitKLE9BQTFCO0FBQUEsb0NBQW1DO0FBQ2pDOzs7Ozs7OztBQVFBLFVBQUkzQyxNQUFNLENBQ1I7QUFDRTRELGVBQU8sTUFEVDtBQUVFQyxpQkFBU2pMLEtBQUtrTCxRQUZoQjtBQUdFbkIsaUJBQVM7QUFDUG9CLGlCQUFPO0FBREEsU0FIWDtBQU1FblIsZUFBTztBQUNMMFEsd0JBQWMxSyxLQUFLMEssWUFEZDtBQUVMQyx3QkFBYzNLLEtBQUsySztBQUZkO0FBTlQsT0FEUSxFQVlSO0FBQ0VLLGVBQU9oTCxLQUFLb0wsV0FEZDtBQUVFSCxpQkFBU2pMLEtBQUswSyxZQUZoQjtBQUdFWCxpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUVuUixlQUFPO0FBQ0xrUixvQkFBVWxMLEtBQUtrTCxRQURWO0FBRUxQLHdCQUFjM0ssS0FBSzJLO0FBRmQ7QUFOVCxPQVpRLEVBdUJSO0FBQ0VLLGVBQU9oTCxLQUFLcUwsV0FEZDtBQUVFSixpQkFBU2pMLEtBQUsySyxZQUZoQjtBQUdFWixpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUVuUixlQUFPO0FBQ0xrUixvQkFBVWxMLEtBQUtrTCxRQURWO0FBRUxSLHdCQUFjMUssS0FBSzBLO0FBRmQ7QUFOVCxPQXZCUSxDQUFWO0FBb0NBLFVBQUlZLFFBQVEsRUFBWjs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY25FLEdBQWQsRUFBbUI7QUFDakJrRSxjQUFNOUYsSUFBTixDQUFXO0FBQ1RnRyxvQ0FDUSxLQUFLNUIsS0FBTCxDQUFXN0ssU0FBWCxDQUNKLENBQ0U7QUFBQzBNLG9CQUFRQyxPQUFPQyxNQUFQLENBQWNKLEVBQUV2UixLQUFoQixFQUF1QjtBQUFDaUYscUJBQU9lLEtBQUtmO0FBQWIsYUFBdkI7QUFBVCxXQURGLEVBRUU7QUFBQzJNLHNCQUFVRixPQUFPQyxNQUFQLENBQWNKLEVBQUV4QixPQUFoQixFQUF5QkEsT0FBekI7QUFBWCxXQUZGLEVBR0U7QUFBQzhCLG1CQUFPO0FBQUN6TCxtQkFBSztBQUFOO0FBQVIsV0FIRixDQURJLEVBTUp0QixPQU5JLEVBRFIsQ0FEUztBQVNUZ04saUJBQU9QO0FBVEUsU0FBWDtBQVdEOztBQUVELGFBQU9ELEtBQVA7QUFDRCxLQTlERDtBQUFBLEdBN0hrQyxDQTZMbEM7QUFDQTs7O0FBQ0FTLGdCQUFlL0wsSUFBZixFQUFxQjtBQUNuQixRQUFJZ00sYUFBYSxFQUFqQjtBQUNBLFFBQUloTSxLQUFLZixLQUFULEVBQWdCK00sV0FBV3hHLElBQVgsQ0FBZ0J4RixLQUFLZixLQUFyQjtBQUNoQixRQUFJZSxLQUFLMEssWUFBVCxFQUF1QnNCLFdBQVd4RyxJQUFYLENBQWdCeEYsS0FBSzBLLFlBQXJCO0FBQ3ZCLFFBQUkxSyxLQUFLMkssWUFBVCxFQUF1QnFCLFdBQVd4RyxJQUFYLENBQWdCeEYsS0FBSzJLLFlBQXJCO0FBQ3ZCLFdBQU9xQixXQUFXNUosSUFBWCxDQUFnQixHQUFoQixDQUFQO0FBQ0Q7O0FBRUt6QixrQkFBTixDQUF3QmtHLFNBQXhCLEVBQW1DN0csSUFBbkM7QUFBQSxvQ0FBeUM7QUFDdkM7QUFDQSxVQUFJaU0sWUFBYWYsUUFBRCxJQUFjQSxhQUFhLFFBQWIsR0FBd0IsT0FBeEIsR0FBa0NBLFFBQWhFLENBRnVDLENBSXZDOzs7QUFDQSxVQUFJN0QsWUFBWSxJQUFoQjtBQUNBLFVBQUkyRSxhQUFhLEVBQWpCLENBTnVDLENBUXZDO0FBQ0E7O0FBQ0EsVUFBSWhNLEtBQUtmLEtBQVQsRUFBZ0IrTSxXQUFXeEcsSUFBWCxDQUFnQnhGLEtBQUtmLEtBQXJCO0FBQ2hCLFVBQUllLEtBQUswSyxZQUFULEVBQXVCc0IsV0FBV3hHLElBQVgsQ0FBZ0J4RixLQUFLMEssWUFBckI7QUFDdkIsVUFBSTFLLEtBQUsySyxZQUFULEVBQXVCcUIsV0FBV3hHLElBQVgsQ0FBZ0J4RixLQUFLMkssWUFBckIsRUFaZ0IsQ0FjdkM7O0FBQ0EsVUFBSXVCLGFBQUo7O0FBQ0EsY0FBUWxNLEtBQUtrTCxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQVlnQiwwQkFBZ0IsQ0FBaEI7QUFBbUI7O0FBQy9CLGFBQUssUUFBTDtBQUFlQSwwQkFBZ0IsQ0FBaEI7QUFBbUI7O0FBQ2xDO0FBQVNBLDBCQUFnQixDQUFoQjtBQUFtQjtBQUg5QixPQWhCdUMsQ0FzQnZDOzs7QUFDQSxVQUFJL0UsT0FBTyxFQUFYOztBQUNBLGNBQVFuSCxLQUFLa0wsUUFBYjtBQUNFLGFBQUssS0FBTDtBQUFZL0QsZUFBSzNCLElBQUwsQ0FBVTtBQUFDbk0saUJBQUssQ0FBTjtBQUFTK04saUJBQUs7QUFBZCxXQUFWLEVBQStCO0FBQUMvTixpQkFBSyxDQUFOO0FBQVMrTixpQkFBSztBQUFkLFdBQS9CO0FBQXNEOztBQUNsRSxhQUFLLFFBQUw7QUFBZUQsZUFBSzNCLElBQUwsQ0FBVTtBQUFDbk0saUJBQUssQ0FBTjtBQUFTK04saUJBQUs7QUFBZCxXQUFWLEVBQStCO0FBQUMvTixpQkFBSyxDQUFOO0FBQVMrTixpQkFBSztBQUFkLFdBQS9CO0FBQXNEO0FBRnZFLE9BeEJ1QyxDQTZCdkM7OztBQUNBLFVBQUkrRSxjQUFjLElBQWxCOztBQUNBLGNBQVFuTSxLQUFLa0wsUUFBYjtBQUNFLGFBQUssS0FBTDtBQUFZaUIsd0JBQWMsSUFBZDtBQUFvQjs7QUFDaEMsYUFBSyxRQUFMO0FBQWVBLHdCQUFjLEdBQWQ7QUFBbUI7QUFGcEMsT0EvQnVDLENBb0N2QztBQUNBO0FBQ0E7OztBQUVBLFVBQUliLHNCQUFjLEtBQUtQLFlBQUwsQ0FBa0IvSyxJQUFsQixFQUF3QjtBQUFDK0csb0JBQVk7QUFBYixPQUF4QixDQUFkLENBQUosQ0F4Q3VDLENBMEN2QztBQUVBOztBQUNBdUUsY0FBUUEsTUFBTW5KLEdBQU4sQ0FDTGlLLElBQUQsSUFBVTtBQUNSQSxhQUFLTixLQUFMLENBQVdiLE9BQVgsR0FBcUJnQixVQUFVRyxLQUFLTixLQUFMLENBQVdiLE9BQXJCLENBQXJCO0FBQ0FtQixhQUFLWixVQUFMLEdBQWtCWSxLQUFLWixVQUFMLENBQWdCckosR0FBaEIsQ0FDZmtLLFNBQUQsSUFBZTtBQUNiQSxvQkFBVWxCLEtBQVYsR0FBa0JjLFVBQVVJLFVBQVVsQixLQUFwQixDQUFsQjtBQUNBLGlCQUFPa0IsU0FBUDtBQUNELFNBSmUsQ0FBbEI7QUFNQSxlQUFPRCxJQUFQO0FBQ0QsT0FWSyxDQUFSLENBN0N1QyxDQTBEdkM7O0FBQ0EsVUFBSUUsZ0JBQ0poQixNQUFNbkosR0FBTixDQUNHaUssSUFBRCxJQUNFLGtDQUNHLG1CQURILEdBRUssaUVBRkwsR0FHTyxXQUFVQSxLQUFLTixLQUFMLENBQVdkLEtBQU0sV0FIbEMsR0FJSyxRQUpMLEdBS0lvQixLQUFLWixVQUFMLENBQWdCckosR0FBaEIsQ0FDR2tLLFNBQUQsSUFBZTtBQUNiLFlBQUlELEtBQUtOLEtBQUwsQ0FBV2IsT0FBWCxLQUF1Qm9CLFVBQVVsQixLQUFyQyxFQUE0QztBQUMxQyxpQkFBUSw2QkFBNEJrQixVQUFVdEYsVUFBVywwRUFBeUVzRixVQUFVbEIsS0FBTSx3QkFBbEo7QUFDRCxTQUZELE1BRU87QUFDTCxpQkFBUSw2QkFBNEJrQixVQUFVdEYsVUFBVyxrRUFBaUVzRixVQUFVbEIsS0FBTSxlQUExSTtBQUNEO0FBQ0YsT0FQSCxFQVFFL0ksSUFSRixDQVFPLEVBUlAsQ0FMSixHQWNFLFFBZEYsR0FlQSxRQWpCSixFQWtCRUEsSUFsQkYsQ0FrQk8sRUFsQlAsQ0FEQTtBQXFCQSxVQUFJbUssb0JBQXFCOzs7TUFHdkJELGFBQWM7S0FIaEIsQ0FoRnVDLENBc0Z2Qzs7QUFDQSxVQUFJelUsT0FBTztBQUNUa1Asb0JBQVlNLFNBREg7QUFFVHpHLG9CQUFZaUcsU0FGSDtBQUdUeE8sY0FBTyxHQUFFMlQsV0FBVzVKLElBQVgsQ0FBZ0IsR0FBaEIsQ0FBcUIsSUFBRzZKLFVBQVVqTSxLQUFLa0wsUUFBZixDQUF5QixJQUFHbEwsS0FBSzNILElBQUssSUFBRzJILEtBQUt3TSxRQUFTLEVBSC9FO0FBSVRDLDRCQUFvQkYsaUJBSlg7QUFLVHhFLG1CQUFXL0gsS0FBSzBNLFdBQUwsR0FBbUIsR0FMckI7QUFNVEMsc0JBQWNYLFdBQVc1SixJQUFYLENBQWdCLEdBQWhCLENBTkw7QUFPVHdLLGlCQUFTNU0sS0FBSzZNLFlBUEw7QUFRVEMsaUJBQVM5TSxLQUFLK00sV0FBTCxHQUFtQixJQVJuQjtBQVF5QjtBQUNsQ2hLLGdCQUFRL0MsS0FBSytDLE1BVEo7QUFVVGlLLHlCQUFpQmQsYUFWUjtBQVdUL0UsY0FBTUEsSUFYRztBQVlUOEYsc0JBQWNkO0FBWkwsT0FBWDtBQWVBVCxhQUFPQyxNQUFQLENBQWM5VCxJQUFkLEVBQW9CbUksS0FBS00sSUFBTCxDQUFVQyxXQUE5QjtBQUVBLGFBQU8xSSxJQUFQO0FBQ0QsS0F6R0Q7QUFBQSxHQXZNa0MsQ0FrVGxDOzs7QUFDTWdNLGtCQUFOLENBQXdCcUosR0FBeEIsRUFBNkJsTixJQUE3QjtBQUFBLG9DQUFtQztBQUNqQyxVQUFJNkMsUUFBUSxFQUFaLENBRGlDLENBRWpDOztBQUNBQSxjQUFRcUssSUFBSWxOLEtBQUtrTCxRQUFULENBQVIsQ0FIaUMsQ0FLakM7O0FBQ0EsWUFBTWlDLFlBQVksSUFBbEI7O0FBQ0EsV0FBSyxJQUFJN0YsSUFBSSxDQUFiLEVBQWdCQSxJQUFJdEgsS0FBSytDLE1BQUwsQ0FBWXdFLE1BQWhDLEVBQXdDRCxHQUF4QyxFQUE2QztBQUMzQ3pFLGNBQU1zSyxhQUFhN0YsSUFBSSxDQUFqQixDQUFOLElBQTZCdEgsS0FBSytDLE1BQUwsQ0FBWXVFLENBQVosQ0FBN0I7QUFDRCxPQVRnQyxDQVdqQzs7O0FBQ0F6RSxZQUFNLE1BQU4sSUFBZ0I3QyxLQUFLTSxJQUFMLENBQVV1QyxLQUFWLENBQWdCdUssUUFBaEM7QUFDQXZLLFlBQU0sTUFBTixJQUFpQixHQUFFLEtBQUtrSixhQUFMLENBQW1CL0wsSUFBbkIsQ0FBeUIsSUFBR0EsS0FBS2tMLFFBQVMsSUFBR2xMLEtBQUszSCxJQUFLLEVBQTFFO0FBQ0F3SyxZQUFNLE1BQU4sSUFBZ0I3QyxLQUFLK00sV0FBckI7QUFDQWxLLFlBQU0sTUFBTixJQUFnQjdDLEtBQUsrTSxXQUFyQjtBQUNBbEssWUFBTSxNQUFOLElBQWdCLEtBQUtrSixhQUFMLENBQW1CL0wsSUFBbkIsQ0FBaEI7QUFDQTZDLFlBQU0sSUFBTixJQUFjN0MsS0FBSzBNLFdBQW5CO0FBQ0E3SixZQUFNLGdCQUFOLElBQTBCN0MsS0FBS3dNLFFBQS9CO0FBRUEsYUFBTzNKLEtBQVA7QUFDRCxLQXJCRDtBQUFBOztBQW5Ua0MsQzs7Ozs7Ozs7Ozs7QUNIcEN4TSxPQUFPMk4sTUFBUCxDQUFjO0FBQUN4TixXQUFRLE1BQUk2VztBQUFiLENBQWQ7O0FBQWUsTUFBTUEsU0FBTixDQUFnQjtBQUM3QixTQUFPQyxLQUFQLENBQWM1USxDQUFkLEVBQWlCO0FBQ2YsUUFBSXpDLE1BQU0sRUFBVjs7QUFFQSxRQUFJeUMsYUFBYTBJLEtBQWpCLEVBQXdCO0FBQ3RCbkwsVUFBSXNULE9BQUosR0FBYzdRLEVBQUU2USxPQUFoQjtBQUNBdFQsVUFBSTVCLElBQUosR0FBV3FFLEVBQUVyRSxJQUFiO0FBQ0E0QixVQUFJdVQsUUFBSixHQUFlOVEsRUFBRThRLFFBQWpCO0FBQ0F2VCxVQUFJd1QsVUFBSixHQUFpQi9RLEVBQUUrUSxVQUFuQjtBQUNBeFQsVUFBSXlULFlBQUosR0FBbUJoUixFQUFFZ1IsWUFBckI7QUFDQXpULFVBQUkwVCxLQUFKLEdBQVlqUixFQUFFaVIsS0FBZDtBQUNELEtBUEQsTUFPTztBQUNMMVQsWUFBTXlDLENBQU47QUFDRDs7QUFFRCxXQUFPekMsR0FBUDtBQUNEOztBQWhCNEIsQzs7Ozs7Ozs7Ozs7QUNBL0I1RCxPQUFPMk4sTUFBUCxDQUFjO0FBQUN6RixtQkFBZ0IsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJaUssV0FBSjtBQUFnQm5TLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ2lTLGNBQVkvUixDQUFaLEVBQWM7QUFBQytSLGtCQUFZL1IsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTs7QUFFOUQsTUFBTThILGVBQU4sQ0FBc0I7QUFDM0IsU0FBYUksR0FBYixDQUFrQkgsSUFBbEIsRUFBd0JJLFVBQXhCO0FBQUEsb0NBQW9DO0FBQ2xDLFVBQUl5Syx1QkFBZWIsWUFBWWMsT0FBWixDQUFvQjlLLEtBQUsrSyxHQUF6QixDQUFmLENBQUo7QUFDQSxVQUFJakwsS0FBSytLLE9BQU8vSyxFQUFQLENBQVVFLEtBQUtnTCxRQUFmLENBQVQ7QUFDQSxhQUFPbEwsR0FBR00sVUFBSCxDQUFjQSxVQUFkLENBQVA7QUFDRCxLQUpEO0FBQUE7O0FBRDJCLEM7Ozs7Ozs7Ozs7O0FDRjdCdkksT0FBTzJOLE1BQVAsQ0FBYztBQUFDeE4sV0FBUSxNQUFJd0M7QUFBYixDQUFkO0FBQW1DLElBQUk4TCxLQUFKO0FBQVV6TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDcU8sWUFBTXJPLENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSW1YLE1BQUo7QUFBV3ZYLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNtWCxhQUFPblgsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDs7QUFHaEcsTUFBTXVDLEtBQU4sQ0FBWTtBQUN6QnlMLGNBQWFwRyxPQUFiLEVBQXNCO0FBQ3BCO0FBQ0EsU0FBS3dQLElBQUwsR0FBWS9JLE1BQU1nSixVQUFOLENBQWlCelAsT0FBakIsQ0FBWixDQUZvQixDQUlwQjs7QUFDQSxRQUFJMFAsZUFBZTtBQUFDQywwQkFBb0I7QUFBckIsS0FBbkI7QUFDQXRDLFdBQU9DLE1BQVAsQ0FBY29DLFlBQWQsRUFBNEIxUCxPQUE1QjtBQUNBLFNBQUs0UCxTQUFMLEdBQWlCbkosTUFBTWdKLFVBQU4sQ0FBaUJDLFlBQWpCLENBQWpCO0FBQ0Q7O0FBRUQsU0FBT0csVUFBUCxDQUFtQkMsSUFBbkIsRUFBeUI7QUFDdkIsV0FBT1AsT0FBT08sSUFBUCxFQUFhQyxNQUFiLEdBQXNCbFIsU0FBdEIsQ0FBZ0MsQ0FBaEMsRUFBbUMsRUFBbkMsRUFBdUNtUixPQUF2QyxDQUErQyxHQUEvQyxFQUFvRCxHQUFwRCxDQUFQO0FBQ0Q7QUFFRDs7Ozs7O0FBSUFyVSxRQUFPSyxHQUFQLEVBQVk7QUFDVjtBQUNBO0FBQ0EsV0FBTyxLQUFLaVUsTUFBTCxHQUNKQyxJQURJLENBRUZDLEdBQUQsSUFBUztBQUNQLGFBQU8sSUFBSXRJLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQW9JLFlBQUl4VSxLQUFKLENBQVVLLEdBQVYsRUFBZSxDQUFDcUMsQ0FBRCxFQUFJekMsR0FBSixLQUFZO0FBQ3pCO0FBQ0F1VSxjQUFJQyxPQUFKOztBQUNBLGNBQUkvUixDQUFKLEVBQU87QUFDTDBKLG1CQUFPMUosQ0FBUDtBQUNELFdBRkQsTUFFT3lKLFFBQVFsTSxHQUFSO0FBQ1IsU0FORDtBQU9ELE9BVkksQ0FBUDtBQVlELEtBZkUsRUFpQkpzTSxLQWpCSSxDQWlCRzdKLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQW5CSSxDQUFQO0FBb0JEOztBQUVLZ1MsY0FBTixDQUFvQnJVLEdBQXBCO0FBQUEsb0NBQXlCO0FBQ3ZCLFVBQUlKLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPSixJQUFJMFUsUUFBWDtBQUNELEtBSEQ7QUFBQTtBQUtBOzs7Ozs7OztBQU1NbFMsYUFBTixDQUFtQnlJLEtBQW5CLEVBQTBCck4sT0FBTyxFQUFqQyxFQUFxQytXLFVBQVUsRUFBL0M7QUFBQSxvQ0FBbUQ7QUFDakQ7QUFDQTtBQUVBLFVBQUl2VSxNQUFPLGVBQWM2SyxLQUFNLEdBQS9CO0FBRUEsVUFBSS9DLE1BQU0sSUFBSTBNLEdBQUosRUFBVjs7QUFDQSxXQUFLLElBQUlqSCxDQUFULElBQWM4RCxPQUFPL0QsSUFBUCxDQUFZOVAsSUFBWixDQUFkLEVBQWlDO0FBQy9CLFlBQUlBLEtBQUsrUCxDQUFMLE1BQVksSUFBaEIsRUFBc0I7QUFDcEJ6RixjQUFJaUYsR0FBSixDQUFRUSxDQUFSLEVBQVcsTUFBWDtBQUNELFNBRkQsTUFFTyxJQUFJL1AsS0FBSytQLENBQUwsRUFBUW5ELFdBQVIsQ0FBb0JwTSxJQUFwQixLQUE2QixNQUFqQyxFQUF5QztBQUM5QztBQUNBOEosY0FBSWlGLEdBQUosQ0FBUVEsQ0FBUixFQUFZLElBQUc1TyxNQUFNa1YsVUFBTixDQUFpQnJXLEtBQUsrUCxDQUFMLENBQWpCLENBQTBCLEdBQXpDO0FBQ0QsU0FITSxNQUdBO0FBQ0x6RixjQUFJaUYsR0FBSixDQUFRUSxDQUFSLEVBQVksR0FBRTlDLE1BQU1nSyxNQUFOLENBQWFqWCxLQUFLK1AsQ0FBTCxDQUFiLENBQXNCLEVBQXBDO0FBQ0Q7QUFDRjs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBYzhELE9BQU8vRCxJQUFQLENBQVlpSCxPQUFaLENBQWQsRUFBb0M7QUFDbEN6TSxZQUFJaUYsR0FBSixDQUFRUSxDQUFSLEVBQVdnSCxRQUFRaEgsQ0FBUixNQUFlLElBQWYsR0FBc0IsTUFBdEIsR0FBK0JnSCxRQUFRaEgsQ0FBUixDQUExQztBQUNEOztBQUVEdk4sYUFBUSxLQUFJLENBQUMsR0FBRzhILElBQUl3RixJQUFKLEVBQUosRUFBZ0J2RixJQUFoQixDQUFxQixHQUFyQixDQUEwQixLQUF0QztBQUVBL0gsYUFBUSxXQUFVLENBQUMsR0FBRzhILElBQUk0TSxNQUFKLEVBQUosRUFBa0IzTSxJQUFsQixDQUF1QixHQUF2QixDQUE0QixLQUE5QztBQUVBLFVBQUluSSxvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT0osSUFBSTBVLFFBQVg7QUFDRCxLQTNCRDtBQUFBO0FBNkJBOzs7Ozs7Ozs7QUFPTWpJLGFBQU4sQ0FBbUJ4QixLQUFuQixFQUEwQnpMLE1BQTFCLEVBQWtDNUIsSUFBbEMsRUFBd0MrVyxPQUF4QztBQUFBLG9DQUFpRDtBQUMvQyxVQUFJdlUsTUFBTyxVQUFTNkssS0FBTSxPQUExQjtBQUVBLFVBQUk4SixVQUFVLEVBQWQ7O0FBQ0EsV0FBSyxJQUFJcEgsQ0FBVCxJQUFjOEQsT0FBTy9ELElBQVAsQ0FBWTlQLElBQVosQ0FBZCxFQUFpQztBQUMvQm1YLGdCQUFReEosSUFBUixDQUFjLEdBQUVvQyxDQUFFLElBQUc5QyxNQUFNZ0ssTUFBTixDQUFhalgsS0FBSytQLENBQUwsQ0FBYixDQUFzQixFQUEzQztBQUNEOztBQUNELFdBQUssSUFBSUEsQ0FBVCxJQUFjOEQsT0FBTy9ELElBQVAsQ0FBWWlILE9BQVosQ0FBZCxFQUFvQztBQUNsQ0ksZ0JBQVF4SixJQUFSLENBQWMsR0FBRW9DLENBQUUsSUFBR2dILFFBQVFoSCxDQUFSLENBQVcsRUFBaEM7QUFDRDs7QUFDRHZOLGFBQU8yVSxRQUFRNU0sSUFBUixDQUFhLEdBQWIsQ0FBUDtBQUVBL0gsYUFBUSxVQUFTWixNQUFPLEdBQXhCO0FBRUEsVUFBSVEsb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9KLEdBQVA7QUFDRCxLQWhCRDtBQUFBLEdBM0Z5QixDQTZHekI7OztBQUNNZ1YsWUFBTixDQUFrQjVVLEdBQWxCO0FBQUEsb0NBQXVCO0FBQ3JCLFVBQUk2VSxXQUFXLEtBQUtyQixJQUFwQjtBQUNBLFdBQUtBLElBQUwsR0FBWSxLQUFLSSxTQUFqQjs7QUFDQSxVQUFJO0FBQ0YsWUFBSWhVLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxlQUFPSixHQUFQO0FBQ0QsT0FIRCxTQUdVO0FBQ1IsYUFBSzRULElBQUwsR0FBWXFCLFFBQVo7QUFDRDtBQUNGLEtBVEQ7QUFBQTs7QUFXTUMsa0JBQU47QUFBQSxvQ0FBMEI7QUFDeEIsb0JBQU0sS0FBS25WLEtBQUwsQ0FBWSxvQkFBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNb1YsUUFBTjtBQUFBLG9DQUFnQjtBQUNkLG9CQUFNLEtBQUtwVixLQUFMLENBQVksU0FBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNcVYsVUFBTjtBQUFBLG9DQUFrQjtBQUNoQixvQkFBTSxLQUFLclYsS0FBTCxDQUFZLFdBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJQW1MLGlCQUFnQjlLLEdBQWhCLEVBQXFCMkssV0FBWTVLLE1BQUQsSUFBWSxDQUFFLENBQTlDLEVBQWdENkssVUFBV3ZJLENBQUQsSUFBTyxDQUFFLENBQW5FLEVBQXFFO0FBQ25FLFdBQU8sS0FBSzRSLE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUl0SSxPQUFKLENBQ0wsQ0FBT0MsT0FBUCxFQUFnQkMsTUFBaEIsOEJBQTJCO0FBQ3pCO0FBQ0FvSSxZQUFJeFUsS0FBSixDQUFVSyxHQUFWLEVBQ0dpVixFQURILENBQ00sUUFETixFQUVLbFYsTUFBRCxJQUFZO0FBQ1ZvVSxjQUFJZSxLQUFKO0FBQ0F2SyxtQkFBUzVLLE1BQVQ7QUFDQW9VLGNBQUlnQixNQUFKO0FBQ0QsU0FOTCxFQU9HRixFQVBILENBT00sT0FQTixFQU9nQjVTLENBQUQsSUFBTztBQUNsQnVJLGtCQUFRdkksQ0FBUjtBQUNELFNBVEgsRUFVRzRTLEVBVkgsQ0FVTSxLQVZOLEVBVWEsTUFBTTtBQUNmZCxjQUFJQyxPQUFKO0FBQ0F0STtBQUNELFNBYkg7QUFjRCxPQWhCRCxDQURLLENBQVA7QUFtQkQsS0F0QkUsRUF3QkpJLEtBeEJJLENBd0JHN0osQ0FBRCxJQUFPO0FBQ1osWUFBTUEsQ0FBTjtBQUNELEtBMUJJLENBQVA7QUEyQkQ7O0FBRUQ0UixXQUFVO0FBQ1IsV0FBTyxJQUFJcEksT0FBSixDQUNMLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUNuQjtBQUNBLFdBQUt5SCxJQUFMLENBQVU0QixhQUFWLENBQXdCLENBQUMvUyxDQUFELEVBQUk4UixHQUFKLEtBQVk7QUFDbEMsWUFBSTlSLENBQUosRUFBTztBQUNMMEosaUJBQU8xSixDQUFQO0FBQ0QsU0FGRCxNQUVPO0FBQ0x5SixrQkFBUXFJLEdBQVI7QUFDRDtBQUNGLE9BTkQ7QUFPRCxLQVZJLEVBWUpqSSxLQVpJLENBYUY3SixDQUFELElBQU87QUFDTCxZQUFNQSxDQUFOO0FBQ0QsS0FmRSxDQUFQO0FBaUJEOztBQXJMd0IsQzs7Ozs7Ozs7Ozs7QUNIM0JyRyxPQUFPMk4sTUFBUCxDQUFjO0FBQUN4TixXQUFRLE1BQUk4SztBQUFiLENBQWQ7O0FBQWUsTUFBTUEsTUFBTixDQUFhO0FBQzFCbUQsY0FBYTdDLFVBQWIsRUFBeUI7QUFDdkIsU0FBS0EsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxTQUFLUyxhQUFMLEdBQXFCLElBQXJCO0FBQ0EsU0FBS00sUUFBTCxHQUFnQixJQUFoQjtBQUNBLFNBQUtTLFdBQUwsR0FBbUIsSUFBbkI7QUFDQSxTQUFLcUMsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLbkQsV0FBTCxHQUFtQixDQUFuQjtBQUNEOztBQUVLd0IsUUFBTixDQUFjbEIsR0FBZDtBQUFBLG9DQUFtQjtBQUNqQjtBQUNBLFVBQUksS0FBSzZDLEtBQUwsR0FBYSxLQUFLN0QsVUFBbEIsS0FBaUMsQ0FBckMsRUFBd0M7QUFDdEMsWUFBSSxLQUFLUyxhQUFULEVBQXdCO0FBQ3RCLHdCQUFNLEtBQUtBLGFBQUwsQ0FBbUIsS0FBS0MsV0FBeEIsQ0FBTjtBQUNEO0FBQ0Y7O0FBQ0QsVUFBSSxLQUFLSyxRQUFULEVBQW1CO0FBQ2pCLHNCQUFNLEtBQUtBLFFBQUwsQ0FBY0MsR0FBZCxDQUFOO0FBQ0Q7O0FBQ0QsV0FBSzZDLEtBQUwsR0FWaUIsQ0FXakI7O0FBQ0EsVUFBSSxLQUFLQSxLQUFMLEdBQWEsS0FBSzdELFVBQWxCLEtBQWlDLENBQXJDLEVBQXdDO0FBQ3RDLFlBQUksS0FBS3dCLFdBQVQsRUFBc0I7QUFDcEIsd0JBQU0sS0FBS0EsV0FBTCxDQUFpQixLQUFLZCxXQUF0QixDQUFOO0FBQ0Q7O0FBQ0QsYUFBS0EsV0FBTDtBQUNEO0FBQ0YsS0FsQkQ7QUFBQTs7QUFtQkF5QixVQUFTO0FBQ1AsU0FBS1gsV0FBTCxDQUFpQixLQUFLZCxXQUF0QjtBQUNEOztBQS9CeUIsQzs7Ozs7Ozs7Ozs7QUNBNUJqTSxPQUFPMk4sTUFBUCxDQUFjO0FBQUN4TixXQUFRLE1BQUl5QztBQUFiLENBQWQ7QUFBb0MsSUFBSW9VLFNBQUo7QUFBY2hYLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM0VyxnQkFBVTVXLENBQVY7QUFBWTs7QUFBeEIsQ0FBaEMsRUFBMEQsQ0FBMUQ7QUFBNkQsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDs7QUFHM0csTUFBTXdDLE1BQU4sQ0FBYTtBQUMxQndMLGdCQUFlO0FBQ2IsU0FBS3JLLE1BQUwsR0FBYyxFQUFkO0FBQ0EsU0FBSzRPLFNBQUwsR0FBaUIsRUFBakI7QUFDQSxTQUFLMEcsUUFBTCxHQUFnQixJQUFoQjtBQUNEOztBQUVEQyxrQkFBaUI7QUFDZixTQUFLRCxRQUFMLEdBQWdCLElBQUlFLFFBQUosRUFBaEI7QUFDQSxTQUFLNUcsU0FBTCxDQUFleEQsSUFBZixDQUFvQixLQUFLa0ssUUFBekI7QUFDRDs7QUFFSzNWLE9BQU4sQ0FBYTFCLE9BQU8sRUFBcEIsRUFBd0IwUSxLQUFLLCtCQUFZLENBQUUsQ0FBZCxDQUE3QjtBQUFBLG9DQUE2QztBQUMzQyxXQUFLNEcsYUFBTDtBQUVBLFVBQUlFLE1BQU0sRUFBVjs7QUFFQSxVQUFJO0FBQ0YsWUFBSTVWLG9CQUFZOE8sSUFBWixDQUFKO0FBRUEyQyxlQUFPQyxNQUFQLENBQWNrRSxHQUFkLEVBQW1CO0FBQ2pCaEwsZ0JBQU0sU0FEVztBQUVqQjlLLGlCQUFPMUIsSUFGVTtBQUdqQnlYLGtCQUFRN1Y7QUFIUyxTQUFuQjtBQUtELE9BUkQsQ0FRRSxPQUFPeUMsQ0FBUCxFQUFVO0FBQ1ZnUCxlQUFPQyxNQUFQLENBQWNrRSxHQUFkLEVBQW1CO0FBQ2pCaEwsZ0JBQU0sT0FEVztBQUVqQjlLLGlCQUFPMUIsSUFGVTtBQUdqQnlYLGtCQUFRekMsVUFBVUMsS0FBVixDQUFnQjVRLENBQWhCO0FBSFMsU0FBbkI7QUFLRCxPQWRELFNBY1U7QUFDUixZQUFJLEtBQUtnVCxRQUFMLENBQWNLLEtBQWxCLEVBQXlCO0FBQ3ZCckUsaUJBQU9DLE1BQVAsQ0FBY2tFLEdBQWQsRUFBbUI7QUFDakJILHNCQUFVLEtBQUtBO0FBREUsV0FBbkI7QUFHRDs7QUFDRCxhQUFLdFYsTUFBTCxDQUFZb0wsSUFBWixDQUFpQnFLLEdBQWpCO0FBQ0Q7QUFDRixLQTNCRDtBQUFBOztBQTZCQTVPLFdBQVUrTyxTQUFWLEVBQXFCO0FBQ25CLFNBQUtOLFFBQUwsQ0FBY08sT0FBZCxDQUFzQkQsU0FBdEI7QUFDRDs7QUFFRHJULFNBQVFxVCxTQUFSLEVBQW1CO0FBQ2pCLFNBQUtOLFFBQUwsQ0FBY2xYLEtBQWQsQ0FBb0I2VSxVQUFVQyxLQUFWLENBQWdCMEMsU0FBaEIsQ0FBcEI7QUFDRDs7QUFFREUsaUJBQWdCO0FBQ2QsUUFBSUMsV0FBVyxLQUFLbkgsU0FBTCxDQUFlbkssSUFBZixDQUFvQm5DLEtBQUtBLEVBQUV3VCxZQUFGLEVBQXpCLENBQWY7QUFDQSxRQUFJRSxXQUFXLEtBQWY7O0FBQ0EsU0FBSyxJQUFJUCxHQUFULElBQWdCLEtBQUt6VixNQUFyQixFQUE2QjtBQUMzQixVQUFJeVYsSUFBSWhMLElBQUosS0FBYSxPQUFqQixFQUEwQjtBQUN4QnVMLG1CQUFXLElBQVg7QUFDQTtBQUNEO0FBQ0Y7O0FBQ0QsV0FBT0QsWUFBWUMsUUFBbkI7QUFDRDs7QUFFRGhTLFlBQVc7QUFDVCxRQUFJLEtBQUs4UixZQUFMLEVBQUosRUFBeUI7QUFDdkIsWUFBTSxJQUFJN1ksT0FBTytOLEtBQVgsQ0FBaUIsS0FBS2hMLE1BQXRCLENBQU47QUFDRDs7QUFDRCxXQUFPLEtBQUtBLE1BQVo7QUFDRDs7QUFsRXlCOztBQXFFNUIsTUFBTXdWLFFBQU4sQ0FBZTtBQUNibkwsZ0JBQWU7QUFDYixTQUFLc0wsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLTSxLQUFMLEdBQWE7QUFDWEosZUFBUztBQUNQRixlQUFPLENBREE7QUFFUE8saUJBQVM7QUFGRixPQURFO0FBS1g5WCxhQUFPO0FBQ0x1WCxlQUFPLENBREY7QUFFTE8saUJBQVM7QUFGSjtBQUxJLEtBQWI7QUFVRDs7QUFFREwsVUFBU0QsU0FBVCxFQUFvQjtBQUNsQixRQUFJQSxTQUFKLEVBQWU7QUFDYixXQUFLSyxLQUFMLENBQVdKLE9BQVgsQ0FBbUJLLE9BQW5CLENBQTJCOUssSUFBM0IsQ0FBZ0N3SyxTQUFoQztBQUNEOztBQUNELFNBQUtLLEtBQUwsQ0FBV0osT0FBWCxDQUFtQkYsS0FBbkI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBQ0R2WCxRQUFPd1gsU0FBUCxFQUFrQjtBQUNoQjtBQUNBLFFBQUlPLFlBQVksSUFBaEI7QUFDQSxRQUFJakssUUFBUSxLQUFLK0osS0FBTCxDQUFXN1gsS0FBWCxDQUFpQjhYLE9BQWpCLENBQXlCL0ksTUFBckM7O0FBQ0EsUUFBSWpCLEtBQUosRUFBVztBQUNUaUssa0JBQVksS0FBS0YsS0FBTCxDQUFXN1gsS0FBWCxDQUFpQjhYLE9BQWpCLENBQXlCaEssUUFBUSxDQUFqQyxDQUFaO0FBQ0QsS0FOZSxDQVFoQjs7O0FBQ0EsUUFBSTFOLEtBQUtDLFNBQUwsQ0FBZTBYLFNBQWYsTUFBOEIzWCxLQUFLQyxTQUFMLENBQWVtWCxTQUFmLENBQWxDLEVBQTZEO0FBQzNELFVBQUlBLGFBQWFBLGNBQWMsRUFBM0IsSUFBaUNBLGNBQWMsRUFBbkQsRUFBdUQ7QUFDckQsYUFBS0ssS0FBTCxDQUFXN1gsS0FBWCxDQUFpQjhYLE9BQWpCLENBQXlCOUssSUFBekIsQ0FBOEJ3SyxTQUE5QjtBQUNEO0FBQ0Y7O0FBQ0QsU0FBS0ssS0FBTCxDQUFXN1gsS0FBWCxDQUFpQnVYLEtBQWpCO0FBQ0EsU0FBS0EsS0FBTDtBQUNEOztBQUVERyxpQkFBZ0I7QUFDZCxXQUFPLEtBQUtHLEtBQUwsQ0FBVzdYLEtBQVgsQ0FBaUJ1WCxLQUF4QjtBQUNEOztBQTFDWSxDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIChyZXEsIHJlcywgbmV4dCkgPT4ge1xyXG4vLyAgIHJlcy53cml0ZUhlYWQoMjAwKTtcclxuLy8gICByZXMuZW5kKGBIZWxsbyB3b3JsZCBmcm9tOiAke01ldGVvci5yZWxlYXNlfWApO1xyXG4vLyB9KTtcclxuXHJcbmltcG9ydCBmcyBmcm9tICdmcyc7XHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJztcclxuXHJcbi8vIFJlcXVpcmVzIG11bHRpcGFydHkgXHJcbmltcG9ydCBtdWx0aXBhcnR5IGZyb20gJ2Nvbm5lY3QtbXVsdGlwYXJ0eSc7XHJcbmltcG9ydCB7XHJcbiAgVXBsb2Fkc1xyXG59IGZyb20gJy4uLy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi91cGxvYWRzJztcclxubGV0IG11bHRpcGFydHlNaWRkbGV3YXJlID0gbXVsdGlwYXJ0eSgpO1xyXG5cclxuY29uc3Qgcm91dGUgPSAnL3VwbG9hZC9pbWFnZSc7XHJcblxyXG4vLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIGZ1Yy51cGxvYWRGaWxlICk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCBtdWx0aXBhcnR5TWlkZGxld2FyZSk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCAocmVxLCByZXNwKSA9PiB7XHJcbiAgLy8gZG9uJ3QgZm9yZ2V0IHRvIGRlbGV0ZSBhbGwgcmVxLmZpbGVzIHdoZW4gZG9uZVxyXG5cclxuICBjb25zdCByZWFkZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLnJlYWRGaWxlKTtcclxuICBjb25zdCB3cml0ZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLndyaXRlRmlsZSk7XHJcbiAgY29uc3QgdXBsb2FkSWQgPSB1bmlxaWQoKTtcclxuXHJcbiAgZm9yIChsZXQgZmlsZSBvZiByZXEuZmlsZXMuZmlsZSkge1xyXG4gICAgY29uc3QgZGF0YSA9IHJlYWRlcihmaWxlLnBhdGgpO1xyXG4gICAgLy8g44OV44Kh44Kk44Or5ZCN44Gu6YeN6KSH44KS6YG/44GR44KL44Gf44KB44CB5LiA5oSP44Gu44OV44Kh44Kk44Or5ZCN44KS5L2c5oiQ44GZ44KLXHJcbiAgICAvLyDmpb3lpKnjga7jg5XjgqHjgqTjg6vlkI3mloflrZfmlbDliLbpmZAyMOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IGZpbGVuYW1lID0gYCR7dW5pcWlkKCl9LmpwZ2BcclxuXHJcbiAgICAvLyBzZXQgdGhlIGNvcnJlY3QgcGF0aCBmb3IgdGhlIGZpbGUgbm90IHRoZSB0ZW1wb3Jhcnkgb25lIGZyb20gdGhlIEFQSTpcclxuICAgIGxldCBzYXZlUGF0aCA9IHJlcS5ib2R5LmltYWdlZGlyICsgJy8nICsgZmlsZW5hbWU7XHJcblxyXG4gICAgLy8gY29weSB0aGUgZGF0YSBmcm9tIHRoZSByZXEuZmlsZXMuZmlsZS5wYXRoIGFuZCBwYXN0ZSBpdCB0byBmaWxlLnBhdGhcclxuXHJcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nntZDmnpzjgpLoqJjpjLLjgZnjgotcclxuICAgIGxldCBkb2MgPSB7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgICAgY2xpZW50RmlsZU5hbWU6IGZpbGUubmFtZSxcclxuICAgICAgdXBsb2FkZWRGaWxlTmFtZTogZmlsZW5hbWVcclxuICAgIH07XHJcbiAgICBcclxuICAgIHRyeXtcclxuICAgICAgd3JpdGVyKHNhdmVQYXRoLCBkYXRhKTtcclxuICAgIH1cclxuICAgIGNhdGNoKGVycil7XHJcbiAgICAgIGRvYy5lcnJvciA9IGVycjtcclxuICAgIH1cclxuICAgIFVwbG9hZHMuaW5zZXJ0KGRvYyk7XHJcblxyXG4gICAgZGVsZXRlIGZpbGU7XHJcblxyXG4gIH07XHJcbiAgcmVzcC53cml0ZUhlYWQoMjAwKTtcclxuICByZXNwLmVuZChKU09OLnN0cmluZ2lmeSh7XHJcbiAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICBzYXZlRGlyOiByZXEuYm9keS5pbWFnZWRpclxyXG4gIH0pKTtcclxuXHJcbn0pOyIsImltcG9ydCBjcnlwdG8gZnJvbSAnY3J5cHRvJ1xyXG5cclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IFJlcG9ydCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIEdyb3VwLFxyXG4gIEdyb3VwRmFjdG9yeVxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9ncm91cHMnXHJcbmltcG9ydCB7XHJcbiAgRmlsdGVyXHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2ZpbHRlcnMnXHJcblxyXG5sZXQgdGFnID0gJ2N1YmVtaWcnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm1pZ3JhdGVgXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgLy8gc2V0dXAgZ3JvdXBcclxuICAgIC8vXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBGaWx0ZXIoY29uZmlnLnNyY0ZpbHRlcklkKVxyXG4gICAgLy8gbGV0IHBsdWcgPSBncm91cC5nZXRQbHVnKCk7XHJcblxyXG4gICAgLy8gY2hlY2tpbmcgY29ubmVjdGlvblxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgdGVzdFF1ZXJ5ID0gJ1NIT1cgREFUQUJBU0VTJ1xyXG5cclxuICAgIGxldCBkc3REYiA9IG5ldyBNeVNRTChjb25maWcuZHN0LmNyZWQpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKCdDb25uZWN0IHRvIERlc3RpbmF0aW9uJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5KHRlc3RRdWVyeSlcclxuICAgICAgfSlcclxuXHJcbiAgICAvLyBwcm9jZXNzIGZvciBlYWNoIG1lbWJlcnNcclxuICAgIC8vXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKCdTZWxlY3QgbG9vcCBpbiBzb3VyY2UnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgIG1vYmlsZU51bGw6IGFzeW5jIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgLy8gLy8g5YCk44KS5pW055CGXHJcbiAgICAgICAgICAgIC8vIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgIC8vICAgaWYgKHJlY29yZFtrZXldID09PSBudWxsKTtcclxuICAgICAgICAgICAgLy8gICBlbHNlIGlmIChyZWNvcmRba2V5XS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnRGF0ZScpIHtcclxuICAgICAgICAgICAgLy8gICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgICAgICAvLyAgICAgcmVjb3JkW2tleV0gPSBNeVNRTC5mb3JtYXREYXRlKHJlY29yZFtrZXldKTtcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gYFwiJHtyZWNvcmRba2V5XX1cImA7XHJcbiAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXIg44Gr5L+d5a2YXHJcblxyXG4gICAgICAgICAgICBsZXQgc3FsID0gYFxyXG5cclxuICAgICAgICAgICAgICAgIElOU0VSVCBkdGJfY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICggXFxgY3VzdG9tZXJfaWRcXGAsIFxcYHN0YXR1c1xcYCwgXFxgc2V4XFxgLCBcXGBqb2JcXGAsIFxcYGNvdW50cnlfaWRcXGAsIFxcYHByZWZcXGAsIFxcYG5hbWUwMVxcYCwgXFxgbmFtZTAyXFxgLCBcXGBrYW5hMDFcXGAsIFxcYGthbmEwMlxcYCwgXFxgY29tcGFueV9uYW1lXFxgLCBcXGB6aXAwMVxcYCwgXFxgemlwMDJcXGAsIFxcYHppcGNvZGVcXGAsIFxcYGFkZHIwMVxcYCwgXFxgYWRkcjAyXFxgLCBcXGBlbWFpbFxcYCwgXFxgdGVsMDFcXGAsIFxcYHRlbDAyXFxgLCBcXGB0ZWwwM1xcYCwgXFxgZmF4MDFcXGAsIFxcYGZheDAyXFxgLCBcXGBmYXgwM1xcYCwgXFxgYmlydGhcXGAsIFxcYHBhc3N3b3JkXFxgLCBcXGBzYWx0XFxgLCBcXGBzZWNyZXRfa2V5XFxgLCBcXGBmaXJzdF9idXlfZGF0ZVxcYCwgXFxgbGFzdF9idXlfZGF0ZVxcYCwgXFxgYnV5X3RpbWVzXFxgLCBcXGBidXlfdG90YWxcXGAsIFxcYG5vdGVcXGAsIFxcYGNyZWF0ZV9kYXRlXFxgLCBcXGB1cGRhdGVfZGF0ZVxcYCwgXFxgZGVsX2ZsZ1xcYCApXHJcblxyXG4gICAgICAgICAgICAgICAgVkFMVUVTKCAke3JlY29yZC5jdXN0b21lcl9pZH0gLCAke3JlY29yZC5zdGF0dXN9ICwgJHtyZWNvcmQuc2V4fSAsICR7cmVjb3JkLmpvYn0gLCAke3JlY29yZC5jb3VudHJ5X2lkfSAsICR7cmVjb3JkLnByZWZ9ICwgJHtyZWNvcmQubmFtZTAxfSAsICR7cmVjb3JkLm5hbWUwMn0gLCAke3JlY29yZC5rYW5hMDF9ICwgJHtyZWNvcmQua2FuYTAyfSAsICR7cmVjb3JkLmNvbXBhbnlfbmFtZX0gLCAke3JlY29yZC56aXAwMX0gLCAke3JlY29yZC56aXAwMn0gLCAke3JlY29yZC56aXBjb2RlfSAsICR7cmVjb3JkLmFkZHIwMX0gLCAke3JlY29yZC5hZGRyMDJ9ICwgJHtyZWNvcmQuZW1haWx9ICwgJHtyZWNvcmQudGVsMDF9ICwgJHtyZWNvcmQudGVsMDJ9ICwgJHtyZWNvcmQudGVsMDN9ICwgJHtyZWNvcmQuZmF4MDF9ICwgJHtyZWNvcmQuZmF4MDJ9ICwgJHtyZWNvcmQuZmF4MDN9ICwgJHtyZWNvcmQuYmlydGh9ICwgJHtyZWNvcmQucGFzc3dvcmR9ICwgJHtyZWNvcmQuc2FsdH0gLCAke3JlY29yZC5zZWNyZXRfa2V5fSAsICR7cmVjb3JkLmZpcnN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmxhc3RfYnV5X2RhdGV9ICwgJHtyZWNvcmQuYnV5X3RpbWVzfSAsICR7cmVjb3JkLmJ1eV90b3RhbH0gLCAke3JlY29yZC5ub3RlfSAsICR7cmVjb3JkLmNyZWF0ZV9kYXRlfSAsICR7cmVjb3JkLnVwZGF0ZV9kYXRlfSAsICR7cmVjb3JkLmRlbF9mbGd9IClcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgYFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdkdGJfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVjb3JkLnN0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgc2V4OiByZWNvcmQuc2V4LFxyXG4gICAgICAgICAgICAgICAgICBqb2I6IHJlY29yZC5qb2IsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgZW1haWw6IHJlY29yZC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgYmlydGg6IHJlY29yZC5iaXJ0aCxcclxuICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHJlY29yZC5wYXNzd29yZCxcclxuICAgICAgICAgICAgICAgICAgc2FsdDogcmVjb3JkLnNhbHQsXHJcbiAgICAgICAgICAgICAgICAgIHNlY3JldF9rZXk6IHJlY29yZC5zZWNyZXRfa2V5LFxyXG4gICAgICAgICAgICAgICAgICBmaXJzdF9idXlfZGF0ZTogcmVjb3JkLmZpcnN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBsYXN0X2J1eV9kYXRlOiByZWNvcmQubGFzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RpbWVzOiByZWNvcmQuYnV5X3RpbWVzLFxyXG4gICAgICAgICAgICAgICAgICBidXlfdG90YWw6IHJlY29yZC5idXlfdG90YWwsXHJcbiAgICAgICAgICAgICAgICAgIG5vdGU6IHJlY29yZC5ub3RlLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyX2FkZHJlc3NcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdkdGJfY3VzdG9tZXJfYWRkcmVzcycsIHtcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfYWRkcmVzc19pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8g44Oh44Or44Oe44Ks44OX44Op44Kw44Kk44OzIHBsZ19tYWlsbWFnYV9jdXN0b21lclxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ3BsZ19tYWlsbWFnYV9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIG1haWxtYWdhX2ZsZzogcmVjb3JkLm1haWxtYWdhX2ZsZyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOOCr+ODvOODneODs+eZuuihjO+8iEVDQ1VCRTLjga7jg53jgqTjg7Pjg4jpgoTlhYPvvIlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25DZCA9IGNyeXB0by5yYW5kb21CeXRlcyg4KS50b1N0cmluZygnYmFzZTY0Jykuc3Vic3RyaW5nKDAsIDExKVxyXG5cclxuICAgICAgICAgICAgbGV0IGNvdXBvbk5hbWUgPSBgJHtyZWNvcmQubmFtZTAxfSAke3JlY29yZC5uYW1lMDJ9IOanmCDjgZTlhKrlvoXjgq/jg7zjg53jg7Mg5Lya5ZOh55Wq5Y+3OiR7cmVjb3JkLmN1c3RvbWVyX2lkfWBcclxuXHJcbiAgICAgICAgICAgIGxldCBkaXNjb3VudFByaWNlID0gcmVjb3JkLnBvaW50ICsgNTAwXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfY291cG9uJywge1xyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25faWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9jZDogY291cG9uQ2QsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl90eXBlOiAzLCAvLyDlhajllYblk4FcclxuICAgICAgICAgICAgICAgICAgY291cG9uX25hbWU6IGNvdXBvbk5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3R5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl91c2VfdGltZTogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3JlbGVhc2U6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3ByaWNlOiBkaXNjb3VudFByaWNlLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9yYXRlOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBlbmFibGVfZmxhZzogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX21lbWJlcjogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2xvd2VyX2xpbWl0OiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfZnJvbV9kYXRlOiAnMjAxOC0wNC0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV90b19kYXRlOiAnMjAxOS0wNS0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IDBcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIGFzeW5jICdjdWJlbWlnLnNlcnZlckNoZWNrJyAocHJvZmlsZSkge1xyXG4gICAgbGV0IGRiID0gbmV3IE15U1FMKHByb2ZpbGUpXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgZGIucXVlcnkoJ1NIT1cgREFUQUJBU0VTJylcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgeyBNb25nb0NvbGxlY3Rpb24gfSBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbW9uZ28nXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdqbGluZS5jb2xsZWN0aW9uJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5maW5kYF0gKHBsdWcsIHF1ZXJ5ID0ge30sIHByb2plY3Rpb24gPSB7fSkge1xyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbilcclxuICAgIGxldCByZXMgPSBhd2FpdCBjb2xsLmZpbmQocXVlcnksIHtwcm9qZWN0aW9uOiBwcm9qZWN0aW9ufSkudG9BcnJheSgpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uYWdncmVnYXRlYF0gKHBsdWcsIHF1ZXJ5ID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5hZ2dyZWdhdGUocXVlcnkpLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi8uLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdqbGluZS5pdGVtcydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgb7jgZnjgIJcclxuICAgKiBAcGFyYW1cclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5zZXRJbWFnZWBdIChwbHVnLCB1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgbGV0IHVwbG9hZGVkID0gYXdhaXQgaXRlbWNvbi5zZXRJbWFnZSh1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSwgY2xhc3MyKVxyXG4gICAgcmV0dXJuIHVwbG9hZGVkXHJcbiAgfSxcclxuXHJcbiAgLyoqXHJcbiAgICog44Ki44Kk44OG44Og5oOF5aCx44OH44O844K/44OZ44O844K544Gu55S75YOP55m76Yyy44KS5YmK6Zmk44GZ44KL77yI55S75YOP6Ieq5L2T44Gv5YmK6Zmk44GX44Gq44GE77yJXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uY2xlYW5JbWFnZWBdIChwbHVnLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpXHJcbiAgICBhd2FpdCBpdGVtY29uLmNsZWFuSW1hZ2UobW9kZWwsIGNsYXNzMSwgY2xhc3MyKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQge1xyXG4gIEN1YmUzQXBpXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2N1YmUnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5Zyo5bqr5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZVN0b2NrYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgIGxldCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgIGxldCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQilcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn5Zyo5bqr44Gu5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5KVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx55m76Yyy44Go5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliSXRlbWBdIChjb25maWcpIHtcclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpXHJcbiAgICBsZXQgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKVxyXG5cclxuICAgIGxldCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0VDQ1VCRTPjgbjjga7llYblk4HnmbvpjLInLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICdJTlNFUlQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgY29sID0gY29udGV4dC5jb2xsZWN0aW9uXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCBjdWJlSXRlbSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnLmNyZWF0b3JfaWQsIGl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIGxldCBpbnNlcnRSZXMgPSBhd2FpdCBhcGkucHJvZHVjdENyZWF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgLy8gaXRlbSDjg4fjg7zjgr/jg5njg7zjgrnjgbjjga7nmbvpjLJcclxuICAgICAgICAgICAgICBhd2FpdCBjb2wudXBkYXRlKHtcclxuICAgICAgICAgICAgICAgIF9pZDogaXRlbS5faWRcclxuICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICAgICAgICAgICdtYWxsLnNoYXJha3VTaG9wJzogaW5zZXJ0UmVzLnJlc1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH0pXHJcblxyXG4gICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0VDQ1VCRTPllYblk4Hmg4XloLHjga7mm7TmlrAnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICdVUERBVEUnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgY29sID0gY29udGV4dC5jb2xsZWN0aW9uXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCBjdWJlSXRlbSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnLmNyZWF0b3JfaWQsIGl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0SW1hZ2VVcGRhdGUoY3ViZUl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RVcGRhdGUoY3ViZUl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RUYWdVcGRhdGUoY3ViZUl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS51cGRhdGVTdG9jayhpdGVtLm1hbGwuc2hhcmFrdVNob3AucHJvZHVjdF9jbGFzc19pZCwgcXVhbnRpdHkpXHJcblxyXG4gICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9LFxyXG4gICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICd0b29sJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS50ZXN0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuXHJcbiAgICBjb25zdCBuZXdMb2NhbCA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHt9LCBhc3luYyAoZSkgPT4ge1xyXG4gICAgICB0aHJvdyBlXHJcbiAgICB9KVxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44OV44Kj44Or44K/44O844OG44K544OIJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBuZXdMb2NhbFxyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IFBhY2tldCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcGFja2V0J1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgYXJjaGl2ZXIgZnJvbSAnYXJjaGl2ZXInXHJcblxyXG5jb25zdCBwcmVmaXggPSAncGFja2V0J1xyXG5jb25zdCB0YWcgPSAneWF1Y3QnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g44Ok44OV44Kq44Kv5Ye65ZOB44OV44Kh44Kk44OrXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliaXRgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lh7rlk4Hjg5XjgqHjgqTjg6snLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy8g5Yid5pyf5YyW5Yem55CGXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgY29uc3QgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgICAgIGNvbnN0IGl0ZW1Db250cm9sbGVyID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgICAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgICAgICAvLyDnubDjgorov5TjgZflh6bnkIbjgpLku7vmhI/jga7vvIhwYWNrZXRTaXpl77yJ44Gn5YiG5YmyXHJcbiAgICAgICAgY29uc3QgcGFja2V0ID0gbmV3IFBhY2tldChjb25maWcucGFja2V0U2l6ZSlcclxuXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA5YaF44KS44GZ44G544Gm44Kv44Oq44Ki44GX44Gm44GK44GPXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuXHJcbiAgICAgICAgbGV0IGNkID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jjg5Xjgqnjg6vjg4BcclxuICAgICAgICBsZXQgZmlsZW5hbWUgPSBudWxsIC8vIGNzduODleOCoeOCpOODq1xyXG4gICAgICAgIGxldCBuYW1lID0gbnVsbCAvLyDjg5HjgrHjg4Pjg4jnlarlj7dcclxuXHJcbiAgICAgICAgLy8gQ1NW44OV44Kj44O844Or44OJ44KS5a6a576p44GX44CB6aCG55Wq44KS56K65a6a44GZ44KLXHJcbiAgICAgICAgbGV0IGZpZWxkcyA9IFsn566h55CG55Wq5Y+3JywgJ+OCq+ODhuOCtOODqicsICfjgr/jgqTjg4jjg6snLCAn6Kqs5piOJywgJ+OCueODiOOCouWGheWVhuWTgeaknOe0oueUqOOCreODvOODr+ODvOODiScsICfplovlp4vkvqHmoLwnLCAn5Y2z5rG65L6h5qC8JywgJ+WApOS4i+OBkuS6pOa4iScsICflgIvmlbAnLCAn5YWl5pyt5YCL5pWw5Yi26ZmQJywgJ+acn+mWkycsICfntYLkuobmmYLplpMnLCAn5ZWG5ZOB55m66YCB5YWD44Gu6YO96YGT5bqc55yMJywgJ+WVhuWTgeeZuumAgeWFg+OBruW4guWMuueUuuadkScsICfpgIHmlpnosqDmi4UnLCAn5Luj6YeR5YWI5omV44GE44CB5b6M5omV44GEJywgJ+iQveacreODiuODk+axuua4iOaWueazleioreWumicsICfllYblk4Hjga7nirbmhYsnLCAn5ZWG5ZOB44Gu54q25oWL5YKZ6ICDJywgJ+i/lOWTgeOBruWPr+WQpicsICfov5Tlk4Hjga7lj6/lkKblgpnogIMnLCAn55S75YOPMScsICfnlLvlg48x44Kz44Oh44Oz44OIJywgJ+eUu+WDjzInLCAn55S75YOPMuOCs+ODoeODs+ODiCcsICfnlLvlg48zJywgJ+eUu+WDjzPjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNCcsICfnlLvlg48044Kz44Oh44Oz44OIJywgJ+eUu+WDjzUnLCAn55S75YOPNeOCs+ODoeODs+ODiCcsICfnlLvlg482JywgJ+eUu+WDjzbjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNycsICfnlLvlg48344Kz44Oh44Oz44OIJywgJ+eUu+WDjzgnLCAn55S75YOPOOOCs+ODoeODs+ODiCcsICfnlLvlg485JywgJ+eUu+WDjznjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMTAnLCAn55S75YOPMTDjgrPjg6Hjg7Pjg4gnLCAn5pyA5L2O6KmV5L6hJywgJ+aCquipleWJsuWQiOWItumZkCcsICflhaXmnK3ogIXoqo3oqLzliLbpmZAnLCAn6Ieq5YuV5bu26ZW3JywgJ+aXqeacn+e1guS6hicsICfllYblk4Hjga7oh6rli5Xlho3lh7rlk4EnLCAn6Ieq5YuV5YCk5LiL44GSJywgJ+acgOS9juiQveacreS+oeagvCcsICfjg4Hjg6Pjg6rjg4bjgqPjg7wnLCAn5rOo55uu44Gu44Kq44O844Kv44K344On44OzJywgJ+WkquWtl+ODhuOCreOCueODiCcsICfog4zmma/oibInLCAn44K544OI44Ki44Ob44OD44OI44Kq44O844Kv44K344On44OzJywgJ+ebrueri+OBoeOCouOCpOOCs+ODsycsICfotIjnrZTlk4HjgqLjgqTjgrPjg7MnLCAnVOODneOCpOODs+ODiOOCquODl+OCt+ODp+ODsycsICfjgqLjg5XjgqPjg6rjgqjjgqTjg4jjgqrjg5fjgrfjg6fjg7MnLCAn6I2354mp44Gu5aSn44GN44GVJywgJ+iNt+eJqeOBrumHjemHjycsICfjga/jgZNCT09OJywgJ+OBneOBruS7lumFjemAgeaWueazlTEnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTInLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTMnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTQnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTUnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTYnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTcnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+aWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTgnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTknLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55YWo5Zu95LiA5b6L5L6h5qC8JywgJ+OBneOBruS7lumFjemAgeaWueazlTEwJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTEw5YWo5Zu95LiA5b6L5L6h5qC8JywgJ+a1t+WklueZuumAgScsICfphY3pgIHmlrnms5Xjg7vpgIHmlpnoqK3lrponLCAn5Luj5byV5omL5pWw5paZ6Kit5a6aJywgJ+a2iOiyu+eojuioreWumicsICdKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ11cclxuICAgICAgICBsZXQgaGVhZGVyID0gZmllbGRzLm1hcCh2ID0+IGBcIiR7dn1cImApLmpvaW4oJywnKSArICdcXG4nXHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOWMlumWi+Wni+aZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldFN0YXJ0ID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBuYW1lID0gcHJlZml4ICsgKCcwMDAwMCcgKyBwYWNrZXRDb3VudCkuc2xpY2UoLTUpXHJcbiAgICAgICAgICBjZCA9IGAke2NvbmZpZy53b3JrZGlyfS8ke25hbWV9YFxyXG4gICAgICAgICAgZmlsZW5hbWUgPSBgJHtjZH0vJHtjb25maWcuY3N2RmlsZU5hbWV9YFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2RpcihjZClcclxuICAgICAgICAgIC8vIENTVuODleOCoeOCpOODq+OBq+ODleOCo+ODvOODq+ODieOCkuioreWumuOBmeOCi1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUoaGVhZGVyLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXQgPSBhc3luYyAoYXJnKSA9PiB7XHJcbiAgICAgICAgICBsZXQgeWF1Y3QgPSBhcmcueWF1Y3RcclxuICAgICAgICAgIGxldCBpdGVtID0gYXJnLml0ZW1cclxuICAgICAgICAgIC8vIGNzduODleOCoeOCpOODq+OBq+ODrOOCs+ODvOODie+8iOWVhuWTgeODhuODs+ODl+ODrOODvOODiO+8ieOCkui/veWKoOOBmeOCi1xyXG4gICAgICAgICAgbGV0IHJlY29yZCA9IGZpZWxkcy5tYXAodiA9PiB7IHJldHVybiB5YXVjdFt2XSA/IGBcIiR7eWF1Y3Rbdl19XCJgIDogJ1wiXCInIH0pLmpvaW4oJywnKSArICdcXG4nXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShyZWNvcmQsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICAgIC8vIOeUu+WDj+ODleOCoeOCpOODq+OCkuOCs+ODlOODvFxyXG4gICAgICAgICAgZm9yIChsZXQgaW1nIG9mIGl0ZW0uaW1hZ2VzKSB7XHJcbiAgICAgICAgICAgIGxldCBpbWdTcmMgPSBgJHtjb25maWcuaW1hZ2VkaXJ9LyR7aW1nfWBcclxuICAgICAgICAgICAgbGV0IGltZ1RndCA9IGAke2NkfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgLy8g5ZCM44GY44OV44Kh44Kk44Or44GM44GC44KL5aC05ZCI44Gv44Kz44OU44O844GX44Gq44GEXHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5hY2Nlc3MoaW1nVGd0KVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5jb3B5RmlsZShpbWdTcmMsIGltZ1RndClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI57WC5LqG5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0RW5kID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB6aXAgPSBhcmNoaXZlcignemlwJylcclxuICAgICAgICAgIGNvbnN0IHppcG5hbWUgPSBjZCArICcuemlwJ1xyXG4gICAgICAgICAgY29uc3Qgb3V0cHV0ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbSh6aXBuYW1lKVxyXG4gICAgICAgICAgemlwLnBpcGUob3V0cHV0KVxyXG4gICAgICAgICAgemlwLmRpcmVjdG9yeShjZCwgZmFsc2UpXHJcbiAgICAgICAgICB6aXAuZmluYWxpemUoKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgIC8vIGl0ZW3jgavlrprnvqnjgZXjgozjgabjgYTjgovmnIDkvY7lv4XopoHlnKjluqvjgojjgorlpJrjgYTllYblk4HjgpLlh7rlk4HjgZnjgotcclxuICAgICAgICAgICAgaWYgKHF1YW50aXR5ID49IGl0ZW0ubWFsbC55YXVjdC5taW5RdWFudGl0eSkge1xyXG4gICAgICAgICAgICAgIGxldCB5YXVjdCA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtWWF1Y3QoY29uZmlnLmRlZmF1bHQsIGl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgcGFja2V0LnN1Ym1pdCh7eWF1Y3Q6IHlhdWN0LCBpdGVtOiBpdGVtfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHBhY2tldC5jbG9zZSgpXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCAnLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MnXHJcblxyXG5pbXBvcnQgJy4vcm91dGUvdXBsb2FkL2ltYWdlJ1xyXG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbiBcclxuZXhwb3J0IGNvbnN0IENvbmZpZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29uZmlncycse2lkR2VuZXJhdGlvbjonTU9OR08nfSk7XHJcblxyXG4vLyBNZXRlb3IubWV0aG9kcyh7IFxyXG4vLyAgIGFzeW5jICdteXNxbFNlcnZlcnMuaW5zZXJ0JyAoIG5ld1NlcnZlciApe1xyXG4vLyAgICAgcmV0dXJuIGF3YWl0IE15c3FsU2VydmVycy5pbnNlcnQobmV3U2VydmVyKTtcclxuLy8gICB9XHJcbi8vIH0pO1xyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCc7XHJcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0JztcclxuaW1wb3J0IHsgR3JvdXBCYXNlIH0gZnJvbSAnLi9ncm91cHMnO1xyXG5cclxuY29uc3QgRmlsdGVycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdmaWx0ZXJzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBGaWx0ZXIgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcihmaWx0ZXJJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gRmlsdGVycy5maW5kT25lKHtcclxuICAgICAgX2lkOiBmaWx0ZXJJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG5cclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jICggb25SZXN1bHQgPSAocmVjb3JkKT0+e30sIG9uRXJyb3IgPSAoZSk9Pnt9ICkgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgb25FcnJvcik7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsYXRmb3JtIHR5cGUnKTtcclxuXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge3sgZmlsdGVyVHlwZTogYXN5bmMgKHJlY29yZCApID0+IHt9IH19IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaChjYWxsYmFja3MgPSB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlKCk7XHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgdHlwZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ID0ge307XHJcbiAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgIGNvdW50W2ZpbHRlci50eXBlXSA9IHtcclxuICAgICAgICBxdWVyeTogZmlsdGVyLnF1ZXJ5LFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQpPT57XHJcbiAgICAgICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICAgICAgbGV0IHF1ZXJ5ID0gbW9iamVjdC51bmVzY2FwZShmaWx0ZXIucXVlcnkpO1xyXG4gICAgICAgICAgbGV0IGV4YW0gPSBzaWZ0KCBxdWVyeSApO1xyXG4gICAgICAgICAgaWYoIGV4YW0ocmVjb3JkKSApe1xyXG4gICAgICAgICAgICBjb3VudFtmaWx0ZXIudHlwZV0uY291bnQrKztcclxuICAgICAgICAgICAgaWYoIHR5cGVvZiBjYWxsYmFja3NbZmlsdGVyLnR5cGVdICE9PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2tzW2ZpbHRlci50eXBlXShyZWNvcmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgb25FcnJvclxyXG4gICAgKTtcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50O1xyXG5cclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG5jb25zdCBHcm91cHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZ3JvdXBzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cEJhc2Uge1xyXG5cclxuICBwcm9maWxlO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9maWxlKSB7XHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogZ2V0cyAnUGx1Zycgd2l0Y2ggaXMgYSBzZXQgb2YgcHJvcGVydGllcyBuZWVkZWRcclxuICAgKiB3aGVuIGNvbm5lY3QgdG8gc29tZSBwbGF0Zm9ybXNcclxuICAgKiB0byBnZXQgZGF0YXMoTWVtYmVycyBvZiB0aGUgR3JvdXApXHJcbiAgICovXHJcbiAgZ2V0UGx1ZygpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGUucGxhdGZvcm1QbHVnO1xyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZSgpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHt9O1xyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZ3JvdXBJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gR3JvdXBzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGdyb3VwSWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jIChkb2MpID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9IFdIRVJFIFxcYCR7ZG9jLmtleX1cXGAgPSBcIiR7ZG9jLmlkfVwiYDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgZ3JvdXAgdHlwZScpO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge2FzeW5jIChyZWNvcmQpPT52b2lkfSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBjdXIgPSBHcm91cHMuZmluZCh7XHJcbiAgICAgIGdyb3VwSWQ6IHRoaXMucHJvZmlsZS5faWRcclxuICAgIH0sIHtcclxuICAgICAgZmllbGRzOiB7XHJcbiAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgIGlkOiAxLFxyXG4gICAgICAgIGtleTogMVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBcclxuICAgICAgICBjdXIuZm9yRWFjaChcclxuICAgICAgICAgIGFzeW5jIChkb2MsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlY29yZCA9IGF3YWl0IHRoaXMuaW1wb3J0KGRvYyk7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2socmVjb3JkKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIG9uRXJyb3IoZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGluZGV4ICsgMSA9PT0gY3VyLmNvdW50KCkpIHtcclxuICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgfVxyXG4gICAgKS5jYXRjaChcclxuICAgICAgKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICB9XHJcblxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG4gXHJcbmV4cG9ydCBjb25zdCBVcGxvYWRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VwbG9hZHMnLHtpZEdlbmVyYXRpb246J01PTkdPJ30pO1xyXG5cclxuIiwiaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuXHJcbmV4cG9ydCBjbGFzcyBDdWJlM0FwaSB7XHJcbiAgY29uc3RydWN0b3IgKG15c3FsID0gbmV3IE15U1FMKCkpIHtcclxuICAgIHRoaXMubXlzcWxfID0gbXlzcWxcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZVN0b2NrIChwcm9kdWN0Q2xhc3NJZCwgcXVhbnRpdHkgPSAwKSB7XHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXHJcbiAgICAgIHt9LCB7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsXHJcbiAgICAgIGBwcm9kdWN0X2NsYXNzX2lkID0gJHtwcm9kdWN0Q2xhc3NJZH1gLFxyXG4gICAgICB7fSwge1xyXG4gICAgICAgIHN0b2NrOiBxdWFudGl0eSxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VGFnVXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IFtdXHJcblxyXG4gICAgLy8g5YmK6Zmk44GZ44KL44K/44KwXHJcbiAgICBsZXQgdGFnb2ZmID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICBsZXQgc3FsID0gYFxyXG4gICAgICBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF90YWcgXHJcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxyXG4gICAgICBgXHJcbiAgICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbCkpXHJcbiAgICB9XHJcblxyXG4gICAgLy8g6KGo56S644GZ44KL44K/44KwXHJcbiAgICBsZXQgdGFnb24gPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIC8vIOOBmeOBp+OBq+ihqOekuuOBleOCjOOBpuOBhOOCi+OCv+OCsOOBjOOBguOCjOOBsOS9leOCguOBl+OBquOBhFxyXG4gICAgICBsZXQgc3FsID0gYFxyXG4gICAgICBTRUxFQ1QgQ09VTlQoKikgRlJPTSBkdGJfcHJvZHVjdF90YWcgXHJcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxyXG4gICAgICBgXHJcbiAgICAgIGxldCBjb3VudFJlcyA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbClcclxuICAgICAgaWYgKGNvdW50UmVzWzBdWydDT1VOVCgqKSddKSByZXR1cm5cclxuXHJcbiAgICAgIHJlcy5wdXNoKFxyXG4gICAgICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgJ2R0Yl9wcm9kdWN0X3RhZycsXHJcbiAgICAgICAgICB7fSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgcHJvZHVjdF9pZDogZGF0YS5wcm9kdWN0X2lkLFxyXG4gICAgICAgICAgICB0YWc6IHRhZyxcclxuICAgICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICkpXHJcbiAgICB9XHJcblxyXG4gICAgZm9yIChsZXQgdGFnU2V0IG9mIGRhdGEudGFncykge1xyXG4gICAgICBzd2l0Y2ggKHRhZ1NldC5zZXQpIHtcclxuICAgICAgICBjYXNlICdvbic6XHJcbiAgICAgICAgICBhd2FpdCB0YWdvbih0YWdTZXQudGFnKVxyXG4gICAgICAgICAgYnJlYWtcclxuICAgICAgICBjYXNlICdvZmYnOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb2ZmKHRhZ1NldC50YWcpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RJbWFnZVVwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IHByb2R1Y3RJZCA9IGRhdGEucHJvZHVjdF9pZFxyXG4gICAgbGV0IGltYWdlcyA9IGRhdGEuaW1hZ2VzXHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IFtdXHJcblxyXG4gICAgLy8g5ZWG5ZOB44Gr6Zai6YCj44GZ44KL44GZ44G544Gm44Gu55S75YOP5oOF5aCx44KS5YmK6Zmk44GZ44KLXHJcbiAgICBsZXQgc3FsID0gYERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X2ltYWdlIFdIRVJFIHByb2R1Y3RfaWQgPSAke3Byb2R1Y3RJZH1gXHJcbiAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpKVxyXG5cclxuICAgIC8vIOaUueOCgeOBpueUu+WDj+OCkueZu+mMsuOBl+OBquOBiuOBmVxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgJ2R0Yl9wcm9kdWN0X2ltYWdlJywge1xyXG4gICAgICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdElkLFxyXG4gICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgICAgZmlsZV9uYW1lOiBpbWFnZXNbaV0sXHJcbiAgICAgICAgICByYW5rOiBpICsgMVxyXG4gICAgICAgIH0sIHtcclxuICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCB1cGRhdGVEYXRhID0ge31cclxuICAgIGxldCBrZXlzID0gW11cclxuXHJcbiAgICAvLyBkdGJfcHJvZHVjdFxyXG5cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdzdGF0dXMnLFxyXG4gICAgICAnbmFtZScsXHJcbiAgICAgICdub3RlJyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2xpc3QnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJyxcclxuICAgICAgJ3NlYXJjaF93b3JkJyxcclxuICAgICAgJ2ZyZWVfYXJlYSdcclxuICAgIF1cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcclxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0X2NsYXNzXHJcblxyXG4gICAgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnZGVsaXZlcnlfZGF0ZV9pZCcsXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAnc2FsZV9saW1pdCcsXHJcbiAgICAgICdwcmljZTAxJyxcclxuICAgICAgJ3ByaWNlMDInLFxyXG4gICAgICAnZGVsaXZlcnlfZmVlJ1xyXG4gICAgXVxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgYHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH1gLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0Q3JlYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IHt9XHJcblxyXG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fVxyXG4gICAgbGV0IGtleXMgPSBbXVxyXG5cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCdcclxuICAgIF1cclxuICAgIC8vIHtcclxuICAgIC8vICAgbmFtZTogaXRlbS5uYW1lLFxyXG4gICAgLy8gICBkZXNjcmlwdGlvbl9kZXRhaWw6IGl0ZW0uZGVzY3JpcHRpb24sXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHN0YXR1czogMSxcclxuICAgICAgICBub3RlOiAnTlVMTCcsXHJcbiAgICAgICAgZGVzY3JpcHRpb25fbGlzdDogJ05VTEwnLFxyXG4gICAgICAgIHNlYXJjaF93b3JkOiAnTlVMTCcsXHJcbiAgICAgICAgZnJlZV9hcmVhOiAnTlVMTCcsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHVwZGF0ZURhdGEgPSB7fVxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdwcm9kdWN0X3R5cGVfaWQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJyxcclxuICAgICAgJ2RlbGl2ZXJ5X2ZlZSdcclxuICAgIF1cclxuICAgIC8vIHtcclxuICAgIC8vICAgcHJvZHVjdF9jb2RlOiBpdGVtLm1vZGVsLFxyXG4gICAgLy8gICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcclxuICAgIC8vICAgcHJpY2UwMjogaXRlbS5zYWxlc19wcmljZSxcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2NsYXNzX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgcHJvZHVjdF9pZDogcmVzLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgc3RvY2s6IDAsXHJcbiAgICAgICAgc3RvY2tfdW5saW1pdGVkOiAwLFxyXG4gICAgICAgIGNsYXNzX2NhdGVnb3J5X2lkMTogJ05VTEwnLFxyXG4gICAgICAgIGNsYXNzX2NhdGVnb3J5X2lkMjogJ05VTEwnLFxyXG4gICAgICAgIGRlbGl2ZXJ5X2RhdGVfaWQ6ICdOVUxMJyxcclxuICAgICAgICBzYWxlX2xpbWl0OiAnTlVMTCcsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9zdG9ja19pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLCB7fSwge1xyXG4gICAgICAgIHByb2R1Y3RfY2xhc3NfaWQ6IHJlcy5wcm9kdWN0X2NsYXNzX2lkLFxyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gZm9yIHRlc3RcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJ1xyXG5pbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCdcclxuaW1wb3J0IHtNb25nb0NsaWVudH0gZnJvbSAnbW9uZ29kYidcclxuXHJcbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXHJcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnXHJcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0J1xyXG5cclxuZXhwb3J0IGNsYXNzIERCRmlsdGVyRmFjdG9yeSB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIGxldCBpbnN0YW5jZVxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIGluc3RhbmNlID0gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSlcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gaW5zdGFuY2VcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHRoaXMucGx1ZyA9IHBsdWdcclxuICAgIHRoaXMucHJvZmlsZSA9IHByb2ZpbGVcclxuICB9XHJcblxyXG4gIHN0YXRpYyBmYWN0b3J5IChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgcmV0dXJuIG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsdWcgdHlwZScpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBnZXRQbHVnXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wbHVnXHJcbiAgfVxyXG5cclxuICBnZXRDcmVkXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wbHVnLmNyZWRcclxuICB9XHJcblxyXG4gIGdldFByb2ZpbGVfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGVcclxuICB9XHJcblxyXG4gIHNldEltcG9ydEZ1bmN0aW9uXyAoXHJcbiAgICBmbiA9IGFzeW5jIChvblJlc3VsdCA9IHJlY29yZCA9PiB7fSwgb25FcnJvciA9IGUgPT4ge30pID0+IHt9XHJcbiAgKSB7XHJcbiAgICB0aGlzLmltcG9ydCA9IGZuXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiB1c2VhZ2U6XHJcbiAgICpcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7IE9iamVjdCB9IGl0ZXJhdG9ycyB7IGZpbHRlck5hbWU6IGFzeW5jIChkb2MsY29udGV4dCk9Pnt9LCAuLi4gfSBpdGVyYXRvciBmb3IgZWFjaCBmaWx0ZXJzXHJcbiAgICogQHBhcmFtIHsgYXN5bmMgZnVuY3Rpb24gfSBvbkVycm9yIGVycm9yIGhhbmRsZXIgd2hpbGUgaXRlcmF0aW5nXHJcbiAgICogQHJldHVybnMgeyBPYmplY3QgfSB7IGZpbHRlck5hbWU6IHsgcXVlcnk6IGFueSwgY291bnQ6IG51bWJlciB9LCAuLi4gfVxyXG4gICAqL1xyXG4gIGFzeW5jIGZvcmVhY2ggKGl0ZXJhdG9ycyA9IHt9KSB7XHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZV8oKVxyXG5cclxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXHJcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XHJcbiAgICAgIG5hbWU6ICdtaXNjJyxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBjb3VudGVyID0ge31cclxuICAgIGZvciAobGV0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IGZpbHRlcnMgPSBbXVxyXG5cclxuICAgIGZvciAobGV0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XHJcbiAgICAgIGNvdW50ZXJbZi5uYW1lXSA9IHtcclxuICAgICAgICBxdWVyeTogZi5xdWVyeSxcclxuICAgICAgICBsaW1pdDogdHlwZW9mIGYubGltaXQgIT09ICd1bmRlZmluZWQnID8gZi5saW1pdCA6IDAsXHJcbiAgICAgICAgY291bnQ6IDBcclxuICAgICAgfVxyXG4gICAgICBmaWx0ZXJzLnB1c2goXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbmFtZTogZi5uYW1lLFxyXG4gICAgICAgICAgZXhhbTogc2lmdChtb2JqZWN0LnVuZXNjYXBlKGYucXVlcnkpKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgZm9yIChsZXQgZiBvZiBmaWx0ZXJzKSB7XHJcbiAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgIGxldCBjID0gY291bnRlcltmLm5hbWVdXHJcbiAgICAgICAgICBpZiAoYy5saW1pdCkge1xyXG4gICAgICAgICAgICBpZiAoYy5jb3VudCA+PSBjLmxpbWl0KSB7XHJcbiAgICAgICAgICAgICAgY29udGludWVcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG5cclxuICAgICAgICAgIGlmIChmLmV4YW0ocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyBjb3VudGVyIGxpbWl0ZXJcclxuICAgICAgICAgICAgYy5jb3VudCsrXHJcblxyXG4gICAgICAgICAgICAvLyBpdGVyYXRvclxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZXJhdG9yc1tmLm5hbWVdICE9PSAndW5kZWZpbmVkJykge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGl0ZXJhdG9yc1tmLm5hbWVdKHJlY29yZCwgY29udGV4dClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVha1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50ZXJcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBNeXNxbERCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKVxyXG5cclxuICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpXHJcblxyXG4gICAgdGhpcy5teXNxbCA9IG5ldyBNeVNRTChjcmVkKVxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YFxyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCAoZSkgPT4geyB0aHJvdyBlIH0pXHJcbiAgICAgIHJldHVybiByZXNcclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgTW9uZ29OYXRpdmUgZnJvbSAnbW9uZ29kYic7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gTW9uZ29OYXRpdmUuTW9uZ29DbGllbnQ7XHJcbi8vIGNvbnN0IE1vbmdvQ2xpZW50ID0gcmVxdWlyZSgnbW9uZ29kYicpLk1vbmdvQ2xpZW50O1xyXG5cclxuZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpXHJcblxyXG4gICAgLy8gbW9uZ28g44G45o6l57aaXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgbGV0IGNsaWVudFxyXG4gICAgICBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG5cclxuICAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5Y+W5b6XXHJcbiAgICAgIGxldCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKVxyXG4gICAgICBsZXQgY29sbGVjdGlvbiA9IGRiLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKVxyXG5cclxuICAgICAgbGV0IGNvbnRleHQgPSB7XHJcbiAgICAgICAgY2xpZW50OiBjbGllbnQsXHJcbiAgICAgICAgY29sbGVjdGlvbjogY29sbGVjdGlvbixcclxuICAgICAgICBkYXRhYmFzZTogZGJcclxuICAgICAgfVxyXG5cclxuICAgICAgbGV0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpXHJcblxyXG4gICAgICAvLyDjgqvjg7zjgr3jg6vjga7jgr/jgqTjg6DjgqLjgqbjg4jjgpLop6PpmaRcclxuICAgICAgY3VyLmFkZEN1cnNvckZsYWcoJ25vQ3Vyc29yVGltZW91dCcsIHRydWUpXHJcblxyXG4gICAgICAvLyDjgZnjgbnjgabjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgpLjg6vjg7zjg5dcclxuICAgICAgdHJ5IHtcclxuICAgICAgICB3aGlsZSAoYXdhaXQgY3VyLmhhc05leHQoKSkge1xyXG4gICAgICAgICAgbGV0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgICAgIGF3YWl0IG9uUmVzdWx0KGRvYywgY29udGV4dClcclxuICAgICAgICB9O1xyXG4gICAgICB9IGZpbmFsbHkge1xyXG4gICAgICAgIC8vIOOCq+ODvOOCveODq+OCkumWi+aUvlxyXG4gICAgICAgIGF3YWl0IGN1ci5jbG9zZSgpXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgfVxyXG59XHJcblxyXG4vLyBpbXBvcnQgbW9uZ29vc2UgZnJvbSAnbW9uZ29vc2UnO1xyXG5cclxuLy8gZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbi8vICAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xyXG4vLyAgICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XHJcblxyXG4vLyAgICAgLy8gbW9uZ28g44G45o6l57aaXHJcbi8vICAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKTtcclxuLy8gICAgIGxldCBjb251cmkgPSBgbW9uZ29kYjovLyR7Y3JlZC5ob3N0fToke2NyZWQucG9ydH0vJHtjcmVkLmRhdGFiYXNlfWA7XHJcbi8vICAgICBhd2FpdCBtb25nb29zZS5jb25uZWN0KGNvbnVyaSk7XHJcblxyXG4vLyAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5L2c44KLXHJcbi8vICAgICBsZXQgY29sbGVjdGlvbiA9IG1vbmdvb3NlLmNvbm5lY3Rpb24uY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pO1xyXG5cclxuLy8gICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4vLyAgICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XHJcblxyXG4vLyAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCBvbkVycm9yKTtcclxuLy8gICAgIH0pO1xyXG4vLyAgIH1cclxuLy8gfVxyXG4iLCJpbXBvcnQge01vbmdvQ29sbGVjdGlvbn0gZnJvbSAnLi4vdXRpbC9tb25nbydcclxuaW1wb3J0IHtVcGxvYWRzfSBmcm9tICcuLi9jb2xsZWN0aW9uL3VwbG9hZHMnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtQ29udHJvbGxlciB7XHJcbiAgYXN5bmMgaW5pdCAocGx1Zykge1xyXG4gICAgdGhpcy5JdGVtcyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ2l0ZW1zJylcclxuICAgIHRoaXMuUHJvZHVjdHMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdwcm9kdWN0cycpXHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTdG9jayAoaXRlbUlkKSB7XHJcbiAgICBsZXQgcHJvamVjdCA9IGF3YWl0IHRoaXMuSXRlbXMuZmluZE9uZSh7X2lkOiBpdGVtSWR9LCB7cHJvamVjdGlvbjogeydwcm9kdWN0JzogMX19KVxyXG4gICAgbGV0IHByb2R1Y3RQYWNrID0gcHJvamVjdC5wcm9kdWN0XHJcblxyXG4gICAgLy8gcHJvZHVjdCAqIDwtPiAqIGl0ZW1cclxuICAgIC8vIHByb2R1Y3RbXTog6KSH5pWw44Gu5ZWG5ZOB44KSMeODkeODg+OCseODvOOCuOOBqOOBl+OBpuiyqeWjslxyXG4gICAgLy8gcHJvZHVjdFtbXV06IOeVsOOBquOCi+a1gemAmue1jOi3r+OAgeeVsOOBquOCi+WOn+S+oeODu+S7leWFpeOCjOWApFxyXG4gICAgLy8gaXRlbTog55Ww44Gq44KL44K744O844Or44CB6LKp5aOy5b2i5oWLXHJcbiAgICAvLyDigLsgcHJvZHVjdCDjgYvjgonjga/jgIHosqnlo7Llj6/og73jgarlnKjluqvjgIHliKnnm4roqIjnrpfjga7jgZ/jgoHjga7mg4XloLHjgpLlvpfjgotcclxuXHJcbiAgICBsZXQgcXVhbnRpdGllcyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgcHJvZHVjdFNrdSBvZiBwcm9kdWN0UGFjaykge1xyXG4gICAgICBsZXQgcXVhbnRpdHlTa3UgPSAwXHJcblxyXG4gICAgICBmb3IgKGxldCBwcm9kdWN0SWQgb2YgcHJvZHVjdFNrdSkge1xyXG4gICAgICAgIGxldCBwcm9qZWN0ID0gYXdhaXQgdGhpcy5Qcm9kdWN0cy5maW5kT25lKHtfaWQ6IHByb2R1Y3RJZH0sIHtwcm9qZWN0aW9uOiB7J3N0b2NrJzogMX19KVxyXG4gICAgICAgIGxldCBzdG9ja0FycmF5ID0gcHJvamVjdC5zdG9ja1xyXG5cclxuICAgICAgICAvLyDljZjntJTjgavjgZnjgbnjgabjga7lnKjluqvllYblk4HjgIHnn63mnJ/plpPlj5bjgorlr4TjgZvlj6/og73llYblk4HjgpLlkIjnrpdcclxuICAgICAgICBmb3IgKGxldCBzdG9jayBvZiBzdG9ja0FycmF5KSB7XHJcbiAgICAgICAgICBxdWFudGl0eVNrdSArPSBzdG9jay5xdWFudGl0eVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgcXVhbnRpdGllcy5wdXNoKHF1YW50aXR5U2t1KVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCu+ODg+ODiOWVhuWTgeOBruWgtOWQiOOAgeS4gOeVquWwkeOBquOBhOWVhuWTgeaVsOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IHF1YW50aXR5ID0gTWF0aC5taW4uYXBwbHkobnVsbCwgcXVhbnRpdGllcylcclxuXHJcbiAgICByZXR1cm4gcXVhbnRpdHlcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgovjgIJcclxuICAgKlxyXG4gICAqIOODoeODvOOCq+ODvOODouODh+ODq+OBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog54m55a6a44Gu5bGe5oCn77yI44Kr44Op44O844Gq44Gp77yJ44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXHJcbiAgICogY2xhc3Mx44Gr5YCk44KS5oyH5a6a44GX44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXHJcbiAgICog44KC44GXY2xhc3My44Gu44G/5oyH5a6a44GX44Gf44GE5aC05ZCI44GvY2xhc3Mx44GrbnVsbOOCkuaMh+WumuOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog5L6L77yaSkstMTAw44GuQkxBQ0vjga7llYblk4HnlLvlg4/jgpJcclxuICAgKiDjgZnjgbnjgabjga7jgrXjgqTjgrrvvIhTLE0sTCxYTCwyWEwsM1hMLDRYTOKApu+8ieOBq+mWoumAo+S7mOOBkeOCi+WgtOWQiFxyXG4gICAqIHNldEltYWdlKCB1cGxvYWRJZCwgJ0pLLTEwMCcsICdCTEFDSycgKTtcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB1cGxvYWRJZCDkuIDlm57jga7jgqLjg4Pjg5fjg63jg7zjg4nnlLvlg4/jgpLmnZ/jga3jgabjgYTjgotJROOAgm1ldGVvcuODh+ODvOOCv+ODmeODvOOCueOAgVVwbG9hZHPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjg4njgq3jg6Xjg6Hjg7Pjg4jjga51cGxvYWRJZOODl+ODreODkeODhuOCo1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgc2V0SW1hZ2UgKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44Gu5oOF5aCx5Y+W5b6XXHJcbiAgICBsZXQgaW1hZ2VzID0gVXBsb2Fkcy5maW5kKHt1cGxvYWRJZDogdXBsb2FkSWR9KS5mZXRjaCgpLm1hcCgodikgPT4gdi51cGxvYWRlZEZpbGVOYW1lKVxyXG5cclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlcixcclxuICAgICAge1xyXG4gICAgICAgICRwdXNoOiB7XHJcbiAgICAgICAgICBpbWFnZXM6IHtcclxuICAgICAgICAgICAgJGVhY2g6IGltYWdlc1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIOeZu+mMsuOBl+OBn+eUu+WDj+ODleOCoeOCpOODq+WQjeS4gOimp1xyXG4gICAgcmV0dXJuIGltYWdlc1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+eZu+mMsuOBleOCjOOBpuOBhOOCi+eUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKi9cclxuICBhc3luYyBjbGVhbkltYWdlIChtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge31cclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsXHJcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxXHJcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLFxyXG4gICAgICB7XHJcbiAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44Gu5ZWG5ZOB44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gu5bGe5oCn5Yil44Gu5ZWG5ZOB5oOF5aCx44KS6L+U44GZ44CCXHJcbiAgICpcclxuICAgKiDlvJXmlbDjgajjgZfjgablj5fjgZHlj5bjgotpdGVt44Gv5Lu75oSP44Gu5ZWG5ZOB5oOF5aCx44CCXHJcbiAgICogaXRlbeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBq+OBpOOBhOOBpuW/heimgeOBquaDheWgseOCkuaVtOeQhuOBl+i/lOOBmeOAglxyXG4gICAqXHJcbiAgICogcHJvamVjdOOBq+WPgueFp+OBl+OBn+OBhOWVhuWTgeaDheWgseODleOCo+ODvOODq+ODieOCkuWumue+qeOBmeOCi+OAglxyXG4gICAqIOODoeOCveODg+ODieOBruWRvOOBs+WHuuOBl+aZguOBq+W/heimgeOBq+W/nOOBmOOBpnByb2plY3TjgpLoqK3lrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS9leOBq+azqOebruOBl+OBpuWVhuWTgeOBrumWoumAo+aAp+OCkuaknOWHuuOBmeOCi+OBi+OBr+OAgeOBk+OBruODoeOCveODg+ODieWGheOBp+Wumue+qeOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGl0ZW1cclxuICAgKiBAcGFyYW0ge09iamVjdH0gcHJvamVjdFxyXG4gICAqL1xyXG4gIGFzeW5jIGdldFZhcmlhdGlvbiAoaXRlbSwgcHJvamVjdCkge1xyXG4gICAgLyoqXHJcbiAgICAgKiBhZ2dyZWdhdGlvbuioreWumlxyXG4gICAgICpcclxuICAgICAqIGxhYmVsOiDlsZ7mgKflkI3vvIjphY3pgIHmlrnms5XjgIHjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganvvIlcclxuICAgICAqIGN1cnJlbnQ6IOaMh+WumuOBleOCjOOBn+OCouOCpOODhuODoO+8iGl0ZW3vvInjgYzoqbLlvZPjgZnjgovpoIXnm65cclxuICAgICAqIHBvcmplY3Q6IOODkOODquOCqOODvOOCt+ODp+ODs+aknOe0ouOBruOCreODvOOBqOOBquOCi2l0ZW3lhoXjga7jg5XjgqPjg7zjg6vjg4nlkI0gJFvjg5XjgqPjg7zjg6vjg4nlkI1d5b2i5byPXHJcbiAgICAgKiBxdWVyeTogYWdncmVnYXRpb27lr77osaHjgajjgZnjgovjg4njgq3jg6Xjg6Hjg7Pjg4jjga7mpJzntKLmnaHku7ZcclxuICAgICAqL1xyXG4gICAgbGV0IHNldCA9IFtcclxuICAgICAge1xyXG4gICAgICAgIGxhYmVsOiAn6YWN6YCB5pa55rOVJyxcclxuICAgICAgICBjdXJyZW50OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICAgIHZhbHVlOiAnJGRlbGl2ZXJ5J1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcXVlcnk6IHtcclxuICAgICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgICAgICBjbGFzczJfdmFsdWU6IGl0ZW0uY2xhc3MyX3ZhbHVlXHJcbiAgICAgICAgfVxyXG4gICAgICB9LFxyXG4gICAgICB7XHJcbiAgICAgICAgbGFiZWw6IGl0ZW0uY2xhc3MxX25hbWUsXHJcbiAgICAgICAgY3VycmVudDogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgICAgdmFsdWU6ICckY2xhc3MxX3ZhbHVlJ1xyXG4gICAgICAgIH0sXHJcbiAgICAgICAgcXVlcnk6IHtcclxuICAgICAgICAgIGRlbGl2ZXJ5OiBpdGVtLmRlbGl2ZXJ5LFxyXG4gICAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAge1xyXG4gICAgICAgIGxhYmVsOiBpdGVtLmNsYXNzMl9uYW1lLFxyXG4gICAgICAgIGN1cnJlbnQ6IGl0ZW0uY2xhc3MyX3ZhbHVlLFxyXG4gICAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICAgIHZhbHVlOiAnJGNsYXNzMl92YWx1ZSdcclxuICAgICAgICB9LFxyXG4gICAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgICBkZWxpdmVyeTogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWVcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgIF1cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBbXVxyXG5cclxuICAgIGZvciAobGV0IHMgb2Ygc2V0KSB7XHJcbiAgICAgIGF0dHJzLnB1c2goe1xyXG4gICAgICAgIHZhcmlhdGlvbnM6XHJcbiAgICAgICAgICBhd2FpdCB0aGlzLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgICAgW1xyXG4gICAgICAgICAgICAgIHskbWF0Y2g6IE9iamVjdC5hc3NpZ24ocy5xdWVyeSwge21vZGVsOiBpdGVtLm1vZGVsfSl9LFxyXG4gICAgICAgICAgICAgIHskcHJvamVjdDogT2JqZWN0LmFzc2lnbihzLnByb2plY3QsIHByb2plY3QpfSxcclxuICAgICAgICAgICAgICB7JHNvcnQ6IHtfaWQ6IDF9fVxyXG4gICAgICAgICAgICBdXHJcbiAgICAgICAgICApLnRvQXJyYXkoKSxcclxuICAgICAgICBwcm9wczogc1xyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBhdHRyc1xyXG4gIH1cclxuXHJcbiAgLy8g44Oi44OH44Or44Kv44Op44K55b2i5byP44KS5L2c44KLXHJcbiAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gIGdldE1vZGVsQ2xhc3MgKGl0ZW0pIHtcclxuICAgIGxldCBtb2RlbENsYXNzID0gW11cclxuICAgIGlmIChpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbClcclxuICAgIGlmIChpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpXHJcbiAgICByZXR1cm4gbW9kZWxDbGFzcy5qb2luKCcvJylcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTMgKGNyZWF0b3JJZCwgaXRlbSkge1xyXG4gICAgLy8g5YCk5aSJ5o+bXHJcbiAgICBsZXQgY29udkRlbGl2ID0gKGRlbGl2ZXJ5KSA9PiBkZWxpdmVyeSA9PT0gJ+OChuOBhuODkeOCseODg+ODiCcgPyAn44Od44K544OI5oqV5Ye9JyA6IGRlbGl2ZXJ5XHJcblxyXG4gICAgLy8gcHJvZHVjdF9pZFxyXG4gICAgbGV0IHByb2R1Y3RJZCA9IG51bGxcclxuICAgIGxldCBtb2RlbENsYXNzID0gW11cclxuXHJcbiAgICAvLyDkuIvoqJjjga7lvaLlvI/jgpLkvZzjgotcclxuICAgIC8vIFvjg6Hjg7zjgqvjg7zjgrPjg7zjg4ldL1vlsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJXS9b5bGe5oCnMu+8iOOCteOCpOOCuuOBquOBqe+8iV1cclxuICAgIGlmIChpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbClcclxuICAgIGlmIChpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpXHJcblxyXG4gICAgLy8g5ZWG5ZOB56iu5Yil44KS5Ymy44KK5b2T44Gm44KLXHJcbiAgICBsZXQgcHJvZHVjdFR5cGVJZFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6IHByb2R1Y3RUeXBlSWQgPSAxOyBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOiBwcm9kdWN0VHlwZUlkID0gMjsgYnJlYWtcclxuICAgICAgZGVmYXVsdDogcHJvZHVjdFR5cGVJZCA9IDE7IGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB44K/44Kw44KS6Kit5a6a44GZ44KLXHJcbiAgICBsZXQgdGFncyA9IFtdXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzogdGFncy5wdXNoKHt0YWc6IDQsIHNldDogJ29uJ30sIHt0YWc6IDUsIHNldDogJ29mZid9KTsgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzogdGFncy5wdXNoKHt0YWc6IDUsIHNldDogJ29uJ30sIHt0YWc6IDQsIHNldDogJ29mZid9KTsgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4HliKXpgIHmlpnjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCBkZWxpdmVyeUZlZSA9IG51bGxcclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOiBkZWxpdmVyeUZlZSA9IG51bGw7IGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6IGRlbGl2ZXJ5RmVlID0gMjQwOyBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vXHJcbiAgICAvLyDpoaflrqLlkJHjgZHjg5Djg6rjgqjjg7zjgrfjg6fjg7PllYblk4Hpgbjmip7mqZ/og73jga7lrp/oo4VcclxuICAgIC8vXHJcblxyXG4gICAgbGV0IGF0dHJzID0gYXdhaXQgdGhpcy5nZXRWYXJpYXRpb24oaXRlbSwge3Byb2R1Y3RfaWQ6ICckbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJ30pXHJcblxyXG4gICAgLy8gSFRNTCDjg5Djg6rjgqjjg7zjgrfjg6fjg7PllYblk4HjgZTjgajjga7jg6rjg7Pjgq/ku5jjgY3jg5zjgr/jg7PjgpLooajnpLrjgZnjgotcclxuXHJcbiAgICAvLyDlgKTjga7lpInmj5tcclxuICAgIGF0dHJzID0gYXR0cnMubWFwKFxyXG4gICAgICAoYXR0cikgPT4ge1xyXG4gICAgICAgIGF0dHIucHJvcHMuY3VycmVudCA9IGNvbnZEZWxpdihhdHRyLnByb3BzLmN1cnJlbnQpXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zID0gYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgdmFyaWF0aW9uLnZhbHVlID0gY29udkRlbGl2KHZhcmlhdGlvbi52YWx1ZSlcclxuICAgICAgICAgICAgcmV0dXJuIHZhcmlhdGlvblxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgICByZXR1cm4gYXR0clxyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gSFRNTOeUn+aIkFxyXG4gICAgbGV0IHZhcmlhdGlvbkh0bWwgPVxyXG4gICAgYXR0cnMubWFwKFxyXG4gICAgICAoYXR0cikgPT5cclxuICAgICAgICAnPGRpdiBjbGFzcz1cImNvbnRhaW5lci1mbHVpZFwiPicgK1xyXG4gICAgICAgICAgYDxkaXYgY2xhc3M9XCJyb3dcIj5gICtcclxuICAgICAgICAgICAgYDxkaXYgc3R5bGU9XCJvcGFjaXR5OjAuM1wiIGNsYXNzPVwiYnRuIGJ0bi1pbmZvIGJ0bi1ibG9jayBidG4teHNcIj5gICtcclxuICAgICAgICAgICAgICBgPHN0cm9uZz4ke2F0dHIucHJvcHMubGFiZWx9PC9zdHJvbmc+YCArXHJcbiAgICAgICAgICAgIGA8L2Rpdj5gICtcclxuICAgICAgICAgICAgYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICAgICAodmFyaWF0aW9uKSA9PiB7XHJcbiAgICAgICAgICAgICAgICBpZiAoYXR0ci5wcm9wcy5jdXJyZW50ID09PSB2YXJpYXRpb24udmFsdWUpIHtcclxuICAgICAgICAgICAgICAgICAgcmV0dXJuIGA8YSBocmVmPVwiL3Byb2R1Y3RzL2RldGFpbC8ke3ZhcmlhdGlvbi5wcm9kdWN0X2lkfVwiPjxidXR0b24gY2xhc3M9XCJidG4gYnRuLXN1Y2Nlc3MgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPjxzdHJvbmc+JHt2YXJpYXRpb24udmFsdWV9PC9zdHJvbmc+PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgICAgIHJldHVybiBgPGEgaHJlZj1cIi9wcm9kdWN0cy9kZXRhaWwvJHt2YXJpYXRpb24ucHJvZHVjdF9pZH1cIj48YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj48L2E+YFxyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgKS5qb2luKCcnKSArXHJcbiAgICAgICAgICAnPC9kaXY+JyArXHJcbiAgICAgICAgJzwvZGl2PidcclxuICAgICkuam9pbignJylcclxuXHJcbiAgICBsZXQgZGVzY3JpcHRpb25EZXRhaWwgPSBgXHJcbiAgICA8c21hbGw+4oC7IOmFjemAgeaWueazleODu+OCq+ODqeODvOODu+OCteOCpOOCuuOBr+S4i+iomOOBi+OCieOBiumBuOOBs+OBj+OBoOOBleOBhOOAgjwvc21hbGw+XHJcbiAgICA8c21hbGwgY2xhc3M9XCJ0ZXh0LWRhbmdlclwiPuKAuyDlnKjluqvjgYzjgarjgYTllYblk4Hjga7loLTlkIjjgIzjg5rjg7zjgrjjgYzopovjgaTjgYvjgorjgb7jgZvjgpPjgI3jgajooajnpLrjgZXjgozjgb7jgZnjgII8L3NtYWxsPlxyXG4gICAgJHt2YXJpYXRpb25IdG1sfVxyXG4gICAgYFxyXG5cclxuICAgIC8vIOWVhuWTgeODh+ODvOOCv+OCkuS9nOOCi1xyXG4gICAgbGV0IGRhdGEgPSB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcclxuICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICBuYW1lOiBgJHttb2RlbENsYXNzLmpvaW4oJy8nKX0gJHtjb252RGVsaXYoaXRlbS5kZWxpdmVyeSl9ICR7aXRlbS5uYW1lfSAke2l0ZW0uamFuX2NvZGV9YCxcclxuICAgICAgZGVzY3JpcHRpb25fZGV0YWlsOiBkZXNjcmlwdGlvbkRldGFpbCxcclxuICAgICAgZnJlZV9hcmVhOiBpdGVtLmRlc2NyaXB0aW9uICsgJyAnLFxyXG4gICAgICBwcm9kdWN0X2NvZGU6IG1vZGVsQ2xhc3Muam9pbignLycpLFxyXG4gICAgICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcclxuICAgICAgcHJpY2UwMjogaXRlbS5zYWxlc19wcmljZSAqIDAuOTUsIC8vIOalveWkqeS+oeagvOOBi+OCiTUl5YCk5byV44GNXHJcbiAgICAgIGltYWdlczogaXRlbS5pbWFnZXMsXHJcbiAgICAgIHByb2R1Y3RfdHlwZV9pZDogcHJvZHVjdFR5cGVJZCxcclxuICAgICAgdGFnczogdGFncyxcclxuICAgICAgZGVsaXZlcnlfZmVlOiBkZWxpdmVyeUZlZVxyXG4gICAgfVxyXG5cclxuICAgIE9iamVjdC5hc3NpZ24oZGF0YSwgaXRlbS5tYWxsLnNoYXJha3VTaG9wKVxyXG5cclxuICAgIHJldHVybiBkYXRhXHJcbiAgfVxyXG5cclxuICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjgbjjga7lpInmj5tcclxuICBhc3luYyBjb252ZXJ0SXRlbVlhdWN0IChkZWYsIGl0ZW0pIHtcclxuICAgIGxldCB5YXVjdCA9IHt9XHJcbiAgICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjga7liJ3mnJ/lgKTvvIjjgobjgYbjg5HjgrHjg4Pjg4jjg7vlroXphY3kvr/jgafnlbDjgarjgovvvIlcclxuICAgIHlhdWN0ID0gZGVmW2l0ZW0uZGVsaXZlcnldXHJcblxyXG4gICAgLy8g55S75YOP44Gu6KiY6L+wXHJcbiAgICBjb25zdCBpbWdQcmVmaXggPSAn55S75YOPJ1xyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBpdGVtLmltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICB5YXVjdFtpbWdQcmVmaXggKyAoaSArIDEpXSA9IGl0ZW0uaW1hZ2VzW2ldXHJcbiAgICB9XHJcblxyXG4gICAgLy8g44K/44Kk44OI44OrXHJcbiAgICB5YXVjdFsn44Kr44OG44K044OqJ10gPSBpdGVtLm1hbGwueWF1Y3QuY2F0ZWdvcnlcclxuICAgIHlhdWN0Wyfjgr/jgqTjg4jjg6snXSA9IGAke3RoaXMuZ2V0TW9kZWxDbGFzcyhpdGVtKX0gJHtpdGVtLmRlbGl2ZXJ5fSAke2l0ZW0ubmFtZX1gXHJcbiAgICB5YXVjdFsn6ZaL5aeL5L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlXHJcbiAgICB5YXVjdFsn5Y2z5rG65L6h5qC8J10gPSBpdGVtLnNhbGVzX3ByaWNlXHJcbiAgICB5YXVjdFsn566h55CG55Wq5Y+3J10gPSB0aGlzLmdldE1vZGVsQ2xhc3MoaXRlbSlcclxuICAgIHlhdWN0WyfoqqzmmI4nXSA9IGl0ZW0uZGVzY3JpcHRpb25cclxuICAgIHlhdWN0WydKQU7jgrPjg7zjg4njg7tJU0JO44Kz44O844OJJ10gPSBpdGVtLmphbl9jb2RlXHJcblxyXG4gICAgcmV0dXJuIHlhdWN0XHJcbiAgfVxyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIHV0aWxFcnJvciB7XHJcbiAgc3RhdGljIHBhcnNlIChlKSB7XHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICAgIHJlcy5tZXNzYWdlID0gZS5tZXNzYWdlXHJcbiAgICAgIHJlcy5uYW1lID0gZS5uYW1lXHJcbiAgICAgIHJlcy5maWxlTmFtZSA9IGUuZmlsZU5hbWVcclxuICAgICAgcmVzLmxpbmVOdW1iZXIgPSBlLmxpbmVOdW1iZXJcclxuICAgICAgcmVzLmNvbHVtbk51bWJlciA9IGUuY29sdW1uTnVtYmVyXHJcbiAgICAgIHJlcy5zdGFjayA9IGUuc3RhY2tcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlcyA9IGVcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvQ2xpZW50IH0gZnJvbSAnbW9uZ29kYidcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0NvbGxlY3Rpb24ge1xyXG4gIHN0YXRpYyBhc3luYyBnZXQgKHBsdWcsIGNvbGxlY3Rpb24pIHtcclxuICAgIGxldCBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG4gICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICByZXR1cm4gZGIuY29sbGVjdGlvbihjb2xsZWN0aW9uKVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnXHJcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlTUUwge1xyXG4gIGNvbnN0cnVjdG9yIChwcm9maWxlKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pjg5fjg7zjg6vliJ3mnJ/ljJZcclxuICAgIHRoaXMucG9vbCA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZSlcclxuXHJcbiAgICAvLyDopIfmlbDooYzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jlr77lv5xcclxuICAgIGxldCBwcm9maWxlTXVsdGkgPSB7bXVsdGlwbGVTdGF0ZW1lbnRzOiB0cnVlfVxyXG4gICAgT2JqZWN0LmFzc2lnbihwcm9maWxlTXVsdGksIHByb2ZpbGUpXHJcbiAgICB0aGlzLnBvb2xNdWx0aSA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZU11bHRpKVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZvcm1hdERhdGUgKGRhdGUpIHtcclxuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsIDE5KS5yZXBsYWNlKCdUJywgJyAnKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsXHJcbiAgICovXHJcbiAgcXVlcnkgKHNxbCkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz56K656uLXHJcbiAgICAvLyBsZXQgY29uID0gYXdhaXQgdGhpcy5nZXRDb24oKTtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwsIChlLCByZXMpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+mWi+aUvlxyXG4gICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxyXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXMpXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnRfIChzcWwpIHtcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O844CBbnVsbOOAgWphdmFzY3JpcHQtPm15c3Fs5pel5LuY5aSJ5o+b44Gr44KC5a++5b+cXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnQgKHRhYmxlLCBkYXRhID0ge30sIGRhdGFTcWwgPSB7fSkge1xyXG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgXHJcblxyXG4gICAgbGV0IG1hcCA9IG5ldyBNYXAoKVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCkge1xyXG4gICAgICAgIG1hcC5zZXQoaywgJ05VTEwnKVxyXG4gICAgICB9IGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG1hcC5zZXQoaywgYCR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgbWFwLnNldChrLCBkYXRhU3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YVNxbFtrXSlcclxuICAgIH1cclxuXHJcbiAgICBzcWwgKz0gYCggJHtbLi4ubWFwLmtleXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBzcWwgKz0gYFZBTFVFUyggJHtbLi4ubWFwLnZhbHVlcygpXS5qb2luKCcsJyl9ICkgYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICBhc3luYyBxdWVyeVVwZGF0ZSAodGFibGUsIGZpbHRlciwgZGF0YSwgZGF0YVNxbCkge1xyXG4gICAgbGV0IHNxbCA9IGBVUERBVEUgJHt0YWJsZX0gU0VUIGBcclxuXHJcbiAgICBsZXQgdXBkYXRlcyA9IFtdXHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgfVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhU3FsW2tdfWApXHJcbiAgICB9XHJcbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJylcclxuXHJcbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIC8vIGVuYWJsZSB0byB1c2UgbXVsdGlwbGUgc3RhdGVtZW50c1xyXG4gIGFzeW5jIHF1ZXJ5TXVsdGkgKHNxbCkge1xyXG4gICAgbGV0IHBvb2xTd2FwID0gdGhpcy5wb29sXHJcbiAgICB0aGlzLnBvb2wgPSB0aGlzLnBvb2xNdWx0aVxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3RhcnRUcmFuc2FjdGlvbiAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBTVEFSVCBUUkFOU0FDVElPTjtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29tbWl0ICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYENPTU1JVDtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcm9sbGJhY2sgKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgUk9MTEJBQ0s7YClcclxuICB9XHJcblxyXG4gIHN0cmVhbWluZ1F1ZXJ5IChzcWwsIG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pIHtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwpXHJcbiAgICAgICAgICAgICAgICAub24oJ3Jlc3VsdCcsXHJcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb24ucGF1c2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0KHJlY29yZClcclxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKClcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGVcclxuICAgICAgfSlcclxuICB9XHJcblxyXG4gIGdldENvbiAoKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAvLyDjg5fjg7zjg6vjgYvjgonjga7jgrPjg43jgq/jgrfjg6fjg7PnjbLlvpdcclxuICAgICAgICB0aGlzLnBvb2wuZ2V0Q29ubmVjdGlvbigoZSwgY29uKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICByZWplY3QoZSlcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUoY29uKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLmNhdGNoKFxyXG4gICAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgfTtcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBQYWNrZXQge1xyXG4gIGNvbnN0cnVjdG9yIChwYWNrZXRTaXplKSB7XHJcbiAgICB0aGlzLnBhY2tldFNpemUgPSBwYWNrZXRTaXplXHJcbiAgICB0aGlzLm9uUGFja2V0U3RhcnQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldEVuZCA9IG51bGxcclxuICAgIHRoaXMuY291bnQgPSAwXHJcbiAgICB0aGlzLnBhY2tldENvdW50ID0gMFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0IChhcmcpIHtcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHliJ3mnJ/ljJbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0U3RhcnQpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLm9uUGFja2V0U3RhcnQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMub25QYWNrZXQpIHtcclxuICAgICAgYXdhaXQgdGhpcy5vblBhY2tldChhcmcpXHJcbiAgICB9XHJcbiAgICB0aGlzLmNvdW50KytcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHntYLkuoblh6bnkIbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0RW5kKSB7XHJcbiAgICAgICAgYXdhaXQgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgICB9XHJcbiAgICAgIHRoaXMucGFja2V0Q291bnQrK1xyXG4gICAgfVxyXG4gIH1cclxuICBjbG9zZSAoKSB7XHJcbiAgICB0aGlzLm9uUGFja2V0RW5kKHRoaXMucGFja2V0Q291bnQpXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB1dGlsRXJyb3IgZnJvbSAnLi9lcnJvcidcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZXBvcnQge1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMucmVjb3JkID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3JzID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3IgPSBudWxsXHJcbiAgfVxyXG5cclxuICBzZXR1cEl0ZXJhdG9yICgpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IoKVxyXG4gICAgdGhpcy5pdGVyYXRvcnMucHVzaCh0aGlzLml0ZXJhdG9yKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGhhc2UgKG5hbWUgPSAnJywgZm4gPSBhc3luYyAoKSA9PiB7fSkge1xyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKClcclxuXHJcbiAgICBsZXQgcmVjID0ge31cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgZm4oKVxyXG5cclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnc3VjY2VzcycsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiByZXNcclxuICAgICAgfSlcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogdXRpbEVycm9yLnBhcnNlKGUpXHJcbiAgICAgIH0pXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci50b3RhbCkge1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgICBpdGVyYXRvcjogdGhpcy5pdGVyYXRvclxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5yZWNvcmQucHVzaChyZWMpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpU3VjY2VzcyAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLnN1Y2Nlc3MobmV3UmVjb3JkKVxyXG4gIH1cclxuXHJcbiAgaUVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IuZXJyb3IodXRpbEVycm9yLnBhcnNlKG5ld1JlY29yZCkpXHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQgKCkge1xyXG4gICAgbGV0IGl0ZUVycm9yID0gdGhpcy5pdGVyYXRvcnMuZmluZChlID0+IGUuZXJyb3JPY3VycmVkKCkpXHJcbiAgICBsZXQgcGhhRXJyb3IgPSBmYWxzZVxyXG4gICAgZm9yIChsZXQgcmVjIG9mIHRoaXMucmVjb3JkKSB7XHJcbiAgICAgIGlmIChyZWMudHlwZSA9PT0gJ2Vycm9yJykge1xyXG4gICAgICAgIHBoYUVycm9yID0gdHJ1ZVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBpdGVFcnJvciB8fCBwaGFFcnJvclxyXG4gIH1cclxuXHJcbiAgcHVibGlzaCAoKSB7XHJcbiAgICBpZiAodGhpcy5lcnJvck9jdXJyZWQoKSkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKHRoaXMucmVjb3JkKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMucmVjb3JkXHJcbiAgfVxyXG59XHJcblxyXG5jbGFzcyBJdGVyYXRvciB7XHJcbiAgY29uc3RydWN0b3IgKCkge1xyXG4gICAgdGhpcy50b3RhbCA9IDBcclxuICAgIHRoaXMudHJhY2UgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IHtcclxuICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICByZWNvcmRzOiBbXVxyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjoge1xyXG4gICAgICAgIHRvdGFsOiAwLFxyXG4gICAgICAgIHJlY29yZHM6IFtdXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLnRyYWNlLnN1Y2Nlc3MucmVjb3Jkcy5wdXNoKG5ld1JlY29yZClcclxuICAgIH1cclxuICAgIHRoaXMudHJhY2Uuc3VjY2Vzcy50b3RhbCsrXHJcbiAgICB0aGlzLnRvdGFsKytcclxuICB9XHJcbiAgZXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgLy8g55u05YmN44Gu44Ko44Op44O844KS5Y+W5b6XXHJcbiAgICBsZXQgbGFzdEVycm9yID0gbnVsbFxyXG4gICAgbGV0IGluZGV4ID0gdGhpcy50cmFjZS5lcnJvci5yZWNvcmRzLmxlbmd0aFxyXG4gICAgaWYgKGluZGV4KSB7XHJcbiAgICAgIGxhc3RFcnJvciA9IHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkc1tpbmRleCAtIDFdXHJcbiAgICB9XHJcblxyXG4gICAgLy8g55u05YmN44Go5ZCM44GY44Ko44Op44O844Gv55yB44GPXHJcbiAgICBpZiAoSlNPTi5zdHJpbmdpZnkobGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkcy5wdXNoKG5ld1JlY29yZClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy50cmFjZS5lcnJvci50b3RhbCsrXHJcbiAgICB0aGlzLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy50cmFjZS5lcnJvci50b3RhbFxyXG4gIH1cclxufVxyXG4iXX0=
