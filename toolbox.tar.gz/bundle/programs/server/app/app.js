var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/route/upload/image.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube/cubemig.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 3);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 4);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 5);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let couponCd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let couponName = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discountPrice = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: couponCd,
                coupon_type: 3,
                // 全商品
                coupon_name: couponName,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discountPrice,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                customer_id: record.customer_id,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
        return res;
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/collection.js                                                                                  //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
      return res;
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug, plug.collection));
      let res = Promise.await(coll.aggregate(query).toArray());
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/jline/items.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let ItemController;
module.watch(require("../../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/cube.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/service/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 5);
let tag = 'cube';
Meteor.methods({
  //
  // 在庫更新
  [`${tag}.updateStock`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB));
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('在庫の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id));
            Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
          })
        }));
        return res;
      })));
      return report.publish();
    });
  },

  //
  // 商品情報登録と更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      let itemController = new ItemController();
      Promise.await(itemController.init(config.itemsDB)); // クライアントが参照するための処理結果作成オブジェクト

      let report = new Report();
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        let res = Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = Promise.await(itemController.convertItemCube3(config.creator_id, item));
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              let quantity = Promise.await(itemController.getStock(item._id));
              Promise.await(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/tooltest.js                                                                                          //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      const newLocal = Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
        throw e;
      })));
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return newLocal;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/yauct.js                                                                                             //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/service/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let ItemController;
module.watch(require("../imports/service/items"), {
  default(v) {
    ItemController = v;
  }

}, 2);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 3);
let Packet;
module.watch(require("../imports/util/packet"), {
  default(v) {
    Packet = v;
  }

}, 4);
let fsExtra;
module.watch(require("fs-extra"), {
  default(v) {
    fsExtra = v;
  }

}, 5);
let iconv;
module.watch(require("iconv-lite"), {
  default(v) {
    iconv = v;
  }

}, 6);
let archiver;
module.watch(require("archiver"), {
  default(v) {
    archiver = v;
  }

}, 7);
let csv;
module.watch(require("csv"), {
  default(v) {
    csv = v;
  }

}, 8);
let PassThrough, Transform;
module.watch(require("stream"), {
  PassThrough(v) {
    PassThrough = v;
  },

  Transform(v) {
    Transform = v;
  }

}, 9);
const prefix = 'packet';
const tag = 'yauct';
Meteor.methods({
  //
  // ヤフオク受注ファイル
  [`${tag}.order`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク受注', () => Promise.asyncApply(() => {
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB));
        const workdir = `${config.workdir}/order`;
        const r = fsExtra.createReadStream(`${workdir}/${config.orderLoadfile}`);
        const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`);
        r.pipe(iconv.decodeStream('SJIS')).pipe(iconv.encodeStream('UTF-8')).pipe(csv.parse({
          columns: true
        })).pipe(csv.transform((record, callback) => Promise.asyncApply(() => {
          let err = null; // 管理番号を置き換える

          try {
            record['管理番号'] = Promise.await(itemController.getModelClass(record['管理番号']));
          } catch (e) {
            err = e;
          }

          callback(err, record);
        }))).pipe(csv.stringify({
          header: true
        })).pipe(iconv.decodeStream('UTF-8')).pipe(iconv.encodeStream('SJIS')).pipe(w);
      })));
    });
  },

  //
  // ヤフオク出品ファイル
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      Promise.await(report.phase('ヤフオク出品', () => Promise.asyncApply(() => {
        // 初期化処理
        //
        const filter = new MongoDBFilter(config.itemsDB, config.profile);
        const itemController = new ItemController();
        Promise.await(itemController.init(config.itemsDB)); // 繰り返し処理を任意の（packetSize）で分割

        const packet = new Packet(config.packetSize); // 作業フォルダを作成する

        try {
          Promise.await(fsExtra.mkdir(config.workdir));
        } catch (e) {} // CSVファイルを作成し画像データを収集する場所


        const workdir = `${config.workdir}/work`;
        Promise.await(fsExtra.remove(workdir));
        Promise.await(fsExtra.mkdir(workdir)); // ZIPファイルを保存する場所

        const uploaddir = `${config.workdir}/upload`;
        Promise.await(fsExtra.remove(uploaddir));
        Promise.await(fsExtra.mkdir(uploaddir));
        let cd = null; // パケットフォルダ

        let filename = null; // csvファイル

        let name = null; // パケット番号
        // CSVフィールドを定義し、順番を確定する

        let fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
        let header = fields.map(v => `"${v}"`).join(',') + '\n'; // パケット化開始時

        packet.onPacketStart = packetCount => Promise.asyncApply(() => {
          name = prefix + ('00000' + packetCount).slice(-5);
          cd = `${workdir}/${name}`;
          filename = `${cd}/${config.csvFileName}`;
          Promise.await(fsExtra.mkdir(cd)); // CSVファイルにフィールドを設定する

          Promise.await(fsExtra.appendFile(filename, iconv.encode(header, 'Shift_JIS')));
        }); // パケット化時


        packet.onPacket = arg => Promise.asyncApply(() => {
          let yauct = arg.yauct;
          let item = arg.item; // csvファイルにレコード（商品テンプレート）を追加する

          let record = fields.map(v => {
            return yauct[v] ? `"${yauct[v]}"` : '""';
          }).join(',') + '\n';
          Promise.await(fsExtra.appendFile(filename, iconv.encode(record, 'Shift_JIS'))); // 画像ファイルをコピー

          for (let img of item.images) {
            let imgSrc = `${config.imagedir}/${img}`;
            let imgTgt = `${cd}/${img}`;

            try {
              // 同じファイルがある場合はコピーしない
              Promise.await(fsExtra.access(imgTgt));
            } catch (e) {
              Promise.await(fsExtra.copyFile(imgSrc, imgTgt));
            }
          }
        }); // パケット終了時


        packet.onPacketEnd = packetCount => Promise.asyncApply(() => {
          const zip = archiver('zip');
          const zipname = `${uploaddir}/${name}.zip`;
          const output = fsExtra.createWriteStream(zipname);
          zip.pipe(output);
          zip.directory(cd, false);
          zip.finalize();
        }); // メインループ
        //


        let res = Promise.await(filter.foreach({
          'TARGET': (item, context) => Promise.asyncApply(() => {
            let quantity = Promise.await(itemController.getStock(item._id)); // itemに定義されている最低必要在庫より多い商品を出品する

            if (quantity >= item.mall.yauct.minQuantity) {
              let yauct = Promise.await(itemController.convertItemYauct(config.default, item));
              Promise.await(packet.submit({
                yauct: yauct,
                item: item
              }));
            }
          })
        }));
        packet.close();
        return res;
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// server/main.js                                                                                              //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/configs.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/filters.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/groups.js                                                                                //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/collection/uploads.js                                                                               //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/cube3api.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  updateStock(productClassId, quantity = 0) {
    return Promise.asyncApply(() => {
      Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        stock_unlimited: 0,
        update_date: 'NOW()'
      }));
      Promise.await(this.mysql_.queryUpdate('dtb_product_stock', `product_class_id = ${productClassId}`, {}, {
        stock: quantity,
        update_date: 'NOW()'
      }));
    });
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = []; // 削除するタグ

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      }); // 表示するタグ


      let tagon = tag => Promise.asyncApply(() => {
        // すでに表示されているタグがあれば何もしない
        let sql = `
      SELECT COUNT(*) FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        let countRes = Promise.await(this.mysql_.query(sql));
        if (countRes[0]['COUNT(*)']) return;
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creatorId,
          create_date: 'NOW()'
        })));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let productId = data.product_id;
      let images = data.images;
      let creatorId = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${productId}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        Promise.await(this.mysql_.queryInsert('dtb_product_image', {
          product_id: productId,
          creator_id: creatorId,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        }));
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let updateData = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      Promise.await(this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      })); // dtb_product_class

      updateData = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      let res = Promise.await(this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, updateData, {
        update_date: 'NOW()'
      }));
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creatorId = data.creator_id;
      let res = {};
      let updateData = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', updateData, {
        creator_id: creatorId,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      updateData = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', updateData, {
        creator_id: creatorId,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) updateData[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creatorId,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/dbfilter.js                                                                                 //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 3);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 4);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case 'mysql':
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    switch (plug.type) {
      case 'mysql':
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error('invalid plug type');
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   *
   *
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== 'undefined') {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      let res = Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
      return res;
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find(); // カーソルのタイムアウトを解除

      cur.addCursorFlag('noCursorTimeout', true); // すべてのドキュメントをループ

      try {
        while (Promise.await(cur.hasNext())) {
          let doc = Promise.await(cur.next());
          Promise.await(onResult(doc, context));
        }

        ;
      } finally {
        // カーソルを開放
        Promise.await(cur.close());
      }
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/service/items.js                                                                                    //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);
let ObjectID;
module.watch(require("bson"), {
  ObjectID(v) {
    ObjectID = v;
  }

}, 2);
let TextUtil;
module.watch(require("../util/text"), {
  default(v) {
    TextUtil = v;
  }

}, 3);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      this.Items = Promise.await(MongoCollection.get(plug, 'items'));
      this.Products = Promise.await(MongoCollection.get(plug, 'products'));
    });
  }

  getStock(itemId) {
    return Promise.asyncApply(() => {
      let project = Promise.await(this.Items.findOne({
        _id: itemId
      }, {
        projection: {
          'product': 1
        }
      }));
      let productPack = project.product; // product * <-> * item
      // product[]: 複数の商品を1パッケージとして販売
      // product[[]]: 異なる流通経路、異なる原価・仕入れ値
      // item: 異なるセール、販売形態
      // ※ product からは、販売可能な在庫、利益計算のための情報を得る

      let quantities = [];

      for (let productSku of productPack) {
        let quantitySku = 0;

        for (let productId of productSku) {
          let project = Promise.await(this.Products.findOne({
            _id: productId
          }, {
            projection: {
              'stock': 1
            }
          }));
          let stockArray = project.stock; // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算

          for (let stock of stockArray) {
            quantitySku += stock.quantity;
          }
        }

        quantities.push(quantitySku);
      } // セット商品の場合、一番少ない商品数に合わせる


      let quantity = Math.min.apply(null, quantities);
      return quantity;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   *
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   *
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   *
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   *
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   *
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   *
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }
  /**
   * 指定の商品に関連する商品群の属性別の商品情報を返す。
   *
   * 引数として受け取るitemは任意の商品情報。
   * itemに関連する商品群について必要な情報を整理し返す。
   *
   * projectに参照したい商品情報フィールドを定義する。
   * メソッドの呼び出し時に必要に応じてprojectを設定する。
   *
   * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
   *
   * @param {Object} item
   * @param {Object} project
   */


  getVariation(item, project) {
    return Promise.asyncApply(() => {
      /**
       * aggregation設定
       *
       * label: 属性名（配送方法、カラー、サイズなど）
       * current: 指定されたアイテム（item）が該当する項目
       * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
       * query: aggregation対象とするドキュメントの検索条件
       */
      let set = [{
        label: '配送方法',
        current: item.delivery,
        project: {
          value: '$delivery'
        },
        query: {
          class1_value: item.class1_value,
          class2_value: item.class2_value
        }
      }, {
        label: item.class1_name,
        current: item.class1_value,
        project: {
          value: '$class1_value'
        },
        query: {
          delivery: item.delivery,
          class2_value: item.class2_value
        }
      }, {
        label: item.class2_name,
        current: item.class2_value,
        project: {
          value: '$class2_value'
        },
        query: {
          delivery: item.delivery,
          class1_value: item.class1_value
        }
      }];
      let attrs = [];

      for (let s of set) {
        attrs.push({
          variations: Promise.await(this.Items.aggregate([{
            $match: Object.assign(s.query, {
              model: item.model
            })
          }, {
            $project: Object.assign(s.project, project)
          }, {
            $sort: {
              _id: 1
            }
          }]).toArray()),
          props: s
        });
      }

      return attrs;
    });
  } // モデルクラス形式を作る
  // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]


  getModelClass(arg) {
    return Promise.asyncApply(() => {
      let item; // item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

      if (typeof arg === 'string') {
        let exp = new RegExp(`${arg}$`);
        let cur = this.Items.find({}, {
          projection: {
            model: 1,
            class1_value: 1,
            class2_value: 1
          }
        });

        while (1) {
          try {
            item = Promise.await(cur.next());
            let match = Promise.await(item._id.toHexString().match(exp));

            if (match) {
              break;
            }
          } catch (e) {
            // 該当するitemデータがない
            cur.close();
            return arg;
          }
        }

        cur.close();
      } else {
        item = arg;
      }

      let modelClass = [];
      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value);
      return modelClass.join('/');
    });
  }

  convertItemCube3(creatorId, item) {
    return Promise.asyncApply(() => {
      // 値変換
      let convDeliv = delivery => delivery === 'ゆうパケット' ? 'ポスト投函' : delivery; // product_id


      let productId = null;
      let modelClass = []; // 下記の形式を作る
      // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]

      if (item.model) modelClass.push(item.model);
      if (item.class1_value) modelClass.push(item.class1_value);
      if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

      let productTypeId;

      switch (item.delivery) {
        case '宅配便':
          productTypeId = 1;
          break;

        case 'ゆうパケット':
          productTypeId = 2;
          break;

        default:
          productTypeId = 1;
          break;
      } // 商品タグを設定する


      let tags = [];

      switch (item.delivery) {
        case '宅配便':
          tags.push({
            tag: 4,
            set: 'on'
          }, {
            tag: 5,
            set: 'off'
          });
          break;

        case 'ゆうパケット':
          tags.push({
            tag: 5,
            set: 'on'
          }, {
            tag: 4,
            set: 'off'
          });
          break;
      } // 商品別送料を設定する


      let deliveryFee = null;

      switch (item.delivery) {
        case '宅配便':
          deliveryFee = null;
          break;

        case 'ゆうパケット':
          deliveryFee = 240;
          break;
      } //
      // 顧客向けバリエーション商品選択機能の実装
      //


      let attrs = Promise.await(this.getVariation(item, {
        product_id: '$mall.sharakuShop.product_id'
      })); // HTML バリエーション商品ごとのリンク付きボタンを表示する
      // 値の変換

      attrs = attrs.map(attr => {
        attr.props.current = convDeliv(attr.props.current);
        attr.variations = attr.variations.map(variation => {
          variation.value = convDeliv(variation.value);
          return variation;
        });
        return attr;
      }); // HTML生成

      let variationHtml = attrs.map(attr => '<div class="container-fluid">' + `<div class="row">` + `<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">` + `<strong>${attr.props.label}</strong>` + `</div>` + attr.variations.map(variation => {
        if (attr.props.current === variation.value) {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-success btn-sm btn-item-class-select"><strong>${variation.value}</strong></button></a>`;
        } else {
          return `<a href="/products/detail/${variation.product_id}"><button class="btn btn-default btn-sm btn-item-class-select">${variation.value}</button></a>`;
        }
      }).join('') + '</div>' + '</div>').join('');
      let descriptionDetail = `
    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>
    <small class="text-danger">※ 在庫がない商品の場合「ページが見つかりません」と表示されます。</small>
    ${variationHtml}
    `; // 商品データを作る

      let data = {
        product_id: productId,
        creator_id: creatorId,
        name: `${modelClass.join('/')} ${convDeliv(item.delivery)} ${item.name} ${item.jan_code}`,
        description_detail: descriptionDetail,
        free_area: item.description + ' ',
        product_code: modelClass.join('/'),
        price01: item.retail_price,
        price02: item.sales_price * 0.95,
        // 楽天価格から5%値引き
        images: item.images,
        product_type_id: productTypeId,
        tags: tags,
        delivery_fee: deliveryFee
      };
      Object.assign(data, item.mall.sharakuShop);
      return data;
    });
  } // ヤフオクテンプレートへの変換


  convertItemYauct(def, item) {
    return Promise.asyncApply(() => {
      const idLength = 20;
      const titleLength = 130;
      let yauct = {}; // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）

      yauct = JSON.parse(JSON.stringify(def[item.delivery])); // 画像の記述

      const imgPrefix = '画像';

      for (let i = 0; i < item.images.length; i++) {
        yauct[imgPrefix + (i + 1)] = item.images[i];
      } // タイトル


      yauct['カテゴリ'] = item.mall.yauct.category;
      yauct['タイトル'] = TextUtil.substr8(`${Promise.await(this.getModelClass(item))} ${item.delivery} ${item.name}`, titleLength);
      yauct['開始価格'] = item.sales_price;
      yauct['即決価格'] = item.sales_price;
      yauct['管理番号'] = item._id.toHexString().slice(-idLength);
      yauct['説明'] = item.description;
      yauct['JANコード・ISBNコード'] = item.jan_code;
      return yauct;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/error.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => utilError
});

class utilError {
  static parse(e) {
    let res = {};

    if (e instanceof Error) {
      res.message = e.message;
      res.name = e.name;
      res.fileName = e.fileName;
      res.lineNumber = e.lineNumber;
      res.columnNumber = e.columnNumber;
      res.stack = e.stack;
    } else {
      res = e;
    }

    return res;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mongo.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug, collection) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/mysql.js                                                                                       //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   *
   * @param {String} sql
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      });
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, dataSql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `${mysql.escape(data[k])}`);
        }
      }

      for (let k of Object.keys(dataSql)) {
        map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   *
   * @param {String} table
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, dataSql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}=${mysql.escape(data[k])}`);
      }

      for (let k of Object.keys(dataSql)) {
        updates.push(`${k}=${dataSql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/packet.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Packet
});

class Packet {
  constructor(packetSize) {
    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  submit(arg) {
    return Promise.asyncApply(() => {
      // packetSizeの回数ごとに、初期化を呼び出す
      if (this.count % this.packetSize === 0) {
        if (this.onPacketStart) {
          Promise.await(this.onPacketStart(this.packetCount));
        }
      }

      if (this.onPacket) {
        Promise.await(this.onPacket(arg));
      }

      this.count++; // packetSizeの回数ごとに、終了処理を呼び出す

      if (this.count % this.packetSize === 0) {
        this.close();
        this.packetCount++;
      }
    });
  }

  close() {
    if (this.onPacketEnd) {
      this.onPacketEnd(this.packetCount);
    }
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/report.js                                                                                      //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => Report
});
let utilError;
module.watch(require("./error"), {
  default(v) {
    utilError = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);

class Report {
  constructor() {
    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  setupIterator() {
    this.iterator = new Iterator();
    this.iterators.push(this.iterator);
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.setupIterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: utilError.parse(e)
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(utilError.parse(newRecord));
  }

  errorOcurred() {
    let iteError = this.iterators.find(e => e.errorOcurred());
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    // 直前のエラーを取得
    let lastError = null;
    let index = this.trace.error.records.length;

    if (index) {
      lastError = this.trace.error.records[index - 1];
    } // 直前と同じエラーは省く


    if (JSON.stringify(lastError) !== JSON.stringify(newRecord)) {
      if (newRecord && newRecord !== {} && newRecord !== '') {
        this.trace.error.records.push(newRecord);
      }
    }

    this.trace.error.total++;
    this.total++;
  }

  errorOcurred() {
    return this.trace.error.total;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                             //
// imports/util/text.js                                                                                        //
//                                                                                                             //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                               //
module.export({
  default: () => TextUtil
});

class TextUtil {
  static substr8(text, len, truncation) {
    if (truncation === undefined) {
      truncation = '';
    }

    var textArray = text.split('');
    var count = 0;
    var str = '';

    for (let i = 0; i < textArray.length; i++) {
      var n = escape(textArray[i]);
      if (n.length < 4) count++;else count += 2;

      if (count > len) {
        return str + truncation;
      }

      str += text.charAt(i);
    }

    return text;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci90b29sdGVzdC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3lhdWN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL2Vycm9yLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbW9uZ28uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9teXNxbC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3BhY2tldC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3JlcG9ydC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL3RleHQuanMiXSwibmFtZXMiOlsiZnMiLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJkZWZhdWx0IiwidiIsInVuaXFpZCIsIm11bHRpcGFydHkiLCJVcGxvYWRzIiwibXVsdGlwYXJ0eU1pZGRsZXdhcmUiLCJyb3V0ZSIsIldlYkFwcCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsInJlcSIsInJlc3AiLCJyZWFkZXIiLCJNZXRlb3IiLCJ3cmFwQXN5bmMiLCJyZWFkRmlsZSIsIndyaXRlciIsIndyaXRlRmlsZSIsInVwbG9hZElkIiwiZmlsZSIsImZpbGVzIiwiZGF0YSIsInBhdGgiLCJmaWxlbmFtZSIsInNhdmVQYXRoIiwiYm9keSIsImltYWdlZGlyIiwiZG9jIiwiY2xpZW50RmlsZU5hbWUiLCJuYW1lIiwidXBsb2FkZWRGaWxlTmFtZSIsImVyciIsImVycm9yIiwiaW5zZXJ0Iiwid3JpdGVIZWFkIiwiZW5kIiwiSlNPTiIsInN0cmluZ2lmeSIsInNhdmVEaXIiLCJjcnlwdG8iLCJNeVNRTCIsIlJlcG9ydCIsIkdyb3VwIiwiR3JvdXBGYWN0b3J5IiwiRmlsdGVyIiwidGFnIiwibWV0aG9kcyIsImNvbmZpZyIsInJlcG9ydCIsImZpbHRlciIsInNyY0ZpbHRlcklkIiwidGVzdFF1ZXJ5IiwiZHN0RGIiLCJkc3QiLCJjcmVkIiwicGhhc2UiLCJxdWVyeSIsInJlcyIsImZvcmVhY2giLCJtb2JpbGVOdWxsIiwicmVjb3JkIiwic3FsIiwiY3VzdG9tZXJfaWQiLCJzdGF0dXMiLCJzZXgiLCJqb2IiLCJjb3VudHJ5X2lkIiwicHJlZiIsIm5hbWUwMSIsIm5hbWUwMiIsImthbmEwMSIsImthbmEwMiIsImNvbXBhbnlfbmFtZSIsInppcDAxIiwiemlwMDIiLCJ6aXBjb2RlIiwiYWRkcjAxIiwiYWRkcjAyIiwiZW1haWwiLCJ0ZWwwMSIsInRlbDAyIiwidGVsMDMiLCJmYXgwMSIsImZheDAyIiwiZmF4MDMiLCJiaXJ0aCIsInBhc3N3b3JkIiwic2FsdCIsInNlY3JldF9rZXkiLCJmaXJzdF9idXlfZGF0ZSIsImxhc3RfYnV5X2RhdGUiLCJidXlfdGltZXMiLCJidXlfdG90YWwiLCJub3RlIiwiY3JlYXRlX2RhdGUiLCJ1cGRhdGVfZGF0ZSIsImRlbF9mbGciLCJxdWVyeUluc2VydCIsImUiLCJpRXJyb3IiLCJjdXN0b21lcl9hZGRyZXNzX2lkIiwiaWQiLCJtYWlsbWFnYV9mbGciLCJjb3Vwb25DZCIsInJhbmRvbUJ5dGVzIiwidG9TdHJpbmciLCJzdWJzdHJpbmciLCJjb3Vwb25OYW1lIiwiZGlzY291bnRQcmljZSIsInBvaW50IiwiY291cG9uX2lkIiwiY291cG9uX2NkIiwiY291cG9uX3R5cGUiLCJjb3Vwb25fbmFtZSIsImRpc2NvdW50X3R5cGUiLCJjb3Vwb25fdXNlX3RpbWUiLCJjb3Vwb25fcmVsZWFzZSIsImRpc2NvdW50X3ByaWNlIiwiZGlzY291bnRfcmF0ZSIsImVuYWJsZV9mbGFnIiwiY291cG9uX21lbWJlciIsImNvdXBvbl9sb3dlcl9saW1pdCIsImF2YWlsYWJsZV9mcm9tX2RhdGUiLCJhdmFpbGFibGVfdG9fZGF0ZSIsInB1Ymxpc2giLCJwcm9maWxlIiwiZGIiLCJNb25nb0NvbGxlY3Rpb24iLCJwbHVnIiwicHJvamVjdGlvbiIsImNvbGwiLCJnZXQiLCJjb2xsZWN0aW9uIiwiZmluZCIsInRvQXJyYXkiLCJhZ2dyZWdhdGUiLCJJdGVtQ29udHJvbGxlciIsIm1vZGVsIiwiY2xhc3MxIiwiY2xhc3MyIiwiaXRlbWNvbiIsImluaXQiLCJ1cGxvYWRlZCIsInNldEltYWdlIiwiY2xlYW5JbWFnZSIsIk1vbmdvREJGaWx0ZXIiLCJDdWJlM0FwaSIsIml0ZW1zREIiLCJpdGVtQ29udHJvbGxlciIsInRhcmdldERCIiwiY3ViZTNEQiIsImFwaSIsIml0ZW0iLCJjb250ZXh0IiwicXVhbnRpdHkiLCJnZXRTdG9jayIsIl9pZCIsInVwZGF0ZVN0b2NrIiwibWFsbCIsInNoYXJha3VTaG9wIiwicHJvZHVjdF9jbGFzc19pZCIsImNvbCIsImN1YmVJdGVtIiwiY29udmVydEl0ZW1DdWJlMyIsImNyZWF0b3JfaWQiLCJpbnNlcnRSZXMiLCJwcm9kdWN0Q3JlYXRlIiwidXBkYXRlIiwiJHNldCIsImlTdWNjZXNzIiwicHJvZHVjdEltYWdlVXBkYXRlIiwicHJvZHVjdFVwZGF0ZSIsInByb2R1Y3RUYWdVcGRhdGUiLCJuZXdMb2NhbCIsIlBhY2tldCIsImZzRXh0cmEiLCJpY29udiIsImFyY2hpdmVyIiwiY3N2IiwiUGFzc1Rocm91Z2giLCJUcmFuc2Zvcm0iLCJwcmVmaXgiLCJ3b3JrZGlyIiwiciIsImNyZWF0ZVJlYWRTdHJlYW0iLCJvcmRlckxvYWRmaWxlIiwidyIsImNyZWF0ZVdyaXRlU3RyZWFtIiwib3JkZXJTYXZlZmlsZSIsInBpcGUiLCJkZWNvZGVTdHJlYW0iLCJlbmNvZGVTdHJlYW0iLCJwYXJzZSIsImNvbHVtbnMiLCJ0cmFuc2Zvcm0iLCJjYWxsYmFjayIsImdldE1vZGVsQ2xhc3MiLCJoZWFkZXIiLCJwYWNrZXQiLCJwYWNrZXRTaXplIiwibWtkaXIiLCJyZW1vdmUiLCJ1cGxvYWRkaXIiLCJjZCIsImZpZWxkcyIsIm1hcCIsImpvaW4iLCJvblBhY2tldFN0YXJ0IiwicGFja2V0Q291bnQiLCJzbGljZSIsImNzdkZpbGVOYW1lIiwiYXBwZW5kRmlsZSIsImVuY29kZSIsIm9uUGFja2V0IiwiYXJnIiwieWF1Y3QiLCJpbWciLCJpbWFnZXMiLCJpbWdTcmMiLCJpbWdUZ3QiLCJhY2Nlc3MiLCJjb3B5RmlsZSIsIm9uUGFja2V0RW5kIiwiemlwIiwiemlwbmFtZSIsIm91dHB1dCIsImRpcmVjdG9yeSIsImZpbmFsaXplIiwibWluUXVhbnRpdHkiLCJjb252ZXJ0SXRlbVlhdWN0Iiwic3VibWl0IiwiY2xvc2UiLCJleHBvcnQiLCJDb25maWdzIiwiTW9uZ28iLCJDb2xsZWN0aW9uIiwiaWRHZW5lcmF0aW9uIiwic2lmdCIsIm1vYmplY3QiLCJHcm91cEJhc2UiLCJGaWx0ZXJzIiwiY29uc3RydWN0b3IiLCJmaWx0ZXJJZCIsImZpbmRPbmUiLCJnZXRQbHVnIiwidHlwZSIsIm15c3FsIiwiaW1wb3J0Iiwib25SZXN1bHQiLCJvbkVycm9yIiwidGFibGUiLCJzdHJlYW1pbmdRdWVyeSIsIkVycm9yIiwiY2FsbGJhY2tzIiwiZ2V0UHJvZmlsZSIsImZpbHRlcnMiLCJwdXNoIiwiY291bnQiLCJ1bmVzY2FwZSIsImV4YW0iLCJHcm91cHMiLCJwbGF0Zm9ybVBsdWciLCJncm91cElkIiwia2V5IiwiY3VyIiwiUHJvbWlzZSIsInJlc29sdmUiLCJyZWplY3QiLCJmb3JFYWNoIiwiaW5kZXgiLCJjYXRjaCIsIm15c3FsXyIsInByb2R1Y3RDbGFzc0lkIiwicXVlcnlVcGRhdGUiLCJzdG9jayIsInN0b2NrX3VubGltaXRlZCIsImNyZWF0b3JJZCIsInRhZ29mZiIsInByb2R1Y3RfaWQiLCJ0YWdvbiIsImNvdW50UmVzIiwidGFnU2V0IiwidGFncyIsInNldCIsInByb2R1Y3RJZCIsImkiLCJsZW5ndGgiLCJmaWxlX25hbWUiLCJyYW5rIiwidXBkYXRlRGF0YSIsImtleXMiLCJrIiwiZGVzY3JpcHRpb25fbGlzdCIsInNlYXJjaF93b3JkIiwiZnJlZV9hcmVhIiwiY2xhc3NfY2F0ZWdvcnlfaWQxIiwiY2xhc3NfY2F0ZWdvcnlfaWQyIiwiZGVsaXZlcnlfZGF0ZV9pZCIsInNhbGVfbGltaXQiLCJwcm9kdWN0X3N0b2NrX2lkIiwiREJGaWx0ZXJGYWN0b3J5IiwiREJGaWx0ZXIiLCJNeXNxbERCRmlsdGVyIiwiTW9uZ29DbGllbnQiLCJpbnN0YW5jZSIsImZhY3RvcnkiLCJnZXRQbHVnXyIsImdldENyZWRfIiwiZ2V0UHJvZmlsZV8iLCJzZXRJbXBvcnRGdW5jdGlvbl8iLCJmbiIsIml0ZXJhdG9ycyIsImNvdW50ZXIiLCJmIiwibGltaXQiLCJjIiwiY2xpZW50IiwiY29ubmVjdCIsInVyaSIsImRhdGFiYXNlIiwiYWRkQ3Vyc29yRmxhZyIsImhhc05leHQiLCJuZXh0IiwiT2JqZWN0SUQiLCJUZXh0VXRpbCIsIkl0ZW1zIiwiUHJvZHVjdHMiLCJpdGVtSWQiLCJwcm9qZWN0IiwicHJvZHVjdFBhY2siLCJwcm9kdWN0IiwicXVhbnRpdGllcyIsInByb2R1Y3RTa3UiLCJxdWFudGl0eVNrdSIsInN0b2NrQXJyYXkiLCJNYXRoIiwibWluIiwiYXBwbHkiLCJmZXRjaCIsImNsYXNzMV92YWx1ZSIsImNsYXNzMl92YWx1ZSIsInVwZGF0ZU1hbnkiLCIkcHVzaCIsIiRlYWNoIiwiZ2V0VmFyaWF0aW9uIiwibGFiZWwiLCJjdXJyZW50IiwiZGVsaXZlcnkiLCJ2YWx1ZSIsImNsYXNzMV9uYW1lIiwiY2xhc3MyX25hbWUiLCJhdHRycyIsInMiLCJ2YXJpYXRpb25zIiwiJG1hdGNoIiwiT2JqZWN0IiwiYXNzaWduIiwiJHByb2plY3QiLCIkc29ydCIsInByb3BzIiwiZXhwIiwiUmVnRXhwIiwibWF0Y2giLCJ0b0hleFN0cmluZyIsIm1vZGVsQ2xhc3MiLCJjb252RGVsaXYiLCJwcm9kdWN0VHlwZUlkIiwiZGVsaXZlcnlGZWUiLCJhdHRyIiwidmFyaWF0aW9uIiwidmFyaWF0aW9uSHRtbCIsImRlc2NyaXB0aW9uRGV0YWlsIiwiamFuX2NvZGUiLCJkZXNjcmlwdGlvbl9kZXRhaWwiLCJkZXNjcmlwdGlvbiIsInByb2R1Y3RfY29kZSIsInByaWNlMDEiLCJyZXRhaWxfcHJpY2UiLCJwcmljZTAyIiwic2FsZXNfcHJpY2UiLCJwcm9kdWN0X3R5cGVfaWQiLCJkZWxpdmVyeV9mZWUiLCJkZWYiLCJpZExlbmd0aCIsInRpdGxlTGVuZ3RoIiwiaW1nUHJlZml4IiwiY2F0ZWdvcnkiLCJzdWJzdHI4IiwidXRpbEVycm9yIiwibWVzc2FnZSIsImZpbGVOYW1lIiwibGluZU51bWJlciIsImNvbHVtbk51bWJlciIsInN0YWNrIiwibW9tZW50IiwicG9vbCIsImNyZWF0ZVBvb2wiLCJwcm9maWxlTXVsdGkiLCJtdWx0aXBsZVN0YXRlbWVudHMiLCJwb29sTXVsdGkiLCJmb3JtYXREYXRlIiwiZGF0ZSIsImZvcm1hdCIsInJlcGxhY2UiLCJnZXRDb24iLCJ0aGVuIiwiY29uIiwicmVsZWFzZSIsInF1ZXJ5SW5zZXJ0XyIsImluc2VydElkIiwiZGF0YVNxbCIsIk1hcCIsImVzY2FwZSIsInZhbHVlcyIsInVwZGF0ZXMiLCJxdWVyeU11bHRpIiwicG9vbFN3YXAiLCJzdGFydFRyYW5zYWN0aW9uIiwiY29tbWl0Iiwicm9sbGJhY2siLCJvbiIsInBhdXNlIiwicmVzdW1lIiwiZ2V0Q29ubmVjdGlvbiIsIml0ZXJhdG9yIiwic2V0dXBJdGVyYXRvciIsIkl0ZXJhdG9yIiwicmVjIiwicmVzdWx0IiwidG90YWwiLCJuZXdSZWNvcmQiLCJzdWNjZXNzIiwiZXJyb3JPY3VycmVkIiwiaXRlRXJyb3IiLCJwaGFFcnJvciIsInRyYWNlIiwicmVjb3JkcyIsImxhc3RFcnJvciIsInRleHQiLCJsZW4iLCJ0cnVuY2F0aW9uIiwidW5kZWZpbmVkIiwidGV4dEFycmF5Iiwic3BsaXQiLCJzdHIiLCJuIiwiY2hhckF0Il0sIm1hcHBpbmdzIjoiOzs7Ozs7OztBQUFBLElBQUlBLEVBQUo7QUFBT0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLElBQVIsQ0FBYixFQUEyQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0wsU0FBR0ssQ0FBSDtBQUFLOztBQUFqQixDQUEzQixFQUE4QyxDQUE5QztBQUFpRCxJQUFJQyxNQUFKO0FBQVdMLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNDLGFBQU9ELENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7QUFBeUQsSUFBSUUsVUFBSjtBQUFlTixPQUFPQyxLQUFQLENBQWFDLFFBQVEsb0JBQVIsQ0FBYixFQUEyQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0UsaUJBQVdGLENBQVg7QUFBYTs7QUFBekIsQ0FBM0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSUcsT0FBSjtBQUFZUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEscUNBQVIsQ0FBYixFQUE0RDtBQUFDSyxVQUFRSCxDQUFSLEVBQVU7QUFBQ0csY0FBUUgsQ0FBUjtBQUFVOztBQUF0QixDQUE1RCxFQUFvRixDQUFwRjtBQWFoTyxJQUFJSSx1QkFBdUJGLFlBQTNCO0FBRUEsTUFBTUcsUUFBUSxlQUFkLEMsQ0FFQTs7QUFDQUMsT0FBT0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJILEtBQTNCLEVBQWtDRCxvQkFBbEM7QUFDQUUsT0FBT0MsZUFBUCxDQUF1QkMsR0FBdkIsQ0FBMkJILEtBQTNCLEVBQWtDLENBQUNJLEdBQUQsRUFBTUMsSUFBTixLQUFlO0FBQy9DO0FBRUEsUUFBTUMsU0FBU0MsT0FBT0MsU0FBUCxDQUFpQmxCLEdBQUdtQixRQUFwQixDQUFmO0FBQ0EsUUFBTUMsU0FBU0gsT0FBT0MsU0FBUCxDQUFpQmxCLEdBQUdxQixTQUFwQixDQUFmO0FBQ0EsUUFBTUMsV0FBV2hCLFFBQWpCOztBQUVBLE9BQUssSUFBSWlCLElBQVQsSUFBaUJULElBQUlVLEtBQUosQ0FBVUQsSUFBM0IsRUFBaUM7QUFDL0IsVUFBTUUsT0FBT1QsT0FBT08sS0FBS0csSUFBWixDQUFiLENBRCtCLENBRS9CO0FBQ0E7O0FBQ0EsUUFBSUMsV0FBWSxHQUFFckIsUUFBUyxNQUEzQixDQUorQixDQU0vQjs7QUFDQSxRQUFJc0IsV0FBV2QsSUFBSWUsSUFBSixDQUFTQyxRQUFULEdBQW9CLEdBQXBCLEdBQTBCSCxRQUF6QyxDQVArQixDQVMvQjtBQUVBOztBQUNBLFFBQUlJLE1BQU07QUFDUlQsZ0JBQVVBLFFBREY7QUFFUlUsc0JBQWdCVCxLQUFLVSxJQUZiO0FBR1JDLHdCQUFrQlA7QUFIVixLQUFWOztBQU1BLFFBQUc7QUFDRFAsYUFBT1EsUUFBUCxFQUFpQkgsSUFBakI7QUFDRCxLQUZELENBR0EsT0FBTVUsR0FBTixFQUFVO0FBQ1JKLFVBQUlLLEtBQUosR0FBWUQsR0FBWjtBQUNEOztBQUNEM0IsWUFBUTZCLE1BQVIsQ0FBZU4sR0FBZjtBQUVBLFdBQU9SLElBQVA7QUFFRDs7QUFBQTtBQUNEUixPQUFLdUIsU0FBTCxDQUFlLEdBQWY7QUFDQXZCLE9BQUt3QixHQUFMLENBQVNDLEtBQUtDLFNBQUwsQ0FBZTtBQUN0Qm5CLGNBQVVBLFFBRFk7QUFFdEJvQixhQUFTNUIsSUFBSWUsSUFBSixDQUFTQztBQUZJLEdBQWYsQ0FBVDtBQUtELENBMUNELEU7Ozs7Ozs7Ozs7O0FDbkJBLElBQUlhLE1BQUo7QUFBVzFDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzQyxhQUFPdEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VDLFlBQU12QyxDQUFOO0FBQVE7O0FBQXBCLENBQWpELEVBQXVFLENBQXZFO0FBQTBFLElBQUl3QyxNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMkJBQVIsQ0FBYixFQUFrRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQWxELEVBQXlFLENBQXpFO0FBQTRFLElBQUl5QyxLQUFKLEVBQVVDLFlBQVY7QUFBdUI5QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsaUNBQVIsQ0FBYixFQUF3RDtBQUFDMkMsUUFBTXpDLENBQU4sRUFBUTtBQUFDeUMsWUFBTXpDLENBQU47QUFBUSxHQUFsQjs7QUFBbUIwQyxlQUFhMUMsQ0FBYixFQUFlO0FBQUMwQyxtQkFBYTFDLENBQWI7QUFBZTs7QUFBbEQsQ0FBeEQsRUFBNEcsQ0FBNUc7QUFBK0csSUFBSTJDLE1BQUo7QUFBVy9DLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxrQ0FBUixDQUFiLEVBQXlEO0FBQUM2QyxTQUFPM0MsQ0FBUCxFQUFTO0FBQUMyQyxhQUFPM0MsQ0FBUDtBQUFTOztBQUFwQixDQUF6RCxFQUErRSxDQUEvRTtBQWExYyxJQUFJNEMsTUFBTSxTQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLFVBQWQsRUFBMEJFLE1BQTFCO0FBQUEsb0NBQWtDO0FBQ2hDLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiLENBRGdDLENBR2hDO0FBQ0E7O0FBRUEsVUFBSVEsU0FBUyxJQUFJTCxNQUFKLENBQVdHLE9BQU9HLFdBQWxCLENBQWIsQ0FOZ0MsQ0FPaEM7QUFFQTtBQUNBOztBQUVBLFVBQUlDLFlBQVksZ0JBQWhCO0FBRUEsVUFBSUMsUUFBUSxJQUFJWixLQUFKLENBQVVPLE9BQU9NLEdBQVAsQ0FBV0MsSUFBckIsQ0FBWjtBQUVBLG9CQUFNTixPQUFPTyxLQUFQLENBQWEsd0JBQWIsRUFDSiwrQkFBWTtBQUNWLHNCQUFNSCxNQUFNSSxLQUFOLENBQVlMLFNBQVosQ0FBTjtBQUNELE9BRkQsQ0FESSxDQUFOLEVBaEJnQyxDQXFCaEM7QUFDQTs7QUFFQSxvQkFBTUgsT0FBT08sS0FBUCxDQUFhLHVCQUFiLEVBQ0osK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCQyxzQkFBbUJDLE1BQVAsNkJBQWtCO0FBQzVCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUVBO0FBRUEsZ0JBQUlDLE1BQU87Ozs7OzBCQUtHRCxPQUFPRSxXQUFZLE1BQUtGLE9BQU9HLE1BQU8sTUFBS0gsT0FBT0ksR0FBSSxNQUFLSixPQUFPSyxHQUFJLE1BQUtMLE9BQU9NLFVBQVcsTUFBS04sT0FBT08sSUFBSyxNQUFLUCxPQUFPUSxNQUFPLE1BQUtSLE9BQU9TLE1BQU8sTUFBS1QsT0FBT1UsTUFBTyxNQUFLVixPQUFPVyxNQUFPLE1BQUtYLE9BQU9ZLFlBQWEsTUFBS1osT0FBT2EsS0FBTSxNQUFLYixPQUFPYyxLQUFNLE1BQUtkLE9BQU9lLE9BQVEsTUFBS2YsT0FBT2dCLE1BQU8sTUFBS2hCLE9BQU9pQixNQUFPLE1BQUtqQixPQUFPa0IsS0FBTSxNQUFLbEIsT0FBT21CLEtBQU0sTUFBS25CLE9BQU9vQixLQUFNLE1BQUtwQixPQUFPcUIsS0FBTSxNQUFLckIsT0FBT3NCLEtBQU0sTUFBS3RCLE9BQU91QixLQUFNLE1BQUt2QixPQUFPd0IsS0FBTSxNQUFLeEIsT0FBT3lCLEtBQU0sTUFBS3pCLE9BQU8wQixRQUFTLE1BQUsxQixPQUFPMkIsSUFBSyxNQUFLM0IsT0FBTzRCLFVBQVcsTUFBSzVCLE9BQU82QixjQUFlLE1BQUs3QixPQUFPOEIsYUFBYyxNQUFLOUIsT0FBTytCLFNBQVUsTUFBSy9CLE9BQU9nQyxTQUFVLE1BQUtoQyxPQUFPaUMsSUFBSyxNQUFLakMsT0FBT2tDLFdBQVksTUFBS2xDLE9BQU9tQyxXQUFZLE1BQUtuQyxPQUFPb0MsT0FBUTs7aUJBTGxzQjs7QUFTQSxnQkFBSTtBQUNGLDRCQUFNNUMsTUFBTTZDLFdBQU4sQ0FDSixjQURJLEVBQ1k7QUFDZG5DLDZCQUFhRixPQUFPRSxXQUROO0FBRWRDLHdCQUFRSCxPQUFPRyxNQUZEO0FBR2RDLHFCQUFLSixPQUFPSSxHQUhFO0FBSWRDLHFCQUFLTCxPQUFPSyxHQUpFO0FBS2RDLDRCQUFZTixPQUFPTSxVQUxMO0FBTWRDLHNCQUFNUCxPQUFPTyxJQU5DO0FBT2RDLHdCQUFRUixPQUFPUSxNQVBEO0FBUWRDLHdCQUFRVCxPQUFPUyxNQVJEO0FBU2RDLHdCQUFRVixPQUFPVSxNQVREO0FBVWRDLHdCQUFRWCxPQUFPVyxNQVZEO0FBV2RDLDhCQUFjWixPQUFPWSxZQVhQO0FBWWRDLHVCQUFPYixPQUFPYSxLQVpBO0FBYWRDLHVCQUFPZCxPQUFPYyxLQWJBO0FBY2RDLHlCQUFTZixPQUFPZSxPQWRGO0FBZWRDLHdCQUFRaEIsT0FBT2dCLE1BZkQ7QUFnQmRDLHdCQUFRakIsT0FBT2lCLE1BaEJEO0FBaUJkQyx1QkFBT2xCLE9BQU9rQixLQWpCQTtBQWtCZEMsdUJBQU9uQixPQUFPbUIsS0FsQkE7QUFtQmRDLHVCQUFPcEIsT0FBT29CLEtBbkJBO0FBb0JkQyx1QkFBT3JCLE9BQU9xQixLQXBCQTtBQXFCZEMsdUJBQU90QixPQUFPc0IsS0FyQkE7QUFzQmRDLHVCQUFPdkIsT0FBT3VCLEtBdEJBO0FBdUJkQyx1QkFBT3hCLE9BQU93QixLQXZCQTtBQXdCZEMsdUJBQU96QixPQUFPeUIsS0F4QkE7QUF5QmRDLDBCQUFVMUIsT0FBTzBCLFFBekJIO0FBMEJkQyxzQkFBTTNCLE9BQU8yQixJQTFCQztBQTJCZEMsNEJBQVk1QixPQUFPNEIsVUEzQkw7QUE0QmRDLGdDQUFnQjdCLE9BQU82QixjQTVCVDtBQTZCZEMsK0JBQWU5QixPQUFPOEIsYUE3QlI7QUE4QmRDLDJCQUFXL0IsT0FBTytCLFNBOUJKO0FBK0JkQywyQkFBV2hDLE9BQU9nQyxTQS9CSjtBQWdDZEMsc0JBQU1qQyxPQUFPaUMsSUFoQ0M7QUFpQ2RDLDZCQUFhbEMsT0FBT2tDLFdBakNOO0FBa0NkQyw2QkFBYW5DLE9BQU9tQyxXQWxDTjtBQW1DZEMseUJBQVNwQyxPQUFPb0M7QUFuQ0YsZUFEWixDQUFOO0FBdUNELGFBeENELENBd0NFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWhFMkIsQ0FrRTVCOzs7QUFDQSxnQkFBSTtBQUNGLDRCQUFNOUMsTUFBTTZDLFdBQU4sQ0FDSixzQkFESSxFQUNvQjtBQUN0QkcscUNBQXFCLElBREM7QUFFdEJ0Qyw2QkFBYUYsT0FBT0UsV0FGRTtBQUd0QkksNEJBQVlOLE9BQU9NLFVBSEc7QUFJdEJDLHNCQUFNUCxPQUFPTyxJQUpTO0FBS3RCQyx3QkFBUVIsT0FBT1EsTUFMTztBQU10QkMsd0JBQVFULE9BQU9TLE1BTk87QUFPdEJDLHdCQUFRVixPQUFPVSxNQVBPO0FBUXRCQyx3QkFBUVgsT0FBT1csTUFSTztBQVN0QkMsOEJBQWNaLE9BQU9ZLFlBVEM7QUFVdEJDLHVCQUFPYixPQUFPYSxLQVZRO0FBV3RCQyx1QkFBT2QsT0FBT2MsS0FYUTtBQVl0QkMseUJBQVNmLE9BQU9lLE9BWk07QUFhdEJDLHdCQUFRaEIsT0FBT2dCLE1BYk87QUFjdEJDLHdCQUFRakIsT0FBT2lCLE1BZE87QUFldEJFLHVCQUFPbkIsT0FBT21CLEtBZlE7QUFnQnRCQyx1QkFBT3BCLE9BQU9vQixLQWhCUTtBQWlCdEJDLHVCQUFPckIsT0FBT3FCLEtBakJRO0FBa0J0QkMsdUJBQU90QixPQUFPc0IsS0FsQlE7QUFtQnRCQyx1QkFBT3ZCLE9BQU91QixLQW5CUTtBQW9CdEJDLHVCQUFPeEIsT0FBT3dCLEtBcEJRO0FBcUJ0QlUsNkJBQWFsQyxPQUFPa0MsV0FyQkU7QUFzQnRCQyw2QkFBYW5DLE9BQU9tQyxXQXRCRTtBQXVCdEJDLHlCQUFTcEMsT0FBT29DO0FBdkJNLGVBRHBCLENBQU47QUEyQkQsYUE1QkQsQ0E0QkUsT0FBT0UsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBakcyQixDQW1HNUI7OztBQUNBLGdCQUFJO0FBQ0YsNEJBQU05QyxNQUFNNkMsV0FBTixDQUNKLHVCQURJLEVBQ3FCO0FBQ3ZCSSxvQkFBSSxJQURtQjtBQUV2QnZDLDZCQUFhRixPQUFPRSxXQUZHO0FBR3ZCd0MsOEJBQWMxQyxPQUFPMEMsWUFIRTtBQUl2QlIsNkJBQWFsQyxPQUFPa0MsV0FKRztBQUt2QkMsNkJBQWFuQyxPQUFPbUMsV0FMRztBQU12QkMseUJBQVNwQyxPQUFPb0M7QUFOTyxlQURyQixDQUFOO0FBVUQsYUFYRCxDQVdFLE9BQU9FLENBQVAsRUFBVTtBQUNWbEQscUJBQU9tRCxNQUFQLENBQWNELENBQWQ7QUFDRCxhQWpIMkIsQ0FtSDVCOzs7QUFFQSxnQkFBSUssV0FBV2hFLE9BQU9pRSxXQUFQLENBQW1CLENBQW5CLEVBQXNCQyxRQUF0QixDQUErQixRQUEvQixFQUF5Q0MsU0FBekMsQ0FBbUQsQ0FBbkQsRUFBc0QsRUFBdEQsQ0FBZjtBQUVBLGdCQUFJQyxhQUFjLEdBQUUvQyxPQUFPUSxNQUFPLElBQUdSLE9BQU9TLE1BQU8sbUJBQWtCVCxPQUFPRSxXQUFZLEVBQXhGO0FBRUEsZ0JBQUk4QyxnQkFBZ0JoRCxPQUFPaUQsS0FBUCxHQUFlLEdBQW5DOztBQUVBLGdCQUFJO0FBQ0Ysa0JBQUlwRCxvQkFBWUwsTUFBTTZDLFdBQU4sQ0FDZCxZQURjLEVBQ0E7QUFDWmEsMkJBQVcsSUFEQztBQUVaQywyQkFBV1IsUUFGQztBQUdaUyw2QkFBYSxDQUhEO0FBR0k7QUFDaEJDLDZCQUFhTixVQUpEO0FBS1pPLCtCQUFlLENBTEg7QUFNWkMsaUNBQWlCLENBTkw7QUFPWkMsZ0NBQWdCLENBUEo7QUFRWkMsZ0NBQWdCVCxhQVJKO0FBU1pVLCtCQUFlLElBVEg7QUFVWkMsNkJBQWEsQ0FWRDtBQVdaQywrQkFBZSxDQVhIO0FBWVpDLG9DQUFvQixJQVpSO0FBYVozRCw2QkFBYUYsT0FBT0UsV0FiUjtBQWNaNEQscUNBQXFCLHFCQWRUO0FBZVpDLG1DQUFtQixxQkFmUDtBQWdCWjNCLHlCQUFTO0FBaEJHLGVBREEsRUFrQlg7QUFDREYsNkJBQWEsT0FEWjtBQUVEQyw2QkFBYTtBQUZaLGVBbEJXLENBQVosQ0FBSjtBQXVCRCxhQXhCRCxDQXdCRSxPQUFPRyxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRixXQXRKVztBQURpQixTQUFmLEVBeUpUQSxDQUFQLDZCQUFhO0FBQ1hsRCxpQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNELFNBRkQsQ0F6SmdCLENBQVosQ0FBSjtBQThKQSxlQUFPekMsR0FBUDtBQUNELE9BaEtELENBREksQ0FBTjtBQW1LQSxhQUFPVCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0E1TEQ7QUFBQSxHQUZhOztBQWdNUCx1QkFBTixDQUE2QkMsT0FBN0I7QUFBQSxvQ0FBc0M7QUFDcEMsVUFBSUMsS0FBSyxJQUFJdEYsS0FBSixDQUFVcUYsT0FBVixDQUFUO0FBQ0EsVUFBSXBFLG9CQUFZcUUsR0FBR3RFLEtBQUgsQ0FBUyxnQkFBVCxDQUFaLENBQUo7QUFDQSxhQUFPQyxHQUFQO0FBQ0QsS0FKRDtBQUFBOztBQWhNYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDZkEsSUFBSXNFLGVBQUo7QUFBb0JsSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDZ0ksa0JBQWdCOUgsQ0FBaEIsRUFBa0I7QUFBQzhILHNCQUFnQjlILENBQWhCO0FBQWtCOztBQUF0QyxDQUFqRCxFQUF5RixDQUF6RjtBQUE0RixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBRzNILElBQUk0QyxNQUFNLGtCQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLE9BQWQsRUFBdUJtRixJQUF2QixFQUE2QnhFLFFBQVEsRUFBckMsRUFBeUN5RSxhQUFhLEVBQXREO0FBQUEsb0NBQTBEO0FBQ3hELFVBQUlDLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQkEsS0FBS0ksVUFBL0IsQ0FBYixDQUFKO0FBQ0EsVUFBSTNFLG9CQUFZeUUsS0FBS0csSUFBTCxDQUFVN0UsS0FBVixFQUFpQjtBQUFDeUUsb0JBQVlBO0FBQWIsT0FBakIsRUFBMkNLLE9BQTNDLEVBQVosQ0FBSjtBQUNBLGFBQU83RSxHQUFQO0FBQ0QsS0FKRDtBQUFBLEdBRmE7O0FBUWIsR0FBUSxHQUFFWixHQUFJLFlBQWQsRUFBNEJtRixJQUE1QixFQUFrQ3hFLFFBQVEsRUFBMUM7QUFBQSxvQ0FBOEM7QUFDNUMsVUFBSTBFLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQkEsS0FBS0ksVUFBL0IsQ0FBYixDQUFKO0FBQ0EsVUFBSTNFLG9CQUFZeUUsS0FBS0ssU0FBTCxDQUFlL0UsS0FBZixFQUFzQjhFLE9BQXRCLEVBQVosQ0FBSjtBQUNBLGFBQU83RSxHQUFQO0FBQ0QsS0FKRDtBQUFBOztBQVJhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNMQSxJQUFJK0UsY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFwRCxFQUFtRixDQUFuRjtBQUFzRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBR3BILElBQUk0QyxNQUFNLGFBQVY7QUFFQWhDLE9BQU9pQyxPQUFQLENBQWU7QUFFYjs7Ozs7QUFLQSxHQUFRLEdBQUVELEdBQUksV0FBZCxFQUEyQm1GLElBQTNCLEVBQWlDOUcsUUFBakMsRUFBMkN1SCxLQUEzQyxFQUFrREMsU0FBUyxJQUEzRCxFQUFpRUMsU0FBUyxJQUExRTtBQUFBLG9DQUFnRjtBQUM5RSxVQUFJQyxVQUFVLElBQUlKLGNBQUosRUFBZDtBQUNBLG9CQUFNSSxRQUFRQyxJQUFSLENBQWFiLElBQWIsQ0FBTjtBQUNBLFVBQUljLHlCQUFpQkYsUUFBUUcsUUFBUixDQUFpQjdILFFBQWpCLEVBQTJCdUgsS0FBM0IsRUFBa0NDLE1BQWxDLEVBQTBDQyxNQUExQyxDQUFqQixDQUFKO0FBQ0EsYUFBT0csUUFBUDtBQUNELEtBTEQ7QUFBQSxHQVBhOztBQWNiOzs7QUFHQSxHQUFRLEdBQUVqRyxHQUFJLGFBQWQsRUFBNkJtRixJQUE3QixFQUFtQ1MsS0FBbkMsRUFBMENDLFNBQVMsSUFBbkQsRUFBeURDLFNBQVMsSUFBbEU7QUFBQSxvQ0FBd0U7QUFDdEUsVUFBSUMsVUFBVSxJQUFJSixjQUFKLEVBQWQ7QUFDQSxvQkFBTUksUUFBUUMsSUFBUixDQUFhYixJQUFiLENBQU47QUFDQSxvQkFBTVksUUFBUUksVUFBUixDQUFtQlAsS0FBbkIsRUFBMEJDLE1BQTFCLEVBQWtDQyxNQUFsQyxDQUFOO0FBQ0QsS0FKRDtBQUFBOztBQWpCYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDTEEsSUFBSWxHLE1BQUo7QUFBVzVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDd0MsYUFBT3hDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWdKLGFBQUo7QUFBa0JwSixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDa0osZ0JBQWNoSixDQUFkLEVBQWdCO0FBQUNnSixvQkFBY2hKLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUlpSixRQUFKO0FBQWFySixPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDbUosV0FBU2pKLENBQVQsRUFBVztBQUFDaUosZUFBU2pKLENBQVQ7QUFBVzs7QUFBeEIsQ0FBcEQsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSXVJLGNBQUo7QUFBbUIzSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3VJLHFCQUFldkksQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBakQsRUFBZ0YsQ0FBaEY7QUFBbUYsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQVlqZSxJQUFJNEMsTUFBTSxNQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxjQUFkLEVBQThCRSxNQUE5QjtBQUFBLG9DQUFzQztBQUNwQztBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsVUFBSVEsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBQ0EsVUFBSXVCLGlCQUFpQixJQUFJWixjQUFKLEVBQXJCO0FBQ0Esb0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTjtBQUVBLFVBQUlFLFdBQVcsSUFBSTdHLEtBQUosQ0FBVU8sT0FBT3VHLE9BQWpCLENBQWY7QUFDQSxVQUFJQyxNQUFNLElBQUlMLFFBQUosQ0FBYUcsUUFBYixDQUFWO0FBRUEsb0JBQU1yRyxPQUFPTyxLQUFQLENBQ0osT0FESSxFQUVKLCtCQUFZO0FBQ1YsWUFBSUUsb0JBQVlSLE9BQU9TLE9BQVAsQ0FBZTtBQUU3QixvQkFBVSxDQUFPOEYsSUFBUCxFQUFhQyxPQUFiLDhCQUF5QjtBQUNqQyxnQkFBSUMseUJBQWlCTixlQUFlTyxRQUFmLENBQXdCSCxLQUFLSSxHQUE3QixDQUFqQixDQUFKO0FBQ0EsMEJBQU1MLElBQUlNLFdBQUosQ0FBZ0JMLEtBQUtNLElBQUwsQ0FBVUMsV0FBVixDQUFzQkMsZ0JBQXRDLEVBQXdETixRQUF4RCxDQUFOO0FBQ0QsV0FIUztBQUZtQixTQUFmLENBQVosQ0FBSjtBQU9BLGVBQU9qRyxHQUFQO0FBQ0QsT0FURCxDQUZJLENBQU47QUFhQSxhQUFPVCxPQUFPNEUsT0FBUCxFQUFQO0FBQ0QsS0F6QkQ7QUFBQSxHQUxhOztBQWdDYjtBQUNBO0FBRUEsR0FBUSxHQUFFL0UsR0FBSSxZQUFkLEVBQTRCRSxNQUE1QjtBQUFBLG9DQUFvQztBQUNsQyxVQUFJRSxTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWI7QUFDQSxVQUFJd0IsV0FBVyxJQUFJN0csS0FBSixDQUFVTyxPQUFPdUcsT0FBakIsQ0FBZjtBQUNBLFVBQUlDLE1BQU0sSUFBSUwsUUFBSixDQUFhRyxRQUFiLENBQVY7QUFFQSxVQUFJRCxpQkFBaUIsSUFBSVosY0FBSixFQUFyQjtBQUNBLG9CQUFNWSxlQUFlUCxJQUFmLENBQW9COUYsT0FBT29HLE9BQTNCLENBQU4sRUFOa0MsQ0FRbEM7O0FBQ0EsVUFBSW5HLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsb0JBQU1PLE9BQU9PLEtBQVAsQ0FDSixlQURJLEVBRUosK0JBQVk7QUFDVixZQUFJRSxvQkFBWVIsT0FBT1MsT0FBUCxDQUFlO0FBQzdCLG9CQUFVLENBQU84RixJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBQ2pDLGdCQUFJUSxNQUFNUixRQUFRckIsVUFBbEI7O0FBRUEsZ0JBQUk7QUFDRixrQkFBSThCLHlCQUFpQmQsZUFBZWUsZ0JBQWYsQ0FBZ0NwSCxPQUFPcUgsVUFBdkMsRUFBbURaLElBQW5ELENBQWpCLENBQUo7QUFFQSxrQkFBSWEsMEJBQWtCZCxJQUFJZSxhQUFKLENBQWtCSixRQUFsQixDQUFsQixDQUFKLENBSEUsQ0FLRjs7QUFDQSw0QkFBTUQsSUFBSU0sTUFBSixDQUFXO0FBQ2ZYLHFCQUFLSixLQUFLSTtBQURLLGVBQVgsRUFFSDtBQUNEWSxzQkFBTTtBQUNKLHNDQUFvQkgsVUFBVTVHO0FBRDFCO0FBREwsZUFGRyxDQUFOO0FBUUFULHFCQUFPeUgsUUFBUDtBQUNELGFBZkQsQ0FlRSxPQUFPdkUsQ0FBUCxFQUFVO0FBQ1ZsRCxxQkFBT21ELE1BQVAsQ0FBY0QsQ0FBZDtBQUNEO0FBQ0YsV0FyQlM7QUFEbUIsU0FBZixFQXdCVEEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQXhCZ0IsQ0FBWixDQUFKO0FBNEJBLGVBQU96QyxHQUFQO0FBQ0QsT0E5QkQsQ0FGSSxDQUFOO0FBa0NBLG9CQUFNVCxPQUFPTyxLQUFQLENBQ0osZ0JBREksRUFFSiwrQkFBWTtBQUNWLFlBQUlFLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFDN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlRLE1BQU1SLFFBQVFyQixVQUFsQjs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJOEIseUJBQWlCZCxlQUFlZSxnQkFBZixDQUFnQ3BILE9BQU9xSCxVQUF2QyxFQUFtRFosSUFBbkQsQ0FBakIsQ0FBSjtBQUVBLDRCQUFNRCxJQUFJbUIsa0JBQUosQ0FBdUJSLFFBQXZCLENBQU47QUFDQSw0QkFBTVgsSUFBSW9CLGFBQUosQ0FBa0JULFFBQWxCLENBQU47QUFDQSw0QkFBTVgsSUFBSXFCLGdCQUFKLENBQXFCVixRQUFyQixDQUFOO0FBRUEsa0JBQUlSLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF3QkgsS0FBS0ksR0FBN0IsQ0FBakIsQ0FBSjtBQUNBLDRCQUFNTCxJQUFJTSxXQUFKLENBQWdCTCxLQUFLTSxJQUFMLENBQVVDLFdBQVYsQ0FBc0JDLGdCQUF0QyxFQUF3RE4sUUFBeEQsQ0FBTjtBQUVBMUcscUJBQU95SCxRQUFQO0FBQ0QsYUFYRCxDQVdFLE9BQU92RSxDQUFQLEVBQVU7QUFDVmxELHFCQUFPbUQsTUFBUCxDQUFjRCxDQUFkO0FBQ0Q7QUFDRixXQWpCUztBQURtQixTQUFmLEVBb0JUQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBcEJnQixDQUFaLENBQUo7QUF3QkEsZUFBT3pDLEdBQVA7QUFDRCxPQTFCRCxDQUZJLENBQU47QUE4QkEsYUFBT1QsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBNUVEO0FBQUE7O0FBbkNhLENBQWYsRTs7Ozs7Ozs7Ozs7QUNkQSxJQUFJbkYsTUFBSjtBQUFXNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHdCQUFSLENBQWIsRUFBK0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN3QyxhQUFPeEMsQ0FBUDtBQUFTOztBQUFyQixDQUEvQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJZ0osYUFBSjtBQUFrQnBKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUNrSixnQkFBY2hKLENBQWQsRUFBZ0I7QUFBQ2dKLG9CQUFjaEosQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXVDLEtBQUo7QUFBVTNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBOUMsRUFBb0UsQ0FBcEU7QUFBdUUsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQU83UixJQUFJNEMsTUFBTSxNQUFWO0FBRUFoQyxPQUFPaUMsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXVCRSxNQUF2QjtBQUFBLG9DQUErQjtBQUM3QjtBQUNBLFVBQUlDLFNBQVMsSUFBSVAsTUFBSixFQUFiO0FBRUEsVUFBSVEsU0FBUyxJQUFJZ0csYUFBSixDQUFrQmxHLE9BQU9vRyxPQUF6QixFQUFrQ3BHLE9BQU84RSxPQUF6QyxDQUFiO0FBRUEsWUFBTWdELHlCQUFpQjVILE9BQU9TLE9BQVAsQ0FBZSxFQUFmLEVBQTBCd0MsQ0FBUCw2QkFBYTtBQUNyRCxjQUFNQSxDQUFOO0FBQ0QsT0FGeUMsQ0FBbkIsQ0FBakIsQ0FBTjtBQUdBLG9CQUFNbEQsT0FBT08sS0FBUCxDQUNKLFVBREksRUFFSiwrQkFBWTtBQUNWLGVBQU9zSCxRQUFQO0FBQ0QsT0FGRCxDQUZJLENBQU47QUFNQSxhQUFPN0gsT0FBTzRFLE9BQVAsRUFBUDtBQUNELEtBaEJEO0FBQUE7O0FBTGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ1RBLElBQUluRixNQUFKO0FBQVc1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3dDLGFBQU94QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUlnSixhQUFKO0FBQWtCcEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ2tKLGdCQUFjaEosQ0FBZCxFQUFnQjtBQUFDZ0osb0JBQWNoSixDQUFkO0FBQWdCOztBQUFsQyxDQUFwRCxFQUF3RixDQUF4RjtBQUEyRixJQUFJdUksY0FBSjtBQUFtQjNJLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUkscUJBQWV2SSxDQUFmO0FBQWlCOztBQUE3QixDQUFqRCxFQUFnRixDQUFoRjtBQUFtRixJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUk2SyxNQUFKO0FBQVdqTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZLLGFBQU83SyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUk4SyxPQUFKO0FBQVlsTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsVUFBUixDQUFiLEVBQWlDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDOEssY0FBUTlLLENBQVI7QUFBVTs7QUFBdEIsQ0FBakMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSStLLEtBQUo7QUFBVW5MLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxZQUFSLENBQWIsRUFBbUM7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMrSyxZQUFNL0ssQ0FBTjtBQUFROztBQUFwQixDQUFuQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJZ0wsUUFBSjtBQUFhcEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ2dMLGVBQVNoTCxDQUFUO0FBQVc7O0FBQXZCLENBQWpDLEVBQTBELENBQTFEO0FBQTZELElBQUlpTCxHQUFKO0FBQVFyTCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsS0FBUixDQUFiLEVBQTRCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDaUwsVUFBSWpMLENBQUo7QUFBTTs7QUFBbEIsQ0FBNUIsRUFBZ0QsQ0FBaEQ7QUFBbUQsSUFBSWtMLFdBQUosRUFBZ0JDLFNBQWhCO0FBQTBCdkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDb0wsY0FBWWxMLENBQVosRUFBYztBQUFDa0wsa0JBQVlsTCxDQUFaO0FBQWMsR0FBOUI7O0FBQStCbUwsWUFBVW5MLENBQVYsRUFBWTtBQUFDbUwsZ0JBQVVuTCxDQUFWO0FBQVk7O0FBQXhELENBQS9CLEVBQXlGLENBQXpGO0FBZWx2QixNQUFNb0wsU0FBUyxRQUFmO0FBQ0EsTUFBTXhJLE1BQU0sT0FBWjtBQUVBaEMsT0FBT2lDLE9BQVAsQ0FBZTtBQUViO0FBQ0E7QUFFQSxHQUFRLEdBQUVELEdBQUksUUFBZCxFQUF3QkUsTUFBeEI7QUFBQSxvQ0FBZ0M7QUFDOUI7QUFDQSxVQUFJQyxTQUFTLElBQUlQLE1BQUosRUFBYjtBQUVBLG9CQUFNTyxPQUFPTyxLQUFQLENBQ0osUUFESSxFQUVKLCtCQUFZO0FBQ1YsY0FBTTZGLGlCQUFpQixJQUFJWixjQUFKLEVBQXZCO0FBQ0Esc0JBQU1ZLGVBQWVQLElBQWYsQ0FBb0I5RixPQUFPb0csT0FBM0IsQ0FBTjtBQUNBLGNBQU1tQyxVQUFXLEdBQUV2SSxPQUFPdUksT0FBUSxRQUFsQztBQUNBLGNBQU1DLElBQUlSLFFBQVFTLGdCQUFSLENBQTBCLEdBQUVGLE9BQVEsSUFBR3ZJLE9BQU8wSSxhQUFjLEVBQTVELENBQVY7QUFDQSxjQUFNQyxJQUFJWCxRQUFRWSxpQkFBUixDQUEyQixHQUFFTCxPQUFRLElBQUd2SSxPQUFPNkksYUFBYyxFQUE3RCxDQUFWO0FBQ0FMLFVBQUVNLElBQUYsQ0FBT2IsTUFBTWMsWUFBTixDQUFtQixNQUFuQixDQUFQLEVBQ0dELElBREgsQ0FDUWIsTUFBTWUsWUFBTixDQUFtQixPQUFuQixDQURSLEVBRUdGLElBRkgsQ0FFUVgsSUFBSWMsS0FBSixDQUFVO0FBQUNDLG1CQUFTO0FBQVYsU0FBVixDQUZSLEVBR0dKLElBSEgsQ0FHUVgsSUFBSWdCLFNBQUosQ0FDSixDQUFPdEksTUFBUCxFQUFldUksUUFBZiw4QkFBNEI7QUFDMUIsY0FBSXBLLE1BQU0sSUFBVixDQUQwQixDQUUxQjs7QUFDQSxjQUFJO0FBQ0Y2QixtQkFBTyxNQUFQLGtCQUF1QndGLGVBQWVnRCxhQUFmLENBQTZCeEksT0FBTyxNQUFQLENBQTdCLENBQXZCO0FBQ0QsV0FGRCxDQUVFLE9BQU9zQyxDQUFQLEVBQVU7QUFDVm5FLGtCQUFNbUUsQ0FBTjtBQUNEOztBQUNEaUcsbUJBQVNwSyxHQUFULEVBQWM2QixNQUFkO0FBQ0QsU0FURCxDQURJLENBSFIsRUFlR2lJLElBZkgsQ0FlUVgsSUFBSTdJLFNBQUosQ0FBYztBQUFDZ0ssa0JBQVE7QUFBVCxTQUFkLENBZlIsRUFnQkdSLElBaEJILENBZ0JRYixNQUFNYyxZQUFOLENBQW1CLE9BQW5CLENBaEJSLEVBaUJHRCxJQWpCSCxDQWlCUWIsTUFBTWUsWUFBTixDQUFtQixNQUFuQixDQWpCUixFQWtCR0YsSUFsQkgsQ0FrQlFILENBbEJSO0FBbUJELE9BekJELENBRkksQ0FBTjtBQTZCRCxLQWpDRDtBQUFBLEdBTGE7O0FBd0NiO0FBQ0E7QUFFQSxHQUFRLEdBQUU3SSxHQUFJLFVBQWQsRUFBMEJFLE1BQTFCO0FBQUEsb0NBQWtDO0FBQ2hDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUCxNQUFKLEVBQWI7QUFFQSxvQkFBTU8sT0FBT08sS0FBUCxDQUNKLFFBREksRUFFSiwrQkFBWTtBQUNWO0FBQ0E7QUFFQSxjQUFNTixTQUFTLElBQUlnRyxhQUFKLENBQWtCbEcsT0FBT29HLE9BQXpCLEVBQWtDcEcsT0FBTzhFLE9BQXpDLENBQWY7QUFDQSxjQUFNdUIsaUJBQWlCLElBQUlaLGNBQUosRUFBdkI7QUFDQSxzQkFBTVksZUFBZVAsSUFBZixDQUFvQjlGLE9BQU9vRyxPQUEzQixDQUFOLEVBTlUsQ0FRVjs7QUFDQSxjQUFNbUQsU0FBUyxJQUFJeEIsTUFBSixDQUFXL0gsT0FBT3dKLFVBQWxCLENBQWYsQ0FUVSxDQVdWOztBQUNBLFlBQUk7QUFDRix3QkFBTXhCLFFBQVF5QixLQUFSLENBQWN6SixPQUFPdUksT0FBckIsQ0FBTjtBQUNELFNBRkQsQ0FFRSxPQUFPcEYsQ0FBUCxFQUFVLENBQUUsQ0FkSixDQWdCVjs7O0FBQ0EsY0FBTW9GLFVBQVcsR0FBRXZJLE9BQU91SSxPQUFRLE9BQWxDO0FBQ0Esc0JBQU1QLFFBQVEwQixNQUFSLENBQWVuQixPQUFmLENBQU47QUFDQSxzQkFBTVAsUUFBUXlCLEtBQVIsQ0FBY2xCLE9BQWQsQ0FBTixFQW5CVSxDQXFCVjs7QUFDQSxjQUFNb0IsWUFBYSxHQUFFM0osT0FBT3VJLE9BQVEsU0FBcEM7QUFDQSxzQkFBTVAsUUFBUTBCLE1BQVIsQ0FBZUMsU0FBZixDQUFOO0FBQ0Esc0JBQU0zQixRQUFReUIsS0FBUixDQUFjRSxTQUFkLENBQU47QUFFQSxZQUFJQyxLQUFLLElBQVQsQ0ExQlUsQ0EwQkk7O0FBQ2QsWUFBSXBMLFdBQVcsSUFBZixDQTNCVSxDQTJCVTs7QUFDcEIsWUFBSU0sT0FBTyxJQUFYLENBNUJVLENBNEJNO0FBRWhCOztBQUNBLFlBQUkrSyxTQUFTLENBQUMsTUFBRCxFQUFTLE1BQVQsRUFBaUIsTUFBakIsRUFBeUIsSUFBekIsRUFBK0IsZ0JBQS9CLEVBQWlELE1BQWpELEVBQXlELE1BQXpELEVBQWlFLE9BQWpFLEVBQTBFLElBQTFFLEVBQWdGLFFBQWhGLEVBQTBGLElBQTFGLEVBQWdHLE1BQWhHLEVBQXdHLFlBQXhHLEVBQXNILFlBQXRILEVBQW9JLE1BQXBJLEVBQTRJLFdBQTVJLEVBQXlKLFlBQXpKLEVBQXVLLE9BQXZLLEVBQWdMLFNBQWhMLEVBQTJMLE9BQTNMLEVBQW9NLFNBQXBNLEVBQStNLEtBQS9NLEVBQXNOLFNBQXROLEVBQWlPLEtBQWpPLEVBQXdPLFNBQXhPLEVBQW1QLEtBQW5QLEVBQTBQLFNBQTFQLEVBQXFRLEtBQXJRLEVBQTRRLFNBQTVRLEVBQXVSLEtBQXZSLEVBQThSLFNBQTlSLEVBQXlTLEtBQXpTLEVBQWdULFNBQWhULEVBQTJULEtBQTNULEVBQWtVLFNBQWxVLEVBQTZVLEtBQTdVLEVBQW9WLFNBQXBWLEVBQStWLEtBQS9WLEVBQXNXLFNBQXRXLEVBQWlYLE1BQWpYLEVBQXlYLFVBQXpYLEVBQXFZLE1BQXJZLEVBQTZZLFFBQTdZLEVBQXVaLFNBQXZaLEVBQWthLE1BQWxhLEVBQTBhLE1BQTFhLEVBQWtiLFVBQWxiLEVBQThiLE9BQTliLEVBQXVjLFFBQXZjLEVBQWlkLFFBQWpkLEVBQTJkLFdBQTNkLEVBQXdlLFFBQXhlLEVBQWtmLEtBQWxmLEVBQXlmLGNBQXpmLEVBQXlnQixTQUF6Z0IsRUFBb2hCLFNBQXBoQixFQUEraEIsWUFBL2hCLEVBQTZpQixjQUE3aUIsRUFBNmpCLFFBQTdqQixFQUF1a0IsT0FBdmtCLEVBQWdsQixRQUFobEIsRUFBMGxCLFVBQTFsQixFQUFzbUIsbUJBQXRtQixFQUEybkIsZ0JBQTNuQixFQUE2b0IsVUFBN29CLEVBQXlwQixtQkFBenBCLEVBQThxQixnQkFBOXFCLEVBQWdzQixVQUFoc0IsRUFBNHNCLG1CQUE1c0IsRUFBaXVCLGdCQUFqdUIsRUFBbXZCLFVBQW52QixFQUErdkIsbUJBQS92QixFQUFveEIsZ0JBQXB4QixFQUFzeUIsVUFBdHlCLEVBQWt6QixtQkFBbHpCLEVBQXUwQixnQkFBdjBCLEVBQXkxQixVQUF6MUIsRUFBcTJCLG1CQUFyMkIsRUFBMDNCLGdCQUExM0IsRUFBNDRCLFVBQTU0QixFQUF3NUIsbUJBQXg1QixFQUE2NkIsZ0JBQTc2QixFQUErN0IsVUFBLzdCLEVBQTI4QixtQkFBMzhCLEVBQWcrQixnQkFBaCtCLEVBQWsvQixVQUFsL0IsRUFBOC9CLG1CQUE5L0IsRUFBbWhDLGdCQUFuaEMsRUFBcWlDLFdBQXJpQyxFQUFrakMsb0JBQWxqQyxFQUF3a0MsaUJBQXhrQyxFQUEybEMsTUFBM2xDLEVBQW1tQyxXQUFubUMsRUFBZ25DLFNBQWhuQyxFQUEybkMsT0FBM25DLEVBQW9vQyxnQkFBcG9DLENBQWI7QUFDQSxZQUFJUCxTQUFTTyxPQUFPQyxHQUFQLENBQVc1TSxLQUFNLElBQUdBLENBQUUsR0FBdEIsRUFBMEI2TSxJQUExQixDQUErQixHQUEvQixJQUFzQyxJQUFuRCxDQWhDVSxDQWtDVjs7QUFDQVIsZUFBT1MsYUFBUCxHQUE4QkMsV0FBUCw2QkFBdUI7QUFDNUNuTCxpQkFBT3dKLFNBQVMsQ0FBQyxVQUFVMkIsV0FBWCxFQUF3QkMsS0FBeEIsQ0FBOEIsQ0FBQyxDQUEvQixDQUFoQjtBQUNBTixlQUFNLEdBQUVyQixPQUFRLElBQUd6SixJQUFLLEVBQXhCO0FBQ0FOLHFCQUFZLEdBQUVvTCxFQUFHLElBQUc1SixPQUFPbUssV0FBWSxFQUF2QztBQUNBLHdCQUFNbkMsUUFBUXlCLEtBQVIsQ0FBY0csRUFBZCxDQUFOLEVBSjRDLENBSzVDOztBQUNBLHdCQUFNNUIsUUFBUW9DLFVBQVIsQ0FBbUI1TCxRQUFuQixFQUE2QnlKLE1BQU1vQyxNQUFOLENBQWFmLE1BQWIsRUFBcUIsV0FBckIsQ0FBN0IsQ0FBTjtBQUNELFNBUHNCLENBQXZCLENBbkNVLENBNENWOzs7QUFDQUMsZUFBT2UsUUFBUCxHQUF5QkMsR0FBUCw2QkFBZTtBQUMvQixjQUFJQyxRQUFRRCxJQUFJQyxLQUFoQjtBQUNBLGNBQUkvRCxPQUFPOEQsSUFBSTlELElBQWYsQ0FGK0IsQ0FHL0I7O0FBQ0EsY0FBSTVGLFNBQVNnSixPQUFPQyxHQUFQLENBQVc1TSxLQUFLO0FBQUUsbUJBQU9zTixNQUFNdE4sQ0FBTixJQUFZLElBQUdzTixNQUFNdE4sQ0FBTixDQUFTLEdBQXhCLEdBQTZCLElBQXBDO0FBQTBDLFdBQTVELEVBQThENk0sSUFBOUQsQ0FBbUUsR0FBbkUsSUFBMEUsSUFBdkY7QUFDQSx3QkFBTS9CLFFBQVFvQyxVQUFSLENBQW1CNUwsUUFBbkIsRUFBNkJ5SixNQUFNb0MsTUFBTixDQUFheEosTUFBYixFQUFxQixXQUFyQixDQUE3QixDQUFOLEVBTCtCLENBTS9COztBQUNBLGVBQUssSUFBSTRKLEdBQVQsSUFBZ0JoRSxLQUFLaUUsTUFBckIsRUFBNkI7QUFDM0IsZ0JBQUlDLFNBQVUsR0FBRTNLLE9BQU9yQixRQUFTLElBQUc4TCxHQUFJLEVBQXZDO0FBQ0EsZ0JBQUlHLFNBQVUsR0FBRWhCLEVBQUcsSUFBR2EsR0FBSSxFQUExQjs7QUFDQSxnQkFBSTtBQUNGO0FBQ0EsNEJBQU16QyxRQUFRNkMsTUFBUixDQUFlRCxNQUFmLENBQU47QUFDRCxhQUhELENBR0UsT0FBT3pILENBQVAsRUFBVTtBQUNWLDRCQUFNNkUsUUFBUThDLFFBQVIsQ0FBaUJILE1BQWpCLEVBQXlCQyxNQUF6QixDQUFOO0FBQ0Q7QUFDRjtBQUNGLFNBakJpQixDQUFsQixDQTdDVSxDQWdFVjs7O0FBQ0FyQixlQUFPd0IsV0FBUCxHQUE0QmQsV0FBUCw2QkFBdUI7QUFDMUMsZ0JBQU1lLE1BQU05QyxTQUFTLEtBQVQsQ0FBWjtBQUNBLGdCQUFNK0MsVUFBVyxHQUFFdEIsU0FBVSxJQUFHN0ssSUFBSyxNQUFyQztBQUNBLGdCQUFNb00sU0FBU2xELFFBQVFZLGlCQUFSLENBQTBCcUMsT0FBMUIsQ0FBZjtBQUNBRCxjQUFJbEMsSUFBSixDQUFTb0MsTUFBVDtBQUNBRixjQUFJRyxTQUFKLENBQWN2QixFQUFkLEVBQWtCLEtBQWxCO0FBQ0FvQixjQUFJSSxRQUFKO0FBQ0QsU0FQb0IsQ0FBckIsQ0FqRVUsQ0EwRVY7QUFDQTs7O0FBRUEsWUFBSTFLLG9CQUFZUixPQUFPUyxPQUFQLENBQWU7QUFFN0Isb0JBQVUsQ0FBTzhGLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFDakMsZ0JBQUlDLHlCQUFpQk4sZUFBZU8sUUFBZixDQUF3QkgsS0FBS0ksR0FBN0IsQ0FBakIsQ0FBSixDQURpQyxDQUVqQzs7QUFDQSxnQkFBSUYsWUFBWUYsS0FBS00sSUFBTCxDQUFVeUQsS0FBVixDQUFnQmEsV0FBaEMsRUFBNkM7QUFDM0Msa0JBQUliLHNCQUFjbkUsZUFBZWlGLGdCQUFmLENBQWdDdEwsT0FBTy9DLE9BQXZDLEVBQWdEd0osSUFBaEQsQ0FBZCxDQUFKO0FBQ0EsNEJBQU04QyxPQUFPZ0MsTUFBUCxDQUFjO0FBQUNmLHVCQUFPQSxLQUFSO0FBQWUvRCxzQkFBTUE7QUFBckIsZUFBZCxDQUFOO0FBQ0Q7QUFDRixXQVBTO0FBRm1CLFNBQWYsQ0FBWixDQUFKO0FBV0E4QyxlQUFPaUMsS0FBUDtBQUVBLGVBQU85SyxHQUFQO0FBQ0QsT0EzRkQsQ0FGSSxDQUFOO0FBK0ZBLGFBQU9ULE9BQU80RSxPQUFQLEVBQVA7QUFDRCxLQXBHRDtBQUFBOztBQTNDYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDbEJBL0gsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLCtCQUFSLENBQWI7QUFBdURGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxzQkFBUixDQUFiLEU7Ozs7Ozs7Ozs7O0FDQXZERixPQUFPMk8sTUFBUCxDQUFjO0FBQUNDLFdBQVEsTUFBSUE7QUFBYixDQUFkO0FBQXFDLElBQUlDLEtBQUo7QUFBVTdPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQzJPLFFBQU16TyxDQUFOLEVBQVE7QUFBQ3lPLFlBQU16TyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRXhDLE1BQU13TyxVQUFVLElBQUlDLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBK0I7QUFBQ0MsZ0JBQWE7QUFBZCxDQUEvQixDQUFoQixDOzs7Ozs7Ozs7OztBQ0ZQL08sT0FBTzJPLE1BQVAsQ0FBYztBQUFDNUwsVUFBTyxNQUFJQTtBQUFaLENBQWQ7QUFBbUMsSUFBSThMLEtBQUo7QUFBVTdPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQzJPLFFBQU16TyxDQUFOLEVBQVE7QUFBQ3lPLFlBQU16TyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJNE8sSUFBSjtBQUFTaFAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE1BQVIsQ0FBYixFQUE2QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzRPLFdBQUs1TyxDQUFMO0FBQU87O0FBQW5CLENBQTdCLEVBQWtELENBQWxEO0FBQXFELElBQUk2TyxPQUFKO0FBQVlqUCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsYUFBUixDQUFiLEVBQW9DO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDNk8sY0FBUTdPLENBQVI7QUFBVTs7QUFBdEIsQ0FBcEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSThPLFNBQUo7QUFBY2xQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxVQUFSLENBQWIsRUFBaUM7QUFBQ2dQLFlBQVU5TyxDQUFWLEVBQVk7QUFBQzhPLGdCQUFVOU8sQ0FBVjtBQUFZOztBQUExQixDQUFqQyxFQUE2RCxDQUE3RDtBQWFuWixNQUFNK08sVUFBVSxJQUFJTixNQUFNQyxVQUFWLENBQXFCLFNBQXJCLEVBQWdDO0FBQzlDQyxnQkFBYztBQURnQyxDQUFoQyxDQUFoQjs7QUFJTyxNQUFNaE0sTUFBTixTQUFxQm1NLFNBQXJCLENBQStCO0FBRXBDRSxjQUFZQyxRQUFaLEVBQXNCO0FBRXBCLFFBQUlySCxVQUFVbUgsUUFBUUcsT0FBUixDQUFnQjtBQUM1QnZGLFdBQUtzRjtBQUR1QixLQUFoQixDQUFkO0FBSUEsVUFBTXJILE9BQU47QUFFQSxRQUFJRyxPQUFPLEtBQUtvSCxPQUFMLEVBQVg7O0FBRUEsWUFBUXBILEtBQUtxSCxJQUFiO0FBRUUsV0FBSyxPQUFMO0FBQ0UsYUFBS0MsS0FBTCxHQUFhLElBQUk5TSxLQUFKLENBQVV3RixLQUFLMUUsSUFBZixDQUFiOztBQUNBLGFBQUtpTSxNQUFMLEdBQWMsQ0FBUUMsV0FBWTVMLE1BQUQsSUFBVSxDQUFFLENBQS9CLEVBQWlDNkwsVUFBV3ZKLENBQUQsSUFBSyxDQUFFLENBQWxELDhCQUF3RDtBQUNwRSxjQUFJckMsTUFBTyxpQkFBZ0JtRSxLQUFLMEgsS0FBTSxFQUF0QztBQUNBLCtCQUFhLEtBQUtKLEtBQUwsQ0FBV0ssY0FBWCxDQUEwQjlMLEdBQTFCLEVBQStCMkwsUUFBL0IsRUFBeUNDLE9BQXpDLENBQWI7QUFDRCxTQUhhLENBQWQ7O0FBSUE7O0FBRUY7QUFDRSxjQUFNLElBQUlHLEtBQUosQ0FBVSx1QkFBVixDQUFOO0FBWEo7QUFjRDtBQUVEOzs7Ozs7QUFJTWxNLFNBQU4sQ0FBY21NLFlBQVksRUFBMUIsRUFBOEJKLFVBQWlCdkosQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBeEM7QUFBQSxvQ0FBeUQ7QUFFdkQsVUFBSTJCLFVBQVUsS0FBS2lJLFVBQUwsRUFBZCxDQUZ1RCxDQUl2RDs7QUFDQWpJLGNBQVFrSSxPQUFSLENBQWdCQyxJQUFoQixDQUFxQjtBQUNuQlgsY0FBTSxNQURhO0FBRW5CN0wsZUFBTztBQUZZLE9BQXJCO0FBS0EsVUFBSXlNLFFBQVEsRUFBWjs7QUFDQSxXQUFLLElBQUloTixNQUFULElBQW1CNEUsUUFBUWtJLE9BQTNCLEVBQW9DO0FBQ2xDRSxjQUFNaE4sT0FBT29NLElBQWIsSUFBcUI7QUFDbkI3TCxpQkFBT1AsT0FBT08sS0FESztBQUVuQnlNLGlCQUFPO0FBRlksU0FBckI7QUFJRDs7QUFFRCxvQkFBTSxLQUFLVixNQUFMLENBQ0czTCxNQUFQLDZCQUFnQjtBQUNkLGFBQUssSUFBSVgsTUFBVCxJQUFtQjRFLFFBQVFrSSxPQUEzQixFQUFvQztBQUNsQyxjQUFJdk0sUUFBUXNMLFFBQVFvQixRQUFSLENBQWlCak4sT0FBT08sS0FBeEIsQ0FBWjtBQUNBLGNBQUkyTSxPQUFPdEIsS0FBTXJMLEtBQU4sQ0FBWDs7QUFDQSxjQUFJMk0sS0FBS3ZNLE1BQUwsQ0FBSixFQUFrQjtBQUNoQnFNLGtCQUFNaE4sT0FBT29NLElBQWIsRUFBbUJZLEtBQW5COztBQUNBLGdCQUFJLE9BQU9KLFVBQVU1TSxPQUFPb00sSUFBakIsQ0FBUCxLQUFrQyxXQUF0QyxFQUFrRDtBQUNoRCw0QkFBTVEsVUFBVTVNLE9BQU9vTSxJQUFqQixFQUF1QnpMLE1BQXZCLENBQU47QUFDRDs7QUFDRDtBQUNEO0FBQ0Y7QUFDRixPQVpELENBREksRUFjSjZMLE9BZEksQ0FBTixFQWxCdUQsQ0FtQ3ZEOztBQUNBLGFBQU9RLEtBQVA7QUFFRCxLQXRDRDtBQUFBOztBQWhDb0MsQzs7Ozs7Ozs7Ozs7QUNqQnRDcFEsT0FBTzJPLE1BQVAsQ0FBYztBQUFDTyxhQUFVLE1BQUlBLFNBQWY7QUFBeUJyTSxTQUFNLE1BQUlBO0FBQW5DLENBQWQ7QUFBeUQsSUFBSWdNLEtBQUo7QUFBVTdPLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQzJPLFFBQU16TyxDQUFOLEVBQVE7QUFBQ3lPLFlBQU16TyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBQTRELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSVksTUFBSjtBQUFXaEIsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDYyxTQUFPWixDQUFQLEVBQVM7QUFBQ1ksYUFBT1osQ0FBUDtBQUFTOztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQVFuTixNQUFNbVEsU0FBUyxJQUFJMUIsTUFBTUMsVUFBVixDQUFxQixRQUFyQixFQUErQjtBQUM1Q0MsZ0JBQWM7QUFEOEIsQ0FBL0IsQ0FBZjs7QUFJTyxNQUFNRyxTQUFOLENBQWdCO0FBSXJCRSxjQUFZcEgsT0FBWixFQUFxQjtBQUNuQixTQUFLQSxPQUFMLEdBQWVBLE9BQWY7QUFDRDtBQUVEOzs7Ozs7O0FBS0F1SCxZQUFVO0FBQ1IsV0FBTyxLQUFLdkgsT0FBTCxDQUFhd0ksWUFBcEI7QUFDRDs7QUFFRFAsZUFBYTtBQUNYLFdBQU8sS0FBS2pJLE9BQVo7QUFDRDs7QUFFRG5FLFVBQVF5SSxXQUFrQnZJLE1BQVAsNkJBQWtCLENBQUUsQ0FBcEIsQ0FBbkIsRUFBeUM2TCxVQUFpQnZKLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQW5ELEVBQW9FLENBQUU7O0FBckJqRDs7QUF5QmhCLE1BQU14RCxLQUFOLFNBQW9CcU0sU0FBcEIsQ0FBOEI7QUFFbkNFLGNBQVlxQixPQUFaLEVBQXFCO0FBRW5CLFFBQUl6SSxVQUFVdUksT0FBT2pCLE9BQVAsQ0FBZTtBQUMzQnZGLFdBQUswRztBQURzQixLQUFmLENBQWQ7QUFJQSxVQUFNekksT0FBTjtBQUVBLFFBQUlHLE9BQU8sS0FBS29ILE9BQUwsRUFBWDs7QUFFQSxZQUFRcEgsS0FBS3FILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxhQUFLQyxLQUFMLEdBQWEsSUFBSTlNLEtBQUosQ0FBVXdGLEtBQUsxRSxJQUFmLENBQWI7O0FBQ0EsYUFBS2lNLE1BQUwsR0FBcUI1TixHQUFQLDZCQUFlO0FBQzNCLGNBQUlrQyxNQUFPLGlCQUFnQm1FLEtBQUswSCxLQUFNLFlBQVcvTixJQUFJNE8sR0FBSSxTQUFRNU8sSUFBSTBFLEVBQUcsR0FBeEU7QUFDQSwrQkFBYSxLQUFLaUosS0FBTCxDQUFXOUwsS0FBWCxDQUFpQkssR0FBakIsQ0FBYjtBQUNELFNBSGEsQ0FBZDs7QUFJQTs7QUFDRjtBQUNFLGNBQU0sSUFBSStMLEtBQUosQ0FBVSxvQkFBVixDQUFOO0FBVEo7QUFZRDtBQUdEOzs7Ozs7QUFJQWxNLFVBQVF5SSxXQUFrQnZJLE1BQVAsNkJBQWtCLENBQUUsQ0FBcEIsQ0FBbkIsRUFBeUM2TCxVQUFpQnZKLENBQVAsNkJBQWEsQ0FBRSxDQUFmLENBQW5ELEVBQW9FO0FBRWxFLFFBQUlzSyxNQUFNSixPQUFPL0gsSUFBUCxDQUFZO0FBQ3BCaUksZUFBUyxLQUFLekksT0FBTCxDQUFhK0I7QUFERixLQUFaLEVBRVA7QUFDRGdELGNBQVE7QUFDTmhELGFBQUssQ0FEQztBQUVOdkQsWUFBSSxDQUZFO0FBR05rSyxhQUFLO0FBSEM7QUFEUCxLQUZPLENBQVY7QUFVQSxXQUFPLElBQUlFLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFFbkJILFVBQUlJLE9BQUosQ0FDRSxDQUFPalAsR0FBUCxFQUFZa1AsS0FBWiw4QkFBc0I7QUFDcEIsWUFBSTtBQUNGLGNBQUlqTix1QkFBZSxLQUFLMkwsTUFBTCxDQUFZNU4sR0FBWixDQUFmLENBQUo7QUFDQSx3QkFBTXdLLFNBQVN2SSxNQUFULENBQU47QUFDRCxTQUhELENBR0UsT0FBT3NDLENBQVAsRUFBVTtBQUNWdUosa0JBQVF2SixDQUFSO0FBQ0Q7O0FBQ0QsWUFBSTJLLFFBQVEsQ0FBUixLQUFjTCxJQUFJUCxLQUFKLEVBQWxCLEVBQStCO0FBQzdCUztBQUNEO0FBQ0YsT0FWRCxDQURGO0FBYUQsS0FoQkksRUFpQkxJLEtBakJLLENBa0JKNUssQ0FBRCxJQUFPO0FBQ0wsWUFBTUEsQ0FBTjtBQUNELEtBcEJJLENBQVA7QUF1QkQ7O0FBbEVrQyxDOzs7Ozs7Ozs7OztBQ3JDckNyRyxPQUFPMk8sTUFBUCxDQUFjO0FBQUNwTyxXQUFRLE1BQUlBO0FBQWIsQ0FBZDtBQUFxQyxJQUFJc08sS0FBSjtBQUFVN08sT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDMk8sUUFBTXpPLENBQU4sRUFBUTtBQUFDeU8sWUFBTXpPLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFeEMsTUFBTUcsVUFBVSxJQUFJc08sTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUErQjtBQUFDQyxnQkFBYTtBQUFkLENBQS9CLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDRlAvTyxPQUFPMk8sTUFBUCxDQUFjO0FBQUN0RixZQUFTLE1BQUlBO0FBQWQsQ0FBZDtBQUF1QyxJQUFJMUcsS0FBSjtBQUFVM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN1QyxZQUFNdkMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTs7QUFFMUMsTUFBTWlKLFFBQU4sQ0FBZTtBQUNwQitGLGNBQWFLLFFBQVEsSUFBSTlNLEtBQUosRUFBckIsRUFBa0M7QUFDaEMsU0FBS3VPLE1BQUwsR0FBY3pCLEtBQWQ7QUFDRDs7QUFFS3pGLGFBQU4sQ0FBbUJtSCxjQUFuQixFQUFtQ3RILFdBQVcsQ0FBOUM7QUFBQSxvQ0FBaUQ7QUFDL0Msb0JBQU0sS0FBS3FILE1BQUwsQ0FBWUUsV0FBWixDQUNKLG1CQURJLEVBRUgsc0JBQXFCRCxjQUFlLEVBRmpDLEVBR0osRUFISSxFQUdBO0FBQ0ZFLGVBQU94SCxRQURMO0FBRUZ5SCx5QkFBaUIsQ0FGZjtBQUdGcEwscUJBQWE7QUFIWCxPQUhBLENBQU47QUFVQSxvQkFBTSxLQUFLZ0wsTUFBTCxDQUFZRSxXQUFaLENBQ0osbUJBREksRUFFSCxzQkFBcUJELGNBQWUsRUFGakMsRUFHSixFQUhJLEVBR0E7QUFDRkUsZUFBT3hILFFBREw7QUFFRjNELHFCQUFhO0FBRlgsT0FIQSxDQUFOO0FBUUQsS0FuQkQ7QUFBQTs7QUFxQk02RSxrQkFBTixDQUF3QnZKLElBQXhCO0FBQUEsb0NBQThCO0FBQzVCLFVBQUkrUCxZQUFZL1AsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVixDQUg0QixDQUs1Qjs7QUFDQSxVQUFJNE4sU0FBZ0J4TyxHQUFQLDZCQUFlO0FBQzFCLFlBQUlnQixNQUFPOzsyQkFFVXhDLEtBQUtpUSxVQUFXLGNBQWF6TyxHQUFJO09BRnREO0FBSUFZLFlBQUl1TSxJQUFKLGVBQWUsS0FBS2UsTUFBTCxDQUFZdk4sS0FBWixDQUFrQkssR0FBbEIsQ0FBZjtBQUNELE9BTlksQ0FBYixDQU40QixDQWM1Qjs7O0FBQ0EsVUFBSTBOLFFBQWUxTyxHQUFQLDZCQUFlO0FBQ3pCO0FBQ0EsWUFBSWdCLE1BQU87OzJCQUVVeEMsS0FBS2lRLFVBQVcsY0FBYXpPLEdBQUk7T0FGdEQ7QUFJQSxZQUFJMk8seUJBQWlCLEtBQUtULE1BQUwsQ0FBWXZOLEtBQVosQ0FBa0JLLEdBQWxCLENBQWpCLENBQUo7QUFDQSxZQUFJMk4sU0FBUyxDQUFULEVBQVksVUFBWixDQUFKLEVBQTZCO0FBRTdCL04sWUFBSXVNLElBQUosZUFDUSxLQUFLZSxNQUFMLENBQVk5SyxXQUFaLENBQ0osaUJBREksRUFFSixFQUZJLEVBR0o7QUFDRXFMLHNCQUFZalEsS0FBS2lRLFVBRG5CO0FBRUV6TyxlQUFLQSxHQUZQO0FBR0V1SCxzQkFBWWdILFNBSGQ7QUFJRXRMLHVCQUFhO0FBSmYsU0FISSxDQURSO0FBV0QsT0FwQlcsQ0FBWjs7QUFzQkEsV0FBSyxJQUFJMkwsTUFBVCxJQUFtQnBRLEtBQUtxUSxJQUF4QixFQUE4QjtBQUM1QixnQkFBUUQsT0FBT0UsR0FBZjtBQUNFLGVBQUssSUFBTDtBQUNFLDBCQUFNSixNQUFNRSxPQUFPNU8sR0FBYixDQUFOO0FBQ0E7O0FBQ0YsZUFBSyxLQUFMO0FBQ0UsMEJBQU13TyxPQUFPSSxPQUFPNU8sR0FBZCxDQUFOO0FBQ0E7QUFOSjtBQVFEOztBQUVELGFBQU87QUFDTFksYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0FuREQ7QUFBQTs7QUFxRE1pSCxvQkFBTixDQUEwQnJKLElBQTFCO0FBQUEsb0NBQWdDO0FBQzlCLFVBQUl1USxZQUFZdlEsS0FBS2lRLFVBQXJCO0FBQ0EsVUFBSTdELFNBQVNwTSxLQUFLb00sTUFBbEI7QUFDQSxVQUFJMkQsWUFBWS9QLEtBQUsrSSxVQUFyQjtBQUVBLFVBQUkzRyxNQUFNLEVBQVYsQ0FMOEIsQ0FPOUI7O0FBQ0EsVUFBSUksTUFBTyxvREFBbUQrTixTQUFVLEVBQXhFO0FBQ0FuTyxVQUFJdU0sSUFBSixlQUFlLEtBQUtlLE1BQUwsQ0FBWXZOLEtBQVosQ0FBa0JLLEdBQWxCLENBQWYsR0FUOEIsQ0FXOUI7O0FBQ0EsV0FBSyxJQUFJZ08sSUFBSSxDQUFiLEVBQWdCQSxJQUFJcEUsT0FBT3FFLE1BQTNCLEVBQW1DRCxHQUFuQyxFQUF3QztBQUN0QyxzQkFBTSxLQUFLZCxNQUFMLENBQVk5SyxXQUFaLENBQ0osbUJBREksRUFDaUI7QUFDbkJxTCxzQkFBWU0sU0FETztBQUVuQnhILHNCQUFZZ0gsU0FGTztBQUduQlcscUJBQVd0RSxPQUFPb0UsQ0FBUCxDQUhRO0FBSW5CRyxnQkFBTUgsSUFBSTtBQUpTLFNBRGpCLEVBTUQ7QUFDRC9MLHVCQUFhO0FBRFosU0FOQyxDQUFOO0FBVUQ7O0FBRUQsYUFBTztBQUNMckMsYUFBS0E7QUFEQSxPQUFQO0FBR0QsS0E1QkQ7QUFBQTs7QUE4Qk1rSCxlQUFOLENBQXFCdEosSUFBckI7QUFBQSxvQ0FBMkI7QUFDekIsVUFBSTRRLGFBQWEsRUFBakI7QUFDQSxVQUFJQyxPQUFPLEVBQVgsQ0FGeUIsQ0FJekI7O0FBRUFBLGFBQU8sQ0FDTCxRQURLLEVBRUwsTUFGSyxFQUdMLE1BSEssRUFJTCxrQkFKSyxFQUtMLG9CQUxLLEVBTUwsYUFOSyxFQU9MLFdBUEssQ0FBUDs7QUFTQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRCxvQkFBTSxLQUFLcEIsTUFBTCxDQUFZRSxXQUFaLENBQ0osYUFESSxFQUVILGdCQUFlNVAsS0FBS2lRLFVBQVcsRUFGNUIsRUFHSlcsVUFISSxFQUdRO0FBQ1ZsTSxxQkFBYTtBQURILE9BSFIsQ0FBTixFQW5CeUIsQ0EyQnpCOztBQUVBa00sbUJBQWEsRUFBYjtBQUNBQyxhQUFPLENBQ0wsa0JBREssRUFFTCxjQUZLLEVBR0wsWUFISyxFQUlMLFNBSkssRUFLTCxTQUxLLEVBTUwsY0FOSyxDQUFQOztBQVFBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVELFVBQUkxTyxvQkFBWSxLQUFLc04sTUFBTCxDQUFZRSxXQUFaLENBQ2QsbUJBRGMsRUFFYixnQkFBZTVQLEtBQUtpUSxVQUFXLEVBRmxCLEVBR2RXLFVBSGMsRUFHRjtBQUNWbE0scUJBQWE7QUFESCxPQUhFLENBQVosQ0FBSjtBQVFBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBckREO0FBQUE7O0FBdURNNkcsZUFBTixDQUFxQmpKLElBQXJCO0FBQUEsb0NBQTJCO0FBQ3pCLFVBQUkrUCxZQUFZL1AsS0FBSytJLFVBQXJCO0FBRUEsVUFBSTNHLE1BQU0sRUFBVjtBQUVBLFVBQUl3TyxhQUFhLEVBQWpCO0FBQ0EsVUFBSUMsT0FBTyxFQUFYO0FBRUFBLGFBQU8sQ0FDTCxNQURLLEVBRUwsb0JBRkssQ0FBUCxDQVJ5QixDQVl6QjtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRDFPLFVBQUk2TixVQUFKLGlCQUF1QixLQUFLUCxNQUFMLENBQVk5SyxXQUFaLENBQ3JCLGFBRHFCLEVBRXJCZ00sVUFGcUIsRUFFVDtBQUNWN0gsb0JBQVlnSCxTQURGO0FBRVZyTixnQkFBUSxDQUZFO0FBR1Y4QixjQUFNLE1BSEk7QUFJVnVNLDBCQUFrQixNQUpSO0FBS1ZDLHFCQUFhLE1BTEg7QUFNVkMsbUJBQVcsTUFORDtBQU9WeE0scUJBQWEsT0FQSDtBQVFWQyxxQkFBYTtBQVJILE9BRlMsQ0FBdkI7QUFjQWtNLG1CQUFhLEVBQWI7QUFDQUMsYUFBTyxDQUNMLGNBREssRUFFTCxpQkFGSyxFQUdMLFNBSEssRUFJTCxTQUpLLEVBS0wsY0FMSyxDQUFQLENBcEN5QixDQTJDekI7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY0QsSUFBZCxFQUFvQjtBQUNsQixZQUFJN1EsS0FBSzhRLENBQUwsQ0FBSixFQUFhRixXQUFXRSxDQUFYLElBQWdCOVEsS0FBSzhRLENBQUwsQ0FBaEI7QUFDZDs7QUFFRDFPLFVBQUl1RyxnQkFBSixpQkFBNkIsS0FBSytHLE1BQUwsQ0FBWTlLLFdBQVosQ0FDM0IsbUJBRDJCLEVBRTNCZ00sVUFGMkIsRUFFZjtBQUNWN0gsb0JBQVlnSCxTQURGO0FBRVZFLG9CQUFZN04sSUFBSTZOLFVBRk47QUFHVkosZUFBTyxDQUhHO0FBSVZDLHlCQUFpQixDQUpQO0FBS1ZvQiw0QkFBb0IsTUFMVjtBQU1WQyw0QkFBb0IsTUFOVjtBQU9WQywwQkFBa0IsTUFQUjtBQVFWQyxvQkFBWSxNQVJGO0FBU1Y1TSxxQkFBYSxPQVRIO0FBVVZDLHFCQUFhO0FBVkgsT0FGZSxDQUE3Qjs7QUFnQkEsV0FBSyxJQUFJb00sQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUk3USxLQUFLOFEsQ0FBTCxDQUFKLEVBQWFGLFdBQVdFLENBQVgsSUFBZ0I5USxLQUFLOFEsQ0FBTCxDQUFoQjtBQUNkOztBQUVEMU8sVUFBSWtQLGdCQUFKLGlCQUE2QixLQUFLNUIsTUFBTCxDQUFZOUssV0FBWixDQUMzQixtQkFEMkIsRUFDTixFQURNLEVBQ0Y7QUFDdkIrRCwwQkFBa0J2RyxJQUFJdUcsZ0JBREM7QUFFdkJJLG9CQUFZZ0gsU0FGVztBQUd2QkYsZUFBTyxDQUhnQjtBQUl2QnBMLHFCQUFhLE9BSlU7QUFLdkJDLHFCQUFhO0FBTFUsT0FERSxDQUE3QixFQXpFeUIsQ0FtRnpCOztBQUNBLGFBQU87QUFDTHRDLGFBQUtBO0FBREEsT0FBUDtBQUdELEtBdkZEO0FBQUE7O0FBcEtvQixDOzs7Ozs7Ozs7OztBQ0Z0QjVELE9BQU8yTyxNQUFQLENBQWM7QUFBQ29FLG1CQUFnQixNQUFJQSxlQUFyQjtBQUFxQ0MsWUFBUyxNQUFJQSxRQUFsRDtBQUEyREMsaUJBQWMsTUFBSUEsYUFBN0U7QUFBMkY3SixpQkFBYyxNQUFJQTtBQUE3RyxDQUFkO0FBQTJJLElBQUl5RixLQUFKO0FBQVU3TyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUMyTyxRQUFNek8sQ0FBTixFQUFRO0FBQUN5TyxZQUFNek8sQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUl1QyxLQUFKO0FBQVUzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdUMsWUFBTXZDLENBQU47QUFBUTs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7QUFBK0QsSUFBSThTLFdBQUo7QUFBZ0JsVCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNnVCxjQUFZOVMsQ0FBWixFQUFjO0FBQUM4UyxrQkFBWTlTLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSTRPLElBQUo7QUFBU2hQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM0TyxXQUFLNU8sQ0FBTDtBQUFPOztBQUFuQixDQUE3QixFQUFrRCxDQUFsRDtBQUFxRCxJQUFJNk8sT0FBSjtBQUFZalAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGFBQVIsQ0FBYixFQUFvQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzZPLGNBQVE3TyxDQUFSO0FBQVU7O0FBQXRCLENBQXBDLEVBQTRELENBQTVEOztBQVMxZixNQUFNMlMsZUFBTixDQUFzQjtBQUMzQjNELGNBQWFqSCxJQUFiLEVBQW1CSCxPQUFuQixFQUE0QjtBQUMxQixRQUFJbUwsUUFBSjs7QUFDQSxZQUFRaEwsS0FBS3FILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRTJELG1CQUFXLElBQUlGLGFBQUosQ0FBa0I5SyxJQUFsQixFQUF3QkgsT0FBeEIsQ0FBWDtBQUZKOztBQUtBLFdBQU9tTCxRQUFQO0FBQ0Q7O0FBVDBCOztBQVl0QixNQUFNSCxRQUFOLENBQWU7QUFDcEI1RCxjQUFhakgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsU0FBS0csSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS0gsT0FBTCxHQUFlQSxPQUFmO0FBQ0Q7O0FBRUQsU0FBT29MLE9BQVAsQ0FBZ0JqTCxJQUFoQixFQUFzQkgsT0FBdEIsRUFBK0I7QUFDN0IsWUFBUUcsS0FBS3FILElBQWI7QUFDRSxXQUFLLE9BQUw7QUFDRSxlQUFPLElBQUl5RCxhQUFKLENBQWtCOUssSUFBbEIsRUFBd0JILE9BQXhCLENBQVA7O0FBQ0Y7QUFDRSxjQUFNLElBQUkrSCxLQUFKLENBQVUsbUJBQVYsQ0FBTjtBQUpKO0FBTUQ7O0FBRURzRCxhQUFZO0FBQ1YsV0FBTyxLQUFLbEwsSUFBWjtBQUNEOztBQUVEbUwsYUFBWTtBQUNWLFdBQU8sS0FBS25MLElBQUwsQ0FBVTFFLElBQWpCO0FBQ0Q7O0FBRUQ4UCxnQkFBZTtBQUNiLFdBQU8sS0FBS3ZMLE9BQVo7QUFDRDs7QUFFRHdMLHFCQUNFQyxLQUFLLENBQU85RCxXQUFXNUwsVUFBVSxDQUFFLENBQTlCLEVBQWdDNkwsVUFBVXZKLEtBQUssQ0FBRSxDQUFqRCw4QkFBc0QsQ0FBRSxDQUF4RCxDQURQLEVBRUU7QUFDQSxTQUFLcUosTUFBTCxHQUFjK0QsRUFBZDtBQUNEO0FBRUQ7Ozs7Ozs7Ozs7O0FBU001UCxTQUFOLENBQWU2UCxZQUFZLEVBQTNCO0FBQUEsb0NBQStCO0FBQzdCLFVBQUkxTCxVQUFVLEtBQUt1TCxXQUFMLEVBQWQsQ0FENkIsQ0FHN0I7O0FBQ0F2TCxjQUFRa0ksT0FBUixDQUFnQkMsSUFBaEIsQ0FBcUI7QUFDbkJuTyxjQUFNLE1BRGE7QUFFbkIyQixlQUFPO0FBRlksT0FBckI7QUFLQSxVQUFJZ1EsVUFBVSxFQUFkOztBQUNBLFdBQUssSUFBSUMsQ0FBVCxJQUFjNUwsUUFBUWtJLE9BQXRCLEVBQStCLENBQzlCOztBQUVELFVBQUlBLFVBQVUsRUFBZDs7QUFFQSxXQUFLLElBQUkwRCxDQUFULElBQWM1TCxRQUFRa0ksT0FBdEIsRUFBK0I7QUFDN0J5RCxnQkFBUUMsRUFBRTVSLElBQVYsSUFBa0I7QUFDaEIyQixpQkFBT2lRLEVBQUVqUSxLQURPO0FBRWhCa1EsaUJBQU8sT0FBT0QsRUFBRUMsS0FBVCxLQUFtQixXQUFuQixHQUFpQ0QsRUFBRUMsS0FBbkMsR0FBMkMsQ0FGbEM7QUFHaEJ6RCxpQkFBTztBQUhTLFNBQWxCO0FBS0FGLGdCQUFRQyxJQUFSLENBQ0U7QUFDRW5PLGdCQUFNNFIsRUFBRTVSLElBRFY7QUFFRXNPLGdCQUFNdEIsS0FBS0MsUUFBUW9CLFFBQVIsQ0FBaUJ1RCxFQUFFalEsS0FBbkIsQ0FBTDtBQUZSLFNBREY7QUFNRDs7QUFFRCxvQkFBTSxLQUFLK0wsTUFBTCxDQUNKLENBQU8zTCxNQUFQLEVBQWU2RixPQUFmLDhCQUEyQjtBQUN6QixhQUFLLElBQUlnSyxDQUFULElBQWMxRCxPQUFkLEVBQXVCO0FBQ3JCO0FBQ0EsY0FBSTRELElBQUlILFFBQVFDLEVBQUU1UixJQUFWLENBQVI7O0FBQ0EsY0FBSThSLEVBQUVELEtBQU4sRUFBYTtBQUNYLGdCQUFJQyxFQUFFMUQsS0FBRixJQUFXMEQsRUFBRUQsS0FBakIsRUFBd0I7QUFDdEI7QUFDRDtBQUNGOztBQUVELGNBQUlELEVBQUV0RCxJQUFGLENBQU92TSxNQUFQLENBQUosRUFBb0I7QUFDbEI7QUFDQStQLGNBQUUxRCxLQUFGLEdBRmtCLENBSWxCOztBQUNBLGdCQUFJLE9BQU9zRCxVQUFVRSxFQUFFNVIsSUFBWixDQUFQLEtBQTZCLFdBQWpDLEVBQThDO0FBQzVDLDRCQUFNMFIsVUFBVUUsRUFBRTVSLElBQVosRUFBa0IrQixNQUFsQixFQUEwQjZGLE9BQTFCLENBQU47QUFDRDs7QUFDRDtBQUNEO0FBQ0Y7QUFDRixPQXJCRCxDQURJLENBQU4sRUE3QjZCLENBcUQ3Qjs7QUFDQSxhQUFPK0osT0FBUDtBQUNELEtBdkREO0FBQUE7O0FBMUNvQjs7QUFvR2YsTUFBTVYsYUFBTixTQUE0QkQsUUFBNUIsQ0FBcUM7QUFDMUM1RCxjQUFhakgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTUcsSUFBTixFQUFZSCxPQUFaO0FBRUEsUUFBSXZFLE9BQU8sS0FBSzZQLFFBQUwsRUFBWDtBQUVBLFNBQUs3RCxLQUFMLEdBQWEsSUFBSTlNLEtBQUosQ0FBVWMsSUFBVixDQUFiO0FBQ0EsU0FBSytQLGtCQUFMLENBQXdCLENBQU83RCxRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQsVUFBSTVMLE1BQU8saUJBQWdCbUUsS0FBSzBILEtBQU0sRUFBdEM7QUFDQSxVQUFJak0sb0JBQVksS0FBSzZMLEtBQUwsQ0FBV0ssY0FBWCxDQUEwQjlMLEdBQTFCLEVBQStCMkwsUUFBL0IsRUFBMEN0SixDQUFELElBQU87QUFBRSxjQUFNQSxDQUFOO0FBQVMsT0FBM0QsQ0FBWixDQUFKO0FBQ0EsYUFBT3pDLEdBQVA7QUFDRCxLQUp1QixDQUF4QjtBQUtEOztBQVp5Qzs7QUFtQnJDLE1BQU13RixhQUFOLFNBQTRCNEosUUFBNUIsQ0FBcUM7QUFDMUM1RCxjQUFhakgsSUFBYixFQUFtQkgsT0FBbkIsRUFBNEI7QUFDMUIsVUFBTUcsSUFBTixFQUFZSCxPQUFaLEVBRDBCLENBRzFCOztBQUNBLFNBQUt3TCxrQkFBTCxDQUF3QixDQUFPN0QsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBQ25ELFVBQUltRSxNQUFKO0FBQ0FBLDZCQUFlYixZQUFZYyxPQUFaLENBQW9CN0wsS0FBSzhMLEdBQXpCLENBQWYsRUFGbUQsQ0FJbkQ7O0FBQ0EsVUFBSWhNLEtBQUs4TCxPQUFPOUwsRUFBUCxDQUFVRSxLQUFLK0wsUUFBZixDQUFUO0FBQ0EsVUFBSTNMLGFBQWFOLEdBQUdNLFVBQUgsQ0FBY0osS0FBS0ksVUFBbkIsQ0FBakI7QUFFQSxVQUFJcUIsVUFBVTtBQUNabUssZ0JBQVFBLE1BREk7QUFFWnhMLG9CQUFZQSxVQUZBO0FBR1oyTCxrQkFBVWpNO0FBSEUsT0FBZDtBQU1BLFVBQUkwSSxNQUFNcEksV0FBV0MsSUFBWCxFQUFWLENBZG1ELENBZ0JuRDs7QUFDQW1JLFVBQUl3RCxhQUFKLENBQWtCLGlCQUFsQixFQUFxQyxJQUFyQyxFQWpCbUQsQ0FtQm5EOztBQUNBLFVBQUk7QUFDRiw2QkFBYXhELElBQUl5RCxPQUFKLEVBQWIsR0FBNEI7QUFDMUIsY0FBSXRTLG9CQUFZNk8sSUFBSTBELElBQUosRUFBWixDQUFKO0FBQ0Esd0JBQU0xRSxTQUFTN04sR0FBVCxFQUFjOEgsT0FBZCxDQUFOO0FBQ0Q7O0FBQUE7QUFDRixPQUxELFNBS1U7QUFDUjtBQUNBLHNCQUFNK0csSUFBSWpDLEtBQUosRUFBTjtBQUNEO0FBQ0YsS0E3QnVCLENBQXhCO0FBOEJEOztBQW5DeUMsQzs7Ozs7Ozs7Ozs7QUM1STVDMU8sT0FBTzJPLE1BQVAsQ0FBYztBQUFDeE8sV0FBUSxNQUFJd0k7QUFBYixDQUFkO0FBQTRDLElBQUlULGVBQUo7QUFBb0JsSSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNnSSxrQkFBZ0I5SCxDQUFoQixFQUFrQjtBQUFDOEgsc0JBQWdCOUgsQ0FBaEI7QUFBa0I7O0FBQXRDLENBQXRDLEVBQThFLENBQTlFO0FBQWlGLElBQUlHLE9BQUo7QUFBWVAsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHVCQUFSLENBQWIsRUFBOEM7QUFBQ0ssVUFBUUgsQ0FBUixFQUFVO0FBQUNHLGNBQVFILENBQVI7QUFBVTs7QUFBdEIsQ0FBOUMsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSWtVLFFBQUo7QUFBYXRVLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxNQUFSLENBQWIsRUFBNkI7QUFBQ29VLFdBQVNsVSxDQUFULEVBQVc7QUFBQ2tVLGVBQVNsVSxDQUFUO0FBQVc7O0FBQXhCLENBQTdCLEVBQXVELENBQXZEO0FBQTBELElBQUltVSxRQUFKO0FBQWF2VSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDbVUsZUFBU25VLENBQVQ7QUFBVzs7QUFBdkIsQ0FBckMsRUFBOEQsQ0FBOUQ7O0FBVzNTLE1BQU11SSxjQUFOLENBQXFCO0FBQzVCSyxNQUFOLENBQVliLElBQVo7QUFBQSxvQ0FBa0I7QUFDaEIsV0FBS3FNLEtBQUwsaUJBQW1CdE0sZ0JBQWdCSSxHQUFoQixDQUFvQkgsSUFBcEIsRUFBMEIsT0FBMUIsQ0FBbkI7QUFDQSxXQUFLc00sUUFBTCxpQkFBc0J2TSxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixFQUEwQixVQUExQixDQUF0QjtBQUNELEtBSEQ7QUFBQTs7QUFLTTJCLFVBQU4sQ0FBZ0I0SyxNQUFoQjtBQUFBLG9DQUF3QjtBQUN0QixVQUFJQyx3QkFBZ0IsS0FBS0gsS0FBTCxDQUFXbEYsT0FBWCxDQUFtQjtBQUNyQ3ZGLGFBQUsySztBQURnQyxPQUFuQixFQUVqQjtBQUNEdE0sb0JBQVk7QUFDVixxQkFBVztBQUREO0FBRFgsT0FGaUIsQ0FBaEIsQ0FBSjtBQU9BLFVBQUl3TSxjQUFjRCxRQUFRRSxPQUExQixDQVJzQixDQVV0QjtBQUNBO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFVBQUlDLGFBQWEsRUFBakI7O0FBRUEsV0FBSyxJQUFJQyxVQUFULElBQXVCSCxXQUF2QixFQUFvQztBQUNsQyxZQUFJSSxjQUFjLENBQWxCOztBQUVBLGFBQUssSUFBSWpELFNBQVQsSUFBc0JnRCxVQUF0QixFQUFrQztBQUNoQyxjQUFJSix3QkFBZ0IsS0FBS0YsUUFBTCxDQUFjbkYsT0FBZCxDQUFzQjtBQUN4Q3ZGLGlCQUFLZ0k7QUFEbUMsV0FBdEIsRUFFakI7QUFDRDNKLHdCQUFZO0FBQ1YsdUJBQVM7QUFEQztBQURYLFdBRmlCLENBQWhCLENBQUo7QUFPQSxjQUFJNk0sYUFBYU4sUUFBUXRELEtBQXpCLENBUmdDLENBVWhDOztBQUNBLGVBQUssSUFBSUEsS0FBVCxJQUFrQjRELFVBQWxCLEVBQThCO0FBQzVCRCwyQkFBZTNELE1BQU14SCxRQUFyQjtBQUNEO0FBQ0Y7O0FBRURpTCxtQkFBVzNFLElBQVgsQ0FBZ0I2RSxXQUFoQjtBQUNELE9BdENxQixDQXdDdEI7OztBQUNBLFVBQUluTCxXQUFXcUwsS0FBS0MsR0FBTCxDQUFTQyxLQUFULENBQWUsSUFBZixFQUFxQk4sVUFBckIsQ0FBZjtBQUVBLGFBQU9qTCxRQUFQO0FBQ0QsS0E1Q0Q7QUFBQTtBQThDQTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFxQk1YLFVBQU4sQ0FBZ0I3SCxRQUFoQixFQUEwQnVILEtBQTFCLEVBQWlDQyxTQUFTLElBQTFDLEVBQWdEQyxTQUFTLElBQXpEO0FBQUEsb0NBQStEO0FBQzdEO0FBQ0EsVUFBSThFLFNBQVNyTixRQUFRaUksSUFBUixDQUFhO0FBQ3hCbkgsa0JBQVVBO0FBRGMsT0FBYixFQUVWZ1UsS0FGVSxHQUVGckksR0FGRSxDQUVHNU0sQ0FBRCxJQUFPQSxFQUFFNkIsZ0JBRlgsQ0FBYixDQUY2RCxDQU03RDs7QUFDQSxVQUFJbUIsU0FBUyxFQUFiO0FBQ0FBLGFBQU93RixLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQVl6RixPQUFPa1MsWUFBUCxHQUFzQnpNLE1BQXRCO0FBQ1osVUFBSUMsTUFBSixFQUFZMUYsT0FBT21TLFlBQVAsR0FBc0J6TSxNQUF0QjtBQUVaLFVBQUlsRixvQkFBWSxLQUFLNFEsS0FBTCxDQUFXZ0IsVUFBWCxDQUNkcFMsTUFEYyxFQUNOO0FBQ05xUyxlQUFPO0FBQ0w3SCxrQkFBUTtBQUNOOEgsbUJBQU85SDtBQUREO0FBREg7QUFERCxPQURNLENBQVosQ0FBSixDQVo2RCxDQXNCN0Q7O0FBQ0EsYUFBT0EsTUFBUDtBQUNELEtBeEJEO0FBQUE7QUEwQkE7Ozs7Ozs7Ozs7QUFRTXpFLFlBQU4sQ0FBa0JQLEtBQWxCLEVBQXlCQyxTQUFTLElBQWxDLEVBQXdDQyxTQUFTLElBQWpEO0FBQUEsb0NBQXVEO0FBQ3JEO0FBQ0EsVUFBSTFGLFNBQVMsRUFBYjtBQUNBQSxhQUFPd0YsS0FBUCxHQUFlQSxLQUFmO0FBQ0EsVUFBSUMsTUFBSixFQUFZekYsT0FBT2tTLFlBQVAsR0FBc0J6TSxNQUF0QjtBQUNaLFVBQUlDLE1BQUosRUFBWTFGLE9BQU9tUyxZQUFQLEdBQXNCek0sTUFBdEI7QUFFWixVQUFJbEYsb0JBQVksS0FBSzRRLEtBQUwsQ0FBV2dCLFVBQVgsQ0FDZHBTLE1BRGMsRUFDTjtBQUNOdUgsY0FBTTtBQUNKaUQsa0JBQVE7QUFESjtBQURBLE9BRE0sQ0FBWixDQUFKO0FBT0QsS0FkRDtBQUFBO0FBZ0JBOzs7Ozs7Ozs7Ozs7Ozs7O0FBY00rSCxjQUFOLENBQW9CaE0sSUFBcEIsRUFBMEJnTCxPQUExQjtBQUFBLG9DQUFtQztBQUNqQzs7Ozs7Ozs7QUFRQSxVQUFJN0MsTUFBTSxDQUFDO0FBQ1Q4RCxlQUFPLE1BREU7QUFFVEMsaUJBQVNsTSxLQUFLbU0sUUFGTDtBQUdUbkIsaUJBQVM7QUFDUG9CLGlCQUFPO0FBREEsU0FIQTtBQU1UcFMsZUFBTztBQUNMMlIsd0JBQWMzTCxLQUFLMkwsWUFEZDtBQUVMQyx3QkFBYzVMLEtBQUs0TDtBQUZkO0FBTkUsT0FBRCxFQVdWO0FBQ0VLLGVBQU9qTSxLQUFLcU0sV0FEZDtBQUVFSCxpQkFBU2xNLEtBQUsyTCxZQUZoQjtBQUdFWCxpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUVwUyxlQUFPO0FBQ0xtUyxvQkFBVW5NLEtBQUttTSxRQURWO0FBRUxQLHdCQUFjNUwsS0FBSzRMO0FBRmQ7QUFOVCxPQVhVLEVBc0JWO0FBQ0VLLGVBQU9qTSxLQUFLc00sV0FEZDtBQUVFSixpQkFBU2xNLEtBQUs0TCxZQUZoQjtBQUdFWixpQkFBUztBQUNQb0IsaUJBQU87QUFEQSxTQUhYO0FBTUVwUyxlQUFPO0FBQ0xtUyxvQkFBVW5NLEtBQUttTSxRQURWO0FBRUxSLHdCQUFjM0wsS0FBSzJMO0FBRmQ7QUFOVCxPQXRCVSxDQUFWO0FBbUNBLFVBQUlZLFFBQVEsRUFBWjs7QUFFQSxXQUFLLElBQUlDLENBQVQsSUFBY3JFLEdBQWQsRUFBbUI7QUFDakJvRSxjQUFNL0YsSUFBTixDQUFXO0FBQ1RpRyxvQ0FBa0IsS0FBSzVCLEtBQUwsQ0FBVzlMLFNBQVgsQ0FDaEIsQ0FBQztBQUNDMk4sb0JBQVFDLE9BQU9DLE1BQVAsQ0FBY0osRUFBRXhTLEtBQWhCLEVBQXVCO0FBQzdCaUYscUJBQU9lLEtBQUtmO0FBRGlCLGFBQXZCO0FBRFQsV0FBRCxFQUtBO0FBQ0U0TixzQkFBVUYsT0FBT0MsTUFBUCxDQUFjSixFQUFFeEIsT0FBaEIsRUFBeUJBLE9BQXpCO0FBRFosV0FMQSxFQVFBO0FBQ0U4QixtQkFBTztBQUNMMU0sbUJBQUs7QUFEQTtBQURULFdBUkEsQ0FEZ0IsRUFlaEJ0QixPQWZnQixFQUFsQixDQURTO0FBaUJUaU8saUJBQU9QO0FBakJFLFNBQVg7QUFtQkQ7O0FBRUQsYUFBT0QsS0FBUDtBQUNELEtBckVEO0FBQUEsR0F6SWtDLENBZ05sQztBQUNBOzs7QUFDTTNKLGVBQU4sQ0FBcUJrQixHQUFyQjtBQUFBLG9DQUEwQjtBQUN4QixVQUFJOUQsSUFBSixDQUR3QixDQUV4Qjs7QUFDQSxVQUFJLE9BQU84RCxHQUFQLEtBQWUsUUFBbkIsRUFBNkI7QUFDM0IsWUFBSWtKLE1BQU0sSUFBSUMsTUFBSixDQUFZLEdBQUVuSixHQUFJLEdBQWxCLENBQVY7QUFDQSxZQUFJa0QsTUFBTSxLQUFLNkQsS0FBTCxDQUFXaE0sSUFBWCxDQUFnQixFQUFoQixFQUFvQjtBQUM1Qkosc0JBQVk7QUFDVlEsbUJBQU8sQ0FERztBQUVWME0sMEJBQWMsQ0FGSjtBQUdWQywwQkFBYztBQUhKO0FBRGdCLFNBQXBCLENBQVY7O0FBUUEsZUFBTyxDQUFQLEVBQVU7QUFDUixjQUFJO0FBQ0Y1TCxpQ0FBYWdILElBQUkwRCxJQUFKLEVBQWI7QUFDQSxnQkFBSXdDLHNCQUFjbE4sS0FBS0ksR0FBTCxDQUFTK00sV0FBVCxHQUF1QkQsS0FBdkIsQ0FBNkJGLEdBQTdCLENBQWQsQ0FBSjs7QUFDQSxnQkFBSUUsS0FBSixFQUFXO0FBQ1Q7QUFDRDtBQUNGLFdBTkQsQ0FNRSxPQUFPeFEsQ0FBUCxFQUFVO0FBQ1Y7QUFDQXNLLGdCQUFJakMsS0FBSjtBQUNBLG1CQUFPakIsR0FBUDtBQUNEO0FBQ0Y7O0FBQ0RrRCxZQUFJakMsS0FBSjtBQUNELE9BeEJELE1Bd0JPO0FBQ0wvRSxlQUFPOEQsR0FBUDtBQUNEOztBQUVELFVBQUlzSixhQUFhLEVBQWpCO0FBQ0EsVUFBSXBOLEtBQUtmLEtBQVQsRUFBZ0JtTyxXQUFXNUcsSUFBWCxDQUFnQnhHLEtBQUtmLEtBQXJCO0FBQ2hCLFVBQUllLEtBQUsyTCxZQUFULEVBQXVCeUIsV0FBVzVHLElBQVgsQ0FBZ0J4RyxLQUFLMkwsWUFBckI7QUFDdkIsVUFBSTNMLEtBQUs0TCxZQUFULEVBQXVCd0IsV0FBVzVHLElBQVgsQ0FBZ0J4RyxLQUFLNEwsWUFBckI7QUFDdkIsYUFBT3dCLFdBQVc5SixJQUFYLENBQWdCLEdBQWhCLENBQVA7QUFDRCxLQXBDRDtBQUFBOztBQXNDTTNDLGtCQUFOLENBQXdCaUgsU0FBeEIsRUFBbUM1SCxJQUFuQztBQUFBLG9DQUF5QztBQUN2QztBQUNBLFVBQUlxTixZQUFhbEIsUUFBRCxJQUFjQSxhQUFhLFFBQWIsR0FBd0IsT0FBeEIsR0FBa0NBLFFBQWhFLENBRnVDLENBSXZDOzs7QUFDQSxVQUFJL0QsWUFBWSxJQUFoQjtBQUNBLFVBQUlnRixhQUFhLEVBQWpCLENBTnVDLENBUXZDO0FBQ0E7O0FBQ0EsVUFBSXBOLEtBQUtmLEtBQVQsRUFBZ0JtTyxXQUFXNUcsSUFBWCxDQUFnQnhHLEtBQUtmLEtBQXJCO0FBQ2hCLFVBQUllLEtBQUsyTCxZQUFULEVBQXVCeUIsV0FBVzVHLElBQVgsQ0FBZ0J4RyxLQUFLMkwsWUFBckI7QUFDdkIsVUFBSTNMLEtBQUs0TCxZQUFULEVBQXVCd0IsV0FBVzVHLElBQVgsQ0FBZ0J4RyxLQUFLNEwsWUFBckIsRUFaZ0IsQ0FjdkM7O0FBQ0EsVUFBSTBCLGFBQUo7O0FBQ0EsY0FBUXROLEtBQUttTSxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VtQiwwQkFBZ0IsQ0FBaEI7QUFDQTs7QUFDRixhQUFLLFFBQUw7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7O0FBQ0Y7QUFDRUEsMEJBQWdCLENBQWhCO0FBQ0E7QUFUSixPQWhCdUMsQ0E0QnZDOzs7QUFDQSxVQUFJcEYsT0FBTyxFQUFYOztBQUNBLGNBQVFsSSxLQUFLbU0sUUFBYjtBQUNFLGFBQUssS0FBTDtBQUNFakUsZUFBSzFCLElBQUwsQ0FBVTtBQUNSbk4saUJBQUssQ0FERztBQUVSOE8saUJBQUs7QUFGRyxXQUFWLEVBR0c7QUFDRDlPLGlCQUFLLENBREo7QUFFRDhPLGlCQUFLO0FBRkosV0FISDtBQU9BOztBQUNGLGFBQUssUUFBTDtBQUNFRCxlQUFLMUIsSUFBTCxDQUFVO0FBQ1JuTixpQkFBSyxDQURHO0FBRVI4TyxpQkFBSztBQUZHLFdBQVYsRUFHRztBQUNEOU8saUJBQUssQ0FESjtBQUVEOE8saUJBQUs7QUFGSixXQUhIO0FBT0E7QUFsQkosT0E5QnVDLENBbUR2Qzs7O0FBQ0EsVUFBSW9GLGNBQWMsSUFBbEI7O0FBQ0EsY0FBUXZOLEtBQUttTSxRQUFiO0FBQ0UsYUFBSyxLQUFMO0FBQ0VvQix3QkFBYyxJQUFkO0FBQ0E7O0FBQ0YsYUFBSyxRQUFMO0FBQ0VBLHdCQUFjLEdBQWQ7QUFDQTtBQU5KLE9BckR1QyxDQThEdkM7QUFDQTtBQUNBOzs7QUFFQSxVQUFJaEIsc0JBQWMsS0FBS1AsWUFBTCxDQUFrQmhNLElBQWxCLEVBQXdCO0FBQ3hDOEgsb0JBQVk7QUFENEIsT0FBeEIsQ0FBZCxDQUFKLENBbEV1QyxDQXNFdkM7QUFFQTs7QUFDQXlFLGNBQVFBLE1BQU1sSixHQUFOLENBQ0xtSyxJQUFELElBQVU7QUFDUkEsYUFBS1QsS0FBTCxDQUFXYixPQUFYLEdBQXFCbUIsVUFBVUcsS0FBS1QsS0FBTCxDQUFXYixPQUFyQixDQUFyQjtBQUNBc0IsYUFBS2YsVUFBTCxHQUFrQmUsS0FBS2YsVUFBTCxDQUFnQnBKLEdBQWhCLENBQ2ZvSyxTQUFELElBQWU7QUFDYkEsb0JBQVVyQixLQUFWLEdBQWtCaUIsVUFBVUksVUFBVXJCLEtBQXBCLENBQWxCO0FBQ0EsaUJBQU9xQixTQUFQO0FBQ0QsU0FKZSxDQUFsQjtBQU1BLGVBQU9ELElBQVA7QUFDRCxPQVZLLENBQVIsQ0F6RXVDLENBc0Z2Qzs7QUFDQSxVQUFJRSxnQkFDRm5CLE1BQU1sSixHQUFOLENBQ0dtSyxJQUFELElBQ0Usa0NBQ0QsbUJBREMsR0FFRCxpRUFGQyxHQUdELFdBQVVBLEtBQUtULEtBQUwsQ0FBV2QsS0FBTSxXQUgxQixHQUlELFFBSkMsR0FLRnVCLEtBQUtmLFVBQUwsQ0FBZ0JwSixHQUFoQixDQUNHb0ssU0FBRCxJQUFlO0FBQ2IsWUFBSUQsS0FBS1QsS0FBTCxDQUFXYixPQUFYLEtBQXVCdUIsVUFBVXJCLEtBQXJDLEVBQTRDO0FBQzFDLGlCQUFRLDZCQUE0QnFCLFVBQVUzRixVQUFXLDBFQUF5RTJGLFVBQVVyQixLQUFNLHdCQUFsSjtBQUNELFNBRkQsTUFFTztBQUNMLGlCQUFRLDZCQUE0QnFCLFVBQVUzRixVQUFXLGtFQUFpRTJGLFVBQVVyQixLQUFNLGVBQTFJO0FBQ0Q7QUFDRixPQVBILEVBUUU5SSxJQVJGLENBUU8sRUFSUCxDQUxFLEdBY0YsUUFkRSxHQWVGLFFBakJGLEVBa0JFQSxJQWxCRixDQWtCTyxFQWxCUCxDQURGO0FBcUJBLFVBQUlxSyxvQkFBcUI7OztNQUd2QkQsYUFBYztLQUhoQixDQTVHdUMsQ0FrSHZDOztBQUNBLFVBQUk3VixPQUFPO0FBQ1RpUSxvQkFBWU0sU0FESDtBQUVUeEgsb0JBQVlnSCxTQUZIO0FBR1R2UCxjQUFPLEdBQUUrVSxXQUFXOUosSUFBWCxDQUFnQixHQUFoQixDQUFxQixJQUFHK0osVUFBVXJOLEtBQUttTSxRQUFmLENBQXlCLElBQUduTSxLQUFLM0gsSUFBSyxJQUFHMkgsS0FBSzROLFFBQVMsRUFIL0U7QUFJVEMsNEJBQW9CRixpQkFKWDtBQUtUN0UsbUJBQVc5SSxLQUFLOE4sV0FBTCxHQUFtQixHQUxyQjtBQU1UQyxzQkFBY1gsV0FBVzlKLElBQVgsQ0FBZ0IsR0FBaEIsQ0FOTDtBQU9UMEssaUJBQVNoTyxLQUFLaU8sWUFQTDtBQVFUQyxpQkFBU2xPLEtBQUttTyxXQUFMLEdBQW1CLElBUm5CO0FBUXlCO0FBQ2xDbEssZ0JBQVFqRSxLQUFLaUUsTUFUSjtBQVVUbUsseUJBQWlCZCxhQVZSO0FBV1RwRixjQUFNQSxJQVhHO0FBWVRtRyxzQkFBY2Q7QUFaTCxPQUFYO0FBZUFaLGFBQU9DLE1BQVAsQ0FBYy9VLElBQWQsRUFBb0JtSSxLQUFLTSxJQUFMLENBQVVDLFdBQTlCO0FBRUEsYUFBTzFJLElBQVA7QUFDRCxLQXJJRDtBQUFBLEdBeFBrQyxDQStYbEM7OztBQUNNZ04sa0JBQU4sQ0FBd0J5SixHQUF4QixFQUE2QnRPLElBQTdCO0FBQUEsb0NBQW1DO0FBQ2pDLFlBQU11TyxXQUFXLEVBQWpCO0FBQ0EsWUFBTUMsY0FBYyxHQUFwQjtBQUVBLFVBQUl6SyxRQUFRLEVBQVosQ0FKaUMsQ0FLakM7O0FBQ0FBLGNBQVFuTCxLQUFLNEosS0FBTCxDQUFXNUosS0FBS0MsU0FBTCxDQUFleVYsSUFBSXRPLEtBQUttTSxRQUFULENBQWYsQ0FBWCxDQUFSLENBTmlDLENBUWpDOztBQUNBLFlBQU1zQyxZQUFZLElBQWxCOztBQUNBLFdBQUssSUFBSXBHLElBQUksQ0FBYixFQUFnQkEsSUFBSXJJLEtBQUtpRSxNQUFMLENBQVlxRSxNQUFoQyxFQUF3Q0QsR0FBeEMsRUFBNkM7QUFDM0N0RSxjQUFNMEssYUFBYXBHLElBQUksQ0FBakIsQ0FBTixJQUE2QnJJLEtBQUtpRSxNQUFMLENBQVlvRSxDQUFaLENBQTdCO0FBQ0QsT0FaZ0MsQ0FjakM7OztBQUNBdEUsWUFBTSxNQUFOLElBQWdCL0QsS0FBS00sSUFBTCxDQUFVeUQsS0FBVixDQUFnQjJLLFFBQWhDO0FBQ0EzSyxZQUFNLE1BQU4sSUFBZ0I2RyxTQUFTK0QsT0FBVCxDQUFrQixHQUFELGNBQVMsS0FBSy9MLGFBQUwsQ0FBbUI1QyxJQUFuQixDQUFULENBQWtDLElBQUdBLEtBQUttTSxRQUFTLElBQUduTSxLQUFLM0gsSUFBSyxFQUFqRixFQUFvRm1XLFdBQXBGLENBQWhCO0FBQ0F6SyxZQUFNLE1BQU4sSUFBZ0IvRCxLQUFLbU8sV0FBckI7QUFDQXBLLFlBQU0sTUFBTixJQUFnQi9ELEtBQUttTyxXQUFyQjtBQUNBcEssWUFBTSxNQUFOLElBQWdCL0QsS0FBS0ksR0FBTCxDQUFTK00sV0FBVCxHQUF1QjFKLEtBQXZCLENBQTZCLENBQUM4SyxRQUE5QixDQUFoQjtBQUNBeEssWUFBTSxJQUFOLElBQWMvRCxLQUFLOE4sV0FBbkI7QUFDQS9KLFlBQU0sZ0JBQU4sSUFBMEIvRCxLQUFLNE4sUUFBL0I7QUFFQSxhQUFPN0osS0FBUDtBQUNELEtBeEJEO0FBQUE7O0FBaFlrQyxDOzs7Ozs7Ozs7OztBQ1hwQzFOLE9BQU8yTyxNQUFQLENBQWM7QUFBQ3hPLFdBQVEsTUFBSW9ZO0FBQWIsQ0FBZDs7QUFBZSxNQUFNQSxTQUFOLENBQWdCO0FBQzdCLFNBQU9wTSxLQUFQLENBQWM5RixDQUFkLEVBQWlCO0FBQ2YsUUFBSXpDLE1BQU0sRUFBVjs7QUFFQSxRQUFJeUMsYUFBYTBKLEtBQWpCLEVBQXdCO0FBQ3RCbk0sVUFBSTRVLE9BQUosR0FBY25TLEVBQUVtUyxPQUFoQjtBQUNBNVUsVUFBSTVCLElBQUosR0FBV3FFLEVBQUVyRSxJQUFiO0FBQ0E0QixVQUFJNlUsUUFBSixHQUFlcFMsRUFBRW9TLFFBQWpCO0FBQ0E3VSxVQUFJOFUsVUFBSixHQUFpQnJTLEVBQUVxUyxVQUFuQjtBQUNBOVUsVUFBSStVLFlBQUosR0FBbUJ0UyxFQUFFc1MsWUFBckI7QUFDQS9VLFVBQUlnVixLQUFKLEdBQVl2UyxFQUFFdVMsS0FBZDtBQUNELEtBUEQsTUFPTztBQUNMaFYsWUFBTXlDLENBQU47QUFDRDs7QUFFRCxXQUFPekMsR0FBUDtBQUNEOztBQWhCNEIsQzs7Ozs7Ozs7Ozs7QUNBL0I1RCxPQUFPMk8sTUFBUCxDQUFjO0FBQUN6RyxtQkFBZ0IsTUFBSUE7QUFBckIsQ0FBZDtBQUFxRCxJQUFJZ0wsV0FBSjtBQUFnQmxULE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxTQUFSLENBQWIsRUFBZ0M7QUFBQ2dULGNBQVk5UyxDQUFaLEVBQWM7QUFBQzhTLGtCQUFZOVMsQ0FBWjtBQUFjOztBQUE5QixDQUFoQyxFQUFnRSxDQUFoRTs7QUFFOUQsTUFBTThILGVBQU4sQ0FBc0I7QUFDM0IsU0FBYUksR0FBYixDQUFrQkgsSUFBbEIsRUFBd0JJLFVBQXhCO0FBQUEsb0NBQW9DO0FBQ2xDLFVBQUl3TCx1QkFBZWIsWUFBWWMsT0FBWixDQUFvQjdMLEtBQUs4TCxHQUF6QixDQUFmLENBQUo7QUFDQSxVQUFJaE0sS0FBSzhMLE9BQU85TCxFQUFQLENBQVVFLEtBQUsrTCxRQUFmLENBQVQ7QUFDQSxhQUFPak0sR0FBR00sVUFBSCxDQUFjQSxVQUFkLENBQVA7QUFDRCxLQUpEO0FBQUE7O0FBRDJCLEM7Ozs7Ozs7Ozs7O0FDRjdCdkksT0FBTzJPLE1BQVAsQ0FBYztBQUFDeE8sV0FBUSxNQUFJd0M7QUFBYixDQUFkO0FBQW1DLElBQUk4TSxLQUFKO0FBQVV6UCxPQUFPQyxLQUFQLENBQWFDLFFBQVEsT0FBUixDQUFiLEVBQThCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDcVAsWUFBTXJQLENBQU47QUFBUTs7QUFBcEIsQ0FBOUIsRUFBb0QsQ0FBcEQ7QUFBdUQsSUFBSXlZLE1BQUo7QUFBVzdZLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN5WSxhQUFPelksQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDs7QUFHaEcsTUFBTXVDLEtBQU4sQ0FBWTtBQUN6QnlNLGNBQWFwSCxPQUFiLEVBQXNCO0FBQ3BCO0FBQ0EsU0FBSzhRLElBQUwsR0FBWXJKLE1BQU1zSixVQUFOLENBQWlCL1EsT0FBakIsQ0FBWixDQUZvQixDQUlwQjs7QUFDQSxRQUFJZ1IsZUFBZTtBQUFDQywwQkFBb0I7QUFBckIsS0FBbkI7QUFDQTNDLFdBQU9DLE1BQVAsQ0FBY3lDLFlBQWQsRUFBNEJoUixPQUE1QjtBQUNBLFNBQUtrUixTQUFMLEdBQWlCekosTUFBTXNKLFVBQU4sQ0FBaUJDLFlBQWpCLENBQWpCO0FBQ0Q7O0FBRUQsU0FBT0csVUFBUCxDQUFtQkMsSUFBbkIsRUFBeUI7QUFDdkIsV0FBT1AsT0FBT08sSUFBUCxFQUFhQyxNQUFiLEdBQXNCeFMsU0FBdEIsQ0FBZ0MsQ0FBaEMsRUFBbUMsRUFBbkMsRUFBdUN5UyxPQUF2QyxDQUErQyxHQUEvQyxFQUFvRCxHQUFwRCxDQUFQO0FBQ0Q7QUFFRDs7Ozs7O0FBSUEzVixRQUFPSyxHQUFQLEVBQVk7QUFDVjtBQUNBO0FBQ0EsV0FBTyxLQUFLdVYsTUFBTCxHQUNKQyxJQURJLENBRUZDLEdBQUQsSUFBUztBQUNQLGFBQU8sSUFBSTdJLE9BQUosQ0FDTCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQTJJLFlBQUk5VixLQUFKLENBQVVLLEdBQVYsRUFBZSxDQUFDcUMsQ0FBRCxFQUFJekMsR0FBSixLQUFZO0FBQ3pCO0FBQ0E2VixjQUFJQyxPQUFKOztBQUNBLGNBQUlyVCxDQUFKLEVBQU87QUFDTHlLLG1CQUFPekssQ0FBUDtBQUNELFdBRkQsTUFFT3dLLFFBQVFqTixHQUFSO0FBQ1IsU0FORDtBQU9ELE9BVkksQ0FBUDtBQVlELEtBZkUsRUFpQkpxTixLQWpCSSxDQWlCRzVLLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQW5CSSxDQUFQO0FBb0JEOztBQUVLc1QsY0FBTixDQUFvQjNWLEdBQXBCO0FBQUEsb0NBQXlCO0FBQ3ZCLFVBQUlKLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxhQUFPSixJQUFJZ1csUUFBWDtBQUNELEtBSEQ7QUFBQTtBQUtBOzs7Ozs7OztBQU1NeFQsYUFBTixDQUFtQnlKLEtBQW5CLEVBQTBCck8sT0FBTyxFQUFqQyxFQUFxQ3FZLFVBQVUsRUFBL0M7QUFBQSxvQ0FBbUQ7QUFDakQ7QUFDQTtBQUVBLFVBQUk3VixNQUFPLGVBQWM2TCxLQUFNLEdBQS9CO0FBRUEsVUFBSTdDLE1BQU0sSUFBSThNLEdBQUosRUFBVjs7QUFDQSxXQUFLLElBQUl4SCxDQUFULElBQWNnRSxPQUFPakUsSUFBUCxDQUFZN1EsSUFBWixDQUFkLEVBQWlDO0FBQy9CLFlBQUlBLEtBQUs4USxDQUFMLE1BQVksSUFBaEIsRUFBc0I7QUFDcEJ0RixjQUFJOEUsR0FBSixDQUFRUSxDQUFSLEVBQVcsTUFBWDtBQUNELFNBRkQsTUFFTyxJQUFJOVEsS0FBSzhRLENBQUwsRUFBUWxELFdBQVIsQ0FBb0JwTixJQUFwQixLQUE2QixNQUFqQyxFQUF5QztBQUM5QztBQUNBZ0wsY0FBSThFLEdBQUosQ0FBUVEsQ0FBUixFQUFZLElBQUczUCxNQUFNd1csVUFBTixDQUFpQjNYLEtBQUs4USxDQUFMLENBQWpCLENBQTBCLEdBQXpDO0FBQ0QsU0FITSxNQUdBO0FBQ0x0RixjQUFJOEUsR0FBSixDQUFRUSxDQUFSLEVBQVksR0FBRTdDLE1BQU1zSyxNQUFOLENBQWF2WSxLQUFLOFEsQ0FBTCxDQUFiLENBQXNCLEVBQXBDO0FBQ0Q7QUFDRjs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBY2dFLE9BQU9qRSxJQUFQLENBQVl3SCxPQUFaLENBQWQsRUFBb0M7QUFDbEM3TSxZQUFJOEUsR0FBSixDQUFRUSxDQUFSLEVBQVd1SCxRQUFRdkgsQ0FBUixNQUFlLElBQWYsR0FBc0IsTUFBdEIsR0FBK0J1SCxRQUFRdkgsQ0FBUixDQUExQztBQUNEOztBQUVEdE8sYUFBUSxLQUFJLENBQUMsR0FBR2dKLElBQUlxRixJQUFKLEVBQUosRUFBZ0JwRixJQUFoQixDQUFxQixHQUFyQixDQUEwQixLQUF0QztBQUVBakosYUFBUSxXQUFVLENBQUMsR0FBR2dKLElBQUlnTixNQUFKLEVBQUosRUFBa0IvTSxJQUFsQixDQUF1QixHQUF2QixDQUE0QixLQUE5QztBQUVBLFVBQUlySixvQkFBWSxLQUFLRCxLQUFMLENBQVdLLEdBQVgsQ0FBWixDQUFKO0FBQ0EsYUFBT0osSUFBSWdXLFFBQVg7QUFDRCxLQTNCRDtBQUFBO0FBNkJBOzs7Ozs7Ozs7QUFPTXhJLGFBQU4sQ0FBbUJ2QixLQUFuQixFQUEwQnpNLE1BQTFCLEVBQWtDNUIsSUFBbEMsRUFBd0NxWSxPQUF4QztBQUFBLG9DQUFpRDtBQUMvQyxVQUFJN1YsTUFBTyxVQUFTNkwsS0FBTSxPQUExQjtBQUVBLFVBQUlvSyxVQUFVLEVBQWQ7O0FBQ0EsV0FBSyxJQUFJM0gsQ0FBVCxJQUFjZ0UsT0FBT2pFLElBQVAsQ0FBWTdRLElBQVosQ0FBZCxFQUFpQztBQUMvQnlZLGdCQUFROUosSUFBUixDQUFjLEdBQUVtQyxDQUFFLElBQUc3QyxNQUFNc0ssTUFBTixDQUFhdlksS0FBSzhRLENBQUwsQ0FBYixDQUFzQixFQUEzQztBQUNEOztBQUNELFdBQUssSUFBSUEsQ0FBVCxJQUFjZ0UsT0FBT2pFLElBQVAsQ0FBWXdILE9BQVosQ0FBZCxFQUFvQztBQUNsQ0ksZ0JBQVE5SixJQUFSLENBQWMsR0FBRW1DLENBQUUsSUFBR3VILFFBQVF2SCxDQUFSLENBQVcsRUFBaEM7QUFDRDs7QUFDRHRPLGFBQU9pVyxRQUFRaE4sSUFBUixDQUFhLEdBQWIsQ0FBUDtBQUVBakosYUFBUSxVQUFTWixNQUFPLEdBQXhCO0FBRUEsVUFBSVEsb0JBQVksS0FBS0QsS0FBTCxDQUFXSyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9KLEdBQVA7QUFDRCxLQWhCRDtBQUFBLEdBM0Z5QixDQTZHekI7OztBQUNNc1csWUFBTixDQUFrQmxXLEdBQWxCO0FBQUEsb0NBQXVCO0FBQ3JCLFVBQUltVyxXQUFXLEtBQUtyQixJQUFwQjtBQUNBLFdBQUtBLElBQUwsR0FBWSxLQUFLSSxTQUFqQjs7QUFDQSxVQUFJO0FBQ0YsWUFBSXRWLG9CQUFZLEtBQUtELEtBQUwsQ0FBV0ssR0FBWCxDQUFaLENBQUo7QUFDQSxlQUFPSixHQUFQO0FBQ0QsT0FIRCxTQUdVO0FBQ1IsYUFBS2tWLElBQUwsR0FBWXFCLFFBQVo7QUFDRDtBQUNGLEtBVEQ7QUFBQTs7QUFXTUMsa0JBQU47QUFBQSxvQ0FBMEI7QUFDeEIsb0JBQU0sS0FBS3pXLEtBQUwsQ0FBWSxvQkFBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNMFcsUUFBTjtBQUFBLG9DQUFnQjtBQUNkLG9CQUFNLEtBQUsxVyxLQUFMLENBQVksU0FBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNMlcsVUFBTjtBQUFBLG9DQUFrQjtBQUNoQixvQkFBTSxLQUFLM1csS0FBTCxDQUFZLFdBQVosQ0FBTjtBQUNELEtBRkQ7QUFBQTs7QUFJQW1NLGlCQUFnQjlMLEdBQWhCLEVBQXFCMkwsV0FBWTVMLE1BQUQsSUFBWSxDQUFFLENBQTlDLEVBQWdENkwsVUFBV3ZKLENBQUQsSUFBTyxDQUFFLENBQW5FLEVBQXFFO0FBQ25FLFdBQU8sS0FBS2tULE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUk3SSxPQUFKLENBQ0wsQ0FBT0MsT0FBUCxFQUFnQkMsTUFBaEIsOEJBQTJCO0FBQ3pCO0FBQ0EySSxZQUFJOVYsS0FBSixDQUFVSyxHQUFWLEVBQ0d1VyxFQURILENBQ00sUUFETixFQUVLeFcsTUFBRCxJQUFZO0FBQ1YwVixjQUFJZSxLQUFKO0FBQ0E3SyxtQkFBUzVMLE1BQVQ7QUFDQTBWLGNBQUlnQixNQUFKO0FBQ0QsU0FOTCxFQU9HRixFQVBILENBT00sT0FQTixFQU9nQmxVLENBQUQsSUFBTztBQUNsQnVKLGtCQUFRdkosQ0FBUjtBQUNELFNBVEgsRUFVR2tVLEVBVkgsQ0FVTSxLQVZOLEVBVWEsTUFBTTtBQUNmZCxjQUFJQyxPQUFKO0FBQ0E3STtBQUNELFNBYkg7QUFjRCxPQWhCRCxDQURLLENBQVA7QUFtQkQsS0F0QkUsRUF3QkpJLEtBeEJJLENBd0JHNUssQ0FBRCxJQUFPO0FBQ1osWUFBTUEsQ0FBTjtBQUNELEtBMUJJLENBQVA7QUEyQkQ7O0FBRURrVCxXQUFVO0FBQ1IsV0FBTyxJQUFJM0ksT0FBSixDQUNMLENBQUNDLE9BQUQsRUFBVUMsTUFBVixLQUFxQjtBQUNuQjtBQUNBLFdBQUtnSSxJQUFMLENBQVU0QixhQUFWLENBQXdCLENBQUNyVSxDQUFELEVBQUlvVCxHQUFKLEtBQVk7QUFDbEMsWUFBSXBULENBQUosRUFBTztBQUNMeUssaUJBQU96SyxDQUFQO0FBQ0QsU0FGRCxNQUVPO0FBQ0x3SyxrQkFBUTRJLEdBQVI7QUFDRDtBQUNGLE9BTkQ7QUFPRCxLQVZJLEVBWUp4SSxLQVpJLENBYUY1SyxDQUFELElBQU87QUFDTCxZQUFNQSxDQUFOO0FBQ0QsS0FmRSxDQUFQO0FBaUJEOztBQXJMd0IsQzs7Ozs7Ozs7Ozs7QUNIM0JyRyxPQUFPMk8sTUFBUCxDQUFjO0FBQUN4TyxXQUFRLE1BQUk4SztBQUFiLENBQWQ7O0FBQWUsTUFBTUEsTUFBTixDQUFhO0FBQzFCbUUsY0FBYTFDLFVBQWIsRUFBeUI7QUFDdkIsU0FBS0EsVUFBTCxHQUFrQkEsVUFBbEI7QUFDQSxTQUFLUSxhQUFMLEdBQXFCLElBQXJCO0FBQ0EsU0FBS00sUUFBTCxHQUFnQixJQUFoQjtBQUNBLFNBQUtTLFdBQUwsR0FBbUIsSUFBbkI7QUFDQSxTQUFLbUMsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLakQsV0FBTCxHQUFtQixDQUFuQjtBQUNEOztBQUVLc0IsUUFBTixDQUFjaEIsR0FBZDtBQUFBLG9DQUFtQjtBQUNqQjtBQUNBLFVBQUksS0FBSzJDLEtBQUwsR0FBYSxLQUFLMUQsVUFBbEIsS0FBaUMsQ0FBckMsRUFBd0M7QUFDdEMsWUFBSSxLQUFLUSxhQUFULEVBQXdCO0FBQ3RCLHdCQUFNLEtBQUtBLGFBQUwsQ0FBbUIsS0FBS0MsV0FBeEIsQ0FBTjtBQUNEO0FBQ0Y7O0FBQ0QsVUFBSSxLQUFLSyxRQUFULEVBQW1CO0FBQ2pCLHNCQUFNLEtBQUtBLFFBQUwsQ0FBY0MsR0FBZCxDQUFOO0FBQ0Q7O0FBQ0QsV0FBSzJDLEtBQUwsR0FWaUIsQ0FXakI7O0FBQ0EsVUFBSSxLQUFLQSxLQUFMLEdBQWEsS0FBSzFELFVBQWxCLEtBQWlDLENBQXJDLEVBQXdDO0FBQ3RDLGFBQUtnQyxLQUFMO0FBQ0EsYUFBS3ZCLFdBQUw7QUFDRDtBQUNGLEtBaEJEO0FBQUE7O0FBaUJBdUIsVUFBUztBQUNQLFFBQUksS0FBS1QsV0FBVCxFQUFzQjtBQUNwQixXQUFLQSxXQUFMLENBQWlCLEtBQUtkLFdBQXRCO0FBQ0Q7QUFDRjs7QUEvQnlCLEM7Ozs7Ozs7Ozs7O0FDQTVCbk4sT0FBTzJPLE1BQVAsQ0FBYztBQUFDeE8sV0FBUSxNQUFJeUM7QUFBYixDQUFkO0FBQW9DLElBQUkyVixTQUFKO0FBQWN2WSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDbVksZ0JBQVVuWSxDQUFWO0FBQVk7O0FBQXhCLENBQWhDLEVBQTBELENBQTFEO0FBQTZELElBQUlZLE1BQUo7QUFBV2hCLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ2MsU0FBT1osQ0FBUCxFQUFTO0FBQUNZLGFBQU9aLENBQVA7QUFBUzs7QUFBcEIsQ0FBdEMsRUFBNEQsQ0FBNUQ7O0FBRzNHLE1BQU13QyxNQUFOLENBQWE7QUFDMUJ3TSxnQkFBZTtBQUNiLFNBQUtyTCxNQUFMLEdBQWMsRUFBZDtBQUNBLFNBQUsyUCxTQUFMLEdBQWlCLEVBQWpCO0FBQ0EsU0FBS2lILFFBQUwsR0FBZ0IsSUFBaEI7QUFDRDs7QUFFREMsa0JBQWlCO0FBQ2YsU0FBS0QsUUFBTCxHQUFnQixJQUFJRSxRQUFKLEVBQWhCO0FBQ0EsU0FBS25ILFNBQUwsQ0FBZXZELElBQWYsQ0FBb0IsS0FBS3dLLFFBQXpCO0FBQ0Q7O0FBRUtqWCxPQUFOLENBQWExQixPQUFPLEVBQXBCLEVBQXdCeVIsS0FBSywrQkFBWSxDQUFFLENBQWQsQ0FBN0I7QUFBQSxvQ0FBNkM7QUFDM0MsV0FBS21ILGFBQUw7QUFFQSxVQUFJRSxNQUFNLEVBQVY7O0FBRUEsVUFBSTtBQUNGLFlBQUlsWCxvQkFBWTZQLElBQVosQ0FBSjtBQUVBNkMsZUFBT0MsTUFBUCxDQUFjdUUsR0FBZCxFQUFtQjtBQUNqQnRMLGdCQUFNLFNBRFc7QUFFakI5TCxpQkFBTzFCLElBRlU7QUFHakIrWSxrQkFBUW5YO0FBSFMsU0FBbkI7QUFLRCxPQVJELENBUUUsT0FBT3lDLENBQVAsRUFBVTtBQUNWaVEsZUFBT0MsTUFBUCxDQUFjdUUsR0FBZCxFQUFtQjtBQUNqQnRMLGdCQUFNLE9BRFc7QUFFakI5TCxpQkFBTzFCLElBRlU7QUFHakIrWSxrQkFBUXhDLFVBQVVwTSxLQUFWLENBQWdCOUYsQ0FBaEI7QUFIUyxTQUFuQjtBQUtELE9BZEQsU0FjVTtBQUNSLFlBQUksS0FBS3NVLFFBQUwsQ0FBY0ssS0FBbEIsRUFBeUI7QUFDdkIxRSxpQkFBT0MsTUFBUCxDQUFjdUUsR0FBZCxFQUFtQjtBQUNqQkgsc0JBQVUsS0FBS0E7QUFERSxXQUFuQjtBQUdEOztBQUNELGFBQUs1VyxNQUFMLENBQVlvTSxJQUFaLENBQWlCMkssR0FBakI7QUFDRDtBQUNGLEtBM0JEO0FBQUE7O0FBNkJBbFEsV0FBVXFRLFNBQVYsRUFBcUI7QUFDbkIsU0FBS04sUUFBTCxDQUFjTyxPQUFkLENBQXNCRCxTQUF0QjtBQUNEOztBQUVEM1UsU0FBUTJVLFNBQVIsRUFBbUI7QUFDakIsU0FBS04sUUFBTCxDQUFjeFksS0FBZCxDQUFvQm9XLFVBQVVwTSxLQUFWLENBQWdCOE8sU0FBaEIsQ0FBcEI7QUFDRDs7QUFFREUsaUJBQWdCO0FBQ2QsUUFBSUMsV0FBVyxLQUFLMUgsU0FBTCxDQUFlbEwsSUFBZixDQUFvQm5DLEtBQUtBLEVBQUU4VSxZQUFGLEVBQXpCLENBQWY7QUFDQSxRQUFJRSxXQUFXLEtBQWY7O0FBQ0EsU0FBSyxJQUFJUCxHQUFULElBQWdCLEtBQUsvVyxNQUFyQixFQUE2QjtBQUMzQixVQUFJK1csSUFBSXRMLElBQUosS0FBYSxPQUFqQixFQUEwQjtBQUN4QjZMLG1CQUFXLElBQVg7QUFDQTtBQUNEO0FBQ0Y7O0FBQ0QsV0FBT0QsWUFBWUMsUUFBbkI7QUFDRDs7QUFFRHRULFlBQVc7QUFDVCxRQUFJLEtBQUtvVCxZQUFMLEVBQUosRUFBeUI7QUFDdkIsWUFBTSxJQUFJbmEsT0FBTytPLEtBQVgsQ0FBaUIsS0FBS2hNLE1BQXRCLENBQU47QUFDRDs7QUFDRCxXQUFPLEtBQUtBLE1BQVo7QUFDRDs7QUFsRXlCOztBQXFFNUIsTUFBTThXLFFBQU4sQ0FBZTtBQUNiekwsZ0JBQWU7QUFDYixTQUFLNEwsS0FBTCxHQUFhLENBQWI7QUFDQSxTQUFLTSxLQUFMLEdBQWE7QUFDWEosZUFBUztBQUNQRixlQUFPLENBREE7QUFFUE8saUJBQVM7QUFGRixPQURFO0FBS1hwWixhQUFPO0FBQ0w2WSxlQUFPLENBREY7QUFFTE8saUJBQVM7QUFGSjtBQUxJLEtBQWI7QUFVRDs7QUFFREwsVUFBU0QsU0FBVCxFQUFvQjtBQUNsQixRQUFJQSxTQUFKLEVBQWU7QUFDYixXQUFLSyxLQUFMLENBQVdKLE9BQVgsQ0FBbUJLLE9BQW5CLENBQTJCcEwsSUFBM0IsQ0FBZ0M4SyxTQUFoQztBQUNEOztBQUNELFNBQUtLLEtBQUwsQ0FBV0osT0FBWCxDQUFtQkYsS0FBbkI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBQ0Q3WSxRQUFPOFksU0FBUCxFQUFrQjtBQUNoQjtBQUNBLFFBQUlPLFlBQVksSUFBaEI7QUFDQSxRQUFJeEssUUFBUSxLQUFLc0ssS0FBTCxDQUFXblosS0FBWCxDQUFpQm9aLE9BQWpCLENBQXlCdEosTUFBckM7O0FBQ0EsUUFBSWpCLEtBQUosRUFBVztBQUNUd0ssa0JBQVksS0FBS0YsS0FBTCxDQUFXblosS0FBWCxDQUFpQm9aLE9BQWpCLENBQXlCdkssUUFBUSxDQUFqQyxDQUFaO0FBQ0QsS0FOZSxDQVFoQjs7O0FBQ0EsUUFBSXpPLEtBQUtDLFNBQUwsQ0FBZWdaLFNBQWYsTUFBOEJqWixLQUFLQyxTQUFMLENBQWV5WSxTQUFmLENBQWxDLEVBQTZEO0FBQzNELFVBQUlBLGFBQWFBLGNBQWMsRUFBM0IsSUFBaUNBLGNBQWMsRUFBbkQsRUFBdUQ7QUFDckQsYUFBS0ssS0FBTCxDQUFXblosS0FBWCxDQUFpQm9aLE9BQWpCLENBQXlCcEwsSUFBekIsQ0FBOEI4SyxTQUE5QjtBQUNEO0FBQ0Y7O0FBQ0QsU0FBS0ssS0FBTCxDQUFXblosS0FBWCxDQUFpQjZZLEtBQWpCO0FBQ0EsU0FBS0EsS0FBTDtBQUNEOztBQUVERyxpQkFBZ0I7QUFDZCxXQUFPLEtBQUtHLEtBQUwsQ0FBV25aLEtBQVgsQ0FBaUI2WSxLQUF4QjtBQUNEOztBQTFDWSxDOzs7Ozs7Ozs7OztBQ3hFZmhiLE9BQU8yTyxNQUFQLENBQWM7QUFBQ3hPLFdBQVEsTUFBSW9VO0FBQWIsQ0FBZDs7QUFBZSxNQUFNQSxRQUFOLENBQWU7QUFDNUIsU0FBTytELE9BQVAsQ0FBZ0JtRCxJQUFoQixFQUFzQkMsR0FBdEIsRUFBMkJDLFVBQTNCLEVBQXVDO0FBQ3JDLFFBQUlBLGVBQWVDLFNBQW5CLEVBQThCO0FBQUVELG1CQUFhLEVBQWI7QUFBaUI7O0FBQ2pELFFBQUlFLFlBQVlKLEtBQUtLLEtBQUwsQ0FBVyxFQUFYLENBQWhCO0FBQ0EsUUFBSTFMLFFBQVEsQ0FBWjtBQUNBLFFBQUkyTCxNQUFNLEVBQVY7O0FBQ0EsU0FBSyxJQUFJL0osSUFBSSxDQUFiLEVBQWdCQSxJQUFJNkosVUFBVTVKLE1BQTlCLEVBQXNDRCxHQUF0QyxFQUEyQztBQUN6QyxVQUFJZ0ssSUFBSWpDLE9BQU84QixVQUFVN0osQ0FBVixDQUFQLENBQVI7QUFDQSxVQUFJZ0ssRUFBRS9KLE1BQUYsR0FBVyxDQUFmLEVBQWtCN0IsUUFBbEIsS0FDS0EsU0FBUyxDQUFUOztBQUNMLFVBQUlBLFFBQVFzTCxHQUFaLEVBQWlCO0FBQ2YsZUFBT0ssTUFBTUosVUFBYjtBQUNEOztBQUNESSxhQUFPTixLQUFLUSxNQUFMLENBQVlqSyxDQUFaLENBQVA7QUFDRDs7QUFDRCxXQUFPeUosSUFBUDtBQUNEOztBQWhCMkIsQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCAocmVxLCByZXMsIG5leHQpID0+IHtcclxuLy8gICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbi8vICAgcmVzLmVuZChgSGVsbG8gd29ybGQgZnJvbTogJHtNZXRlb3IucmVsZWFzZX1gKTtcclxuLy8gfSk7XHJcblxyXG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xyXG5pbXBvcnQgdW5pcWlkIGZyb20gJ3VuaXFpZCc7XHJcblxyXG4vLyBSZXF1aXJlcyBtdWx0aXBhcnR5IFxyXG5pbXBvcnQgbXVsdGlwYXJ0eSBmcm9tICdjb25uZWN0LW11bHRpcGFydHknO1xyXG5pbXBvcnQge1xyXG4gIFVwbG9hZHNcclxufSBmcm9tICcuLi8uLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcyc7XHJcbmxldCBtdWx0aXBhcnR5TWlkZGxld2FyZSA9IG11bHRpcGFydHkoKTtcclxuXHJcbmNvbnN0IHJvdXRlID0gJy91cGxvYWQvaW1hZ2UnO1xyXG5cclxuLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCBmdWMudXBsb2FkRmlsZSApO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgbXVsdGlwYXJ0eU1pZGRsZXdhcmUpO1xyXG5XZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZShyb3V0ZSwgKHJlcSwgcmVzcCkgPT4ge1xyXG4gIC8vIGRvbid0IGZvcmdldCB0byBkZWxldGUgYWxsIHJlcS5maWxlcyB3aGVuIGRvbmVcclxuXHJcbiAgY29uc3QgcmVhZGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy5yZWFkRmlsZSk7XHJcbiAgY29uc3Qgd3JpdGVyID0gTWV0ZW9yLndyYXBBc3luYyhmcy53cml0ZUZpbGUpO1xyXG4gIGNvbnN0IHVwbG9hZElkID0gdW5pcWlkKCk7XHJcblxyXG4gIGZvciAobGV0IGZpbGUgb2YgcmVxLmZpbGVzLmZpbGUpIHtcclxuICAgIGNvbnN0IGRhdGEgPSByZWFkZXIoZmlsZS5wYXRoKTtcclxuICAgIC8vIOODleOCoeOCpOODq+WQjeOBrumHjeikh+OCkumBv+OBkeOCi+OBn+OCgeOAgeS4gOaEj+OBruODleOCoeOCpOODq+WQjeOCkuS9nOaIkOOBmeOCi1xyXG4gICAgLy8g5qW95aSp44Gu44OV44Kh44Kk44Or5ZCN5paH5a2X5pWw5Yi26ZmQMjDjgavlkIjjgo/jgZvjgotcclxuICAgIGxldCBmaWxlbmFtZSA9IGAke3VuaXFpZCgpfS5qcGdgXHJcblxyXG4gICAgLy8gc2V0IHRoZSBjb3JyZWN0IHBhdGggZm9yIHRoZSBmaWxlIG5vdCB0aGUgdGVtcG9yYXJ5IG9uZSBmcm9tIHRoZSBBUEk6XHJcbiAgICBsZXQgc2F2ZVBhdGggPSByZXEuYm9keS5pbWFnZWRpciArICcvJyArIGZpbGVuYW1lO1xyXG5cclxuICAgIC8vIGNvcHkgdGhlIGRhdGEgZnJvbSB0aGUgcmVxLmZpbGVzLmZpbGUucGF0aCBhbmQgcGFzdGUgaXQgdG8gZmlsZS5wYXRoXHJcblxyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ57WQ5p6c44KS6KiY6Yyy44GZ44KLXHJcbiAgICBsZXQgZG9jID0ge1xyXG4gICAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICAgIGNsaWVudEZpbGVOYW1lOiBmaWxlLm5hbWUsXHJcbiAgICAgIHVwbG9hZGVkRmlsZU5hbWU6IGZpbGVuYW1lXHJcbiAgICB9O1xyXG4gICAgXHJcbiAgICB0cnl7XHJcbiAgICAgIHdyaXRlcihzYXZlUGF0aCwgZGF0YSk7XHJcbiAgICB9XHJcbiAgICBjYXRjaChlcnIpe1xyXG4gICAgICBkb2MuZXJyb3IgPSBlcnI7XHJcbiAgICB9XHJcbiAgICBVcGxvYWRzLmluc2VydChkb2MpO1xyXG5cclxuICAgIGRlbGV0ZSBmaWxlO1xyXG5cclxuICB9O1xyXG4gIHJlc3Aud3JpdGVIZWFkKDIwMCk7XHJcbiAgcmVzcC5lbmQoSlNPTi5zdHJpbmdpZnkoe1xyXG4gICAgdXBsb2FkSWQ6IHVwbG9hZElkLFxyXG4gICAgc2F2ZURpcjogcmVxLmJvZHkuaW1hZ2VkaXJcclxuICB9KSk7XHJcblxyXG59KTsiLCJpbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0bydcclxuXHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCBSZXBvcnQgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBHcm91cCxcclxuICBHcm91cEZhY3RvcnlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzJ1xyXG5pbXBvcnQge1xyXG4gIEZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlbWlnJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5taWdyYXRlYF0gKGNvbmZpZykge1xyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIC8vIHNldHVwIGdyb3VwXHJcbiAgICAvL1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgRmlsdGVyKGNvbmZpZy5zcmNGaWx0ZXJJZClcclxuICAgIC8vIGxldCBwbHVnID0gZ3JvdXAuZ2V0UGx1ZygpO1xyXG5cclxuICAgIC8vIGNoZWNraW5nIGNvbm5lY3Rpb25cclxuICAgIC8vXHJcblxyXG4gICAgbGV0IHRlc3RRdWVyeSA9ICdTSE9XIERBVEFCQVNFUydcclxuXHJcbiAgICBsZXQgZHN0RGIgPSBuZXcgTXlTUUwoY29uZmlnLmRzdC5jcmVkKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnQ29ubmVjdCB0byBEZXN0aW5hdGlvbicsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBhd2FpdCBkc3REYi5xdWVyeSh0ZXN0UXVlcnkpXHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcHJvY2VzcyBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICAvL1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZSgnU2VsZWN0IGxvb3AgaW4gc291cmNlJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICBtb2JpbGVOdWxsOiBhc3luYyAocmVjb3JkKSA9PiB7XHJcbiAgICAgICAgICAgIC8vIC8vIOWApOOCkuaVtOeQhlxyXG4gICAgICAgICAgICAvLyBmb3IgKGxldCBrZXkgb2YgT2JqZWN0LmtleXMocmVjb3JkKSkge1xyXG4gICAgICAgICAgICAvLyAgIGlmIChyZWNvcmRba2V5XSA9PT0gbnVsbCk7XHJcbiAgICAgICAgICAgIC8vICAgZWxzZSBpZiAocmVjb3JkW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgICAgIC8vICAgICAvLyDml6Xku5jjgpLlpInmj5tcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gTXlTUUwuZm9ybWF0RGF0ZShyZWNvcmRba2V5XSk7XHJcbiAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IGBcIiR7cmVjb3JkW2tleV19XCJgO1xyXG4gICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgLy8gfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyIOOBq+S/neWtmFxyXG5cclxuICAgICAgICAgICAgbGV0IHNxbCA9IGBcclxuXHJcbiAgICAgICAgICAgICAgICBJTlNFUlQgZHRiX2N1c3RvbWVyXHJcbiAgICAgICAgICAgICAgICAoIFxcYGN1c3RvbWVyX2lkXFxgLCBcXGBzdGF0dXNcXGAsIFxcYHNleFxcYCwgXFxgam9iXFxgLCBcXGBjb3VudHJ5X2lkXFxgLCBcXGBwcmVmXFxgLCBcXGBuYW1lMDFcXGAsIFxcYG5hbWUwMlxcYCwgXFxga2FuYTAxXFxgLCBcXGBrYW5hMDJcXGAsIFxcYGNvbXBhbnlfbmFtZVxcYCwgXFxgemlwMDFcXGAsIFxcYHppcDAyXFxgLCBcXGB6aXBjb2RlXFxgLCBcXGBhZGRyMDFcXGAsIFxcYGFkZHIwMlxcYCwgXFxgZW1haWxcXGAsIFxcYHRlbDAxXFxgLCBcXGB0ZWwwMlxcYCwgXFxgdGVsMDNcXGAsIFxcYGZheDAxXFxgLCBcXGBmYXgwMlxcYCwgXFxgZmF4MDNcXGAsIFxcYGJpcnRoXFxgLCBcXGBwYXNzd29yZFxcYCwgXFxgc2FsdFxcYCwgXFxgc2VjcmV0X2tleVxcYCwgXFxgZmlyc3RfYnV5X2RhdGVcXGAsIFxcYGxhc3RfYnV5X2RhdGVcXGAsIFxcYGJ1eV90aW1lc1xcYCwgXFxgYnV5X3RvdGFsXFxgLCBcXGBub3RlXFxgLCBcXGBjcmVhdGVfZGF0ZVxcYCwgXFxgdXBkYXRlX2RhdGVcXGAsIFxcYGRlbF9mbGdcXGAgKVxyXG5cclxuICAgICAgICAgICAgICAgIFZBTFVFUyggJHtyZWNvcmQuY3VzdG9tZXJfaWR9ICwgJHtyZWNvcmQuc3RhdHVzfSAsICR7cmVjb3JkLnNleH0gLCAke3JlY29yZC5qb2J9ICwgJHtyZWNvcmQuY291bnRyeV9pZH0gLCAke3JlY29yZC5wcmVmfSAsICR7cmVjb3JkLm5hbWUwMX0gLCAke3JlY29yZC5uYW1lMDJ9ICwgJHtyZWNvcmQua2FuYTAxfSAsICR7cmVjb3JkLmthbmEwMn0gLCAke3JlY29yZC5jb21wYW55X25hbWV9ICwgJHtyZWNvcmQuemlwMDF9ICwgJHtyZWNvcmQuemlwMDJ9ICwgJHtyZWNvcmQuemlwY29kZX0gLCAke3JlY29yZC5hZGRyMDF9ICwgJHtyZWNvcmQuYWRkcjAyfSAsICR7cmVjb3JkLmVtYWlsfSAsICR7cmVjb3JkLnRlbDAxfSAsICR7cmVjb3JkLnRlbDAyfSAsICR7cmVjb3JkLnRlbDAzfSAsICR7cmVjb3JkLmZheDAxfSAsICR7cmVjb3JkLmZheDAyfSAsICR7cmVjb3JkLmZheDAzfSAsICR7cmVjb3JkLmJpcnRofSAsICR7cmVjb3JkLnBhc3N3b3JkfSAsICR7cmVjb3JkLnNhbHR9ICwgJHtyZWNvcmQuc2VjcmV0X2tleX0gLCAke3JlY29yZC5maXJzdF9idXlfZGF0ZX0gLCAke3JlY29yZC5sYXN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmJ1eV90aW1lc30gLCAke3JlY29yZC5idXlfdG90YWx9ICwgJHtyZWNvcmQubm90ZX0gLCAke3JlY29yZC5jcmVhdGVfZGF0ZX0gLCAke3JlY29yZC51cGRhdGVfZGF0ZX0gLCAke3JlY29yZC5kZWxfZmxnfSApXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGBcclxuXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyJywge1xyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBzdGF0dXM6IHJlY29yZC5zdGF0dXMsXHJcbiAgICAgICAgICAgICAgICAgIHNleDogcmVjb3JkLnNleCxcclxuICAgICAgICAgICAgICAgICAgam9iOiByZWNvcmQuam9iLFxyXG4gICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgcHJlZjogcmVjb3JkLnByZWYsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDE6IHJlY29yZC5rYW5hMDEsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMTogcmVjb3JkLnppcDAxLFxyXG4gICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAxOiByZWNvcmQuYWRkcjAxLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgIGVtYWlsOiByZWNvcmQuZW1haWwsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgIHRlbDAzOiByZWNvcmQudGVsMDMsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgIGZheDAzOiByZWNvcmQuZmF4MDMsXHJcbiAgICAgICAgICAgICAgICAgIGJpcnRoOiByZWNvcmQuYmlydGgsXHJcbiAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiByZWNvcmQucGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICAgIHNhbHQ6IHJlY29yZC5zYWx0LFxyXG4gICAgICAgICAgICAgICAgICBzZWNyZXRfa2V5OiByZWNvcmQuc2VjcmV0X2tleSxcclxuICAgICAgICAgICAgICAgICAgZmlyc3RfYnV5X2RhdGU6IHJlY29yZC5maXJzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgbGFzdF9idXlfZGF0ZTogcmVjb3JkLmxhc3RfYnV5X2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGJ1eV90aW1lczogcmVjb3JkLmJ1eV90aW1lcyxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RvdGFsOiByZWNvcmQuYnV5X3RvdGFsLFxyXG4gICAgICAgICAgICAgICAgICBub3RlOiByZWNvcmQubm90ZSxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIGR0Yl9jdXN0b21lcl9hZGRyZXNzXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAnZHRiX2N1c3RvbWVyX2FkZHJlc3MnLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2FkZHJlc3NfaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOODoeODq+ODnuOCrOODl+ODqeOCsOOCpOODsyBwbGdfbWFpbG1hZ2FfY3VzdG9tZXJcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfbWFpbG1hZ2FfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGlkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBtYWlsbWFnYV9mbGc6IHJlY29yZC5tYWlsbWFnYV9mbGcsXHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiByZWNvcmQudXBkYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAvLyDjgq/jg7zjg53jg7PnmbrooYzvvIhFQ0NVQkUy44Gu44Od44Kk44Oz44OI6YKE5YWD77yJXHJcblxyXG4gICAgICAgICAgICBsZXQgY291cG9uQ2QgPSBjcnlwdG8ucmFuZG9tQnl0ZXMoOCkudG9TdHJpbmcoJ2Jhc2U2NCcpLnN1YnN0cmluZygwLCAxMSlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25OYW1lID0gYCR7cmVjb3JkLm5hbWUwMX0gJHtyZWNvcmQubmFtZTAyfSDmp5gg44GU5YSq5b6F44Kv44O844Od44OzIOS8muWToeeVquWPtzoke3JlY29yZC5jdXN0b21lcl9pZH1gXHJcblxyXG4gICAgICAgICAgICBsZXQgZGlzY291bnRQcmljZSA9IHJlY29yZC5wb2ludCArIDUwMFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAncGxnX2NvdXBvbicsIHtcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2lkOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fY2Q6IGNvdXBvbkNkLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdHlwZTogMywgLy8g5YWo5ZWG5ZOBXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9uYW1lOiBjb3Vwb25OYW1lLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF90eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25fdXNlX3RpbWU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9yZWxlYXNlOiAxLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9wcmljZTogZGlzY291bnRQcmljZSxcclxuICAgICAgICAgICAgICAgICAgZGlzY291bnRfcmF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgZW5hYmxlX2ZsYWc6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9tZW1iZXI6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9sb3dlcl9saW1pdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX2Zyb21fZGF0ZTogJzIwMTgtMDQtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfdG9fZGF0ZTogJzIwMTktMDUtMDIgMDA6MDA6MDAnLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiAwXHJcbiAgICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICB9XHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICBhc3luYyAnY3ViZW1pZy5zZXJ2ZXJDaGVjaycgKHByb2ZpbGUpIHtcclxuICAgIGxldCBkYiA9IG5ldyBNeVNRTChwcm9maWxlKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGRiLnF1ZXJ5KCdTSE9XIERBVEFCQVNFUycpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IHsgTW9uZ29Db2xsZWN0aW9uIH0gZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL21vbmdvJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuY29sbGVjdGlvbidcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZmluZGBdIChwbHVnLCBxdWVyeSA9IHt9LCBwcm9qZWN0aW9uID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5maW5kKHF1ZXJ5LCB7cHJvamVjdGlvbjogcHJvamVjdGlvbn0pLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH0sXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmFnZ3JlZ2F0ZWBdIChwbHVnLCBxdWVyeSA9IHt9KSB7XHJcbiAgICBsZXQgY29sbCA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgcGx1Zy5jb2xsZWN0aW9uKVxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGNvbGwuYWdncmVnYXRlKHF1ZXJ5KS50b0FycmF5KClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAnamxpbmUuaXRlbXMnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z44Kz44Os44Kv44K344On44Oz5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44G+44GZ44CCXHJcbiAgICogQHBhcmFtXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uc2V0SW1hZ2VgXSAocGx1ZywgdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtY29uLmluaXQocGx1ZylcclxuICAgIGxldCB1cGxvYWRlZCA9IGF3YWl0IGl0ZW1jb24uc2V0SW1hZ2UodXBsb2FkSWQsIG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICAgIHJldHVybiB1cGxvYWRlZFxyXG4gIH0sXHJcblxyXG4gIC8qKlxyXG4gICAqIOOCouOCpOODhuODoOaDheWgseODh+ODvOOCv+ODmeODvOOCueOBrueUu+WDj+eZu+mMsuOCkuWJiumZpOOBmeOCi++8iOeUu+WDj+iHquS9k+OBr+WJiumZpOOBl+OBquOBhO+8iVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LmNsZWFuSW1hZ2VgXSAocGx1ZywgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5jbGVhbkltYWdlKG1vZGVsLCBjbGFzczEsIGNsYXNzMilcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnXHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IHtcclxuICBDdWJlM0FwaVxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9jdWJlM2FwaSdcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdjdWJlJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWcqOW6q+abtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVTdG9ja2BdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpXHJcbiAgICBsZXQgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+WcqOW6q+OBruabtOaWsCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG5cclxuICAgICAgICAgICdVUERBVEUnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgYXdhaXQgYXBpLnVwZGF0ZVN0b2NrKGl0ZW0ubWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2NsYXNzX2lkLCBxdWFudGl0eSlcclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseeZu+mMsuOBqOabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYkl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IE1vbmdvREJGaWx0ZXIoY29uZmlnLml0ZW1zREIsIGNvbmZpZy5wcm9maWxlKVxyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKVxyXG4gICAgbGV0IGFwaSA9IG5ldyBDdWJlM0FwaSh0YXJnZXREQilcclxuXHJcbiAgICBsZXQgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdFQ0NVQkUz44G444Gu5ZWG5ZOB55m76YyyJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnSU5TRVJUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvblxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKVxyXG5cclxuICAgICAgICAgICAgICBsZXQgaW5zZXJ0UmVzID0gYXdhaXQgYXBpLnByb2R1Y3RDcmVhdGUoY3ViZUl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIC8vIGl0ZW0g44OH44O844K/44OZ44O844K544G444Gu55m76YyyXHJcbiAgICAgICAgICAgICAgYXdhaXQgY29sLnVwZGF0ZSh7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IGl0ZW0uX2lkXHJcbiAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgICAgICAgICAnbWFsbC5zaGFyYWt1U2hvcCc6IGluc2VydFJlcy5yZXNcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9KVxyXG5cclxuICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdFQ0NVQkUz5ZWG5ZOB5oOF5aCx44Gu5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnVVBEQVRFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvblxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKVxyXG5cclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdEltYWdlVXBkYXRlKGN1YmVJdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VXBkYXRlKGN1YmVJdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VGFnVXBkYXRlKGN1YmVJdGVtKVxyXG5cclxuICAgICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5KVxyXG5cclxuICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuXHJcbmxldCB0YWcgPSAndG9vbCdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udGVzdGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcblxyXG4gICAgY29uc3QgbmV3TG9jYWwgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7fSwgYXN5bmMgKGUpID0+IHtcclxuICAgICAgdGhyb3cgZVxyXG4gICAgfSlcclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODleOCo+ODq+OCv+ODvOODhuOCueODiCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gbmV3TG9jYWxcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcbmltcG9ydCBQYWNrZXQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3BhY2tldCdcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcblxyXG5pbXBvcnQgaWNvbnYgZnJvbSAnaWNvbnYtbGl0ZSdcclxuaW1wb3J0IGFyY2hpdmVyIGZyb20gJ2FyY2hpdmVyJ1xyXG5pbXBvcnQgY3N2IGZyb20gJ2NzdidcclxuaW1wb3J0IHsgUGFzc1Rocm91Z2gsIFRyYW5zZm9ybSB9IGZyb20gJ3N0cmVhbSdcclxuXHJcbmNvbnN0IHByZWZpeCA9ICdwYWNrZXQnXHJcbmNvbnN0IHRhZyA9ICd5YXVjdCdcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDjg6Tjg5Xjgqrjgq/lj5fms6jjg5XjgqHjgqTjg6tcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30ub3JkZXJgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICfjg6Tjg5Xjgqrjgq/lj5fms6gnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9vcmRlcmBcclxuICAgICAgICBjb25zdCByID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyTG9hZGZpbGV9YClcclxuICAgICAgICBjb25zdCB3ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbShgJHt3b3JrZGlyfS8ke2NvbmZpZy5vcmRlclNhdmVmaWxlfWApXHJcbiAgICAgICAgci5waXBlKGljb252LmRlY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtjb2x1bW5zOiB0cnVlfSkpXHJcbiAgICAgICAgICAucGlwZShjc3YudHJhbnNmb3JtKFxyXG4gICAgICAgICAgICBhc3luYyAocmVjb3JkLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgICAgIGxldCBlcnIgPSBudWxsXHJcbiAgICAgICAgICAgICAgLy8g566h55CG55Wq5Y+344KS572u44GN5o+b44GI44KLXHJcbiAgICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICAgIHJlY29yZFsn566h55CG55Wq5Y+3J10gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRNb2RlbENsYXNzKHJlY29yZFsn566h55CG55Wq5Y+3J10pXHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgZXJyID0gZVxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICBjYWxsYmFjayhlcnIsIHJlY29yZClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKSlcclxuICAgICAgICAgIC5waXBlKGNzdi5zdHJpbmdpZnkoe2hlYWRlcjogdHJ1ZX0pKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAucGlwZSh3KVxyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyDjg6Tjg5Xjgqrjgq/lh7rlk4Hjg5XjgqHjgqTjg6tcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJpdGBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODpOODleOCquOCr+WHuuWTgScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvLyDliJ3mnJ/ljJblh6bnkIZcclxuICAgICAgICAvL1xyXG5cclxuICAgICAgICBjb25zdCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vIOe5sOOCiui/lOOBl+WHpueQhuOCkuS7u+aEj+OBru+8iHBhY2tldFNpemXvvInjgafliIblibJcclxuICAgICAgICBjb25zdCBwYWNrZXQgPSBuZXcgUGFja2V0KGNvbmZpZy5wYWNrZXRTaXplKVxyXG5cclxuICAgICAgICAvLyDkvZzmpa3jg5Xjgqnjg6vjg4DjgpLkvZzmiJDjgZnjgotcclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcihjb25maWcud29ya2RpcilcclxuICAgICAgICB9IGNhdGNoIChlKSB7fVxyXG5cclxuICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgpLkvZzmiJDjgZfnlLvlg4/jg4fjg7zjgr/jgpLlj47pm4bjgZnjgovloLTmiYBcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L3dvcmtgXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUod29ya2RpcilcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcblxyXG4gICAgICAgIC8vIFpJUOODleOCoeOCpOODq+OCkuS/neWtmOOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHVwbG9hZGRpciA9IGAke2NvbmZpZy53b3JrZGlyfS91cGxvYWRgXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5yZW1vdmUodXBsb2FkZGlyKVxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIodXBsb2FkZGlyKVxyXG5cclxuICAgICAgICBsZXQgY2QgPSBudWxsIC8vIOODkeOCseODg+ODiOODleOCqeODq+ODgFxyXG4gICAgICAgIGxldCBmaWxlbmFtZSA9IG51bGwgLy8gY3N244OV44Kh44Kk44OrXHJcbiAgICAgICAgbGV0IG5hbWUgPSBudWxsIC8vIOODkeOCseODg+ODiOeVquWPt1xyXG5cclxuICAgICAgICAvLyBDU1bjg5XjgqPjg7zjg6vjg4njgpLlrprnvqnjgZfjgIHpoIbnlarjgpLnorrlrprjgZnjgotcclxuICAgICAgICBsZXQgZmllbGRzID0gWyfnrqHnkIbnlarlj7cnLCAn44Kr44OG44K044OqJywgJ+OCv+OCpOODiOODqycsICfoqqzmmI4nLCAn44K544OI44Ki5YaF5ZWG5ZOB5qSc57Si55So44Kt44O844Ov44O844OJJywgJ+mWi+Wni+S+oeagvCcsICfljbPmsbrkvqHmoLwnLCAn5YCk5LiL44GS5Lqk5riJJywgJ+WAi+aVsCcsICflhaXmnK3lgIvmlbDliLbpmZAnLCAn5pyf6ZaTJywgJ+e1guS6huaZgumWkycsICfllYblk4HnmbrpgIHlhYPjga7pg73pgZPlupznnIwnLCAn5ZWG5ZOB55m66YCB5YWD44Gu5biC5Yy655S65p2RJywgJ+mAgeaWmeiyoOaLhScsICfku6Pph5HlhYjmiZXjgYTjgIHlvozmiZXjgYQnLCAn6JC95pyt44OK44OT5rG65riI5pa55rOV6Kit5a6aJywgJ+WVhuWTgeOBrueKtuaFiycsICfllYblk4Hjga7nirbmhYvlgpnogIMnLCAn6L+U5ZOB44Gu5Y+v5ZCmJywgJ+i/lOWTgeOBruWPr+WQpuWCmeiAgycsICfnlLvlg48xJywgJ+eUu+WDjzHjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMicsICfnlLvlg48y44Kz44Oh44Oz44OIJywgJ+eUu+WDjzMnLCAn55S75YOPM+OCs+ODoeODs+ODiCcsICfnlLvlg480JywgJ+eUu+WDjzTjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNScsICfnlLvlg48144Kz44Oh44Oz44OIJywgJ+eUu+WDjzYnLCAn55S75YOPNuOCs+ODoeODs+ODiCcsICfnlLvlg483JywgJ+eUu+WDjzfjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOCcsICfnlLvlg48444Kz44Oh44Oz44OIJywgJ+eUu+WDjzknLCAn55S75YOPOeOCs+ODoeODs+ODiCcsICfnlLvlg48xMCcsICfnlLvlg48xMOOCs+ODoeODs+ODiCcsICfmnIDkvY7oqZXkvqEnLCAn5oKq6KmV5Ymy5ZCI5Yi26ZmQJywgJ+WFpeacreiAheiqjeiovOWItumZkCcsICfoh6rli5Xlu7bplbcnLCAn5pep5pyf57WC5LqGJywgJ+WVhuWTgeOBruiHquWLleWGjeWHuuWTgScsICfoh6rli5XlgKTkuIvjgZInLCAn5pyA5L2O6JC95pyt5L6h5qC8JywgJ+ODgeODo+ODquODhuOCo+ODvCcsICfms6jnm67jga7jgqrjg7zjgq/jgrfjg6fjg7MnLCAn5aSq5a2X44OG44Kt44K544OIJywgJ+iDjOaZr+iJsicsICfjgrnjg4jjgqLjg5vjg4Pjg4jjgqrjg7zjgq/jgrfjg6fjg7MnLCAn55uu56uL44Gh44Ki44Kk44Kz44OzJywgJ+i0iOetlOWTgeOCouOCpOOCs+ODsycsICdU44Od44Kk44Oz44OI44Kq44OX44K344On44OzJywgJ+OCouODleOCo+ODquOCqOOCpOODiOOCquODl+OCt+ODp+ODsycsICfojbfnianjga7lpKfjgY3jgZUnLCAn6I2354mp44Gu6YeN6YePJywgJ+OBr+OBk0JPT04nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMScsICfjgZ3jga7ku5bphY3pgIHmlrnms5Ux5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTHlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMicsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uy5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTLlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMycsICfjgZ3jga7ku5bphY3pgIHmlrnms5Uz5paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTPlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U05paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTTlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNScsICfjgZ3jga7ku5bphY3pgIHmlrnms5U15paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTXlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNicsICfjgZ3jga7ku5bphY3pgIHmlrnms5U25paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTblhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNycsICfjgZ3jga7ku5bphY3pgIHmlrnms5U35paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTflhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U45paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTjlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOScsICfjgZ3jga7ku5bphY3pgIHmlrnms5U55paZ6YeR6KGo44Oa44O844K444Oq44Oz44KvJywgJ+OBneOBruS7lumFjemAgeaWueazlTnlhajlm73kuIDlvovkvqHmoLwnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTAnLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTDmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMTDlhajlm73kuIDlvovkvqHmoLwnLCAn5rW35aSW55m66YCBJywgJ+mFjemAgeaWueazleODu+mAgeaWmeioreWumicsICfku6PlvJXmiYvmlbDmlpnoqK3lrponLCAn5raI6LK756iO6Kit5a6aJywgJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXVxyXG4gICAgICAgIGxldCBoZWFkZXIgPSBmaWVsZHMubWFwKHYgPT4gYFwiJHt2fVwiYCkuam9pbignLCcpICsgJ1xcbidcclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW6ZaL5aeL5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0U3RhcnQgPSBhc3luYyAocGFja2V0Q291bnQpID0+IHtcclxuICAgICAgICAgIG5hbWUgPSBwcmVmaXggKyAoJzAwMDAwJyArIHBhY2tldENvdW50KS5zbGljZSgtNSlcclxuICAgICAgICAgIGNkID0gYCR7d29ya2Rpcn0vJHtuYW1lfWBcclxuICAgICAgICAgIGZpbGVuYW1lID0gYCR7Y2R9LyR7Y29uZmlnLmNzdkZpbGVOYW1lfWBcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY2QpXHJcbiAgICAgICAgICAvLyBDU1bjg5XjgqHjgqTjg6vjgavjg5XjgqPjg7zjg6vjg4njgpLoqK3lrprjgZnjgotcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYXBwZW5kRmlsZShmaWxlbmFtZSwgaWNvbnYuZW5jb2RlKGhlYWRlciwgJ1NoaWZ0X0pJUycpKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI5YyW5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0ID0gYXN5bmMgKGFyZykgPT4ge1xyXG4gICAgICAgICAgbGV0IHlhdWN0ID0gYXJnLnlhdWN0XHJcbiAgICAgICAgICBsZXQgaXRlbSA9IGFyZy5pdGVtXHJcbiAgICAgICAgICAvLyBjc3bjg5XjgqHjgqTjg6vjgavjg6zjgrPjg7zjg4nvvIjllYblk4Hjg4bjg7Pjg5fjg6zjg7zjg4jvvInjgpLov73liqDjgZnjgotcclxuICAgICAgICAgIGxldCByZWNvcmQgPSBmaWVsZHMubWFwKHYgPT4geyByZXR1cm4geWF1Y3Rbdl0gPyBgXCIke3lhdWN0W3ZdfVwiYCA6ICdcIlwiJyB9KS5qb2luKCcsJykgKyAnXFxuJ1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUocmVjb3JkLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgICAvLyDnlLvlg4/jg5XjgqHjgqTjg6vjgpLjgrPjg5Tjg7xcclxuICAgICAgICAgIGZvciAobGV0IGltZyBvZiBpdGVtLmltYWdlcykge1xyXG4gICAgICAgICAgICBsZXQgaW1nU3JjID0gYCR7Y29uZmlnLmltYWdlZGlyfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIGxldCBpbWdUZ3QgPSBgJHtjZH0vJHtpbWd9YFxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIC8vIOWQjOOBmOODleOCoeOCpOODq+OBjOOBguOCi+WgtOWQiOOBr+OCs+ODlOODvOOBl+OBquOBhFxyXG4gICAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEuYWNjZXNzKGltZ1RndClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGZzRXh0cmEuY29weUZpbGUoaW1nU3JjLCBpbWdUZ3QpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODkeOCseODg+ODiOe1guS6huaZglxyXG4gICAgICAgIHBhY2tldC5vblBhY2tldEVuZCA9IGFzeW5jIChwYWNrZXRDb3VudCkgPT4ge1xyXG4gICAgICAgICAgY29uc3QgemlwID0gYXJjaGl2ZXIoJ3ppcCcpXHJcbiAgICAgICAgICBjb25zdCB6aXBuYW1lID0gYCR7dXBsb2FkZGlyfS8ke25hbWV9LnppcGBcclxuICAgICAgICAgIGNvbnN0IG91dHB1dCA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oemlwbmFtZSlcclxuICAgICAgICAgIHppcC5waXBlKG91dHB1dClcclxuICAgICAgICAgIHppcC5kaXJlY3RvcnkoY2QsIGZhbHNlKVxyXG4gICAgICAgICAgemlwLmZpbmFsaXplKClcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIC8vIOODoeOCpOODs+ODq+ODvOODl1xyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1RBUkdFVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICAvLyBpdGVt44Gr5a6a576p44GV44KM44Gm44GE44KL5pyA5L2O5b+F6KaB5Zyo5bqr44KI44KK5aSa44GE5ZWG5ZOB44KS5Ye65ZOB44GZ44KLXHJcbiAgICAgICAgICAgIGlmIChxdWFudGl0eSA+PSBpdGVtLm1hbGwueWF1Y3QubWluUXVhbnRpdHkpIHtcclxuICAgICAgICAgICAgICBsZXQgeWF1Y3QgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbVlhdWN0KGNvbmZpZy5kZWZhdWx0LCBpdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IHBhY2tldC5zdWJtaXQoe3lhdWN0OiB5YXVjdCwgaXRlbTogaXRlbX0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH19KVxyXG5cclxuICAgICAgICBwYWNrZXQuY2xvc2UoKVxyXG5cclxuICAgICAgICByZXR1cm4gcmVzXHJcbiAgICAgIH0pXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKClcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgJy4uL2ltcG9ydHMvY29sbGVjdGlvbi9jb25maWdzJ1xyXG5cclxuaW1wb3J0ICcuL3JvdXRlL3VwbG9hZC9pbWFnZSdcclxuIiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG4gXHJcbmV4cG9ydCBjb25zdCBDb25maWdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NvbmZpZ3MnLHtpZEdlbmVyYXRpb246J01PTkdPJ30pO1xyXG5cclxuLy8gTWV0ZW9yLm1ldGhvZHMoeyBcclxuLy8gICBhc3luYyAnbXlzcWxTZXJ2ZXJzLmluc2VydCcgKCBuZXdTZXJ2ZXIgKXtcclxuLy8gICAgIHJldHVybiBhd2FpdCBNeXNxbFNlcnZlcnMuaW5zZXJ0KG5ld1NlcnZlcik7XHJcbi8vICAgfVxyXG4vLyB9KTtcclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXHJcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnO1xyXG5pbXBvcnQgbW9iamVjdCBmcm9tICdtb25nb29iamVjdCc7XHJcbmltcG9ydCB7IEdyb3VwQmFzZSB9IGZyb20gJy4vZ3JvdXBzJztcclxuXHJcbmNvbnN0IEZpbHRlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZmlsdGVycycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgRmlsdGVyIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZmlsdGVySWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEZpbHRlcnMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZmlsdGVySWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuXHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoIG9uUmVzdWx0ID0gKHJlY29yZCk9Pnt9LCBvbkVycm9yID0gKGUpPT57fSApID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbGF0Zm9ybSB0eXBlJyk7XHJcblxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHt7IGZpbHRlclR5cGU6IGFzeW5jIChyZWNvcmQgKSA9PiB7fSB9fSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGFzeW5jIGZvcmVhY2goY2FsbGJhY2tzID0ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZSgpO1xyXG5cclxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXHJcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XHJcbiAgICAgIHR5cGU6ICdtaXNjJyxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBjb3VudCA9IHt9O1xyXG4gICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICBjb3VudFtmaWx0ZXIudHlwZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGZpbHRlci5xdWVyeSxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkKT0+e1xyXG4gICAgICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgICAgIGxldCBxdWVyeSA9IG1vYmplY3QudW5lc2NhcGUoZmlsdGVyLnF1ZXJ5KTtcclxuICAgICAgICAgIGxldCBleGFtID0gc2lmdCggcXVlcnkgKTtcclxuICAgICAgICAgIGlmKCBleGFtKHJlY29yZCkgKXtcclxuICAgICAgICAgICAgY291bnRbZmlsdGVyLnR5cGVdLmNvdW50Kys7XHJcbiAgICAgICAgICAgIGlmKCB0eXBlb2YgY2FsbGJhY2tzW2ZpbHRlci50eXBlXSAhPT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0ocmVjb3JkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIG9uRXJyb3JcclxuICAgICk7XHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudDtcclxuXHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuY29uc3QgR3JvdXBzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2dyb3VwcycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXBCYXNlIHtcclxuXHJcbiAgcHJvZmlsZTtcclxuXHJcbiAgY29uc3RydWN0b3IocHJvZmlsZSkge1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGdldHMgJ1BsdWcnIHdpdGNoIGlzIGEgc2V0IG9mIHByb3BlcnRpZXMgbmVlZGVkXHJcbiAgICogd2hlbiBjb25uZWN0IHRvIHNvbWUgcGxhdGZvcm1zXHJcbiAgICogdG8gZ2V0IGRhdGFzKE1lbWJlcnMgb2YgdGhlIEdyb3VwKVxyXG4gICAqL1xyXG4gIGdldFBsdWcoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlLnBsYXRmb3JtUGx1ZztcclxuICB9XHJcblxyXG4gIGdldFByb2ZpbGUoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7fTtcclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cCBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGdyb3VwSWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEdyb3Vwcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBncm91cElkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoZG9jKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfSBXSEVSRSBcXGAke2RvYy5rZXl9XFxgID0gXCIke2RvYy5pZH1cImA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIGdyb3VwIHR5cGUnKTtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHthc3luYyAocmVjb3JkKT0+dm9pZH0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgY3VyID0gR3JvdXBzLmZpbmQoe1xyXG4gICAgICBncm91cElkOiB0aGlzLnByb2ZpbGUuX2lkXHJcbiAgICB9LCB7XHJcbiAgICAgIGZpZWxkczoge1xyXG4gICAgICAgIF9pZDogMCxcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICBrZXk6IDFcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY3VyLmZvckVhY2goXHJcbiAgICAgICAgICBhc3luYyAoZG9jLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZWNvcmQgPSBhd2FpdCB0aGlzLmltcG9ydChkb2MpO1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBvbkVycm9yKGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpbmRleCArIDEgPT09IGN1ci5jb3VudCgpKSB7XHJcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgIH1cclxuICAgICkuY2F0Y2goXHJcbiAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgfVxyXG5cclxufSIsImltcG9ydCB7IE1vbmdvIH0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuIFxyXG5leHBvcnQgY29uc3QgVXBsb2FkcyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCd1cGxvYWRzJyx7aWRHZW5lcmF0aW9uOidNT05HTyd9KTtcclxuXHJcbiIsImltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcblxyXG5leHBvcnQgY2xhc3MgQ3ViZTNBcGkge1xyXG4gIGNvbnN0cnVjdG9yIChteXNxbCA9IG5ldyBNeVNRTCgpKSB7XHJcbiAgICB0aGlzLm15c3FsXyA9IG15c3FsXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9jayAocHJvZHVjdENsYXNzSWQsIHF1YW50aXR5ID0gMCkge1xyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIGBwcm9kdWN0X2NsYXNzX2lkID0gJHtwcm9kdWN0Q2xhc3NJZH1gLFxyXG4gICAgICB7fSwge1xyXG4gICAgICAgIHN0b2NrOiBxdWFudGl0eSxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3Rfc3RvY2snLFxyXG4gICAgICBgcHJvZHVjdF9jbGFzc19pZCA9ICR7cHJvZHVjdENsYXNzSWR9YCxcclxuICAgICAge30sIHtcclxuICAgICAgICBzdG9jazogcXVhbnRpdHksXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdFRhZ1VwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSBbXVxyXG5cclxuICAgIC8vIOWJiumZpOOBmeOCi+OCv+OCsFxyXG4gICAgbGV0IHRhZ29mZiA9IGFzeW5jICh0YWcpID0+IHtcclxuICAgICAgbGV0IHNxbCA9IGBcclxuICAgICAgREVMRVRFIEZST00gZHRiX3Byb2R1Y3RfdGFnIFxyXG4gICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9IEFORCB0YWcgPSAke3RhZ31cclxuICAgICAgYFxyXG4gICAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOihqOekuuOBmeOCi+OCv+OCsFxyXG4gICAgbGV0IHRhZ29uID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICAvLyDjgZnjgafjgavooajnpLrjgZXjgozjgabjgYTjgovjgr/jgrDjgYzjgYLjgozjgbDkvZXjgoLjgZfjgarjgYRcclxuICAgICAgbGV0IHNxbCA9IGBcclxuICAgICAgU0VMRUNUIENPVU5UKCopIEZST00gZHRiX3Byb2R1Y3RfdGFnIFxyXG4gICAgICBXSEVSRSBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9IEFORCB0YWcgPSAke3RhZ31cclxuICAgICAgYFxyXG4gICAgICBsZXQgY291bnRSZXMgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpXHJcbiAgICAgIGlmIChjb3VudFJlc1swXVsnQ09VTlQoKiknXSkgcmV0dXJuXHJcblxyXG4gICAgICByZXMucHVzaChcclxuICAgICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAgICdkdGJfcHJvZHVjdF90YWcnLFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGRhdGEucHJvZHVjdF9pZCxcclxuICAgICAgICAgICAgdGFnOiB0YWcsXHJcbiAgICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICAgIH1cclxuICAgICAgICApKVxyXG4gICAgfVxyXG5cclxuICAgIGZvciAobGV0IHRhZ1NldCBvZiBkYXRhLnRhZ3MpIHtcclxuICAgICAgc3dpdGNoICh0YWdTZXQuc2V0KSB7XHJcbiAgICAgICAgY2FzZSAnb24nOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb24odGFnU2V0LnRhZylcclxuICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgY2FzZSAnb2ZmJzpcclxuICAgICAgICAgIGF3YWl0IHRhZ29mZih0YWdTZXQudGFnKVxyXG4gICAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0SW1hZ2VVcGRhdGUgKGRhdGEpIHtcclxuICAgIGxldCBwcm9kdWN0SWQgPSBkYXRhLnByb2R1Y3RfaWRcclxuICAgIGxldCBpbWFnZXMgPSBkYXRhLmltYWdlc1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSBbXVxyXG5cclxuICAgIC8vIOWVhuWTgeOBq+mWoumAo+OBmeOCi+OBmeOBueOBpuOBrueUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi1xyXG4gICAgbGV0IHNxbCA9IGBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF9pbWFnZSBXSEVSRSBwcm9kdWN0X2lkID0gJHtwcm9kdWN0SWR9YFxyXG4gICAgcmVzLnB1c2goYXdhaXQgdGhpcy5teXNxbF8ucXVlcnkoc3FsKSlcclxuXHJcbiAgICAvLyDmlLnjgoHjgabnlLvlg4/jgpLnmbvpjLLjgZfjgarjgYrjgZlcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICdkdGJfcHJvZHVjdF9pbWFnZScsIHtcclxuICAgICAgICAgIHByb2R1Y3RfaWQ6IHByb2R1Y3RJZCxcclxuICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICAgIGZpbGVfbmFtZTogaW1hZ2VzW2ldLFxyXG4gICAgICAgICAgcmFuazogaSArIDFcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBsZXQga2V5cyA9IFtdXHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RcclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnc3RhdHVzJyxcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnbm90ZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9saXN0JyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXHJcbiAgICAgICdzZWFyY2hfd29yZCcsXHJcbiAgICAgICdmcmVlX2FyZWEnXHJcbiAgICBdXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBkdGJfcHJvZHVjdF9jbGFzc1xyXG5cclxuICAgIHVwZGF0ZURhdGEgPSB7fVxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ2RlbGl2ZXJ5X2RhdGVfaWQnLFxyXG4gICAgICAncHJvZHVjdF9jb2RlJyxcclxuICAgICAgJ3NhbGVfbGltaXQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJyxcclxuICAgICAgJ2RlbGl2ZXJ5X2ZlZSdcclxuICAgIF1cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9jbGFzcycsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdENyZWF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IGNyZWF0b3JJZCA9IGRhdGEuY3JlYXRvcl9pZFxyXG5cclxuICAgIGxldCByZXMgPSB7fVxyXG5cclxuICAgIGxldCB1cGRhdGVEYXRhID0ge31cclxuICAgIGxldCBrZXlzID0gW11cclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnbmFtZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnXHJcbiAgICBdXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgIC8vICAgZGVzY3JpcHRpb25fZGV0YWlsOiBpdGVtLmRlc2NyaXB0aW9uLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0JyxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBzdGF0dXM6IDEsXHJcbiAgICAgICAgbm90ZTogJ05VTEwnLFxyXG4gICAgICAgIGRlc2NyaXB0aW9uX2xpc3Q6ICdOVUxMJyxcclxuICAgICAgICBzZWFyY2hfd29yZDogJ05VTEwnLFxyXG4gICAgICAgIGZyZWVfYXJlYTogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICB1cGRhdGVEYXRhID0ge31cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdwcm9kdWN0X2NvZGUnLFxyXG4gICAgICAncHJvZHVjdF90eXBlX2lkJyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdXHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIHByb2R1Y3RfY29kZTogaXRlbS5tb2RlbCxcclxuICAgIC8vICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAvLyAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UsXHJcbiAgICAvLyB9LFxyXG5cclxuICAgIGZvciAobGV0IGsgb2Yga2V5cykge1xyXG4gICAgICBpZiAoZGF0YVtrXSkgdXBkYXRlRGF0YVtrXSA9IGRhdGFba11cclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9jbGFzc19pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICB1cGRhdGVEYXRhLCB7XHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHByb2R1Y3RfaWQ6IHJlcy5wcm9kdWN0X2lkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDE6ICdOVUxMJyxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDI6ICdOVUxMJyxcclxuICAgICAgICBkZWxpdmVyeV9kYXRlX2lkOiAnTlVMTCcsXHJcbiAgICAgICAgc2FsZV9saW1pdDogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3Rfc3RvY2tfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJywge30sIHtcclxuICAgICAgICBwcm9kdWN0X2NsYXNzX2lkOiByZXMucHJvZHVjdF9jbGFzc19pZCxcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgc3RvY2s6IDAsXHJcbiAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIGZvciB0ZXN0XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnXHJcbmltcG9ydCB7TW9uZ29DbGllbnR9IGZyb20gJ21vbmdvZGInXHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tICdzaWZ0J1xyXG5pbXBvcnQgbW9iamVjdCBmcm9tICdtb25nb29iamVjdCdcclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlckZhY3Rvcnkge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBsZXQgaW5zdGFuY2VcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICBpbnN0YW5jZSA9IG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpXHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGluc3RhbmNlXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnXHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlXHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZmFjdG9yeSAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHJldHVybiBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKVxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbHVnIHR5cGUnKVxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0UGx1Z18gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Z1xyXG4gIH1cclxuXHJcbiAgZ2V0Q3JlZF8gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucGx1Zy5jcmVkXHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlXyAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlXHJcbiAgfVxyXG5cclxuICBzZXRJbXBvcnRGdW5jdGlvbl8gKFxyXG4gICAgZm4gPSBhc3luYyAob25SZXN1bHQgPSByZWNvcmQgPT4ge30sIG9uRXJyb3IgPSBlID0+IHt9KSA9PiB7fVxyXG4gICkge1xyXG4gICAgdGhpcy5pbXBvcnQgPSBmblxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogdXNlYWdlOlxyXG4gICAqXHJcbiAgICpcclxuICAgKiBAcGFyYW0geyBPYmplY3QgfSBpdGVyYXRvcnMgeyBmaWx0ZXJOYW1lOiBhc3luYyAoZG9jLGNvbnRleHQpPT57fSwgLi4uIH0gaXRlcmF0b3IgZm9yIGVhY2ggZmlsdGVyc1xyXG4gICAqIEBwYXJhbSB7IGFzeW5jIGZ1bmN0aW9uIH0gb25FcnJvciBlcnJvciBoYW5kbGVyIHdoaWxlIGl0ZXJhdGluZ1xyXG4gICAqIEByZXR1cm5zIHsgT2JqZWN0IH0geyBmaWx0ZXJOYW1lOiB7IHF1ZXJ5OiBhbnksIGNvdW50OiBudW1iZXIgfSwgLi4uIH1cclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoIChpdGVyYXRvcnMgPSB7fSkge1xyXG4gICAgbGV0IHByb2ZpbGUgPSB0aGlzLmdldFByb2ZpbGVfKClcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICBuYW1lOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSlcclxuXHJcbiAgICBsZXQgY291bnRlciA9IHt9XHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgfVxyXG5cclxuICAgIGxldCBmaWx0ZXJzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgICBjb3VudGVyW2YubmFtZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGYucXVlcnksXHJcbiAgICAgICAgbGltaXQ6IHR5cGVvZiBmLmxpbWl0ICE9PSAndW5kZWZpbmVkJyA/IGYubGltaXQgOiAwLFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH1cclxuICAgICAgZmlsdGVycy5wdXNoKFxyXG4gICAgICAgIHtcclxuICAgICAgICAgIG5hbWU6IGYubmFtZSxcclxuICAgICAgICAgIGV4YW06IHNpZnQobW9iamVjdC51bmVzY2FwZShmLnF1ZXJ5KSlcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICBhd2FpdCB0aGlzLmltcG9ydChcclxuICAgICAgYXN5bmMgKHJlY29yZCwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgIGZvciAobGV0IGYgb2YgZmlsdGVycykge1xyXG4gICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXHJcbiAgICAgICAgICBsZXQgYyA9IGNvdW50ZXJbZi5uYW1lXVxyXG4gICAgICAgICAgaWYgKGMubGltaXQpIHtcclxuICAgICAgICAgICAgaWYgKGMuY291bnQgPj0gYy5saW1pdCkge1xyXG4gICAgICAgICAgICAgIGNvbnRpbnVlXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZi5leGFtKHJlY29yZCkpIHtcclxuICAgICAgICAgICAgLy8gY291bnRlciBsaW1pdGVyXHJcbiAgICAgICAgICAgIGMuY291bnQrK1xyXG5cclxuICAgICAgICAgICAgLy8gaXRlcmF0b3JcclxuICAgICAgICAgICAgaWYgKHR5cGVvZiBpdGVyYXRvcnNbZi5uYW1lXSAhPT0gJ3VuZGVmaW5lZCcpIHtcclxuICAgICAgICAgICAgICBhd2FpdCBpdGVyYXRvcnNbZi5uYW1lXShyZWNvcmQsIGNvbnRleHQpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgYnJlYWtcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0pXHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudGVyXHJcbiAgfVxyXG59XHJcblxyXG5leHBvcnQgY2xhc3MgTXlzcWxEQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICBsZXQgY3JlZCA9IHRoaXMuZ2V0Q3JlZF8oKVxyXG5cclxuICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwoY3JlZClcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfWBcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgKGUpID0+IHsgdGhyb3cgZSB9KVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuLy8gaW1wb3J0IE1vbmdvTmF0aXZlIGZyb20gJ21vbmdvZGInO1xyXG4vLyBjb25zdCBNb25nb0NsaWVudCA9IE1vbmdvTmF0aXZlLk1vbmdvQ2xpZW50O1xyXG4vLyBjb25zdCBNb25nb0NsaWVudCA9IHJlcXVpcmUoJ21vbmdvZGInKS5Nb25nb0NsaWVudDtcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yIChwbHVnLCBwcm9maWxlKSB7XHJcbiAgICBzdXBlcihwbHVnLCBwcm9maWxlKVxyXG5cclxuICAgIC8vIG1vbmdvIOOBuOaOpee2mlxyXG4gICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbiAgICAgIGxldCBjbGllbnRcclxuICAgICAgY2xpZW50ID0gYXdhaXQgTW9uZ29DbGllbnQuY29ubmVjdChwbHVnLnVyaSlcclxuXHJcbiAgICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuWPluW+l1xyXG4gICAgICBsZXQgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSlcclxuICAgICAgbGV0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbilcclxuXHJcbiAgICAgIGxldCBjb250ZXh0ID0ge1xyXG4gICAgICAgIGNsaWVudDogY2xpZW50LFxyXG4gICAgICAgIGNvbGxlY3Rpb246IGNvbGxlY3Rpb24sXHJcbiAgICAgICAgZGF0YWJhc2U6IGRiXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKVxyXG5cclxuICAgICAgLy8g44Kr44O844K944Or44Gu44K/44Kk44Og44Ki44Km44OI44KS6Kej6ZmkXHJcbiAgICAgIGN1ci5hZGRDdXJzb3JGbGFnKCdub0N1cnNvclRpbWVvdXQnLCB0cnVlKVxyXG5cclxuICAgICAgLy8g44GZ44G544Gm44Gu44OJ44Kt44Ol44Oh44Oz44OI44KS44Or44O844OXXHJcbiAgICAgIHRyeSB7XHJcbiAgICAgICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgICAgIGxldCBkb2MgPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgICAgICBhd2FpdCBvblJlc3VsdChkb2MsIGNvbnRleHQpXHJcbiAgICAgICAgfTtcclxuICAgICAgfSBmaW5hbGx5IHtcclxuICAgICAgICAvLyDjgqvjg7zjgr3jg6vjgpLplovmlL5cclxuICAgICAgICBhd2FpdCBjdXIuY2xvc2UoKVxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuLy8gaW1wb3J0IG1vbmdvb3NlIGZyb20gJ21vbmdvb3NlJztcclxuXHJcbi8vIGV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4vLyAgIGNvbnN0cnVjdG9yKHBsdWcsIHByb2ZpbGUpIHtcclxuLy8gICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xyXG5cclxuLy8gICAgIC8vIG1vbmdvIOOBuOaOpee2mlxyXG4vLyAgICAgbGV0IGNyZWQgPSB0aGlzLmdldENyZWRfKCk7XHJcbi8vICAgICBsZXQgY29udXJpID0gYG1vbmdvZGI6Ly8ke2NyZWQuaG9zdH06JHtjcmVkLnBvcnR9LyR7Y3JlZC5kYXRhYmFzZX1gO1xyXG4vLyAgICAgYXdhaXQgbW9uZ29vc2UuY29ubmVjdChjb251cmkpO1xyXG5cclxuLy8gICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuS9nOOCi1xyXG4vLyAgICAgbGV0IGNvbGxlY3Rpb24gPSBtb25nb29zZS5jb25uZWN0aW9uLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKTtcclxuXHJcbi8vICAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuLy8gICAgICAgbGV0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpO1xyXG5cclxuLy8gICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgb25FcnJvcik7XHJcbi8vICAgICB9KTtcclxuLy8gICB9XHJcbi8vIH1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb0NvbGxlY3Rpb25cclxufSBmcm9tICcuLi91dGlsL21vbmdvJ1xyXG5pbXBvcnQge1xyXG4gIFVwbG9hZHNcclxufSBmcm9tICcuLi9jb2xsZWN0aW9uL3VwbG9hZHMnXHJcbmltcG9ydCB7XHJcbiAgT2JqZWN0SURcclxufSBmcm9tICdic29uJ1xyXG5pbXBvcnQgVGV4dFV0aWwgZnJvbSAnLi4vdXRpbC90ZXh0J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgSXRlbUNvbnRyb2xsZXIge1xyXG4gIGFzeW5jIGluaXQgKHBsdWcpIHtcclxuICAgIHRoaXMuSXRlbXMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdpdGVtcycpXHJcbiAgICB0aGlzLlByb2R1Y3RzID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCAncHJvZHVjdHMnKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgZ2V0U3RvY2sgKGl0ZW1JZCkge1xyXG4gICAgbGV0IHByb2plY3QgPSBhd2FpdCB0aGlzLkl0ZW1zLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGl0ZW1JZFxyXG4gICAgfSwge1xyXG4gICAgICBwcm9qZWN0aW9uOiB7XHJcbiAgICAgICAgJ3Byb2R1Y3QnOiAxXHJcbiAgICAgIH1cclxuICAgIH0pXHJcbiAgICBsZXQgcHJvZHVjdFBhY2sgPSBwcm9qZWN0LnByb2R1Y3RcclxuXHJcbiAgICAvLyBwcm9kdWN0ICogPC0+ICogaXRlbVxyXG4gICAgLy8gcHJvZHVjdFtdOiDopIfmlbDjga7llYblk4HjgpIx44OR44OD44Kx44O844K444Go44GX44Gm6LKp5aOyXHJcbiAgICAvLyBwcm9kdWN0W1tdXTog55Ww44Gq44KL5rWB6YCa57WM6Lev44CB55Ww44Gq44KL5Y6f5L6h44O75LuV5YWl44KM5YCkXHJcbiAgICAvLyBpdGVtOiDnlbDjgarjgovjgrvjg7zjg6vjgIHosqnlo7LlvaLmhYtcclxuICAgIC8vIOKAuyBwcm9kdWN0IOOBi+OCieOBr+OAgeiyqeWjsuWPr+iDveOBquWcqOW6q+OAgeWIqeebiuioiOeul+OBruOBn+OCgeOBruaDheWgseOCkuW+l+OCi1xyXG5cclxuICAgIGxldCBxdWFudGl0aWVzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBwcm9kdWN0U2t1IG9mIHByb2R1Y3RQYWNrKSB7XHJcbiAgICAgIGxldCBxdWFudGl0eVNrdSA9IDBcclxuXHJcbiAgICAgIGZvciAobGV0IHByb2R1Y3RJZCBvZiBwcm9kdWN0U2t1KSB7XHJcbiAgICAgICAgbGV0IHByb2plY3QgPSBhd2FpdCB0aGlzLlByb2R1Y3RzLmZpbmRPbmUoe1xyXG4gICAgICAgICAgX2lkOiBwcm9kdWN0SWRcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBwcm9qZWN0aW9uOiB7XHJcbiAgICAgICAgICAgICdzdG9jayc6IDFcclxuICAgICAgICAgIH1cclxuICAgICAgICB9KVxyXG4gICAgICAgIGxldCBzdG9ja0FycmF5ID0gcHJvamVjdC5zdG9ja1xyXG5cclxuICAgICAgICAvLyDljZjntJTjgavjgZnjgbnjgabjga7lnKjluqvllYblk4HjgIHnn63mnJ/plpPlj5bjgorlr4TjgZvlj6/og73llYblk4HjgpLlkIjnrpdcclxuICAgICAgICBmb3IgKGxldCBzdG9jayBvZiBzdG9ja0FycmF5KSB7XHJcbiAgICAgICAgICBxdWFudGl0eVNrdSArPSBzdG9jay5xdWFudGl0eVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgcXVhbnRpdGllcy5wdXNoKHF1YW50aXR5U2t1KVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCu+ODg+ODiOWVhuWTgeOBruWgtOWQiOOAgeS4gOeVquWwkeOBquOBhOWVhuWTgeaVsOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IHF1YW50aXR5ID0gTWF0aC5taW4uYXBwbHkobnVsbCwgcXVhbnRpdGllcylcclxuXHJcbiAgICByZXR1cm4gcXVhbnRpdHlcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgovjgIJcclxuICAgKlxyXG4gICAqIOODoeODvOOCq+ODvOODouODh+ODq+OBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog54m55a6a44Gu5bGe5oCn77yI44Kr44Op44O844Gq44Gp77yJ44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXHJcbiAgICogY2xhc3Mx44Gr5YCk44KS5oyH5a6a44GX44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXHJcbiAgICog44KC44GXY2xhc3My44Gu44G/5oyH5a6a44GX44Gf44GE5aC05ZCI44GvY2xhc3Mx44GrbnVsbOOCkuaMh+WumuOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog5L6L77yaSkstMTAw44GuQkxBQ0vjga7llYblk4HnlLvlg4/jgpJcclxuICAgKiDjgZnjgbnjgabjga7jgrXjgqTjgrrvvIhTLE0sTCxYTCwyWEwsM1hMLDRYTOKApu+8ieOBq+mWoumAo+S7mOOBkeOCi+WgtOWQiFxyXG4gICAqIHNldEltYWdlKCB1cGxvYWRJZCwgJ0pLLTEwMCcsICdCTEFDSycgKTtcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB1cGxvYWRJZCDkuIDlm57jga7jgqLjg4Pjg5fjg63jg7zjg4nnlLvlg4/jgpLmnZ/jga3jgabjgYTjgotJROOAgm1ldGVvcuODh+ODvOOCv+ODmeODvOOCueOAgVVwbG9hZHPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjg4njgq3jg6Xjg6Hjg7Pjg4jjga51cGxvYWRJZOODl+ODreODkeODhuOCo1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgc2V0SW1hZ2UgKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44Gu5oOF5aCx5Y+W5b6XXHJcbiAgICBsZXQgaW1hZ2VzID0gVXBsb2Fkcy5maW5kKHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkXHJcbiAgICB9KS5mZXRjaCgpLm1hcCgodikgPT4gdi51cGxvYWRlZEZpbGVOYW1lKVxyXG5cclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlciwge1xyXG4gICAgICAgICRwdXNoOiB7XHJcbiAgICAgICAgICBpbWFnZXM6IHtcclxuICAgICAgICAgICAgJGVhY2g6IGltYWdlc1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIOeZu+mMsuOBl+OBn+eUu+WDj+ODleOCoeOCpOODq+WQjeS4gOimp1xyXG4gICAgcmV0dXJuIGltYWdlc1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+eZu+mMsuOBleOCjOOBpuOBhOOCi+eUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKi9cclxuICBhc3luYyBjbGVhbkltYWdlIChtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge31cclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsXHJcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxXHJcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLCB7XHJcbiAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44Gu5ZWG5ZOB44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gu5bGe5oCn5Yil44Gu5ZWG5ZOB5oOF5aCx44KS6L+U44GZ44CCXHJcbiAgICpcclxuICAgKiDlvJXmlbDjgajjgZfjgablj5fjgZHlj5bjgotpdGVt44Gv5Lu75oSP44Gu5ZWG5ZOB5oOF5aCx44CCXHJcbiAgICogaXRlbeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBq+OBpOOBhOOBpuW/heimgeOBquaDheWgseOCkuaVtOeQhuOBl+i/lOOBmeOAglxyXG4gICAqXHJcbiAgICogcHJvamVjdOOBq+WPgueFp+OBl+OBn+OBhOWVhuWTgeaDheWgseODleOCo+ODvOODq+ODieOCkuWumue+qeOBmeOCi+OAglxyXG4gICAqIOODoeOCveODg+ODieOBruWRvOOBs+WHuuOBl+aZguOBq+W/heimgeOBq+W/nOOBmOOBpnByb2plY3TjgpLoqK3lrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS9leOBq+azqOebruOBl+OBpuWVhuWTgeOBrumWoumAo+aAp+OCkuaknOWHuuOBmeOCi+OBi+OBr+OAgeOBk+OBruODoeOCveODg+ODieWGheOBp+Wumue+qeOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGl0ZW1cclxuICAgKiBAcGFyYW0ge09iamVjdH0gcHJvamVjdFxyXG4gICAqL1xyXG4gIGFzeW5jIGdldFZhcmlhdGlvbiAoaXRlbSwgcHJvamVjdCkge1xyXG4gICAgLyoqXHJcbiAgICAgKiBhZ2dyZWdhdGlvbuioreWumlxyXG4gICAgICpcclxuICAgICAqIGxhYmVsOiDlsZ7mgKflkI3vvIjphY3pgIHmlrnms5XjgIHjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganvvIlcclxuICAgICAqIGN1cnJlbnQ6IOaMh+WumuOBleOCjOOBn+OCouOCpOODhuODoO+8iGl0ZW3vvInjgYzoqbLlvZPjgZnjgovpoIXnm65cclxuICAgICAqIHBvcmplY3Q6IOODkOODquOCqOODvOOCt+ODp+ODs+aknOe0ouOBruOCreODvOOBqOOBquOCi2l0ZW3lhoXjga7jg5XjgqPjg7zjg6vjg4nlkI0gJFvjg5XjgqPjg7zjg6vjg4nlkI1d5b2i5byPXHJcbiAgICAgKiBxdWVyeTogYWdncmVnYXRpb27lr77osaHjgajjgZnjgovjg4njgq3jg6Xjg6Hjg7Pjg4jjga7mpJzntKLmnaHku7ZcclxuICAgICAqL1xyXG4gICAgbGV0IHNldCA9IFt7XHJcbiAgICAgIGxhYmVsOiAn6YWN6YCB5pa55rOVJyxcclxuICAgICAgY3VycmVudDogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgIHZhbHVlOiAnJGRlbGl2ZXJ5J1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogaXRlbS5jbGFzczFfbmFtZSxcclxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRjbGFzczFfdmFsdWUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogaXRlbS5jbGFzczJfbmFtZSxcclxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczJfdmFsdWUsXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRjbGFzczJfdmFsdWUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgICAgY2xhc3MxX3ZhbHVlOiBpdGVtLmNsYXNzMV92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBdXHJcblxyXG4gICAgbGV0IGF0dHJzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBzIG9mIHNldCkge1xyXG4gICAgICBhdHRycy5wdXNoKHtcclxuICAgICAgICB2YXJpYXRpb25zOiBhd2FpdCB0aGlzLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFt7XHJcbiAgICAgICAgICAgICRtYXRjaDogT2JqZWN0LmFzc2lnbihzLnF1ZXJ5LCB7XHJcbiAgICAgICAgICAgICAgbW9kZWw6IGl0ZW0ubW9kZWxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICRwcm9qZWN0OiBPYmplY3QuYXNzaWduKHMucHJvamVjdCwgcHJvamVjdClcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICRzb3J0OiB7XHJcbiAgICAgICAgICAgICAgX2lkOiAxXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIF1cclxuICAgICAgICApLnRvQXJyYXkoKSxcclxuICAgICAgICBwcm9wczogc1xyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBhdHRyc1xyXG4gIH1cclxuXHJcbiAgLy8g44Oi44OH44Or44Kv44Op44K55b2i5byP44KS5L2c44KLXHJcbiAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gIGFzeW5jIGdldE1vZGVsQ2xhc3MgKGFyZykge1xyXG4gICAgbGV0IGl0ZW1cclxuICAgIC8vIGl0ZW0g44GM5paH5a2X5YiX44Gq44KJ44CBaXRlbeOBr+S7u+aEj+OBruOCquODluOCuOOCp+OCr+ODiElE44Gu5pyr5bC+44GL44KJ5Lu75oSP44Gu5qGB5pWw44GuMTbpgLLmlbBcclxuICAgIGlmICh0eXBlb2YgYXJnID09PSAnc3RyaW5nJykge1xyXG4gICAgICBsZXQgZXhwID0gbmV3IFJlZ0V4cChgJHthcmd9JGApXHJcbiAgICAgIGxldCBjdXIgPSB0aGlzLkl0ZW1zLmZpbmQoe30sIHtcclxuICAgICAgICBwcm9qZWN0aW9uOiB7XHJcbiAgICAgICAgICBtb2RlbDogMSxcclxuICAgICAgICAgIGNsYXNzMV92YWx1ZTogMSxcclxuICAgICAgICAgIGNsYXNzMl92YWx1ZTogMVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICAgIHdoaWxlICgxKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgICAgICBsZXQgbWF0Y2ggPSBhd2FpdCBpdGVtLl9pZC50b0hleFN0cmluZygpLm1hdGNoKGV4cClcclxuICAgICAgICAgIGlmIChtYXRjaCkge1xyXG4gICAgICAgICAgICBicmVha1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIC8vIOipsuW9k+OBmeOCi2l0ZW3jg4fjg7zjgr/jgYzjgarjgYRcclxuICAgICAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICAgICAgICByZXR1cm4gYXJnXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpdGVtID0gYXJnXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuICAgIHJldHVybiBtb2RlbENsYXNzLmpvaW4oJy8nKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlMyAoY3JlYXRvcklkLCBpdGVtKSB7XHJcbiAgICAvLyDlgKTlpInmj5tcclxuICAgIGxldCBjb252RGVsaXYgPSAoZGVsaXZlcnkpID0+IGRlbGl2ZXJ5ID09PSAn44KG44GG44OR44Kx44OD44OIJyA/ICfjg53jgrnjg4jmipXlh70nIDogZGVsaXZlcnlcclxuXHJcbiAgICAvLyBwcm9kdWN0X2lkXHJcbiAgICBsZXQgcHJvZHVjdElkID0gbnVsbFxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG5cclxuICAgIC8vIOS4i+iomOOBruW9ouW8j+OCkuS9nOOCi1xyXG4gICAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuXHJcbiAgICAvLyDllYblk4HnqK7liKXjgpLlibLjgorlvZPjgabjgotcclxuICAgIGxldCBwcm9kdWN0VHlwZUlkXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDJcclxuICAgICAgICBicmVha1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCB0YWdzID0gW11cclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeWIpemAgeaWmeOCkuioreWumuOBmeOCi1xyXG4gICAgbGV0IGRlbGl2ZXJ5RmVlID0gbnVsbFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBudWxsXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICBkZWxpdmVyeUZlZSA9IDI0MFxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy9cclxuICAgIC8vIOmhp+WuouWQkeOBkeODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgemBuOaKnuapn+iDveOBruWun+ijhVxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6ICckbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJ1xyXG4gICAgfSlcclxuXHJcbiAgICAvLyBIVE1MIOODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgeOBlOOBqOOBruODquODs+OCr+S7mOOBjeODnOOCv+ODs+OCkuihqOekuuOBmeOCi1xyXG5cclxuICAgIC8vIOWApOOBruWkieaPm1xyXG4gICAgYXR0cnMgPSBhdHRycy5tYXAoXHJcbiAgICAgIChhdHRyKSA9PiB7XHJcbiAgICAgICAgYXR0ci5wcm9wcy5jdXJyZW50ID0gY29udkRlbGl2KGF0dHIucHJvcHMuY3VycmVudClcclxuICAgICAgICBhdHRyLnZhcmlhdGlvbnMgPSBhdHRyLnZhcmlhdGlvbnMubWFwKFxyXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xyXG4gICAgICAgICAgICB2YXJpYXRpb24udmFsdWUgPSBjb252RGVsaXYodmFyaWF0aW9uLnZhbHVlKVxyXG4gICAgICAgICAgICByZXR1cm4gdmFyaWF0aW9uXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIHJldHVybiBhdHRyXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBIVE1M55Sf5oiQXHJcbiAgICBsZXQgdmFyaWF0aW9uSHRtbCA9XHJcbiAgICAgIGF0dHJzLm1hcChcclxuICAgICAgICAoYXR0cikgPT5cclxuICAgICAgICAgICc8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWZsdWlkXCI+JyArXHJcbiAgICAgICAgYDxkaXYgY2xhc3M9XCJyb3dcIj5gICtcclxuICAgICAgICBgPGRpdiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLWJsb2NrIGJ0bi14c1wiPmAgK1xyXG4gICAgICAgIGA8c3Ryb25nPiR7YXR0ci5wcm9wcy5sYWJlbH08L3N0cm9uZz5gICtcclxuICAgICAgICBgPC9kaXY+YCArXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgaWYgKGF0dHIucHJvcHMuY3VycmVudCA9PT0gdmFyaWF0aW9uLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YSBocmVmPVwiL3Byb2R1Y3RzL2RldGFpbC8ke3ZhcmlhdGlvbi5wcm9kdWN0X2lkfVwiPjxidXR0b24gY2xhc3M9XCJidG4gYnRuLXN1Y2Nlc3MgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPjxzdHJvbmc+JHt2YXJpYXRpb24udmFsdWV9PC9zdHJvbmc+PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgICByZXR1cm4gYDxhIGhyZWY9XCIvcHJvZHVjdHMvZGV0YWlsLyR7dmFyaWF0aW9uLnByb2R1Y3RfaWR9XCI+PGJ1dHRvbiBjbGFzcz1cImJ0biBidG4tZGVmYXVsdCBidG4tc20gYnRuLWl0ZW0tY2xhc3Mtc2VsZWN0XCI+JHt2YXJpYXRpb24udmFsdWV9PC9idXR0b24+PC9hPmBcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICkuam9pbignJykgK1xyXG4gICAgICAgICc8L2Rpdj4nICtcclxuICAgICAgICAnPC9kaXY+J1xyXG4gICAgICApLmpvaW4oJycpXHJcblxyXG4gICAgbGV0IGRlc2NyaXB0aW9uRGV0YWlsID0gYFxyXG4gICAgPHNtYWxsPuKAuyDphY3pgIHmlrnms5Xjg7vjgqvjg6njg7zjg7vjgrXjgqTjgrrjga/kuIvoqJjjgYvjgonjgYrpgbjjgbPjgY/jgaDjgZXjgYTjgII8L3NtYWxsPlxyXG4gICAgPHNtYWxsIGNsYXNzPVwidGV4dC1kYW5nZXJcIj7igLsg5Zyo5bqr44GM44Gq44GE5ZWG5ZOB44Gu5aC05ZCI44CM44Oa44O844K444GM6KaL44Gk44GL44KK44G+44Gb44KT44CN44Go6KGo56S644GV44KM44G+44GZ44CCPC9zbWFsbD5cclxuICAgICR7dmFyaWF0aW9uSHRtbH1cclxuICAgIGBcclxuXHJcbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcclxuICAgIGxldCBkYXRhID0ge1xyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7Y29udkRlbGl2KGl0ZW0uZGVsaXZlcnkpfSAke2l0ZW0ubmFtZX0gJHtpdGVtLmphbl9jb2RlfWAsXHJcbiAgICAgIGRlc2NyaXB0aW9uX2RldGFpbDogZGVzY3JpcHRpb25EZXRhaWwsXHJcbiAgICAgIGZyZWVfYXJlYTogaXRlbS5kZXNjcmlwdGlvbiArICcgJyxcclxuICAgICAgcHJvZHVjdF9jb2RlOiBtb2RlbENsYXNzLmpvaW4oJy8nKSxcclxuICAgICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAgIHByaWNlMDI6IGl0ZW0uc2FsZXNfcHJpY2UgKiAwLjk1LCAvLyDmpb3lpKnkvqHmoLzjgYvjgok1JeWApOW8leOBjVxyXG4gICAgICBpbWFnZXM6IGl0ZW0uaW1hZ2VzLFxyXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RUeXBlSWQsXHJcbiAgICAgIHRhZ3M6IHRhZ3MsXHJcbiAgICAgIGRlbGl2ZXJ5X2ZlZTogZGVsaXZlcnlGZWVcclxuICAgIH1cclxuXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcClcclxuXHJcbiAgICByZXR1cm4gZGF0YVxyXG4gIH1cclxuXHJcbiAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44G444Gu5aSJ5o+bXHJcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdCAoZGVmLCBpdGVtKSB7XHJcbiAgICBjb25zdCBpZExlbmd0aCA9IDIwXHJcbiAgICBjb25zdCB0aXRsZUxlbmd0aCA9IDEzMFxyXG5cclxuICAgIGxldCB5YXVjdCA9IHt9XHJcbiAgICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjga7liJ3mnJ/lgKTvvIjjgobjgYbjg5HjgrHjg4Pjg4jjg7vlroXphY3kvr/jgafnlbDjgarjgovvvIlcclxuICAgIHlhdWN0ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkZWZbaXRlbS5kZWxpdmVyeV0pKVxyXG5cclxuICAgIC8vIOeUu+WDj+OBruiomOi/sFxyXG4gICAgY29uc3QgaW1nUHJlZml4ID0gJ+eUu+WDjydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgeWF1Y3RbaW1nUHJlZml4ICsgKGkgKyAxKV0gPSBpdGVtLmltYWdlc1tpXVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCv+OCpOODiOODq1xyXG4gICAgeWF1Y3RbJ+OCq+ODhuOCtOODqiddID0gaXRlbS5tYWxsLnlhdWN0LmNhdGVnb3J5XHJcbiAgICB5YXVjdFsn44K/44Kk44OI44OrJ10gPSBUZXh0VXRpbC5zdWJzdHI4KGAke2F3YWl0IHRoaXMuZ2V0TW9kZWxDbGFzcyhpdGVtKX0gJHtpdGVtLmRlbGl2ZXJ5fSAke2l0ZW0ubmFtZX1gLCB0aXRsZUxlbmd0aClcclxuICAgIHlhdWN0Wyfplovlp4vkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfljbPmsbrkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfnrqHnkIbnlarlj7cnXSA9IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkuc2xpY2UoLWlkTGVuZ3RoKVxyXG4gICAgeWF1Y3RbJ+iqrOaYjiddID0gaXRlbS5kZXNjcmlwdGlvblxyXG4gICAgeWF1Y3RbJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXSA9IGl0ZW0uamFuX2NvZGVcclxuXHJcbiAgICByZXR1cm4geWF1Y3RcclxuICB9XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgdXRpbEVycm9yIHtcclxuICBzdGF0aWMgcGFyc2UgKGUpIHtcclxuICAgIGxldCByZXMgPSB7fVxyXG5cclxuICAgIGlmIChlIGluc3RhbmNlb2YgRXJyb3IpIHtcclxuICAgICAgcmVzLm1lc3NhZ2UgPSBlLm1lc3NhZ2VcclxuICAgICAgcmVzLm5hbWUgPSBlLm5hbWVcclxuICAgICAgcmVzLmZpbGVOYW1lID0gZS5maWxlTmFtZVxyXG4gICAgICByZXMubGluZU51bWJlciA9IGUubGluZU51bWJlclxyXG4gICAgICByZXMuY29sdW1uTnVtYmVyID0gZS5jb2x1bW5OdW1iZXJcclxuICAgICAgcmVzLnN0YWNrID0gZS5zdGFja1xyXG4gICAgfSBlbHNlIHtcclxuICAgICAgcmVzID0gZVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiByZXNcclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tICdtb25nb2RiJ1xyXG5cclxuZXhwb3J0IGNsYXNzIE1vbmdvQ29sbGVjdGlvbiB7XHJcbiAgc3RhdGljIGFzeW5jIGdldCAocGx1ZywgY29sbGVjdGlvbikge1xyXG4gICAgbGV0IGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpXHJcbiAgICBsZXQgZGIgPSBjbGllbnQuZGIocGx1Zy5kYXRhYmFzZSlcclxuICAgIHJldHVybiBkYi5jb2xsZWN0aW9uKGNvbGxlY3Rpb24pXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCBteXNxbCBmcm9tICdteXNxbCdcclxuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBNeVNRTCB7XHJcbiAgY29uc3RydWN0b3IgKHByb2ZpbGUpIHtcclxuICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+ODl+ODvOODq+WIneacn+WMllxyXG4gICAgdGhpcy5wb29sID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlKVxyXG5cclxuICAgIC8vIOikh+aVsOihjOOCueODhuODvOODiOODoeODs+ODiOWvvuW/nFxyXG4gICAgbGV0IHByb2ZpbGVNdWx0aSA9IHttdWx0aXBsZVN0YXRlbWVudHM6IHRydWV9XHJcbiAgICBPYmplY3QuYXNzaWduKHByb2ZpbGVNdWx0aSwgcHJvZmlsZSlcclxuICAgIHRoaXMucG9vbE11bHRpID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlTXVsdGkpXHJcbiAgfVxyXG5cclxuICBzdGF0aWMgZm9ybWF0RGF0ZSAoZGF0ZSkge1xyXG4gICAgcmV0dXJuIG1vbWVudChkYXRlKS5mb3JtYXQoKS5zdWJzdHJpbmcoMCwgMTkpLnJlcGxhY2UoJ1QnLCAnICcpXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBzcWxcclxuICAgKi9cclxuICBxdWVyeSAoc3FsKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pnorrnq4tcclxuICAgIC8vIGxldCBjb24gPSBhd2FpdCB0aGlzLmdldENvbigpO1xyXG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcclxuICAgICAgLnRoZW4oXHJcbiAgICAgICAgKGNvbikgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAgICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXHJcbiAgICAgICAgICAgICAgY29uLnF1ZXJ5KHNxbCwgKGUsIHJlcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8g44Kz44ON44Kv44K344On44Oz6ZaL5pS+XHJcbiAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpXHJcbiAgICAgICAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICAgICAgICByZWplY3QoZSlcclxuICAgICAgICAgICAgICAgIH0gZWxzZSByZXNvbHZlKHJlcylcclxuICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGVcclxuICAgICAgfSlcclxuICB9O1xyXG5cclxuICBhc3luYyBxdWVyeUluc2VydF8gKHNxbCkge1xyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZFxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdGFibGVcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7zjgIFudWxs44CBamF2YXNjcmlwdC0+bXlzcWzml6Xku5jlpInmj5vjgavjgoLlr77lv5xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICBhc3luYyBxdWVyeUluc2VydCAodGFibGUsIGRhdGEgPSB7fSwgZGF0YVNxbCA9IHt9KSB7XHJcbiAgICAvLyBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpO1xyXG4gICAgLy8gcmV0dXJuIHJlcy5pbnNlcnRJZDtcclxuXHJcbiAgICBsZXQgc3FsID0gYElOU0VSVCBJTlRPICR7dGFibGV9IGBcclxuXHJcbiAgICBsZXQgbWFwID0gbmV3IE1hcCgpXHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdID09PSBudWxsKSB7XHJcbiAgICAgICAgbWFwLnNldChrLCAnTlVMTCcpXHJcbiAgICAgIH0gZWxzZSBpZiAoZGF0YVtrXS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnRGF0ZScpIHtcclxuICAgICAgICAvLyDml6Xku5jjgpLlpInmj5tcclxuICAgICAgICBtYXAuc2V0KGssIGBcIiR7TXlTUUwuZm9ybWF0RGF0ZShkYXRhW2tdKX1cImApXHJcbiAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgbWFwLnNldChrLCBgJHtteXNxbC5lc2NhcGUoZGF0YVtrXSl9YClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xyXG4gICAgICBtYXAuc2V0KGssIGRhdGFTcWxba10gPT09IG51bGwgPyAnTlVMTCcgOiBkYXRhU3FsW2tdKVxyXG4gICAgfVxyXG5cclxuICAgIHNxbCArPSBgKCAke1suLi5tYXAua2V5cygpXS5qb2luKCcsJyl9ICkgYFxyXG5cclxuICAgIHNxbCArPSBgVkFMVUVTKCAke1suLi5tYXAudmFsdWVzKCldLmpvaW4oJywnKX0gKSBgXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgcmV0dXJuIHJlcy5pbnNlcnRJZFxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gdGFibGVcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gZmlsdGVyIFNRTCBVUERBVEXjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjga5XSEVSReWPpVxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhIOaWh+Wtl+WIl+OBruODkeODqeODoeODvOOCv+ODvFxyXG4gICAqIEBwYXJhbSB7T2JqZWN0fSBkYXRhU3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xyXG4gICAqL1xyXG4gIGFzeW5jIHF1ZXJ5VXBkYXRlICh0YWJsZSwgZmlsdGVyLCBkYXRhLCBkYXRhU3FsKSB7XHJcbiAgICBsZXQgc3FsID0gYFVQREFURSAke3RhYmxlfSBTRVQgYFxyXG5cclxuICAgIGxldCB1cGRhdGVzID0gW11cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YSkpIHtcclxuICAgICAgdXBkYXRlcy5wdXNoKGAke2t9PSR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApXHJcbiAgICB9XHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGFTcWwpKSB7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke2RhdGFTcWxba119YClcclxuICAgIH1cclxuICAgIHNxbCArPSB1cGRhdGVzLmpvaW4oJywnKVxyXG5cclxuICAgIHNxbCArPSBgIFdIRVJFICR7ZmlsdGVyfSBgXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbiAgLy8gZW5hYmxlIHRvIHVzZSBtdWx0aXBsZSBzdGF0ZW1lbnRzXHJcbiAgYXN5bmMgcXVlcnlNdWx0aSAoc3FsKSB7XHJcbiAgICBsZXQgcG9vbFN3YXAgPSB0aGlzLnBvb2xcclxuICAgIHRoaXMucG9vbCA9IHRoaXMucG9vbE11bHRpXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgdGhpcy5xdWVyeShzcWwpXHJcbiAgICAgIHJldHVybiByZXNcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIHRoaXMucG9vbCA9IHBvb2xTd2FwXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBhc3luYyBzdGFydFRyYW5zYWN0aW9uICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYFNUQVJUIFRSQU5TQUNUSU9OO2ApXHJcbiAgfVxyXG5cclxuICBhc3luYyBjb21taXQgKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgQ09NTUlUO2ApXHJcbiAgfVxyXG5cclxuICBhc3luYyByb2xsYmFjayAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBST0xMQkFDSztgKVxyXG4gIH1cclxuXHJcbiAgc3RyZWFtaW5nUXVlcnkgKHNxbCwgb25SZXN1bHQgPSAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IChlKSA9PiB7fSkge1xyXG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcclxuICAgICAgLnRoZW4oXHJcbiAgICAgICAgKGNvbikgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAgICAgICBhc3luYyAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXHJcbiAgICAgICAgICAgICAgY29uLnF1ZXJ5KHNxbClcclxuICAgICAgICAgICAgICAgIC5vbigncmVzdWx0JyxcclxuICAgICAgICAgICAgICAgICAgKHJlY29yZCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbi5wYXVzZSgpXHJcbiAgICAgICAgICAgICAgICAgICAgb25SZXN1bHQocmVjb3JkKVxyXG4gICAgICAgICAgICAgICAgICAgIGNvbi5yZXN1bWUoKVxyXG4gICAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlcnJvcicsIChlKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIG9uRXJyb3IoZSlcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgICAgICAub24oJ2VuZCcsICgpID0+IHtcclxuICAgICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxyXG4gICAgICAgICAgICAgICAgICByZXNvbHZlKClcclxuICAgICAgICAgICAgICAgIH0pXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIClcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgICAgLmNhdGNoKChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZVxyXG4gICAgICB9KVxyXG4gIH1cclxuXHJcbiAgZ2V0Q29uICgpIHtcclxuICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgIC8vIOODl+ODvOODq+OBi+OCieOBruOCs+ODjeOCr+OCt+ODp+ODs+eNsuW+l1xyXG4gICAgICAgIHRoaXMucG9vbC5nZXRDb25uZWN0aW9uKChlLCBjb24pID0+IHtcclxuICAgICAgICAgIGlmIChlKSB7XHJcbiAgICAgICAgICAgIHJlamVjdChlKVxyXG4gICAgICAgICAgfSBlbHNlIHtcclxuICAgICAgICAgICAgcmVzb2x2ZShjb24pXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgKVxyXG4gICAgICAuY2F0Y2goXHJcbiAgICAgICAgKGUpID0+IHtcclxuICAgICAgICAgIHRocm93IGVcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICB9O1xyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIFBhY2tldCB7XHJcbiAgY29uc3RydWN0b3IgKHBhY2tldFNpemUpIHtcclxuICAgIHRoaXMucGFja2V0U2l6ZSA9IHBhY2tldFNpemVcclxuICAgIHRoaXMub25QYWNrZXRTdGFydCA9IG51bGxcclxuICAgIHRoaXMub25QYWNrZXQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0RW5kID0gbnVsbFxyXG4gICAgdGhpcy5jb3VudCA9IDBcclxuICAgIHRoaXMucGFja2V0Q291bnQgPSAwXHJcbiAgfVxyXG5cclxuICBhc3luYyBzdWJtaXQgKGFyZykge1xyXG4gICAgLy8gcGFja2V0U2l6ZeOBruWbnuaVsOOBlOOBqOOBq+OAgeWIneacn+WMluOCkuWRvOOBs+WHuuOBmVxyXG4gICAgaWYgKHRoaXMuY291bnQgJSB0aGlzLnBhY2tldFNpemUgPT09IDApIHtcclxuICAgICAgaWYgKHRoaXMub25QYWNrZXRTdGFydCkge1xyXG4gICAgICAgIGF3YWl0IHRoaXMub25QYWNrZXRTdGFydCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBpZiAodGhpcy5vblBhY2tldCkge1xyXG4gICAgICBhd2FpdCB0aGlzLm9uUGFja2V0KGFyZylcclxuICAgIH1cclxuICAgIHRoaXMuY291bnQrK1xyXG4gICAgLy8gcGFja2V0U2l6ZeOBruWbnuaVsOOBlOOBqOOBq+OAgee1guS6huWHpueQhuOCkuWRvOOBs+WHuuOBmVxyXG4gICAgaWYgKHRoaXMuY291bnQgJSB0aGlzLnBhY2tldFNpemUgPT09IDApIHtcclxuICAgICAgdGhpcy5jbG9zZSgpXHJcbiAgICAgIHRoaXMucGFja2V0Q291bnQrK1xyXG4gICAgfVxyXG4gIH1cclxuICBjbG9zZSAoKSB7XHJcbiAgICBpZiAodGhpcy5vblBhY2tldEVuZCkge1xyXG4gICAgICB0aGlzLm9uUGFja2V0RW5kKHRoaXMucGFja2V0Q291bnQpXHJcbiAgICB9XHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB1dGlsRXJyb3IgZnJvbSAnLi9lcnJvcidcclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBSZXBvcnQge1xyXG4gIGNvbnN0cnVjdG9yICgpIHtcclxuICAgIHRoaXMucmVjb3JkID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3JzID0gW11cclxuICAgIHRoaXMuaXRlcmF0b3IgPSBudWxsXHJcbiAgfVxyXG5cclxuICBzZXR1cEl0ZXJhdG9yICgpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IoKVxyXG4gICAgdGhpcy5pdGVyYXRvcnMucHVzaCh0aGlzLml0ZXJhdG9yKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcGhhc2UgKG5hbWUgPSAnJywgZm4gPSBhc3luYyAoKSA9PiB7fSkge1xyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKClcclxuXHJcbiAgICBsZXQgcmVjID0ge31cclxuXHJcbiAgICB0cnkge1xyXG4gICAgICBsZXQgcmVzID0gYXdhaXQgZm4oKVxyXG5cclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnc3VjY2VzcycsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiByZXNcclxuICAgICAgfSlcclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogdXRpbEVycm9yLnBhcnNlKGUpXHJcbiAgICAgIH0pXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci50b3RhbCkge1xyXG4gICAgICAgIE9iamVjdC5hc3NpZ24ocmVjLCB7XHJcbiAgICAgICAgICBpdGVyYXRvcjogdGhpcy5pdGVyYXRvclxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgICAgdGhpcy5yZWNvcmQucHVzaChyZWMpXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICBpU3VjY2VzcyAobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLnN1Y2Nlc3MobmV3UmVjb3JkKVxyXG4gIH1cclxuXHJcbiAgaUVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IuZXJyb3IodXRpbEVycm9yLnBhcnNlKG5ld1JlY29yZCkpXHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQgKCkge1xyXG4gICAgbGV0IGl0ZUVycm9yID0gdGhpcy5pdGVyYXRvcnMuZmluZChlID0+IGUuZXJyb3JPY3VycmVkKCkpXHJcbiAgICBsZXQgcGhhRXJyb3IgPSBmYWxzZVxyXG4gICAgZm9yIChsZXQgcmVjIG9mIHRoaXMucmVjb3JkKSB7XHJcbiAgICAgIGlmIChyZWMudHlwZSA9PT0gJ2Vycm9yJykge1xyXG4gICAgICAgIHBoYUVycm9yID0gdHJ1ZVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIHJldHVybiBpdGVFcnJvciB8fCBwaGFFcnJvclxyXG4gIH1cclxuXHJcbiAgcHVibGlzaCAoKSB7XHJcbiAgICBpZiAodGhpcy5lcnJvck9jdXJyZWQoKSkge1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKHRoaXMucmVjb3JkKVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIHRoaXMucmVjb3JkXHJcbiAgfVxyXG59XHJcblxyXG5jbGFzcyBJdGVyYXRvciB7XHJcbiAgY29uc3RydWN0b3IgKCkge1xyXG4gICAgdGhpcy50b3RhbCA9IDBcclxuICAgIHRoaXMudHJhY2UgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IHtcclxuICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICByZWNvcmRzOiBbXVxyXG4gICAgICB9LFxyXG4gICAgICBlcnJvcjoge1xyXG4gICAgICAgIHRvdGFsOiAwLFxyXG4gICAgICAgIHJlY29yZHM6IFtdXHJcbiAgICAgIH1cclxuICAgIH1cclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLnRyYWNlLnN1Y2Nlc3MucmVjb3Jkcy5wdXNoKG5ld1JlY29yZClcclxuICAgIH1cclxuICAgIHRoaXMudHJhY2Uuc3VjY2Vzcy50b3RhbCsrXHJcbiAgICB0aGlzLnRvdGFsKytcclxuICB9XHJcbiAgZXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgLy8g55u05YmN44Gu44Ko44Op44O844KS5Y+W5b6XXHJcbiAgICBsZXQgbGFzdEVycm9yID0gbnVsbFxyXG4gICAgbGV0IGluZGV4ID0gdGhpcy50cmFjZS5lcnJvci5yZWNvcmRzLmxlbmd0aFxyXG4gICAgaWYgKGluZGV4KSB7XHJcbiAgICAgIGxhc3RFcnJvciA9IHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkc1tpbmRleCAtIDFdXHJcbiAgICB9XHJcblxyXG4gICAgLy8g55u05YmN44Go5ZCM44GY44Ko44Op44O844Gv55yB44GPXHJcbiAgICBpZiAoSlNPTi5zdHJpbmdpZnkobGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMudHJhY2UuZXJyb3IucmVjb3Jkcy5wdXNoKG5ld1JlY29yZClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy50cmFjZS5lcnJvci50b3RhbCsrXHJcbiAgICB0aGlzLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy50cmFjZS5lcnJvci50b3RhbFxyXG4gIH1cclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBUZXh0VXRpbCB7XHJcbiAgc3RhdGljIHN1YnN0cjggKHRleHQsIGxlbiwgdHJ1bmNhdGlvbikge1xyXG4gICAgaWYgKHRydW5jYXRpb24gPT09IHVuZGVmaW5lZCkgeyB0cnVuY2F0aW9uID0gJycgfVxyXG4gICAgdmFyIHRleHRBcnJheSA9IHRleHQuc3BsaXQoJycpXHJcbiAgICB2YXIgY291bnQgPSAwXHJcbiAgICB2YXIgc3RyID0gJydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgdGV4dEFycmF5Lmxlbmd0aDsgaSsrKSB7XHJcbiAgICAgIHZhciBuID0gZXNjYXBlKHRleHRBcnJheVtpXSlcclxuICAgICAgaWYgKG4ubGVuZ3RoIDwgNCkgY291bnQrK1xyXG4gICAgICBlbHNlIGNvdW50ICs9IDJcclxuICAgICAgaWYgKGNvdW50ID4gbGVuKSB7XHJcbiAgICAgICAgcmV0dXJuIHN0ciArIHRydW5jYXRpb25cclxuICAgICAgfVxyXG4gICAgICBzdHIgKz0gdGV4dC5jaGFyQXQoaSlcclxuICAgIH1cclxuICAgIHJldHVybiB0ZXh0XHJcbiAgfVxyXG59XHJcbiJdfQ==
