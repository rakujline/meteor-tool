var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/route/upload/image.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

// WebApp.connectHandlers.use('/upload', (req, res, next) => {
//   res.writeHead(200);
//   res.end(`Hello world from: ${Meteor.release}`);
// });

var _fs = require('fs');

var _fs2 = _interopRequireDefault(_fs);

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

// Requires multiparty

var _connectMultiparty = require('connect-multiparty');

var _connectMultiparty2 = _interopRequireDefault(_connectMultiparty);

var _importsCollections = require('../../../imports/collections');

var multipartyMiddleware = (0, _connectMultiparty2['default'])();

var route = '/upload/image';

// WebApp.connectHandlers.use('/upload', fuc.uploadFile );
WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, function (req, resp) {
  // don't forget to delete all req.files when done

  var reader = Meteor.wrapAsync(_fs2['default'].readFile);
  var writer = Meteor.wrapAsync(_fs2['default'].writeFile);
  var uploadId = (0, _uniqid2['default'])();

  var _iteratorNormalCompletion = true;
  var _didIteratorError = false;
  var _iteratorError = undefined;

  try {
    for (var _iterator = req.files.file[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
      var file = _step.value;

      var data = reader(file.path);
      // ファイル名の重複を避けるため、一意のファイル名を作成する
      // 楽天のファイル名文字数制限20に合わせる
      var filename = (0, _uniqid2['default'])() + '.jpg';

      // set the correct path for the file not the temporary one from the API:
      var savePath = req.body.imagedir + '/' + filename;

      // copy the data from the req.files.file.path and paste it to file.path

      // アップロード結果を記録する
      var doc = {
        uploadId: uploadId,
        clientFileName: file.name,
        uploadedFileName: filename
      };

      try {
        writer(savePath, data);
      } catch (err) {
        doc.error = err;
      }
      _importsCollections.Uploads.insert(doc);

      delete file;
    }
  } catch (err) {
    _didIteratorError = true;
    _iteratorError = err;
  } finally {
    try {
      if (!_iteratorNormalCompletion && _iterator['return']) {
        _iterator['return']();
      }
    } finally {
      if (_didIteratorError) {
        throw _iteratorError;
      }
    }
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"cubemig.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube/cubemig.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _crypto = require('crypto');

var _crypto2 = _interopRequireDefault(_crypto);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsUtilReport = require('../../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsCollectionGroups = require('../../imports/collection/groups');

var _importsCollectionFilters = require('../../imports/collection/filters');

var tag = 'cubemig';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.migrate', function callee$0$0(config) {
  var report, filter, testQuery, dstDb;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsCollectionFilters.Filter(config.srcFilterId);
        testQuery = 'SHOW DATABASES';
        dstDb = new _importsUtilMysql2['default'](config.dst.cred);
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(report.phase('Connect to Destination', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(dstDb.query(testQuery));

              case 2:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 6:
        context$1$0.next = 8;
        return regeneratorRuntime.awrap(report.phase('Select loop in source', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this2 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  mobileNull: function mobileNull(record) {
                    var sql, couponCd, couponName, discountPrice, _res;

                    return regeneratorRuntime.async(function mobileNull$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          sql = '\n\n                INSERT dtb_customer\n                ( `customer_id`, `status`, `sex`, `job`, `country_id`, `pref`, `name01`, `name02`, `kana01`, `kana02`, `company_name`, `zip01`, `zip02`, `zipcode`, `addr01`, `addr02`, `email`, `tel01`, `tel02`, `tel03`, `fax01`, `fax02`, `fax03`, `birth`, `password`, `salt`, `secret_key`, `first_buy_date`, `last_buy_date`, `buy_times`, `buy_total`, `note`, `create_date`, `update_date`, `del_flg` )\n\n                VALUES( ' + record.customer_id + ' , ' + record.status + ' , ' + record.sex + ' , ' + record.job + ' , ' + record.country_id + ' , ' + record.pref + ' , ' + record.name01 + ' , ' + record.name02 + ' , ' + record.kana01 + ' , ' + record.kana02 + ' , ' + record.company_name + ' , ' + record.zip01 + ' , ' + record.zip02 + ' , ' + record.zipcode + ' , ' + record.addr01 + ' , ' + record.addr02 + ' , ' + record.email + ' , ' + record.tel01 + ' , ' + record.tel02 + ' , ' + record.tel03 + ' , ' + record.fax01 + ' , ' + record.fax02 + ' , ' + record.fax03 + ' , ' + record.birth + ' , ' + record.password + ' , ' + record.salt + ' , ' + record.secret_key + ' , ' + record.first_buy_date + ' , ' + record.last_buy_date + ' , ' + record.buy_times + ' , ' + record.buy_total + ' , ' + record.note + ' , ' + record.create_date + ' , ' + record.update_date + ' , ' + record.del_flg + ' )\n                \n                ';
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer', {
                            customer_id: record.customer_id,
                            status: record.status,
                            sex: record.sex,
                            job: record.job,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            email: record.email,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            birth: record.birth,
                            password: record.password,
                            salt: record.salt,
                            secret_key: record.secret_key,
                            first_buy_date: record.first_buy_date,
                            last_buy_date: record.last_buy_date,
                            buy_times: record.buy_times,
                            buy_total: record.buy_total,
                            note: record.note,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 4:
                          context$3$0.next = 9;
                          break;

                        case 6:
                          context$3$0.prev = 6;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 9:
                          context$3$0.prev = 9;
                          context$3$0.next = 12;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('dtb_customer_address', {
                            customer_address_id: null,
                            customer_id: record.customer_id,
                            country_id: record.country_id,
                            pref: record.pref,
                            name01: record.name01,
                            name02: record.name02,
                            kana01: record.kana01,
                            kana02: record.kana02,
                            company_name: record.company_name,
                            zip01: record.zip01,
                            zip02: record.zip02,
                            zipcode: record.zipcode,
                            addr01: record.addr01,
                            addr02: record.addr02,
                            tel01: record.tel01,
                            tel02: record.tel02,
                            tel03: record.tel03,
                            fax01: record.fax01,
                            fax02: record.fax02,
                            fax03: record.fax03,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 12:
                          context$3$0.next = 17;
                          break;

                        case 14:
                          context$3$0.prev = 14;
                          context$3$0.t1 = context$3$0['catch'](9);

                          report.iError(context$3$0.t1);

                        case 17:
                          context$3$0.prev = 17;
                          context$3$0.next = 20;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_mailmaga_customer', {
                            id: null,
                            customer_id: record.customer_id,
                            mailmaga_flg: record.mailmaga_flg,
                            create_date: record.create_date,
                            update_date: record.update_date,
                            del_flg: record.del_flg
                          }));

                        case 20:
                          context$3$0.next = 25;
                          break;

                        case 22:
                          context$3$0.prev = 22;
                          context$3$0.t2 = context$3$0['catch'](17);

                          report.iError(context$3$0.t2);

                        case 25:
                          couponCd = _crypto2['default'].randomBytes(8).toString('base64').substring(0, 11);
                          couponName = record.name01 + ' ' + record.name02 + ' 様 ご優待クーポン 会員番号:' + record.customer_id;
                          discountPrice = record.point + 500;
                          context$3$0.prev = 28;
                          context$3$0.next = 31;
                          return regeneratorRuntime.awrap(dstDb.queryInsert('plg_coupon', {
                            coupon_id: null,
                            coupon_cd: couponCd,
                            coupon_type: 3, // 全商品
                            coupon_name: couponName,
                            discount_type: 1,
                            coupon_use_time: 1,
                            coupon_release: 1,
                            discount_price: discountPrice,
                            discount_rate: null,
                            enable_flag: 1,
                            coupon_member: 1,
                            coupon_lower_limit: null,
                            customer_id: record.customer_id,
                            available_from_date: '2018-04-02 00:00:00',
                            available_to_date: '2019-05-02 00:00:00',
                            del_flg: 0
                          }, {
                            create_date: 'NOW()',
                            update_date: 'NOW()'
                          }));

                        case 31:
                          _res = context$3$0.sent;
                          context$3$0.next = 37;
                          break;

                        case 34:
                          context$3$0.prev = 34;
                          context$3$0.t3 = context$3$0['catch'](28);

                          report.iError(context$3$0.t3);

                        case 37:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this2, [[1, 6], [9, 14], [17, 22], [28, 34]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        report.iError(e);

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this2);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 8:
        return context$1$0.abrupt('return', report.publish());

      case 9:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, 'cubemig.serverCheck', function cubemigServerCheck(profile) {
  var db, res;
  return regeneratorRuntime.async(function cubemigServerCheck$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        db = new _importsUtilMysql2['default'](profile);
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(db.query('SHOW DATABASES'));

      case 3:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

// setup group
//

// let plug = group.getPlug();

// checking connection
//

// process for each members
//

// // 値を整理
// for (let key of Object.keys(record)) {
//   if (record[key] === null);
//   else if (record[key].constructor.name === 'Date') {
//     // 日付を変換
//     record[key] = MySQL.formatDate(record[key]);
//     record[key] = `"${record[key]}"`;
//   }
// }

// dtb_customer に保存

// dtb_customer_address

// メルマガプラグイン plg_mailmaga_customer

// クーポン発行（ECCUBE2のポイント還元）
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/collection.js                                                                                         //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilMongo = require('../../imports/util/mongo');

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.collection';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.find', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var projection = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.find(query, { projection: projection }).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.aggregate', function callee$0$0(plug) {
  var query = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
  var coll, res;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        context$1$0.next = 2;
        return regeneratorRuntime.awrap(_importsUtilMongo.MongoCollection.get(plug, plug.collection));

      case 2:
        coll = context$1$0.sent;
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(coll.aggregate(query).toArray());

      case 5:
        res = context$1$0.sent;
        return context$1$0.abrupt('return', res);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/jline/items.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsServiceItems = require('../../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'jline.items';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.setImage', function callee$0$0(plug, uploadId, model) {
  var class1 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var class2 = arguments.length <= 4 || arguments[4] === undefined ? null : arguments[4];
  var itemcon, uploaded;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.setImage(uploadId, model, class1, class2));

      case 5:
        uploaded = context$1$0.sent;
        return context$1$0.abrupt('return', uploaded);

      case 7:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.cleanImage', function callee$0$0(plug, model) {
  var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
  var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
  var itemcon;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        itemcon = new _importsServiceItems2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(itemcon.init(plug));

      case 3:
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemcon.cleanImage(model, class1, class2));

      case 5:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

/**
 * 指定された条件に一致するitemsコレクション内のドキュメントに、
 * アップロード済み画像を関連付けます。
 * @param
 */

/**
 * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
 */
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/cube.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceCube3api = require('../imports/service/cube3api');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'cube';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report, filter, itemController, targetDB, api;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 5;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 5:
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('在庫の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({

                  'UPDATE': function UPDATE(item, context) {
                    var quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;
                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 5:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 9:
        return context$1$0.abrupt('return', report.publish());

      case 10:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibItem', function callee$0$0(config) {
  var filter, targetDB, api, itemController, report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        targetDB = new _importsUtilMysql2['default'](config.cube3DB);
        api = new _importsServiceCube3api.Cube3Api(targetDB);
        itemController = new _importsServiceItems2['default']();
        context$1$0.next = 6;
        return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

      case 6:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 9;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3への商品登録', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  'INSERT': function INSERT(item, context) {
                    var col, cubeItem, insertRes;
                    return regeneratorRuntime.async(function INSERT$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.creator_id, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productCreate(cubeItem));

                        case 7:
                          insertRes = context$3$0.sent;
                          context$3$0.next = 10;
                          return regeneratorRuntime.awrap(col.update({
                            _id: item._id
                          }, {
                            $set: {
                              'mall.sharakuShop.product_id': insertRes.res.product_id,
                              'mall.sharakuShop.product_class_id': insertRes.res.product_class_id,
                              'mall.sharakuShop.product_stock_id': insertRes.res.product_stock_id
                            }
                          }));

                        case 10:

                          report.iSuccess();
                          context$3$0.next = 16;
                          break;

                        case 13:
                          context$3$0.prev = 13;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 16:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3, [[1, 13]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 9:
        context$1$0.next = 11;
        return regeneratorRuntime.awrap(report.phase('ECCUBE3商品情報の更新', function callee$1$0() {
          var res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this5 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                context$2$0.next = 2;
                return regeneratorRuntime.awrap(filter.foreach({
                  'UPDATE': function UPDATE(item, context) {
                    var col, cubeItem, quantity;
                    return regeneratorRuntime.async(function UPDATE$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          col = context.collection;
                          context$3$0.prev = 1;
                          context$3$0.next = 4;
                          return regeneratorRuntime.awrap(itemController.convertItemCube3(config.creator_id, item));

                        case 4:
                          cubeItem = context$3$0.sent;
                          context$3$0.next = 7;
                          return regeneratorRuntime.awrap(api.productImageUpdate(cubeItem));

                        case 7:
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(api.productUpdate(cubeItem));

                        case 9:
                          context$3$0.next = 11;
                          return regeneratorRuntime.awrap(api.productTagUpdate(cubeItem));

                        case 11:
                          context$3$0.next = 13;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 13:
                          quantity = context$3$0.sent;
                          context$3$0.next = 16;
                          return regeneratorRuntime.awrap(api.updateStock(item.mall.sharakuShop.product_class_id, quantity));

                        case 16:

                          report.iSuccess();
                          context$3$0.next = 22;
                          break;

                        case 19:
                          context$3$0.prev = 19;
                          context$3$0.t0 = context$3$0['catch'](1);

                          report.iError(context$3$0.t0);

                        case 22:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this5, [[1, 19]]);
                  }
                }, function callee$2$0(e) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        throw e;

                      case 1:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this5);
                }));

              case 2:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 4:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 11:
        return context$1$0.abrupt('return', report.publish());

      case 12:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 商品情報登録と更新

// クライアントが参照するための処理結果作成オブジェクト

// item データベースへの登録
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"robotin.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/robotin.js                                                                                                  //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilPacket = require('../imports/util/packet');

var _importsUtilPacket2 = _interopRequireDefault(_importsUtilPacket);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var tag = 'robotinPostlabel';

var ORDER_NO_PREFIX = '受注番号：';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.addItemCode', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Robot-in 送り状に商品コードを記載', function callee$1$0() {
          var workdir, orderCsv;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                workdir = config.workdir + '/postlabel';
                context$2$0.prev = 1;
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 4:
                context$2$0.next = 8;
                break;

              case 6:
                context$2$0.prev = 6;
                context$2$0.t0 = context$2$0['catch'](1);

              case 8:
                context$2$0.prev = 8;
                context$2$0.next = 11;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 11:
                context$2$0.next = 26;
                break;

              case 13:
                context$2$0.prev = 13;
                context$2$0.t1 = context$2$0['catch'](8);
                context$2$0.next = 17;
                return regeneratorRuntime.awrap(_fsExtra2['default'].readFile(workdir + '/' + config.orderCsvPrefix + '.csv'));

              case 17:
                orderCsv = context$2$0.sent;
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_iconvLite2['default'].decode(orderCsv, 'SJIS'));

              case 20:
                orderCsv = context$2$0.sent;
                context$2$0.next = 23;
                return regeneratorRuntime.awrap(_iconvLite2['default'].encode(orderCsv, 'UTF-8'));

              case 23:
                orderCsv = context$2$0.sent;
                context$2$0.next = 26;
                return regeneratorRuntime.awrap(config.postages.forEach(function callee$3$0(e) {
                  var postCSV;
                  return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
                    while (1) switch (context$4$0.prev = context$4$0.next) {
                      case 0:
                        console.log('csvPrefix: ' + e.csvPrefix);
                        // await e.id.forEach(
                        //   async id => {
                        //     console.log(`${id.order}: ${recOrder[id.order]}`)
                        //   }
                        // )
                        // console.log(`${config.itemCodeColumn}: ${recOrder[config.itemCodeColumn]}`)

                        // 送り状CSVを開き、配送ごとに商品コードを記載する
                        postCSV = _fsExtra2['default'].createReadStream(workdir + '/' + e.csvPrefix + '.csv');

                        postCSV.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({
                          columns: true
                        }));

                      case 3:
                      case 'end':
                        return context$4$0.stop();
                    }
                  }, null, _this);
                }));

              case 26:
                throw new _meteorMeteor.Meteor.Error('正しい作業ディレクトリが用意されていませんでした。下記のフォルダへ受注CSV、送り状CSVをコピーしてください。\n[' + workdir + ']');

              case 27:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2, [[1, 6], [8, 13]]);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// Robot-in
// 送り状に商品コードを記載

// クライアントが参照するための処理結果作成オブジェクト

// 作業フォルダを作成する

// workdir が準備されていたら実行する

// const w = fsExtra.createWriteStream(`${workdir}/${config.orderSavefile}`)

// orderCsv.pipe(iconv.decodeStream('SJIS'))
//   .pipe(iconv.encodeStream('UTF-8'))
//   .pipe(csv.parse({
//     columns: true
//   }))
//   .pipe(csv.transform(
//     async (recOrder, callback) => {
//       let err = null
//       try {
// 送り状の種類ごとに繰り返す

//       } catch (e) {
//         err = e
//       }
//       callback(err, recOrder)
//     }
//   ))
// .pipe(csv.stringify({header: true}))
// .pipe(iconv.decodeStream('UTF-8'))
// .pipe(iconv.encodeStream('SJIS'))
// .pipe(w)
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/tooltest.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsUtilMysql = require('../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var _meteorMeteor = require('meteor/meteor');

var tag = 'tool';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.test', function callee$0$0(config) {
  var report, filter, newLocal;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
        context$1$0.next = 4;
        return regeneratorRuntime.awrap(filter.foreach({}, function callee$1$0(e) {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                throw e;

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 4:
        newLocal = context$1$0.sent;
        context$1$0.next = 7;
        return regeneratorRuntime.awrap(report.phase('フィルターテスト', function callee$1$0() {
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                return context$2$0.abrupt('return', newLocal);

              case 1:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this);
        }));

      case 7:
        return context$1$0.abrupt('return', report.publish());

      case 8:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// 商品情報更新

// クライアントが参照するための処理結果作成オブジェクト
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowma.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowma.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _importsServiceWowmaApi = require('../imports/service/wowmaApi');

var _importsServiceWowmaApi2 = _interopRequireDefault(_importsServiceWowmaApi);

var _importsUtilError = require('../imports/util/error');

var _importsUtilError2 = _interopRequireDefault(_importsUtilError);

var tag = 'wowma';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.updateItem.deliveryMethod', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品の配送方法を設定する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }]
                  }
                },
                // テスト検索条件設定
                // {
                //   $or: [
                //     {
                //       'mall.wowma.itemCode': 'gk-163'
                //     },
                //     {
                //       'mall.wowma.itemCode': '10004942' // JK-120
                //     }
                //     // {
                //     //   'mall.wowma.itemCode': '10005402'
                //     // },
                //     // {
                //     //   'mall.wowma.itemCode': '10004743'
                //     // }
                //   ]
                // }
                {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        context$3$0.t0 = Object;
                        context$3$0.t1 = item;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.convertItemWowmaCreateDeliveryMethod(item.itemCode));

                      case 4:
                        context$3$0.t2 = context$3$0.sent;
                        context$3$0.t0.assign.call(context$3$0.t0, context$3$0.t1, context$3$0.t2);
                        context$3$0.prev = 6;
                        context$3$0.next = 9;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 9:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 13:
                        context$3$0.prev = 13;
                        context$3$0.t3 = context$3$0['catch'](6);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t3));

                      case 16:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[6, 13]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateItem.open', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('Wowma! 商品データベース上の商品を公開する', function callee$1$0() {
          var itemController, cur, api;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    // {
                    //   $or: [
                    //     {
                    //       'mall.wowma.itemCode': 'gk-163'
                    //     }
                    //     // {
                    //     //   'mall.wowma.itemCode': '10005402'
                    //     // },
                    //     // {
                    //     //   'mall.wowma.itemCode': '10004743'
                    //     // }
                    //   ]
                    // }
                    ]
                  }
                }, {
                  // 商品コードの一覧を作る
                  $group: {
                    _id: '$mall.wowma.itemCode'
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.next = 9;
                return regeneratorRuntime.awrap(report.forEachOnCursor(cur, function callee$2$0(item) {
                  var res;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        item.saleStatus = 1;
                        item.limitedPasswd = 'NULL';
                        context$3$0.prev = 2;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(api.updateItem(item));

                      case 5:
                        res = context$3$0.sent;
                        return context$3$0.abrupt('return', { requestBody: item, response: res });

                      case 9:
                        context$3$0.prev = 9;
                        context$3$0.t0 = context$3$0['catch'](2);
                        throw Object.assign({ requestBody: item }, _importsUtilError2['default'].parse(context$3$0.t0));

                      case 12:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[2, 9]]);
                }));

              case 9:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.updateStock', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this5 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 在庫更新', function callee$1$0() {
          var itemController, cur, item, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, e, api, res;

          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                context$2$0.next = 5;
                return regeneratorRuntime.awrap(itemController.Items.aggregate([{
                  $match: {
                    $and: [{
                      'mall.wowma.itemCode': { $exists: 1 }
                    }
                    // テスト検索条件設定
                    //   ,{
                    //     $or: [
                    //       {
                    //         'mall.wowma.itemCode': '10005402'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': 'gk-163'
                    //       }
                    //       ,{
                    //         'mall.wowma.itemCode': '10004743'
                    //       }
                    //     ]
                    //   }
                    ]
                  }
                }, {
                  // 配送方法の違いを省く
                  $group: {
                    _id: {
                      itemCode: '$mall.wowma.itemCode',
                      choicesStockHorizontalCode: '$mall.wowma.HChoiceName',
                      choicesStockVerticalCode: '$mall.wowma.VChoiceName'
                    },
                    item: {
                      $first: '$_id'
                    }
                  }
                }, {
                  // 商品ページごと（商品コード）にグループ化する
                  $group: {
                    _id: '$_id.itemCode',
                    variations: {
                      $push: {
                        _id: '$item',
                        choicesStockHorizontalCode: '$_id.choicesStockHorizontalCode',
                        choicesStockVerticalCode: '$_id.choicesStockVerticalCode'
                      }
                    }
                  }
                }, {
                  $project: {
                    _id: 0,
                    itemCode: '$_id',
                    variations: '$variations'
                  }
                }]));

              case 5:
                cur = context$2$0.sent;

              case 6:
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(cur.hasNext());

              case 8:
                if (!context$2$0.sent) {
                  context$2$0.next = 53;
                  break;
                }

                context$2$0.next = 11;
                return regeneratorRuntime.awrap(cur.next());

              case 11:
                item = context$2$0.sent;
                _iteratorNormalCompletion = true;
                _didIteratorError = false;
                _iteratorError = undefined;
                context$2$0.prev = 15;
                _iterator = item.variations[Symbol.iterator]();

              case 17:
                if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                  context$2$0.next = 26;
                  break;
                }

                e = _step.value;
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(itemController.getStock(e._id));

              case 21:
                e.stock = context$2$0.sent;

                delete e._id;

              case 23:
                _iteratorNormalCompletion = true;
                context$2$0.next = 17;
                break;

              case 26:
                context$2$0.next = 32;
                break;

              case 28:
                context$2$0.prev = 28;
                context$2$0.t0 = context$2$0['catch'](15);
                _didIteratorError = true;
                _iteratorError = context$2$0.t0;

              case 32:
                context$2$0.prev = 32;
                context$2$0.prev = 33;

                if (!_iteratorNormalCompletion && _iterator['return']) {
                  _iterator['return']();
                }

              case 35:
                context$2$0.prev = 35;

                if (!_didIteratorError) {
                  context$2$0.next = 38;
                  break;
                }

                throw _iteratorError;

              case 38:
                return context$2$0.finish(35);

              case 39:
                return context$2$0.finish(32);

              case 40:
                api = new _importsServiceWowmaApi2['default'](config.wowmaApiPost, config.shopId);
                context$2$0.prev = 41;
                context$2$0.next = 44;
                return regeneratorRuntime.awrap(api.updateStock([item]));

              case 44:
                res = context$2$0.sent;

                report.iSuccess(res);
                context$2$0.next = 51;
                break;

              case 48:
                context$2$0.prev = 48;
                context$2$0.t1 = context$2$0['catch'](41);

                report.iError(context$2$0.t1);

              case 51:
                context$2$0.next = 6;
                break;

              case 53:
                cur.close();

              case 54:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this5, [[15, 28, 32, 40], [33,, 35, 39], [41, 48]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.searchItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this7 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, workdir, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this6 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.prev = 4;
                context$2$0.next = 7;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 7:
                context$2$0.next = 11;
                break;

              case 9:
                context$2$0.prev = 9;
                context$2$0.t0 = context$2$0['catch'](4);

              case 11:
                workdir = config.workdir + '/items_' + new Date().getTime();
                context$2$0.prev = 12;
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 15:
                context$2$0.next = 19;
                break;

              case 17:
                context$2$0.prev = 17;
                context$2$0.t1 = context$2$0['catch'](12);

              case 19:
                context$2$0.next = 21;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var options, repos, filename;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          options = JSON.parse(JSON.stringify(config.wowmaApi));

                          options.uri = options.uri + '/searchItemInfo';
                          options.qs.itemCode = item.mall.wowma.itemCode;

                          context$3$0.next = 5;
                          return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

                        case 5:
                          repos = context$3$0.sent;
                          filename = workdir + '/' + item.model + '.xml';
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(_fsExtra2['default'].writeFile(filename, repos));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this6);
                  } }));

              case 21:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 23:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this7, [[4, 9], [12, 17]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// WOWMA 商品の配送方法を設定する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 商品データベース上の商品を公開する

// クライアントが参照するための処理結果作成オブジェクト

//
// jline_engine 商品データベースへの接続

//
// 商品情報の作成

// 得られた商品ごとにAPIリクエストを発行

//
// WOWMA 在庫更新

// クライアントが参照するための処理結果作成オブジェクト

//
// 在庫情報の作成

// let resMongo = await cur.toArray()
// return resMongo

// リクエストボディ

// 在庫を設定する

//
// 在庫更新リクエスト

//
// WOWMA 商品検索

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 作業フォルダを作成する

// APIから取得した商品情報を保存する場所

// 作業フォルダを作成する

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/wowmaApi.js                                                                                                 //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var tag = 'wowmaApi';

_meteorMeteor.Meteor.methods(_defineProperty({}, tag + '.getItem', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('WOWMA! 商品情報取得', function callee$1$0() {
          var filter, itemController, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.WowmaApiItemFilter(config.wowmaApi, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                context$2$0.next = 6;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          report.iSuccess(item);

                        case 1:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this);
                  } }));

              case 6:
                res = context$2$0.sent;
                return context$2$0.abrupt('return', res);

              case 8:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}));

//
// WOWMA商品情報取得

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(config.workdir)
// } catch (e) {}

// // APIから取得した商品情報を保存する場所
// const workdir = `${config.workdir}/items_${(new Date()).getTime()}`
// // 作業フォルダを作成する
// try {
//   await fsExtra.mkdir(workdir)
// } catch (e) {}

// メインループ
//
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"yauct.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/yauct.js                                                                                                    //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
var _Meteor$methods;

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

var _importsUtilReport = require('../imports/util/report');

var _importsUtilReport2 = _interopRequireDefault(_importsUtilReport);

var _importsServiceDbfilter = require('../imports/service/dbfilter');

var _importsServiceItems = require('../imports/service/items');

var _importsServiceItems2 = _interopRequireDefault(_importsServiceItems);

var _meteorMeteor = require('meteor/meteor');

var _importsUtilPacket = require('../imports/util/packet');

var _importsUtilPacket2 = _interopRequireDefault(_importsUtilPacket);

var _fsExtra = require('fs-extra');

var _fsExtra2 = _interopRequireDefault(_fsExtra);

var _iconvLite = require('iconv-lite');

var _iconvLite2 = _interopRequireDefault(_iconvLite);

var _archiver = require('archiver');

var _archiver2 = _interopRequireDefault(_archiver);

var _csv = require('csv');

var _csv2 = _interopRequireDefault(_csv);

var _stream = require('stream');

var prefix = 'packet';
var tag = 'yauct';

_meteorMeteor.Meteor.methods((_Meteor$methods = {}, _defineProperty(_Meteor$methods, tag + '.order', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this2 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク受注', function callee$1$0() {
          var itemController, workdir, r, w;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 3;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 3:
                workdir = config.workdir + '/order';
                r = _fsExtra2['default'].createReadStream(workdir + '/' + config.orderLoadfile);
                w = _fsExtra2['default'].createWriteStream(workdir + '/' + config.orderSavefile);

                r.pipe(_iconvLite2['default'].decodeStream('SJIS')).pipe(_iconvLite2['default'].encodeStream('UTF-8')).pipe(_csv2['default'].parse({ columns: true })).pipe(_csv2['default'].transform(function callee$2$0(record, callback) {
                  var err;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        err = null;
                        context$3$0.prev = 1;
                        context$3$0.next = 4;
                        return regeneratorRuntime.awrap(itemController.getModelClass(record['管理番号']));

                      case 4:
                        record['管理番号'] = context$3$0.sent;
                        context$3$0.next = 10;
                        break;

                      case 7:
                        context$3$0.prev = 7;
                        context$3$0.t0 = context$3$0['catch'](1);

                        err = context$3$0.t0;

                      case 10:
                        callback(err, record);

                      case 11:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this, [[1, 7]]);
                })).pipe(_csv2['default'].stringify({ header: true })).pipe(_iconvLite2['default'].decodeStream('UTF-8')).pipe(_iconvLite2['default'].encodeStream('SJIS')).pipe(w);

              case 7:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this2);
        }));

      case 3:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _defineProperty(_Meteor$methods, tag + '.exhibit', function callee$0$0(config) {
  var report;
  return regeneratorRuntime.async(function callee$0$0$(context$1$0) {
    var _this4 = this;

    while (1) switch (context$1$0.prev = context$1$0.next) {
      case 0:
        report = new _importsUtilReport2['default']();
        context$1$0.next = 3;
        return regeneratorRuntime.awrap(report.phase('ヤフオク出品', function callee$1$0() {
          var filter, itemController, packet, workdir, uploaddir, cd, filename, name, fields, header, res;
          return regeneratorRuntime.async(function callee$1$0$(context$2$0) {
            var _this3 = this;

            while (1) switch (context$2$0.prev = context$2$0.next) {
              case 0:
                filter = new _importsServiceDbfilter.MongoDBFilter(config.itemsDB, config.profile);
                itemController = new _importsServiceItems2['default']();
                context$2$0.next = 4;
                return regeneratorRuntime.awrap(itemController.init(config.itemsDB));

              case 4:
                packet = new _importsUtilPacket2['default'](config.packetSize);
                context$2$0.prev = 5;
                context$2$0.next = 8;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(config.workdir));

              case 8:
                context$2$0.next = 12;
                break;

              case 10:
                context$2$0.prev = 10;
                context$2$0.t0 = context$2$0['catch'](5);

              case 12:
                workdir = config.workdir + '/work';
                context$2$0.next = 15;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(workdir));

              case 15:
                context$2$0.next = 17;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(workdir));

              case 17:
                uploaddir = config.workdir + '/upload';
                context$2$0.next = 20;
                return regeneratorRuntime.awrap(_fsExtra2['default'].remove(uploaddir));

              case 20:
                context$2$0.next = 22;
                return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(uploaddir));

              case 22:
                cd = null;
                filename = null;
                name = null;
                fields = ['管理番号', 'カテゴリ', 'タイトル', '説明', 'ストア内商品検索用キーワード', '開始価格', '即決価格', '値下げ交渉', '個数', '入札個数制限', '期間', '終了時間', '商品発送元の都道府県', '商品発送元の市区町村', '送料負担', '代金先払い、後払い', '落札ナビ決済方法設定', '商品の状態', '商品の状態備考', '返品の可否', '返品の可否備考', '画像1', '画像1コメント', '画像2', '画像2コメント', '画像3', '画像3コメント', '画像4', '画像4コメント', '画像5', '画像5コメント', '画像6', '画像6コメント', '画像7', '画像7コメント', '画像8', '画像8コメント', '画像9', '画像9コメント', '画像10', '画像10コメント', '最低評価', '悪評割合制限', '入札者認証制限', '自動延長', '早期終了', '商品の自動再出品', '自動値下げ', '最低落札価格', 'チャリティー', '注目のオークション', '太字テキスト', '背景色', 'ストアホットオークション', '目立ちアイコン', '贈答品アイコン', 'Tポイントオプション', 'アフィリエイトオプション', '荷物の大きさ', '荷物の重量', 'はこBOON', 'その他配送方法1', 'その他配送方法1料金表ページリンク', 'その他配送方法1全国一律価格', 'その他配送方法2', 'その他配送方法2料金表ページリンク', 'その他配送方法2全国一律価格', 'その他配送方法3', 'その他配送方法3料金表ページリンク', 'その他配送方法3全国一律価格', 'その他配送方法4', 'その他配送方法4料金表ページリンク', 'その他配送方法4全国一律価格', 'その他配送方法5', 'その他配送方法5料金表ページリンク', 'その他配送方法5全国一律価格', 'その他配送方法6', 'その他配送方法6料金表ページリンク', 'その他配送方法6全国一律価格', 'その他配送方法7', 'その他配送方法7料金表ページリンク', 'その他配送方法7全国一律価格', 'その他配送方法8', 'その他配送方法8料金表ページリンク', 'その他配送方法8全国一律価格', 'その他配送方法9', 'その他配送方法9料金表ページリンク', 'その他配送方法9全国一律価格', 'その他配送方法10', 'その他配送方法10料金表ページリンク', 'その他配送方法10全国一律価格', '海外発送', '配送方法・送料設定', '代引手数料設定', '消費税設定', 'JANコード・ISBNコード'];
                header = fields.map(function (v) {
                  return '"' + v + '"';
                }).join(',') + '\n';

                // パケット化開始時
                packet.onPacketStart = function callee$2$0(packetCount) {
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        name = prefix + ('00000' + packetCount).slice(-5);
                        cd = workdir + '/' + name;
                        filename = cd + '/' + config.csvFileName;
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].mkdir(cd));

                      case 5:
                        context$3$0.next = 7;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(header, 'Shift_JIS')));

                      case 7:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // パケット化時
                packet.onPacket = function callee$2$0(arg) {
                  var yauct, item, record, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, img, imgSrc, imgTgt;

                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        yauct = arg.yauct;
                        item = arg.item;
                        record = fields.map(function (v) {
                          return yauct[v] ? '"' + yauct[v] + '"' : '""';
                        }).join(',') + '\n';
                        context$3$0.next = 5;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].appendFile(filename, _iconvLite2['default'].encode(record, 'Shift_JIS')));

                      case 5:
                        _iteratorNormalCompletion = true;
                        _didIteratorError = false;
                        _iteratorError = undefined;
                        context$3$0.prev = 8;
                        _iterator = item.images[Symbol.iterator]();

                      case 10:
                        if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
                          context$3$0.next = 26;
                          break;
                        }

                        img = _step.value;
                        imgSrc = config.imagedir + '/' + img;
                        imgTgt = cd + '/' + img;
                        context$3$0.prev = 14;
                        context$3$0.next = 17;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].access(imgTgt));

                      case 17:
                        context$3$0.next = 23;
                        break;

                      case 19:
                        context$3$0.prev = 19;
                        context$3$0.t0 = context$3$0['catch'](14);
                        context$3$0.next = 23;
                        return regeneratorRuntime.awrap(_fsExtra2['default'].copyFile(imgSrc, imgTgt));

                      case 23:
                        _iteratorNormalCompletion = true;
                        context$3$0.next = 10;
                        break;

                      case 26:
                        context$3$0.next = 32;
                        break;

                      case 28:
                        context$3$0.prev = 28;
                        context$3$0.t1 = context$3$0['catch'](8);
                        _didIteratorError = true;
                        _iteratorError = context$3$0.t1;

                      case 32:
                        context$3$0.prev = 32;
                        context$3$0.prev = 33;

                        if (!_iteratorNormalCompletion && _iterator['return']) {
                          _iterator['return']();
                        }

                      case 35:
                        context$3$0.prev = 35;

                        if (!_didIteratorError) {
                          context$3$0.next = 38;
                          break;
                        }

                        throw _iteratorError;

                      case 38:
                        return context$3$0.finish(35);

                      case 39:
                        return context$3$0.finish(32);

                      case 40:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3, [[8, 28, 32, 40], [14, 19], [33,, 35, 39]]);
                };

                // パケット終了時
                packet.onPacketEnd = function callee$2$0(packetCount) {
                  var zip, zipname, output;
                  return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                    while (1) switch (context$3$0.prev = context$3$0.next) {
                      case 0:
                        zip = (0, _archiver2['default'])('zip');
                        zipname = uploaddir + '/' + name + '.zip';
                        output = _fsExtra2['default'].createWriteStream(zipname);

                        zip.pipe(output);
                        zip.directory(cd, false);
                        zip.finalize();

                      case 6:
                      case 'end':
                        return context$3$0.stop();
                    }
                  }, null, _this3);
                };

                // メインループ
                //

                context$2$0.next = 32;
                return regeneratorRuntime.awrap(filter.foreach({

                  'TARGET': function TARGET(item, context) {
                    var quantity, yauct;
                    return regeneratorRuntime.async(function TARGET$(context$3$0) {
                      while (1) switch (context$3$0.prev = context$3$0.next) {
                        case 0:
                          context$3$0.next = 2;
                          return regeneratorRuntime.awrap(itemController.getStock(item._id));

                        case 2:
                          quantity = context$3$0.sent;

                          if (!(quantity >= item.mall.yauct.minQuantity)) {
                            context$3$0.next = 9;
                            break;
                          }

                          context$3$0.next = 6;
                          return regeneratorRuntime.awrap(itemController.convertItemYauct(config['default'], item));

                        case 6:
                          yauct = context$3$0.sent;
                          context$3$0.next = 9;
                          return regeneratorRuntime.awrap(packet.submit({ yauct: yauct, item: item }));

                        case 9:
                        case 'end':
                          return context$3$0.stop();
                      }
                    }, null, _this3);
                  } }));

              case 32:
                res = context$2$0.sent;

                packet.close();

                return context$2$0.abrupt('return', res);

              case 35:
              case 'end':
                return context$2$0.stop();
            }
          }, null, _this4, [[5, 10]]);
        }));

      case 3:
        return context$1$0.abrupt('return', report.publish());

      case 4:
      case 'end':
        return context$1$0.stop();
    }
  }, null, this);
}), _Meteor$methods));

//
// ヤフオク受注ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 管理番号を置き換える

//
// ヤフオク出品ファイル

// クライアントが参照するための処理結果作成オブジェクト

// 初期化処理
//

// 繰り返し処理を任意の（packetSize）で分割

// 作業フォルダを作成する

// CSVファイルを作成し画像データを収集する場所

// ZIPファイルを保存する場所
// パケットフォルダ
// csvファイル
// パケット番号

// CSVフィールドを定義し、順番を確定する

// CSVファイルにフィールドを設定する

// csvファイルにレコード（商品テンプレート）を追加する

// 画像ファイルをコピー

// 同じファイルがある場合はコピーしない

// itemに定義されている最低必要在庫より多い商品を出品する
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// server/main.js                                                                                                     //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
require('../imports/collections');

require('./route/upload/image');
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"filters.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/filters.js                                                                                      //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _groups = require('./groups');

var Filters = new _meteorMongo.Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

var Filter = (function (_GroupBase) {
  _inherits(Filter, _GroupBase);

  function Filter(filterId) {
    var _this = this;

    _classCallCheck(this, Filter);

    var profile = Filters.findOne({
      _id: filterId
    });

    _get(Object.getPrototypeOf(Filter.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {

      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0() {
          var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
          var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table;
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, onError));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this);
        };
        break;

      default:
        throw new Error('invalid platform type');

    }
  }

  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */

  _createClass(Filter, [{
    key: 'foreach',
    value: function foreach() {
      var _this2 = this;

      var callbacks = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this2);
      } : arguments[1];

      var profile, count, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, filter;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this3 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              type: 'misc',
              query: {}
            });

            count = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              filter = _step.value;

              count[filter.type] = {
                query: filter.query,
                count: 0
              };
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record) {
              var _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, filter, query, exam;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion2 = true;
                    _didIteratorError2 = false;
                    _iteratorError2 = undefined;
                    context$3$0.prev = 3;
                    _iterator2 = profile.filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
                      context$3$0.next = 18;
                      break;
                    }

                    filter = _step2.value;
                    query = _mongoobject2['default'].unescape(filter.query);
                    exam = (0, _sift2['default'])(query);

                    if (!exam(record)) {
                      context$3$0.next = 15;
                      break;
                    }

                    count[filter.type].count++;

                    if (!(typeof callbacks[filter.type] !== 'undefined')) {
                      context$3$0.next = 14;
                      break;
                    }

                    context$3$0.next = 14;
                    return regeneratorRuntime.awrap(callbacks[filter.type](record));

                  case 14:
                    return context$3$0.abrupt('break', 18);

                  case 15:
                    _iteratorNormalCompletion2 = true;
                    context$3$0.next = 5;
                    break;

                  case 18:
                    context$3$0.next = 24;
                    break;

                  case 20:
                    context$3$0.prev = 20;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError2 = true;
                    _iteratorError2 = context$3$0.t0;

                  case 24:
                    context$3$0.prev = 24;
                    context$3$0.prev = 25;

                    if (!_iteratorNormalCompletion2 && _iterator2['return']) {
                      _iterator2['return']();
                    }

                  case 27:
                    context$3$0.prev = 27;

                    if (!_didIteratorError2) {
                      context$3$0.next = 30;
                      break;
                    }

                    throw _iteratorError2;

                  case 30:
                    return context$3$0.finish(27);

                  case 31:
                    return context$3$0.finish(24);

                  case 32:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this3, [[3, 20, 24, 32], [25,, 27, 31]]);
            }, onError));

          case 24:
            return context$2$0.abrupt('return', count);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21]]);
    }
  }]);

  return Filter;
})(_groups.GroupBase);

exports.Filter = Filter;

// return result of filtering
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collection/groups.js                                                                                       //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _meteorMongo = require('meteor/mongo');

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _meteorMeteor = require('meteor/meteor');

var Groups = new _meteorMongo.Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

var GroupBase = (function () {
  function GroupBase(profile) {
    _classCallCheck(this, GroupBase);

    this.profile = profile;
  }

  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */

  _createClass(GroupBase, [{
    key: 'getPlug',
    value: function getPlug() {
      return this.profile.platformPlug;
    }
  }, {
    key: 'getProfile',
    value: function getProfile() {
      return this.profile;
    }
  }, {
    key: 'foreach',
    value: function foreach() {
      var _this = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
    }
  }]);

  return GroupBase;
})();

exports.GroupBase = GroupBase;

var Group = (function (_GroupBase) {
  _inherits(Group, _GroupBase);

  function Group(groupId) {
    var _this2 = this;

    _classCallCheck(this, Group);

    var profile = Groups.findOne({
      _id: groupId
    });

    _get(Object.getPrototypeOf(Group.prototype), 'constructor', this).call(this, profile);

    var plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new _utilMysql2['default'](plug.cred);
        this['import'] = function callee$2$0(doc) {
          var sql;
          return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
            while (1) switch (context$3$0.prev = context$3$0.next) {
              case 0:
                sql = 'SELECT * FROM ' + plug.table + ' WHERE `' + doc.key + '` = "' + doc.id + '"';
                context$3$0.next = 3;
                return regeneratorRuntime.awrap(this.mysql.query(sql));

              case 3:
                return context$3$0.abrupt('return', context$3$0.sent);

              case 4:
              case 'end':
                return context$3$0.stop();
            }
          }, null, _this2);
        };
        break;
      default:
        throw new Error('invalid group type');
    }
  }

  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */

  _createClass(Group, [{
    key: 'foreach',
    value: function foreach() {
      var _this3 = this;

      var callback = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0(record) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[0];
      var onError = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0(e) {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this3);
      } : arguments[1];

      var cur = Groups.find({
        groupId: this.profile._id
      }, {
        fields: {
          _id: 0,
          id: 1,
          key: 1
        }
      });

      return new Promise(function (resolve, reject) {

        cur.forEach(function callee$3$0(doc, index) {
          var record;
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                context$4$0.prev = 0;
                context$4$0.next = 3;
                return regeneratorRuntime.awrap(this['import'](doc));

              case 3:
                record = context$4$0.sent;
                context$4$0.next = 6;
                return regeneratorRuntime.awrap(callback(record));

              case 6:
                context$4$0.next = 11;
                break;

              case 8:
                context$4$0.prev = 8;
                context$4$0.t0 = context$4$0['catch'](0);

                onError(context$4$0.t0);

              case 11:
                if (index + 1 === cur.count()) {
                  resolve();
                }

              case 12:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this3, [[0, 8]]);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }]);

  return Group;
})(GroupBase);

exports.Group = Group;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"service":{"cube3api.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/cube3api.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _importsUtilMysql = require('../../imports/util/mysql');

var _importsUtilMysql2 = _interopRequireDefault(_importsUtilMysql);

var Cube3Api = (function () {
  /**
   *
   * @param {MySQL} mysql
   */

  function Cube3Api(mysql) {
    _classCallCheck(this, Cube3Api);

    this.mysql_ = mysql;
  }

  _createClass(Cube3Api, [{
    key: 'updateStock',
    value: function updateStock(productClassId) {
      var quantity = arguments.length <= 1 || arguments[1] === undefined ? 0 : arguments[1];
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_class', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              stock_unlimited: 0,
              update_date: 'NOW()'
            }));

          case 2:
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_stock', 'product_class_id = ' + productClassId, {}, {
              stock: quantity,
              update_date: 'NOW()'
            }));

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productTagUpdate',
    value: function productTagUpdate(data) {
      var creatorId, res, tagoff, tagon, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, tagSet;

      return regeneratorRuntime.async(function productTagUpdate$(context$2$0) {
        var _this = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = [];

            tagoff = function tagoff(tag) {
              var sql;
              return regeneratorRuntime.async(function tagoff$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      DELETE FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.t0 = res;
                    context$3$0.next = 4;
                    return regeneratorRuntime.awrap(this.mysql_.query(sql));

                  case 4:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 6:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            };

            tagon = function tagon(tag) {
              var sql, countRes;
              return regeneratorRuntime.async(function tagon$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    sql = '\n      SELECT COUNT(*) FROM dtb_product_tag \n      WHERE product_id = ' + data.product_id + ' AND tag = ' + tag + '\n      ';
                    context$3$0.next = 3;
                    return regeneratorRuntime.awrap(this.mysql_.query(sql));

                  case 3:
                    countRes = context$3$0.sent;

                    if (!countRes[0]['COUNT(*)']) {
                      context$3$0.next = 6;
                      break;
                    }

                    return context$3$0.abrupt('return');

                  case 6:
                    context$3$0.t0 = res;
                    context$3$0.next = 9;
                    return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_tag', {}, {
                      product_id: data.product_id,
                      tag: tag,
                      creator_id: creatorId,
                      create_date: 'NOW()'
                    }));

                  case 9:
                    context$3$0.t1 = context$3$0.sent;
                    context$3$0.t0.push.call(context$3$0.t0, context$3$0.t1);

                  case 11:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this);
            };

            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 7;
            _iterator = data.tags[Symbol.iterator]();

          case 9:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 23;
              break;
            }

            tagSet = _step.value;
            context$2$0.t0 = tagSet.set;
            context$2$0.next = context$2$0.t0 === 'on' ? 14 : context$2$0.t0 === 'off' ? 17 : 20;
            break;

          case 14:
            context$2$0.next = 16;
            return regeneratorRuntime.awrap(tagon(tagSet.tag));

          case 16:
            return context$2$0.abrupt('break', 20);

          case 17:
            context$2$0.next = 19;
            return regeneratorRuntime.awrap(tagoff(tagSet.tag));

          case 19:
            return context$2$0.abrupt('break', 20);

          case 20:
            _iteratorNormalCompletion = true;
            context$2$0.next = 9;
            break;

          case 23:
            context$2$0.next = 29;
            break;

          case 25:
            context$2$0.prev = 25;
            context$2$0.t1 = context$2$0['catch'](7);
            _didIteratorError = true;
            _iteratorError = context$2$0.t1;

          case 29:
            context$2$0.prev = 29;
            context$2$0.prev = 30;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 32:
            context$2$0.prev = 32;

            if (!_didIteratorError) {
              context$2$0.next = 35;
              break;
            }

            throw _iteratorError;

          case 35:
            return context$2$0.finish(32);

          case 36:
            return context$2$0.finish(29);

          case 37:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 38:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[7, 25, 29, 37], [30,, 32, 36]]);
    }
  }, {
    key: 'productImageUpdate',
    value: function productImageUpdate(data) {
      var productId, images, creatorId, res, sql, i;
      return regeneratorRuntime.async(function productImageUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            productId = data.product_id;
            images = data.images;
            creatorId = data.creator_id;
            res = [];
            sql = 'DELETE FROM dtb_product_image WHERE product_id = ' + productId;
            context$2$0.t0 = res;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(this.mysql_.query(sql));

          case 8:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t1);
            i = 0;

          case 11:
            if (!(i < images.length)) {
              context$2$0.next = 17;
              break;
            }

            context$2$0.next = 14;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_image', {
              product_id: productId,
              creator_id: creatorId,
              file_name: images[i],
              rank: i + 1
            }, {
              create_date: 'NOW()'
            }));

          case 14:
            i++;
            context$2$0.next = 11;
            break;

          case 17:
            return context$2$0.abrupt('return', {
              res: res
            });

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'productUpdate',
    value: function productUpdate(data) {
      var updateData, keys, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, k, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, res;

      return regeneratorRuntime.async(function productUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            updateData = {};
            keys = [];

            // dtb_product

            keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 6;
            for (_iterator2 = keys[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError2) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError2;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            context$2$0.next = 24;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 24:

            // dtb_product_class

            updateData = {};
            keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 29;
            for (_iterator3 = keys[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 37;
            break;

          case 33:
            context$2$0.prev = 33;
            context$2$0.t1 = context$2$0['catch'](29);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t1;

          case 37:
            context$2$0.prev = 37;
            context$2$0.prev = 38;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 40:
            context$2$0.prev = 40;

            if (!_didIteratorError3) {
              context$2$0.next = 43;
              break;
            }

            throw _iteratorError3;

          case 43:
            return context$2$0.finish(40);

          case 44:
            return context$2$0.finish(37);

          case 45:
            context$2$0.next = 47;
            return regeneratorRuntime.awrap(this.mysql_.queryUpdate('dtb_product_class', 'product_id = ' + data.product_id, updateData, {
              update_date: 'NOW()'
            }));

          case 47:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 49:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [29, 33, 37, 45], [38,, 40, 44]]);
    }
  }, {
    key: 'productCreate',
    value: function productCreate(data) {
      var creatorId, res, updateData, keys, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, k, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6;

      return regeneratorRuntime.async(function productCreate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            creatorId = data.creator_id;
            res = {};
            updateData = {};
            keys = [];

            keys = ['name', 'description_detail'];
            // {
            //   name: item.name,
            //   description_detail: item.description,
            // },

            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 8;
            for (_iterator4 = keys[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 16;
            break;

          case 12:
            context$2$0.prev = 12;
            context$2$0.t0 = context$2$0['catch'](8);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t0;

          case 16:
            context$2$0.prev = 16;
            context$2$0.prev = 17;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 19:
            context$2$0.prev = 19;

            if (!_didIteratorError4) {
              context$2$0.next = 22;
              break;
            }

            throw _iteratorError4;

          case 22:
            return context$2$0.finish(19);

          case 23:
            return context$2$0.finish(16);

          case 24:
            context$2$0.next = 26;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product', updateData, {
              creator_id: creatorId,
              status: 1,
              note: 'NULL',
              description_list: 'NULL',
              search_word: 'NULL',
              free_area: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 26:
            res.product_id = context$2$0.sent;

            updateData = {};
            keys = ['product_code', 'product_type_id', 'price01', 'price02', 'delivery_fee'];
            // {
            //   product_code: item.model,
            //   price01: item.retail_price,
            //   price02: item.sales_price,
            // },

            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 32;
            for (_iterator5 = keys[Symbol.iterator](); !(_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done); _iteratorNormalCompletion5 = true) {
              k = _step5.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 40;
            break;

          case 36:
            context$2$0.prev = 36;
            context$2$0.t1 = context$2$0['catch'](32);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t1;

          case 40:
            context$2$0.prev = 40;
            context$2$0.prev = 41;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 43:
            context$2$0.prev = 43;

            if (!_didIteratorError5) {
              context$2$0.next = 46;
              break;
            }

            throw _iteratorError5;

          case 46:
            return context$2$0.finish(43);

          case 47:
            return context$2$0.finish(40);

          case 48:
            context$2$0.next = 50;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_class', updateData, {
              creator_id: creatorId,
              product_id: res.product_id,
              stock: 0,
              stock_unlimited: 0,
              class_category_id1: 'NULL',
              class_category_id2: 'NULL',
              delivery_date_id: 'NULL',
              sale_limit: 'NULL',
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 50:
            res.product_class_id = context$2$0.sent;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 54;

            for (_iterator6 = keys[Symbol.iterator](); !(_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done); _iteratorNormalCompletion6 = true) {
              k = _step6.value;

              if (data[k]) updateData[k] = data[k];
            }

            context$2$0.next = 62;
            break;

          case 58:
            context$2$0.prev = 58;
            context$2$0.t2 = context$2$0['catch'](54);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t2;

          case 62:
            context$2$0.prev = 62;
            context$2$0.prev = 63;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 65:
            context$2$0.prev = 65;

            if (!_didIteratorError6) {
              context$2$0.next = 68;
              break;
            }

            throw _iteratorError6;

          case 68:
            return context$2$0.finish(65);

          case 69:
            return context$2$0.finish(62);

          case 70:
            context$2$0.next = 72;
            return regeneratorRuntime.awrap(this.mysql_.queryInsert('dtb_product_stock', {}, {
              product_class_id: res.product_class_id,
              creator_id: creatorId,
              stock: 0,
              create_date: 'NOW()',
              update_date: 'NOW()'
            }));

          case 72:
            res.product_stock_id = context$2$0.sent;
            return context$2$0.abrupt('return', {
              res: res
            });

          case 74:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 12, 16, 24], [17,, 19, 23], [32, 36, 40, 48], [41,, 43, 47], [54, 58, 62, 70], [63,, 65, 69]]);
    }
  }]);

  return Cube3Api;
})();

exports.Cube3Api = Cube3Api;

// 削除するタグ

// 表示するタグ

// すでに表示されているタグがあれば何もしない

// 商品に関連するすべての画像情報を削除する

// 改めて画像を登録しなおす

// for test
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/dbfilter.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _get = function get(_x5, _x6, _x7) { var _again = true; _function: while (_again) { var object = _x5, property = _x6, receiver = _x7; _again = false; if (object === null) object = Function.prototype; var desc = Object.getOwnPropertyDescriptor(object, property); if (desc === undefined) { var parent = Object.getPrototypeOf(object); if (parent === null) { return undefined; } else { _x5 = parent; _x6 = property; _x7 = receiver; _again = true; desc = parent = undefined; continue _function; } } else if ('value' in desc) { return desc.value; } else { var getter = desc.get; if (getter === undefined) { return undefined; } return getter.call(receiver); } } };

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _inherits(subClass, superClass) { if (typeof superClass !== 'function' && superClass !== null) { throw new TypeError('Super expression must either be null or a function, not ' + typeof superClass); } subClass.prototype = Object.create(superClass && superClass.prototype, { constructor: { value: subClass, enumerable: false, writable: true, configurable: true } }); if (superClass) Object.setPrototypeOf ? Object.setPrototypeOf(subClass, superClass) : subClass.__proto__ = superClass; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMysql = require('../util/mysql');

var _utilMysql2 = _interopRequireDefault(_utilMysql);

var _mongodb = require('mongodb');

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

// validate objects & filter arrays with mongodb queries

var _sift = require('sift');

var _sift2 = _interopRequireDefault(_sift);

var _mongoobject = require('mongoobject');

var _mongoobject2 = _interopRequireDefault(_mongoobject);

var _xmlJs = require('xml-js');

var DBFilterFactory = function DBFilterFactory(plug, profile) {
  _classCallCheck(this, DBFilterFactory);

  var instance = undefined;
  switch (plug.type) {
    case 'mysql':
      instance = new MysqlDBFilter(plug, profile);
  }

  return instance;
};

exports.DBFilterFactory = DBFilterFactory;

var DBFilter = (function () {
  function DBFilter(plug, profile) {
    _classCallCheck(this, DBFilter);

    this.plug = plug;
    this.profile = profile;
  }

  _createClass(DBFilter, [{
    key: 'getPlug_',
    value: function getPlug_() {
      return this.plug;
    }
  }, {
    key: 'getCred_',
    value: function getCred_() {
      return this.plug.cred;
    }
  }, {
    key: 'getProfile_',
    value: function getProfile_() {
      return this.profile;
    }
  }, {
    key: 'setImportFunction_',
    value: function setImportFunction_() {
      var _this = this;

      var fn = arguments.length <= 0 || arguments[0] === undefined ? function callee$2$0() {
        var onResult = arguments.length <= 0 || arguments[0] === undefined ? function (record) {} : arguments[0];
        var onError = arguments.length <= 1 || arguments[1] === undefined ? function (e) {} : arguments[1];
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[0];

      this['import'] = fn;
    }

    /**
     * traces members of the group
     * useage:
     *
     *
     * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters
     * @param { async function } onError error handler while iterating
     * @returns { Object } { filterName: { query: any, count: number }, ... }
     */
  }, {
    key: 'foreach',
    value: function foreach() {
      var iterators = arguments.length <= 0 || arguments[0] === undefined ? {} : arguments[0];

      var profile, counter, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, f, filters, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2;

      return regeneratorRuntime.async(function foreach$(context$2$0) {
        var _this2 = this;

        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            profile = this.getProfile_();

            // misc フィルターを末尾に自動追加
            profile.filters.push({
              name: 'misc',
              query: {}
            });

            counter = {};
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 6;

            for (_iterator = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              f = _step.value;
            }

            context$2$0.next = 14;
            break;

          case 10:
            context$2$0.prev = 10;
            context$2$0.t0 = context$2$0['catch'](6);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 14:
            context$2$0.prev = 14;
            context$2$0.prev = 15;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 17:
            context$2$0.prev = 17;

            if (!_didIteratorError) {
              context$2$0.next = 20;
              break;
            }

            throw _iteratorError;

          case 20:
            return context$2$0.finish(17);

          case 21:
            return context$2$0.finish(14);

          case 22:
            filters = [];
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 26;

            for (_iterator2 = profile.filters[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              f = _step2.value;

              counter[f.name] = {
                query: f.query,
                limit: typeof f.limit !== 'undefined' ? f.limit : 0,
                count: 0
              };
              filters.push({
                name: f.name,
                exam: (0, _sift2['default'])(_mongoobject2['default'].unescape(f.query))
              });
            }

            context$2$0.next = 34;
            break;

          case 30:
            context$2$0.prev = 30;
            context$2$0.t1 = context$2$0['catch'](26);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 34:
            context$2$0.prev = 34;
            context$2$0.prev = 35;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 37:
            context$2$0.prev = 37;

            if (!_didIteratorError2) {
              context$2$0.next = 40;
              break;
            }

            throw _iteratorError2;

          case 40:
            return context$2$0.finish(37);

          case 41:
            return context$2$0.finish(34);

          case 42:
            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this['import'](function callee$2$0(record, context) {
              var _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, f, c;

              return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
                while (1) switch (context$3$0.prev = context$3$0.next) {
                  case 0:
                    _iteratorNormalCompletion3 = true;
                    _didIteratorError3 = false;
                    _iteratorError3 = undefined;
                    context$3$0.prev = 3;
                    _iterator3 = filters[Symbol.iterator]();

                  case 5:
                    if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
                      context$3$0.next = 20;
                      break;
                    }

                    f = _step3.value;
                    c = counter[f.name];

                    if (!c.limit) {
                      context$3$0.next = 11;
                      break;
                    }

                    if (!(c.count >= c.limit)) {
                      context$3$0.next = 11;
                      break;
                    }

                    return context$3$0.abrupt('continue', 17);

                  case 11:
                    if (!f.exam(record)) {
                      context$3$0.next = 17;
                      break;
                    }

                    // counter limiter
                    c.count++;

                    // iterator

                    if (!(typeof iterators[f.name] !== 'undefined')) {
                      context$3$0.next = 16;
                      break;
                    }

                    context$3$0.next = 16;
                    return regeneratorRuntime.awrap(iterators[f.name](record, context));

                  case 16:
                    return context$3$0.abrupt('break', 20);

                  case 17:
                    _iteratorNormalCompletion3 = true;
                    context$3$0.next = 5;
                    break;

                  case 20:
                    context$3$0.next = 26;
                    break;

                  case 22:
                    context$3$0.prev = 22;
                    context$3$0.t0 = context$3$0['catch'](3);
                    _didIteratorError3 = true;
                    _iteratorError3 = context$3$0.t0;

                  case 26:
                    context$3$0.prev = 26;
                    context$3$0.prev = 27;

                    if (!_iteratorNormalCompletion3 && _iterator3['return']) {
                      _iterator3['return']();
                    }

                  case 29:
                    context$3$0.prev = 29;

                    if (!_didIteratorError3) {
                      context$3$0.next = 32;
                      break;
                    }

                    throw _iteratorError3;

                  case 32:
                    return context$3$0.finish(29);

                  case 33:
                    return context$3$0.finish(26);

                  case 34:
                  case 'end':
                    return context$3$0.stop();
                }
              }, null, _this2, [[3, 22, 26, 34], [27,, 29, 33]]);
            }));

          case 44:
            return context$2$0.abrupt('return', counter);

          case 45:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 10, 14, 22], [15,, 17, 21], [26, 30, 34, 42], [35,, 37, 41]]);
    }
  }], [{
    key: 'factory',
    value: function factory(plug, profile) {
      switch (plug.type) {
        case 'mysql':
          return new MysqlDBFilter(plug, profile);
        default:
          throw new Error('invalid plug type');
      }
    }
  }]);

  return DBFilter;
})();

exports.DBFilter = DBFilter;

var MysqlDBFilter = (function (_DBFilter) {
  _inherits(MysqlDBFilter, _DBFilter);

  function MysqlDBFilter(plug, profile) {
    var _this3 = this;

    _classCallCheck(this, MysqlDBFilter);

    _get(Object.getPrototypeOf(MysqlDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    var cred = this.getCred_();

    this.mysql = new _utilMysql2['default'](cred);
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var sql, res;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            sql = 'SELECT * FROM ' + plug.table;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(this.mysql.streamingQuery(sql, onResult, function (e) {
              throw e;
            }));

          case 3:
            res = context$3$0.sent;
            return context$3$0.abrupt('return', res);

          case 5:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this3);
    });
  }

  // import MongoNative from 'mongodb';
  // const MongoClient = MongoNative.MongoClient;
  // const MongoClient = require('mongodb').MongoClient;

  return MysqlDBFilter;
})(DBFilter);

exports.MysqlDBFilter = MysqlDBFilter;

var MongoDBFilter = (function (_DBFilter2) {
  _inherits(MongoDBFilter, _DBFilter2);

  function MongoDBFilter(plug, profile) {
    var _this4 = this;

    _classCallCheck(this, MongoDBFilter);

    _get(Object.getPrototypeOf(MongoDBFilter.prototype), 'constructor', this).call(this, plug, profile);

    // mongo へ接続
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var client, db, collection, context, cur, doc;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            client = undefined;
            context$3$0.next = 3;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri));

          case 3:
            client = context$3$0.sent;
            db = client.db(plug.database);
            collection = db.collection(plug.collection);
            context = {
              client: client,
              collection: collection,
              database: db
            };
            cur = collection.find();

            // カーソルのタイムアウトを解除
            cur.addCursorFlag('noCursorTimeout', true);

            // すべてのドキュメントをループ
            context$3$0.prev = 9;

          case 10:
            context$3$0.next = 12;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 12:
            if (!context$3$0.sent) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 15;
            return regeneratorRuntime.awrap(cur.next());

          case 15:
            doc = context$3$0.sent;
            context$3$0.next = 18;
            return regeneratorRuntime.awrap(onResult(doc, context));

          case 18:
            context$3$0.next = 10;
            break;

          case 20:
            ;

          case 21:
            context$3$0.prev = 21;
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(cur.close());

          case 24:
            return context$3$0.finish(21);

          case 25:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this4, [[9,, 21, 25]]);
    });
  }

  return MongoDBFilter;
})(DBFilter);

exports.MongoDBFilter = MongoDBFilter;

var WowmaApiItemFilter = (function (_DBFilter3) {
  _inherits(WowmaApiItemFilter, _DBFilter3);

  function WowmaApiItemFilter(plug, profile) {
    var _this5 = this;

    _classCallCheck(this, WowmaApiItemFilter);

    _get(Object.getPrototypeOf(WowmaApiItemFilter.prototype), 'constructor', this).call(this, plug, profile);

    // 商品情報の取得ループを定義
    this.setImportFunction_(function callee$2$0(onResult, onError) {
      var options, context, res, maxCount, resultCount, startCount, resultStocks, i, next;
      return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
        while (1) switch (context$3$0.prev = context$3$0.next) {
          case 0:
            options = JSON.parse(JSON.stringify(plug));

            options.uri = options.uri + '/searchStocks';
            context = {
              options: options
            };

          case 3:
            if (!1) {
              context$3$0.next = 30;
              break;
            }

            context$3$0.next = 6;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(options));

          case 6:
            res = context$3$0.sent;

            res = (0, _xmlJs.xml2js)(res, { compact: true });

            maxCount = Number(res.response.searchResult.maxCount._text);
            resultCount = Number(res.response.searchResult.resultCount._text);
            startCount = Number(res.response.searchResult.startCount._text);
            resultStocks = res.response.searchResult.resultStocks;

            if (!(resultStocks instanceof Array)) {
              context$3$0.next = 22;
              break;
            }

            i = 0;

          case 14:
            if (!(i < resultCount)) {
              context$3$0.next = 20;
              break;
            }

            context$3$0.next = 17;
            return regeneratorRuntime.awrap(onResult(resultStocks[i], context));

          case 17:
            i++;
            context$3$0.next = 14;
            break;

          case 20:
            context$3$0.next = 24;
            break;

          case 22:
            context$3$0.next = 24;
            return regeneratorRuntime.awrap(onResult(resultStocks, context));

          case 24:
            next = startCount + resultCount;

            if (!(next > maxCount)) {
              context$3$0.next = 27;
              break;
            }

            return context$3$0.abrupt('break', 30);

          case 27:
            options.qs.startCount = next;
            context$3$0.next = 3;
            break;

          case 30:
          case 'end':
            return context$3$0.stop();
        }
      }, null, _this5);
    });
  }

  // import mongoose from 'mongoose';

  // export class MongoDBFilter extends DBFilter {
  //   constructor(plug, profile) {
  //     super(plug, profile);

  //     // mongo へ接続
  //     let cred = this.getCred_();
  //     let conuri = `mongodb://${cred.host}:${cred.port}/${cred.database}`;
  //     await mongoose.connect(conuri);

  //     // コレクションを作る
  //     let collection = mongoose.connection.collection(plug.collection);

  //     this.setImportFunction_(async (onResult, onError) => {
  //       let cur = collection.find();

  //       return await this.mysql.streamingQuery(sql, onResult, onError);
  //     });
  //   }
  // }
  return WowmaApiItemFilter;
})(DBFilter);

exports.WowmaApiItemFilter = WowmaApiItemFilter;

// counter limiter

// return result of filtering

// コレクションを取得

// カーソルを開放

// コレクションを取得

// Wowma Api から商品情報を取得

// 取得した商品情報をカスタムプロセスに渡す

// 取得したデータが複数商品の場合

// 取得したデータが単数商品の場合
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/items.js                                                                                           //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _defineProperty(obj, key, value) { if (key in obj) { Object.defineProperty(obj, key, { value: value, enumerable: true, configurable: true, writable: true }); } else { obj[key] = value; } return obj; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _utilMongo = require('../util/mongo');

var _collections = require('../collections');

var _bson = require('bson');

var _bluebird = require('bluebird');

var _bluebird2 = _interopRequireDefault(_bluebird);

var _utilText = require('../util/text');

var _utilText2 = _interopRequireDefault(_utilText);

var ItemController = (function () {
  function ItemController() {
    _classCallCheck(this, ItemController);
  }

  _createClass(ItemController, [{
    key: 'init',
    value: function init(plug) {
      return regeneratorRuntime.async(function init$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'items'));

          case 2:
            this.Items = context$2$0.sent;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(_utilMongo.MongoCollection.get(plug, 'products'));

          case 5:
            this.Products = context$2$0.sent;

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'getStock',
    value: function getStock(itemId) {
      var item, productSet, quantities, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, productRef, prdQuantity, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, id, product, stockArray, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, stock, quantity;

      return regeneratorRuntime.async(function getStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.Items.findOne({
              _id: itemId
            }, {
              projection: {
                'product': 1
              }
            }));

          case 2:
            item = context$2$0.sent;
            productSet = item.product;
            quantities = [];
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 8;
            _iterator = productSet[Symbol.iterator]();

          case 10:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 64;
              break;
            }

            productRef = _step.value;
            prdQuantity = 0;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 16;
            _iterator2 = productRef.ids[Symbol.iterator]();

          case 18:
            if (_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done) {
              context$2$0.next = 46;
              break;
            }

            id = _step2.value;
            context$2$0.next = 22;
            return regeneratorRuntime.awrap(this.Products.findOne({
              _id: id
            }, {
              projection: {
                'stock': 1
              }
            }));

          case 22:
            product = context$2$0.sent;
            stockArray = product.stock;
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 27;

            // 単純にすべての在庫商品、短期間取り寄せ可能商品を合算
            for (_iterator3 = stockArray[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              stock = _step3.value;

              prdQuantity += stock.quantity;
            }
            context$2$0.next = 35;
            break;

          case 31:
            context$2$0.prev = 31;
            context$2$0.t0 = context$2$0['catch'](27);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 35:
            context$2$0.prev = 35;
            context$2$0.prev = 36;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 38:
            context$2$0.prev = 38;

            if (!_didIteratorError3) {
              context$2$0.next = 41;
              break;
            }

            throw _iteratorError3;

          case 41:
            return context$2$0.finish(38);

          case 42:
            return context$2$0.finish(35);

          case 43:
            _iteratorNormalCompletion2 = true;
            context$2$0.next = 18;
            break;

          case 46:
            context$2$0.next = 52;
            break;

          case 48:
            context$2$0.prev = 48;
            context$2$0.t1 = context$2$0['catch'](16);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 52:
            context$2$0.prev = 52;
            context$2$0.prev = 53;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 55:
            context$2$0.prev = 55;

            if (!_didIteratorError2) {
              context$2$0.next = 58;
              break;
            }

            throw _iteratorError2;

          case 58:
            return context$2$0.finish(55);

          case 59:
            return context$2$0.finish(52);

          case 60:

            // 商品(item)の在庫数 = 製品在庫数(prdQuantity) / 必要セット数(productRef.set)
            quantities.push(Math.floor(prdQuantity / productRef.set));

          case 61:
            _iteratorNormalCompletion = true;
            context$2$0.next = 10;
            break;

          case 64:
            context$2$0.next = 70;
            break;

          case 66:
            context$2$0.prev = 66;
            context$2$0.t2 = context$2$0['catch'](8);
            _didIteratorError = true;
            _iteratorError = context$2$0.t2;

          case 70:
            context$2$0.prev = 70;
            context$2$0.prev = 71;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 73:
            context$2$0.prev = 73;

            if (!_didIteratorError) {
              context$2$0.next = 76;
              break;
            }

            throw _iteratorError;

          case 76:
            return context$2$0.finish(73);

          case 77:
            return context$2$0.finish(70);

          case 78:
            quantity = Math.min.apply(null, quantities);
            return context$2$0.abrupt('return', quantity);

          case 80:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[8, 66, 70, 78], [16, 48, 52, 60], [27, 31, 35, 43], [36,, 38, 42], [53,, 55, 59], [71,, 73, 77]]);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに、
     * アップロード済み画像を関連付ける。
     *
     * メーカーモデルに共通の画像を一括で関連付けたい場合、
     * class1、class2引数を指定せずに実行する。
     *
     * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
     * class1に値を指定し、class2引数を指定せずに実行する。
     * もしclass2のみ指定したい場合はclass1にnullを指定する。
     *
     * 例：JK-100のBLACKの商品画像を
     * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
     * setImage( uploadId, 'JK-100', 'BLACK' );
     *
     * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'setImage',
    value: function setImage(uploadId, model) {
      var class1 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var class2 = arguments.length <= 3 || arguments[3] === undefined ? null : arguments[3];
      var images, filter, res;
      return regeneratorRuntime.async(function setImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            images = _collections.Uploads.find({
              uploadId: uploadId
            }).fetch().map(function (v) {
              return v.uploadedFileName;
            });
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $push: {
                images: {
                  $each: images
                }
              }
            }));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', images);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
     *
     * @param {String} model メーカーモデル
     * @param {String} class1 カラー、サイズなどの属性
     * @param {String} class2 カラー、サイズなどの属性
     */
  }, {
    key: 'cleanImage',
    value: function cleanImage(model) {
      var class1 = arguments.length <= 1 || arguments[1] === undefined ? null : arguments[1];
      var class2 = arguments.length <= 2 || arguments[2] === undefined ? null : arguments[2];
      var filter, res;
      return regeneratorRuntime.async(function cleanImage$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            filter = {};

            filter.model = model;
            if (class1) filter.class1_value = class1;
            if (class2) filter.class2_value = class2;

            context$2$0.next = 6;
            return regeneratorRuntime.awrap(this.Items.updateMany(filter, {
              $set: {
                images: []
              }
            }));

          case 6:
            res = context$2$0.sent;

          case 7:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     * 指定の商品に関連する商品群の属性別の商品情報を返す。
     *
     * 引数として受け取るitemは任意の商品情報。
     * itemに関連する商品群について必要な情報を整理し返す。
     *
     * projectに参照したい商品情報フィールドを定義する。
     * メソッドの呼び出し時に必要に応じてprojectを設定する。
     *
     * 何に注目して商品の関連性を検出するかは、このメソッド内で定義する。
     *
     * @param {Object} item
     * @param {Object} project
     */
  }, {
    key: 'getVariation',
    value: function getVariation(item, project) {
      var set, attrs, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, s, _iteratorNormalCompletion5, _didIteratorError5, _iteratorError5, _iterator5, _step5, attr, _iteratorNormalCompletion6, _didIteratorError6, _iteratorError6, _iterator6, _step6, v;

      return regeneratorRuntime.async(function getVariation$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            set = [{
              label: '配送方法',
              current: item.delivery,
              project: {
                value: '$delivery'
              },
              query: {
                class1_value: item.class1_value,
                class2_value: item.class2_value
              }
            }, {
              label: item.class1_name,
              current: item.class1_value,
              project: {
                value: '$class1_value'
              },
              query: {
                delivery: item.delivery,
                class2_value: item.class2_value
              }
            }, {
              label: item.class2_name,
              current: item.class2_value,
              project: {
                value: '$class2_value'
              },
              query: {
                delivery: item.delivery,
                class1_value: item.class1_value
              }
            }];
            attrs = [];
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 5;
            _iterator4 = set[Symbol.iterator]();

          case 7:
            if (_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done) {
              context$2$0.next = 19;
              break;
            }

            s = _step4.value;
            context$2$0.t0 = attrs;
            context$2$0.next = 12;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: Object.assign(s.query, {
                model: item.model
              })
            }, {
              $project: Object.assign(s.project, project)
            }, {
              $sort: {
                _id: 1
              }
            }]).toArray());

          case 12:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = s;
            context$2$0.t3 = {
              variations: context$2$0.t1,
              props: context$2$0.t2
            };
            context$2$0.t0.push.call(context$2$0.t0, context$2$0.t3);

          case 16:
            _iteratorNormalCompletion4 = true;
            context$2$0.next = 7;
            break;

          case 19:
            context$2$0.next = 25;
            break;

          case 21:
            context$2$0.prev = 21;
            context$2$0.t4 = context$2$0['catch'](5);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t4;

          case 25:
            context$2$0.prev = 25;
            context$2$0.prev = 26;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 28:
            context$2$0.prev = 28;

            if (!_didIteratorError4) {
              context$2$0.next = 31;
              break;
            }

            throw _iteratorError4;

          case 31:
            return context$2$0.finish(28);

          case 32:
            return context$2$0.finish(25);

          case 33:
            _iteratorNormalCompletion5 = true;
            _didIteratorError5 = false;
            _iteratorError5 = undefined;
            context$2$0.prev = 36;
            _iterator5 = attrs[Symbol.iterator]();

          case 38:
            if (_iteratorNormalCompletion5 = (_step5 = _iterator5.next()).done) {
              context$2$0.next = 70;
              break;
            }

            attr = _step5.value;
            _iteratorNormalCompletion6 = true;
            _didIteratorError6 = false;
            _iteratorError6 = undefined;
            context$2$0.prev = 43;
            _iterator6 = attr.variations[Symbol.iterator]();

          case 45:
            if (_iteratorNormalCompletion6 = (_step6 = _iterator6.next()).done) {
              context$2$0.next = 53;
              break;
            }

            v = _step6.value;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.getStock(v._id));

          case 49:
            v.stock = context$2$0.sent;

          case 50:
            _iteratorNormalCompletion6 = true;
            context$2$0.next = 45;
            break;

          case 53:
            context$2$0.next = 59;
            break;

          case 55:
            context$2$0.prev = 55;
            context$2$0.t5 = context$2$0['catch'](43);
            _didIteratorError6 = true;
            _iteratorError6 = context$2$0.t5;

          case 59:
            context$2$0.prev = 59;
            context$2$0.prev = 60;

            if (!_iteratorNormalCompletion6 && _iterator6['return']) {
              _iterator6['return']();
            }

          case 62:
            context$2$0.prev = 62;

            if (!_didIteratorError6) {
              context$2$0.next = 65;
              break;
            }

            throw _iteratorError6;

          case 65:
            return context$2$0.finish(62);

          case 66:
            return context$2$0.finish(59);

          case 67:
            _iteratorNormalCompletion5 = true;
            context$2$0.next = 38;
            break;

          case 70:
            context$2$0.next = 76;
            break;

          case 72:
            context$2$0.prev = 72;
            context$2$0.t6 = context$2$0['catch'](36);
            _didIteratorError5 = true;
            _iteratorError5 = context$2$0.t6;

          case 76:
            context$2$0.prev = 76;
            context$2$0.prev = 77;

            if (!_iteratorNormalCompletion5 && _iterator5['return']) {
              _iterator5['return']();
            }

          case 79:
            context$2$0.prev = 79;

            if (!_didIteratorError5) {
              context$2$0.next = 82;
              break;
            }

            throw _iteratorError5;

          case 82:
            return context$2$0.finish(79);

          case 83:
            return context$2$0.finish(76);

          case 84:
            return context$2$0.abrupt('return', attrs);

          case 85:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 21, 25, 33], [26,, 28, 32], [36, 72, 76, 84], [43, 55, 59, 67], [60,, 62, 66], [77,, 79, 83]]);
    }

    // モデルクラス形式を作る
    // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
  }, {
    key: 'getModelClass',
    value: function getModelClass(arg) {
      var item, exp, cur, match, modelClass;
      return regeneratorRuntime.async(function getModelClass$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            item = undefined;

            if (!(typeof arg === 'string')) {
              context$2$0.next = 25;
              break;
            }

            exp = new RegExp(arg + '$');
            cur = this.Items.find({}, {
              projection: {
                model: 1,
                class1_value: 1,
                class2_value: 1
              }
            });

          case 4:
            if (!1) {
              context$2$0.next = 22;
              break;
            }

            context$2$0.prev = 5;
            context$2$0.next = 8;
            return regeneratorRuntime.awrap(cur.next());

          case 8:
            item = context$2$0.sent;
            context$2$0.next = 11;
            return regeneratorRuntime.awrap(item._id.toHexString().match(exp));

          case 11:
            match = context$2$0.sent;

            if (!match) {
              context$2$0.next = 14;
              break;
            }

            return context$2$0.abrupt('break', 22);

          case 14:
            context$2$0.next = 20;
            break;

          case 16:
            context$2$0.prev = 16;
            context$2$0.t0 = context$2$0['catch'](5);

            // 該当するitemデータがない
            cur.close();
            return context$2$0.abrupt('return', arg);

          case 20:
            context$2$0.next = 4;
            break;

          case 22:
            cur.close();
            context$2$0.next = 26;
            break;

          case 25:
            item = arg;

          case 26:
            modelClass = [];

            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);
            return context$2$0.abrupt('return', modelClass.join('/'));

          case 31:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 16]]);
    }
  }, {
    key: 'convertItemCube3',
    value: function convertItemCube3(creatorId, item) {
      var convDeliv, productId, modelClass, productTypeId, tags, deliveryFee, attrs, variationHtml, descriptionDetail, data;
      return regeneratorRuntime.async(function convertItemCube3$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            convDeliv = function convDeliv(delivery) {
              return delivery === 'ゆうパケット' ? 'ポスト投函' : delivery;
            };

            productId = null;
            modelClass = [];

            // 下記の形式を作る
            // [メーカーコード]/[属性1（カラーなど）]/[属性2（サイズなど）]
            if (item.model) modelClass.push(item.model);
            if (item.class1_value) modelClass.push(item.class1_value);
            if (item.class2_value) modelClass.push(item.class2_value);

            // 商品種別を割り当てる
            productTypeId = undefined;
            context$2$0.t0 = item.delivery;
            context$2$0.next = context$2$0.t0 === '宅配便' ? 10 : context$2$0.t0 === 'ゆうパケット' ? 12 : 14;
            break;

          case 10:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 12:
            productTypeId = 2;
            return context$2$0.abrupt('break', 16);

          case 14:
            productTypeId = 1;
            return context$2$0.abrupt('break', 16);

          case 16:
            tags = [];
            context$2$0.t1 = item.delivery;
            context$2$0.next = context$2$0.t1 === '宅配便' ? 20 : context$2$0.t1 === 'ゆうパケット' ? 22 : 24;
            break;

          case 20:
            tags.push({
              tag: 4,
              set: 'on'
            }, {
              tag: 5,
              set: 'off'
            });
            return context$2$0.abrupt('break', 24);

          case 22:
            tags.push({
              tag: 5,
              set: 'on'
            }, {
              tag: 4,
              set: 'off'
            });
            return context$2$0.abrupt('break', 24);

          case 24:
            deliveryFee = null;
            context$2$0.t2 = item.delivery;
            context$2$0.next = context$2$0.t2 === '宅配便' ? 28 : context$2$0.t2 === 'ゆうパケット' ? 30 : 32;
            break;

          case 28:
            deliveryFee = null;
            return context$2$0.abrupt('break', 32);

          case 30:
            deliveryFee = 240;
            return context$2$0.abrupt('break', 32);

          case 32:
            context$2$0.next = 34;
            return regeneratorRuntime.awrap(this.getVariation(item, {
              product_id: '$mall.sharakuShop.product_id'
            }));

          case 34:
            attrs = context$2$0.sent;

            // HTML バリエーション商品ごとのリンク付きボタンを表示する

            // 値の変換
            attrs = attrs.map(function (attr) {
              attr.props.current = convDeliv(attr.props.current);
              attr.variations = attr.variations.map(function (variation) {
                variation.value = convDeliv(variation.value);
                return variation;
              });
              return attr;
            });

            // HTML生成
            variationHtml = attrs.map(function (attr) {
              return '<div class="container-fluid">' + '<div class="row">' + '<div style="opacity:0.3" class="btn btn-info btn-block btn-xs">' + ('<strong>' + attr.props.label + '</strong>') + '</div>' + attr.variations.map(function (variation) {
                if (attr.props.current === variation.value) {
                  // 表示中の商品ボタン
                  return '<button class="btn btn-success btn-sm btn-item-class-select"><strong>' + variation.value + '</strong></button>';
                } else if (variation.stock > 0) {
                  // 販売可能商品のボタン
                  return '<a href="/products/detail/' + variation.product_id + '"><button class="btn btn-default btn-sm btn-item-class-select">' + variation.value + '</button></a>';
                } else {
                  // 販売不可能商品のボタン（在庫なし）
                  return '<button class="btn btn-default btn-sm btn-item-class-select" style="opacity:0.3" data-toggle="tooltip" title="在庫がございません">' + variation.value + '</button>';
                }
              }).join('') + '</div>' + '</div>';
            }).join('');
            descriptionDetail = '\n    <small>※ 配送方法・カラー・サイズは下記からお選びください。</small>\n    ' + variationHtml + '\n    ';
            data = {
              product_id: productId,
              creator_id: creatorId,
              name: modelClass.join('/') + ' ' + convDeliv(item.delivery) + ' ' + item.name + (item.jan_code ? ' ' + item.jan_code : ''),
              description_detail: descriptionDetail,
              // free_area: await this.convertItemCube3createFreeArea(item),
              product_code: modelClass.join('/'),
              price01: item.retail_price,
              // price02: await this.convertItemCube3createPrice02(item),
              // images: await this.convertItemCube3createImages(item),
              product_type_id: productTypeId,
              tags: tags,
              delivery_fee: deliveryFee
            };
            context$2$0.t3 = Object;
            context$2$0.t4 = data;
            context$2$0.next = 43;
            return regeneratorRuntime.awrap(this.convertItemCube3createFreeArea(item));

          case 43:
            context$2$0.t5 = context$2$0.sent;
            context$2$0.t3.assign.call(context$2$0.t3, context$2$0.t4, context$2$0.t5);
            context$2$0.t6 = Object;
            context$2$0.t7 = data;
            context$2$0.next = 49;
            return regeneratorRuntime.awrap(this.convertItemCube3createPrice02(item));

          case 49:
            context$2$0.t8 = context$2$0.sent;
            context$2$0.t6.assign.call(context$2$0.t6, context$2$0.t7, context$2$0.t8);
            context$2$0.t9 = Object;
            context$2$0.t10 = data;
            context$2$0.next = 55;
            return regeneratorRuntime.awrap(this.convertItemCube3createImages(item));

          case 55:
            context$2$0.t11 = context$2$0.sent;
            context$2$0.t9.assign.call(context$2$0.t9, context$2$0.t10, context$2$0.t11);

            Object.assign(data, item.mall.sharakuShop);

            return context$2$0.abrupt('return', data);

          case 59:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createFreeArea',
    value: function convertItemCube3createFreeArea(item) {
      var freeArea, i;
      return regeneratorRuntime.async(function convertItemCube3createFreeArea$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            freeArea = '';

            // 商品情報テキストを記載する
            freeArea += item.description;
            // 2番目以降の画像をフリーエリアに記載する
            for (i = 1; i < item.images.length; i++) {
              freeArea += '<img src="/upload/save_image/' + item.images[i] + '"><br>';
            }
            // 情報のクリア
            freeArea += ' ';
            return context$2$0.abrupt('return', { free_area: freeArea });

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createPrice02',
    value: function convertItemCube3createPrice02(item) {
      return regeneratorRuntime.async(function convertItemCube3createPrice02$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            return context$2$0.abrupt('return', { price02: item.mall.sharakuShop.price });

          case 1:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemCube3createImages',
    value: function convertItemCube3createImages(item) {
      var arr;
      return regeneratorRuntime.async(function convertItemCube3createImages$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            arr = typeof item.images[0] === 'undefined' ? [] : [item.images[0]];
            return context$2$0.abrupt('return', { images: arr });

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    // ヤフオクテンプレートへの変換
  }, {
    key: 'convertItemYauct',
    value: function convertItemYauct(def, item) {
      var idLength, titleLength, yauct, imgPrefix, i;
      return regeneratorRuntime.async(function convertItemYauct$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            idLength = 20;
            titleLength = 130;
            yauct = {};

            // ヤフオクテンプレートの初期値（ゆうパケット・宅配便で異なる）
            yauct = JSON.parse(JSON.stringify(def[item.delivery]));

            // 画像の記述
            imgPrefix = '画像';

            for (i = 0; i < item.images.length; i++) {
              yauct[imgPrefix + (i + 1)] = item.images[i];
            }

            // タイトル
            yauct['カテゴリ'] = item.mall.yauct.category;
            context$2$0.t0 = _utilText2['default'];
            context$2$0.next = 10;
            return regeneratorRuntime.awrap(this.getModelClass(item));

          case 10:
            context$2$0.t1 = context$2$0.sent;
            context$2$0.t2 = context$2$0.t1 + ' ';
            context$2$0.t3 = item.delivery;
            context$2$0.t4 = context$2$0.t2 + context$2$0.t3;
            context$2$0.t5 = context$2$0.t4 + ' ';
            context$2$0.t6 = item.name;
            context$2$0.t7 = context$2$0.t5 + context$2$0.t6;
            context$2$0.t8 = titleLength;
            yauct['タイトル'] = context$2$0.t0.substr8.call(context$2$0.t0, context$2$0.t7, context$2$0.t8);

            yauct['開始価格'] = item.sales_price;
            yauct['即決価格'] = item.sales_price;
            yauct['管理番号'] = item._id.toHexString().slice(-idLength);
            yauct['説明'] = item.description;
            yauct['JANコード・ISBNコード'] = item.jan_code;

            return context$2$0.abrupt('return', yauct);

          case 25:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'convertItemWowmaCreateDeliveryMethod',
    value: function convertItemWowmaCreateDeliveryMethod(itemCode) {
      var id, set, metrics, aggr, acceptDeliv, _iteratorNormalCompletion7, _didIteratorError7, _iteratorError7, _iterator7, _step7, del, deliveryMethod, i, _id;

      return regeneratorRuntime.async(function convertItemWowmaCreateDeliveryMethod$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            id = 'mall.wowma.itemCode';
            set = 'delivery';
            metrics = {
              'ゆうパケット': ['Post'],
              '宅配便': ['YU-Pack', 'Kangaroo']
            };
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.Items.aggregate([{
              $match: _defineProperty({}, id, itemCode)
            }, {
              $group: _defineProperty({
                _id: '$' + id
              }, set, { $addToSet: '$' + set })
            }, {
              $project: _defineProperty({
                _id: 0,
                itemCode: '$_id'
              }, set, '$' + set)
            }]).toArray());

          case 5:
            aggr = context$2$0.sent;
            acceptDeliv = [];
            _iteratorNormalCompletion7 = true;
            _didIteratorError7 = false;
            _iteratorError7 = undefined;
            context$2$0.prev = 10;

            for (_iterator7 = aggr[0].delivery[Symbol.iterator](); !(_iteratorNormalCompletion7 = (_step7 = _iterator7.next()).done); _iteratorNormalCompletion7 = true) {
              del = _step7.value;

              acceptDeliv = acceptDeliv.concat(metrics['' + del]);
            }
            context$2$0.next = 18;
            break;

          case 14:
            context$2$0.prev = 14;
            context$2$0.t0 = context$2$0['catch'](10);
            _didIteratorError7 = true;
            _iteratorError7 = context$2$0.t0;

          case 18:
            context$2$0.prev = 18;
            context$2$0.prev = 19;

            if (!_iteratorNormalCompletion7 && _iterator7['return']) {
              _iterator7['return']();
            }

          case 21:
            context$2$0.prev = 21;

            if (!_didIteratorError7) {
              context$2$0.next = 24;
              break;
            }

            throw _iteratorError7;

          case 24:
            return context$2$0.finish(21);

          case 25:
            return context$2$0.finish(18);

          case 26:
            deliveryMethod = new Array(5);

            for (i = 0; i < deliveryMethod.length; i++) {
              _id = typeof acceptDeliv[i] === 'undefined' ? 'NULL' : acceptDeliv[i];

              deliveryMethod[i] = { deliveryMethodSeq: i + 1, deliveryMethodId: _id };
            }

            return context$2$0.abrupt('return', { deliveryMethod: deliveryMethod });

          case 29:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[10, 14, 18, 26], [19,, 21, 25]]);
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る

  }], [{
    key: 'convertItemRobotin',
    value: function convertItemRobotin(item) {
      var newId, robotinItem, shopS;
      return regeneratorRuntime.async(function convertItemRobotin$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            newId = item._id.toHexString();
            robotinItem = {
              item: {
                'コントロールカラム': 'n',
                '新規登録ID': newId,
                '商品ID': null,
                '商品名': item.name,
                '規格': 'なし'
              },
              select: {
                'コントロールカラム': 'n',
                '新規登録ID': newId,
                '商品ID': null,
                '外部連携ID': null,
                '外部連携商品番号': '' + item.model + (item.class1_value === '' ? '' : '/' + item.class1_value) + (item.class2_value === '' ? '' : '/' + item.class2_value)
              },
              shopS: []
            };
            shopS = _collections.RobotinShop.find();

            shopS.forEach(function (shop) {
              var model = item.mall['' + shop.name]['' + shop.modelPath];
              var class1 = item.mall['' + shop.name]['' + shop.class1Path];
              var class2 = item.mall['' + shop.name]['' + shop.class2Path];

              robotinItem.shopS.push({
                'コントロールカラム': 'u',
                '新規登録ID': newId,
                '受注商品ID': null,
                '店舗ID': shop['店舗ID'],
                '店舗名': null,
                '受注商品番号': '' + model + class1 + class2,
                '有効フラグ': '有効'
              });
            });

            return context$2$0.abrupt('return', robotinItem);

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その1 item.csv

  }, {
    key: 'convertItemRobotinItem',
    value: function convertItemRobotinItem(item) {
      return {
        'コントロールカラム': 'n',
        '新規登録ID': item._id.toHexString(),
        '商品ID': null,
        '商品名': item.name,
        '規格': 'なし'
      };
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その2 select.csv

  }, {
    key: 'convertItemRobotinSelect',
    value: function convertItemRobotinSelect(item) {
      return {
        'コントロールカラム': 'n',
        '新規登録ID': item._id.toHexString(),
        '商品ID': null,
        '外部連携ID': null,
        '外部連携商品番号': '' + item.model + (item.class1_value === '' ? '' : '/' + item.class1_value) + (item.class2_value === '' ? '' : '/' + item.class2_value)
      };
    }

    //
    // Robot-in 外部連携商品番号の登録のためのデータを作る
    // その3 selectShop.csv

  }, {
    key: 'convertItemRobotinSelectShop',
    value: function convertItemRobotinSelectShop(shop, item) {
      var model = item.mall['' + shop.name]['' + shop.modelPath];
      var class1 = item.mall['' + shop.name]['' + shop.class1Path];
      var class2 = item.mall['' + shop.name]['' + shop.class2Path];

      return {
        'コントロールカラム': 'u',
        '新規登録ID': item._id.toHexString(),
        '受注商品ID': null,
        '店舗ID': shop['店舗ID'],
        '店舗名': null,
        '受注商品番号': '' + model + class1 + class2,
        '有効フラグ': '有効'
      };
    }
  }]);

  return ItemController;
})();

exports['default'] = ItemController;
module.exports = exports['default'];

// product * <-> * item
// product[]: 複数の商品を1パッケージとして販売
// product[{ids:[<ObjectId>],set:<Number>}]: 異なる流通経路、異なる原価・仕入れ値
// item: 異なるセール、販売形態
// ※ product からは、販売可能な在庫、利益計算のための情報を得る

// セット商品の場合、一番少ない商品数に合わせる

// アップロード済み画像の情報取得

// 検索条件の組み立て

// 登録した画像ファイル名一覧

// 検索条件の組み立て

/**
 * aggregation設定
 *
 * label: 属性名（配送方法、カラー、サイズなど）
 * current: 指定されたアイテム（item）が該当する項目
 * porject: バリエーション検索のキーとなるitem内のフィールド名 $[フィールド名]形式
 * query: aggregation対象とするドキュメントの検索条件
 */

// item が文字列なら、itemは任意のオブジェクトIDの末尾から任意の桁数の16進数

// 値変換

// product_id

// 商品タグを設定する

// 商品別送料を設定する

//
// 顧客向けバリエーション商品選択機能の実装
//

// 商品データを作る

// 価格を返す

// 画像リストのうち1つめだけを返す

// deliveryMethodSeq
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"wowmaApi.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/service/wowmaApi.js                                                                                        //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _requestPromise = require('request-promise');

var _requestPromise2 = _interopRequireDefault(_requestPromise);

var _xmlJs = require('xml-js');

var _utilError = require('../util/error');

var _utilError2 = _interopRequireDefault(_utilError);

var BASE_URI = 'https://api.manager.wowma.jp/wmshopapi';

var WowmaApi = (function () {
  function WowmaApi(plug, shopId) {
    _classCallCheck(this, WowmaApi);

    this.plug = plug;
    this.shopId = shopId;
  }

  // 商品情報更新

  _createClass(WowmaApi, [{
    key: 'updateItem',
    value: function updateItem(_updateItem) {
      var request, res;
      return regeneratorRuntime.async(function updateItem$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            request = '<request><shopId>' + this.shopId + '</shopId><updateItem>' + (0, _xmlJs.json2xml)(_updateItem, { compact: true }) + '</updateItem></request>';
            context$2$0.prev = 1;
            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.requestPost('updateItemInfo', request));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', { response: res, requestXML: request });

          case 8:
            context$2$0.prev = 8;
            context$2$0.t0 = context$2$0['catch'](1);
            throw Object.assign(_utilError2['default'].parse(context$2$0.t0), { requestXML: request });

          case 11:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[1, 8]]);
    }
  }, {
    key: 'requestPost',
    value: function requestPost(method, body) {
      var apiRequest, res;
      return regeneratorRuntime.async(function requestPost$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/' + method,
              body: body
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            // リクエスト発行
            context$2$0.next = 4;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 4:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 6:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStock',
    value: function updateStock(stockUpdateItem) {
      var apiRequest, res;
      return regeneratorRuntime.async(function updateStock$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            apiRequest = {
              method: 'POST',
              uri: BASE_URI + '/updateStock'
            };

            // 共通の接続設定と結合する
            Object.assign(apiRequest, this.plug);

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.updateStockCreateRequestBody(stockUpdateItem));

          case 4:
            apiRequest.body = context$2$0.sent;
            context$2$0.next = 7;
            return regeneratorRuntime.awrap((0, _requestPromise2['default'])(apiRequest));

          case 7:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 9:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'updateStockCreateRequestBody',
    value: function updateStockCreateRequestBody(stockUpdateItem) {
      var stockUpdateItemXML, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, item, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, e, var0, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, variation, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, key, apiRequestBody;

      return regeneratorRuntime.async(function updateStockCreateRequestBody$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            stockUpdateItemXML = '';
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 4;
            _iterator = stockUpdateItem[Symbol.iterator]();

          case 6:
            if (_iteratorNormalCompletion = (_step = _iterator.next()).done) {
              context$2$0.next = 87;
              break;
            }

            item = _step.value;
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 11;

            // 値のチェック
            for (_iterator2 = item.variations[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              e = _step2.value;

              // 在庫数の上限100
              if (e.stock > 100) e.stock = 100;
            }

            context$2$0.next = 19;
            break;

          case 15:
            context$2$0.prev = 15;
            context$2$0.t0 = context$2$0['catch'](11);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t0;

          case 19:
            context$2$0.prev = 19;
            context$2$0.prev = 20;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 22:
            context$2$0.prev = 22;

            if (!_didIteratorError2) {
              context$2$0.next = 25;
              break;
            }

            throw _iteratorError2;

          case 25:
            return context$2$0.finish(22);

          case 26:
            return context$2$0.finish(19);

          case 27:
            stockUpdateItemXML += '<stockUpdateItem>';
            stockUpdateItemXML += '<itemCode>' + item.itemCode + '</itemCode>';

            // 商品在庫種別を振り分け
            // 1 -> 通常商品
            // 2 -> 選択肢別在庫

            var0 = item.variations[0];

            if (!(var0.choicesStockHorizontalCode === '' && var0.choicesStockVerticalCode === '')) {
              context$2$0.next = 35;
              break;
            }

            // 通常商品
            stockUpdateItemXML += '<stockSegment>1</stockSegment>';
            stockUpdateItemXML += '<stockCount>' + var0.stock + '</stockCount>';
            context$2$0.next = 83;
            break;

          case 35:
            // 選択肢別在庫
            stockUpdateItemXML += '<stockSegment>2</stockSegment>';

            // リクエストボディを作成する
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 39;
            _iterator3 = item.variations[Symbol.iterator]();

          case 41:
            if (_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done) {
              context$2$0.next = 69;
              break;
            }

            variation = _step3.value;

            // 在庫設定タグの名前を差し替える
            variation.choicesStockCount = variation.stock;
            delete variation.stock;

            // xmlを構成する
            stockUpdateItemXML += '<choicesStocks>';
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 49;
            for (_iterator4 = Object.keys(variation)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              key = _step4.value;

              stockUpdateItemXML += '<' + key + '>' + variation[key] + '</' + key + '>';
            }
            context$2$0.next = 57;
            break;

          case 53:
            context$2$0.prev = 53;
            context$2$0.t1 = context$2$0['catch'](49);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 57:
            context$2$0.prev = 57;
            context$2$0.prev = 58;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 60:
            context$2$0.prev = 60;

            if (!_didIteratorError4) {
              context$2$0.next = 63;
              break;
            }

            throw _iteratorError4;

          case 63:
            return context$2$0.finish(60);

          case 64:
            return context$2$0.finish(57);

          case 65:
            stockUpdateItemXML += '</choicesStocks>';

          case 66:
            _iteratorNormalCompletion3 = true;
            context$2$0.next = 41;
            break;

          case 69:
            context$2$0.next = 75;
            break;

          case 71:
            context$2$0.prev = 71;
            context$2$0.t2 = context$2$0['catch'](39);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t2;

          case 75:
            context$2$0.prev = 75;
            context$2$0.prev = 76;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 78:
            context$2$0.prev = 78;

            if (!_didIteratorError3) {
              context$2$0.next = 81;
              break;
            }

            throw _iteratorError3;

          case 81:
            return context$2$0.finish(78);

          case 82:
            return context$2$0.finish(75);

          case 83:

            stockUpdateItemXML += '</stockUpdateItem>';

          case 84:
            _iteratorNormalCompletion = true;
            context$2$0.next = 6;
            break;

          case 87:
            context$2$0.next = 93;
            break;

          case 89:
            context$2$0.prev = 89;
            context$2$0.t3 = context$2$0['catch'](4);
            _didIteratorError = true;
            _iteratorError = context$2$0.t3;

          case 93:
            context$2$0.prev = 93;
            context$2$0.prev = 94;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 96:
            context$2$0.prev = 96;

            if (!_didIteratorError) {
              context$2$0.next = 99;
              break;
            }

            throw _iteratorError;

          case 99:
            return context$2$0.finish(96);

          case 100:
            return context$2$0.finish(93);

          case 101:
            apiRequestBody = '\n    <request>\n    <shopId>' + this.shopId + '</shopId>\n    ' + stockUpdateItemXML + '\n    </request>\n    ';
            return context$2$0.abrupt('return', apiRequestBody);

          case 103:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[4, 89, 93, 101], [11, 15, 19, 27], [20,, 22, 26], [39, 71, 75, 83], [49, 53, 57, 65], [58,, 60, 64], [76,, 78, 82], [94,, 96, 100]]);
    }
  }]);

  return WowmaApi;
})();

exports['default'] = WowmaApi;
module.exports = exports['default'];

// 接続オプションの作成

// 接続オプションの作成

// リクエスト発行

//
// stockUpdateItem =
// [
//   {
//     itemCode: <String>,
//     variations: [
//        {
//          choicesStockHorizontalCode: <String>,
//          choicesStockVerticalCode: <String>,
//          stock: <Number>
//        }
//     ]
//   }
// ]

// リクエストボディの作成

// リクエストボディを返す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"error.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/error.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var utilError = (function () {
  function utilError() {
    _classCallCheck(this, utilError);
  }

  _createClass(utilError, null, [{
    key: "parse",
    value: function parse(e) {
      var res = {};

      if (e instanceof Error) {
        res.message = e.message;
        res.name = e.name;
        res.fileName = e.fileName;
        res.lineNumber = e.lineNumber;
        res.columnNumber = e.columnNumber;
        res.stack = e.stack;
      } else {
        res = e;
      }

      return res;
    }
  }]);

  return utilError;
})();

exports["default"] = utilError;
module.exports = exports["default"];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mongo.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mongo.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mongodb = require('mongodb');

var MongoCollection = (function () {
  function MongoCollection() {
    _classCallCheck(this, MongoCollection);
  }

  _createClass(MongoCollection, null, [{
    key: 'get',
    value: function get(plug, collection) {
      var client, db;
      return regeneratorRuntime.async(function get$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(_mongodb.MongoClient.connect(plug.uri));

          case 2:
            client = context$2$0.sent;
            db = client.db(plug.database);
            return context$2$0.abrupt('return', db.collection(collection));

          case 5:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }]);

  return MongoCollection;
})();

exports.MongoCollection = MongoCollection;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/mysql.js                                                                                              //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _toConsumableArray(arr) { if (Array.isArray(arr)) { for (var i = 0, arr2 = Array(arr.length); i < arr.length; i++) arr2[i] = arr[i]; return arr2; } else { return Array.from(arr); } }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _mysql = require('mysql');

var _mysql2 = _interopRequireDefault(_mysql);

var _moment = require('moment');

var _moment2 = _interopRequireDefault(_moment);

var MySQL = (function () {
  function MySQL(profile) {
    _classCallCheck(this, MySQL);

    // コネクションプール初期化
    this.pool = _mysql2['default'].createPool(profile);

    // 複数行ステートメント対応
    var profileMulti = { multipleStatements: true };
    Object.assign(profileMulti, profile);
    this.poolMulti = _mysql2['default'].createPool(profileMulti);
  }

  _createClass(MySQL, [{
    key: 'query',

    /**
     *
     * @param {String} sql
     */
    value: function query(sql) {
      // コネクション確立
      // let con = await this.getCon();
      return this.getCon().then(function (con) {
        return new Promise(function (resolve, reject) {
          // クエリ送信
          con.query(sql, function (e, res) {
            // コネクション開放
            con.release();
            if (e) {
              reject(e);
            } else resolve(res);
          });
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'queryInsert_',
    value: function queryInsert_(sql) {
      var res;
      return regeneratorRuntime.async(function queryInsert_$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query(sql));

          case 2:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 4:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }

    /**
     *
     * @param {String} table
     * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryInsert',
    value: function queryInsert(table) {
      var data = arguments.length <= 1 || arguments[1] === undefined ? {} : arguments[1];
      var dataSql = arguments.length <= 2 || arguments[2] === undefined ? {} : arguments[2];

      var sql, map, _iteratorNormalCompletion, _didIteratorError, _iteratorError, _iterator, _step, k, _iteratorNormalCompletion2, _didIteratorError2, _iteratorError2, _iterator2, _step2, res;

      return regeneratorRuntime.async(function queryInsert$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'INSERT INTO ' + table + ' ';
            map = new Map();
            _iteratorNormalCompletion = true;
            _didIteratorError = false;
            _iteratorError = undefined;
            context$2$0.prev = 5;

            for (_iterator = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
              k = _step.value;

              if (data[k] === null) {
                map.set(k, 'NULL');
              } else if (data[k].constructor.name === 'Date') {
                // 日付を変換
                map.set(k, '"' + MySQL.formatDate(data[k]) + '"');
              } else {
                map.set(k, '' + _mysql2['default'].escape(data[k]));
              }
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError = true;
            _iteratorError = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion && _iterator['return']) {
              _iterator['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion2 = true;
            _didIteratorError2 = false;
            _iteratorError2 = undefined;
            context$2$0.prev = 24;
            for (_iterator2 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion2 = (_step2 = _iterator2.next()).done); _iteratorNormalCompletion2 = true) {
              k = _step2.value;

              map.set(k, dataSql[k] === null ? 'NULL' : dataSql[k]);
            }

            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError2 = true;
            _iteratorError2 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion2 && _iterator2['return']) {
              _iterator2['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError2) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError2;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += '( ' + [].concat(_toConsumableArray(map.keys())).join(',') + ' ) ';

            sql += 'VALUES( ' + [].concat(_toConsumableArray(map.values())).join(',') + ' ) ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res.insertId);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    /**
     *
     * @param {String} table
     * @param {String} filter SQL UPDATEステートメントのWHERE句
     * @param {Object} data 文字列のパラメーター
     * @param {Object} dataSql SQLステートメントや数字など文字列以外のパラメータ
     */
  }, {
    key: 'queryUpdate',
    value: function queryUpdate(table, filter, data, dataSql) {
      var sql, updates, _iteratorNormalCompletion3, _didIteratorError3, _iteratorError3, _iterator3, _step3, k, _iteratorNormalCompletion4, _didIteratorError4, _iteratorError4, _iterator4, _step4, res;

      return regeneratorRuntime.async(function queryUpdate$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            sql = 'UPDATE ' + table + ' SET ';
            updates = [];
            _iteratorNormalCompletion3 = true;
            _didIteratorError3 = false;
            _iteratorError3 = undefined;
            context$2$0.prev = 5;

            for (_iterator3 = Object.keys(data)[Symbol.iterator](); !(_iteratorNormalCompletion3 = (_step3 = _iterator3.next()).done); _iteratorNormalCompletion3 = true) {
              k = _step3.value;

              updates.push(k + '=' + _mysql2['default'].escape(data[k]));
            }
            context$2$0.next = 13;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](5);
            _didIteratorError3 = true;
            _iteratorError3 = context$2$0.t0;

          case 13:
            context$2$0.prev = 13;
            context$2$0.prev = 14;

            if (!_iteratorNormalCompletion3 && _iterator3['return']) {
              _iterator3['return']();
            }

          case 16:
            context$2$0.prev = 16;

            if (!_didIteratorError3) {
              context$2$0.next = 19;
              break;
            }

            throw _iteratorError3;

          case 19:
            return context$2$0.finish(16);

          case 20:
            return context$2$0.finish(13);

          case 21:
            _iteratorNormalCompletion4 = true;
            _didIteratorError4 = false;
            _iteratorError4 = undefined;
            context$2$0.prev = 24;
            for (_iterator4 = Object.keys(dataSql)[Symbol.iterator](); !(_iteratorNormalCompletion4 = (_step4 = _iterator4.next()).done); _iteratorNormalCompletion4 = true) {
              k = _step4.value;

              updates.push(k + '=' + dataSql[k]);
            }
            context$2$0.next = 32;
            break;

          case 28:
            context$2$0.prev = 28;
            context$2$0.t1 = context$2$0['catch'](24);
            _didIteratorError4 = true;
            _iteratorError4 = context$2$0.t1;

          case 32:
            context$2$0.prev = 32;
            context$2$0.prev = 33;

            if (!_iteratorNormalCompletion4 && _iterator4['return']) {
              _iterator4['return']();
            }

          case 35:
            context$2$0.prev = 35;

            if (!_didIteratorError4) {
              context$2$0.next = 38;
              break;
            }

            throw _iteratorError4;

          case 38:
            return context$2$0.finish(35);

          case 39:
            return context$2$0.finish(32);

          case 40:
            sql += updates.join(',');

            sql += ' WHERE ' + filter + ' ';

            context$2$0.next = 44;
            return regeneratorRuntime.awrap(this.query(sql));

          case 44:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 46:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[5, 9, 13, 21], [14,, 16, 20], [24, 28, 32, 40], [33,, 35, 39]]);
    }

    // enable to use multiple statements
  }, {
    key: 'queryMulti',
    value: function queryMulti(sql) {
      var poolSwap, res;
      return regeneratorRuntime.async(function queryMulti$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            poolSwap = this.pool;

            this.pool = this.poolMulti;
            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(this.query(sql));

          case 5:
            res = context$2$0.sent;
            return context$2$0.abrupt('return', res);

          case 7:
            context$2$0.prev = 7;

            this.pool = poolSwap;
            return context$2$0.finish(7);

          case 10:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2,, 7, 10]]);
    }
  }, {
    key: 'startTransaction',
    value: function startTransaction() {
      return regeneratorRuntime.async(function startTransaction$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('START TRANSACTION;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'commit',
    value: function commit() {
      return regeneratorRuntime.async(function commit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('COMMIT;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'rollback',
    value: function rollback() {
      return regeneratorRuntime.async(function rollback$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(this.query('ROLLBACK;'));

          case 2:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: 'streamingQuery',
    value: function streamingQuery(sql) {
      var _this = this;

      var onResult = arguments.length <= 1 || arguments[1] === undefined ? function (record) {} : arguments[1];
      var onError = arguments.length <= 2 || arguments[2] === undefined ? function (e) {} : arguments[2];

      return this.getCon().then(function (con) {
        return new Promise(function callee$3$0(resolve, reject) {
          return regeneratorRuntime.async(function callee$3$0$(context$4$0) {
            while (1) switch (context$4$0.prev = context$4$0.next) {
              case 0:
                // クエリ送信
                con.query(sql).on('result', function (record) {
                  con.pause();
                  onResult(record);
                  con.resume();
                }).on('error', function (e) {
                  onError(e);
                }).on('end', function () {
                  con.release();
                  resolve();
                });

              case 1:
              case 'end':
                return context$4$0.stop();
            }
          }, null, _this);
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }, {
    key: 'getCon',
    value: function getCon() {
      var _this2 = this;

      return new Promise(function (resolve, reject) {
        // プールからのコネクション獲得
        _this2.pool.getConnection(function (e, con) {
          if (e) {
            reject(e);
          } else {
            resolve(con);
          }
        });
      })['catch'](function (e) {
        throw e;
      });
    }
  }], [{
    key: 'formatDate',
    value: function formatDate(date) {
      return (0, _moment2['default'])(date).format().substring(0, 19).replace('T', ' ');
    }
  }]);

  return MySQL;
})();

exports['default'] = MySQL;
module.exports = exports['default'];

// let res = await this.query(sql);
// return res.insertId;
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"packet.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/packet.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, "__esModule", {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ("value" in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError("Cannot call a class as a function"); } }

var Packet = (function () {
  function Packet(packetSize) {
    _classCallCheck(this, Packet);

    this.packetSize = packetSize;
    this.onPacketStart = null;
    this.onPacket = null;
    this.onPacketEnd = null;
    this.count = 0;
    this.packetCount = 0;
  }

  _createClass(Packet, [{
    key: "submit",
    value: function submit(arg) {
      return regeneratorRuntime.async(function submit$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            if (!(this.count % this.packetSize === 0)) {
              context$2$0.next = 4;
              break;
            }

            if (!this.onPacketStart) {
              context$2$0.next = 4;
              break;
            }

            context$2$0.next = 4;
            return regeneratorRuntime.awrap(this.onPacketStart(this.packetCount));

          case 4:
            if (!this.onPacket) {
              context$2$0.next = 7;
              break;
            }

            context$2$0.next = 7;
            return regeneratorRuntime.awrap(this.onPacket(arg));

          case 7:
            this.count++;
            // packetSizeの回数ごとに、終了処理を呼び出す
            if (this.count % this.packetSize === 0) {
              this.close();
              this.packetCount++;
            }

          case 9:
          case "end":
            return context$2$0.stop();
        }
      }, null, this);
    }
  }, {
    key: "close",
    value: function close() {
      if (this.onPacketEnd) {
        this.onPacketEnd(this.packetCount);
      }
    }
  }]);

  return Packet;
})();

exports["default"] = Packet;
module.exports = exports["default"];

// packetSizeの回数ごとに、初期化を呼び出す
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/report.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _interopRequireDefault(obj) { return obj && obj.__esModule ? obj : { 'default': obj }; }

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var _error = require('./error');

var _error2 = _interopRequireDefault(_error);

var _meteorMeteor = require('meteor/meteor');

var _collections = require('../collections');

var _uniqid = require('uniqid');

var _uniqid2 = _interopRequireDefault(_uniqid);

var Report = (function () {
  function Report() {
    _classCallCheck(this, Report);

    this.record = [];
    this.iterators = [];
    this.iterator = null;
  }

  // private

  _createClass(Report, [{
    key: 'setupIterator',
    value: function setupIterator(phaseId) {
      this.iterator = new Iterator(phaseId);
      this.iterators.push(this.iterator);
    }
  }, {
    key: 'phase',
    value: function phase() {
      var _this = this;

      var name = arguments.length <= 0 || arguments[0] === undefined ? '' : arguments[0];
      var fn = arguments.length <= 1 || arguments[1] === undefined ? function callee$2$0() {
        return regeneratorRuntime.async(function callee$2$0$(context$3$0) {
          while (1) switch (context$3$0.prev = context$3$0.next) {
            case 0:
            case 'end':
              return context$3$0.stop();
          }
        }, null, _this);
      } : arguments[1];
      var rec, res;
      return regeneratorRuntime.async(function phase$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            rec = {
              phaseId: (0, _uniqid2['default'])()
            };

            this.setupIterator(rec.phaseId);

            context$2$0.prev = 2;
            context$2$0.next = 5;
            return regeneratorRuntime.awrap(fn());

          case 5:
            res = context$2$0.sent;

            Object.assign(rec, {
              type: 'success',
              phase: name,
              result: res
            });
            context$2$0.next = 12;
            break;

          case 9:
            context$2$0.prev = 9;
            context$2$0.t0 = context$2$0['catch'](2);

            Object.assign(rec, {
              type: 'error',
              phase: name,
              result: _error2['default'].parse(context$2$0.t0)
            });

          case 12:
            context$2$0.prev = 12;

            // ループ処理のレポートを作成
            if (this.iterator.metric.total) {
              Object.assign(rec, {
                iterator: this.iterator.metric
              });
            }
            // タイムスタンプ
            rec.timeStamp = new Date();
            // レポートをデータベースに記録
            _collections.Logs.insert(rec);

            // 呼び出し元用レポートに追加
            this.record.push(rec);
            return context$2$0.finish(12);

          case 18:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[2, 9, 12, 18]]);
    }

    // カーソルをループし、与えられた関数を実行
    // 呼び出す関数の引数にはカーソルから得られたドキュメントを渡す
  }, {
    key: 'forEachOnCursor',
    value: function forEachOnCursor(cur, fn) {
      var doc, res;
      return regeneratorRuntime.async(function forEachOnCursor$(context$2$0) {
        while (1) switch (context$2$0.prev = context$2$0.next) {
          case 0:
            context$2$0.next = 2;
            return regeneratorRuntime.awrap(cur.hasNext());

          case 2:
            if (!context$2$0.sent) {
              context$2$0.next = 18;
              break;
            }

            context$2$0.next = 5;
            return regeneratorRuntime.awrap(cur.next());

          case 5:
            doc = context$2$0.sent;
            context$2$0.prev = 6;
            context$2$0.next = 9;
            return regeneratorRuntime.awrap(fn(doc));

          case 9:
            res = context$2$0.sent;

            this.iSuccess(res);
            context$2$0.next = 16;
            break;

          case 13:
            context$2$0.prev = 13;
            context$2$0.t0 = context$2$0['catch'](6);

            this.iError(context$2$0.t0);

          case 16:
            context$2$0.next = 0;
            break;

          case 18:
            cur.close();

          case 19:
          case 'end':
            return context$2$0.stop();
        }
      }, null, this, [[6, 13]]);
    }
  }, {
    key: 'iSuccess',
    value: function iSuccess(newRecord) {
      this.iterator.success(newRecord);
    }
  }, {
    key: 'iError',
    value: function iError(newRecord) {
      this.iterator.error(_error2['default'].parse(newRecord));
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      var iteError = this.iterators.find(function (e) {
        return e.errorOcurred();
      });
      var phaError = false;
      var _iteratorNormalCompletion = true;
      var _didIteratorError = false;
      var _iteratorError = undefined;

      try {
        for (var _iterator = this.record[Symbol.iterator](), _step; !(_iteratorNormalCompletion = (_step = _iterator.next()).done); _iteratorNormalCompletion = true) {
          var rec = _step.value;

          if (rec.type === 'error') {
            phaError = true;
            break;
          }
        }
      } catch (err) {
        _didIteratorError = true;
        _iteratorError = err;
      } finally {
        try {
          if (!_iteratorNormalCompletion && _iterator['return']) {
            _iterator['return']();
          }
        } finally {
          if (_didIteratorError) {
            throw _iteratorError;
          }
        }
      }

      return iteError || phaError;
    }
  }, {
    key: 'publish',
    value: function publish() {
      // 呼び出し元へレポート
      if (this.errorOcurred()) {
        throw new _meteorMeteor.Meteor.Error(this.record);
      }
      return this.record;
    }
  }]);

  return Report;
})();

exports['default'] = Report;

var Iterator = (function () {
  function Iterator(phaseId) {
    _classCallCheck(this, Iterator);

    this.metric = {
      total: 0,
      success: 0,
      error: 0,
      phaseId: phaseId
    };
    this.lastError = null;
  }

  _createClass(Iterator, [{
    key: 'success',
    value: function success(newRecord) {
      if (newRecord) {
        this.log(newRecord, true);
      }
      this.metric.success++;
      this.metric.total++;
    }
  }, {
    key: 'error',
    value: function error(newRecord) {
      // 直前と同じエラーは省く
      if (JSON.stringify(this.lastError) !== JSON.stringify(newRecord)) {
        if (newRecord && newRecord !== {} && newRecord !== '') {
          this.log(newRecord, false);
          this.lastError = newRecord;
        }
      }
      this.metric.error++;
      this.metric.total++;
    }
  }, {
    key: 'log',
    value: function log(newRecord, isSuccess /* true => success or false => error */) {
      var rec = {
        success: isSuccess,
        phaseId: this.metric.phaseId,
        message: newRecord,
        timeStamp: new Date()
      };
      _collections.Logs.insert(rec);
    }
  }, {
    key: 'errorOcurred',
    value: function errorOcurred() {
      return this.metric.error;
    }
  }]);

  return Iterator;
})();

module.exports = exports['default'];

// リクエスト発行
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"text.js":function(require,exports,module){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/util/text.js                                                                                               //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _createClass = (function () { function defineProperties(target, props) { for (var i = 0; i < props.length; i++) { var descriptor = props[i]; descriptor.enumerable = descriptor.enumerable || false; descriptor.configurable = true; if ('value' in descriptor) descriptor.writable = true; Object.defineProperty(target, descriptor.key, descriptor); } } return function (Constructor, protoProps, staticProps) { if (protoProps) defineProperties(Constructor.prototype, protoProps); if (staticProps) defineProperties(Constructor, staticProps); return Constructor; }; })();

function _classCallCheck(instance, Constructor) { if (!(instance instanceof Constructor)) { throw new TypeError('Cannot call a class as a function'); } }

var TextUtil = (function () {
  function TextUtil() {
    _classCallCheck(this, TextUtil);
  }

  _createClass(TextUtil, null, [{
    key: 'substr8',
    value: function substr8(text, len, truncation) {
      if (truncation === undefined) {
        truncation = '';
      }
      var textArray = text.split('');
      var count = 0;
      var str = '';
      for (var i = 0; i < textArray.length; i++) {
        var n = escape(textArray[i]);
        if (n.length < 4) count++;else count += 2;
        if (count > len) {
          return str + truncation;
        }
        str += text.charAt(i);
      }
      return text;
    }
  }]);

  return TextUtil;
})();

exports['default'] = TextUtil;
module.exports = exports['default'];
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"collections.js":function(require,exports){

////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                    //
// imports/collections.js                                                                                             //
//                                                                                                                    //
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                      //
Object.defineProperty(exports, '__esModule', {
  value: true
});

var _meteorMeteor = require('meteor/meteor');

var _meteorMongo = require('meteor/mongo');

var Logs = new _meteorMongo.Mongo.Collection('logs', { idGeneration: 'MONGO' });
exports.Logs = Logs;
var Uploads = new _meteorMongo.Mongo.Collection('uploads', { idGeneration: 'MONGO' });
exports.Uploads = Uploads;
var RobotinShop = new _meteorMongo.Mongo.Collection('robotinShop', { idGeneration: 'MONGO' });

exports.RobotinShop = RobotinShop;
var Configs = new _meteorMongo.Mongo.Collection('configs', { idGeneration: 'MONGO' });

exports.Configs = Configs;
if (_meteorMeteor.Meteor.isServer) {
  _meteorMeteor.Meteor.publish('configs', function () {
    return Configs.find();
  });
}

if (_meteorMeteor.Meteor.isClient) {
  _meteorMeteor.Meteor.subscribe('configs');
}
////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/robotin.js");
require("/server/tooltest.js");
require("/server/wowma.js");
require("/server/wowmaApi.js");
require("/server/yauct.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvY3ViZW1pZy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2NvbGxlY3Rpb24uanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9qbGluZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9yb2JvdGluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvdG9vbHRlc3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci93b3dtYS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIveWF1Y3QuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL3NlcnZlci9tYWluLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2dyb3Vwcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXIuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvc2VydmljZS9pdGVtcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9zZXJ2aWNlL3dvd21hQXBpLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvZXJyb3IuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9tb25nby5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL215c3FsLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvcGFja2V0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvcmVwb3J0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvdGV4dC5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9ucy5qcyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7a0JBS2UsSUFBSTs7OztzQkFDQSxRQUFROzs7Ozs7aUNBR0osb0JBQW9COzs7O2tDQUdwQyw4QkFBOEI7O0FBQ3JDLElBQUksb0JBQW9CLEdBQUcscUNBQVksQ0FBQzs7QUFFeEMsSUFBTSxLQUFLLEdBQUcsZUFBZSxDQUFDOzs7QUFHOUIsTUFBTSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLG9CQUFvQixDQUFDLENBQUM7QUFDeEQsTUFBTSxDQUFDLGVBQWUsQ0FBQyxHQUFHLENBQUMsS0FBSyxFQUFFLFVBQUMsR0FBRyxFQUFFLElBQUksRUFBSzs7O0FBRy9DLE1BQU0sTUFBTSxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsZ0JBQUcsUUFBUSxDQUFDLENBQUM7QUFDN0MsTUFBTSxNQUFNLEdBQUcsTUFBTSxDQUFDLFNBQVMsQ0FBQyxnQkFBRyxTQUFTLENBQUMsQ0FBQztBQUM5QyxNQUFNLFFBQVEsR0FBRywwQkFBUSxDQUFDOzs7Ozs7O0FBRTFCLHlCQUFpQixHQUFHLENBQUMsS0FBSyxDQUFDLElBQUksOEhBQUU7VUFBeEIsSUFBSTs7QUFDWCxVQUFNLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxDQUFDOzs7QUFHL0IsVUFBSSxRQUFRLEdBQU0sMEJBQVEsU0FBTTs7O0FBR2hDLFVBQUksUUFBUSxHQUFHLEdBQUcsQ0FBQyxJQUFJLENBQUMsUUFBUSxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUM7Ozs7O0FBS2xELFVBQUksR0FBRyxHQUFHO0FBQ1IsZ0JBQVEsRUFBRSxRQUFRO0FBQ2xCLHNCQUFjLEVBQUUsSUFBSSxDQUFDLElBQUk7QUFDekIsd0JBQWdCLEVBQUUsUUFBUTtPQUMzQixDQUFDOztBQUVGLFVBQUc7QUFDRCxjQUFNLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDO09BQ3hCLENBQ0QsT0FBTSxHQUFHLEVBQUM7QUFDUixXQUFHLENBQUMsS0FBSyxHQUFHLEdBQUcsQ0FBQztPQUNqQjtBQUNELGtDQUFRLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQzs7QUFFcEIsYUFBTyxJQUFJLENBQUM7S0FFYjs7Ozs7Ozs7Ozs7Ozs7OztBQUFBLEdBQUM7QUFDRixNQUFJLENBQUMsU0FBUyxDQUFDLEdBQUcsQ0FBQyxDQUFDO0FBQ3BCLE1BQUksQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQztBQUN0QixZQUFRLEVBQUUsUUFBUTtBQUNsQixXQUFPLEVBQUUsR0FBRyxDQUFDLElBQUksQ0FBQyxRQUFRO0dBQzNCLENBQUMsQ0FBQyxDQUFDO0NBRUwsQ0FBQyxDOzs7Ozs7Ozs7Ozs7Ozs7OztzQkM3RGlCLFFBQVE7Ozs7NEJBRUosZUFBZTs7Z0NBQ3BCLDBCQUEwQjs7OztpQ0FDekIsMkJBQTJCOzs7O3VDQUl2QyxpQ0FBaUM7O3dDQUdqQyxrQ0FBa0M7O0FBRXpDLElBQUksR0FBRyxHQUFHLFNBQVM7O0FBRW5CLHFCQUFPLE9BQU8seURBRUYsR0FBRyxlQUFZLG9CQUFDLE1BQU07TUFDMUIsTUFBTSxFQUtOLE1BQU0sRUFNTixTQUFTLEVBRVQsS0FBSzs7Ozs7O0FBYkwsY0FBTSxHQUFHLG9DQUFZO0FBS3JCLGNBQU0sR0FBRyxxQ0FBVyxNQUFNLENBQUMsV0FBVyxDQUFDO0FBTXZDLGlCQUFTLEdBQUcsZ0JBQWdCO0FBRTVCLGFBQUssR0FBRyxrQ0FBVSxNQUFNLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQzs7d0NBRWhDLE1BQU0sQ0FBQyxLQUFLLENBQUMsd0JBQXdCLEVBQ3pDOzs7OztnREFDUSxLQUFLLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQzs7Ozs7OztTQUM3QixDQUFDOzs7O3dDQUtFLE1BQU0sQ0FBQyxLQUFLLENBQUMsdUJBQXVCLEVBQ3hDO2NBQ00sR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzdCLDRCQUFVLEVBQUUsb0JBQU8sTUFBTTt3QkFhbkIsR0FBRyxFQXdHSCxRQUFRLEVBRVIsVUFBVSxFQUVWLGFBQWEsRUFHWCxJQUFHOzs7OztBQS9HTCw2QkFBRyw2ZEFLTyxNQUFNLENBQUMsV0FBVyxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLEdBQUcsV0FBTSxNQUFNLENBQUMsR0FBRyxXQUFNLE1BQU0sQ0FBQyxVQUFVLFdBQU0sTUFBTSxDQUFDLElBQUksV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxNQUFNLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxZQUFZLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxPQUFPLFdBQU0sTUFBTSxDQUFDLE1BQU0sV0FBTSxNQUFNLENBQUMsTUFBTSxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsS0FBSyxXQUFNLE1BQU0sQ0FBQyxLQUFLLFdBQU0sTUFBTSxDQUFDLEtBQUssV0FBTSxNQUFNLENBQUMsUUFBUSxXQUFNLE1BQU0sQ0FBQyxJQUFJLFdBQU0sTUFBTSxDQUFDLFVBQVUsV0FBTSxNQUFNLENBQUMsY0FBYyxXQUFNLE1BQU0sQ0FBQyxhQUFhLFdBQU0sTUFBTSxDQUFDLFNBQVMsV0FBTSxNQUFNLENBQUMsU0FBUyxXQUFNLE1BQU0sQ0FBQyxJQUFJLFdBQU0sTUFBTSxDQUFDLFdBQVcsV0FBTSxNQUFNLENBQUMsV0FBVyxXQUFNLE1BQU0sQ0FBQyxPQUFPOzs7MERBS3pyQixLQUFLLENBQUMsV0FBVyxDQUNyQixjQUFjLEVBQUU7QUFDZCx1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsK0JBQUcsRUFBRSxNQUFNLENBQUMsR0FBRztBQUNmLCtCQUFHLEVBQUUsTUFBTSxDQUFDLEdBQUc7QUFDZixzQ0FBVSxFQUFFLE1BQU0sQ0FBQyxVQUFVO0FBQzdCLGdDQUFJLEVBQUUsTUFBTSxDQUFDLElBQUk7QUFDakIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQix3Q0FBWSxFQUFFLE1BQU0sQ0FBQyxZQUFZO0FBQ2pDLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO0FBQ3ZCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsb0NBQVEsRUFBRSxNQUFNLENBQUMsUUFBUTtBQUN6QixnQ0FBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO0FBQ2pCLHNDQUFVLEVBQUUsTUFBTSxDQUFDLFVBQVU7QUFDN0IsMENBQWMsRUFBRSxNQUFNLENBQUMsY0FBYztBQUNyQyx5Q0FBYSxFQUFFLE1BQU0sQ0FBQyxhQUFhO0FBQ25DLHFDQUFTLEVBQUUsTUFBTSxDQUFDLFNBQVM7QUFDM0IscUNBQVMsRUFBRSxNQUFNLENBQUMsU0FBUztBQUMzQixnQ0FBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO0FBQ2pCLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQixtQ0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPOzJCQUN4QixDQUNGOzs7Ozs7Ozs7O0FBRUQsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7OzswREFLVixLQUFLLENBQUMsV0FBVyxDQUNyQixzQkFBc0IsRUFBRTtBQUN0QiwrQ0FBbUIsRUFBRSxJQUFJO0FBQ3pCLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0Isc0NBQVUsRUFBRSxNQUFNLENBQUMsVUFBVTtBQUM3QixnQ0FBSSxFQUFFLE1BQU0sQ0FBQyxJQUFJO0FBQ2pCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsa0NBQU0sRUFBRSxNQUFNLENBQUMsTUFBTTtBQUNyQixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsd0NBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtBQUNqQyxpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTztBQUN2QixrQ0FBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNO0FBQ3JCLGtDQUFNLEVBQUUsTUFBTSxDQUFDLE1BQU07QUFDckIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsaUNBQUssRUFBRSxNQUFNLENBQUMsS0FBSztBQUNuQixpQ0FBSyxFQUFFLE1BQU0sQ0FBQyxLQUFLO0FBQ25CLGlDQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIsdUNBQVcsRUFBRSxNQUFNLENBQUMsV0FBVztBQUMvQix1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLG1DQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU87MkJBQ3hCLENBQ0Y7Ozs7Ozs7Ozs7QUFFRCxnQ0FBTSxDQUFDLE1BQU0sZ0JBQUc7Ozs7OzBEQUtWLEtBQUssQ0FBQyxXQUFXLENBQ3JCLHVCQUF1QixFQUFFO0FBQ3ZCLDhCQUFFLEVBQUUsSUFBSTtBQUNSLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0Isd0NBQVksRUFBRSxNQUFNLENBQUMsWUFBWTtBQUNqQyx1Q0FBVyxFQUFFLE1BQU0sQ0FBQyxXQUFXO0FBQy9CLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsbUNBQU8sRUFBRSxNQUFNLENBQUMsT0FBTzsyQkFDeEIsQ0FDRjs7Ozs7Ozs7OztBQUVELGdDQUFNLENBQUMsTUFBTSxnQkFBRzs7O0FBS2Qsa0NBQVEsR0FBRyxvQkFBTyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsUUFBUSxDQUFDLFFBQVEsQ0FBQyxDQUFDLFNBQVMsQ0FBQyxDQUFDLEVBQUUsRUFBRSxDQUFDO0FBRXBFLG9DQUFVLEdBQU0sTUFBTSxDQUFDLE1BQU0sU0FBSSxNQUFNLENBQUMsTUFBTSx3QkFBbUIsTUFBTSxDQUFDLFdBQVc7QUFFbkYsdUNBQWEsR0FBRyxNQUFNLENBQUMsS0FBSyxHQUFHLEdBQUc7OzswREFHcEIsS0FBSyxDQUFDLFdBQVcsQ0FDL0IsWUFBWSxFQUFFO0FBQ1oscUNBQVMsRUFBRSxJQUFJO0FBQ2YscUNBQVMsRUFBRSxRQUFRO0FBQ25CLHVDQUFXLEVBQUUsQ0FBQztBQUNkLHVDQUFXLEVBQUUsVUFBVTtBQUN2Qix5Q0FBYSxFQUFFLENBQUM7QUFDaEIsMkNBQWUsRUFBRSxDQUFDO0FBQ2xCLDBDQUFjLEVBQUUsQ0FBQztBQUNqQiwwQ0FBYyxFQUFFLGFBQWE7QUFDN0IseUNBQWEsRUFBRSxJQUFJO0FBQ25CLHVDQUFXLEVBQUUsQ0FBQztBQUNkLHlDQUFhLEVBQUUsQ0FBQztBQUNoQiw4Q0FBa0IsRUFBRSxJQUFJO0FBQ3hCLHVDQUFXLEVBQUUsTUFBTSxDQUFDLFdBQVc7QUFDL0IsK0NBQW1CLEVBQUUscUJBQXFCO0FBQzFDLDZDQUFpQixFQUFFLHFCQUFxQjtBQUN4QyxtQ0FBTyxFQUFFLENBQUM7MkJBQ1gsRUFBRTtBQUNELHVDQUFXLEVBQUUsT0FBTztBQUNwQix1Q0FBVyxFQUFFLE9BQU87MkJBQ3JCLENBQ0Y7OztBQXRCRyw4QkFBRzs7Ozs7Ozs7QUF3QlAsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7Ozs7O21CQUVuQjtpQkFDRixFQUNELG9CQUFPLENBQUM7Ozs7QUFDTiw4QkFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFDLENBQUM7Ozs7Ozs7aUJBQ2pCLENBQ0E7OztBQTVKRyxtQkFBRztvREE4SkEsR0FBRzs7Ozs7OztTQUNYLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUVLLHFCQUFxQixFQUFDLDRCQUFDLE9BQU87TUFDOUIsRUFBRSxFQUNGLEdBQUc7Ozs7QUFESCxVQUFFLEdBQUcsa0NBQVUsT0FBTyxDQUFDOzt3Q0FDWCxFQUFFLENBQUMsS0FBSyxDQUFDLGdCQUFnQixDQUFDOzs7QUFBdEMsV0FBRzs0Q0FDQSxHQUFHOzs7Ozs7O0NBQ1gsb0JBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2dDQ3JOOEIsMEJBQTBCOzs0QkFDckMsZUFBZTs7QUFFcEMsSUFBSSxHQUFHLEdBQUcsa0JBQWtCOztBQUU1QixxQkFBTyxPQUFPLHlEQUVGLEdBQUcsWUFBUyxvQkFBQyxJQUFJO01BQUUsS0FBSyx5REFBRyxFQUFFO01BQUUsVUFBVSx5REFBRyxFQUFFO01BQ2xELElBQUksRUFDSixHQUFHOzs7Ozt3Q0FEVSxrQ0FBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsVUFBVSxDQUFDOzs7QUFBdkQsWUFBSTs7d0NBQ1EsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLEVBQUUsRUFBQyxVQUFVLEVBQUUsVUFBVSxFQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUU7OztBQUFoRSxXQUFHOzRDQUNBLEdBQUc7Ozs7Ozs7Q0FDWCxvQ0FFUyxHQUFHLGlCQUFjLG9CQUFDLElBQUk7TUFBRSxLQUFLLHlEQUFHLEVBQUU7TUFDdEMsSUFBSSxFQUNKLEdBQUc7Ozs7O3dDQURVLGtDQUFnQixHQUFHLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUM7OztBQUF2RCxZQUFJOzt3Q0FDUSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQyxDQUFDLE9BQU8sRUFBRTs7O0FBQTNDLFdBQUc7NENBQ0EsR0FBRzs7Ozs7OztDQUNYLG9CQUVELEM7Ozs7Ozs7Ozs7Ozs7Ozs7O21DQ25CeUIsNkJBQTZCOzs7OzRCQUNuQyxlQUFlOztBQUVwQyxJQUFJLEdBQUcsR0FBRyxhQUFhOztBQUV2QixxQkFBTyxPQUFPLHlEQU9GLEdBQUcsZ0JBQWEsb0JBQUMsSUFBSSxFQUFFLFFBQVEsRUFBRSxLQUFLO01BQUUsTUFBTSx5REFBRyxJQUFJO01BQUUsTUFBTSx5REFBRyxJQUFJO01BQ3hFLE9BQU8sRUFFUCxRQUFROzs7O0FBRlIsZUFBTyxHQUFHLHNDQUFvQjs7d0NBQzVCLE9BQU8sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDOzs7O3dDQUNILE9BQU8sQ0FBQyxRQUFRLENBQUMsUUFBUSxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsTUFBTSxDQUFDOzs7QUFBbEUsZ0JBQVE7NENBQ0wsUUFBUTs7Ozs7OztDQUNoQixvQ0FLUyxHQUFHLGtCQUFlLG9CQUFDLElBQUksRUFBRSxLQUFLO01BQUUsTUFBTSx5REFBRyxJQUFJO01BQUUsTUFBTSx5REFBRyxJQUFJO01BQ2hFLE9BQU87Ozs7QUFBUCxlQUFPLEdBQUcsc0NBQW9COzt3Q0FDNUIsT0FBTyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUM7Ozs7d0NBQ2xCLE9BQU8sQ0FBQyxVQUFVLENBQUMsS0FBSyxFQUFFLE1BQU0sRUFBRSxNQUFNLENBQUM7Ozs7Ozs7Q0FDaEQsb0JBRUQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0M1QmlCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOztzQ0FHN0IsNkJBQTZCOztnQ0FDbEIsdUJBQXVCOzs7O21DQUNkLDBCQUEwQjs7Ozs0QkFFaEMsZUFBZTs7QUFFcEMsSUFBSSxHQUFHLEdBQUcsTUFBTTs7QUFFaEIscUJBQU8sT0FBTyx5REFLRixHQUFHLG1CQUFnQixvQkFBQyxNQUFNO01BRTlCLE1BQU0sRUFFTixNQUFNLEVBQ04sY0FBYyxFQUdkLFFBQVEsRUFDUixHQUFHOzs7Ozs7QUFQSCxjQUFNLEdBQUcsb0NBQVk7QUFFckIsY0FBTSxHQUFHLDBDQUFrQixNQUFNLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDMUQsc0JBQWMsR0FBRyxzQ0FBb0I7O3dDQUNuQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUVyQyxnQkFBUSxHQUFHLGtDQUFVLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDcEMsV0FBRyxHQUFHLHFDQUFhLFFBQVEsQ0FBQzs7d0NBRTFCLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLE9BQU8sRUFDUDtjQUNNLEdBQUc7Ozs7Ozs7Z0RBQVMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7QUFFN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDeEIsUUFBUTs7Ozs7MERBQVMsY0FBYyxDQUFDLFFBQVEsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDOzs7QUFBbEQsa0NBQVE7OzBEQUNOLEdBQUcsQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsZ0JBQWdCLEVBQUUsUUFBUSxDQUFDOzs7Ozs7O21CQUN4RSxFQUFDLENBQUM7OztBQUxELG1CQUFHO29EQU9BLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLGlCQUFjLG9CQUFDLE1BQU07TUFDNUIsTUFBTSxFQUNOLFFBQVEsRUFDUixHQUFHLEVBRUgsY0FBYyxFQUlkLE1BQU07Ozs7OztBQVJOLGNBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELGdCQUFRLEdBQUcsa0NBQVUsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUNwQyxXQUFHLEdBQUcscUNBQWEsUUFBUSxDQUFDO0FBRTVCLHNCQUFjLEdBQUcsc0NBQW9COzt3Q0FDbkMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7QUFHckMsY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBQ00sR0FBRzs7Ozs7OztnREFBUyxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3hCLEdBQUcsRUFHRCxRQUFRLEVBRVIsU0FBUzs7OztBQUxYLDZCQUFHLEdBQUcsT0FBTyxDQUFDLFVBQVU7OzswREFHTCxjQUFjLENBQUMsZ0JBQWdCLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUM7OztBQUF6RSxrQ0FBUTs7MERBRVUsR0FBRyxDQUFDLGFBQWEsQ0FBQyxRQUFRLENBQUM7OztBQUE3QyxtQ0FBUzs7MERBR1AsR0FBRyxDQUFDLE1BQU0sQ0FBQztBQUNmLCtCQUFHLEVBQUUsSUFBSSxDQUFDLEdBQUc7MkJBQ2QsRUFBRTtBQUNELGdDQUFJLEVBQUU7QUFDSiwyREFBNkIsRUFBRSxTQUFTLENBQUMsR0FBRyxDQUFDLFVBQVU7QUFDdkQsaUVBQW1DLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0I7QUFDbkUsaUVBQW1DLEVBQUUsU0FBUyxDQUFDLEdBQUcsQ0FBQyxnQkFBZ0I7NkJBQ3BFOzJCQUNGLENBQUM7Ozs7QUFFRixnQ0FBTSxDQUFDLFFBQVEsRUFBRTs7Ozs7Ozs7QUFFakIsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7Ozs7O21CQUVuQjtpQkFDRixFQUNELG9CQUFPLENBQUM7Ozs7OEJBQ0EsQ0FBQzs7Ozs7OztpQkFDUixDQUFDOzs7QUE1QkUsbUJBQUc7b0RBOEJBLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7O3dDQUVFLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGdCQUFnQixFQUNoQjtjQUNNLEdBQUc7Ozs7Ozs7Z0RBQVMsTUFBTSxDQUFDLE9BQU8sQ0FBQztBQUM3QiwwQkFBUSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPO3dCQUN4QixHQUFHLEVBR0QsUUFBUSxFQU1SLFFBQVE7Ozs7QUFUViw2QkFBRyxHQUFHLE9BQU8sQ0FBQyxVQUFVOzs7MERBR0wsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDOzs7QUFBekUsa0NBQVE7OzBEQUVOLEdBQUcsQ0FBQyxrQkFBa0IsQ0FBQyxRQUFRLENBQUM7Ozs7MERBQ2hDLEdBQUcsQ0FBQyxhQUFhLENBQUMsUUFBUSxDQUFDOzs7OzBEQUMzQixHQUFHLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDOzs7OzBEQUVmLGNBQWMsQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7O0FBQWxELGtDQUFROzswREFDTixHQUFHLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLGdCQUFnQixFQUFFLFFBQVEsQ0FBQzs7OztBQUV2RSxnQ0FBTSxDQUFDLFFBQVEsRUFBRTs7Ozs7Ozs7QUFFakIsZ0NBQU0sQ0FBQyxNQUFNLGdCQUFHOzs7Ozs7O21CQUVuQjtpQkFDRixFQUNELG9CQUFPLENBQUM7Ozs7OEJBQ0EsQ0FBQzs7Ozs7OztpQkFDUixDQUFDOzs7QUF0QkUsbUJBQUc7b0RBd0JBLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2lDQ2pJaUIsd0JBQXdCOzs7O3NDQUdwQyw2QkFBNkI7O21DQUNULDBCQUEwQjs7Ozs0QkFJOUMsZUFBZTs7aUNBQ0gsd0JBQXdCOzs7O3VCQUN2QixVQUFVOzs7O3lCQUVaLFlBQVk7Ozs7d0JBQ1QsVUFBVTs7OzttQkFDZixLQUFLOzs7O0FBRXJCLElBQU0sR0FBRyxHQUFHLGtCQUFrQjs7QUFFOUIsSUFBTSxlQUFlLEdBQUcsT0FBTzs7QUFFL0IscUJBQU8sT0FBTyxxQkFNRixHQUFHLG1CQUFnQixvQkFBQyxNQUFNO01BRTlCLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLHVCQUF1QixFQUN2QjtjQUNRLE9BQU8sRUFZUCxRQUFROzs7Ozs7QUFaUix1QkFBTyxHQUFNLE1BQU0sQ0FBQyxPQUFPOzs7Z0RBR3pCLHFCQUFRLEtBQUssQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7O2dEQUc3QixxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7O2dEQU1QLHFCQUFRLFFBQVEsQ0FBSSxPQUFPLFNBQUksTUFBTSxDQUFDLGNBQWMsVUFBTzs7O0FBQTVFLHdCQUFROztnREFDSyx1QkFBTSxNQUFNLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQzs7O0FBQS9DLHdCQUFROztnREFDUyx1QkFBTSxNQUFNLENBQUMsUUFBUSxFQUFFLE9BQU8sQ0FBQzs7O0FBQWhELHdCQUFROztnREFZRixNQUFNLENBQUMsUUFBUSxDQUFDLE9BQU8sQ0FDM0Isb0JBQU0sQ0FBQztzQkFVQyxPQUFPOzs7O0FBVGIsK0JBQU8sQ0FBQyxHQUFHLGlCQUFlLENBQUMsQ0FBQyxTQUFTLENBQUc7Ozs7Ozs7OztBQVNsQywrQkFBTyxHQUFHLHFCQUFRLGdCQUFnQixDQUFJLE9BQU8sU0FBSSxDQUFDLENBQUMsU0FBUyxVQUFPOztBQUN6RSwrQkFBTyxDQUFDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDckMsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsaUJBQUksS0FBSyxDQUFDO0FBQ2QsaUNBQU8sRUFBRSxJQUFJO3lCQUNkLENBQUMsQ0FBQzs7Ozs7OztpQkFDTixDQUNGOzs7c0JBWUcsSUFBSSxxQkFBTyxLQUFLLGlFQUErRCxPQUFPLE9BQUk7Ozs7Ozs7U0FDakcsQ0FDRjs7Ozs7OztDQUNGLEVBQ0Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUNDN0ZpQix3QkFBd0I7Ozs7c0NBR3BDLDZCQUE2Qjs7Z0NBQ2xCLHVCQUF1Qjs7Ozs0QkFDcEIsZUFBZTs7QUFFcEMsSUFBSSxHQUFHLEdBQUcsTUFBTTs7QUFFaEIscUJBQU8sT0FBTyxxQkFLRixHQUFHLFlBQVMsb0JBQUMsTUFBTTtNQUV2QixNQUFNLEVBRU4sTUFBTSxFQUVKLFFBQVE7Ozs7OztBQUpWLGNBQU0sR0FBRyxvQ0FBWTtBQUVyQixjQUFNLEdBQUcsMENBQWtCLE1BQU0sQ0FBQyxPQUFPLEVBQUUsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7d0NBRXZDLE1BQU0sQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLG9CQUFPLENBQUM7Ozs7c0JBQzFDLENBQUM7Ozs7Ozs7U0FDUixDQUFDOzs7QUFGSSxnQkFBUTs7d0NBR1IsTUFBTSxDQUFDLEtBQUssQ0FDaEIsVUFBVSxFQUNWOzs7O29EQUNTLFFBQVE7Ozs7Ozs7U0FDaEIsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsRUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0NoQ2lCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOzttQ0FDVCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O3VCQUNoQixVQUFVOzs7OzhCQUVWLGlCQUFpQjs7OztzQ0FDaEIsNkJBQTZCOzs7O2dDQUM1Qix1QkFBdUI7Ozs7QUFFN0MsSUFBTSxHQUFHLEdBQUcsT0FBTzs7QUFFbkIscUJBQU8sT0FBTyx5REFLRixHQUFHLGlDQUE4QixvQkFBQyxNQUFNO01BRTVDLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLHFCQUFxQixFQUNyQjtjQUdRLGNBQWMsRUFLaEIsR0FBRyxFQTRDSCxHQUFHOzs7Ozs7QUFqREQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBSXpCLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUM1QyxDQUNFO0FBQ0Usd0JBQU0sRUFBRTtBQUNOLHdCQUFJLEVBQUUsQ0FDSjtBQUNFLDJDQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtxQkFDdEMsQ0FrQkY7bUJBQ0Y7aUJBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFLHNCQUFzQjttQkFDNUI7aUJBQ0YsRUFDRDtBQUNFLDBCQUFRLEVBQUU7QUFDUix1QkFBRyxFQUFFLENBQUM7QUFDTiw0QkFBUSxFQUFFLE1BQU07bUJBQ2pCO2lCQUNGLENBQ0YsQ0FDRjs7O0FBekNHLG1CQUFHO0FBNENILG1CQUFHLEdBQUcsd0NBQWEsTUFBTSxDQUFDLFlBQVksRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDOztnREFDcEQsTUFBTSxDQUFDLGVBQWUsQ0FDMUIsR0FBRyxFQUNILG9CQUFNLElBQUk7c0JBR0YsR0FBRzs7Ozt5Q0FGVCxNQUFNO3lDQUFRLElBQUk7O3dEQUFRLGNBQWMsQ0FBQyxvQ0FBb0MsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDOzs7O3VDQUFyRixNQUFNOzs7d0RBRUssR0FBRyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUM7OztBQUFoQywyQkFBRzs0REFDQSxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUUsUUFBUSxFQUFFLEdBQUcsRUFBQzs7Ozs7OEJBRW5DLE1BQU0sQ0FBQyxNQUFNLENBQUMsRUFBQyxXQUFXLEVBQUUsSUFBSSxFQUFDLEVBQUUsOEJBQVUsS0FBSyxnQkFBRyxDQUFDOzs7Ozs7O2lCQUUvRCxDQUNGOzs7Ozs7O1NBQ0YsQ0FDRjs7OzRDQUVNLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsb0NBS1MsR0FBRyx1QkFBb0Isb0JBQUMsTUFBTTtNQUVsQyxNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQiwwQkFBMEIsRUFDMUI7Y0FHUSxjQUFjLEVBS2hCLEdBQUcsRUF5Q0gsR0FBRzs7Ozs7O0FBOUNELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUl6QixjQUFjLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDNUMsQ0FDRTtBQUNFLHdCQUFNLEVBQUU7QUFDTix3QkFBSSxFQUFFLENBQ0o7QUFDRSwyQ0FBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxDQUFDLEVBQUU7cUJBQ3RDOzs7Ozs7Ozs7Ozs7Ozs7cUJBZUY7bUJBQ0Y7aUJBQ0YsRUFDRDs7QUFFRSx3QkFBTSxFQUFFO0FBQ04sdUJBQUcsRUFBRSxzQkFBc0I7bUJBQzVCO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO21CQUNqQjtpQkFDRixDQUNGLENBQ0Y7OztBQXRDRyxtQkFBRztBQXlDSCxtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Z0RBQ3BELE1BQU0sQ0FBQyxlQUFlLENBQzFCLEdBQUcsRUFDSCxvQkFBTSxJQUFJO3NCQUlGLEdBQUc7Ozs7QUFIVCw0QkFBSSxDQUFDLFVBQVUsR0FBRyxDQUFDO0FBQ25CLDRCQUFJLENBQUMsYUFBYSxHQUFHLE1BQU07Ozt3REFFVCxHQUFHLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQzs7O0FBQWhDLDJCQUFHOzREQUNBLEVBQUMsV0FBVyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsR0FBRyxFQUFDOzs7Ozs4QkFFbkMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxFQUFDLFdBQVcsRUFBRSxJQUFJLEVBQUMsRUFBRSw4QkFBVSxLQUFLLGdCQUFHLENBQUM7Ozs7Ozs7aUJBRS9ELENBQ0Y7Ozs7Ozs7U0FDRixDQUNGOzs7NENBRU0sTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQ0FLUyxHQUFHLG1CQUFnQixvQkFBQyxNQUFNO01BRTlCLE1BQU07Ozs7OztBQUFOLGNBQU0sR0FBRyxvQ0FBWTs7d0NBRW5CLE1BQU0sQ0FBQyxLQUFLLENBQ2hCLGFBQWEsRUFDYjtjQUdRLGNBQWMsRUFHaEIsR0FBRyxFQWtFRCxJQUFJLGtGQUdDLENBQUMsRUFPTixHQUFHLEVBRUQsR0FBRzs7Ozs7QUFqRkwsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBRXpCLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxDQUM1QyxDQUNFO0FBQ0Usd0JBQU0sRUFBRTtBQUNOLHdCQUFJLEVBQUUsQ0FDSjtBQUNFLDJDQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLENBQUMsRUFBRTtxQkFDdEM7Ozs7Ozs7Ozs7Ozs7OztxQkFlRjttQkFDRjtpQkFDRixFQUNEOztBQUVFLHdCQUFNLEVBQUU7QUFDTix1QkFBRyxFQUFFO0FBQ0gsOEJBQVEsRUFBRSxzQkFBc0I7QUFDaEMsZ0RBQTBCLEVBQUUseUJBQXlCO0FBQ3JELDhDQUF3QixFQUFFLHlCQUF5QjtxQkFDcEQ7QUFDRCx3QkFBSSxFQUFFO0FBQ0osNEJBQU0sRUFBRSxNQUFNO3FCQUNmO21CQUNGO2lCQUNGLEVBQ0Q7O0FBRUUsd0JBQU0sRUFBRTtBQUNOLHVCQUFHLEVBQUUsZUFBZTtBQUNwQiw4QkFBVSxFQUFFO0FBQ1YsMkJBQUssRUFBRTtBQUNMLDJCQUFHLEVBQUUsT0FBTztBQUNaLGtEQUEwQixFQUFFLGlDQUFpQztBQUM3RCxnREFBd0IsRUFBRSwrQkFBK0I7dUJBQzFEO3FCQUNGO21CQUNGO2lCQUNGLEVBQ0Q7QUFDRSwwQkFBUSxFQUFFO0FBQ1IsdUJBQUcsRUFBRSxDQUFDO0FBQ04sNEJBQVEsRUFBRSxNQUFNO0FBQ2hCLDhCQUFVLEVBQUUsYUFBYTttQkFDMUI7aUJBQ0YsQ0FDRixDQUNGOzs7QUEzREcsbUJBQUc7Ozs7Z0RBaUVNLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7OztnREFDUCxHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdkIsb0JBQUk7Ozs7OzRCQUdNLElBQUksQ0FBQyxVQUFVOzs7Ozs7OztBQUFwQixpQkFBQzs7Z0RBQ1EsY0FBYyxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDOzs7QUFBOUMsaUJBQUMsQ0FBQyxLQUFLOztBQUNQLHVCQUFPLENBQUMsQ0FBQyxHQUFHOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLVixtQkFBRyxHQUFHLHdDQUFhLE1BQU0sQ0FBQyxZQUFZLEVBQUUsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7O2dEQUV4QyxHQUFHLENBQUMsV0FBVyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUM7OztBQUFuQyxtQkFBRzs7QUFDUCxzQkFBTSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7O0FBRXBCLHNCQUFNLENBQUMsTUFBTSxnQkFBRzs7Ozs7OztBQUdwQixtQkFBRyxDQUFDLEtBQUssRUFBRTs7Ozs7OztTQUNaLENBQUM7Ozs0Q0FFRyxNQUFNLENBQUMsT0FBTyxFQUFFOzs7Ozs7O0NBQ3hCLG9DQUtTLEdBQUcsa0JBQWUsb0JBQUMsTUFBTTtNQUU3QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixlQUFlLEVBQ2Y7Y0FJUSxNQUFNLEVBQ04sY0FBYyxFQVNkLE9BQU8sRUFTVCxHQUFHOzs7Ozs7QUFuQkQsc0JBQU0sR0FBRywwQ0FBa0IsTUFBTSxDQUFDLE9BQU8sRUFBRSxNQUFNLENBQUMsT0FBTyxDQUFDO0FBQzFELDhCQUFjLEdBQUcsc0NBQW9COztnREFDckMsY0FBYyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsT0FBTyxDQUFDOzs7OztnREFJakMscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7O0FBSS9CLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU8sZUFBVyxJQUFJLElBQUksRUFBRSxDQUFFLE9BQU8sRUFBRTs7O2dEQUd6RCxxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7Z0RBTWQsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7QUFFN0IsMEJBQVEsRUFBRSxnQkFBTyxJQUFJLEVBQUUsT0FBTzt3QkFDeEIsT0FBTyxFQUlQLEtBQUssRUFDTCxRQUFROzs7O0FBTFIsaUNBQU8sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFDOztBQUN6RCxpQ0FBTyxDQUFDLEdBQUcsR0FBTSxPQUFPLENBQUMsR0FBRyxvQkFBaUI7QUFDN0MsaUNBQU8sQ0FBQyxFQUFFLENBQUMsUUFBUSxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVE7OzswREFFNUIsaUNBQVEsT0FBTyxDQUFDOzs7QUFBOUIsK0JBQUs7QUFDTCxrQ0FBUSxHQUFNLE9BQU8sU0FBSSxJQUFJLENBQUMsS0FBSzs7MERBRWpDLHFCQUFRLFNBQVMsQ0FBQyxRQUFRLEVBQUUsS0FBSyxDQUFDOzs7Ozs7O21CQUN6QyxFQUFDLENBQUM7OztBQVhELG1CQUFHO29EQWFBLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQkFDRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0MxVWlCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOzttQ0FDVCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O0FBRXBDLElBQU0sR0FBRyxHQUFHLFVBQVU7O0FBRXRCLHFCQUFPLE9BQU8scUJBS0YsR0FBRyxlQUFZLG9CQUFDLE1BQU07TUFFMUIsTUFBTTs7Ozs7O0FBQU4sY0FBTSxHQUFHLG9DQUFZOzt3Q0FFbkIsTUFBTSxDQUFDLEtBQUssQ0FDaEIsZUFBZSxFQUNmO2NBSVEsTUFBTSxFQUNOLGNBQWMsRUFrQmhCLEdBQUc7Ozs7OztBQW5CRCxzQkFBTSxHQUFHLCtDQUF1QixNQUFNLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDaEUsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Z0RBaUJ6QixNQUFNLENBQUMsT0FBTyxDQUFDOztBQUU3QiwwQkFBUSxFQUFFLGdCQUFPLElBQUksRUFBRSxPQUFPOzs7O0FBQzVCLGdDQUFNLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQzs7Ozs7OzttQkFDdEIsRUFBQyxDQUFDOzs7QUFKRCxtQkFBRztvREFNQSxHQUFHOzs7Ozs7O1NBQ1gsQ0FBQzs7OzRDQUVHLE1BQU0sQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Q0FDeEIsRUFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztpQ0N4RGlCLHdCQUF3Qjs7OztzQ0FHcEMsNkJBQTZCOzttQ0FDVCwwQkFBMEI7Ozs7NEJBRWhDLGVBQWU7O2lDQUNqQix3QkFBd0I7Ozs7dUJBQ3ZCLFVBQVU7Ozs7eUJBRVosWUFBWTs7Ozt3QkFDVCxVQUFVOzs7O21CQUNmLEtBQUs7Ozs7c0JBQ2tCLFFBQVE7O0FBRS9DLElBQU0sTUFBTSxHQUFHLFFBQVE7QUFDdkIsSUFBTSxHQUFHLEdBQUcsT0FBTzs7QUFFbkIscUJBQU8sT0FBTyx5REFLRixHQUFHLGFBQVUsb0JBQUMsTUFBTTtNQUV4QixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixRQUFRLEVBQ1I7Y0FDUSxjQUFjLEVBRWQsT0FBTyxFQUNQLENBQUMsRUFDRCxDQUFDOzs7Ozs7QUFKRCw4QkFBYyxHQUFHLHNDQUFvQjs7Z0RBQ3JDLGNBQWMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQzs7O0FBQ25DLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU87QUFDM0IsaUJBQUMsR0FBRyxxQkFBUSxnQkFBZ0IsQ0FBSSxPQUFPLFNBQUksTUFBTSxDQUFDLGFBQWEsQ0FBRztBQUNsRSxpQkFBQyxHQUFHLHFCQUFRLGlCQUFpQixDQUFJLE9BQU8sU0FBSSxNQUFNLENBQUMsYUFBYSxDQUFHOztBQUN6RSxpQkFBQyxDQUFDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDL0IsSUFBSSxDQUFDLHVCQUFNLFlBQVksQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUNqQyxJQUFJLENBQUMsaUJBQUksS0FBSyxDQUFDLEVBQUMsT0FBTyxFQUFFLElBQUksRUFBQyxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLGlCQUFJLFNBQVMsQ0FDakIsb0JBQU8sTUFBTSxFQUFFLFFBQVE7c0JBQ2pCLEdBQUc7Ozs7QUFBSCwyQkFBRyxHQUFHLElBQUk7Ozt3REFHVyxjQUFjLENBQUMsYUFBYSxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQzs7O0FBQW5FLDhCQUFNLENBQUMsTUFBTSxDQUFDOzs7Ozs7OztBQUVkLDJCQUFHLGlCQUFJOzs7QUFFVCxnQ0FBUSxDQUFDLEdBQUcsRUFBRSxNQUFNLENBQUM7Ozs7Ozs7aUJBQ3RCLENBQ0YsQ0FBQyxDQUNELElBQUksQ0FBQyxpQkFBSSxTQUFTLENBQUMsRUFBQyxNQUFNLEVBQUUsSUFBSSxFQUFDLENBQUMsQ0FBQyxDQUNuQyxJQUFJLENBQUMsdUJBQU0sWUFBWSxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQ2pDLElBQUksQ0FBQyx1QkFBTSxZQUFZLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FDaEMsSUFBSSxDQUFDLENBQUMsQ0FBQzs7Ozs7OztTQUNYLENBQ0Y7Ozs7Ozs7Q0FDRixvQ0FLUyxHQUFHLGVBQVksb0JBQUMsTUFBTTtNQUUxQixNQUFNOzs7Ozs7QUFBTixjQUFNLEdBQUcsb0NBQVk7O3dDQUVuQixNQUFNLENBQUMsS0FBSyxDQUNoQixRQUFRLEVBQ1I7Y0FJUSxNQUFNLEVBQ04sY0FBYyxFQUlkLE1BQU0sRUFRTixPQUFPLEVBS1AsU0FBUyxFQUlYLEVBQUUsRUFDRixRQUFRLEVBQ1IsSUFBSSxFQUdKLE1BQU0sRUFDTixNQUFNLEVBNkNOLEdBQUc7Ozs7OztBQXpFRCxzQkFBTSxHQUFHLDBDQUFrQixNQUFNLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDMUQsOEJBQWMsR0FBRyxzQ0FBb0I7O2dEQUNyQyxjQUFjLENBQUMsSUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7OztBQUduQyxzQkFBTSxHQUFHLG1DQUFXLE1BQU0sQ0FBQyxVQUFVLENBQUM7OztnREFJcEMscUJBQVEsS0FBSyxDQUFDLE1BQU0sQ0FBQyxPQUFPLENBQUM7Ozs7Ozs7Ozs7O0FBSS9CLHVCQUFPLEdBQU0sTUFBTSxDQUFDLE9BQU87O2dEQUMzQixxQkFBUSxNQUFNLENBQUMsT0FBTyxDQUFDOzs7O2dEQUN2QixxQkFBUSxLQUFLLENBQUMsT0FBTyxDQUFDOzs7QUFHdEIseUJBQVMsR0FBTSxNQUFNLENBQUMsT0FBTzs7Z0RBQzdCLHFCQUFRLE1BQU0sQ0FBQyxTQUFTLENBQUM7Ozs7Z0RBQ3pCLHFCQUFRLEtBQUssQ0FBQyxTQUFTLENBQUM7OztBQUUxQixrQkFBRSxHQUFHLElBQUk7QUFDVCx3QkFBUSxHQUFHLElBQUk7QUFDZixvQkFBSSxHQUFHLElBQUk7QUFHWCxzQkFBTSxHQUFHLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLGdCQUFnQixFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLE1BQU0sRUFBRSxZQUFZLEVBQUUsWUFBWSxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsWUFBWSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsU0FBUyxFQUFFLEtBQUssRUFBRSxTQUFTLEVBQUUsS0FBSyxFQUFFLFNBQVMsRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE1BQU0sRUFBRSxRQUFRLEVBQUUsU0FBUyxFQUFFLE1BQU0sRUFBRSxNQUFNLEVBQUUsVUFBVSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLFdBQVcsRUFBRSxRQUFRLEVBQUUsS0FBSyxFQUFFLGNBQWMsRUFBRSxTQUFTLEVBQUUsU0FBUyxFQUFFLFlBQVksRUFBRSxjQUFjLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsVUFBVSxFQUFFLG1CQUFtQixFQUFFLGdCQUFnQixFQUFFLFVBQVUsRUFBRSxtQkFBbUIsRUFBRSxnQkFBZ0IsRUFBRSxVQUFVLEVBQUUsbUJBQW1CLEVBQUUsZ0JBQWdCLEVBQUUsV0FBVyxFQUFFLG9CQUFvQixFQUFFLGlCQUFpQixFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsU0FBUyxFQUFFLE9BQU8sRUFBRSxnQkFBZ0IsQ0FBQztBQUM5cEMsc0JBQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQUM7K0JBQVEsQ0FBQztpQkFBRyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUk7OztBQUd2RCxzQkFBTSxDQUFDLGFBQWEsR0FBRyxvQkFBTyxXQUFXOzs7O0FBQ3ZDLDRCQUFJLEdBQUcsTUFBTSxHQUFHLENBQUMsT0FBTyxHQUFHLFdBQVcsRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDakQsMEJBQUUsR0FBTSxPQUFPLFNBQUksSUFBTTtBQUN6QixnQ0FBUSxHQUFNLEVBQUUsU0FBSSxNQUFNLENBQUMsV0FBYTs7d0RBQ2xDLHFCQUFRLEtBQUssQ0FBQyxFQUFFLENBQUM7Ozs7d0RBRWpCLHFCQUFRLFVBQVUsQ0FBQyxRQUFRLEVBQUUsdUJBQU0sTUFBTSxDQUFDLE1BQU0sRUFBRSxXQUFXLENBQUMsQ0FBQzs7Ozs7OztpQkFDdEU7OztBQUdELHNCQUFNLENBQUMsUUFBUSxHQUFHLG9CQUFPLEdBQUc7c0JBQ3RCLEtBQUssRUFDTCxJQUFJLEVBRUosTUFBTSxrRkFHRCxHQUFHLEVBQ04sTUFBTSxFQUNOLE1BQU07Ozs7O0FBUlIsNkJBQUssR0FBRyxHQUFHLENBQUMsS0FBSztBQUNqQiw0QkFBSSxHQUFHLEdBQUcsQ0FBQyxJQUFJO0FBRWYsOEJBQU0sR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFdBQUMsRUFBSTtBQUFFLGlDQUFPLEtBQUssQ0FBQyxDQUFDLENBQUMsU0FBTyxLQUFLLENBQUMsQ0FBQyxDQUFDLFNBQU0sSUFBSTt5QkFBRSxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxHQUFHLElBQUk7O3dEQUNyRixxQkFBUSxVQUFVLENBQUMsUUFBUSxFQUFFLHVCQUFNLE1BQU0sQ0FBQyxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7Ozs7Ozs7b0NBRXJELElBQUksQ0FBQyxNQUFNOzs7Ozs7OztBQUFsQiwyQkFBRztBQUNOLDhCQUFNLEdBQU0sTUFBTSxDQUFDLFFBQVEsU0FBSSxHQUFHO0FBQ2xDLDhCQUFNLEdBQU0sRUFBRSxTQUFJLEdBQUc7Ozt3REFHakIscUJBQVEsTUFBTSxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7Ozt3REFFdEIscUJBQVEsUUFBUSxDQUFDLE1BQU0sRUFBRSxNQUFNLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7aUJBRzNDOzs7QUFHRCxzQkFBTSxDQUFDLFdBQVcsR0FBRyxvQkFBTyxXQUFXO3NCQUMvQixHQUFHLEVBQ0gsT0FBTyxFQUNQLE1BQU07Ozs7QUFGTiwyQkFBRyxHQUFHLDJCQUFTLEtBQUssQ0FBQztBQUNyQiwrQkFBTyxHQUFNLFNBQVMsU0FBSSxJQUFJO0FBQzlCLDhCQUFNLEdBQUcscUJBQVEsaUJBQWlCLENBQUMsT0FBTyxDQUFDOztBQUNqRCwyQkFBRyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDaEIsMkJBQUcsQ0FBQyxTQUFTLENBQUMsRUFBRSxFQUFFLEtBQUssQ0FBQztBQUN4QiwyQkFBRyxDQUFDLFFBQVEsRUFBRTs7Ozs7OztpQkFDZjs7Ozs7O2dEQUtlLE1BQU0sQ0FBQyxPQUFPLENBQUM7O0FBRTdCLDBCQUFRLEVBQUUsZ0JBQU8sSUFBSSxFQUFFLE9BQU87d0JBQ3hCLFFBQVEsRUFHTixLQUFLOzs7OzswREFIVSxjQUFjLENBQUMsUUFBUSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUFsRCxrQ0FBUTs7Z0NBRVIsUUFBUSxJQUFJLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFdBQVc7Ozs7OzswREFDdkIsY0FBYyxDQUFDLGdCQUFnQixDQUFDLE1BQU0sV0FBUSxFQUFFLElBQUksQ0FBQzs7O0FBQW5FLCtCQUFLOzswREFDSCxNQUFNLENBQUMsTUFBTSxDQUFDLEVBQUMsS0FBSyxFQUFFLEtBQUssRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFDLENBQUM7Ozs7Ozs7bUJBRWxELEVBQUMsQ0FBQzs7O0FBVEQsbUJBQUc7O0FBV1Asc0JBQU0sQ0FBQyxLQUFLLEVBQUU7O29EQUVQLEdBQUc7Ozs7Ozs7U0FDWCxDQUFDOzs7NENBRUcsTUFBTSxDQUFDLE9BQU8sRUFBRTs7Ozs7OztDQUN4QixvQkFFRDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztRQ25LSyx3QkFBd0I7O1FBQ3hCLHNCQUFzQixFOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzJCQ0N0QixjQUFjOzt5QkFDSCxlQUFlOzs7OzRCQUcxQixlQUFlOzs7O29CQUdMLE1BQU07Ozs7MkJBQ0gsYUFBYTs7OztzQkFDUCxVQUFVOztBQUVwQyxJQUFNLE9BQU8sR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxTQUFTLEVBQUU7QUFDOUMsY0FBWSxFQUFFLE9BQU87Q0FDdEIsQ0FBQyxDQUFDOztJQUVVLE1BQU07WUFBTixNQUFNOztBQUVOLFdBRkEsTUFBTSxDQUVMLFFBQVEsRUFBRTs7OzBCQUZYLE1BQU07O0FBSWYsUUFBSSxPQUFPLEdBQUcsT0FBTyxDQUFDLE9BQU8sQ0FBQztBQUM1QixTQUFHLEVBQUUsUUFBUTtLQUNkLENBQUMsQ0FBQzs7QUFFSCwrQkFSUyxNQUFNLDZDQVFULE9BQU8sRUFBRTs7QUFFZixRQUFJLElBQUksR0FBRyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUM7O0FBRTFCLFlBQVEsSUFBSSxDQUFDLElBQUk7O0FBRWYsV0FBSyxPQUFPO0FBQ1YsWUFBSSxDQUFDLEtBQUssR0FBRywyQkFBVSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEMsWUFBSSxVQUFPLEdBQUc7Y0FBUSxRQUFRLHlEQUFHLFVBQUMsTUFBTSxFQUFHLEVBQUU7Y0FBRSxPQUFPLHlEQUFHLFVBQUMsQ0FBQyxFQUFHLEVBQUU7Y0FDMUQsR0FBRzs7OztBQUFILG1CQUFHLHNCQUFvQixJQUFJLENBQUMsS0FBSzs7Z0RBQ3hCLElBQUksQ0FBQyxLQUFLLENBQUMsY0FBYyxDQUFDLEdBQUcsRUFBRSxRQUFRLEVBQUUsT0FBTyxDQUFDOzs7Ozs7Ozs7O1NBQy9ELENBQUM7QUFDRixjQUFNOztBQUVSO0FBQ0UsY0FBTSxJQUFJLEtBQUssQ0FBQyx1QkFBdUIsQ0FBQyxDQUFDOztBQUFBLEtBRTVDO0dBQ0Y7Ozs7Ozs7ZUExQlUsTUFBTTs7V0FnQ0o7OztVQUFDLFNBQVMseURBQUcsRUFBRTtVQUFFLE9BQU8seURBQUcsb0JBQU8sQ0FBQzs7Ozs7Ozs7T0FBTzs7VUFFakQsT0FBTyxFQVFQLEtBQUssa0ZBQ0EsTUFBTTs7Ozs7OztBQVRYLG1CQUFPLEdBQUcsSUFBSSxDQUFDLFVBQVUsRUFBRTs7O0FBRy9CLG1CQUFPLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQztBQUNuQixrQkFBSSxFQUFFLE1BQU07QUFDWixtQkFBSyxFQUFFLEVBQUU7YUFDVixDQUFDOztBQUVFLGlCQUFLLEdBQUcsRUFBRTs7Ozs7O0FBQ2QsNkJBQW1CLE9BQU8sQ0FBQyxPQUFPLHVIQUFFO0FBQTNCLG9CQUFNOztBQUNiLG1CQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHO0FBQ25CLHFCQUFLLEVBQUUsTUFBTSxDQUFDLEtBQUs7QUFDbkIscUJBQUssRUFBRSxDQUFDO2VBQ1QsQ0FBQzthQUNIOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUVLLElBQUksVUFBTyxDQUNmLG9CQUFPLE1BQU07dUdBQ0YsTUFBTSxFQUNULEtBQUssRUFDTCxJQUFJOzs7Ozs7Ozs7aUNBRlMsT0FBTyxDQUFDLE9BQU87Ozs7Ozs7O0FBQXpCLDBCQUFNO0FBQ1QseUJBQUssR0FBRyx5QkFBUSxRQUFRLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQztBQUN0Qyx3QkFBSSxHQUFHLHVCQUFNLEtBQUssQ0FBRTs7eUJBQ3BCLElBQUksQ0FBQyxNQUFNLENBQUM7Ozs7O0FBQ2QseUJBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUMsS0FBSyxFQUFFLENBQUM7OzBCQUN2QixPQUFPLFNBQVMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssV0FBVzs7Ozs7O29EQUN6QyxTQUFTLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzthQUszQyxFQUNELE9BQU8sQ0FDUjs7O2dEQUdNLEtBQUs7Ozs7Ozs7S0FFYjs7O1NBdEVVLE1BQU07Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzsyQkNmWixjQUFjOzt5QkFDSCxlQUFlOzs7OzRCQUcxQixlQUFlOztBQUV0QixJQUFNLE1BQU0sR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxRQUFRLEVBQUU7QUFDNUMsY0FBWSxFQUFFLE9BQU87Q0FDdEIsQ0FBQyxDQUFDOztJQUVVLFNBQVM7QUFJVCxXQUpBLFNBQVMsQ0FJUixPQUFPLEVBQUU7MEJBSlYsU0FBUzs7QUFLbEIsUUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPLENBQUM7R0FDeEI7Ozs7Ozs7O2VBTlUsU0FBUzs7V0FhYixtQkFBRztBQUNSLGFBQU8sSUFBSSxDQUFDLE9BQU8sQ0FBQyxZQUFZLENBQUM7S0FDbEM7OztXQUVTLHNCQUFHO0FBQ1gsYUFBTyxJQUFJLENBQUMsT0FBTyxDQUFDO0tBQ3JCOzs7V0FFTSxtQkFBNkQ7OztVQUE1RCxRQUFRLHlEQUFHLG9CQUFPLE1BQU07Ozs7Ozs7O09BQU87VUFBRSxPQUFPLHlEQUFHLG9CQUFPLENBQUM7Ozs7Ozs7O09BQU87S0FBSTs7O1NBckIzRCxTQUFTOzs7OztJQXlCVCxLQUFLO1lBQUwsS0FBSzs7QUFFTCxXQUZBLEtBQUssQ0FFSixPQUFPLEVBQUU7OzswQkFGVixLQUFLOztBQUlkLFFBQUksT0FBTyxHQUFHLE1BQU0sQ0FBQyxPQUFPLENBQUM7QUFDM0IsU0FBRyxFQUFFLE9BQU87S0FDYixDQUFDLENBQUM7O0FBRUgsK0JBUlMsS0FBSyw2Q0FRUixPQUFPLEVBQUU7O0FBRWYsUUFBSSxJQUFJLEdBQUcsSUFBSSxDQUFDLE9BQU8sRUFBRSxDQUFDOztBQUUxQixZQUFRLElBQUksQ0FBQyxJQUFJO0FBQ2YsV0FBSyxPQUFPO0FBQ1YsWUFBSSxDQUFDLEtBQUssR0FBRywyQkFBVSxJQUFJLENBQUMsSUFBSSxDQUFDLENBQUM7QUFDbEMsWUFBSSxVQUFPLEdBQUcsb0JBQU8sR0FBRztjQUNsQixHQUFHOzs7O0FBQUgsbUJBQUcsc0JBQW9CLElBQUksQ0FBQyxLQUFLLGdCQUFZLEdBQUcsQ0FBQyxHQUFHLGFBQVMsR0FBRyxDQUFDLEVBQUU7O2dEQUMxRCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7Ozs7U0FDbkMsQ0FBQztBQUNGLGNBQU07QUFDUjtBQUNFLGNBQU0sSUFBSSxLQUFLLENBQUMsb0JBQW9CLENBQUMsQ0FBQztBQUFBLEtBQ3pDO0dBRUY7Ozs7Ozs7ZUF4QlUsS0FBSzs7V0ErQlQsbUJBQTZEOzs7VUFBNUQsUUFBUSx5REFBRyxvQkFBTyxNQUFNOzs7Ozs7OztPQUFPO1VBQUUsT0FBTyx5REFBRyxvQkFBTyxDQUFDOzs7Ozs7OztPQUFPOztBQUVoRSxVQUFJLEdBQUcsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDO0FBQ3BCLGVBQU8sRUFBRSxJQUFJLENBQUMsT0FBTyxDQUFDLEdBQUc7T0FDMUIsRUFBRTtBQUNELGNBQU0sRUFBRTtBQUNOLGFBQUcsRUFBRSxDQUFDO0FBQ04sWUFBRSxFQUFFLENBQUM7QUFDTCxhQUFHLEVBQUUsQ0FBQztTQUNQO09BQ0YsQ0FBQyxDQUFDOztBQUVILGFBQU8sSUFBSSxPQUFPLENBQ2hCLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSzs7QUFFbkIsV0FBRyxDQUFDLE9BQU8sQ0FDVCxvQkFBTyxHQUFHLEVBQUUsS0FBSztjQUVULE1BQU07Ozs7OztnREFBUyxJQUFJLFVBQU8sQ0FBQyxHQUFHLENBQUM7OztBQUEvQixzQkFBTTs7Z0RBQ0osUUFBUSxDQUFDLE1BQU0sQ0FBQzs7Ozs7Ozs7OztBQUV0Qix1QkFBTyxnQkFBRyxDQUFDOzs7QUFFYixvQkFBSSxLQUFLLEdBQUcsQ0FBQyxLQUFLLEdBQUcsQ0FBQyxLQUFLLEVBQUUsRUFBRTtBQUM3Qix5QkFBTyxFQUFFLENBQUM7aUJBQ1g7Ozs7Ozs7U0FDRixDQUFDLENBQUM7T0FFTixDQUNGLFNBQU0sQ0FDTCxVQUFDLENBQUMsRUFBSztBQUNMLGNBQU0sQ0FBQyxDQUFDO09BQ1QsQ0FDRixDQUFDO0tBRUg7OztTQWxFVSxLQUFLO0dBQVMsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Z0NDckNsQiwwQkFBMEI7Ozs7SUFFL0IsUUFBUTs7Ozs7O0FBS1AsV0FMRCxRQUFRLENBS04sS0FBSyxFQUFFOzBCQUxULFFBQVE7O0FBTWpCLFFBQUksQ0FBQyxNQUFNLEdBQUcsS0FBSztHQUNwQjs7ZUFQVSxRQUFROztXQVNELHFCQUFDLGNBQWM7VUFBRSxRQUFRLHlEQUFHLENBQUM7Ozs7OzRDQUN2QyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDM0IsbUJBQW1CLDBCQUNHLGNBQWMsRUFDcEMsRUFBRSxFQUFFO0FBQ0YsbUJBQUssRUFBRSxRQUFRO0FBQ2YsNkJBQWUsRUFBRSxDQUFDO0FBQ2xCLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7OzRDQUVLLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUMzQixtQkFBbUIsMEJBQ0csY0FBYyxFQUNwQyxFQUFFLEVBQUU7QUFDRixtQkFBSyxFQUFFLFFBQVE7QUFDZix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs7OztLQUNGOzs7V0FFc0IsMEJBQUMsSUFBSTtVQUN0QixTQUFTLEVBRVQsR0FBRyxFQUdILE1BQU0sRUFTTixLQUFLLGtGQXNCQSxNQUFNOzs7Ozs7O0FBcENYLHFCQUFTLEdBQUcsSUFBSSxDQUFDLFVBQVU7QUFFM0IsZUFBRyxHQUFHLEVBQUU7O0FBR1Isa0JBQU0sR0FBRyxTQUFULE1BQU0sQ0FBVSxHQUFHO2tCQUNqQixHQUFHOzs7O0FBQUgsdUJBQUcsdUVBRWMsSUFBSSxDQUFDLFVBQVUsbUJBQWMsR0FBRztxQ0FFckQsR0FBRzs7b0RBQVksSUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7O21DQUFqQyxJQUFJOzs7Ozs7O2FBQ1Q7O0FBR0csaUJBQUssR0FBRyxTQUFSLEtBQUssQ0FBVSxHQUFHO2tCQUVoQixHQUFHLEVBSUgsUUFBUTs7OztBQUpSLHVCQUFHLGdGQUVjLElBQUksQ0FBQyxVQUFVLG1CQUFjLEdBQUc7O29EQUVoQyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUM7OztBQUF2Qyw0QkFBUTs7eUJBQ1IsUUFBUSxDQUFDLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQzs7Ozs7Ozs7cUNBRTNCLEdBQUc7O29EQUNLLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUMzQixpQkFBaUIsRUFDakIsRUFBRSxFQUNGO0FBQ0UsZ0NBQVUsRUFBRSxJQUFJLENBQUMsVUFBVTtBQUMzQix5QkFBRyxFQUFFLEdBQUc7QUFDUixnQ0FBVSxFQUFFLFNBQVM7QUFDckIsaUNBQVcsRUFBRSxPQUFPO3FCQUNyQixDQUNGOzs7O21DQVZDLElBQUk7Ozs7Ozs7YUFXVDs7Ozs7O3dCQUVrQixJQUFJLENBQUMsSUFBSTs7Ozs7Ozs7QUFBbkIsa0JBQU07NkJBQ0wsTUFBTSxDQUFDLEdBQUc7a0RBQ1gsSUFBSSwyQkFHSixLQUFLOzs7Ozs0Q0FGRixLQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs0Q0FHakIsTUFBTSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnREFLdkI7QUFDTCxpQkFBRyxFQUFFLEdBQUc7YUFDVDs7Ozs7OztLQUNGOzs7V0FFd0IsNEJBQUMsSUFBSTtVQUN4QixTQUFTLEVBQ1QsTUFBTSxFQUNOLFNBQVMsRUFFVCxHQUFHLEVBR0gsR0FBRyxFQUdFLENBQUM7Ozs7QUFWTixxQkFBUyxHQUFHLElBQUksQ0FBQyxVQUFVO0FBQzNCLGtCQUFNLEdBQUcsSUFBSSxDQUFDLE1BQU07QUFDcEIscUJBQVMsR0FBRyxJQUFJLENBQUMsVUFBVTtBQUUzQixlQUFHLEdBQUcsRUFBRTtBQUdSLGVBQUcseURBQXVELFNBQVM7NkJBQ3ZFLEdBQUc7OzRDQUFZLElBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7OzsyQkFBakMsSUFBSTtBQUVDLGFBQUMsR0FBRyxDQUFDOzs7a0JBQUUsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNOzs7Ozs7NENBQ3pCLElBQUksQ0FBQyxNQUFNLENBQUMsV0FBVyxDQUMzQixtQkFBbUIsRUFBRTtBQUNuQix3QkFBVSxFQUFFLFNBQVM7QUFDckIsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHVCQUFTLEVBQUUsTUFBTSxDQUFDLENBQUMsQ0FBQztBQUNwQixrQkFBSSxFQUFFLENBQUMsR0FBRyxDQUFDO2FBQ1osRUFBRTtBQUNELHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFWZ0MsYUFBQyxFQUFFOzs7OztnREFhL0I7QUFDTCxpQkFBRyxFQUFFLEdBQUc7YUFDVDs7Ozs7OztLQUNGOzs7V0FFbUIsdUJBQUMsSUFBSTtVQUNuQixVQUFVLEVBQ1YsSUFBSSx1RkFvQ0MsQ0FBQyx1RkFJTixHQUFHOzs7OztBQXpDSCxzQkFBVSxHQUFHLEVBQUU7QUFDZixnQkFBSSxHQUFHLEVBQUU7Ozs7QUFJYixnQkFBSSxHQUFHLENBQ0wsUUFBUSxFQUNSLE1BQU0sRUFDTixNQUFNLEVBQ04sa0JBQWtCLEVBQ2xCLG9CQUFvQixFQUNwQixhQUFhLEVBQ2IsV0FBVyxDQUNaOzs7OztBQUNELDhCQUFjLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFSyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDM0IsYUFBYSxvQkFDRyxJQUFJLENBQUMsVUFBVSxFQUMvQixVQUFVLEVBQUU7QUFDVix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7Ozs7O0FBSUQsc0JBQVUsR0FBRyxFQUFFO0FBQ2YsZ0JBQUksR0FBRyxDQUNMLGtCQUFrQixFQUNsQixjQUFjLEVBQ2QsWUFBWSxFQUNaLFNBQVMsRUFDVCxTQUFTLEVBQ1QsY0FBYyxDQUNmOzs7OztBQUNELDhCQUFjLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFZSxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDckMsbUJBQW1CLG9CQUNILElBQUksQ0FBQyxVQUFVLEVBQy9CLFVBQVUsRUFBRTtBQUNWLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFORyxlQUFHO2dEQVFBO0FBQ0wsaUJBQUcsRUFBRSxHQUFHO2FBQ1Q7Ozs7Ozs7S0FDRjs7O1dBRW1CLHVCQUFDLElBQUk7VUFDbkIsU0FBUyxFQUVULEdBQUcsRUFFSCxVQUFVLEVBQ1YsSUFBSSx1RkErREMsQ0FBQzs7Ozs7QUFwRU4scUJBQVMsR0FBRyxJQUFJLENBQUMsVUFBVTtBQUUzQixlQUFHLEdBQUcsRUFBRTtBQUVSLHNCQUFVLEdBQUcsRUFBRTtBQUNmLGdCQUFJLEdBQUcsRUFBRTs7QUFFYixnQkFBSSxHQUFHLENBQ0wsTUFBTSxFQUNOLG9CQUFvQixDQUNyQjs7Ozs7Ozs7OztBQU1ELDhCQUFjLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFc0IsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQzVDLGFBQWEsRUFDYixVQUFVLEVBQUU7QUFDVix3QkFBVSxFQUFFLFNBQVM7QUFDckIsb0JBQU0sRUFBRSxDQUFDO0FBQ1Qsa0JBQUksRUFBRSxNQUFNO0FBQ1osOEJBQWdCLEVBQUUsTUFBTTtBQUN4Qix5QkFBVyxFQUFFLE1BQU07QUFDbkIsdUJBQVMsRUFBRSxNQUFNO0FBQ2pCLHlCQUFXLEVBQUUsT0FBTztBQUNwQix5QkFBVyxFQUFFLE9BQU87YUFDckIsQ0FDRjs7O0FBWkQsZUFBRyxDQUFDLFVBQVU7O0FBY2Qsc0JBQVUsR0FBRyxFQUFFO0FBQ2YsZ0JBQUksR0FBRyxDQUNMLGNBQWMsRUFDZCxpQkFBaUIsRUFDakIsU0FBUyxFQUNULFNBQVMsRUFDVCxjQUFjLENBQ2Y7Ozs7Ozs7Ozs7O0FBT0QsOEJBQWMsSUFBSSwySEFBRTtBQUFYLGVBQUM7O0FBQ1Isa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxFQUFFLFVBQVUsQ0FBQyxDQUFDLENBQUMsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDO2FBQ3JDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUU0QixJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FDbEQsbUJBQW1CLEVBQ25CLFVBQVUsRUFBRTtBQUNWLHdCQUFVLEVBQUUsU0FBUztBQUNyQix3QkFBVSxFQUFFLEdBQUcsQ0FBQyxVQUFVO0FBQzFCLG1CQUFLLEVBQUUsQ0FBQztBQUNSLDZCQUFlLEVBQUUsQ0FBQztBQUNsQixnQ0FBa0IsRUFBRSxNQUFNO0FBQzFCLGdDQUFrQixFQUFFLE1BQU07QUFDMUIsOEJBQWdCLEVBQUUsTUFBTTtBQUN4Qix3QkFBVSxFQUFFLE1BQU07QUFDbEIseUJBQVcsRUFBRSxPQUFPO0FBQ3BCLHlCQUFXLEVBQUUsT0FBTzthQUNyQixDQUNGOzs7QUFkRCxlQUFHLENBQUMsZ0JBQWdCOzs7Ozs7QUFnQnBCLDhCQUFjLElBQUksMkhBQUU7QUFBWCxlQUFDOztBQUNSLGtCQUFJLElBQUksQ0FBQyxDQUFDLENBQUMsRUFBRSxVQUFVLENBQUMsQ0FBQyxDQUFDLEdBQUcsSUFBSSxDQUFDLENBQUMsQ0FBQzthQUNyQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs0Q0FFNEIsSUFBSSxDQUFDLE1BQU0sQ0FBQyxXQUFXLENBQ2xELG1CQUFtQixFQUFFLEVBQUUsRUFBRTtBQUN2Qiw4QkFBZ0IsRUFBRSxHQUFHLENBQUMsZ0JBQWdCO0FBQ3RDLHdCQUFVLEVBQUUsU0FBUztBQUNyQixtQkFBSyxFQUFFLENBQUM7QUFDUix5QkFBVyxFQUFFLE9BQU87QUFDcEIseUJBQVcsRUFBRSxPQUFPO2FBQ3JCLENBQ0Y7OztBQVJELGVBQUcsQ0FBQyxnQkFBZ0I7Z0RBV2I7QUFDTCxpQkFBRyxFQUFFLEdBQUc7YUFDVDs7Ozs7OztLQUNGOzs7U0E5UFUsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkNGSCxlQUFlOzs7O3VCQUNQLFNBQVM7OzhCQUNmLGlCQUFpQjs7Ozs7O29CQUdwQixNQUFNOzs7OzJCQUNILGFBQWE7Ozs7cUJBQ1YsUUFBUTs7SUFFbEIsZUFBZSxHQUNkLFNBREQsZUFBZSxDQUNiLElBQUksRUFBRSxPQUFPLEVBQUU7d0JBRGpCLGVBQWU7O0FBRXhCLE1BQUksUUFBUTtBQUNaLFVBQVEsSUFBSSxDQUFDLElBQUk7QUFDZixTQUFLLE9BQU87QUFDVixjQUFRLEdBQUcsSUFBSSxhQUFhLENBQUMsSUFBSSxFQUFFLE9BQU8sQ0FBQztBQUFBLEdBQzlDOztBQUVELFNBQU8sUUFBUTtDQUNoQjs7OztJQUdVLFFBQVE7QUFDUCxXQURELFFBQVEsQ0FDTixJQUFJLEVBQUUsT0FBTyxFQUFFOzBCQURqQixRQUFROztBQUVqQixRQUFJLENBQUMsSUFBSSxHQUFHLElBQUk7QUFDaEIsUUFBSSxDQUFDLE9BQU8sR0FBRyxPQUFPO0dBQ3ZCOztlQUpVLFFBQVE7O1dBZVYsb0JBQUc7QUFDVixhQUFPLElBQUksQ0FBQyxJQUFJO0tBQ2pCOzs7V0FFUSxvQkFBRztBQUNWLGFBQU8sSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJO0tBQ3RCOzs7V0FFVyx1QkFBRztBQUNiLGFBQU8sSUFBSSxDQUFDLE9BQU87S0FDcEI7OztXQUVrQiw4QkFFakI7OztVQURBLEVBQUUseURBQUc7WUFBTyxRQUFRLHlEQUFHLGdCQUFNLEVBQUksRUFBRTtZQUFFLE9BQU8seURBQUcsV0FBQyxFQUFJLEVBQUU7Ozs7Ozs7O09BQU87O0FBRTdELFVBQUksVUFBTyxHQUFHLEVBQUU7S0FDakI7Ozs7Ozs7Ozs7Ozs7V0FXYTtVQUFDLFNBQVMseURBQUcsRUFBRTs7VUFDdkIsT0FBTyxFQVFQLE9BQU8sa0ZBTUYsQ0FBQyxFQUZOLE9BQU87Ozs7Ozs7QUFaUCxtQkFBTyxHQUFHLElBQUksQ0FBQyxXQUFXLEVBQUU7OztBQUdoQyxtQkFBTyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUM7QUFDbkIsa0JBQUksRUFBRSxNQUFNO0FBQ1osbUJBQUssRUFBRSxFQUFFO2FBQ1YsQ0FBQzs7QUFFRSxtQkFBTyxHQUFHLEVBQUU7Ozs7OztBQUNoQiw2QkFBYyxPQUFPLENBQUMsT0FBTyx1SEFBRTtBQUF0QixlQUFDO2FBQ1Q7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVHLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBRWhCLDhCQUFjLE9BQU8sQ0FBQyxPQUFPLDJIQUFFO0FBQXRCLGVBQUM7O0FBQ1IscUJBQU8sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLEdBQUc7QUFDaEIscUJBQUssRUFBRSxDQUFDLENBQUMsS0FBSztBQUNkLHFCQUFLLEVBQUUsT0FBTyxDQUFDLENBQUMsS0FBSyxLQUFLLFdBQVcsR0FBRyxDQUFDLENBQUMsS0FBSyxHQUFHLENBQUM7QUFDbkQscUJBQUssRUFBRSxDQUFDO2VBQ1Q7QUFDRCxxQkFBTyxDQUFDLElBQUksQ0FDVjtBQUNFLG9CQUFJLEVBQUUsQ0FBQyxDQUFDLElBQUk7QUFDWixvQkFBSSxFQUFFLHVCQUFLLHlCQUFRLFFBQVEsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUM7ZUFDdEMsQ0FDRjthQUNGOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OzRDQUVLLElBQUksVUFBTyxDQUNmLG9CQUFPLE1BQU0sRUFBRSxPQUFPO3VHQUNYLENBQUMsRUFFSixDQUFDOzs7Ozs7Ozs7aUNBRk8sT0FBTzs7Ozs7Ozs7QUFBWixxQkFBQztBQUVKLHFCQUFDLEdBQUcsT0FBTyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7O3lCQUNuQixDQUFDLENBQUMsS0FBSzs7Ozs7MEJBQ0wsQ0FBQyxDQUFDLEtBQUssSUFBSSxDQUFDLENBQUMsS0FBSzs7Ozs7Ozs7eUJBS3BCLENBQUMsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDOzs7Ozs7QUFFaEIscUJBQUMsQ0FBQyxLQUFLLEVBQUU7Ozs7MEJBR0wsT0FBTyxTQUFTLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxLQUFLLFdBQVc7Ozs7OztvREFDcEMsU0FBUyxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O2FBSy9DLENBQUM7OztnREFHRyxPQUFPOzs7Ozs7O0tBQ2Y7OztXQTNGYyxpQkFBQyxJQUFJLEVBQUUsT0FBTyxFQUFFO0FBQzdCLGNBQVEsSUFBSSxDQUFDLElBQUk7QUFDZixhQUFLLE9BQU87QUFDVixpQkFBTyxJQUFJLGFBQWEsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDO0FBQ3pDO0FBQ0UsZ0JBQU0sSUFBSSxLQUFLLENBQUMsbUJBQW1CLENBQUM7QUFBQSxPQUN2QztLQUNGOzs7U0FiVSxRQUFROzs7OztJQW9HUixhQUFhO1lBQWIsYUFBYTs7QUFDWixXQURELGFBQWEsQ0FDWCxJQUFJLEVBQUUsT0FBTyxFQUFFOzs7MEJBRGpCLGFBQWE7O0FBRXRCLCtCQUZTLGFBQWEsNkNBRWhCLElBQUksRUFBRSxPQUFPLEVBQUM7O0FBRXBCLFFBQUksSUFBSSxHQUFHLElBQUksQ0FBQyxRQUFRLEVBQUU7O0FBRTFCLFFBQUksQ0FBQyxLQUFLLEdBQUcsMkJBQVUsSUFBSSxDQUFDO0FBQzVCLFFBQUksQ0FBQyxrQkFBa0IsQ0FBQyxvQkFBTyxRQUFRLEVBQUUsT0FBTztVQUMxQyxHQUFHLEVBQ0gsR0FBRzs7OztBQURILGVBQUcsc0JBQW9CLElBQUksQ0FBQyxLQUFLOzs0Q0FDckIsSUFBSSxDQUFDLEtBQUssQ0FBQyxjQUFjLENBQUMsR0FBRyxFQUFFLFFBQVEsRUFBRSxVQUFDLENBQUMsRUFBSztBQUFFLG9CQUFNLENBQUM7YUFBRSxDQUFDOzs7QUFBeEUsZUFBRztnREFDQSxHQUFHOzs7Ozs7O0tBQ1gsQ0FBQztHQUNIOzs7Ozs7U0FaVSxhQUFhO0dBQVMsUUFBUTs7OztJQW1COUIsYUFBYTtZQUFiLGFBQWE7O0FBQ1osV0FERCxhQUFhLENBQ1gsSUFBSSxFQUFFLE9BQU8sRUFBRTs7OzBCQURqQixhQUFhOztBQUV0QiwrQkFGUyxhQUFhLDZDQUVoQixJQUFJLEVBQUUsT0FBTyxFQUFDOzs7QUFHcEIsUUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFPLFFBQVEsRUFBRSxPQUFPO1VBQzFDLE1BQU0sRUFJTixFQUFFLEVBQ0YsVUFBVSxFQUVWLE9BQU8sRUFNUCxHQUFHLEVBUUMsR0FBRzs7OztBQXJCUCxrQkFBTTs7NENBQ0sscUJBQVksT0FBTyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7OztBQUE1QyxrQkFBTTtBQUdGLGNBQUUsR0FBRyxNQUFNLENBQUMsRUFBRSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUM7QUFDN0Isc0JBQVUsR0FBRyxFQUFFLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxVQUFVLENBQUM7QUFFM0MsbUJBQU8sR0FBRztBQUNaLG9CQUFNLEVBQUUsTUFBTTtBQUNkLHdCQUFVLEVBQUUsVUFBVTtBQUN0QixzQkFBUSxFQUFFLEVBQUU7YUFDYjtBQUVHLGVBQUcsR0FBRyxVQUFVLENBQUMsSUFBSSxFQUFFOzs7QUFHM0IsZUFBRyxDQUFDLGFBQWEsQ0FBQyxpQkFBaUIsRUFBRSxJQUFJLENBQUM7Ozs7Ozs7NENBSTNCLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Ozs0Q0FDUixHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdEIsZUFBRzs7NENBQ0QsUUFBUSxDQUFDLEdBQUcsRUFBRSxPQUFPLENBQUM7Ozs7Ozs7QUFDN0IsYUFBQzs7Ozs7NENBR0ksR0FBRyxDQUFDLEtBQUssRUFBRTs7Ozs7Ozs7OztLQUVwQixDQUFDO0dBQ0g7O1NBbkNVLGFBQWE7R0FBUyxRQUFROzs7O0lBc0M5QixrQkFBa0I7WUFBbEIsa0JBQWtCOztBQUNqQixXQURELGtCQUFrQixDQUNoQixJQUFJLEVBQUUsT0FBTyxFQUFFOzs7MEJBRGpCLGtCQUFrQjs7QUFFM0IsK0JBRlMsa0JBQWtCLDZDQUVyQixJQUFJLEVBQUUsT0FBTyxFQUFDOzs7QUFHcEIsUUFBSSxDQUFDLGtCQUFrQixDQUFDLG9CQUFPLFFBQVEsRUFBRSxPQUFPO1VBRTFDLE9BQU8sRUFFUCxPQUFPLEVBTUwsR0FBRyxFQUdILFFBQVEsRUFDUixXQUFXLEVBQ1gsVUFBVSxFQUNWLFlBQVksRUFLTCxDQUFDLEVBUVIsSUFBSTs7OztBQTNCTixtQkFBTyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxJQUFJLENBQUMsQ0FBQzs7QUFDOUMsbUJBQU8sQ0FBQyxHQUFHLEdBQU0sT0FBTyxDQUFDLEdBQUcsa0JBQWU7QUFDdkMsbUJBQU8sR0FBRztBQUNaLHFCQUFPLEVBQUUsT0FBTzthQUNqQjs7O2lCQUVNLENBQUM7Ozs7Ozs0Q0FFVSxpQ0FBUSxPQUFPLENBQUM7OztBQUE1QixlQUFHOztBQUNQLGVBQUcsR0FBRyxtQkFBTyxHQUFHLEVBQUUsRUFBQyxPQUFPLEVBQUUsSUFBSSxFQUFDLENBQUM7O0FBRTlCLG9CQUFRLEdBQUcsTUFBTSxDQUFDLEdBQUcsQ0FBQyxRQUFRLENBQUMsWUFBWSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7QUFDM0QsdUJBQVcsR0FBRyxNQUFNLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsV0FBVyxDQUFDLEtBQUssQ0FBQztBQUNqRSxzQkFBVSxHQUFHLE1BQU0sQ0FBQyxHQUFHLENBQUMsUUFBUSxDQUFDLFlBQVksQ0FBQyxVQUFVLENBQUMsS0FBSyxDQUFDO0FBQy9ELHdCQUFZLEdBQUcsR0FBRyxDQUFDLFFBQVEsQ0FBQyxZQUFZLENBQUMsWUFBWTs7a0JBR3JELFlBQVksWUFBWSxLQUFLOzs7OztBQUV0QixhQUFDLEdBQUcsQ0FBQzs7O2tCQUFFLENBQUMsR0FBRyxXQUFXOzs7Ozs7NENBQ3ZCLFFBQVEsQ0FBQyxZQUFZLENBQUMsQ0FBQyxDQUFDLEVBQUUsT0FBTyxDQUFDOzs7QUFEVCxhQUFDLEVBQUU7Ozs7Ozs7Ozs7NENBSzlCLFFBQVEsQ0FBQyxZQUFZLEVBQUUsT0FBTyxDQUFDOzs7QUFHbkMsZ0JBQUksR0FBRyxVQUFVLEdBQUcsV0FBVzs7a0JBRS9CLElBQUksR0FBRyxRQUFROzs7Ozs7OztBQUNuQixtQkFBTyxDQUFDLEVBQUUsQ0FBQyxVQUFVLEdBQUcsSUFBSTs7Ozs7Ozs7O0tBRS9CLENBQUM7R0FDSDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7U0F4Q1Usa0JBQWtCO0dBQVMsUUFBUTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozt5QkNoTHpDLGVBQWU7OzJCQUdmLGdCQUFnQjs7b0JBR2hCLE1BQU07O3dCQUNLLFVBQVU7Ozs7d0JBQ1AsY0FBYzs7OztJQUVkLGNBQWM7V0FBZCxjQUFjOzBCQUFkLGNBQWM7OztlQUFkLGNBQWM7O1dBQ3RCLGNBQUMsSUFBSTs7Ozs7NENBQ0ssMkJBQWdCLEdBQUcsQ0FBQyxJQUFJLEVBQUUsT0FBTyxDQUFDOzs7QUFBckQsZ0JBQUksQ0FBQyxLQUFLOzs0Q0FDWSwyQkFBZ0IsR0FBRyxDQUFDLElBQUksRUFBRSxVQUFVLENBQUM7OztBQUEzRCxnQkFBSSxDQUFDLFFBQVE7Ozs7Ozs7S0FDZDs7O1dBRWMsa0JBQUMsTUFBTTtVQUNoQixJQUFJLEVBT0osVUFBVSxFQVFWLFVBQVUsa0ZBRUwsVUFBVSxFQUNiLFdBQVcsdUZBRU4sRUFBRSxFQUNMLE9BQU8sRUFPUCxVQUFVLHVGQUdMLEtBQUssRUFVZCxRQUFROzs7Ozs7NENBekNLLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxDQUFDO0FBQ2xDLGlCQUFHLEVBQUUsTUFBTTthQUNaLEVBQUU7QUFDRCx3QkFBVSxFQUFFO0FBQ1YseUJBQVMsRUFBRSxDQUFDO2VBQ2I7YUFDRixDQUFDOzs7QUFORSxnQkFBSTtBQU9KLHNCQUFVLEdBQUcsSUFBSSxDQUFDLE9BQU87QUFRekIsc0JBQVUsR0FBRyxFQUFFOzs7Ozt3QkFFSSxVQUFVOzs7Ozs7OztBQUF4QixzQkFBVTtBQUNiLHVCQUFXLEdBQUcsQ0FBQzs7Ozs7eUJBRUosVUFBVSxDQUFDLEdBQUc7Ozs7Ozs7O0FBQXBCLGNBQUU7OzRDQUNXLElBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDO0FBQ3hDLGlCQUFHLEVBQUUsRUFBRTthQUNSLEVBQUU7QUFDRCx3QkFBVSxFQUFFO0FBQ1YsdUJBQU8sRUFBRSxDQUFDO2VBQ1g7YUFDRixDQUFDOzs7QUFORSxtQkFBTztBQU9QLHNCQUFVLEdBQUcsT0FBTyxDQUFDLEtBQUs7Ozs7Ozs7QUFHOUIsOEJBQWtCLFVBQVUsMkhBQUU7QUFBckIsbUJBQUs7O0FBQ1oseUJBQVcsSUFBSSxLQUFLLENBQUMsUUFBUTthQUM5Qjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUlILHNCQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsV0FBVyxHQUFHLFVBQVUsQ0FBQyxHQUFHLENBQUMsQ0FBQzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBSXZELG9CQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUMsSUFBSSxFQUFFLFVBQVUsQ0FBQztnREFFeEMsUUFBUTs7Ozs7OztLQUNoQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztXQXVCYyxrQkFBQyxRQUFRLEVBQUUsS0FBSztVQUFFLE1BQU0seURBQUcsSUFBSTtVQUFFLE1BQU0seURBQUcsSUFBSTtVQUV2RCxNQUFNLEVBS04sTUFBTSxFQUtOLEdBQUc7Ozs7QUFWSCxrQkFBTSxHQUFHLHFCQUFRLElBQUksQ0FBQztBQUN4QixzQkFBUSxFQUFFLFFBQVE7YUFDbkIsQ0FBQyxDQUFDLEtBQUssRUFBRSxDQUFDLEdBQUcsQ0FBQyxVQUFDLENBQUM7cUJBQUssQ0FBQyxDQUFDLGdCQUFnQjthQUFBLENBQUM7QUFHckMsa0JBQU0sR0FBRyxFQUFFOztBQUNmLGtCQUFNLENBQUMsS0FBSyxHQUFHLEtBQUs7QUFDcEIsZ0JBQUksTUFBTSxFQUFFLE1BQU0sQ0FBQyxZQUFZLEdBQUcsTUFBTTtBQUN4QyxnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNOzs7NENBRXhCLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUNuQyxNQUFNLEVBQUU7QUFDTixtQkFBSyxFQUFFO0FBQ0wsc0JBQU0sRUFBRTtBQUNOLHVCQUFLLEVBQUUsTUFBTTtpQkFDZDtlQUNGO2FBQ0YsQ0FDRjs7O0FBUkcsZUFBRztnREFXQSxNQUFNOzs7Ozs7O0tBQ2Q7Ozs7Ozs7Ozs7OztXQVVnQixvQkFBQyxLQUFLO1VBQUUsTUFBTSx5REFBRyxJQUFJO1VBQUUsTUFBTSx5REFBRyxJQUFJO1VBRS9DLE1BQU0sRUFLTixHQUFHOzs7O0FBTEgsa0JBQU0sR0FBRyxFQUFFOztBQUNmLGtCQUFNLENBQUMsS0FBSyxHQUFHLEtBQUs7QUFDcEIsZ0JBQUksTUFBTSxFQUFFLE1BQU0sQ0FBQyxZQUFZLEdBQUcsTUFBTTtBQUN4QyxnQkFBSSxNQUFNLEVBQUUsTUFBTSxDQUFDLFlBQVksR0FBRyxNQUFNOzs7NENBRXhCLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUNuQyxNQUFNLEVBQUU7QUFDTixrQkFBSSxFQUFFO0FBQ0osc0JBQU0sRUFBRSxFQUFFO2VBQ1g7YUFDRixDQUNGOzs7QUFORyxlQUFHOzs7Ozs7O0tBT1I7Ozs7Ozs7Ozs7Ozs7Ozs7OztXQWdCa0Isc0JBQUMsSUFBSSxFQUFFLE9BQU87VUFTM0IsR0FBRyxFQW1DSCxLQUFLLHVGQUVBLENBQUMsdUZBc0JELElBQUksdUZBQ0YsQ0FBQzs7Ozs7QUE1RFIsZUFBRyxHQUFHLENBQUM7QUFDVCxtQkFBSyxFQUFFLE1BQU07QUFDYixxQkFBTyxFQUFFLElBQUksQ0FBQyxRQUFRO0FBQ3RCLHFCQUFPLEVBQUU7QUFDUCxxQkFBSyxFQUFFLFdBQVc7ZUFDbkI7QUFDRCxtQkFBSyxFQUFFO0FBQ0wsNEJBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtBQUMvQiw0QkFBWSxFQUFFLElBQUksQ0FBQyxZQUFZO2VBQ2hDO2FBQ0YsRUFDRDtBQUNFLG1CQUFLLEVBQUUsSUFBSSxDQUFDLFdBQVc7QUFDdkIscUJBQU8sRUFBRSxJQUFJLENBQUMsWUFBWTtBQUMxQixxQkFBTyxFQUFFO0FBQ1AscUJBQUssRUFBRSxlQUFlO2VBQ3ZCO0FBQ0QsbUJBQUssRUFBRTtBQUNMLHdCQUFRLEVBQUUsSUFBSSxDQUFDLFFBQVE7QUFDdkIsNEJBQVksRUFBRSxJQUFJLENBQUMsWUFBWTtlQUNoQzthQUNGLEVBQ0Q7QUFDRSxtQkFBSyxFQUFFLElBQUksQ0FBQyxXQUFXO0FBQ3ZCLHFCQUFPLEVBQUUsSUFBSSxDQUFDLFlBQVk7QUFDMUIscUJBQU8sRUFBRTtBQUNQLHFCQUFLLEVBQUUsZUFBZTtlQUN2QjtBQUNELG1CQUFLLEVBQUU7QUFDTCx3QkFBUSxFQUFFLElBQUksQ0FBQyxRQUFRO0FBQ3ZCLDRCQUFZLEVBQUUsSUFBSSxDQUFDLFlBQVk7ZUFDaEM7YUFDRixDQUNBO0FBRUcsaUJBQUssR0FBRyxFQUFFOzs7Ozt5QkFFQSxHQUFHOzs7Ozs7OztBQUFSLGFBQUM7NkJBQ1IsS0FBSzs7NENBQ2UsSUFBSSxDQUFDLEtBQUssQ0FBQyxTQUFTLENBQ3BDLENBQUM7QUFDQyxvQkFBTSxFQUFFLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssRUFBRTtBQUM3QixxQkFBSyxFQUFFLElBQUksQ0FBQyxLQUFLO2VBQ2xCLENBQUM7YUFDSCxFQUNEO0FBQ0Usc0JBQVEsRUFBRSxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsT0FBTyxDQUFDO2FBQzVDLEVBQ0Q7QUFDRSxtQkFBSyxFQUFFO0FBQ0wsbUJBQUcsRUFBRSxDQUFDO2VBQ1A7YUFDRixDQUNBLENBQ0YsQ0FBQyxPQUFPLEVBQUU7Ozs7NkJBQ0osQ0FBQzs7QUFoQlIsd0JBQVU7QUFnQlYsbUJBQUs7OzJCQWpCRCxJQUFJOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3lCQXFCSyxLQUFLOzs7Ozs7OztBQUFiLGdCQUFJOzs7Ozt5QkFDRyxJQUFJLENBQUMsVUFBVTs7Ozs7Ozs7QUFBcEIsYUFBQzs7NENBQ1EsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDOzs7QUFBcEMsYUFBQyxDQUFDLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztnREFJSixLQUFLOzs7Ozs7O0tBQ2I7Ozs7OztXQUltQix1QkFBQyxHQUFHO1VBQ2xCLElBQUksRUFHRixHQUFHLEVBQ0gsR0FBRyxFQVdDLEtBQUssRUFlWCxVQUFVOzs7O0FBOUJWLGdCQUFJOztrQkFFSixPQUFPLEdBQUcsS0FBSyxRQUFROzs7OztBQUNyQixlQUFHLEdBQUcsSUFBSSxNQUFNLENBQUksR0FBRyxPQUFJO0FBQzNCLGVBQUcsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxFQUFFLEVBQUU7QUFDNUIsd0JBQVUsRUFBRTtBQUNWLHFCQUFLLEVBQUUsQ0FBQztBQUNSLDRCQUFZLEVBQUUsQ0FBQztBQUNmLDRCQUFZLEVBQUUsQ0FBQztlQUNoQjthQUNGLENBQUM7OztpQkFFSyxDQUFDOzs7Ozs7OzRDQUVTLEdBQUcsQ0FBQyxJQUFJLEVBQUU7OztBQUF2QixnQkFBSTs7NENBQ2MsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUUsQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBL0MsaUJBQUs7O2lCQUNMLEtBQUs7Ozs7Ozs7Ozs7Ozs7Ozs7QUFLVCxlQUFHLENBQUMsS0FBSyxFQUFFO2dEQUNKLEdBQUc7Ozs7Ozs7QUFHZCxlQUFHLENBQUMsS0FBSyxFQUFFOzs7OztBQUVYLGdCQUFJLEdBQUcsR0FBRzs7O0FBR1Isc0JBQVUsR0FBRyxFQUFFOztBQUNuQixnQkFBSSxJQUFJLENBQUMsS0FBSyxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQztBQUMzQyxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztBQUN6RCxnQkFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLFVBQVUsQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLFlBQVksQ0FBQztnREFDbEQsVUFBVSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7S0FDNUI7OztXQUVzQiwwQkFBQyxTQUFTLEVBQUUsSUFBSTtVQUVqQyxTQUFTLEVBR1QsU0FBUyxFQUNULFVBQVUsRUFTVixhQUFhLEVBY2IsSUFBSSxFQXVCSixXQUFXLEVBY1gsS0FBSyxFQXFCTCxhQUFhLEVBMkJiLGlCQUFpQixFQU1qQixJQUFJOzs7O0FBdEhKLHFCQUFTLEdBQUcsU0FBWixTQUFTLENBQUksUUFBUTtxQkFBSyxRQUFRLEtBQUssUUFBUSxHQUFHLE9BQU8sR0FBRyxRQUFRO2FBQUE7O0FBR3BFLHFCQUFTLEdBQUcsSUFBSTtBQUNoQixzQkFBVSxHQUFHLEVBQUU7Ozs7QUFJbkIsZ0JBQUksSUFBSSxDQUFDLEtBQUssRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUM7QUFDM0MsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7QUFDekQsZ0JBQUksSUFBSSxDQUFDLFlBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUM7OztBQUdyRCx5QkFBYTs2QkFDVCxJQUFJLENBQUMsUUFBUTtrREFDZCxLQUFLLDJCQUdMLFFBQVE7Ozs7QUFGWCx5QkFBYSxHQUFHLENBQUM7Ozs7QUFHakIseUJBQWEsR0FBRyxDQUFDOzs7O0FBR2pCLHlCQUFhLEdBQUcsQ0FBQzs7OztBQUtqQixnQkFBSSxHQUFHLEVBQUU7NkJBQ0wsSUFBSSxDQUFDLFFBQVE7a0RBQ2QsS0FBSywyQkFTTCxRQUFROzs7O0FBUlgsZ0JBQUksQ0FBQyxJQUFJLENBQUM7QUFDUixpQkFBRyxFQUFFLENBQUM7QUFDTixpQkFBRyxFQUFFLElBQUk7YUFDVixFQUFFO0FBQ0QsaUJBQUcsRUFBRSxDQUFDO0FBQ04saUJBQUcsRUFBRSxLQUFLO2FBQ1gsQ0FBQzs7OztBQUdGLGdCQUFJLENBQUMsSUFBSSxDQUFDO0FBQ1IsaUJBQUcsRUFBRSxDQUFDO0FBQ04saUJBQUcsRUFBRSxJQUFJO2FBQ1YsRUFBRTtBQUNELGlCQUFHLEVBQUUsQ0FBQztBQUNOLGlCQUFHLEVBQUUsS0FBSzthQUNYLENBQUM7Ozs7QUFLRix1QkFBVyxHQUFHLElBQUk7NkJBQ2QsSUFBSSxDQUFDLFFBQVE7a0RBQ2QsS0FBSywyQkFHTCxRQUFROzs7O0FBRlgsdUJBQVcsR0FBRyxJQUFJOzs7O0FBR2xCLHVCQUFXLEdBQUcsR0FBRzs7Ozs7NENBUUgsSUFBSSxDQUFDLFlBQVksQ0FBQyxJQUFJLEVBQUU7QUFDeEMsd0JBQVUsRUFBRSw4QkFBOEI7YUFDM0MsQ0FBQzs7O0FBRkUsaUJBQUs7Ozs7O0FBT1QsaUJBQUssR0FBRyxLQUFLLENBQUMsR0FBRyxDQUNmLFVBQUMsSUFBSSxFQUFLO0FBQ1Isa0JBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxHQUFHLFNBQVMsQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE9BQU8sQ0FBQztBQUNsRCxrQkFBSSxDQUFDLFVBQVUsR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLEdBQUcsQ0FDbkMsVUFBQyxTQUFTLEVBQUs7QUFDYix5QkFBUyxDQUFDLEtBQUssR0FBRyxTQUFTLENBQUMsU0FBUyxDQUFDLEtBQUssQ0FBQztBQUM1Qyx1QkFBTyxTQUFTO2VBQ2pCLENBQ0Y7QUFDRCxxQkFBTyxJQUFJO2FBQ1osQ0FDRjs7O0FBR0cseUJBQWEsR0FDZixLQUFLLENBQUMsR0FBRyxDQUNQLFVBQUMsSUFBSTtxQkFDSCwrQkFBK0Isc0JBQ2Qsb0VBQzhDLGlCQUN0RCxJQUFJLENBQUMsS0FBSyxDQUFDLEtBQUssZUFBVyxXQUM5QixHQUNSLElBQUksQ0FBQyxVQUFVLENBQUMsR0FBRyxDQUNqQixVQUFDLFNBQVMsRUFBSztBQUNiLG9CQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsT0FBTyxLQUFLLFNBQVMsQ0FBQyxLQUFLLEVBQUU7O0FBRTFDLG1HQUErRSxTQUFTLENBQUMsS0FBSyx3QkFBb0I7aUJBQ25ILE1BQ0QsSUFBSSxTQUFTLENBQUMsS0FBSyxHQUFHLENBQUMsRUFBRTs7QUFFdkIsd0RBQW9DLFNBQVMsQ0FBQyxVQUFVLHVFQUFrRSxTQUFTLENBQUMsS0FBSyxtQkFBZTtpQkFDekosTUFBTTs7QUFFTCx1SkFBbUksU0FBUyxDQUFDLEtBQUssZUFBVztpQkFDOUo7ZUFDRixDQUNGLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxHQUNWLFFBQVEsR0FDUixRQUFRO2FBQUEsQ0FDVCxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUM7QUFFUiw2QkFBaUIsOERBRW5CLGFBQWE7QUFJWCxnQkFBSSxHQUFHO0FBQ1Qsd0JBQVUsRUFBRSxTQUFTO0FBQ3JCLHdCQUFVLEVBQUUsU0FBUztBQUNyQixrQkFBSSxFQUFLLFVBQVUsQ0FBQyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQUksU0FBUyxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsU0FBSSxJQUFJLENBQUMsSUFBSSxJQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsR0FBRyxHQUFHLElBQUksQ0FBQyxRQUFRLEdBQUcsRUFBRSxDQUFFO0FBQ25ILGdDQUFrQixFQUFFLGlCQUFpQjs7QUFFckMsMEJBQVksRUFBRSxVQUFVLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQztBQUNsQyxxQkFBTyxFQUFFLElBQUksQ0FBQyxZQUFZOzs7QUFHMUIsNkJBQWUsRUFBRSxhQUFhO0FBQzlCLGtCQUFJLEVBQUUsSUFBSTtBQUNWLDBCQUFZLEVBQUUsV0FBVzthQUMxQjs2QkFFRCxNQUFNOzZCQUFRLElBQUk7OzRDQUFRLElBQUksQ0FBQyw4QkFBOEIsQ0FBQyxJQUFJLENBQUM7Ozs7MkJBQTVELE1BQU07NkJBQ2IsTUFBTTs2QkFBUSxJQUFJOzs0Q0FBUSxJQUFJLENBQUMsNkJBQTZCLENBQUMsSUFBSSxDQUFDOzs7OzJCQUEzRCxNQUFNOzZCQUNiLE1BQU07OEJBQVEsSUFBSTs7NENBQVEsSUFBSSxDQUFDLDRCQUE0QixDQUFDLElBQUksQ0FBQzs7OzsyQkFBMUQsTUFBTTs7QUFFYixrQkFBTSxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7O2dEQUVuQyxJQUFJOzs7Ozs7O0tBQ1o7OztXQUVvQyx3Q0FBQyxJQUFJO1VBQ3BDLFFBQVEsRUFJSCxDQUFDOzs7O0FBSk4sb0JBQVEsR0FBRyxFQUFFOzs7QUFFakIsb0JBQVEsSUFBSSxJQUFJLENBQUMsV0FBVzs7QUFFNUIsaUJBQVMsQ0FBQyxHQUFHLENBQUMsRUFBRSxDQUFDLEdBQUcsSUFBSSxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDM0Msc0JBQVEsc0NBQW9DLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVE7YUFDbkU7O0FBRUQsb0JBQVEsSUFBSSxHQUFHO2dEQUNSLEVBQUMsU0FBUyxFQUFFLFFBQVEsRUFBQzs7Ozs7OztLQUM3Qjs7O1dBRW1DLHVDQUFDLElBQUk7Ozs7Z0RBRWhDLEVBQUMsT0FBTyxFQUFFLElBQUksQ0FBQyxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBQzs7Ozs7OztLQUM5Qzs7O1dBRWtDLHNDQUFDLElBQUk7VUFFbEMsR0FBRzs7OztBQUFILGVBQUcsR0FBRyxPQUFPLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEtBQUssV0FBVyxHQUFHLEVBQUUsR0FBRyxDQUFFLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUU7Z0RBQ2xFLEVBQUUsTUFBTSxFQUFFLEdBQUcsRUFBRTs7Ozs7OztLQUN2Qjs7Ozs7V0FHc0IsMEJBQUMsR0FBRyxFQUFFLElBQUk7VUFDekIsUUFBUSxFQUNSLFdBQVcsRUFFYixLQUFLLEVBS0gsU0FBUyxFQUNOLENBQUM7Ozs7QUFUSixvQkFBUSxHQUFHLEVBQUU7QUFDYix1QkFBVyxHQUFHLEdBQUc7QUFFbkIsaUJBQUssR0FBRyxFQUFFOzs7QUFFZCxpQkFBSyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxHQUFHLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDLENBQUM7OztBQUdoRCxxQkFBUyxHQUFHLElBQUk7O0FBQ3RCLGlCQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQzNDLG1CQUFLLENBQUMsU0FBUyxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxHQUFHLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDO2FBQzVDOzs7QUFHRCxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFFBQVE7Ozs0Q0FDRSxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQzs7Ozs7NkJBQUksSUFBSSxDQUFDLFFBQVE7Ozs2QkFBSSxJQUFJLENBQUMsSUFBSTs7NkJBQUksV0FBVztBQUEvRyxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxrQkFBWSxPQUFPOztBQUNoQyxpQkFBSyxDQUFDLE1BQU0sQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXO0FBQ2hDLGlCQUFLLENBQUMsTUFBTSxDQUFDLEdBQUcsSUFBSSxDQUFDLFdBQVc7QUFDaEMsaUJBQUssQ0FBQyxNQUFNLENBQUMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRSxDQUFDLEtBQUssQ0FBQyxDQUFDLFFBQVEsQ0FBQztBQUN2RCxpQkFBSyxDQUFDLElBQUksQ0FBQyxHQUFHLElBQUksQ0FBQyxXQUFXO0FBQzlCLGlCQUFLLENBQUMsZ0JBQWdCLENBQUMsR0FBRyxJQUFJLENBQUMsUUFBUTs7Z0RBRWhDLEtBQUs7Ozs7Ozs7S0FDYjs7O1dBRTBDLDhDQUFDLFFBQVE7VUFDOUMsRUFBRSxFQUNGLEdBQUcsRUFDSCxPQUFPLEVBTVAsSUFBSSxFQXVCSixXQUFXLHVGQUNOLEdBQUcsRUFHUixjQUFjLEVBQ1QsQ0FBQyxFQUNKLEdBQUU7Ozs7O0FBckNKLGNBQUUsR0FBRyxxQkFBcUI7QUFDMUIsZUFBRyxHQUFHLFVBQVU7QUFDaEIsbUJBQU8sR0FBRztBQUNaLHNCQUFRLEVBQUUsQ0FBQyxNQUFNLENBQUM7QUFDbEIsbUJBQUssRUFBRSxDQUFDLFNBQVMsRUFBRSxVQUFVLENBQUM7YUFDL0I7OzRDQUdnQixJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FDbkMsQ0FDRTtBQUNFLG9CQUFNLHNCQUNILEVBQUUsRUFBRyxRQUFRLENBQ2Y7YUFDRixFQUNEO0FBQ0Usb0JBQU07QUFDSixtQkFBRyxRQUFNLEVBQUk7aUJBQ1osR0FBRyxFQUFHLEVBQUUsU0FBUyxRQUFNLEdBQUssRUFBRSxDQUNoQzthQUNGLEVBQ0Q7QUFDRSxzQkFBUTtBQUNOLG1CQUFHLEVBQUUsQ0FBQztBQUNOLHdCQUFRLEVBQUUsTUFBTTtpQkFDZixHQUFHLFFBQU8sR0FBRyxDQUNmO2FBQ0YsQ0FDRixDQUNGLENBQUMsT0FBTyxFQUFFOzs7QUFyQlAsZ0JBQUk7QUF1QkosdUJBQVcsR0FBRyxFQUFFOzs7Ozs7QUFDcEIsOEJBQWdCLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxRQUFRLDJIQUFFO0FBQXpCLGlCQUFHOztBQUNWLHlCQUFXLEdBQUcsV0FBVyxDQUFDLE1BQU0sQ0FBQyxPQUFPLE1BQUksR0FBRyxDQUFHLENBQUM7YUFDcEQ7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0csMEJBQWMsR0FBRyxJQUFJLEtBQUssQ0FBQyxDQUFDLENBQUM7O0FBQ2pDLGlCQUFTLENBQUMsR0FBRyxDQUFDLEVBQUUsQ0FBQyxHQUFHLGNBQWMsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxFQUFFLEVBQUU7QUFDMUMsaUJBQUUsR0FBRyxPQUFPLFdBQVcsQ0FBQyxDQUFDLENBQUMsS0FBSyxXQUFXLEdBQUcsTUFBTSxHQUFHLFdBQVcsQ0FBQyxDQUFDLENBQUM7O0FBQ3hFLDRCQUFjLENBQUMsQ0FBQyxDQUFDLEdBQUcsRUFBQyxpQkFBaUIsRUFBRSxDQUFDLEdBQUcsQ0FBQyxFQUFFLGdCQUFnQixFQUFFLEdBQUUsRUFBQzthQUNyRTs7Z0RBRU0sRUFBQyxjQUFjLEVBQUUsY0FBYyxFQUFDOzs7Ozs7O0tBQ3hDOzs7Ozs7O1dBSytCLDRCQUFDLElBQUk7VUFDN0IsS0FBSyxFQUNQLFdBQVcsRUFrQlQsS0FBSzs7OztBQW5CTCxpQkFBSyxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsV0FBVyxFQUFFO0FBQ2hDLHVCQUFXLEdBQUc7QUFDaEIsa0JBQUksRUFBRTtBQUNKLDJCQUFXLEVBQUUsR0FBRztBQUNoQix3QkFBUSxFQUFFLEtBQUs7QUFDZixzQkFBTSxFQUFFLElBQUk7QUFDWixxQkFBSyxFQUFFLElBQUksQ0FBQyxJQUFJO0FBQ2hCLG9CQUFJLEVBQUUsSUFBSTtlQUNYO0FBQ0Qsb0JBQU0sRUFBRTtBQUNOLDJCQUFXLEVBQUUsR0FBRztBQUNoQix3QkFBUSxFQUFFLEtBQUs7QUFDZixzQkFBTSxFQUFFLElBQUk7QUFDWix3QkFBUSxFQUFFLElBQUk7QUFDZCwwQkFBVSxPQUFLLElBQUksQ0FBQyxLQUFLLElBQUcsSUFBSSxDQUFDLFlBQVksS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsWUFBWSxLQUFHLElBQUksQ0FBQyxZQUFZLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBRTtlQUNoSjtBQUNELG1CQUFLLEVBQUUsRUFBRTthQUNWO0FBRUssaUJBQUssR0FBRyx5QkFBWSxJQUFJLEVBQUU7O0FBQ2hDLGlCQUFLLENBQUMsT0FBTyxDQUNYLGNBQUksRUFBSTtBQUNOLGtCQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsU0FBUyxDQUFHO0FBQzVELGtCQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsVUFBVSxDQUFHO0FBQzlELGtCQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsVUFBVSxDQUFHOztBQUU5RCx5QkFBVyxDQUFDLEtBQUssQ0FBQyxJQUFJLENBQ3BCO0FBQ0UsMkJBQVcsRUFBRSxHQUFHO0FBQ2hCLHdCQUFRLEVBQUUsS0FBSztBQUNmLHdCQUFRLEVBQUUsSUFBSTtBQUNkLHNCQUFNLEVBQUUsSUFBSSxDQUFDLE1BQU0sQ0FBQztBQUNwQixxQkFBSyxFQUFFLElBQUk7QUFDWCx3QkFBUSxPQUFLLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBUTtBQUN0Qyx1QkFBTyxFQUFFLElBQUk7ZUFDZCxDQUNGO2FBQ0YsQ0FDRjs7Z0RBRU0sV0FBVzs7Ozs7OztLQUNuQjs7Ozs7Ozs7V0FNNkIsZ0NBQUMsSUFBSSxFQUFFO0FBQ25DLGFBQU87QUFDTCxtQkFBVyxFQUFFLEdBQUc7QUFDaEIsZ0JBQVEsRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFdBQVcsRUFBRTtBQUNoQyxjQUFNLEVBQUUsSUFBSTtBQUNaLGFBQUssRUFBRSxJQUFJLENBQUMsSUFBSTtBQUNoQixZQUFJLEVBQUUsSUFBSTtPQUNYO0tBQ0Y7Ozs7Ozs7O1dBTStCLGtDQUFDLElBQUksRUFBRTtBQUNyQyxhQUFPO0FBQ0wsbUJBQVcsRUFBRSxHQUFHO0FBQ2hCLGdCQUFRLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7QUFDaEMsY0FBTSxFQUFFLElBQUk7QUFDWixnQkFBUSxFQUFFLElBQUk7QUFDZCxrQkFBVSxPQUFLLElBQUksQ0FBQyxLQUFLLElBQUcsSUFBSSxDQUFDLFlBQVksS0FBSyxFQUFFLEdBQUcsRUFBRSxHQUFHLEdBQUcsR0FBRyxJQUFJLENBQUMsWUFBWSxLQUFHLElBQUksQ0FBQyxZQUFZLEtBQUssRUFBRSxHQUFHLEVBQUUsR0FBRyxHQUFHLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBRTtPQUNoSjtLQUNGOzs7Ozs7OztXQU1tQyxzQ0FBQyxJQUFJLEVBQUUsSUFBSSxFQUFFO0FBQy9DLFVBQU0sS0FBSyxHQUFHLElBQUksQ0FBQyxJQUFJLE1BQUksSUFBSSxDQUFDLElBQUksQ0FBRyxNQUFJLElBQUksQ0FBQyxTQUFTLENBQUc7QUFDNUQsVUFBTSxNQUFNLEdBQUcsSUFBSSxDQUFDLElBQUksTUFBSSxJQUFJLENBQUMsSUFBSSxDQUFHLE1BQUksSUFBSSxDQUFDLFVBQVUsQ0FBRztBQUM5RCxVQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsSUFBSSxNQUFJLElBQUksQ0FBQyxJQUFJLENBQUcsTUFBSSxJQUFJLENBQUMsVUFBVSxDQUFHOztBQUU5RCxhQUFPO0FBQ0wsbUJBQVcsRUFBRSxHQUFHO0FBQ2hCLGdCQUFRLEVBQUUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxXQUFXLEVBQUU7QUFDaEMsZ0JBQVEsRUFBRSxJQUFJO0FBQ2QsY0FBTSxFQUFFLElBQUksQ0FBQyxNQUFNLENBQUM7QUFDcEIsYUFBSyxFQUFFLElBQUk7QUFDWCxnQkFBUSxPQUFLLEtBQUssR0FBRyxNQUFNLEdBQUcsTUFBUTtBQUN0QyxlQUFPLEVBQUUsSUFBSTtPQUNkO0tBQ0Y7OztTQTVrQmtCLGNBQWM7OztxQkFBZCxjQUFjOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OEJDWmYsaUJBQWlCOzs7O3FCQUNaLFFBQVE7O3lCQUNYLGVBQWU7Ozs7QUFFckMsSUFBTSxRQUFRLEdBQUcsd0NBQXdDOztJQUVwQyxRQUFRO0FBQ2YsV0FETyxRQUFRLENBQ2QsSUFBSSxFQUFFLE1BQU0sRUFBRTswQkFEUixRQUFROztBQUV6QixRQUFJLENBQUMsSUFBSSxHQUFHLElBQUk7QUFDaEIsUUFBSSxDQUFDLE1BQU0sR0FBRyxNQUFNO0dBQ3JCOzs7O2VBSmtCLFFBQVE7O1dBT1Ysb0JBQUMsV0FBVTtVQUN0QixPQUFPLEVBRUwsR0FBRzs7OztBQUZMLG1CQUFPLHlCQUF1QixJQUFJLENBQUMsTUFBTSw2QkFBd0IscUJBQVMsV0FBVSxFQUFFLEVBQUMsT0FBTyxFQUFFLElBQUksRUFBQyxDQUFDOzs7NENBRXhGLElBQUksQ0FBQyxXQUFXLENBQzlCLGdCQUFnQixFQUNoQixPQUFPLENBQ1I7OztBQUhHLGVBQUc7Z0RBSUEsRUFBQyxRQUFRLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRSxPQUFPLEVBQUM7Ozs7O2tCQUVyQyxNQUFNLENBQUMsTUFBTSxDQUFDLHVCQUFVLEtBQUssZ0JBQUcsRUFBRSxFQUFDLFVBQVUsRUFBRSxPQUFPLEVBQUMsQ0FBQzs7Ozs7OztLQUVqRTs7O1dBRWlCLHFCQUFDLE1BQU0sRUFBRSxJQUFJO1VBRXpCLFVBQVUsRUFTVixHQUFHOzs7O0FBVEgsc0JBQVUsR0FBRztBQUNmLG9CQUFNLEVBQUUsTUFBTTtBQUNkLGlCQUFHLEVBQUssUUFBUSxTQUFJLE1BQVE7QUFDNUIsa0JBQUksRUFBRSxJQUFJO2FBQ1g7OztBQUVELGtCQUFNLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsSUFBSSxDQUFDOzs7OzRDQUdwQixpQ0FBUSxVQUFVLENBQUM7OztBQUEvQixlQUFHO2dEQUVBLEdBQUc7Ozs7Ozs7S0FDWDs7O1dBRWlCLHFCQUFDLGVBQWU7VUFFNUIsVUFBVSxFQVVWLEdBQUc7Ozs7QUFWSCxzQkFBVSxHQUFHO0FBQ2Ysb0JBQU0sRUFBRSxNQUFNO0FBQ2QsaUJBQUcsRUFBSyxRQUFRLGlCQUFjO2FBQy9COzs7QUFFRCxrQkFBTSxDQUFDLE1BQU0sQ0FBQyxVQUFVLEVBQUUsSUFBSSxDQUFDLElBQUksQ0FBQzs7OzRDQUVaLElBQUksQ0FBQyw0QkFBNEIsQ0FBQyxlQUFlLENBQUM7OztBQUExRSxzQkFBVSxDQUFDLElBQUk7OzRDQUdDLGlDQUFRLFVBQVUsQ0FBQzs7O0FBQS9CLGVBQUc7Z0RBRUEsR0FBRzs7Ozs7OztLQUNYOzs7V0FFa0Msc0NBQUMsZUFBZTtVQWdCN0Msa0JBQWtCLGtGQUViLElBQUksdUZBRUYsQ0FBQyxFQVlOLElBQUksdUZBVUcsU0FBUyx1RkFPUCxHQUFHLEVBV2QsY0FBYzs7Ozs7QUE1Q2QsOEJBQWtCLEdBQUcsRUFBRTs7Ozs7d0JBRVYsZUFBZTs7Ozs7Ozs7QUFBdkIsZ0JBQUk7Ozs7Ozs7QUFFWCw4QkFBYyxJQUFJLENBQUMsVUFBVSwySEFBRTtBQUF0QixlQUFDOzs7QUFFUixrQkFBSSxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUcsRUFBRSxDQUFDLENBQUMsS0FBSyxHQUFHLEdBQUc7YUFDakM7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUVELDhCQUFrQixJQUFJLG1CQUFtQjtBQUN6Qyw4QkFBa0IsbUJBQWlCLElBQUksQ0FBQyxRQUFRLGdCQUFhOzs7Ozs7QUFNekQsZ0JBQUksR0FBRyxJQUFJLENBQUMsVUFBVSxDQUFDLENBQUMsQ0FBQzs7a0JBQ3pCLElBQUksQ0FBQywwQkFBMEIsS0FBSyxFQUFFLElBQUksSUFBSSxDQUFDLHdCQUF3QixLQUFLLEVBQUU7Ozs7OztBQUVoRiw4QkFBa0IsSUFBSSxnQ0FBZ0M7QUFDdEQsOEJBQWtCLHFCQUFtQixJQUFJLENBQUMsS0FBSyxrQkFBZTs7Ozs7O0FBRzlELDhCQUFrQixJQUFJLGdDQUFnQzs7Ozs7Ozt5QkFHaEMsSUFBSSxDQUFDLFVBQVU7Ozs7Ozs7O0FBQTVCLHFCQUFTOzs7QUFFaEIscUJBQVMsQ0FBQyxpQkFBaUIsR0FBRyxTQUFTLENBQUMsS0FBSztBQUM3QyxtQkFBTyxTQUFTLENBQUMsS0FBSzs7O0FBR3RCLDhCQUFrQixJQUFJLGlCQUFpQjs7Ozs7QUFDdkMsOEJBQWdCLE1BQU0sQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLDJIQUFFO0FBQS9CLGlCQUFHOztBQUNWLGdDQUFrQixVQUFRLEdBQUcsU0FBSSxTQUFTLENBQUMsR0FBRyxDQUFDLFVBQUssR0FBRyxNQUFHO2FBQzNEOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELDhCQUFrQixJQUFJLGtCQUFrQjs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUk1Qyw4QkFBa0IsSUFBSSxvQkFBb0I7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUl4QywwQkFBYyxxQ0FFUixJQUFJLENBQUMsTUFBTSx1QkFDbkIsa0JBQWtCO2dEQUtiLGNBQWM7Ozs7Ozs7S0FDdEI7OztTQTFIa0IsUUFBUTs7O3FCQUFSLFFBQVE7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQ05SLFNBQVM7V0FBVCxTQUFTOzBCQUFULFNBQVM7OztlQUFULFNBQVM7O1dBQ2YsZUFBQyxDQUFDLEVBQUU7QUFDZixVQUFJLEdBQUcsR0FBRyxFQUFFOztBQUVaLFVBQUksQ0FBQyxZQUFZLEtBQUssRUFBRTtBQUN0QixXQUFHLENBQUMsT0FBTyxHQUFHLENBQUMsQ0FBQyxPQUFPO0FBQ3ZCLFdBQUcsQ0FBQyxJQUFJLEdBQUcsQ0FBQyxDQUFDLElBQUk7QUFDakIsV0FBRyxDQUFDLFFBQVEsR0FBRyxDQUFDLENBQUMsUUFBUTtBQUN6QixXQUFHLENBQUMsVUFBVSxHQUFHLENBQUMsQ0FBQyxVQUFVO0FBQzdCLFdBQUcsQ0FBQyxZQUFZLEdBQUcsQ0FBQyxDQUFDLFlBQVk7QUFDakMsV0FBRyxDQUFDLEtBQUssR0FBRyxDQUFDLENBQUMsS0FBSztPQUNwQixNQUFNO0FBQ0wsV0FBRyxHQUFHLENBQUM7T0FDUjs7QUFFRCxhQUFPLEdBQUc7S0FDWDs7O1NBaEJrQixTQUFTOzs7cUJBQVQsU0FBUzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7dUJDQUYsU0FBUzs7SUFFeEIsZUFBZTtXQUFmLGVBQWU7MEJBQWYsZUFBZTs7O2VBQWYsZUFBZTs7V0FDVCxhQUFDLElBQUksRUFBRSxVQUFVO1VBQzVCLE1BQU0sRUFDTixFQUFFOzs7Ozs0Q0FEYSxxQkFBWSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7O0FBQTVDLGtCQUFNO0FBQ04sY0FBRSxHQUFHLE1BQU0sQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztnREFDMUIsRUFBRSxDQUFDLFVBQVUsQ0FBQyxVQUFVLENBQUM7Ozs7Ozs7S0FDakM7OztTQUxVLGVBQWU7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQ0ZWLE9BQU87Ozs7c0JBQ04sUUFBUTs7OztJQUVOLEtBQUs7QUFDWixXQURPLEtBQUssQ0FDWCxPQUFPLEVBQUU7MEJBREgsS0FBSzs7O0FBR3RCLFFBQUksQ0FBQyxJQUFJLEdBQUcsbUJBQU0sVUFBVSxDQUFDLE9BQU8sQ0FBQzs7O0FBR3JDLFFBQUksWUFBWSxHQUFHLEVBQUMsa0JBQWtCLEVBQUUsSUFBSSxFQUFDO0FBQzdDLFVBQU0sQ0FBQyxNQUFNLENBQUMsWUFBWSxFQUFFLE9BQU8sQ0FBQztBQUNwQyxRQUFJLENBQUMsU0FBUyxHQUFHLG1CQUFNLFVBQVUsQ0FBQyxZQUFZLENBQUM7R0FDaEQ7O2VBVGtCLEtBQUs7Ozs7Ozs7V0FtQmxCLGVBQUMsR0FBRyxFQUFFOzs7QUFHVixhQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FDakIsSUFBSSxDQUNILFVBQUMsR0FBRyxFQUFLO0FBQ1AsZUFBTyxJQUFJLE9BQU8sQ0FDaEIsVUFBQyxPQUFPLEVBQUUsTUFBTSxFQUFLOztBQUVuQixhQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsRUFBRSxVQUFDLENBQUMsRUFBRSxHQUFHLEVBQUs7O0FBRXpCLGVBQUcsQ0FBQyxPQUFPLEVBQUU7QUFDYixnQkFBSSxDQUFDLEVBQUU7QUFDTCxvQkFBTSxDQUFDLENBQUMsQ0FBQzthQUNWLE1BQU0sT0FBTyxDQUFDLEdBQUcsQ0FBQztXQUNwQixDQUFDO1NBQ0gsQ0FDRjtPQUNGLENBQ0YsU0FDSyxDQUFDLFVBQUMsQ0FBQyxFQUFLO0FBQ1osY0FBTSxDQUFDO09BQ1IsQ0FBQztLQUNMOzs7V0FFa0Isc0JBQUMsR0FBRztVQUNqQixHQUFHOzs7Ozs0Q0FBUyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0EsR0FBRyxDQUFDLFFBQVE7Ozs7Ozs7S0FDcEI7Ozs7Ozs7Ozs7V0FRaUIscUJBQUMsS0FBSztVQUFFLElBQUkseURBQUcsRUFBRTtVQUFFLE9BQU8seURBQUcsRUFBRTs7VUFJM0MsR0FBRyxFQUVILEdBQUcsa0ZBV0UsQ0FBQyx1RkFRTixHQUFHOzs7OztBQXJCSCxlQUFHLG9CQUFrQixLQUFLO0FBRTFCLGVBQUcsR0FBRyxJQUFJLEdBQUcsRUFBRTs7Ozs7O0FBQ25CLDZCQUFjLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLHVIQUFFO0FBQXhCLGVBQUM7O0FBQ1Isa0JBQUksSUFBSSxDQUFDLENBQUMsQ0FBQyxLQUFLLElBQUksRUFBRTtBQUNwQixtQkFBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDO2VBQ25CLE1BQU0sSUFBSSxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsV0FBVyxDQUFDLElBQUksS0FBSyxNQUFNLEVBQUU7O0FBRTlDLG1CQUFHLENBQUMsR0FBRyxDQUFDLENBQUMsUUFBTSxLQUFLLENBQUMsVUFBVSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxPQUFJO2VBQzdDLE1BQU07QUFDTCxtQkFBRyxDQUFDLEdBQUcsQ0FBQyxDQUFDLE9BQUssbUJBQU0sTUFBTSxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFHO2VBQ3ZDO2FBQ0Y7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELDhCQUFjLE1BQU0sQ0FBQyxJQUFJLENBQUMsT0FBTyxDQUFDLDJIQUFFO0FBQTNCLGVBQUM7O0FBQ1IsaUJBQUcsQ0FBQyxHQUFHLENBQUMsQ0FBQyxFQUFFLE9BQU8sQ0FBQyxDQUFDLENBQUMsS0FBSyxJQUFJLEdBQUcsTUFBTSxHQUFHLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQzthQUN0RDs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBRUQsZUFBRyxXQUFTLDZCQUFJLEdBQUcsQ0FBQyxJQUFJLEVBQUUsR0FBRSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQUs7O0FBRTFDLGVBQUcsaUJBQWUsNkJBQUksR0FBRyxDQUFDLE1BQU0sRUFBRSxHQUFFLElBQUksQ0FBQyxHQUFHLENBQUMsUUFBSzs7OzRDQUVsQyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0EsR0FBRyxDQUFDLFFBQVE7Ozs7Ozs7S0FDcEI7Ozs7Ozs7Ozs7O1dBU2lCLHFCQUFDLEtBQUssRUFBRSxNQUFNLEVBQUUsSUFBSSxFQUFFLE9BQU87VUFDekMsR0FBRyxFQUVILE9BQU8sdUZBSUYsQ0FBQyx1RkFPTixHQUFHOzs7OztBQWJILGVBQUcsZUFBYSxLQUFLO0FBRXJCLG1CQUFPLEdBQUcsRUFBRTs7Ozs7O0FBQ2hCLDhCQUFjLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxDQUFDLDJIQUFFO0FBQXhCLGVBQUM7O0FBQ1IscUJBQU8sQ0FBQyxJQUFJLENBQUksQ0FBQyxTQUFJLG1CQUFNLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBRzthQUM5Qzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBQ0QsOEJBQWMsTUFBTSxDQUFDLElBQUksQ0FBQyxPQUFPLENBQUMsMkhBQUU7QUFBM0IsZUFBQzs7QUFDUixxQkFBTyxDQUFDLElBQUksQ0FBSSxDQUFDLFNBQUksT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFHO2FBQ25DOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztBQUNELGVBQUcsSUFBSSxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQzs7QUFFeEIsZUFBRyxnQkFBYyxNQUFNLE1BQUc7Ozs0Q0FFVixJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQzs7O0FBQTNCLGVBQUc7Z0RBQ0EsR0FBRzs7Ozs7OztLQUNYOzs7OztXQUdnQixvQkFBQyxHQUFHO1VBQ2YsUUFBUSxFQUdOLEdBQUc7Ozs7QUFITCxvQkFBUSxHQUFHLElBQUksQ0FBQyxJQUFJOztBQUN4QixnQkFBSSxDQUFDLElBQUksR0FBRyxJQUFJLENBQUMsU0FBUzs7OzRDQUVSLElBQUksQ0FBQyxLQUFLLENBQUMsR0FBRyxDQUFDOzs7QUFBM0IsZUFBRztnREFDQSxHQUFHOzs7OztBQUVWLGdCQUFJLENBQUMsSUFBSSxHQUFHLFFBQVE7Ozs7Ozs7O0tBRXZCOzs7V0FFc0I7Ozs7OzRDQUNmLElBQUksQ0FBQyxLQUFLLHNCQUFzQjs7Ozs7OztLQUN2Qzs7O1dBRVk7Ozs7OzRDQUNMLElBQUksQ0FBQyxLQUFLLFdBQVc7Ozs7Ozs7S0FDNUI7OztXQUVjOzs7Ozs0Q0FDUCxJQUFJLENBQUMsS0FBSyxhQUFhOzs7Ozs7O0tBQzlCOzs7V0FFYyx3QkFBQyxHQUFHLEVBQWtEOzs7VUFBaEQsUUFBUSx5REFBRyxVQUFDLE1BQU0sRUFBSyxFQUFFO1VBQUUsT0FBTyx5REFBRyxVQUFDLENBQUMsRUFBSyxFQUFFOztBQUNqRSxhQUFPLElBQUksQ0FBQyxNQUFNLEVBQUUsQ0FDakIsSUFBSSxDQUNILFVBQUMsR0FBRyxFQUFLO0FBQ1AsZUFBTyxJQUFJLE9BQU8sQ0FDaEIsb0JBQU8sT0FBTyxFQUFFLE1BQU07Ozs7O0FBRXBCLG1CQUFHLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUNYLEVBQUUsQ0FBQyxRQUFRLEVBQ1YsVUFBQyxNQUFNLEVBQUs7QUFDVixxQkFBRyxDQUFDLEtBQUssRUFBRTtBQUNYLDBCQUFRLENBQUMsTUFBTSxDQUFDO0FBQ2hCLHFCQUFHLENBQUMsTUFBTSxFQUFFO2lCQUNiLENBQUMsQ0FDSCxFQUFFLENBQUMsT0FBTyxFQUFFLFVBQUMsQ0FBQyxFQUFLO0FBQ2xCLHlCQUFPLENBQUMsQ0FBQyxDQUFDO2lCQUNYLENBQUMsQ0FDRCxFQUFFLENBQUMsS0FBSyxFQUFFLFlBQU07QUFDZixxQkFBRyxDQUFDLE9BQU8sRUFBRTtBQUNiLHlCQUFPLEVBQUU7aUJBQ1YsQ0FBQzs7Ozs7OztTQUNMLENBQ0Y7T0FDRixDQUNGLFNBQ0ssQ0FBQyxVQUFDLENBQUMsRUFBSztBQUNaLGNBQU0sQ0FBQztPQUNSLENBQUM7S0FDTDs7O1dBRU0sa0JBQUc7OztBQUNSLGFBQU8sSUFBSSxPQUFPLENBQ2hCLFVBQUMsT0FBTyxFQUFFLE1BQU0sRUFBSzs7QUFFbkIsZUFBSyxJQUFJLENBQUMsYUFBYSxDQUFDLFVBQUMsQ0FBQyxFQUFFLEdBQUcsRUFBSztBQUNsQyxjQUFJLENBQUMsRUFBRTtBQUNMLGtCQUFNLENBQUMsQ0FBQyxDQUFDO1dBQ1YsTUFBTTtBQUNMLG1CQUFPLENBQUMsR0FBRyxDQUFDO1dBQ2I7U0FDRixDQUFDO09BQ0gsQ0FDRixTQUNPLENBQ0osVUFBQyxDQUFDLEVBQUs7QUFDTCxjQUFNLENBQUM7T0FDUixDQUNGO0tBQ0o7OztXQTFLaUIsb0JBQUMsSUFBSSxFQUFFO0FBQ3ZCLGFBQU8seUJBQU8sSUFBSSxDQUFDLENBQUMsTUFBTSxFQUFFLENBQUMsU0FBUyxDQUFDLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQyxPQUFPLENBQUMsR0FBRyxFQUFFLEdBQUcsQ0FBQztLQUNoRTs7O1NBYmtCLEtBQUs7OztxQkFBTCxLQUFLOzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7OztJQ0hMLE1BQU07QUFDYixXQURPLE1BQU0sQ0FDWixVQUFVLEVBQUU7MEJBRE4sTUFBTTs7QUFFdkIsUUFBSSxDQUFDLFVBQVUsR0FBRyxVQUFVO0FBQzVCLFFBQUksQ0FBQyxhQUFhLEdBQUcsSUFBSTtBQUN6QixRQUFJLENBQUMsUUFBUSxHQUFHLElBQUk7QUFDcEIsUUFBSSxDQUFDLFdBQVcsR0FBRyxJQUFJO0FBQ3ZCLFFBQUksQ0FBQyxLQUFLLEdBQUcsQ0FBQztBQUNkLFFBQUksQ0FBQyxXQUFXLEdBQUcsQ0FBQztHQUNyQjs7ZUFSa0IsTUFBTTs7V0FVWixnQkFBQyxHQUFHOzs7O2tCQUVYLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDOzs7OztpQkFDaEMsSUFBSSxDQUFDLGFBQWE7Ozs7Ozs0Q0FDZCxJQUFJLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7OztpQkFHMUMsSUFBSSxDQUFDLFFBQVE7Ozs7Ozs0Q0FDVCxJQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQzs7O0FBRTFCLGdCQUFJLENBQUMsS0FBSyxFQUFFOztBQUVaLGdCQUFJLElBQUksQ0FBQyxLQUFLLEdBQUcsSUFBSSxDQUFDLFVBQVUsS0FBSyxDQUFDLEVBQUU7QUFDdEMsa0JBQUksQ0FBQyxLQUFLLEVBQUU7QUFDWixrQkFBSSxDQUFDLFdBQVcsRUFBRTthQUNuQjs7Ozs7OztLQUNGOzs7V0FDSyxpQkFBRztBQUNQLFVBQUksSUFBSSxDQUFDLFdBQVcsRUFBRTtBQUNwQixZQUFJLENBQUMsV0FBVyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUM7T0FDbkM7S0FDRjs7O1NBL0JrQixNQUFNOzs7cUJBQU4sTUFBTTs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O3FCQ0FMLFNBQVM7Ozs7NEJBQ1YsZUFBZTs7MkJBQ2YsZ0JBQWdCOztzQkFDbEIsUUFBUTs7OztJQUVOLE1BQU07QUFDYixXQURPLE1BQU0sR0FDVjswQkFESSxNQUFNOztBQUV2QixRQUFJLENBQUMsTUFBTSxHQUFHLEVBQUU7QUFDaEIsUUFBSSxDQUFDLFNBQVMsR0FBRyxFQUFFO0FBQ25CLFFBQUksQ0FBQyxRQUFRLEdBQUcsSUFBSTtHQUNyQjs7OztlQUxrQixNQUFNOztXQVFYLHVCQUFDLE9BQU8sRUFBRTtBQUN0QixVQUFJLENBQUMsUUFBUSxHQUFHLElBQUksUUFBUSxDQUFDLE9BQU8sQ0FBQztBQUNyQyxVQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDO0tBQ25DOzs7V0FFVzs7O1VBQUMsSUFBSSx5REFBRyxFQUFFO1VBQUUsRUFBRSx5REFBRzs7Ozs7Ozs7T0FBYztVQUNyQyxHQUFHLEVBT0QsR0FBRzs7OztBQVBMLGVBQUcsR0FBRztBQUNSLHFCQUFPLEVBQUUsMEJBQVE7YUFDbEI7O0FBRUQsZ0JBQUksQ0FBQyxhQUFhLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQzs7Ozs0Q0FHYixFQUFFLEVBQUU7OztBQUFoQixlQUFHOztBQUVQLGtCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUNqQixrQkFBSSxFQUFFLFNBQVM7QUFDZixtQkFBSyxFQUFFLElBQUk7QUFDWCxvQkFBTSxFQUFFLEdBQUc7YUFDWixDQUFDOzs7Ozs7OztBQUVGLGtCQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUNqQixrQkFBSSxFQUFFLE9BQU87QUFDYixtQkFBSyxFQUFFLElBQUk7QUFDWCxvQkFBTSxFQUFFLG1CQUFVLEtBQUssZ0JBQUc7YUFDM0IsQ0FBQzs7Ozs7O0FBR0YsZ0JBQUksSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0FBQzlCLG9CQUFNLENBQUMsTUFBTSxDQUFDLEdBQUcsRUFBRTtBQUNqQix3QkFBUSxFQUFFLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTTtlQUMvQixDQUFDO2FBQ0g7O0FBRUQsZUFBRyxDQUFDLFNBQVMsR0FBRyxJQUFJLElBQUksRUFBRTs7QUFFMUIsOEJBQUssTUFBTSxDQUFDLEdBQUcsQ0FBQzs7O0FBR2hCLGdCQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUM7Ozs7Ozs7O0tBRXhCOzs7Ozs7V0FJcUIseUJBQUMsR0FBRyxFQUFFLEVBQUU7VUFFdEIsR0FBRyxFQUdELEdBQUc7Ozs7OzRDQUpFLEdBQUcsQ0FBQyxPQUFPLEVBQUU7Ozs7Ozs7Ozs0Q0FDUixHQUFHLENBQUMsSUFBSSxFQUFFOzs7QUFBdEIsZUFBRzs7OzRDQUdXLEVBQUUsQ0FBQyxHQUFHLENBQUM7OztBQUFuQixlQUFHOztBQUNQLGdCQUFJLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQzs7Ozs7Ozs7QUFFbEIsZ0JBQUksQ0FBQyxNQUFNLGdCQUFHOzs7Ozs7O0FBR2xCLGVBQUcsQ0FBQyxLQUFLLEVBQUU7Ozs7Ozs7S0FDWjs7O1dBRVEsa0JBQUMsU0FBUyxFQUFFO0FBQ25CLFVBQUksQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQztLQUNqQzs7O1dBRU0sZ0JBQUMsU0FBUyxFQUFFO0FBQ2pCLFVBQUksQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLG1CQUFVLEtBQUssQ0FBQyxTQUFTLENBQUMsQ0FBQztLQUNoRDs7O1dBRVksd0JBQUc7QUFDZCxVQUFJLFFBQVEsR0FBRyxJQUFJLENBQUMsU0FBUyxDQUFDLElBQUksQ0FBQyxXQUFDO2VBQUksQ0FBQyxDQUFDLFlBQVksRUFBRTtPQUFBLENBQUM7QUFDekQsVUFBSSxRQUFRLEdBQUcsS0FBSzs7Ozs7O0FBQ3BCLDZCQUFnQixJQUFJLENBQUMsTUFBTSw4SEFBRTtjQUFwQixHQUFHOztBQUNWLGNBQUksR0FBRyxDQUFDLElBQUksS0FBSyxPQUFPLEVBQUU7QUFDeEIsb0JBQVEsR0FBRyxJQUFJO0FBQ2Ysa0JBQUs7V0FDTjtTQUNGOzs7Ozs7Ozs7Ozs7Ozs7O0FBQ0QsYUFBTyxRQUFRLElBQUksUUFBUTtLQUM1Qjs7O1dBRU8sbUJBQUc7O0FBRVQsVUFBSSxJQUFJLENBQUMsWUFBWSxFQUFFLEVBQUU7QUFDdkIsY0FBTSxJQUFJLHFCQUFPLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO09BQ3BDO0FBQ0QsYUFBTyxJQUFJLENBQUMsTUFBTTtLQUNuQjs7O1NBN0ZrQixNQUFNOzs7cUJBQU4sTUFBTTs7SUFnR3JCLFFBQVE7QUFDQSxXQURSLFFBQVEsQ0FDQyxPQUFPLEVBQUU7MEJBRGxCLFFBQVE7O0FBRVYsUUFBSSxDQUFDLE1BQU0sR0FBRztBQUNaLFdBQUssRUFBRSxDQUFDO0FBQ1IsYUFBTyxFQUFFLENBQUM7QUFDVixXQUFLLEVBQUUsQ0FBQztBQUNSLGFBQU8sRUFBRSxPQUFPO0tBQ2pCO0FBQ0QsUUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJO0dBQ3RCOztlQVRHLFFBQVE7O1dBV0osaUJBQUMsU0FBUyxFQUFFO0FBQ2xCLFVBQUksU0FBUyxFQUFFO0FBQ2IsWUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLEVBQUUsSUFBSSxDQUFDO09BQzFCO0FBQ0QsVUFBSSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUU7QUFDckIsVUFBSSxDQUFDLE1BQU0sQ0FBQyxLQUFLLEVBQUU7S0FDcEI7OztXQUVLLGVBQUMsU0FBUyxFQUFFOztBQUVoQixVQUFJLElBQUksQ0FBQyxTQUFTLENBQUMsSUFBSSxDQUFDLFNBQVMsQ0FBQyxLQUFLLElBQUksQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLEVBQUU7QUFDaEUsWUFBSSxTQUFTLElBQUksU0FBUyxLQUFLLEVBQUUsSUFBSSxTQUFTLEtBQUssRUFBRSxFQUFFO0FBQ3JELGNBQUksQ0FBQyxHQUFHLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQztBQUMxQixjQUFJLENBQUMsU0FBUyxHQUFHLFNBQVM7U0FDM0I7T0FDRjtBQUNELFVBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0FBQ25CLFVBQUksQ0FBQyxNQUFNLENBQUMsS0FBSyxFQUFFO0tBQ3BCOzs7V0FFRyxhQUFDLFNBQVMsRUFBRSxTQUFTLDBDQUEwQztBQUNqRSxVQUFJLEdBQUcsR0FBRztBQUNSLGVBQU8sRUFBRSxTQUFTO0FBQ2xCLGVBQU8sRUFBRSxJQUFJLENBQUMsTUFBTSxDQUFDLE9BQU87QUFDNUIsZUFBTyxFQUFFLFNBQVM7QUFDbEIsaUJBQVMsRUFBRSxJQUFJLElBQUksRUFBRTtPQUN0QjtBQUNELHdCQUFLLE1BQU0sQ0FBQyxHQUFHLENBQUM7S0FDakI7OztXQUVZLHdCQUFHO0FBQ2QsYUFBTyxJQUFJLENBQUMsTUFBTSxDQUFDLEtBQUs7S0FDekI7OztTQTNDRyxRQUFROzs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7SUNyR08sUUFBUTtXQUFSLFFBQVE7MEJBQVIsUUFBUTs7O2VBQVIsUUFBUTs7V0FDWixpQkFBQyxJQUFJLEVBQUUsR0FBRyxFQUFFLFVBQVUsRUFBRTtBQUNyQyxVQUFJLFVBQVUsS0FBSyxTQUFTLEVBQUU7QUFBRSxrQkFBVSxHQUFHLEVBQUU7T0FBRTtBQUNqRCxVQUFJLFNBQVMsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQztBQUM5QixVQUFJLEtBQUssR0FBRyxDQUFDO0FBQ2IsVUFBSSxHQUFHLEdBQUcsRUFBRTtBQUNaLFdBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxTQUFTLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO0FBQ3pDLFlBQUksQ0FBQyxHQUFHLE1BQU0sQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLENBQUM7QUFDNUIsWUFBSSxDQUFDLENBQUMsTUFBTSxHQUFHLENBQUMsRUFBRSxLQUFLLEVBQUUsTUFDcEIsS0FBSyxJQUFJLENBQUM7QUFDZixZQUFJLEtBQUssR0FBRyxHQUFHLEVBQUU7QUFDZixpQkFBTyxHQUFHLEdBQUcsVUFBVTtTQUN4QjtBQUNELFdBQUcsSUFBSSxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQztPQUN0QjtBQUNELGFBQU8sSUFBSTtLQUNaOzs7U0FoQmtCLFFBQVE7OztxQkFBUixRQUFROzs7Ozs7Ozs7Ozs7Ozs7OzRCQ0FOLGVBQWU7OzJCQUNoQixjQUFjOztBQUU3QixJQUFNLElBQUksR0FBRyxJQUFJLG1CQUFNLFVBQVUsQ0FBQyxNQUFNLEVBQUUsRUFBQyxZQUFZLEVBQUUsT0FBTyxFQUFDLENBQUM7O0FBQ2xFLElBQU0sT0FBTyxHQUFHLElBQUksbUJBQU0sVUFBVSxDQUFDLFNBQVMsRUFBRSxFQUFDLFlBQVksRUFBRSxPQUFPLEVBQUMsQ0FBQzs7QUFDeEUsSUFBTSxXQUFXLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsYUFBYSxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOzs7QUFFaEYsSUFBTSxPQUFPLEdBQUcsSUFBSSxtQkFBTSxVQUFVLENBQUMsU0FBUyxFQUFFLEVBQUMsWUFBWSxFQUFFLE9BQU8sRUFBQyxDQUFDOzs7QUFFL0UsSUFBSSxxQkFBTyxRQUFRLEVBQUU7QUFDbkIsdUJBQU8sT0FBTyxDQUFDLFNBQVMsRUFBRSxZQUFNO0FBQzlCLFdBQU8sT0FBTyxDQUFDLElBQUksRUFBRTtHQUN0QixDQUFDO0NBQ0g7O0FBRUQsSUFBSSxxQkFBTyxRQUFRLEVBQUU7QUFDbkIsdUJBQU8sU0FBUyxDQUFDLFNBQVMsQ0FBQyIsImZpbGUiOiIvYXBwLmpzIiwic291cmNlc0NvbnRlbnQiOlsiLy8gV2ViQXBwLmNvbm5lY3RIYW5kbGVycy51c2UoJy91cGxvYWQnLCAocmVxLCByZXMsIG5leHQpID0+IHtcclxuLy8gICByZXMud3JpdGVIZWFkKDIwMCk7XHJcbi8vICAgcmVzLmVuZChgSGVsbG8gd29ybGQgZnJvbTogJHtNZXRlb3IucmVsZWFzZX1gKTtcclxuLy8gfSk7XHJcblxyXG5pbXBvcnQgZnMgZnJvbSAnZnMnO1xyXG5pbXBvcnQgdW5pcWlkIGZyb20gJ3VuaXFpZCc7XHJcblxyXG4vLyBSZXF1aXJlcyBtdWx0aXBhcnR5IFxyXG5pbXBvcnQgbXVsdGlwYXJ0eSBmcm9tICdjb25uZWN0LW11bHRpcGFydHknO1xyXG5pbXBvcnQge1xyXG4gIFVwbG9hZHNcclxufSBmcm9tICcuLi8uLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb25zJztcclxubGV0IG11bHRpcGFydHlNaWRkbGV3YXJlID0gbXVsdGlwYXJ0eSgpO1xyXG5cclxuY29uc3Qgcm91dGUgPSAnL3VwbG9hZC9pbWFnZSc7XHJcblxyXG4vLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIGZ1Yy51cGxvYWRGaWxlICk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCBtdWx0aXBhcnR5TWlkZGxld2FyZSk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCAocmVxLCByZXNwKSA9PiB7XHJcbiAgLy8gZG9uJ3QgZm9yZ2V0IHRvIGRlbGV0ZSBhbGwgcmVxLmZpbGVzIHdoZW4gZG9uZVxyXG5cclxuICBjb25zdCByZWFkZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLnJlYWRGaWxlKTtcclxuICBjb25zdCB3cml0ZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLndyaXRlRmlsZSk7XHJcbiAgY29uc3QgdXBsb2FkSWQgPSB1bmlxaWQoKTtcclxuXHJcbiAgZm9yIChsZXQgZmlsZSBvZiByZXEuZmlsZXMuZmlsZSkge1xyXG4gICAgY29uc3QgZGF0YSA9IHJlYWRlcihmaWxlLnBhdGgpO1xyXG4gICAgLy8g44OV44Kh44Kk44Or5ZCN44Gu6YeN6KSH44KS6YG/44GR44KL44Gf44KB44CB5LiA5oSP44Gu44OV44Kh44Kk44Or5ZCN44KS5L2c5oiQ44GZ44KLXHJcbiAgICAvLyDmpb3lpKnjga7jg5XjgqHjgqTjg6vlkI3mloflrZfmlbDliLbpmZAyMOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IGZpbGVuYW1lID0gYCR7dW5pcWlkKCl9LmpwZ2BcclxuXHJcbiAgICAvLyBzZXQgdGhlIGNvcnJlY3QgcGF0aCBmb3IgdGhlIGZpbGUgbm90IHRoZSB0ZW1wb3Jhcnkgb25lIGZyb20gdGhlIEFQSTpcclxuICAgIGxldCBzYXZlUGF0aCA9IHJlcS5ib2R5LmltYWdlZGlyICsgJy8nICsgZmlsZW5hbWU7XHJcblxyXG4gICAgLy8gY29weSB0aGUgZGF0YSBmcm9tIHRoZSByZXEuZmlsZXMuZmlsZS5wYXRoIGFuZCBwYXN0ZSBpdCB0byBmaWxlLnBhdGhcclxuXHJcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nntZDmnpzjgpLoqJjpjLLjgZnjgotcclxuICAgIGxldCBkb2MgPSB7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgICAgY2xpZW50RmlsZU5hbWU6IGZpbGUubmFtZSxcclxuICAgICAgdXBsb2FkZWRGaWxlTmFtZTogZmlsZW5hbWVcclxuICAgIH07XHJcbiAgICBcclxuICAgIHRyeXtcclxuICAgICAgd3JpdGVyKHNhdmVQYXRoLCBkYXRhKTtcclxuICAgIH1cclxuICAgIGNhdGNoKGVycil7XHJcbiAgICAgIGRvYy5lcnJvciA9IGVycjtcclxuICAgIH1cclxuICAgIFVwbG9hZHMuaW5zZXJ0KGRvYyk7XHJcblxyXG4gICAgZGVsZXRlIGZpbGU7XHJcblxyXG4gIH07XHJcbiAgcmVzcC53cml0ZUhlYWQoMjAwKTtcclxuICByZXNwLmVuZChKU09OLnN0cmluZ2lmeSh7XHJcbiAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICBzYXZlRGlyOiByZXEuYm9keS5pbWFnZWRpclxyXG4gIH0pKTtcclxuXHJcbn0pOyIsImltcG9ydCBjcnlwdG8gZnJvbSAnY3J5cHRvJ1xyXG5cclxuaW1wb3J0IHsgTWV0ZW9yIH0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCdcclxuaW1wb3J0IFJlcG9ydCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIEdyb3VwLFxyXG4gIEdyb3VwRmFjdG9yeVxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi9ncm91cHMnXHJcbmltcG9ydCB7XHJcbiAgRmlsdGVyXHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb2xsZWN0aW9uL2ZpbHRlcnMnXHJcblxyXG5sZXQgdGFnID0gJ2N1YmVtaWcnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lm1pZ3JhdGVgXSAoY29uZmlnKSB7XHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgLy8gc2V0dXAgZ3JvdXBcclxuICAgIC8vXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBGaWx0ZXIoY29uZmlnLnNyY0ZpbHRlcklkKVxyXG4gICAgLy8gbGV0IHBsdWcgPSBncm91cC5nZXRQbHVnKCk7XHJcblxyXG4gICAgLy8gY2hlY2tpbmcgY29ubmVjdGlvblxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgdGVzdFF1ZXJ5ID0gJ1NIT1cgREFUQUJBU0VTJ1xyXG5cclxuICAgIGxldCBkc3REYiA9IG5ldyBNeVNRTChjb25maWcuZHN0LmNyZWQpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKCdDb25uZWN0IHRvIERlc3RpbmF0aW9uJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5KHRlc3RRdWVyeSlcclxuICAgICAgfSlcclxuXHJcbiAgICAvLyBwcm9jZXNzIGZvciBlYWNoIG1lbWJlcnNcclxuICAgIC8vXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKCdTZWxlY3QgbG9vcCBpbiBzb3VyY2UnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgIG1vYmlsZU51bGw6IGFzeW5jIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgLy8gLy8g5YCk44KS5pW055CGXHJcbiAgICAgICAgICAgIC8vIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgIC8vICAgaWYgKHJlY29yZFtrZXldID09PSBudWxsKTtcclxuICAgICAgICAgICAgLy8gICBlbHNlIGlmIChyZWNvcmRba2V5XS5jb25zdHJ1Y3Rvci5uYW1lID09PSAnRGF0ZScpIHtcclxuICAgICAgICAgICAgLy8gICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgICAgICAvLyAgICAgcmVjb3JkW2tleV0gPSBNeVNRTC5mb3JtYXREYXRlKHJlY29yZFtrZXldKTtcclxuICAgICAgICAgICAgLy8gICAgIHJlY29yZFtrZXldID0gYFwiJHtyZWNvcmRba2V5XX1cImA7XHJcbiAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAvLyB9XHJcblxyXG4gICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXIg44Gr5L+d5a2YXHJcblxyXG4gICAgICAgICAgICBsZXQgc3FsID0gYFxyXG5cclxuICAgICAgICAgICAgICAgIElOU0VSVCBkdGJfY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICggXFxgY3VzdG9tZXJfaWRcXGAsIFxcYHN0YXR1c1xcYCwgXFxgc2V4XFxgLCBcXGBqb2JcXGAsIFxcYGNvdW50cnlfaWRcXGAsIFxcYHByZWZcXGAsIFxcYG5hbWUwMVxcYCwgXFxgbmFtZTAyXFxgLCBcXGBrYW5hMDFcXGAsIFxcYGthbmEwMlxcYCwgXFxgY29tcGFueV9uYW1lXFxgLCBcXGB6aXAwMVxcYCwgXFxgemlwMDJcXGAsIFxcYHppcGNvZGVcXGAsIFxcYGFkZHIwMVxcYCwgXFxgYWRkcjAyXFxgLCBcXGBlbWFpbFxcYCwgXFxgdGVsMDFcXGAsIFxcYHRlbDAyXFxgLCBcXGB0ZWwwM1xcYCwgXFxgZmF4MDFcXGAsIFxcYGZheDAyXFxgLCBcXGBmYXgwM1xcYCwgXFxgYmlydGhcXGAsIFxcYHBhc3N3b3JkXFxgLCBcXGBzYWx0XFxgLCBcXGBzZWNyZXRfa2V5XFxgLCBcXGBmaXJzdF9idXlfZGF0ZVxcYCwgXFxgbGFzdF9idXlfZGF0ZVxcYCwgXFxgYnV5X3RpbWVzXFxgLCBcXGBidXlfdG90YWxcXGAsIFxcYG5vdGVcXGAsIFxcYGNyZWF0ZV9kYXRlXFxgLCBcXGB1cGRhdGVfZGF0ZVxcYCwgXFxgZGVsX2ZsZ1xcYCApXHJcblxyXG4gICAgICAgICAgICAgICAgVkFMVUVTKCAke3JlY29yZC5jdXN0b21lcl9pZH0gLCAke3JlY29yZC5zdGF0dXN9ICwgJHtyZWNvcmQuc2V4fSAsICR7cmVjb3JkLmpvYn0gLCAke3JlY29yZC5jb3VudHJ5X2lkfSAsICR7cmVjb3JkLnByZWZ9ICwgJHtyZWNvcmQubmFtZTAxfSAsICR7cmVjb3JkLm5hbWUwMn0gLCAke3JlY29yZC5rYW5hMDF9ICwgJHtyZWNvcmQua2FuYTAyfSAsICR7cmVjb3JkLmNvbXBhbnlfbmFtZX0gLCAke3JlY29yZC56aXAwMX0gLCAke3JlY29yZC56aXAwMn0gLCAke3JlY29yZC56aXBjb2RlfSAsICR7cmVjb3JkLmFkZHIwMX0gLCAke3JlY29yZC5hZGRyMDJ9ICwgJHtyZWNvcmQuZW1haWx9ICwgJHtyZWNvcmQudGVsMDF9ICwgJHtyZWNvcmQudGVsMDJ9ICwgJHtyZWNvcmQudGVsMDN9ICwgJHtyZWNvcmQuZmF4MDF9ICwgJHtyZWNvcmQuZmF4MDJ9ICwgJHtyZWNvcmQuZmF4MDN9ICwgJHtyZWNvcmQuYmlydGh9ICwgJHtyZWNvcmQucGFzc3dvcmR9ICwgJHtyZWNvcmQuc2FsdH0gLCAke3JlY29yZC5zZWNyZXRfa2V5fSAsICR7cmVjb3JkLmZpcnN0X2J1eV9kYXRlfSAsICR7cmVjb3JkLmxhc3RfYnV5X2RhdGV9ICwgJHtyZWNvcmQuYnV5X3RpbWVzfSAsICR7cmVjb3JkLmJ1eV90b3RhbH0gLCAke3JlY29yZC5ub3RlfSAsICR7cmVjb3JkLmNyZWF0ZV9kYXRlfSAsICR7cmVjb3JkLnVwZGF0ZV9kYXRlfSAsICR7cmVjb3JkLmRlbF9mbGd9IClcclxuICAgICAgICAgICAgICAgIFxyXG4gICAgICAgICAgICAgICAgYFxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdkdGJfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVjb3JkLnN0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgc2V4OiByZWNvcmQuc2V4LFxyXG4gICAgICAgICAgICAgICAgICBqb2I6IHJlY29yZC5qb2IsXHJcbiAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgbmFtZTAxOiByZWNvcmQubmFtZTAxLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAga2FuYTAyOiByZWNvcmQua2FuYTAyLFxyXG4gICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgIHppcDAyOiByZWNvcmQuemlwMDIsXHJcbiAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMjogcmVjb3JkLmFkZHIwMixcclxuICAgICAgICAgICAgICAgICAgZW1haWw6IHJlY29yZC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgdGVsMDE6IHJlY29yZC50ZWwwMSxcclxuICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgZmF4MDE6IHJlY29yZC5mYXgwMSxcclxuICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgYmlydGg6IHJlY29yZC5iaXJ0aCxcclxuICAgICAgICAgICAgICAgICAgcGFzc3dvcmQ6IHJlY29yZC5wYXNzd29yZCxcclxuICAgICAgICAgICAgICAgICAgc2FsdDogcmVjb3JkLnNhbHQsXHJcbiAgICAgICAgICAgICAgICAgIHNlY3JldF9rZXk6IHJlY29yZC5zZWNyZXRfa2V5LFxyXG4gICAgICAgICAgICAgICAgICBmaXJzdF9idXlfZGF0ZTogcmVjb3JkLmZpcnN0X2J1eV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBsYXN0X2J1eV9kYXRlOiByZWNvcmQubGFzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgYnV5X3RpbWVzOiByZWNvcmQuYnV5X3RpbWVzLFxyXG4gICAgICAgICAgICAgICAgICBidXlfdG90YWw6IHJlY29yZC5idXlfdG90YWwsXHJcbiAgICAgICAgICAgICAgICAgIG5vdGU6IHJlY29yZC5ub3RlLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyX2FkZHJlc3NcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdkdGJfY3VzdG9tZXJfYWRkcmVzcycsIHtcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfYWRkcmVzc19pZDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgY291bnRyeV9pZDogcmVjb3JkLmNvdW50cnlfaWQsXHJcbiAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgIG5hbWUwMjogcmVjb3JkLm5hbWUwMixcclxuICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgIGNvbXBhbnlfbmFtZTogcmVjb3JkLmNvbXBhbnlfbmFtZSxcclxuICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgemlwY29kZTogcmVjb3JkLnppcGNvZGUsXHJcbiAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMjogcmVjb3JkLnRlbDAyLFxyXG4gICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMjogcmVjb3JkLmZheDAyLFxyXG4gICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICBjcmVhdGVfZGF0ZTogcmVjb3JkLmNyZWF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgLy8g44Oh44Or44Oe44Ks44OX44Op44Kw44Kk44OzIHBsZ19tYWlsbWFnYV9jdXN0b21lclxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgJ3BsZ19tYWlsbWFnYV9jdXN0b21lcicsIHtcclxuICAgICAgICAgICAgICAgICAgaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2lkOiByZWNvcmQuY3VzdG9tZXJfaWQsXHJcbiAgICAgICAgICAgICAgICAgIG1haWxtYWdhX2ZsZzogcmVjb3JkLm1haWxtYWdhX2ZsZyxcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgZGVsX2ZsZzogcmVjb3JkLmRlbF9mbGdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpXHJcbiAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgIC8vIOOCr+ODvOODneODs+eZuuihjO+8iEVDQ1VCRTLjga7jg53jgqTjg7Pjg4jpgoTlhYPvvIlcclxuXHJcbiAgICAgICAgICAgIGxldCBjb3Vwb25DZCA9IGNyeXB0by5yYW5kb21CeXRlcyg4KS50b1N0cmluZygnYmFzZTY0Jykuc3Vic3RyaW5nKDAsIDExKVxyXG5cclxuICAgICAgICAgICAgbGV0IGNvdXBvbk5hbWUgPSBgJHtyZWNvcmQubmFtZTAxfSAke3JlY29yZC5uYW1lMDJ9IOanmCDjgZTlhKrlvoXjgq/jg7zjg53jg7Mg5Lya5ZOh55Wq5Y+3OiR7cmVjb3JkLmN1c3RvbWVyX2lkfWBcclxuXHJcbiAgICAgICAgICAgIGxldCBkaXNjb3VudFByaWNlID0gcmVjb3JkLnBvaW50ICsgNTAwXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICdwbGdfY291cG9uJywge1xyXG4gICAgICAgICAgICAgICAgICBjb3Vwb25faWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl9jZDogY291cG9uQ2QsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl90eXBlOiAzLCAvLyDlhajllYblk4FcclxuICAgICAgICAgICAgICAgICAgY291cG9uX25hbWU6IGNvdXBvbk5hbWUsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3R5cGU6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGNvdXBvbl91c2VfdGltZTogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX3JlbGVhc2U6IDEsXHJcbiAgICAgICAgICAgICAgICAgIGRpc2NvdW50X3ByaWNlOiBkaXNjb3VudFByaWNlLFxyXG4gICAgICAgICAgICAgICAgICBkaXNjb3VudF9yYXRlOiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBlbmFibGVfZmxhZzogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX21lbWJlcjogMSxcclxuICAgICAgICAgICAgICAgICAgY291cG9uX2xvd2VyX2xpbWl0OiBudWxsLFxyXG4gICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICBhdmFpbGFibGVfZnJvbV9kYXRlOiAnMjAxOC0wNC0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgIGF2YWlsYWJsZV90b19kYXRlOiAnMjAxOS0wNS0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IDBcclxuICAgICAgICAgICAgICAgIH0sIHtcclxuICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKScsXHJcbiAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgIH1cclxuICAgICAgICApXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIGFzeW5jICdjdWJlbWlnLnNlcnZlckNoZWNrJyAocHJvZmlsZSkge1xyXG4gICAgbGV0IGRiID0gbmV3IE15U1FMKHByb2ZpbGUpXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgZGIucXVlcnkoJ1NIT1cgREFUQUJBU0VTJylcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG59KVxyXG4iLCJpbXBvcnQgeyBNb25nb0NvbGxlY3Rpb24gfSBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbW9uZ28nXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdqbGluZS5jb2xsZWN0aW9uJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5maW5kYF0gKHBsdWcsIHF1ZXJ5ID0ge30sIHByb2plY3Rpb24gPSB7fSkge1xyXG4gICAgbGV0IGNvbGwgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsIHBsdWcuY29sbGVjdGlvbilcclxuICAgIGxldCByZXMgPSBhd2FpdCBjb2xsLmZpbmQocXVlcnksIHtwcm9qZWN0aW9uOiBwcm9qZWN0aW9ufSkudG9BcnJheSgpXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uYWdncmVnYXRlYF0gKHBsdWcsIHF1ZXJ5ID0ge30pIHtcclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnLCBwbHVnLmNvbGxlY3Rpb24pXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgY29sbC5hZ2dyZWdhdGUocXVlcnkpLnRvQXJyYXkoKVxyXG4gICAgcmV0dXJuIHJlc1xyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi8uLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICdqbGluZS5pdGVtcydcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgb7jgZnjgIJcclxuICAgKiBAcGFyYW1cclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5zZXRJbWFnZWBdIChwbHVnLCB1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwpIHtcclxuICAgIGxldCBpdGVtY29uID0gbmV3IEl0ZW1Db250cm9sbGVyKClcclxuICAgIGF3YWl0IGl0ZW1jb24uaW5pdChwbHVnKVxyXG4gICAgbGV0IHVwbG9hZGVkID0gYXdhaXQgaXRlbWNvbi5zZXRJbWFnZSh1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSwgY2xhc3MyKVxyXG4gICAgcmV0dXJuIHVwbG9hZGVkXHJcbiAgfSxcclxuXHJcbiAgLyoqXHJcbiAgICog44Ki44Kk44OG44Og5oOF5aCx44OH44O844K/44OZ44O844K544Gu55S75YOP55m76Yyy44KS5YmK6Zmk44GZ44KL77yI55S75YOP6Ieq5L2T44Gv5YmK6Zmk44GX44Gq44GE77yJXHJcbiAgICovXHJcbiAgYXN5bmMgW2Ake3RhZ30uY2xlYW5JbWFnZWBdIChwbHVnLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgbGV0IGl0ZW1jb24gPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpXHJcbiAgICBhd2FpdCBpdGVtY29uLmNsZWFuSW1hZ2UobW9kZWwsIGNsYXNzMSwgY2xhc3MyKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQge1xyXG4gIEN1YmUzQXBpXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2N1YmUzYXBpJ1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vaW1wb3J0cy91dGlsL215c3FsJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtNZXRlb3J9IGZyb20gJ21ldGVvci9tZXRlb3InXHJcblxyXG5sZXQgdGFnID0gJ2N1YmUnXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5Zyo5bqr5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZVN0b2NrYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgIGxldCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgIGxldCB0YXJnZXREQiA9IG5ldyBNeVNRTChjb25maWcuY3ViZTNEQilcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn5Zyo5bqr44Gu5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcblxyXG4gICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcbiAgICAgICAgICAgIGxldCBxdWFudGl0eSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldFN0b2NrKGl0ZW0uX2lkKVxyXG4gICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5KVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx55m76Yyy44Go5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmV4aGliSXRlbWBdIChjb25maWcpIHtcclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpXHJcbiAgICBsZXQgdGFyZ2V0REIgPSBuZXcgTXlTUUwoY29uZmlnLmN1YmUzREIpXHJcbiAgICBsZXQgYXBpID0gbmV3IEN1YmUzQXBpKHRhcmdldERCKVxyXG5cclxuICAgIGxldCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICBhd2FpdCBpdGVtQ29udHJvbGxlci5pbml0KGNvbmZpZy5pdGVtc0RCKVxyXG5cclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0VDQ1VCRTPjgbjjga7llYblk4HnmbvpjLInLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICdJTlNFUlQnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG4gICAgICAgICAgICBsZXQgY29sID0gY29udGV4dC5jb2xsZWN0aW9uXHJcblxyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCBjdWJlSXRlbSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtQ3ViZTMoY29uZmlnLmNyZWF0b3JfaWQsIGl0ZW0pXHJcblxyXG4gICAgICAgICAgICAgIGxldCBpbnNlcnRSZXMgPSBhd2FpdCBhcGkucHJvZHVjdENyZWF0ZShjdWJlSXRlbSlcclxuXHJcbiAgICAgICAgICAgICAgLy8gaXRlbSDjg4fjg7zjgr/jg5njg7zjgrnjgbjjga7nmbvpjLJcclxuICAgICAgICAgICAgICBhd2FpdCBjb2wudXBkYXRlKHtcclxuICAgICAgICAgICAgICAgIF9pZDogaXRlbS5faWRcclxuICAgICAgICAgICAgICB9LCB7XHJcbiAgICAgICAgICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICAgICAgICAgICdtYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfaWQnOiBpbnNlcnRSZXMucmVzLnByb2R1Y3RfaWQsXHJcbiAgICAgICAgICAgICAgICAgICdtYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQnOiBpbnNlcnRSZXMucmVzLnByb2R1Y3RfY2xhc3NfaWQsXHJcbiAgICAgICAgICAgICAgICAgICdtYWxsLnNoYXJha3VTaG9wLnByb2R1Y3Rfc3RvY2tfaWQnOiBpbnNlcnRSZXMucmVzLnByb2R1Y3Rfc3RvY2tfaWRcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9KVxyXG5cclxuICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdFQ0NVQkUz5ZWG5ZOB5oOF5aCx44Gu5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCBmaWx0ZXIuZm9yZWFjaCh7XHJcbiAgICAgICAgICAnVVBEQVRFJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IGNvbCA9IGNvbnRleHQuY29sbGVjdGlvblxyXG5cclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgY3ViZUl0ZW0gPSBhd2FpdCBpdGVtQ29udHJvbGxlci5jb252ZXJ0SXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKVxyXG5cclxuICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdEltYWdlVXBkYXRlKGN1YmVJdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VXBkYXRlKGN1YmVJdGVtKVxyXG4gICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VGFnVXBkYXRlKGN1YmVJdGVtKVxyXG5cclxuICAgICAgICAgICAgICBsZXQgcXVhbnRpdHkgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhpdGVtLl9pZClcclxuICAgICAgICAgICAgICBhd2FpdCBhcGkudXBkYXRlU3RvY2soaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByb2R1Y3RfY2xhc3NfaWQsIHF1YW50aXR5KVxyXG5cclxuICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgIH0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vaW1wb3J0cy91dGlsL3JlcG9ydCdcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2RiZmlsdGVyJ1xyXG5pbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSAnLi4vaW1wb3J0cy9zZXJ2aWNlL2l0ZW1zJ1xyXG5cclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgUGFja2V0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9wYWNrZXQnXHJcbmltcG9ydCBmc0V4dHJhIGZyb20gJ2ZzLWV4dHJhJ1xyXG5cclxuaW1wb3J0IGljb252IGZyb20gJ2ljb252LWxpdGUnXHJcbmltcG9ydCBhcmNoaXZlciBmcm9tICdhcmNoaXZlcidcclxuaW1wb3J0IGNzdiBmcm9tICdjc3YnXHJcblxyXG5jb25zdCB0YWcgPSAncm9ib3RpblBvc3RsYWJlbCdcclxuXHJcbmNvbnN0IE9SREVSX05PX1BSRUZJWCA9ICflj5fms6jnlarlj7fvvJonXHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8gUm9ib3QtaW5cclxuICAvLyDpgIHjgornirbjgavllYblk4HjgrPjg7zjg4njgpLoqJjovIlcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uYWRkSXRlbUNvZGVgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdSb2JvdC1pbiDpgIHjgornirbjgavllYblk4HjgrPjg7zjg4njgpLoqJjovIknLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9wb3N0bGFiZWxgXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuICAgICAgICB0cnkge1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih3b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIC8vIHdvcmtkaXIg44GM5rqW5YKZ44GV44KM44Gm44GE44Gf44KJ5a6f6KGM44GZ44KLXHJcblxyXG4gICAgICAgICAgLy8gY29uc3QgdyA9IGZzRXh0cmEuY3JlYXRlV3JpdGVTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJTYXZlZmlsZX1gKVxyXG5cclxuICAgICAgICAgIGxldCBvcmRlckNzdiA9IGF3YWl0IGZzRXh0cmEucmVhZEZpbGUoYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJDc3ZQcmVmaXh9LmNzdmApXHJcbiAgICAgICAgICBvcmRlckNzdiA9IGF3YWl0IGljb252LmRlY29kZShvcmRlckNzdiwgJ1NKSVMnKVxyXG4gICAgICAgICAgb3JkZXJDc3YgPSBhd2FpdCBpY29udi5lbmNvZGUob3JkZXJDc3YsICdVVEYtOCcpXHJcblxyXG4gICAgICAgICAgLy8gb3JkZXJDc3YucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC8vICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgLy8gICAucGlwZShjc3YucGFyc2Uoe1xyXG4gICAgICAgICAgLy8gICAgIGNvbHVtbnM6IHRydWVcclxuICAgICAgICAgIC8vICAgfSkpXHJcbiAgICAgICAgICAvLyAgIC5waXBlKGNzdi50cmFuc2Zvcm0oXHJcbiAgICAgICAgICAvLyAgICAgYXN5bmMgKHJlY09yZGVyLCBjYWxsYmFjaykgPT4ge1xyXG4gICAgICAgICAgLy8gICAgICAgbGV0IGVyciA9IG51bGxcclxuICAgICAgICAgIC8vICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAvLyDpgIHjgornirbjga7nqK7poZ7jgZTjgajjgavnubDjgorov5TjgZlcclxuICAgICAgICAgIGF3YWl0IGNvbmZpZy5wb3N0YWdlcy5mb3JFYWNoKFxyXG4gICAgICAgICAgICBhc3luYyBlID0+IHtcclxuICAgICAgICAgICAgICBjb25zb2xlLmxvZyhgY3N2UHJlZml4OiAke2UuY3N2UHJlZml4fWApXHJcbiAgICAgICAgICAgICAgLy8gYXdhaXQgZS5pZC5mb3JFYWNoKFxyXG4gICAgICAgICAgICAgIC8vICAgYXN5bmMgaWQgPT4ge1xyXG4gICAgICAgICAgICAgIC8vICAgICBjb25zb2xlLmxvZyhgJHtpZC5vcmRlcn06ICR7cmVjT3JkZXJbaWQub3JkZXJdfWApXHJcbiAgICAgICAgICAgICAgLy8gICB9XHJcbiAgICAgICAgICAgICAgLy8gKVxyXG4gICAgICAgICAgICAgIC8vIGNvbnNvbGUubG9nKGAke2NvbmZpZy5pdGVtQ29kZUNvbHVtbn06ICR7cmVjT3JkZXJbY29uZmlnLml0ZW1Db2RlQ29sdW1uXX1gKVxyXG5cclxuICAgICAgICAgICAgICAvLyDpgIHjgornirZDU1bjgpLplovjgY3jgIHphY3pgIHjgZTjgajjgavllYblk4HjgrPjg7zjg4njgpLoqJjovInjgZnjgotcclxuICAgICAgICAgICAgICBjb25zdCBwb3N0Q1NWID0gZnNFeHRyYS5jcmVhdGVSZWFkU3RyZWFtKGAke3dvcmtkaXJ9LyR7ZS5jc3ZQcmVmaXh9LmNzdmApXHJcbiAgICAgICAgICAgICAgcG9zdENTVi5waXBlKGljb252LmRlY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgICAgICAgLnBpcGUoaWNvbnYuZW5jb2RlU3RyZWFtKCdVVEYtOCcpKVxyXG4gICAgICAgICAgICAgICAgLnBpcGUoY3N2LnBhcnNlKHtcclxuICAgICAgICAgICAgICAgICAgY29sdW1uczogdHJ1ZVxyXG4gICAgICAgICAgICAgICAgfSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIClcclxuICAgICAgICAgIC8vICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIC8vICAgICAgICAgZXJyID0gZVxyXG4gICAgICAgICAgLy8gICAgICAgfVxyXG4gICAgICAgICAgLy8gICAgICAgY2FsbGJhY2soZXJyLCByZWNPcmRlcilcclxuICAgICAgICAgIC8vICAgICB9XHJcbiAgICAgICAgICAvLyAgICkpXHJcbiAgICAgICAgICAvLyAucGlwZShjc3Yuc3RyaW5naWZ5KHtoZWFkZXI6IHRydWV9KSlcclxuICAgICAgICAgIC8vIC5waXBlKGljb252LmRlY29kZVN0cmVhbSgnVVRGLTgnKSlcclxuICAgICAgICAgIC8vIC5waXBlKGljb252LmVuY29kZVN0cmVhbSgnU0pJUycpKVxyXG4gICAgICAgICAgLy8gLnBpcGUodylcclxuICAgICAgICB9XHJcbiAgICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcihg5q2j44GX44GE5L2c5qWt44OH44Kj44Os44Kv44OI44Oq44GM55So5oSP44GV44KM44Gm44GE44G+44Gb44KT44Gn44GX44Gf44CC5LiL6KiY44Gu44OV44Kp44Or44OA44G45Y+X5rOoQ1NW44CB6YCB44KK54q2Q1NW44KS44Kz44OU44O844GX44Gm44GP44Gg44GV44GE44CCXFxuWyR7d29ya2Rpcn1dYClcclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxubGV0IHRhZyA9ICd0b29sJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS50ZXN0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuXHJcbiAgICBjb25zdCBuZXdMb2NhbCA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHt9LCBhc3luYyAoZSkgPT4ge1xyXG4gICAgICB0aHJvdyBlXHJcbiAgICB9KVxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44OV44Kj44Or44K/44O844OG44K544OIJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIHJldHVybiBuZXdMb2NhbFxyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IGZzRXh0cmEgZnJvbSAnZnMtZXh0cmEnXHJcblxyXG5pbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0LXByb21pc2UnXHJcbmltcG9ydCBXb3dtYUFwaSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2Uvd293bWFBcGknXHJcbmltcG9ydCB1dGlsRXJyb3IgZnJvbSAnLi4vaW1wb3J0cy91dGlsL2Vycm9yJ1xyXG5cclxuY29uc3QgdGFnID0gJ3dvd21hJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIFdPV01BIOWVhuWTgeOBrumFjemAgeaWueazleOCkuioreWumuOBmeOCi1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS51cGRhdGVJdGVtLmRlbGl2ZXJ5TWV0aG9kYF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAnV293bWEhIOWVhuWTgeOBrumFjemAgeaWueazleOCkuioreWumuOBmeOCiycsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICAvL1xyXG4gICAgICAgIC8vIGpsaW5lX2VuZ2luZSDllYblk4Hjg4fjg7zjgr/jg5njg7zjgrnjgbjjga7mjqXntppcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyDllYblk4Hmg4XloLHjga7kvZzmiJBcclxuICAgICAgICBsZXQgY3VyID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICAgICAgW1xyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgICAgICAkYW5kOiBbXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6IHsgJGV4aXN0czogMSB9XHJcbiAgICAgICAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIC8vIOODhuOCueODiOaknOe0ouadoeS7tuioreWumlxyXG4gICAgICAgICAgICAgICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJ2drLTE2MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH0sXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJzEwMDA0OTQyJyAvLyBKSy0xMjBcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDU0MDInXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDc0MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICBdXHJcbiAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4HjgrPjg7zjg4njga7kuIDopqfjgpLkvZzjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRtYWxsLndvd21hLml0ZW1Db2RlJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyDlvpfjgonjgozjgZ/llYblk4HjgZTjgajjgatBUEnjg6rjgq/jgqjjgrnjg4jjgpLnmbrooYxcclxuICAgICAgICBsZXQgYXBpID0gbmV3IFdvd21hQXBpKGNvbmZpZy53b3dtYUFwaVBvc3QsIGNvbmZpZy5zaG9wSWQpXHJcbiAgICAgICAgYXdhaXQgcmVwb3J0LmZvckVhY2hPbkN1cnNvcihcclxuICAgICAgICAgIGN1cixcclxuICAgICAgICAgIGFzeW5jIGl0ZW0gPT4ge1xyXG4gICAgICAgICAgICBPYmplY3QuYXNzaWduKGl0ZW0sIGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtV293bWFDcmVhdGVEZWxpdmVyeU1ldGhvZChpdGVtLml0ZW1Db2RlKSlcclxuICAgICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgICBsZXQgcmVzID0gYXdhaXQgYXBpLnVwZGF0ZUl0ZW0oaXRlbSlcclxuICAgICAgICAgICAgICByZXR1cm4ge3JlcXVlc3RCb2R5OiBpdGVtLCByZXNwb25zZTogcmVzfVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih7cmVxdWVzdEJvZHk6IGl0ZW19LCB1dGlsRXJyb3IucGFyc2UoZSkpXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB44OH44O844K/44OZ44O844K55LiK44Gu5ZWG5ZOB44KS5YWs6ZaL44GZ44KLXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnVwZGF0ZUl0ZW0ub3BlbmBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ1dvd21hISDllYblk4Hjg4fjg7zjgr/jg5njg7zjgrnkuIrjga7llYblk4HjgpLlhazplovjgZnjgosnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgLy9cclxuICAgICAgICAvLyBqbGluZV9lbmdpbmUg5ZWG5ZOB44OH44O844K/44OZ44O844K544G444Gu5o6l57aaXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5ZWG5ZOB5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgbGV0IGN1ciA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFtcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRtYXRjaDoge1xyXG4gICAgICAgICAgICAgICAgJGFuZDogW1xyXG4gICAgICAgICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiB7ICRleGlzdHM6IDEgfVxyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAgIC8vIOODhuOCueODiOaknOe0ouadoeS7tuioreWumlxyXG4gICAgICAgICAgICAgICAgICAvLyB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgJG9yOiBbXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICB7XHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogJ2drLTE2MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIHtcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDU0MDInXHJcbiAgICAgICAgICAgICAgICAgIC8vICAgICAvLyB9LFxyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8ge1xyXG4gICAgICAgICAgICAgICAgICAvLyAgICAgLy8gICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDc0MydcclxuICAgICAgICAgICAgICAgICAgLy8gICAgIC8vIH1cclxuICAgICAgICAgICAgICAgICAgLy8gICBdXHJcbiAgICAgICAgICAgICAgICAgIC8vIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4HjgrPjg7zjg4njga7kuIDopqfjgpLkvZzjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRtYWxsLndvd21hLml0ZW1Db2RlJ1xyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICRwcm9qZWN0OiB7XHJcbiAgICAgICAgICAgICAgICBfaWQ6IDAsXHJcbiAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyDlvpfjgonjgozjgZ/llYblk4HjgZTjgajjgatBUEnjg6rjgq/jgqjjgrnjg4jjgpLnmbrooYxcclxuICAgICAgICBsZXQgYXBpID0gbmV3IFdvd21hQXBpKGNvbmZpZy53b3dtYUFwaVBvc3QsIGNvbmZpZy5zaG9wSWQpXHJcbiAgICAgICAgYXdhaXQgcmVwb3J0LmZvckVhY2hPbkN1cnNvcihcclxuICAgICAgICAgIGN1cixcclxuICAgICAgICAgIGFzeW5jIGl0ZW0gPT4ge1xyXG4gICAgICAgICAgICBpdGVtLnNhbGVTdGF0dXMgPSAxXHJcbiAgICAgICAgICAgIGl0ZW0ubGltaXRlZFBhc3N3ZCA9ICdOVUxMJ1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZXMgPSBhd2FpdCBhcGkudXBkYXRlSXRlbShpdGVtKVxyXG4gICAgICAgICAgICAgIHJldHVybiB7cmVxdWVzdEJvZHk6IGl0ZW0sIHJlc3BvbnNlOiByZXN9XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICB0aHJvdyBPYmplY3QuYXNzaWduKHtyZXF1ZXN0Qm9keTogaXRlbX0sIHV0aWxFcnJvci5wYXJzZShlKSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfSxcclxuXHJcbiAgLy9cclxuICAvLyBXT1dNQSDlnKjluqvmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30udXBkYXRlU3RvY2tgXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5Zyo5bqr5pu05pawJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vXHJcbiAgICAgICAgLy8g5Zyo5bqr5oOF5aCx44Gu5L2c5oiQXHJcbiAgICAgICAgY29uc3QgaXRlbUNvbnRyb2xsZXIgPSBuZXcgSXRlbUNvbnRyb2xsZXIoKVxyXG4gICAgICAgIGF3YWl0IGl0ZW1Db250cm9sbGVyLmluaXQoY29uZmlnLml0ZW1zREIpXHJcblxyXG4gICAgICAgIGxldCBjdXIgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5JdGVtcy5hZ2dyZWdhdGUoXHJcbiAgICAgICAgICBbXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAkbWF0Y2g6IHtcclxuICAgICAgICAgICAgICAgICRhbmQ6IFtcclxuICAgICAgICAgICAgICAgICAge1xyXG4gICAgICAgICAgICAgICAgICAgICdtYWxsLndvd21hLml0ZW1Db2RlJzogeyAkZXhpc3RzOiAxIH1cclxuICAgICAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgICAgICAvLyDjg4bjgrnjg4jmpJzntKLmnaHku7boqK3lrppcclxuICAgICAgICAgICAgICAgIC8vICAgLHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAkb3I6IFtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIHtcclxuICAgICAgICAgICAgICAgIC8vICAgICAgICAgJ21hbGwud293bWEuaXRlbUNvZGUnOiAnMTAwMDU0MDInXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAse1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICdnay0xNjMnXHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICB9XHJcbiAgICAgICAgICAgICAgICAvLyAgICAgICAse1xyXG4gICAgICAgICAgICAgICAgLy8gICAgICAgICAnbWFsbC53b3dtYS5pdGVtQ29kZSc6ICcxMDAwNDc0MydcclxuICAgICAgICAgICAgICAgIC8vICAgICAgIH1cclxuICAgICAgICAgICAgICAgIC8vICAgICBdXHJcbiAgICAgICAgICAgICAgICAvLyAgIH1cclxuICAgICAgICAgICAgICAgIF1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDphY3pgIHmlrnms5Xjga7pgZXjgYTjgpLnnIHjgY9cclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDoge1xyXG4gICAgICAgICAgICAgICAgICBpdGVtQ29kZTogJyRtYWxsLndvd21hLml0ZW1Db2RlJyxcclxuICAgICAgICAgICAgICAgICAgY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGU6ICckbWFsbC53b3dtYS5IQ2hvaWNlTmFtZScsXHJcbiAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogJyRtYWxsLndvd21hLlZDaG9pY2VOYW1lJ1xyXG4gICAgICAgICAgICAgICAgfSxcclxuICAgICAgICAgICAgICAgIGl0ZW06IHtcclxuICAgICAgICAgICAgICAgICAgJGZpcnN0OiAnJF9pZCdcclxuICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH0sXHJcbiAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAvLyDllYblk4Hjg5rjg7zjgrjjgZTjgajvvIjllYblk4HjgrPjg7zjg4nvvInjgavjgrDjg6vjg7zjg5fljJbjgZnjgotcclxuICAgICAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogJyRfaWQuaXRlbUNvZGUnLFxyXG4gICAgICAgICAgICAgICAgdmFyaWF0aW9uczoge1xyXG4gICAgICAgICAgICAgICAgICAkcHVzaDoge1xyXG4gICAgICAgICAgICAgICAgICAgIF9pZDogJyRpdGVtJyxcclxuICAgICAgICAgICAgICAgICAgICBjaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZTogJyRfaWQuY2hvaWNlc1N0b2NrSG9yaXpvbnRhbENvZGUnLFxyXG4gICAgICAgICAgICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogJyRfaWQuY2hvaWNlc1N0b2NrVmVydGljYWxDb2RlJ1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9LFxyXG4gICAgICAgICAgICB7XHJcbiAgICAgICAgICAgICAgJHByb2plY3Q6IHtcclxuICAgICAgICAgICAgICAgIF9pZDogMCxcclxuICAgICAgICAgICAgICAgIGl0ZW1Db2RlOiAnJF9pZCcsXHJcbiAgICAgICAgICAgICAgICB2YXJpYXRpb25zOiAnJHZhcmlhdGlvbnMnXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICBdXHJcbiAgICAgICAgKVxyXG5cclxuICAgICAgICAvLyBsZXQgcmVzTW9uZ28gPSBhd2FpdCBjdXIudG9BcnJheSgpXHJcbiAgICAgICAgLy8gcmV0dXJuIHJlc01vbmdvXHJcblxyXG4gICAgICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo1xyXG4gICAgICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XHJcbiAgICAgICAgICBsZXQgaXRlbSA9IGF3YWl0IGN1ci5uZXh0KClcclxuXHJcbiAgICAgICAgICAvLyDlnKjluqvjgpLoqK3lrprjgZnjgotcclxuICAgICAgICAgIGZvciAobGV0IGUgb2YgaXRlbS52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgICAgIGUuc3RvY2sgPSBhd2FpdCBpdGVtQ29udHJvbGxlci5nZXRTdG9jayhlLl9pZClcclxuICAgICAgICAgICAgZGVsZXRlIGUuX2lkXHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgLy9cclxuICAgICAgICAgIC8vIOWcqOW6q+abtOaWsOODquOCr+OCqOOCueODiFxyXG4gICAgICAgICAgbGV0IGFwaSA9IG5ldyBXb3dtYUFwaShjb25maWcud293bWFBcGlQb3N0LCBjb25maWcuc2hvcElkKVxyXG4gICAgICAgICAgdHJ5IHtcclxuICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS51cGRhdGVTdG9jayhbaXRlbV0pXHJcbiAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcyhyZXMpXHJcbiAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSlcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgICAgY3VyLmNsb3NlKClcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH0sXHJcblxyXG4gIC8vXHJcbiAgLy8gV09XTUEg5ZWG5ZOB5qSc57SiXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LnNlYXJjaEl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5ZWG5ZOB5oOF5aCx5Y+W5b6XJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gQVBJ44GL44KJ5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9pdGVtc18keyhuZXcgRGF0ZSgpKS5nZXRUaW1lKCl9YFxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IG9wdGlvbnMgPSBKU09OLnBhcnNlKEpTT04uc3RyaW5naWZ5KGNvbmZpZy53b3dtYUFwaSkpXHJcbiAgICAgICAgICAgIG9wdGlvbnMudXJpID0gYCR7b3B0aW9ucy51cml9L3NlYXJjaEl0ZW1JbmZvYFxyXG4gICAgICAgICAgICBvcHRpb25zLnFzLml0ZW1Db2RlID0gaXRlbS5tYWxsLndvd21hLml0ZW1Db2RlXHJcblxyXG4gICAgICAgICAgICBsZXQgcmVwb3MgPSBhd2FpdCByZXF1ZXN0KG9wdGlvbnMpXHJcbiAgICAgICAgICAgIGxldCBmaWxlbmFtZSA9IGAke3dvcmtkaXJ9LyR7aXRlbS5tb2RlbH0ueG1sYFxyXG5cclxuICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS53cml0ZUZpbGUoZmlsZW5hbWUsIHJlcG9zKVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIFdvd21hQXBpSXRlbUZpbHRlclxyXG59IGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9kYmZpbHRlcidcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uL2ltcG9ydHMvc2VydmljZS9pdGVtcydcclxuXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5cclxuY29uc3QgdGFnID0gJ3dvd21hQXBpJ1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIFdPV01B5ZWG5ZOB5oOF5aCx5Y+W5b6XXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9LmdldEl0ZW1gXSAoY29uZmlnKSB7XHJcbiAgICAvLyDjgq/jg6njgqTjgqLjg7Pjg4jjgYzlj4LnhafjgZnjgovjgZ/jgoHjga7lh6bnkIbntZDmnpzkvZzmiJDjgqrjg5bjgrjjgqfjgq/jg4hcclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KClcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoXHJcbiAgICAgICdXT1dNQSEg5ZWG5ZOB5oOF5aCx5Y+W5b6XJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBXb3dtYUFwaUl0ZW1GaWx0ZXIoY29uZmlnLndvd21hQXBpLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8gLy8g5L2c5qWt44OV44Kp44Or44OA44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgLy8gdHJ5IHtcclxuICAgICAgICAvLyAgIGF3YWl0IGZzRXh0cmEubWtkaXIoY29uZmlnLndvcmtkaXIpXHJcbiAgICAgICAgLy8gfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8gLy8gQVBJ44GL44KJ5Y+W5b6X44GX44Gf5ZWG5ZOB5oOF5aCx44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgLy8gY29uc3Qgd29ya2RpciA9IGAke2NvbmZpZy53b3JrZGlyfS9pdGVtc18keyhuZXcgRGF0ZSgpKS5nZXRUaW1lKCl9YFxyXG4gICAgICAgIC8vIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIC8vIHRyeSB7XHJcbiAgICAgICAgLy8gICBhd2FpdCBmc0V4dHJhLm1rZGlyKHdvcmtkaXIpXHJcbiAgICAgICAgLy8gfSBjYXRjaCAoZSkge31cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKGl0ZW0pXHJcbiAgICAgICAgICB9fSlcclxuXHJcbiAgICAgICAgcmV0dXJuIHJlc1xyXG4gICAgICB9KVxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpXHJcbiAgfVxyXG5cclxufSlcclxuIiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0J1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvZGJmaWx0ZXInXHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL3NlcnZpY2UvaXRlbXMnXHJcblxyXG5pbXBvcnQge01ldGVvcn0gZnJvbSAnbWV0ZW9yL21ldGVvcidcclxuaW1wb3J0IFBhY2tldCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcGFja2V0J1xyXG5pbXBvcnQgZnNFeHRyYSBmcm9tICdmcy1leHRyYSdcclxuXHJcbmltcG9ydCBpY29udiBmcm9tICdpY29udi1saXRlJ1xyXG5pbXBvcnQgYXJjaGl2ZXIgZnJvbSAnYXJjaGl2ZXInXHJcbmltcG9ydCBjc3YgZnJvbSAnY3N2J1xyXG5pbXBvcnQgeyBQYXNzVGhyb3VnaCwgVHJhbnNmb3JtIH0gZnJvbSAnc3RyZWFtJ1xyXG5cclxuY29uc3QgcHJlZml4ID0gJ3BhY2tldCdcclxuY29uc3QgdGFnID0gJ3lhdWN0J1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOODpOODleOCquOCr+WPl+azqOODleOCoeOCpOODq1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5vcmRlcmBdIChjb25maWcpIHtcclxuICAgIC8vIOOCr+ODqeOCpOOCouODs+ODiOOBjOWPgueFp+OBmeOCi+OBn+OCgeOBruWHpueQhue1kOaenOS9nOaIkOOCquODluOCuOOCp+OCr+ODiFxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKVxyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODpOODleOCquOCr+WPl+azqCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuICAgICAgICBjb25zdCB3b3JrZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L29yZGVyYFxyXG4gICAgICAgIGNvbnN0IHIgPSBmc0V4dHJhLmNyZWF0ZVJlYWRTdHJlYW0oYCR7d29ya2Rpcn0vJHtjb25maWcub3JkZXJMb2FkZmlsZX1gKVxyXG4gICAgICAgIGNvbnN0IHcgPSBmc0V4dHJhLmNyZWF0ZVdyaXRlU3RyZWFtKGAke3dvcmtkaXJ9LyR7Y29uZmlnLm9yZGVyU2F2ZWZpbGV9YClcclxuICAgICAgICByLnBpcGUoaWNvbnYuZGVjb2RlU3RyZWFtKCdTSklTJykpXHJcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAucGlwZShjc3YucGFyc2Uoe2NvbHVtbnM6IHRydWV9KSlcclxuICAgICAgICAgIC5waXBlKGNzdi50cmFuc2Zvcm0oXHJcbiAgICAgICAgICAgIGFzeW5jIChyZWNvcmQsIGNhbGxiYWNrKSA9PiB7XHJcbiAgICAgICAgICAgICAgbGV0IGVyciA9IG51bGxcclxuICAgICAgICAgICAgICAvLyDnrqHnkIbnlarlj7fjgpLnva7jgY3mj5vjgYjjgotcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgcmVjb3JkWyfnrqHnkIbnlarlj7cnXSA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmdldE1vZGVsQ2xhc3MocmVjb3JkWyfnrqHnkIbnlarlj7cnXSlcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICBlcnIgPSBlXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICAgIGNhbGxiYWNrKGVyciwgcmVjb3JkKVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApKVxyXG4gICAgICAgICAgLnBpcGUoY3N2LnN0cmluZ2lmeSh7aGVhZGVyOiB0cnVlfSkpXHJcbiAgICAgICAgICAucGlwZShpY29udi5kZWNvZGVTdHJlYW0oJ1VURi04JykpXHJcbiAgICAgICAgICAucGlwZShpY29udi5lbmNvZGVTdHJlYW0oJ1NKSVMnKSlcclxuICAgICAgICAgIC5waXBlKHcpXHJcbiAgICAgIH1cclxuICAgIClcclxuICB9LFxyXG5cclxuICAvL1xyXG4gIC8vIOODpOODleOCquOCr+WHuuWTgeODleOCoeOCpOODq1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5leGhpYml0YF0gKGNvbmZpZykge1xyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpXHJcblxyXG4gICAgYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgICAn44Ok44OV44Kq44Kv5Ye65ZOBJyxcclxuICAgICAgYXN5bmMgKCkgPT4ge1xyXG4gICAgICAgIC8vIOWIneacn+WMluWHpueQhlxyXG4gICAgICAgIC8vXHJcblxyXG4gICAgICAgIGNvbnN0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5pdGVtc0RCLCBjb25maWcucHJvZmlsZSlcclxuICAgICAgICBjb25zdCBpdGVtQ29udHJvbGxlciA9IG5ldyBJdGVtQ29udHJvbGxlcigpXHJcbiAgICAgICAgYXdhaXQgaXRlbUNvbnRyb2xsZXIuaW5pdChjb25maWcuaXRlbXNEQilcclxuXHJcbiAgICAgICAgLy8g57mw44KK6L+U44GX5Yem55CG44KS5Lu75oSP44Gu77yIcGFja2V0U2l6Ze+8ieOBp+WIhuWJslxyXG4gICAgICAgIGNvbnN0IHBhY2tldCA9IG5ldyBQYWNrZXQoY29uZmlnLnBhY2tldFNpemUpXHJcblxyXG4gICAgICAgIC8vIOS9nOalreODleOCqeODq+ODgOOCkuS9nOaIkOOBmeOCi1xyXG4gICAgICAgIHRyeSB7XHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLm1rZGlyKGNvbmZpZy53b3JrZGlyKVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHt9XHJcblxyXG4gICAgICAgIC8vIENTVuODleOCoeOCpOODq+OCkuS9nOaIkOOBl+eUu+WDj+ODh+ODvOOCv+OCkuWPjumbhuOBmeOCi+WgtOaJgFxyXG4gICAgICAgIGNvbnN0IHdvcmtkaXIgPSBgJHtjb25maWcud29ya2Rpcn0vd29ya2BcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh3b3JrZGlyKVxyXG4gICAgICAgIGF3YWl0IGZzRXh0cmEubWtkaXIod29ya2RpcilcclxuXHJcbiAgICAgICAgLy8gWklQ44OV44Kh44Kk44Or44KS5L+d5a2Y44GZ44KL5aC05omAXHJcbiAgICAgICAgY29uc3QgdXBsb2FkZGlyID0gYCR7Y29uZmlnLndvcmtkaXJ9L3VwbG9hZGBcclxuICAgICAgICBhd2FpdCBmc0V4dHJhLnJlbW92ZSh1cGxvYWRkaXIpXHJcbiAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2Rpcih1cGxvYWRkaXIpXHJcblxyXG4gICAgICAgIGxldCBjZCA9IG51bGwgLy8g44OR44Kx44OD44OI44OV44Kp44Or44OAXHJcbiAgICAgICAgbGV0IGZpbGVuYW1lID0gbnVsbCAvLyBjc3bjg5XjgqHjgqTjg6tcclxuICAgICAgICBsZXQgbmFtZSA9IG51bGwgLy8g44OR44Kx44OD44OI55Wq5Y+3XHJcblxyXG4gICAgICAgIC8vIENTVuODleOCo+ODvOODq+ODieOCkuWumue+qeOBl+OAgemghueVquOCkueiuuWumuOBmeOCi1xyXG4gICAgICAgIGxldCBmaWVsZHMgPSBbJ+euoeeQhueVquWPtycsICfjgqvjg4bjgrTjg6onLCAn44K/44Kk44OI44OrJywgJ+iqrOaYjicsICfjgrnjg4jjgqLlhoXllYblk4HmpJzntKLnlKjjgq3jg7zjg6/jg7zjg4knLCAn6ZaL5aeL5L6h5qC8JywgJ+WNs+axuuS+oeagvCcsICflgKTkuIvjgZLkuqTmuIknLCAn5YCL5pWwJywgJ+WFpeacreWAi+aVsOWItumZkCcsICfmnJ/plpMnLCAn57WC5LqG5pmC6ZaTJywgJ+WVhuWTgeeZuumAgeWFg+OBrumDvemBk+W6nOecjCcsICfllYblk4HnmbrpgIHlhYPjga7luILljLrnlLrmnZEnLCAn6YCB5paZ6LKg5ouFJywgJ+S7o+mHkeWFiOaJleOBhOOAgeW+jOaJleOBhCcsICfokL3mnK3jg4rjg5PmsbrmuIjmlrnms5XoqK3lrponLCAn5ZWG5ZOB44Gu54q25oWLJywgJ+WVhuWTgeOBrueKtuaFi+WCmeiAgycsICfov5Tlk4Hjga7lj6/lkKYnLCAn6L+U5ZOB44Gu5Y+v5ZCm5YKZ6ICDJywgJ+eUu+WDjzEnLCAn55S75YOPMeOCs+ODoeODs+ODiCcsICfnlLvlg48yJywgJ+eUu+WDjzLjgrPjg6Hjg7Pjg4gnLCAn55S75YOPMycsICfnlLvlg48z44Kz44Oh44Oz44OIJywgJ+eUu+WDjzQnLCAn55S75YOPNOOCs+ODoeODs+ODiCcsICfnlLvlg481JywgJ+eUu+WDjzXjgrPjg6Hjg7Pjg4gnLCAn55S75YOPNicsICfnlLvlg48244Kz44Oh44Oz44OIJywgJ+eUu+WDjzcnLCAn55S75YOPN+OCs+ODoeODs+ODiCcsICfnlLvlg484JywgJ+eUu+WDjzjjgrPjg6Hjg7Pjg4gnLCAn55S75YOPOScsICfnlLvlg48544Kz44Oh44Oz44OIJywgJ+eUu+WDjzEwJywgJ+eUu+WDjzEw44Kz44Oh44Oz44OIJywgJ+acgOS9juipleS+oScsICfmgqroqZXlibLlkIjliLbpmZAnLCAn5YWl5pyt6ICF6KqN6Ki85Yi26ZmQJywgJ+iHquWLleW7tumVtycsICfml6nmnJ/ntYLkuoYnLCAn5ZWG5ZOB44Gu6Ieq5YuV5YaN5Ye65ZOBJywgJ+iHquWLleWApOS4i+OBkicsICfmnIDkvY7okL3mnK3kvqHmoLwnLCAn44OB44Oj44Oq44OG44Kj44O8JywgJ+azqOebruOBruOCquODvOOCr+OCt+ODp+ODsycsICflpKrlrZfjg4bjgq3jgrnjg4gnLCAn6IOM5pmv6ImyJywgJ+OCueODiOOCouODm+ODg+ODiOOCquODvOOCr+OCt+ODp+ODsycsICfnm67nq4vjgaHjgqLjgqTjgrPjg7MnLCAn6LSI562U5ZOB44Ki44Kk44Kz44OzJywgJ1Tjg53jgqTjg7Pjg4jjgqrjg5fjgrfjg6fjg7MnLCAn44Ki44OV44Kj44Oq44Ko44Kk44OI44Kq44OX44K344On44OzJywgJ+iNt+eJqeOBruWkp+OBjeOBlScsICfojbfnianjga7ph43ph48nLCAn44Gv44GTQk9PTicsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxJywgJ+OBneOBruS7lumFjemAgeaWueazlTHmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UyJywgJ+OBneOBruS7lumFjemAgeaWueazlTLmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVMuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UzJywgJ+OBneOBruS7lumFjemAgeaWueazlTPmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVM+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U0JywgJ+OBneOBruS7lumFjemAgeaWueazlTTmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U1JywgJ+OBneOBruS7lumFjemAgeaWueazlTXmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U2JywgJ+OBneOBruS7lumFjemAgeaWueazlTbmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVNuWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U3JywgJ+OBneOBruS7lumFjemAgeaWueazlTfmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVN+WFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U4JywgJ+OBneOBruS7lumFjemAgeaWueazlTjmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOOWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5U5JywgJ+OBneOBruS7lumFjemAgeaWueazlTnmlpnph5Hooajjg5rjg7zjgrjjg6rjg7Pjgq8nLCAn44Gd44Gu5LuW6YWN6YCB5pa55rOVOeWFqOWbveS4gOW+i+S+oeagvCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMCcsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOaWmemHkeihqOODmuODvOOCuOODquODs+OCrycsICfjgZ3jga7ku5bphY3pgIHmlrnms5UxMOWFqOWbveS4gOW+i+S+oeagvCcsICfmtbflpJbnmbrpgIEnLCAn6YWN6YCB5pa55rOV44O76YCB5paZ6Kit5a6aJywgJ+S7o+W8leaJi+aVsOaWmeioreWumicsICfmtojosrvnqI7oqK3lrponLCAnSkFO44Kz44O844OJ44O7SVNCTuOCs+ODvOODiSddXHJcbiAgICAgICAgbGV0IGhlYWRlciA9IGZpZWxkcy5tYXAodiA9PiBgXCIke3Z9XCJgKS5qb2luKCcsJykgKyAnXFxuJ1xyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbplovlp4vmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXRTdGFydCA9IGFzeW5jIChwYWNrZXRDb3VudCkgPT4ge1xyXG4gICAgICAgICAgbmFtZSA9IHByZWZpeCArICgnMDAwMDAnICsgcGFja2V0Q291bnQpLnNsaWNlKC01KVxyXG4gICAgICAgICAgY2QgPSBgJHt3b3JrZGlyfS8ke25hbWV9YFxyXG4gICAgICAgICAgZmlsZW5hbWUgPSBgJHtjZH0vJHtjb25maWcuY3N2RmlsZU5hbWV9YFxyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5ta2RpcihjZClcclxuICAgICAgICAgIC8vIENTVuODleOCoeOCpOODq+OBq+ODleOCo+ODvOODq+ODieOCkuioreWumuOBmeOCi1xyXG4gICAgICAgICAgYXdhaXQgZnNFeHRyYS5hcHBlbmRGaWxlKGZpbGVuYW1lLCBpY29udi5lbmNvZGUoaGVhZGVyLCAnU2hpZnRfSklTJykpXHJcbiAgICAgICAgfVxyXG5cclxuICAgICAgICAvLyDjg5HjgrHjg4Pjg4jljJbmmYJcclxuICAgICAgICBwYWNrZXQub25QYWNrZXQgPSBhc3luYyAoYXJnKSA9PiB7XHJcbiAgICAgICAgICBsZXQgeWF1Y3QgPSBhcmcueWF1Y3RcclxuICAgICAgICAgIGxldCBpdGVtID0gYXJnLml0ZW1cclxuICAgICAgICAgIC8vIGNzduODleOCoeOCpOODq+OBq+ODrOOCs+ODvOODie+8iOWVhuWTgeODhuODs+ODl+ODrOODvOODiO+8ieOCkui/veWKoOOBmeOCi1xyXG4gICAgICAgICAgbGV0IHJlY29yZCA9IGZpZWxkcy5tYXAodiA9PiB7IHJldHVybiB5YXVjdFt2XSA/IGBcIiR7eWF1Y3Rbdl19XCJgIDogJ1wiXCInIH0pLmpvaW4oJywnKSArICdcXG4nXHJcbiAgICAgICAgICBhd2FpdCBmc0V4dHJhLmFwcGVuZEZpbGUoZmlsZW5hbWUsIGljb252LmVuY29kZShyZWNvcmQsICdTaGlmdF9KSVMnKSlcclxuICAgICAgICAgIC8vIOeUu+WDj+ODleOCoeOCpOODq+OCkuOCs+ODlOODvFxyXG4gICAgICAgICAgZm9yIChsZXQgaW1nIG9mIGl0ZW0uaW1hZ2VzKSB7XHJcbiAgICAgICAgICAgIGxldCBpbWdTcmMgPSBgJHtjb25maWcuaW1hZ2VkaXJ9LyR7aW1nfWBcclxuICAgICAgICAgICAgbGV0IGltZ1RndCA9IGAke2NkfS8ke2ltZ31gXHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgLy8g5ZCM44GY44OV44Kh44Kk44Or44GM44GC44KL5aC05ZCI44Gv44Kz44OU44O844GX44Gq44GEXHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5hY2Nlc3MoaW1nVGd0KVxyXG4gICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgZnNFeHRyYS5jb3B5RmlsZShpbWdTcmMsIGltZ1RndClcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44OR44Kx44OD44OI57WC5LqG5pmCXHJcbiAgICAgICAgcGFja2V0Lm9uUGFja2V0RW5kID0gYXN5bmMgKHBhY2tldENvdW50KSA9PiB7XHJcbiAgICAgICAgICBjb25zdCB6aXAgPSBhcmNoaXZlcignemlwJylcclxuICAgICAgICAgIGNvbnN0IHppcG5hbWUgPSBgJHt1cGxvYWRkaXJ9LyR7bmFtZX0uemlwYFxyXG4gICAgICAgICAgY29uc3Qgb3V0cHV0ID0gZnNFeHRyYS5jcmVhdGVXcml0ZVN0cmVhbSh6aXBuYW1lKVxyXG4gICAgICAgICAgemlwLnBpcGUob3V0cHV0KVxyXG4gICAgICAgICAgemlwLmRpcmVjdG9yeShjZCwgZmFsc2UpXHJcbiAgICAgICAgICB6aXAuZmluYWxpemUoKVxyXG4gICAgICAgIH1cclxuXHJcbiAgICAgICAgLy8g44Oh44Kk44Oz44Or44O844OXXHJcbiAgICAgICAgLy9cclxuXHJcbiAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuXHJcbiAgICAgICAgICAnVEFSR0VUJzogYXN5bmMgKGl0ZW0sIGNvbnRleHQpID0+IHtcclxuICAgICAgICAgICAgbGV0IHF1YW50aXR5ID0gYXdhaXQgaXRlbUNvbnRyb2xsZXIuZ2V0U3RvY2soaXRlbS5faWQpXHJcbiAgICAgICAgICAgIC8vIGl0ZW3jgavlrprnvqnjgZXjgozjgabjgYTjgovmnIDkvY7lv4XopoHlnKjluqvjgojjgorlpJrjgYTllYblk4HjgpLlh7rlk4HjgZnjgotcclxuICAgICAgICAgICAgaWYgKHF1YW50aXR5ID49IGl0ZW0ubWFsbC55YXVjdC5taW5RdWFudGl0eSkge1xyXG4gICAgICAgICAgICAgIGxldCB5YXVjdCA9IGF3YWl0IGl0ZW1Db250cm9sbGVyLmNvbnZlcnRJdGVtWWF1Y3QoY29uZmlnLmRlZmF1bHQsIGl0ZW0pXHJcbiAgICAgICAgICAgICAgYXdhaXQgcGFja2V0LnN1Ym1pdCh7eWF1Y3Q6IHlhdWN0LCBpdGVtOiBpdGVtfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfX0pXHJcblxyXG4gICAgICAgIHBhY2tldC5jbG9zZSgpXHJcblxyXG4gICAgICAgIHJldHVybiByZXNcclxuICAgICAgfSlcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKVxyXG4gIH1cclxuXHJcbn0pXHJcbiIsImltcG9ydCAnLi4vaW1wb3J0cy9jb2xsZWN0aW9ucydcclxuaW1wb3J0ICcuL3JvdXRlL3VwbG9hZC9pbWFnZSdcclxuIiwiaW1wb3J0IHtcclxuICBNb25nb1xyXG59IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbmltcG9ydCBNeVNRTCBmcm9tICcuLi91dGlsL215c3FsJztcclxuaW1wb3J0IHtcclxuICBNZXRlb3JcclxufSBmcm9tICdtZXRlb3IvbWV0ZW9yJztcclxuXHJcbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXHJcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnO1xyXG5pbXBvcnQgbW9iamVjdCBmcm9tICdtb25nb29iamVjdCc7XHJcbmltcG9ydCB7IEdyb3VwQmFzZSB9IGZyb20gJy4vZ3JvdXBzJztcclxuXHJcbmNvbnN0IEZpbHRlcnMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZmlsdGVycycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgRmlsdGVyIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZmlsdGVySWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEZpbHRlcnMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogZmlsdGVySWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuXHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoIG9uUmVzdWx0ID0gKHJlY29yZCk9Pnt9LCBvbkVycm9yID0gKGUpPT57fSApID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9YDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcblxyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcignaW52YWxpZCBwbGF0Zm9ybSB0eXBlJyk7XHJcblxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHt7IGZpbHRlclR5cGU6IGFzeW5jIChyZWNvcmQgKSA9PiB7fSB9fSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGFzeW5jIGZvcmVhY2goY2FsbGJhY2tzID0ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZSgpO1xyXG5cclxuICAgIC8vIG1pc2Mg44OV44Kj44Or44K/44O844KS5pyr5bC+44Gr6Ieq5YuV6L+95YqgXHJcbiAgICBwcm9maWxlLmZpbHRlcnMucHVzaCh7XHJcbiAgICAgIHR5cGU6ICdtaXNjJyxcclxuICAgICAgcXVlcnk6IHt9XHJcbiAgICB9KVxyXG5cclxuICAgIGxldCBjb3VudCA9IHt9O1xyXG4gICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICBjb3VudFtmaWx0ZXIudHlwZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGZpbHRlci5xdWVyeSxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9O1xyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkKT0+e1xyXG4gICAgICAgIGZvciggbGV0IGZpbHRlciBvZiBwcm9maWxlLmZpbHRlcnMgKXtcclxuICAgICAgICAgIGxldCBxdWVyeSA9IG1vYmplY3QudW5lc2NhcGUoZmlsdGVyLnF1ZXJ5KTtcclxuICAgICAgICAgIGxldCBleGFtID0gc2lmdCggcXVlcnkgKTtcclxuICAgICAgICAgIGlmKCBleGFtKHJlY29yZCkgKXtcclxuICAgICAgICAgICAgY291bnRbZmlsdGVyLnR5cGVdLmNvdW50Kys7XHJcbiAgICAgICAgICAgIGlmKCB0eXBlb2YgY2FsbGJhY2tzW2ZpbHRlci50eXBlXSAhPT0gJ3VuZGVmaW5lZCcpe1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrc1tmaWx0ZXIudHlwZV0ocmVjb3JkKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH0sXHJcbiAgICAgIG9uRXJyb3JcclxuICAgICk7XHJcblxyXG4gICAgLy8gcmV0dXJuIHJlc3VsdCBvZiBmaWx0ZXJpbmdcclxuICAgIHJldHVybiBjb3VudDtcclxuXHJcbiAgfVxyXG5cclxufVxyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuY29uc3QgR3JvdXBzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2dyb3VwcycsIHtcclxuICBpZEdlbmVyYXRpb246ICdNT05HTydcclxufSk7XHJcblxyXG5leHBvcnQgY2xhc3MgR3JvdXBCYXNlIHtcclxuXHJcbiAgcHJvZmlsZTtcclxuXHJcbiAgY29uc3RydWN0b3IocHJvZmlsZSkge1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZTtcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIGdldHMgJ1BsdWcnIHdpdGNoIGlzIGEgc2V0IG9mIHByb3BlcnRpZXMgbmVlZGVkXHJcbiAgICogd2hlbiBjb25uZWN0IHRvIHNvbWUgcGxhdGZvcm1zXHJcbiAgICogdG8gZ2V0IGRhdGFzKE1lbWJlcnMgb2YgdGhlIEdyb3VwKVxyXG4gICAqL1xyXG4gIGdldFBsdWcoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlLnBsYXRmb3JtUGx1ZztcclxuICB9XHJcblxyXG4gIGdldFByb2ZpbGUoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgZm9yZWFjaChjYWxsYmFjayA9IGFzeW5jIChyZWNvcmQpID0+IHt9LCBvbkVycm9yID0gYXN5bmMgKGUpID0+IHt9KSB7fTtcclxuXHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cCBleHRlbmRzIEdyb3VwQmFzZSB7XHJcblxyXG4gIGNvbnN0cnVjdG9yKGdyb3VwSWQpIHtcclxuXHJcbiAgICBsZXQgcHJvZmlsZSA9IEdyb3Vwcy5maW5kT25lKHtcclxuICAgICAgX2lkOiBncm91cElkXHJcbiAgICB9KTtcclxuXHJcbiAgICBzdXBlcihwcm9maWxlKTtcclxuXHJcbiAgICBsZXQgcGx1ZyA9IHRoaXMuZ2V0UGx1ZygpO1xyXG5cclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKHBsdWcuY3JlZCk7XHJcbiAgICAgICAgdGhpcy5pbXBvcnQgPSBhc3luYyAoZG9jKSA9PiB7XHJcbiAgICAgICAgICBsZXQgc3FsID0gYFNFTEVDVCAqIEZST00gJHtwbHVnLnRhYmxlfSBXSEVSRSBcXGAke2RvYy5rZXl9XFxgID0gXCIke2RvYy5pZH1cImA7XHJcbiAgICAgICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5xdWVyeShzcWwpO1xyXG4gICAgICAgIH07XHJcbiAgICAgICAgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIGdyb3VwIHR5cGUnKTtcclxuICAgIH1cclxuXHJcbiAgfVxyXG5cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogQHBhcmFtIHthc3luYyAocmVjb3JkKT0+dm9pZH0gY2FsbGJhY2sgY3VzdG9tIGZ1bmN0aW9uIGZvciBlYWNoIG1lbWJlcnNcclxuICAgKi9cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHtcclxuXHJcbiAgICBsZXQgY3VyID0gR3JvdXBzLmZpbmQoe1xyXG4gICAgICBncm91cElkOiB0aGlzLnByb2ZpbGUuX2lkXHJcbiAgICB9LCB7XHJcbiAgICAgIGZpZWxkczoge1xyXG4gICAgICAgIF9pZDogMCxcclxuICAgICAgICBpZDogMSxcclxuICAgICAgICBrZXk6IDFcclxuICAgICAgfVxyXG4gICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgXHJcbiAgICAgICAgY3VyLmZvckVhY2goXHJcbiAgICAgICAgICBhc3luYyAoZG9jLCBpbmRleCkgPT4ge1xyXG4gICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgIGxldCByZWNvcmQgPSBhd2FpdCB0aGlzLmltcG9ydChkb2MpO1xyXG4gICAgICAgICAgICAgIGF3YWl0IGNhbGxiYWNrKHJlY29yZCk7XHJcbiAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICBvbkVycm9yKGUpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGlmIChpbmRleCArIDEgPT09IGN1ci5jb3VudCgpKSB7XHJcbiAgICAgICAgICAgICAgcmVzb2x2ZSgpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9KTtcclxuXHJcbiAgICAgIH1cclxuICAgICkuY2F0Y2goXHJcbiAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgdGhyb3cgZTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgfVxyXG5cclxufSIsImltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnXHJcblxyXG5leHBvcnQgY2xhc3MgQ3ViZTNBcGkge1xyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtNeVNRTH0gbXlzcWxcclxuICAgKi9cclxuICBjb25zdHJ1Y3RvciAobXlzcWwpIHtcclxuICAgIHRoaXMubXlzcWxfID0gbXlzcWxcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZVN0b2NrIChwcm9kdWN0Q2xhc3NJZCwgcXVhbnRpdHkgPSAwKSB7XHJcbiAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeVVwZGF0ZShcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgYHByb2R1Y3RfY2xhc3NfaWQgPSAke3Byb2R1Y3RDbGFzc0lkfWAsXHJcbiAgICAgIHt9LCB7XHJcbiAgICAgICAgc3RvY2s6IHF1YW50aXR5LFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsXHJcbiAgICAgIGBwcm9kdWN0X2NsYXNzX2lkID0gJHtwcm9kdWN0Q2xhc3NJZH1gLFxyXG4gICAgICB7fSwge1xyXG4gICAgICAgIHN0b2NrOiBxdWFudGl0eSxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VGFnVXBkYXRlIChkYXRhKSB7XHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IFtdXHJcblxyXG4gICAgLy8g5YmK6Zmk44GZ44KL44K/44KwXHJcbiAgICBsZXQgdGFnb2ZmID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICBsZXQgc3FsID0gYFxyXG4gICAgICBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF90YWcgXHJcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxyXG4gICAgICBgXHJcbiAgICAgIHJlcy5wdXNoKGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbCkpXHJcbiAgICB9XHJcblxyXG4gICAgLy8g6KGo56S644GZ44KL44K/44KwXHJcbiAgICBsZXQgdGFnb24gPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIC8vIOOBmeOBp+OBq+ihqOekuuOBleOCjOOBpuOBhOOCi+OCv+OCsOOBjOOBguOCjOOBsOS9leOCguOBl+OBquOBhFxyXG4gICAgICBsZXQgc3FsID0gYFxyXG4gICAgICBTRUxFQ1QgQ09VTlQoKikgRlJPTSBkdGJfcHJvZHVjdF90YWcgXHJcbiAgICAgIFdIRVJFIHByb2R1Y3RfaWQgPSAke2RhdGEucHJvZHVjdF9pZH0gQU5EIHRhZyA9ICR7dGFnfVxyXG4gICAgICBgXHJcbiAgICAgIGxldCBjb3VudFJlcyA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5KHNxbClcclxuICAgICAgaWYgKGNvdW50UmVzWzBdWydDT1VOVCgqKSddKSByZXR1cm5cclxuXHJcbiAgICAgIHJlcy5wdXNoKFxyXG4gICAgICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgJ2R0Yl9wcm9kdWN0X3RhZycsXHJcbiAgICAgICAgICB7fSxcclxuICAgICAgICAgIHtcclxuICAgICAgICAgICAgcHJvZHVjdF9pZDogZGF0YS5wcm9kdWN0X2lkLFxyXG4gICAgICAgICAgICB0YWc6IHRhZyxcclxuICAgICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgICkpXHJcbiAgICB9XHJcblxyXG4gICAgZm9yIChsZXQgdGFnU2V0IG9mIGRhdGEudGFncykge1xyXG4gICAgICBzd2l0Y2ggKHRhZ1NldC5zZXQpIHtcclxuICAgICAgICBjYXNlICdvbic6XHJcbiAgICAgICAgICBhd2FpdCB0YWdvbih0YWdTZXQudGFnKVxyXG4gICAgICAgICAgYnJlYWtcclxuICAgICAgICBjYXNlICdvZmYnOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb2ZmKHRhZ1NldC50YWcpXHJcbiAgICAgICAgICBicmVha1xyXG4gICAgICB9XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RJbWFnZVVwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IHByb2R1Y3RJZCA9IGRhdGEucHJvZHVjdF9pZFxyXG4gICAgbGV0IGltYWdlcyA9IGRhdGEuaW1hZ2VzXHJcbiAgICBsZXQgY3JlYXRvcklkID0gZGF0YS5jcmVhdG9yX2lkXHJcblxyXG4gICAgbGV0IHJlcyA9IFtdXHJcblxyXG4gICAgLy8g5ZWG5ZOB44Gr6Zai6YCj44GZ44KL44GZ44G544Gm44Gu55S75YOP5oOF5aCx44KS5YmK6Zmk44GZ44KLXHJcbiAgICBsZXQgc3FsID0gYERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X2ltYWdlIFdIRVJFIHByb2R1Y3RfaWQgPSAke3Byb2R1Y3RJZH1gXHJcbiAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpKVxyXG4gICAgLy8g5pS544KB44Gm55S75YOP44KS55m76Yyy44GX44Gq44GK44GZXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IGltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAnZHRiX3Byb2R1Y3RfaW1hZ2UnLCB7XHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgICBmaWxlX25hbWU6IGltYWdlc1tpXSxcclxuICAgICAgICAgIHJhbms6IGkgKyAxXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgY3JlYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgICB9XHJcbiAgICAgIClcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcHJvZHVjdFVwZGF0ZSAoZGF0YSkge1xyXG4gICAgbGV0IHVwZGF0ZURhdGEgPSB7fVxyXG4gICAgbGV0IGtleXMgPSBbXVxyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0XHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3N0YXR1cycsXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ25vdGUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fbGlzdCcsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9kZXRhaWwnLFxyXG4gICAgICAnc2VhcmNoX3dvcmQnLFxyXG4gICAgICAnZnJlZV9hcmVhJ1xyXG4gICAgXVxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RfY2xhc3NcclxuXHJcbiAgICB1cGRhdGVEYXRhID0ge31cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdkZWxpdmVyeV9kYXRlX2lkJyxcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdzYWxlX2xpbWl0JyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHByb2R1Y3RDcmVhdGUgKGRhdGEpIHtcclxuICAgIGxldCBjcmVhdG9ySWQgPSBkYXRhLmNyZWF0b3JfaWRcclxuXHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBsZXQgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBsZXQga2V5cyA9IFtdXHJcblxyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnZGVzY3JpcHRpb25fZGV0YWlsJ1xyXG4gICAgXVxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBuYW1lOiBpdGVtLm5hbWUsXHJcbiAgICAvLyAgIGRlc2NyaXB0aW9uX2RldGFpbDogaXRlbS5kZXNjcmlwdGlvbixcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIHVwZGF0ZURhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9ySWQsXHJcbiAgICAgICAgc3RhdHVzOiAxLFxyXG4gICAgICAgIG5vdGU6ICdOVUxMJyxcclxuICAgICAgICBkZXNjcmlwdGlvbl9saXN0OiAnTlVMTCcsXHJcbiAgICAgICAgc2VhcmNoX3dvcmQ6ICdOVUxMJyxcclxuICAgICAgICBmcmVlX2FyZWE6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgdXBkYXRlRGF0YSA9IHt9XHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAncHJvZHVjdF9jb2RlJyxcclxuICAgICAgJ3Byb2R1Y3RfdHlwZV9pZCcsXHJcbiAgICAgICdwcmljZTAxJyxcclxuICAgICAgJ3ByaWNlMDInLFxyXG4gICAgICAnZGVsaXZlcnlfZmVlJ1xyXG4gICAgXVxyXG4gICAgLy8ge1xyXG4gICAgLy8gICBwcm9kdWN0X2NvZGU6IGl0ZW0ubW9kZWwsXHJcbiAgICAvLyAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxyXG4gICAgLy8gICBwcmljZTAyOiBpdGVtLnNhbGVzX3ByaWNlLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZURhdGFba10gPSBkYXRhW2tdXHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfY2xhc3NfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgdXBkYXRlRGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgICBwcm9kdWN0X2lkOiByZXMucHJvZHVjdF9pZCxcclxuICAgICAgICBzdG9jazogMCxcclxuICAgICAgICBzdG9ja191bmxpbWl0ZWQ6IDAsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQxOiAnTlVMTCcsXHJcbiAgICAgICAgY2xhc3NfY2F0ZWdvcnlfaWQyOiAnTlVMTCcsXHJcbiAgICAgICAgZGVsaXZlcnlfZGF0ZV9pZDogJ05VTEwnLFxyXG4gICAgICAgIHNhbGVfbGltaXQ6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVEYXRhW2tdID0gZGF0YVtrXVxyXG4gICAgfVxyXG5cclxuICAgIHJlcy5wcm9kdWN0X3N0b2NrX2lkID0gYXdhaXQgdGhpcy5teXNxbF8ucXVlcnlJbnNlcnQoXHJcbiAgICAgICdkdGJfcHJvZHVjdF9zdG9jaycsIHt9LCB7XHJcbiAgICAgICAgcHJvZHVjdF9jbGFzc19pZDogcmVzLnByb2R1Y3RfY2xhc3NfaWQsXHJcbiAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcklkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBmb3IgdGVzdFxyXG4gICAgcmV0dXJuIHtcclxuICAgICAgcmVzOiByZXNcclxuICAgIH1cclxuICB9XHJcbn1cclxuIiwiaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnXHJcbmltcG9ydCB7TW9uZ29DbGllbnR9IGZyb20gJ21vbmdvZGInXHJcbmltcG9ydCByZXF1ZXN0IGZyb20gJ3JlcXVlc3QtcHJvbWlzZSdcclxuXHJcbi8vIHZhbGlkYXRlIG9iamVjdHMgJiBmaWx0ZXIgYXJyYXlzIHdpdGggbW9uZ29kYiBxdWVyaWVzXHJcbmltcG9ydCBzaWZ0IGZyb20gJ3NpZnQnXHJcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0J1xyXG5pbXBvcnQgeyB4bWwyanMgfSBmcm9tICd4bWwtanMnXHJcblxyXG5leHBvcnQgY2xhc3MgREJGaWx0ZXJGYWN0b3J5IHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgbGV0IGluc3RhbmNlXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG4gICAgICBjYXNlICdteXNxbCc6XHJcbiAgICAgICAgaW5zdGFuY2UgPSBuZXcgTXlzcWxEQkZpbHRlcihwbHVnLCBwcm9maWxlKVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBpbnN0YW5jZVxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgdGhpcy5wbHVnID0gcGx1Z1xyXG4gICAgdGhpcy5wcm9maWxlID0gcHJvZmlsZVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZhY3RvcnkgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgJ215c3FsJzpcclxuICAgICAgICByZXR1cm4gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSlcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgcGx1ZyB0eXBlJylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGdldFBsdWdfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnBsdWdcclxuICB9XHJcblxyXG4gIGdldENyZWRfICgpIHtcclxuICAgIHJldHVybiB0aGlzLnBsdWcuY3JlZFxyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZV8gKCkge1xyXG4gICAgcmV0dXJuIHRoaXMucHJvZmlsZVxyXG4gIH1cclxuXHJcbiAgc2V0SW1wb3J0RnVuY3Rpb25fIChcclxuICAgIGZuID0gYXN5bmMgKG9uUmVzdWx0ID0gcmVjb3JkID0+IHt9LCBvbkVycm9yID0gZSA9PiB7fSkgPT4ge31cclxuICApIHtcclxuICAgIHRoaXMuaW1wb3J0ID0gZm5cclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqIHRyYWNlcyBtZW1iZXJzIG9mIHRoZSBncm91cFxyXG4gICAqIHVzZWFnZTpcclxuICAgKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHsgT2JqZWN0IH0gaXRlcmF0b3JzIHsgZmlsdGVyTmFtZTogYXN5bmMgKGRvYyxjb250ZXh0KT0+e30sIC4uLiB9IGl0ZXJhdG9yIGZvciBlYWNoIGZpbHRlcnNcclxuICAgKiBAcGFyYW0geyBhc3luYyBmdW5jdGlvbiB9IG9uRXJyb3IgZXJyb3IgaGFuZGxlciB3aGlsZSBpdGVyYXRpbmdcclxuICAgKiBAcmV0dXJucyB7IE9iamVjdCB9IHsgZmlsdGVyTmFtZTogeyBxdWVyeTogYW55LCBjb3VudDogbnVtYmVyIH0sIC4uLiB9XHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaCAoaXRlcmF0b3JzID0ge30pIHtcclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlXygpXHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgbmFtZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ZXIgPSB7fVxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgIH1cclxuXHJcbiAgICBsZXQgZmlsdGVycyA9IFtdXHJcblxyXG4gICAgZm9yIChsZXQgZiBvZiBwcm9maWxlLmZpbHRlcnMpIHtcclxuICAgICAgY291bnRlcltmLm5hbWVdID0ge1xyXG4gICAgICAgIHF1ZXJ5OiBmLnF1ZXJ5LFxyXG4gICAgICAgIGxpbWl0OiB0eXBlb2YgZi5saW1pdCAhPT0gJ3VuZGVmaW5lZCcgPyBmLmxpbWl0IDogMCxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9XHJcbiAgICAgIGZpbHRlcnMucHVzaChcclxuICAgICAgICB7XHJcbiAgICAgICAgICBuYW1lOiBmLm5hbWUsXHJcbiAgICAgICAgICBleGFtOiBzaWZ0KG1vYmplY3QudW5lc2NhcGUoZi5xdWVyeSkpXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQsIGNvbnRleHQpID0+IHtcclxuICAgICAgICBmb3IgKGxldCBmIG9mIGZpbHRlcnMpIHtcclxuICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgbGV0IGMgPSBjb3VudGVyW2YubmFtZV1cclxuICAgICAgICAgIGlmIChjLmxpbWl0KSB7XHJcbiAgICAgICAgICAgIGlmIChjLmNvdW50ID49IGMubGltaXQpIHtcclxuICAgICAgICAgICAgICBjb250aW51ZVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgaWYgKGYuZXhhbShyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgICBjLmNvdW50KytcclxuXHJcbiAgICAgICAgICAgIC8vIGl0ZXJhdG9yXHJcbiAgICAgICAgICAgIGlmICh0eXBlb2YgaXRlcmF0b3JzW2YubmFtZV0gIT09ICd1bmRlZmluZWQnKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgaXRlcmF0b3JzW2YubmFtZV0ocmVjb3JkLCBjb250ZXh0KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KVxyXG5cclxuICAgIC8vIHJldHVybiByZXN1bHQgb2YgZmlsdGVyaW5nXHJcbiAgICByZXR1cm4gY291bnRlclxyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIE15c3FsREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpXHJcblxyXG4gICAgbGV0IGNyZWQgPSB0aGlzLmdldENyZWRfKClcclxuXHJcbiAgICB0aGlzLm15c3FsID0gbmV3IE15U1FMKGNyZWQpXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gXHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIChlKSA9PiB7IHRocm93IGUgfSlcclxuICAgICAgcmV0dXJuIHJlc1xyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBNb25nb05hdGl2ZSBmcm9tICdtb25nb2RiJztcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSBNb25nb05hdGl2ZS5Nb25nb0NsaWVudDtcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSByZXF1aXJlKCdtb25nb2RiJykuTW9uZ29DbGllbnQ7XHJcblxyXG5leHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuICBjb25zdHJ1Y3RvciAocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSlcclxuXHJcbiAgICAvLyBtb25nbyDjgbjmjqXntppcclxuICAgIHRoaXMuc2V0SW1wb3J0RnVuY3Rpb25fKGFzeW5jIChvblJlc3VsdCwgb25FcnJvcikgPT4ge1xyXG4gICAgICBsZXQgY2xpZW50XHJcbiAgICAgIGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpXHJcblxyXG4gICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLlj5blvpdcclxuICAgICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICAgIGxldCBjb2xsZWN0aW9uID0gZGIuY29sbGVjdGlvbihwbHVnLmNvbGxlY3Rpb24pXHJcblxyXG4gICAgICBsZXQgY29udGV4dCA9IHtcclxuICAgICAgICBjbGllbnQ6IGNsaWVudCxcclxuICAgICAgICBjb2xsZWN0aW9uOiBjb2xsZWN0aW9uLFxyXG4gICAgICAgIGRhdGFiYXNlOiBkYlxyXG4gICAgICB9XHJcblxyXG4gICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKClcclxuXHJcbiAgICAgIC8vIOOCq+ODvOOCveODq+OBruOCv+OCpOODoOOCouOCpuODiOOCkuino+mZpFxyXG4gICAgICBjdXIuYWRkQ3Vyc29yRmxhZygnbm9DdXJzb3JUaW1lb3V0JywgdHJ1ZSlcclxuXHJcbiAgICAgIC8vIOOBmeOBueOBpuOBruODieOCreODpeODoeODs+ODiOOCkuODq+ODvOODl1xyXG4gICAgICB0cnkge1xyXG4gICAgICAgIHdoaWxlIChhd2FpdCBjdXIuaGFzTmV4dCgpKSB7XHJcbiAgICAgICAgICBsZXQgZG9jID0gYXdhaXQgY3VyLm5leHQoKVxyXG4gICAgICAgICAgYXdhaXQgb25SZXN1bHQoZG9jLCBjb250ZXh0KVxyXG4gICAgICAgIH07XHJcbiAgICAgIH0gZmluYWxseSB7XHJcbiAgICAgICAgLy8g44Kr44O844K944Or44KS6ZaL5pS+XHJcbiAgICAgICAgYXdhaXQgY3VyLmNsb3NlKClcclxuICAgICAgfVxyXG4gICAgfSlcclxuICB9XHJcbn1cclxuXHJcbmV4cG9ydCBjbGFzcyBXb3dtYUFwaUl0ZW1GaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IgKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpXHJcblxyXG4gICAgLy8g5ZWG5ZOB5oOF5aCx44Gu5Y+W5b6X44Or44O844OX44KS5a6a576pXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5Y+W5b6XXHJcbiAgICAgIGxldCBvcHRpb25zID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShwbHVnKSlcclxuICAgICAgb3B0aW9ucy51cmkgPSBgJHtvcHRpb25zLnVyaX0vc2VhcmNoU3RvY2tzYFxyXG4gICAgICBsZXQgY29udGV4dCA9IHtcclxuICAgICAgICBvcHRpb25zOiBvcHRpb25zXHJcbiAgICAgIH1cclxuXHJcbiAgICAgIHdoaWxlICgxKSB7XHJcbiAgICAgICAgLy8gV293bWEgQXBpIOOBi+OCieWVhuWTgeaDheWgseOCkuWPluW+l1xyXG4gICAgICAgIGxldCByZXMgPSBhd2FpdCByZXF1ZXN0KG9wdGlvbnMpXHJcbiAgICAgICAgcmVzID0geG1sMmpzKHJlcywge2NvbXBhY3Q6IHRydWV9KVxyXG5cclxuICAgICAgICBsZXQgbWF4Q291bnQgPSBOdW1iZXIocmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5tYXhDb3VudC5fdGV4dClcclxuICAgICAgICBsZXQgcmVzdWx0Q291bnQgPSBOdW1iZXIocmVzLnJlc3BvbnNlLnNlYXJjaFJlc3VsdC5yZXN1bHRDb3VudC5fdGV4dClcclxuICAgICAgICBsZXQgc3RhcnRDb3VudCA9IE51bWJlcihyZXMucmVzcG9uc2Uuc2VhcmNoUmVzdWx0LnN0YXJ0Q291bnQuX3RleHQpXHJcbiAgICAgICAgbGV0IHJlc3VsdFN0b2NrcyA9IHJlcy5yZXNwb25zZS5zZWFyY2hSZXN1bHQucmVzdWx0U3RvY2tzXHJcblxyXG4gICAgICAgIC8vIOWPluW+l+OBl+OBn+WVhuWTgeaDheWgseOCkuOCq+OCueOCv+ODoOODl+ODreOCu+OCueOBq+a4oeOBmVxyXG4gICAgICAgIGlmIChyZXN1bHRTdG9ja3MgaW5zdGFuY2VvZiBBcnJheSkge1xyXG4gICAgICAgICAgLy8g5Y+W5b6X44GX44Gf44OH44O844K/44GM6KSH5pWw5ZWG5ZOB44Gu5aC05ZCIXHJcbiAgICAgICAgICBmb3IgKGxldCBpID0gMDsgaSA8IHJlc3VsdENvdW50OyBpKyspIHtcclxuICAgICAgICAgICAgYXdhaXQgb25SZXN1bHQocmVzdWx0U3RvY2tzW2ldLCBjb250ZXh0KVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAvLyDlj5blvpfjgZfjgZ/jg4fjg7zjgr/jgYzljZjmlbDllYblk4Hjga7loLTlkIhcclxuICAgICAgICAgIGF3YWl0IG9uUmVzdWx0KHJlc3VsdFN0b2NrcywgY29udGV4dClcclxuICAgICAgICB9XHJcblxyXG4gICAgICAgIGxldCBuZXh0ID0gc3RhcnRDb3VudCArIHJlc3VsdENvdW50XHJcblxyXG4gICAgICAgIGlmIChuZXh0ID4gbWF4Q291bnQpIGJyZWFrXHJcbiAgICAgICAgb3B0aW9ucy5xcy5zdGFydENvdW50ID0gbmV4dFxyXG4gICAgICB9XHJcbiAgICB9KVxyXG4gIH1cclxufVxyXG5cclxuLy8gaW1wb3J0IG1vbmdvb3NlIGZyb20gJ21vbmdvb3NlJztcclxuXHJcbi8vIGV4cG9ydCBjbGFzcyBNb25nb0RCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4vLyAgIGNvbnN0cnVjdG9yKHBsdWcsIHByb2ZpbGUpIHtcclxuLy8gICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xyXG5cclxuLy8gICAgIC8vIG1vbmdvIOOBuOaOpee2mlxyXG4vLyAgICAgbGV0IGNyZWQgPSB0aGlzLmdldENyZWRfKCk7XHJcbi8vICAgICBsZXQgY29udXJpID0gYG1vbmdvZGI6Ly8ke2NyZWQuaG9zdH06JHtjcmVkLnBvcnR9LyR7Y3JlZC5kYXRhYmFzZX1gO1xyXG4vLyAgICAgYXdhaXQgbW9uZ29vc2UuY29ubmVjdChjb251cmkpO1xyXG5cclxuLy8gICAgIC8vIOOCs+ODrOOCr+OCt+ODp+ODs+OCkuS9nOOCi1xyXG4vLyAgICAgbGV0IGNvbGxlY3Rpb24gPSBtb25nb29zZS5jb25uZWN0aW9uLmNvbGxlY3Rpb24ocGx1Zy5jb2xsZWN0aW9uKTtcclxuXHJcbi8vICAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuLy8gICAgICAgbGV0IGN1ciA9IGNvbGxlY3Rpb24uZmluZCgpO1xyXG5cclxuLy8gICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgb25FcnJvcik7XHJcbi8vICAgICB9KTtcclxuLy8gICB9XHJcbi8vIH1cclxuIiwiaW1wb3J0IHtcclxuICBNb25nb0NvbGxlY3Rpb25cclxufSBmcm9tICcuLi91dGlsL21vbmdvJ1xyXG5pbXBvcnQge1xyXG4gIFVwbG9hZHMsIFJvYm90aW5TaG9wXHJcbn0gZnJvbSAnLi4vY29sbGVjdGlvbnMnXHJcbmltcG9ydCB7XHJcbiAgT2JqZWN0SURcclxufSBmcm9tICdic29uJ1xyXG5pbXBvcnQgQmx1ZWIgZnJvbSAnYmx1ZWJpcmQnXHJcbmltcG9ydCBUZXh0VXRpbCBmcm9tICcuLi91dGlsL3RleHQnXHJcblxyXG5leHBvcnQgZGVmYXVsdCBjbGFzcyBJdGVtQ29udHJvbGxlciB7XHJcbiAgYXN5bmMgaW5pdCAocGx1Zykge1xyXG4gICAgdGhpcy5JdGVtcyA9IGF3YWl0IE1vbmdvQ29sbGVjdGlvbi5nZXQocGx1ZywgJ2l0ZW1zJylcclxuICAgIHRoaXMuUHJvZHVjdHMgPSBhd2FpdCBNb25nb0NvbGxlY3Rpb24uZ2V0KHBsdWcsICdwcm9kdWN0cycpXHJcbiAgfVxyXG5cclxuICBhc3luYyBnZXRTdG9jayAoaXRlbUlkKSB7XHJcbiAgICBsZXQgaXRlbSA9IGF3YWl0IHRoaXMuSXRlbXMuZmluZE9uZSh7XHJcbiAgICAgIF9pZDogaXRlbUlkXHJcbiAgICB9LCB7XHJcbiAgICAgIHByb2plY3Rpb246IHtcclxuICAgICAgICAncHJvZHVjdCc6IDFcclxuICAgICAgfVxyXG4gICAgfSlcclxuICAgIGxldCBwcm9kdWN0U2V0ID0gaXRlbS5wcm9kdWN0XHJcblxyXG4gICAgLy8gcHJvZHVjdCAqIDwtPiAqIGl0ZW1cclxuICAgIC8vIHByb2R1Y3RbXTog6KSH5pWw44Gu5ZWG5ZOB44KSMeODkeODg+OCseODvOOCuOOBqOOBl+OBpuiyqeWjslxyXG4gICAgLy8gcHJvZHVjdFt7aWRzOls8T2JqZWN0SWQ+XSxzZXQ6PE51bWJlcj59XTog55Ww44Gq44KL5rWB6YCa57WM6Lev44CB55Ww44Gq44KL5Y6f5L6h44O75LuV5YWl44KM5YCkXHJcbiAgICAvLyBpdGVtOiDnlbDjgarjgovjgrvjg7zjg6vjgIHosqnlo7LlvaLmhYtcclxuICAgIC8vIOKAuyBwcm9kdWN0IOOBi+OCieOBr+OAgeiyqeWjsuWPr+iDveOBquWcqOW6q+OAgeWIqeebiuioiOeul+OBruOBn+OCgeOBruaDheWgseOCkuW+l+OCi1xyXG5cclxuICAgIGxldCBxdWFudGl0aWVzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBwcm9kdWN0UmVmIG9mIHByb2R1Y3RTZXQpIHtcclxuICAgICAgbGV0IHByZFF1YW50aXR5ID0gMFxyXG5cclxuICAgICAgZm9yIChsZXQgaWQgb2YgcHJvZHVjdFJlZi5pZHMpIHtcclxuICAgICAgICBsZXQgcHJvZHVjdCA9IGF3YWl0IHRoaXMuUHJvZHVjdHMuZmluZE9uZSh7XHJcbiAgICAgICAgICBfaWQ6IGlkXHJcbiAgICAgICAgfSwge1xyXG4gICAgICAgICAgcHJvamVjdGlvbjoge1xyXG4gICAgICAgICAgICAnc3RvY2snOiAxXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSlcclxuICAgICAgICBsZXQgc3RvY2tBcnJheSA9IHByb2R1Y3Quc3RvY2tcclxuXHJcbiAgICAgICAgLy8g5Y2Y57SU44Gr44GZ44G544Gm44Gu5Zyo5bqr5ZWG5ZOB44CB55+t5pyf6ZaT5Y+W44KK5a+E44Gb5Y+v6IO95ZWG5ZOB44KS5ZCI566XXHJcbiAgICAgICAgZm9yIChsZXQgc3RvY2sgb2Ygc3RvY2tBcnJheSkge1xyXG4gICAgICAgICAgcHJkUXVhbnRpdHkgKz0gc3RvY2sucXVhbnRpdHlcclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuXHJcbiAgICAgIC8vIOWVhuWTgShpdGVtKeOBruWcqOW6q+aVsCA9IOijveWTgeWcqOW6q+aVsChwcmRRdWFudGl0eSkgLyDlv4XopoHjgrvjg4Pjg4jmlbAocHJvZHVjdFJlZi5zZXQpXHJcbiAgICAgIHF1YW50aXRpZXMucHVzaChNYXRoLmZsb29yKHByZFF1YW50aXR5IC8gcHJvZHVjdFJlZi5zZXQpKVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCu+ODg+ODiOWVhuWTgeOBruWgtOWQiOOAgeS4gOeVquWwkeOBquOBhOWVhuWTgeaVsOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IHF1YW50aXR5ID0gTWF0aC5taW4uYXBwbHkobnVsbCwgcXVhbnRpdGllcylcclxuXHJcbiAgICByZXR1cm4gcXVhbnRpdHlcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavjgIFcclxuICAgKiDjgqLjg4Pjg5fjg63jg7zjg4nmuIjjgb/nlLvlg4/jgpLplqLpgKPku5jjgZHjgovjgIJcclxuICAgKlxyXG4gICAqIOODoeODvOOCq+ODvOODouODh+ODq+OBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog54m55a6a44Gu5bGe5oCn77yI44Kr44Op44O844Gq44Gp77yJ44Gr5YWx6YCa44Gu55S75YOP44KS5LiA5ous44Gn6Zai6YCj5LuY44GR44Gf44GE5aC05ZCI44CBXHJcbiAgICogY2xhc3Mx44Gr5YCk44KS5oyH5a6a44GX44CBY2xhc3My5byV5pWw44KS5oyH5a6a44Gb44Ga44Gr5a6f6KGM44GZ44KL44CCXHJcbiAgICog44KC44GXY2xhc3My44Gu44G/5oyH5a6a44GX44Gf44GE5aC05ZCI44GvY2xhc3Mx44GrbnVsbOOCkuaMh+WumuOBmeOCi+OAglxyXG4gICAqXHJcbiAgICog5L6L77yaSkstMTAw44GuQkxBQ0vjga7llYblk4HnlLvlg4/jgpJcclxuICAgKiDjgZnjgbnjgabjga7jgrXjgqTjgrrvvIhTLE0sTCxYTCwyWEwsM1hMLDRYTOKApu+8ieOBq+mWoumAo+S7mOOBkeOCi+WgtOWQiFxyXG4gICAqIHNldEltYWdlKCB1cGxvYWRJZCwgJ0pLLTEwMCcsICdCTEFDSycgKTtcclxuICAgKlxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB1cGxvYWRJZCDkuIDlm57jga7jgqLjg4Pjg5fjg63jg7zjg4nnlLvlg4/jgpLmnZ/jga3jgabjgYTjgotJROOAgm1ldGVvcuODh+ODvOOCv+ODmeODvOOCueOAgVVwbG9hZHPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjg4njgq3jg6Xjg6Hjg7Pjg4jjga51cGxvYWRJZOODl+ODreODkeODhuOCo1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgc2V0SW1hZ2UgKHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44Gu5oOF5aCx5Y+W5b6XXHJcbiAgICBsZXQgaW1hZ2VzID0gVXBsb2Fkcy5maW5kKHtcclxuICAgICAgdXBsb2FkSWQ6IHVwbG9hZElkXHJcbiAgICB9KS5mZXRjaCgpLm1hcCgodikgPT4gdi51cGxvYWRlZEZpbGVOYW1lKVxyXG5cclxuICAgIC8vIOaknOe0ouadoeS7tuOBrue1hOOBv+eri+OBplxyXG4gICAgbGV0IGZpbHRlciA9IHt9XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbFxyXG4gICAgaWYgKGNsYXNzMSkgZmlsdGVyLmNsYXNzMV92YWx1ZSA9IGNsYXNzMVxyXG4gICAgaWYgKGNsYXNzMikgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMlxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlciwge1xyXG4gICAgICAgICRwdXNoOiB7XHJcbiAgICAgICAgICBpbWFnZXM6IHtcclxuICAgICAgICAgICAgJGVhY2g6IGltYWdlc1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG5cclxuICAgIC8vIOeZu+mMsuOBl+OBn+eUu+WDj+ODleOCoeOCpOODq+WQjeS4gOimp1xyXG4gICAgcmV0dXJuIGltYWdlc1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+eZu+mMsuOBleOCjOOBpuOBhOOCi+eUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IG1vZGVsIOODoeODvOOCq+ODvOODouODh+ODq1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczEg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMiDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKi9cclxuICBhc3luYyBjbGVhbkltYWdlIChtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCkge1xyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge31cclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsXHJcbiAgICBpZiAoY2xhc3MxKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxXHJcbiAgICBpZiAoY2xhc3MyKSBmaWx0ZXIuY2xhc3MyX3ZhbHVlID0gY2xhc3MyXHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLCB7XHJcbiAgICAgICAgJHNldDoge1xyXG4gICAgICAgICAgaW1hZ2VzOiBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICog5oyH5a6a44Gu5ZWG5ZOB44Gr6Zai6YCj44GZ44KL5ZWG5ZOB576k44Gu5bGe5oCn5Yil44Gu5ZWG5ZOB5oOF5aCx44KS6L+U44GZ44CCXHJcbiAgICpcclxuICAgKiDlvJXmlbDjgajjgZfjgablj5fjgZHlj5bjgotpdGVt44Gv5Lu75oSP44Gu5ZWG5ZOB5oOF5aCx44CCXHJcbiAgICogaXRlbeOBq+mWoumAo+OBmeOCi+WVhuWTgee+pOOBq+OBpOOBhOOBpuW/heimgeOBquaDheWgseOCkuaVtOeQhuOBl+i/lOOBmeOAglxyXG4gICAqXHJcbiAgICogcHJvamVjdOOBq+WPgueFp+OBl+OBn+OBhOWVhuWTgeaDheWgseODleOCo+ODvOODq+ODieOCkuWumue+qeOBmeOCi+OAglxyXG4gICAqIOODoeOCveODg+ODieOBruWRvOOBs+WHuuOBl+aZguOBq+W/heimgeOBq+W/nOOBmOOBpnByb2plY3TjgpLoqK3lrprjgZnjgovjgIJcclxuICAgKlxyXG4gICAqIOS9leOBq+azqOebruOBl+OBpuWVhuWTgeOBrumWoumAo+aAp+OCkuaknOWHuuOBmeOCi+OBi+OBr+OAgeOBk+OBruODoeOCveODg+ODieWGheOBp+Wumue+qeOBmeOCi+OAglxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGl0ZW1cclxuICAgKiBAcGFyYW0ge09iamVjdH0gcHJvamVjdFxyXG4gICAqL1xyXG4gIGFzeW5jIGdldFZhcmlhdGlvbiAoaXRlbSwgcHJvamVjdCkge1xyXG4gICAgLyoqXHJcbiAgICAgKiBhZ2dyZWdhdGlvbuioreWumlxyXG4gICAgICpcclxuICAgICAqIGxhYmVsOiDlsZ7mgKflkI3vvIjphY3pgIHmlrnms5XjgIHjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganvvIlcclxuICAgICAqIGN1cnJlbnQ6IOaMh+WumuOBleOCjOOBn+OCouOCpOODhuODoO+8iGl0ZW3vvInjgYzoqbLlvZPjgZnjgovpoIXnm65cclxuICAgICAqIHBvcmplY3Q6IOODkOODquOCqOODvOOCt+ODp+ODs+aknOe0ouOBruOCreODvOOBqOOBquOCi2l0ZW3lhoXjga7jg5XjgqPjg7zjg6vjg4nlkI0gJFvjg5XjgqPjg7zjg6vjg4nlkI1d5b2i5byPXHJcbiAgICAgKiBxdWVyeTogYWdncmVnYXRpb27lr77osaHjgajjgZnjgovjg4njgq3jg6Xjg6Hjg7Pjg4jjga7mpJzntKLmnaHku7ZcclxuICAgICAqL1xyXG4gICAgbGV0IHNldCA9IFt7XHJcbiAgICAgIGxhYmVsOiAn6YWN6YCB5pa55rOVJyxcclxuICAgICAgY3VycmVudDogaXRlbS5kZWxpdmVyeSxcclxuICAgICAgcHJvamVjdDoge1xyXG4gICAgICAgIHZhbHVlOiAnJGRlbGl2ZXJ5J1xyXG4gICAgICB9LFxyXG4gICAgICBxdWVyeToge1xyXG4gICAgICAgIGNsYXNzMV92YWx1ZTogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogaXRlbS5jbGFzczFfbmFtZSxcclxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczFfdmFsdWUsXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRjbGFzczFfdmFsdWUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgICAgY2xhc3MyX3ZhbHVlOiBpdGVtLmNsYXNzMl92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9LFxyXG4gICAge1xyXG4gICAgICBsYWJlbDogaXRlbS5jbGFzczJfbmFtZSxcclxuICAgICAgY3VycmVudDogaXRlbS5jbGFzczJfdmFsdWUsXHJcbiAgICAgIHByb2plY3Q6IHtcclxuICAgICAgICB2YWx1ZTogJyRjbGFzczJfdmFsdWUnXHJcbiAgICAgIH0sXHJcbiAgICAgIHF1ZXJ5OiB7XHJcbiAgICAgICAgZGVsaXZlcnk6IGl0ZW0uZGVsaXZlcnksXHJcbiAgICAgICAgY2xhc3MxX3ZhbHVlOiBpdGVtLmNsYXNzMV92YWx1ZVxyXG4gICAgICB9XHJcbiAgICB9XHJcbiAgICBdXHJcblxyXG4gICAgbGV0IGF0dHJzID0gW11cclxuXHJcbiAgICBmb3IgKGxldCBzIG9mIHNldCkge1xyXG4gICAgICBhdHRycy5wdXNoKHtcclxuICAgICAgICB2YXJpYXRpb25zOiBhd2FpdCB0aGlzLkl0ZW1zLmFnZ3JlZ2F0ZShcclxuICAgICAgICAgIFt7XHJcbiAgICAgICAgICAgICRtYXRjaDogT2JqZWN0LmFzc2lnbihzLnF1ZXJ5LCB7XHJcbiAgICAgICAgICAgICAgbW9kZWw6IGl0ZW0ubW9kZWxcclxuICAgICAgICAgICAgfSlcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICRwcm9qZWN0OiBPYmplY3QuYXNzaWduKHMucHJvamVjdCwgcHJvamVjdClcclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgICRzb3J0OiB7XHJcbiAgICAgICAgICAgICAgX2lkOiAxXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICAgIF1cclxuICAgICAgICApLnRvQXJyYXkoKSxcclxuICAgICAgICBwcm9wczogc1xyXG4gICAgICB9KVxyXG4gICAgfVxyXG5cclxuICAgIGZvciAobGV0IGF0dHIgb2YgYXR0cnMpIHtcclxuICAgICAgZm9yIChsZXQgdiBvZiBhdHRyLnZhcmlhdGlvbnMpIHtcclxuICAgICAgICB2LnN0b2NrID0gYXdhaXQgdGhpcy5nZXRTdG9jayh2Ll9pZClcclxuICAgICAgfVxyXG4gICAgfVxyXG5cclxuICAgIHJldHVybiBhdHRyc1xyXG4gIH1cclxuXHJcbiAgLy8g44Oi44OH44Or44Kv44Op44K55b2i5byP44KS5L2c44KLXHJcbiAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gIGFzeW5jIGdldE1vZGVsQ2xhc3MgKGFyZykge1xyXG4gICAgbGV0IGl0ZW1cclxuICAgIC8vIGl0ZW0g44GM5paH5a2X5YiX44Gq44KJ44CBaXRlbeOBr+S7u+aEj+OBruOCquODluOCuOOCp+OCr+ODiElE44Gu5pyr5bC+44GL44KJ5Lu75oSP44Gu5qGB5pWw44GuMTbpgLLmlbBcclxuICAgIGlmICh0eXBlb2YgYXJnID09PSAnc3RyaW5nJykge1xyXG4gICAgICBsZXQgZXhwID0gbmV3IFJlZ0V4cChgJHthcmd9JGApXHJcbiAgICAgIGxldCBjdXIgPSB0aGlzLkl0ZW1zLmZpbmQoe30sIHtcclxuICAgICAgICBwcm9qZWN0aW9uOiB7XHJcbiAgICAgICAgICBtb2RlbDogMSxcclxuICAgICAgICAgIGNsYXNzMV92YWx1ZTogMSxcclxuICAgICAgICAgIGNsYXNzMl92YWx1ZTogMVxyXG4gICAgICAgIH1cclxuICAgICAgfSlcclxuXHJcbiAgICAgIHdoaWxlICgxKSB7XHJcbiAgICAgICAgdHJ5IHtcclxuICAgICAgICAgIGl0ZW0gPSBhd2FpdCBjdXIubmV4dCgpXHJcbiAgICAgICAgICBsZXQgbWF0Y2ggPSBhd2FpdCBpdGVtLl9pZC50b0hleFN0cmluZygpLm1hdGNoKGV4cClcclxuICAgICAgICAgIGlmIChtYXRjaCkge1xyXG4gICAgICAgICAgICBicmVha1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgIC8vIOipsuW9k+OBmeOCi2l0ZW3jg4fjg7zjgr/jgYzjgarjgYRcclxuICAgICAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICAgICAgICByZXR1cm4gYXJnXHJcbiAgICAgICAgfVxyXG4gICAgICB9XHJcbiAgICAgIGN1ci5jbG9zZSgpXHJcbiAgICB9IGVsc2Uge1xyXG4gICAgICBpdGVtID0gYXJnXHJcbiAgICB9XHJcblxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuICAgIHJldHVybiBtb2RlbENsYXNzLmpvaW4oJy8nKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlMyAoY3JlYXRvcklkLCBpdGVtKSB7XHJcbiAgICAvLyDlgKTlpInmj5tcclxuICAgIGxldCBjb252RGVsaXYgPSAoZGVsaXZlcnkpID0+IGRlbGl2ZXJ5ID09PSAn44KG44GG44OR44Kx44OD44OIJyA/ICfjg53jgrnjg4jmipXlh70nIDogZGVsaXZlcnlcclxuXHJcbiAgICAvLyBwcm9kdWN0X2lkXHJcbiAgICBsZXQgcHJvZHVjdElkID0gbnVsbFxyXG4gICAgbGV0IG1vZGVsQ2xhc3MgPSBbXVxyXG5cclxuICAgIC8vIOS4i+iomOOBruW9ouW8j+OCkuS9nOOCi1xyXG4gICAgLy8gW+ODoeODvOOCq+ODvOOCs+ODvOODiV0vW+WxnuaApzHvvIjjgqvjg6njg7zjgarjganvvIldL1vlsZ7mgKcy77yI44K144Kk44K644Gq44Gp77yJXVxyXG4gICAgaWYgKGl0ZW0ubW9kZWwpIG1vZGVsQ2xhc3MucHVzaChpdGVtLm1vZGVsKVxyXG4gICAgaWYgKGl0ZW0uY2xhc3MxX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczFfdmFsdWUpXHJcbiAgICBpZiAoaXRlbS5jbGFzczJfdmFsdWUpIG1vZGVsQ2xhc3MucHVzaChpdGVtLmNsYXNzMl92YWx1ZSlcclxuXHJcbiAgICAvLyDllYblk4HnqK7liKXjgpLlibLjgorlvZPjgabjgotcclxuICAgIGxldCBwcm9kdWN0VHlwZUlkXHJcbiAgICBzd2l0Y2ggKGl0ZW0uZGVsaXZlcnkpIHtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzpcclxuICAgICAgICBwcm9kdWN0VHlwZUlkID0gMVxyXG4gICAgICAgIGJyZWFrXHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6XHJcbiAgICAgICAgcHJvZHVjdFR5cGVJZCA9IDJcclxuICAgICAgICBicmVha1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHByb2R1Y3RUeXBlSWQgPSAxXHJcbiAgICAgICAgYnJlYWtcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCB0YWdzID0gW11cclxuICAgIHN3aXRjaCAoaXRlbS5kZWxpdmVyeSkge1xyXG4gICAgICBjYXNlICflroXphY3kvr8nOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgICBjYXNlICfjgobjgYbjg5HjgrHjg4Pjg4gnOlxyXG4gICAgICAgIHRhZ3MucHVzaCh7XHJcbiAgICAgICAgICB0YWc6IDUsXHJcbiAgICAgICAgICBzZXQ6ICdvbidcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICB0YWc6IDQsXHJcbiAgICAgICAgICBzZXQ6ICdvZmYnXHJcbiAgICAgICAgfSlcclxuICAgICAgICBicmVha1xyXG4gICAgfVxyXG5cclxuICAgIC8vIOWVhuWTgeWIpemAgeaWmeOCkuioreWumuOBmeOCi1xyXG4gICAgbGV0IGRlbGl2ZXJ5RmVlID0gbnVsbFxyXG4gICAgc3dpdGNoIChpdGVtLmRlbGl2ZXJ5KSB7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6XHJcbiAgICAgICAgZGVsaXZlcnlGZWUgPSBudWxsXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgY2FzZSAn44KG44GG44OR44Kx44OD44OIJzpcclxuICAgICAgICBkZWxpdmVyeUZlZSA9IDI0MFxyXG4gICAgICAgIGJyZWFrXHJcbiAgICB9XHJcblxyXG4gICAgLy9cclxuICAgIC8vIOmhp+WuouWQkeOBkeODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgemBuOaKnuapn+iDveOBruWun+ijhVxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgYXR0cnMgPSBhd2FpdCB0aGlzLmdldFZhcmlhdGlvbihpdGVtLCB7XHJcbiAgICAgIHByb2R1Y3RfaWQ6ICckbWFsbC5zaGFyYWt1U2hvcC5wcm9kdWN0X2lkJ1xyXG4gICAgfSlcclxuXHJcbiAgICAvLyBIVE1MIOODkOODquOCqOODvOOCt+ODp+ODs+WVhuWTgeOBlOOBqOOBruODquODs+OCr+S7mOOBjeODnOOCv+ODs+OCkuihqOekuuOBmeOCi1xyXG5cclxuICAgIC8vIOWApOOBruWkieaPm1xyXG4gICAgYXR0cnMgPSBhdHRycy5tYXAoXHJcbiAgICAgIChhdHRyKSA9PiB7XHJcbiAgICAgICAgYXR0ci5wcm9wcy5jdXJyZW50ID0gY29udkRlbGl2KGF0dHIucHJvcHMuY3VycmVudClcclxuICAgICAgICBhdHRyLnZhcmlhdGlvbnMgPSBhdHRyLnZhcmlhdGlvbnMubWFwKFxyXG4gICAgICAgICAgKHZhcmlhdGlvbikgPT4ge1xyXG4gICAgICAgICAgICB2YXJpYXRpb24udmFsdWUgPSBjb252RGVsaXYodmFyaWF0aW9uLnZhbHVlKVxyXG4gICAgICAgICAgICByZXR1cm4gdmFyaWF0aW9uXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKVxyXG4gICAgICAgIHJldHVybiBhdHRyXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICAvLyBIVE1M55Sf5oiQXHJcbiAgICBsZXQgdmFyaWF0aW9uSHRtbCA9XHJcbiAgICAgIGF0dHJzLm1hcChcclxuICAgICAgICAoYXR0cikgPT5cclxuICAgICAgICAgICc8ZGl2IGNsYXNzPVwiY29udGFpbmVyLWZsdWlkXCI+JyArXHJcbiAgICAgICAgYDxkaXYgY2xhc3M9XCJyb3dcIj5gICtcclxuICAgICAgICBgPGRpdiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgY2xhc3M9XCJidG4gYnRuLWluZm8gYnRuLWJsb2NrIGJ0bi14c1wiPmAgK1xyXG4gICAgICAgIGA8c3Ryb25nPiR7YXR0ci5wcm9wcy5sYWJlbH08L3N0cm9uZz5gICtcclxuICAgICAgICBgPC9kaXY+YCArXHJcbiAgICAgICAgYXR0ci52YXJpYXRpb25zLm1hcChcclxuICAgICAgICAgICh2YXJpYXRpb24pID0+IHtcclxuICAgICAgICAgICAgaWYgKGF0dHIucHJvcHMuY3VycmVudCA9PT0gdmFyaWF0aW9uLnZhbHVlKSB7XHJcbiAgICAgICAgICAgICAgLy8g6KGo56S65Lit44Gu5ZWG5ZOB44Oc44K/44OzXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1zdWNjZXNzIGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIj48c3Ryb25nPiR7dmFyaWF0aW9uLnZhbHVlfTwvc3Ryb25nPjwvYnV0dG9uPmBcclxuICAgICAgICAgICAgfSBlbHNlXHJcbiAgICAgICAgICAgIGlmICh2YXJpYXRpb24uc3RvY2sgPiAwKSB7XHJcbiAgICAgICAgICAgICAgLy8g6LKp5aOy5Y+v6IO95ZWG5ZOB44Gu44Oc44K/44OzXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YSBocmVmPVwiL3Byb2R1Y3RzL2RldGFpbC8ke3ZhcmlhdGlvbi5wcm9kdWN0X2lkfVwiPjxidXR0b24gY2xhc3M9XCJidG4gYnRuLWRlZmF1bHQgYnRuLXNtIGJ0bi1pdGVtLWNsYXNzLXNlbGVjdFwiPiR7dmFyaWF0aW9uLnZhbHVlfTwvYnV0dG9uPjwvYT5gXHJcbiAgICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgICAgLy8g6LKp5aOy5LiN5Y+v6IO95ZWG5ZOB44Gu44Oc44K/44Oz77yI5Zyo5bqr44Gq44GX77yJXHJcbiAgICAgICAgICAgICAgcmV0dXJuIGA8YnV0dG9uIGNsYXNzPVwiYnRuIGJ0bi1kZWZhdWx0IGJ0bi1zbSBidG4taXRlbS1jbGFzcy1zZWxlY3RcIiBzdHlsZT1cIm9wYWNpdHk6MC4zXCIgZGF0YS10b2dnbGU9XCJ0b29sdGlwXCIgdGl0bGU9XCLlnKjluqvjgYzjgZTjgZbjgYTjgb7jgZvjgpNcIj4ke3ZhcmlhdGlvbi52YWx1ZX08L2J1dHRvbj5gXHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuICAgICAgICApLmpvaW4oJycpICtcclxuICAgICAgICAnPC9kaXY+JyArXHJcbiAgICAgICAgJzwvZGl2PidcclxuICAgICAgKS5qb2luKCcnKVxyXG5cclxuICAgIGxldCBkZXNjcmlwdGlvbkRldGFpbCA9IGBcclxuICAgIDxzbWFsbD7igLsg6YWN6YCB5pa55rOV44O744Kr44Op44O844O744K144Kk44K644Gv5LiL6KiY44GL44KJ44GK6YG444Gz44GP44Gg44GV44GE44CCPC9zbWFsbD5cclxuICAgICR7dmFyaWF0aW9uSHRtbH1cclxuICAgIGBcclxuXHJcbiAgICAvLyDllYblk4Hjg4fjg7zjgr/jgpLkvZzjgotcclxuICAgIGxldCBkYXRhID0ge1xyXG4gICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0SWQsXHJcbiAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JJZCxcclxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7Y29udkRlbGl2KGl0ZW0uZGVsaXZlcnkpfSAke2l0ZW0ubmFtZX0ke2l0ZW0uamFuX2NvZGUgPyAnICcgKyBpdGVtLmphbl9jb2RlIDogJyd9YCxcclxuICAgICAgZGVzY3JpcHRpb25fZGV0YWlsOiBkZXNjcmlwdGlvbkRldGFpbCxcclxuICAgICAgLy8gZnJlZV9hcmVhOiBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVGcmVlQXJlYShpdGVtKSxcclxuICAgICAgcHJvZHVjdF9jb2RlOiBtb2RlbENsYXNzLmpvaW4oJy8nKSxcclxuICAgICAgcHJpY2UwMTogaXRlbS5yZXRhaWxfcHJpY2UsXHJcbiAgICAgIC8vIHByaWNlMDI6IGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZVByaWNlMDIoaXRlbSksXHJcbiAgICAgIC8vIGltYWdlczogYXdhaXQgdGhpcy5jb252ZXJ0SXRlbUN1YmUzY3JlYXRlSW1hZ2VzKGl0ZW0pLFxyXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RUeXBlSWQsXHJcbiAgICAgIHRhZ3M6IHRhZ3MsXHJcbiAgICAgIGRlbGl2ZXJ5X2ZlZTogZGVsaXZlcnlGZWVcclxuICAgIH1cclxuXHJcbiAgICBPYmplY3QuYXNzaWduKGRhdGEsIGF3YWl0IHRoaXMuY29udmVydEl0ZW1DdWJlM2NyZWF0ZUZyZWVBcmVhKGl0ZW0pKVxyXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyKGl0ZW0pKVxyXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBhd2FpdCB0aGlzLmNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVJbWFnZXMoaXRlbSkpXHJcblxyXG4gICAgT2JqZWN0LmFzc2lnbihkYXRhLCBpdGVtLm1hbGwuc2hhcmFrdVNob3ApXHJcblxyXG4gICAgcmV0dXJuIGRhdGFcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVGcmVlQXJlYSAoaXRlbSkge1xyXG4gICAgbGV0IGZyZWVBcmVhID0gJydcclxuICAgIC8vIOWVhuWTgeaDheWgseODhuOCreOCueODiOOCkuiomOi8ieOBmeOCi1xyXG4gICAgZnJlZUFyZWEgKz0gaXRlbS5kZXNjcmlwdGlvblxyXG4gICAgLy8gMueVquebruS7pemZjeOBrueUu+WDj+OCkuODleODquODvOOCqOODquOCouOBq+iomOi8ieOBmeOCi1xyXG4gICAgZm9yIChsZXQgaSA9IDE7IGkgPCBpdGVtLmltYWdlcy5sZW5ndGg7IGkrKykge1xyXG4gICAgICBmcmVlQXJlYSArPSBgPGltZyBzcmM9XCIvdXBsb2FkL3NhdmVfaW1hZ2UvJHtpdGVtLmltYWdlc1tpXX1cIj48YnI+YFxyXG4gICAgfVxyXG4gICAgLy8g5oOF5aCx44Gu44Kv44Oq44KiXHJcbiAgICBmcmVlQXJlYSArPSAnICdcclxuICAgIHJldHVybiB7ZnJlZV9hcmVhOiBmcmVlQXJlYX1cclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtQ3ViZTNjcmVhdGVQcmljZTAyIChpdGVtKSB7XHJcbiAgICAvLyDkvqHmoLzjgpLov5TjgZlcclxuICAgIHJldHVybiB7cHJpY2UwMjogaXRlbS5tYWxsLnNoYXJha3VTaG9wLnByaWNlfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29udmVydEl0ZW1DdWJlM2NyZWF0ZUltYWdlcyAoaXRlbSkge1xyXG4gICAgLy8g55S75YOP44Oq44K544OI44Gu44GG44GhMeOBpOOCgeOBoOOBkeOCkui/lOOBmVxyXG4gICAgbGV0IGFyciA9IHR5cGVvZiBpdGVtLmltYWdlc1swXSA9PT0gJ3VuZGVmaW5lZCcgPyBbXSA6IFsgaXRlbS5pbWFnZXNbMF0gXVxyXG4gICAgcmV0dXJuIHsgaW1hZ2VzOiBhcnIgfVxyXG4gIH1cclxuXHJcbiAgLy8g44Ok44OV44Kq44Kv44OG44Oz44OX44Os44O844OI44G444Gu5aSJ5o+bXHJcbiAgYXN5bmMgY29udmVydEl0ZW1ZYXVjdCAoZGVmLCBpdGVtKSB7XHJcbiAgICBjb25zdCBpZExlbmd0aCA9IDIwXHJcbiAgICBjb25zdCB0aXRsZUxlbmd0aCA9IDEzMFxyXG5cclxuICAgIGxldCB5YXVjdCA9IHt9XHJcbiAgICAvLyDjg6Tjg5Xjgqrjgq/jg4bjg7Pjg5fjg6zjg7zjg4jjga7liJ3mnJ/lgKTvvIjjgobjgYbjg5HjgrHjg4Pjg4jjg7vlroXphY3kvr/jgafnlbDjgarjgovvvIlcclxuICAgIHlhdWN0ID0gSlNPTi5wYXJzZShKU09OLnN0cmluZ2lmeShkZWZbaXRlbS5kZWxpdmVyeV0pKVxyXG5cclxuICAgIC8vIOeUu+WDj+OBruiomOi/sFxyXG4gICAgY29uc3QgaW1nUHJlZml4ID0gJ+eUu+WDjydcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaXRlbS5pbWFnZXMubGVuZ3RoOyBpKyspIHtcclxuICAgICAgeWF1Y3RbaW1nUHJlZml4ICsgKGkgKyAxKV0gPSBpdGVtLmltYWdlc1tpXVxyXG4gICAgfVxyXG5cclxuICAgIC8vIOOCv+OCpOODiOODq1xyXG4gICAgeWF1Y3RbJ+OCq+ODhuOCtOODqiddID0gaXRlbS5tYWxsLnlhdWN0LmNhdGVnb3J5XHJcbiAgICB5YXVjdFsn44K/44Kk44OI44OrJ10gPSBUZXh0VXRpbC5zdWJzdHI4KGAke2F3YWl0IHRoaXMuZ2V0TW9kZWxDbGFzcyhpdGVtKX0gJHtpdGVtLmRlbGl2ZXJ5fSAke2l0ZW0ubmFtZX1gLCB0aXRsZUxlbmd0aClcclxuICAgIHlhdWN0Wyfplovlp4vkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfljbPmsbrkvqHmoLwnXSA9IGl0ZW0uc2FsZXNfcHJpY2VcclxuICAgIHlhdWN0WyfnrqHnkIbnlarlj7cnXSA9IGl0ZW0uX2lkLnRvSGV4U3RyaW5nKCkuc2xpY2UoLWlkTGVuZ3RoKVxyXG4gICAgeWF1Y3RbJ+iqrOaYjiddID0gaXRlbS5kZXNjcmlwdGlvblxyXG4gICAgeWF1Y3RbJ0pBTuOCs+ODvOODieODu0lTQk7jgrPjg7zjg4knXSA9IGl0ZW0uamFuX2NvZGVcclxuXHJcbiAgICByZXR1cm4geWF1Y3RcclxuICB9XHJcblxyXG4gIGFzeW5jIGNvbnZlcnRJdGVtV293bWFDcmVhdGVEZWxpdmVyeU1ldGhvZCAoaXRlbUNvZGUpIHtcclxuICAgIGxldCBpZCA9ICdtYWxsLndvd21hLml0ZW1Db2RlJ1xyXG4gICAgbGV0IHNldCA9ICdkZWxpdmVyeSdcclxuICAgIGxldCBtZXRyaWNzID0ge1xyXG4gICAgICAn44KG44GG44OR44Kx44OD44OIJzogWydQb3N0J10sXHJcbiAgICAgICflroXphY3kvr8nOiBbJ1lVLVBhY2snLCAnS2FuZ2Fyb28nXVxyXG4gICAgfVxyXG4gICAgLy8gZGVsaXZlcnlNZXRob2RTZXFcclxuXHJcbiAgICBsZXQgYWdnciA9IGF3YWl0IHRoaXMuSXRlbXMuYWdncmVnYXRlKFxyXG4gICAgICBbXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgJG1hdGNoOiB7XHJcbiAgICAgICAgICAgIFtpZF06IGl0ZW1Db2RlXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfSxcclxuICAgICAgICB7XHJcbiAgICAgICAgICAkZ3JvdXA6IHtcclxuICAgICAgICAgICAgX2lkOiBgJCR7aWR9YCxcclxuICAgICAgICAgICAgW3NldF06IHsgJGFkZFRvU2V0OiBgJCR7c2V0fWAgfVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0sXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgJHByb2plY3Q6IHtcclxuICAgICAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgICAgICBpdGVtQ29kZTogJyRfaWQnLFxyXG4gICAgICAgICAgICBbc2V0XTogYCQke3NldH1gXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICBdXHJcbiAgICApLnRvQXJyYXkoKVxyXG5cclxuICAgIGxldCBhY2NlcHREZWxpdiA9IFtdXHJcbiAgICBmb3IgKGxldCBkZWwgb2YgYWdnclswXS5kZWxpdmVyeSkge1xyXG4gICAgICBhY2NlcHREZWxpdiA9IGFjY2VwdERlbGl2LmNvbmNhdChtZXRyaWNzW2Ake2RlbH1gXSlcclxuICAgIH1cclxuICAgIGxldCBkZWxpdmVyeU1ldGhvZCA9IG5ldyBBcnJheSg1KVxyXG4gICAgZm9yIChsZXQgaSA9IDA7IGkgPCBkZWxpdmVyeU1ldGhvZC5sZW5ndGg7IGkrKykge1xyXG4gICAgICBsZXQgaWQgPSB0eXBlb2YgYWNjZXB0RGVsaXZbaV0gPT09ICd1bmRlZmluZWQnID8gJ05VTEwnIDogYWNjZXB0RGVsaXZbaV1cclxuICAgICAgZGVsaXZlcnlNZXRob2RbaV0gPSB7ZGVsaXZlcnlNZXRob2RTZXE6IGkgKyAxLCBkZWxpdmVyeU1ldGhvZElkOiBpZH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge2RlbGl2ZXJ5TWV0aG9kOiBkZWxpdmVyeU1ldGhvZH1cclxuICB9XHJcblxyXG4gIC8vXHJcbiAgLy8gUm9ib3QtaW4g5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+344Gu55m76Yyy44Gu44Gf44KB44Gu44OH44O844K/44KS5L2c44KLXHJcblxyXG4gIHN0YXRpYyBhc3luYyBjb252ZXJ0SXRlbVJvYm90aW4gKGl0ZW0pIHtcclxuICAgIGNvbnN0IG5ld0lkID0gaXRlbS5faWQudG9IZXhTdHJpbmcoKVxyXG4gICAgbGV0IHJvYm90aW5JdGVtID0ge1xyXG4gICAgICBpdGVtOiB7XHJcbiAgICAgICAgJ+OCs+ODs+ODiOODreODvOODq+OCq+ODqeODoCc6ICduJyxcclxuICAgICAgICAn5paw6KaP55m76YyySUQnOiBuZXdJZCxcclxuICAgICAgICAn5ZWG5ZOBSUQnOiBudWxsLFxyXG4gICAgICAgICfllYblk4HlkI0nOiBpdGVtLm5hbWUsXHJcbiAgICAgICAgJ+imj+agvCc6ICfjgarjgZcnXHJcbiAgICAgIH0sXHJcbiAgICAgIHNlbGVjdDoge1xyXG4gICAgICAgICfjgrPjg7Pjg4jjg63jg7zjg6vjgqvjg6njg6AnOiAnbicsXHJcbiAgICAgICAgJ+aWsOimj+eZu+mMsklEJzogbmV3SWQsXHJcbiAgICAgICAgJ+WVhuWTgUlEJzogbnVsbCxcclxuICAgICAgICAn5aSW6YOo6YCj5pC6SUQnOiBudWxsLFxyXG4gICAgICAgICflpJbpg6jpgKPmkLrllYblk4Hnlarlj7cnOiBgJHtpdGVtLm1vZGVsfSR7aXRlbS5jbGFzczFfdmFsdWUgPT09ICcnID8gJycgOiAnLycgKyBpdGVtLmNsYXNzMV92YWx1ZX0ke2l0ZW0uY2xhc3MyX3ZhbHVlID09PSAnJyA/ICcnIDogJy8nICsgaXRlbS5jbGFzczJfdmFsdWV9YFxyXG4gICAgICB9LFxyXG4gICAgICBzaG9wUzogW11cclxuICAgIH1cclxuXHJcbiAgICBjb25zdCBzaG9wUyA9IFJvYm90aW5TaG9wLmZpbmQoKVxyXG4gICAgc2hvcFMuZm9yRWFjaChcclxuICAgICAgc2hvcCA9PiB7XHJcbiAgICAgICAgY29uc3QgbW9kZWwgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AubW9kZWxQYXRofWBdXHJcbiAgICAgICAgY29uc3QgY2xhc3MxID0gaXRlbS5tYWxsW2Ake3Nob3AubmFtZX1gXVtgJHtzaG9wLmNsYXNzMVBhdGh9YF1cclxuICAgICAgICBjb25zdCBjbGFzczIgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AuY2xhc3MyUGF0aH1gXVxyXG5cclxuICAgICAgICByb2JvdGluSXRlbS5zaG9wUy5wdXNoKFxyXG4gICAgICAgICAge1xyXG4gICAgICAgICAgICAn44Kz44Oz44OI44Ot44O844Or44Kr44Op44OgJzogJ3UnLFxyXG4gICAgICAgICAgICAn5paw6KaP55m76YyySUQnOiBuZXdJZCxcclxuICAgICAgICAgICAgJ+WPl+azqOWVhuWTgUlEJzogbnVsbCxcclxuICAgICAgICAgICAgJ+W6l+iIl0lEJzogc2hvcFsn5bqX6IiXSUQnXSxcclxuICAgICAgICAgICAgJ+W6l+iIl+WQjSc6IG51bGwsXHJcbiAgICAgICAgICAgICflj5fms6jllYblk4Hnlarlj7cnOiBgJHttb2RlbH0ke2NsYXNzMX0ke2NsYXNzMn1gLFxyXG4gICAgICAgICAgICAn5pyJ5Yq544OV44Op44KwJzogJ+acieWKuSdcclxuICAgICAgICAgIH1cclxuICAgICAgICApXHJcbiAgICAgIH1cclxuICAgIClcclxuXHJcbiAgICByZXR1cm4gcm9ib3Rpbkl0ZW1cclxuICB9XHJcblxyXG4gIC8vXHJcbiAgLy8gUm9ib3QtaW4g5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+344Gu55m76Yyy44Gu44Gf44KB44Gu44OH44O844K/44KS5L2c44KLXHJcbiAgLy8g44Gd44GuMSBpdGVtLmNzdlxyXG5cclxuICBzdGF0aWMgY29udmVydEl0ZW1Sb2JvdGluSXRlbSAoaXRlbSkge1xyXG4gICAgcmV0dXJuIHtcclxuICAgICAgJ+OCs+ODs+ODiOODreODvOODq+OCq+ODqeODoCc6ICduJyxcclxuICAgICAgJ+aWsOimj+eZu+mMsklEJzogaXRlbS5faWQudG9IZXhTdHJpbmcoKSxcclxuICAgICAgJ+WVhuWTgUlEJzogbnVsbCxcclxuICAgICAgJ+WVhuWTgeWQjSc6IGl0ZW0ubmFtZSxcclxuICAgICAgJ+imj+agvCc6ICfjgarjgZcnXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvL1xyXG4gIC8vIFJvYm90LWluIOWklumDqOmAo+aQuuWVhuWTgeeVquWPt+OBrueZu+mMsuOBruOBn+OCgeOBruODh+ODvOOCv+OCkuS9nOOCi1xyXG4gIC8vIOOBneOBrjIgc2VsZWN0LmNzdlxyXG5cclxuICBzdGF0aWMgY29udmVydEl0ZW1Sb2JvdGluU2VsZWN0IChpdGVtKSB7XHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAn44Kz44Oz44OI44Ot44O844Or44Kr44Op44OgJzogJ24nLFxyXG4gICAgICAn5paw6KaP55m76YyySUQnOiBpdGVtLl9pZC50b0hleFN0cmluZygpLFxyXG4gICAgICAn5ZWG5ZOBSUQnOiBudWxsLFxyXG4gICAgICAn5aSW6YOo6YCj5pC6SUQnOiBudWxsLFxyXG4gICAgICAn5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+3JzogYCR7aXRlbS5tb2RlbH0ke2l0ZW0uY2xhc3MxX3ZhbHVlID09PSAnJyA/ICcnIDogJy8nICsgaXRlbS5jbGFzczFfdmFsdWV9JHtpdGVtLmNsYXNzMl92YWx1ZSA9PT0gJycgPyAnJyA6ICcvJyArIGl0ZW0uY2xhc3MyX3ZhbHVlfWBcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vXHJcbiAgLy8gUm9ib3QtaW4g5aSW6YOo6YCj5pC65ZWG5ZOB55Wq5Y+344Gu55m76Yyy44Gu44Gf44KB44Gu44OH44O844K/44KS5L2c44KLXHJcbiAgLy8g44Gd44GuMyBzZWxlY3RTaG9wLmNzdlxyXG5cclxuICBzdGF0aWMgY29udmVydEl0ZW1Sb2JvdGluU2VsZWN0U2hvcCAoc2hvcCwgaXRlbSkge1xyXG4gICAgY29uc3QgbW9kZWwgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AubW9kZWxQYXRofWBdXHJcbiAgICBjb25zdCBjbGFzczEgPSBpdGVtLm1hbGxbYCR7c2hvcC5uYW1lfWBdW2Ake3Nob3AuY2xhc3MxUGF0aH1gXVxyXG4gICAgY29uc3QgY2xhc3MyID0gaXRlbS5tYWxsW2Ake3Nob3AubmFtZX1gXVtgJHtzaG9wLmNsYXNzMlBhdGh9YF1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICAn44Kz44Oz44OI44Ot44O844Or44Kr44Op44OgJzogJ3UnLFxyXG4gICAgICAn5paw6KaP55m76YyySUQnOiBpdGVtLl9pZC50b0hleFN0cmluZygpLFxyXG4gICAgICAn5Y+X5rOo5ZWG5ZOBSUQnOiBudWxsLFxyXG4gICAgICAn5bqX6IiXSUQnOiBzaG9wWyflupfoiJdJRCddLFxyXG4gICAgICAn5bqX6IiX5ZCNJzogbnVsbCxcclxuICAgICAgJ+WPl+azqOWVhuWTgeeVquWPtyc6IGAke21vZGVsfSR7Y2xhc3MxfSR7Y2xhc3MyfWAsXHJcbiAgICAgICfmnInlirnjg5Xjg6njgrAnOiAn5pyJ5Yq5J1xyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgcmVxdWVzdCBmcm9tICdyZXF1ZXN0LXByb21pc2UnXHJcbmltcG9ydCB7IGpzb24yeG1sIH0gZnJvbSAneG1sLWpzJ1xyXG5pbXBvcnQgdXRpbEVycm9yIGZyb20gJy4uL3V0aWwvZXJyb3InXHJcblxyXG5jb25zdCBCQVNFX1VSSSA9ICdodHRwczovL2FwaS5tYW5hZ2VyLndvd21hLmpwL3dtc2hvcGFwaSdcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIFdvd21hQXBpIHtcclxuICBjb25zdHJ1Y3RvciAocGx1Zywgc2hvcElkKSB7XHJcbiAgICB0aGlzLnBsdWcgPSBwbHVnXHJcbiAgICB0aGlzLnNob3BJZCA9IHNob3BJZFxyXG4gIH1cclxuXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcbiAgYXN5bmMgdXBkYXRlSXRlbSAodXBkYXRlSXRlbSkge1xyXG4gICAgbGV0IHJlcXVlc3QgPSBgPHJlcXVlc3Q+PHNob3BJZD4ke3RoaXMuc2hvcElkfTwvc2hvcElkPjx1cGRhdGVJdGVtPiR7anNvbjJ4bWwodXBkYXRlSXRlbSwge2NvbXBhY3Q6IHRydWV9KX08L3VwZGF0ZUl0ZW0+PC9yZXF1ZXN0PmBcclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnJlcXVlc3RQb3N0KFxyXG4gICAgICAgICd1cGRhdGVJdGVtSW5mbycsXHJcbiAgICAgICAgcmVxdWVzdFxyXG4gICAgICApXHJcbiAgICAgIHJldHVybiB7cmVzcG9uc2U6IHJlcywgcmVxdWVzdFhNTDogcmVxdWVzdH1cclxuICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgdGhyb3cgT2JqZWN0LmFzc2lnbih1dGlsRXJyb3IucGFyc2UoZSksIHtyZXF1ZXN0WE1MOiByZXF1ZXN0fSlcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHJlcXVlc3RQb3N0IChtZXRob2QsIGJvZHkpIHtcclxuICAgIC8vIOaOpee2muOCquODl+OCt+ODp+ODs+OBruS9nOaIkFxyXG4gICAgbGV0IGFwaVJlcXVlc3QgPSB7XHJcbiAgICAgIG1ldGhvZDogJ1BPU1QnLFxyXG4gICAgICB1cmk6IGAke0JBU0VfVVJJfS8ke21ldGhvZH1gLFxyXG4gICAgICBib2R5OiBib2R5XHJcbiAgICB9XHJcbiAgICAvLyDlhbHpgJrjga7mjqXntproqK3lrprjgajntZDlkIjjgZnjgotcclxuICAgIE9iamVjdC5hc3NpZ24oYXBpUmVxdWVzdCwgdGhpcy5wbHVnKVxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOeZuuihjFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHJlcXVlc3QoYXBpUmVxdWVzdClcclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG5cclxuICBhc3luYyB1cGRhdGVTdG9jayAoc3RvY2tVcGRhdGVJdGVtKSB7XHJcbiAgICAvLyDmjqXntprjgqrjg5fjgrfjg6fjg7Pjga7kvZzmiJBcclxuICAgIGxldCBhcGlSZXF1ZXN0ID0ge1xyXG4gICAgICBtZXRob2Q6ICdQT1NUJyxcclxuICAgICAgdXJpOiBgJHtCQVNFX1VSSX0vdXBkYXRlU3RvY2tgXHJcbiAgICB9XHJcbiAgICAvLyDlhbHpgJrjga7mjqXntproqK3lrprjgajntZDlkIjjgZnjgotcclxuICAgIE9iamVjdC5hc3NpZ24oYXBpUmVxdWVzdCwgdGhpcy5wbHVnKVxyXG5cclxuICAgIGFwaVJlcXVlc3QuYm9keSA9IGF3YWl0IHRoaXMudXBkYXRlU3RvY2tDcmVhdGVSZXF1ZXN0Qm9keShzdG9ja1VwZGF0ZUl0ZW0pXHJcblxyXG4gICAgLy8g44Oq44Kv44Ko44K544OI55m66KGMXHJcbiAgICBsZXQgcmVzID0gYXdhaXQgcmVxdWVzdChhcGlSZXF1ZXN0KVxyXG5cclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIGFzeW5jIHVwZGF0ZVN0b2NrQ3JlYXRlUmVxdWVzdEJvZHkgKHN0b2NrVXBkYXRlSXRlbSkge1xyXG4gICAgLy9cclxuICAgIC8vIHN0b2NrVXBkYXRlSXRlbSA9XHJcbiAgICAvLyBbXHJcbiAgICAvLyAgIHtcclxuICAgIC8vICAgICBpdGVtQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgdmFyaWF0aW9uczogW1xyXG4gICAgLy8gICAgICAgIHtcclxuICAgIC8vICAgICAgICAgIGNob2ljZXNTdG9ja0hvcml6b250YWxDb2RlOiA8U3RyaW5nPixcclxuICAgIC8vICAgICAgICAgIGNob2ljZXNTdG9ja1ZlcnRpY2FsQ29kZTogPFN0cmluZz4sXHJcbiAgICAvLyAgICAgICAgICBzdG9jazogPE51bWJlcj5cclxuICAgIC8vICAgICAgICB9XHJcbiAgICAvLyAgICAgXVxyXG4gICAgLy8gICB9XHJcbiAgICAvLyBdXHJcblxyXG4gICAgbGV0IHN0b2NrVXBkYXRlSXRlbVhNTCA9ICcnXHJcblxyXG4gICAgZm9yIChsZXQgaXRlbSBvZiBzdG9ja1VwZGF0ZUl0ZW0pIHtcclxuICAgICAgLy8g5YCk44Gu44OB44Kn44OD44KvXHJcbiAgICAgIGZvciAobGV0IGUgb2YgaXRlbS52YXJpYXRpb25zKSB7XHJcbiAgICAgICAgLy8g5Zyo5bqr5pWw44Gu5LiK6ZmQMTAwXHJcbiAgICAgICAgaWYgKGUuc3RvY2sgPiAxMDApIGUuc3RvY2sgPSAxMDBcclxuICAgICAgfVxyXG5cclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tVcGRhdGVJdGVtPidcclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8aXRlbUNvZGU+JHtpdGVtLml0ZW1Db2RlfTwvaXRlbUNvZGU+YFxyXG5cclxuICAgICAgLy8g5ZWG5ZOB5Zyo5bqr56iu5Yil44KS5oyv44KK5YiG44GRXHJcbiAgICAgIC8vIDEgLT4g6YCa5bi45ZWG5ZOBXHJcbiAgICAgIC8vIDIgLT4g6YG45oqe6IKi5Yil5Zyo5bqrXHJcblxyXG4gICAgICBsZXQgdmFyMCA9IGl0ZW0udmFyaWF0aW9uc1swXVxyXG4gICAgICBpZiAodmFyMC5jaG9pY2VzU3RvY2tIb3Jpem9udGFsQ29kZSA9PT0gJycgJiYgdmFyMC5jaG9pY2VzU3RvY2tWZXJ0aWNhbENvZGUgPT09ICcnKSB7XHJcbiAgICAgICAgLy8g6YCa5bi45ZWG5ZOBXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8c3RvY2tTZWdtZW50PjE8L3N0b2NrU2VnbWVudD4nXHJcbiAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8c3RvY2tDb3VudD4ke3ZhcjAuc3RvY2t9PC9zdG9ja0NvdW50PmBcclxuICAgICAgfSBlbHNlIHtcclxuICAgICAgICAvLyDpgbjmip7ogqLliKXlnKjluqtcclxuICAgICAgICBzdG9ja1VwZGF0ZUl0ZW1YTUwgKz0gJzxzdG9ja1NlZ21lbnQ+Mjwvc3RvY2tTZWdtZW50PidcclxuXHJcbiAgICAgICAgLy8g44Oq44Kv44Ko44K544OI44Oc44OH44Kj44KS5L2c5oiQ44GZ44KLXHJcbiAgICAgICAgZm9yIChsZXQgdmFyaWF0aW9uIG9mIGl0ZW0udmFyaWF0aW9ucykge1xyXG4gICAgICAgICAgLy8g5Zyo5bqr6Kit5a6a44K/44Kw44Gu5ZCN5YmN44KS5beu44GX5pu/44GI44KLXHJcbiAgICAgICAgICB2YXJpYXRpb24uY2hvaWNlc1N0b2NrQ291bnQgPSB2YXJpYXRpb24uc3RvY2tcclxuICAgICAgICAgIGRlbGV0ZSB2YXJpYXRpb24uc3RvY2tcclxuXHJcbiAgICAgICAgICAvLyB4bWzjgpLmp4vmiJDjgZnjgotcclxuICAgICAgICAgIHN0b2NrVXBkYXRlSXRlbVhNTCArPSAnPGNob2ljZXNTdG9ja3M+J1xyXG4gICAgICAgICAgZm9yIChsZXQga2V5IG9mIE9iamVjdC5rZXlzKHZhcmlhdGlvbikpIHtcclxuICAgICAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9IGA8JHtrZXl9PiR7dmFyaWF0aW9uW2tleV19PC8ke2tleX0+YFxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8L2Nob2ljZXNTdG9ja3M+J1xyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG5cclxuICAgICAgc3RvY2tVcGRhdGVJdGVtWE1MICs9ICc8L3N0b2NrVXBkYXRlSXRlbT4nXHJcbiAgICB9XHJcblxyXG4gICAgLy8g44Oq44Kv44Ko44K544OI44Oc44OH44Kj44Gu5L2c5oiQXHJcbiAgICBsZXQgYXBpUmVxdWVzdEJvZHkgPSBgXHJcbiAgICA8cmVxdWVzdD5cclxuICAgIDxzaG9wSWQ+JHt0aGlzLnNob3BJZH08L3Nob3BJZD5cclxuICAgICR7c3RvY2tVcGRhdGVJdGVtWE1MfVxyXG4gICAgPC9yZXF1ZXN0PlxyXG4gICAgYFxyXG5cclxuICAgIC8vIOODquOCr+OCqOOCueODiOODnOODh+OCo+OCkui/lOOBmVxyXG4gICAgcmV0dXJuIGFwaVJlcXVlc3RCb2R5XHJcbiAgfVxyXG59XHJcbiIsImV4cG9ydCBkZWZhdWx0IGNsYXNzIHV0aWxFcnJvciB7XHJcbiAgc3RhdGljIHBhcnNlIChlKSB7XHJcbiAgICBsZXQgcmVzID0ge31cclxuXHJcbiAgICBpZiAoZSBpbnN0YW5jZW9mIEVycm9yKSB7XHJcbiAgICAgIHJlcy5tZXNzYWdlID0gZS5tZXNzYWdlXHJcbiAgICAgIHJlcy5uYW1lID0gZS5uYW1lXHJcbiAgICAgIHJlcy5maWxlTmFtZSA9IGUuZmlsZU5hbWVcclxuICAgICAgcmVzLmxpbmVOdW1iZXIgPSBlLmxpbmVOdW1iZXJcclxuICAgICAgcmVzLmNvbHVtbk51bWJlciA9IGUuY29sdW1uTnVtYmVyXHJcbiAgICAgIHJlcy5zdGFjayA9IGUuc3RhY2tcclxuICAgIH0gZWxzZSB7XHJcbiAgICAgIHJlcyA9IGVcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4gcmVzXHJcbiAgfVxyXG59XHJcbiIsImltcG9ydCB7IE1vbmdvQ2xpZW50IH0gZnJvbSAnbW9uZ29kYidcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0NvbGxlY3Rpb24ge1xyXG4gIHN0YXRpYyBhc3luYyBnZXQgKHBsdWcsIGNvbGxlY3Rpb24pIHtcclxuICAgIGxldCBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKVxyXG4gICAgbGV0IGRiID0gY2xpZW50LmRiKHBsdWcuZGF0YWJhc2UpXHJcbiAgICByZXR1cm4gZGIuY29sbGVjdGlvbihjb2xsZWN0aW9uKVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgbXlzcWwgZnJvbSAnbXlzcWwnXHJcbmltcG9ydCBtb21lbnQgZnJvbSAnbW9tZW50J1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgTXlTUUwge1xyXG4gIGNvbnN0cnVjdG9yIChwcm9maWxlKSB7XHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pjg5fjg7zjg6vliJ3mnJ/ljJZcclxuICAgIHRoaXMucG9vbCA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZSlcclxuXHJcbiAgICAvLyDopIfmlbDooYzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jlr77lv5xcclxuICAgIGxldCBwcm9maWxlTXVsdGkgPSB7bXVsdGlwbGVTdGF0ZW1lbnRzOiB0cnVlfVxyXG4gICAgT2JqZWN0LmFzc2lnbihwcm9maWxlTXVsdGksIHByb2ZpbGUpXHJcbiAgICB0aGlzLnBvb2xNdWx0aSA9IG15c3FsLmNyZWF0ZVBvb2wocHJvZmlsZU11bHRpKVxyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZvcm1hdERhdGUgKGRhdGUpIHtcclxuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsIDE5KS5yZXBsYWNlKCdUJywgJyAnKVxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICpcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gc3FsXHJcbiAgICovXHJcbiAgcXVlcnkgKHNxbCkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz56K656uLXHJcbiAgICAvLyBsZXQgY29uID0gYXdhaXQgdGhpcy5nZXRDb24oKTtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwsIChlLCByZXMpID0+IHtcclxuICAgICAgICAgICAgICAgIC8vIOOCs+ODjeOCr+OCt+ODp+ODs+mWi+aUvlxyXG4gICAgICAgICAgICAgICAgY29uLnJlbGVhc2UoKVxyXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpXHJcbiAgICAgICAgICAgICAgICB9IGVsc2UgcmVzb2x2ZShyZXMpXHJcbiAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKVxyXG4gICAgICAgIH1cclxuICAgICAgKVxyXG4gICAgICAuY2F0Y2goKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlXHJcbiAgICAgIH0pXHJcbiAgfTtcclxuXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnRfIChzcWwpIHtcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O844CBbnVsbOOAgWphdmFzY3JpcHQtPm15c3Fs5pel5LuY5aSJ5o+b44Gr44KC5a++5b+cXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFTcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgYXN5bmMgcXVlcnlJbnNlcnQgKHRhYmxlLCBkYXRhID0ge30sIGRhdGFTcWwgPSB7fSkge1xyXG4gICAgLy8gbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIC8vIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gICAgbGV0IHNxbCA9IGBJTlNFUlQgSU5UTyAke3RhYmxlfSBgXHJcblxyXG4gICAgbGV0IG1hcCA9IG5ldyBNYXAoKVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSkge1xyXG4gICAgICBpZiAoZGF0YVtrXSA9PT0gbnVsbCkge1xyXG4gICAgICAgIG1hcC5zZXQoaywgJ05VTEwnKVxyXG4gICAgICB9IGVsc2UgaWYgKGRhdGFba10uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgLy8g5pel5LuY44KS5aSJ5o+bXHJcbiAgICAgICAgbWFwLnNldChrLCBgXCIke015U1FMLmZvcm1hdERhdGUoZGF0YVtrXSl9XCJgKVxyXG4gICAgICB9IGVsc2Uge1xyXG4gICAgICAgIG1hcC5zZXQoaywgYCR7bXlzcWwuZXNjYXBlKGRhdGFba10pfWApXHJcbiAgICAgIH1cclxuICAgIH1cclxuICAgIGZvciAobGV0IGsgb2YgT2JqZWN0LmtleXMoZGF0YVNxbCkpIHtcclxuICAgICAgbWFwLnNldChrLCBkYXRhU3FsW2tdID09PSBudWxsID8gJ05VTEwnIDogZGF0YVNxbFtrXSlcclxuICAgIH1cclxuXHJcbiAgICBzcWwgKz0gYCggJHtbLi4ubWFwLmtleXMoKV0uam9pbignLCcpfSApIGBcclxuXHJcbiAgICBzcWwgKz0gYFZBTFVFUyggJHtbLi4ubWFwLnZhbHVlcygpXS5qb2luKCcsJyl9ICkgYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWRcclxuICB9XHJcblxyXG4gIC8qKlxyXG4gICAqXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGZpbHRlciBTUUwgVVBEQVRF44K544OG44O844OI44Oh44Oz44OI44GuV0hFUkXlj6VcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YVNxbCBTUUzjgrnjg4bjg7zjg4jjg6Hjg7Pjg4jjgoTmlbDlrZfjgarjganmloflrZfliJfku6XlpJbjga7jg5Hjg6njg6Hjg7zjgr9cclxuICAgKi9cclxuICBhc3luYyBxdWVyeVVwZGF0ZSAodGFibGUsIGZpbHRlciwgZGF0YSwgZGF0YVNxbCkge1xyXG4gICAgbGV0IHNxbCA9IGBVUERBVEUgJHt0YWJsZX0gU0VUIGBcclxuXHJcbiAgICBsZXQgdXBkYXRlcyA9IFtdXHJcbiAgICBmb3IgKGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpKSB7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT0ke215c3FsLmVzY2FwZShkYXRhW2tdKX1gKVxyXG4gICAgfVxyXG4gICAgZm9yIChsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhU3FsKSkge1xyXG4gICAgICB1cGRhdGVzLnB1c2goYCR7a309JHtkYXRhU3FsW2tdfWApXHJcbiAgICB9XHJcbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJylcclxuXHJcbiAgICBzcWwgKz0gYCBXSEVSRSAke2ZpbHRlcn0gYFxyXG5cclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbClcclxuICAgIHJldHVybiByZXNcclxuICB9XHJcblxyXG4gIC8vIGVuYWJsZSB0byB1c2UgbXVsdGlwbGUgc3RhdGVtZW50c1xyXG4gIGFzeW5jIHF1ZXJ5TXVsdGkgKHNxbCkge1xyXG4gICAgbGV0IHBvb2xTd2FwID0gdGhpcy5wb29sXHJcbiAgICB0aGlzLnBvb2wgPSB0aGlzLnBvb2xNdWx0aVxyXG4gICAgdHJ5IHtcclxuICAgICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKVxyXG4gICAgICByZXR1cm4gcmVzXHJcbiAgICB9IGZpbmFsbHkge1xyXG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcFxyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3RhcnRUcmFuc2FjdGlvbiAoKSB7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBTVEFSVCBUUkFOU0FDVElPTjtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29tbWl0ICgpIHtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYENPTU1JVDtgKVxyXG4gIH1cclxuXHJcbiAgYXN5bmMgcm9sbGJhY2sgKCkge1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgUk9MTEJBQ0s7YClcclxuICB9XHJcblxyXG4gIHN0cmVhbWluZ1F1ZXJ5IChzcWwsIG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pIHtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwpXHJcbiAgICAgICAgICAgICAgICAub24oJ3Jlc3VsdCcsXHJcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb24ucGF1c2UoKVxyXG4gICAgICAgICAgICAgICAgICAgIG9uUmVzdWx0KHJlY29yZClcclxuICAgICAgICAgICAgICAgICAgICBjb24ucmVzdW1lKClcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICAgICAgLm9uKCdlbmQnLCAoKSA9PiB7XHJcbiAgICAgICAgICAgICAgICAgIGNvbi5yZWxlYXNlKClcclxuICAgICAgICAgICAgICAgICAgcmVzb2x2ZSgpXHJcbiAgICAgICAgICAgICAgICB9KVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICApXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGVcclxuICAgICAgfSlcclxuICB9XHJcblxyXG4gIGdldENvbiAoKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICAvLyDjg5fjg7zjg6vjgYvjgonjga7jgrPjg43jgq/jgrfjg6fjg7PnjbLlvpdcclxuICAgICAgICB0aGlzLnBvb2wuZ2V0Q29ubmVjdGlvbigoZSwgY29uKSA9PiB7XHJcbiAgICAgICAgICBpZiAoZSkge1xyXG4gICAgICAgICAgICByZWplY3QoZSlcclxuICAgICAgICAgIH0gZWxzZSB7XHJcbiAgICAgICAgICAgIHJlc29sdmUoY29uKVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH0pXHJcbiAgICAgIH1cclxuICAgIClcclxuICAgICAgLmNhdGNoKFxyXG4gICAgICAgIChlKSA9PiB7XHJcbiAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgfTtcclxufVxyXG4iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBQYWNrZXQge1xyXG4gIGNvbnN0cnVjdG9yIChwYWNrZXRTaXplKSB7XHJcbiAgICB0aGlzLnBhY2tldFNpemUgPSBwYWNrZXRTaXplXHJcbiAgICB0aGlzLm9uUGFja2V0U3RhcnQgPSBudWxsXHJcbiAgICB0aGlzLm9uUGFja2V0ID0gbnVsbFxyXG4gICAgdGhpcy5vblBhY2tldEVuZCA9IG51bGxcclxuICAgIHRoaXMuY291bnQgPSAwXHJcbiAgICB0aGlzLnBhY2tldENvdW50ID0gMFxyXG4gIH1cclxuXHJcbiAgYXN5bmMgc3VibWl0IChhcmcpIHtcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHliJ3mnJ/ljJbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIGlmICh0aGlzLm9uUGFja2V0U3RhcnQpIHtcclxuICAgICAgICBhd2FpdCB0aGlzLm9uUGFja2V0U3RhcnQodGhpcy5wYWNrZXRDb3VudClcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgaWYgKHRoaXMub25QYWNrZXQpIHtcclxuICAgICAgYXdhaXQgdGhpcy5vblBhY2tldChhcmcpXHJcbiAgICB9XHJcbiAgICB0aGlzLmNvdW50KytcclxuICAgIC8vIHBhY2tldFNpemXjga7lm57mlbDjgZTjgajjgavjgIHntYLkuoblh6bnkIbjgpLlkbzjgbPlh7rjgZlcclxuICAgIGlmICh0aGlzLmNvdW50ICUgdGhpcy5wYWNrZXRTaXplID09PSAwKSB7XHJcbiAgICAgIHRoaXMuY2xvc2UoKVxyXG4gICAgICB0aGlzLnBhY2tldENvdW50KytcclxuICAgIH1cclxuICB9XHJcbiAgY2xvc2UgKCkge1xyXG4gICAgaWYgKHRoaXMub25QYWNrZXRFbmQpIHtcclxuICAgICAgdGhpcy5vblBhY2tldEVuZCh0aGlzLnBhY2tldENvdW50KVxyXG4gICAgfVxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgdXRpbEVycm9yIGZyb20gJy4vZXJyb3InXHJcbmltcG9ydCB7TWV0ZW9yfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgeyBMb2dzIH0gZnJvbSAnLi4vY29sbGVjdGlvbnMnXHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJ1xyXG5cclxuZXhwb3J0IGRlZmF1bHQgY2xhc3MgUmVwb3J0IHtcclxuICBjb25zdHJ1Y3RvciAoKSB7XHJcbiAgICB0aGlzLnJlY29yZCA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9ycyA9IFtdXHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbnVsbFxyXG4gIH1cclxuXHJcbiAgLy8gcHJpdmF0ZVxyXG4gIHNldHVwSXRlcmF0b3IgKHBoYXNlSWQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3IgPSBuZXcgSXRlcmF0b3IocGhhc2VJZClcclxuICAgIHRoaXMuaXRlcmF0b3JzLnB1c2godGhpcy5pdGVyYXRvcilcclxuICB9XHJcblxyXG4gIGFzeW5jIHBoYXNlIChuYW1lID0gJycsIGZuID0gYXN5bmMgKCkgPT4ge30pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHBoYXNlSWQ6IHVuaXFpZCgpXHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5zZXR1cEl0ZXJhdG9yKHJlYy5waGFzZUlkKVxyXG5cclxuICAgIHRyeSB7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCBmbigpXHJcblxyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdzdWNjZXNzJyxcclxuICAgICAgICBwaGFzZTogbmFtZSxcclxuICAgICAgICByZXN1bHQ6IHJlc1xyXG4gICAgICB9KVxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgIHR5cGU6ICdlcnJvcicsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiB1dGlsRXJyb3IucGFyc2UoZSlcclxuICAgICAgfSlcclxuICAgIH0gZmluYWxseSB7XHJcbiAgICAgIC8vIOODq+ODvOODl+WHpueQhuOBruODrOODneODvOODiOOCkuS9nOaIkFxyXG4gICAgICBpZiAodGhpcy5pdGVyYXRvci5tZXRyaWMudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3IubWV0cmljXHJcbiAgICAgICAgfSlcclxuICAgICAgfVxyXG4gICAgICAvLyDjgr/jgqTjg6Djgrnjgr/jg7Pjg5dcclxuICAgICAgcmVjLnRpbWVTdGFtcCA9IG5ldyBEYXRlKClcclxuICAgICAgLy8g44Os44Od44O844OI44KS44OH44O844K/44OZ44O844K544Gr6KiY6YyyXHJcbiAgICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuXHJcbiAgICAgIC8vIOWRvOOBs+WHuuOBl+WFg+eUqOODrOODneODvOODiOOBq+i/veWKoFxyXG4gICAgICB0aGlzLnJlY29yZC5wdXNoKHJlYylcclxuICAgIH1cclxuICB9XHJcblxyXG4gIC8vIOOCq+ODvOOCveODq+OCkuODq+ODvOODl+OBl+OAgeS4juOBiOOCieOCjOOBn+mWouaVsOOCkuWun+ihjFxyXG4gIC8vIOWRvOOBs+WHuuOBmemWouaVsOOBruW8leaVsOOBq+OBr+OCq+ODvOOCveODq+OBi+OCieW+l+OCieOCjOOBn+ODieOCreODpeODoeODs+ODiOOCkua4oeOBmVxyXG4gIGFzeW5jIGZvckVhY2hPbkN1cnNvciAoY3VyLCBmbikge1xyXG4gICAgd2hpbGUgKGF3YWl0IGN1ci5oYXNOZXh0KCkpIHtcclxuICAgICAgbGV0IGRvYyA9IGF3YWl0IGN1ci5uZXh0KClcclxuICAgICAgdHJ5IHtcclxuICAgICAgICAvLyDjg6rjgq/jgqjjgrnjg4jnmbrooYxcclxuICAgICAgICBsZXQgcmVzID0gYXdhaXQgZm4oZG9jKVxyXG4gICAgICAgIHRoaXMuaVN1Y2Nlc3MocmVzKVxyXG4gICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgdGhpcy5pRXJyb3IoZSlcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgY3VyLmNsb3NlKClcclxuICB9XHJcblxyXG4gIGlTdWNjZXNzIChuZXdSZWNvcmQpIHtcclxuICAgIHRoaXMuaXRlcmF0b3Iuc3VjY2VzcyhuZXdSZWNvcmQpXHJcbiAgfVxyXG5cclxuICBpRXJyb3IgKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5lcnJvcih1dGlsRXJyb3IucGFyc2UobmV3UmVjb3JkKSlcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICBsZXQgaXRlRXJyb3IgPSB0aGlzLml0ZXJhdG9ycy5maW5kKGUgPT4gZS5lcnJvck9jdXJyZWQoKSlcclxuICAgIGxldCBwaGFFcnJvciA9IGZhbHNlXHJcbiAgICBmb3IgKGxldCByZWMgb2YgdGhpcy5yZWNvcmQpIHtcclxuICAgICAgaWYgKHJlYy50eXBlID09PSAnZXJyb3InKSB7XHJcbiAgICAgICAgcGhhRXJyb3IgPSB0cnVlXHJcbiAgICAgICAgYnJlYWtcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGl0ZUVycm9yIHx8IHBoYUVycm9yXHJcbiAgfVxyXG5cclxuICBwdWJsaXNoICgpIHtcclxuICAgIC8vIOWRvOOBs+WHuuOBl+WFg+OBuOODrOODneODvOODiFxyXG4gICAgaWYgKHRoaXMuZXJyb3JPY3VycmVkKCkpIHtcclxuICAgICAgdGhyb3cgbmV3IE1ldGVvci5FcnJvcih0aGlzLnJlY29yZClcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnJlY29yZFxyXG4gIH1cclxufVxyXG5cclxuY2xhc3MgSXRlcmF0b3Ige1xyXG4gIGNvbnN0cnVjdG9yIChwaGFzZUlkKSB7XHJcbiAgICB0aGlzLm1ldHJpYyA9IHtcclxuICAgICAgdG90YWw6IDAsXHJcbiAgICAgIHN1Y2Nlc3M6IDAsXHJcbiAgICAgIGVycm9yOiAwLFxyXG4gICAgICBwaGFzZUlkOiBwaGFzZUlkXHJcbiAgICB9XHJcbiAgICB0aGlzLmxhc3RFcnJvciA9IG51bGxcclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MgKG5ld1JlY29yZCkge1xyXG4gICAgaWYgKG5ld1JlY29yZCkge1xyXG4gICAgICB0aGlzLmxvZyhuZXdSZWNvcmQsIHRydWUpXHJcbiAgICB9XHJcbiAgICB0aGlzLm1ldHJpYy5zdWNjZXNzKytcclxuICAgIHRoaXMubWV0cmljLnRvdGFsKytcclxuICB9XHJcblxyXG4gIGVycm9yIChuZXdSZWNvcmQpIHtcclxuICAgIC8vIOebtOWJjeOBqOWQjOOBmOOCqOODqeODvOOBr+ecgeOBj1xyXG4gICAgaWYgKEpTT04uc3RyaW5naWZ5KHRoaXMubGFzdEVycm9yKSAhPT0gSlNPTi5zdHJpbmdpZnkobmV3UmVjb3JkKSkge1xyXG4gICAgICBpZiAobmV3UmVjb3JkICYmIG5ld1JlY29yZCAhPT0ge30gJiYgbmV3UmVjb3JkICE9PSAnJykge1xyXG4gICAgICAgIHRoaXMubG9nKG5ld1JlY29yZCwgZmFsc2UpXHJcbiAgICAgICAgdGhpcy5sYXN0RXJyb3IgPSBuZXdSZWNvcmRcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgdGhpcy5tZXRyaWMuZXJyb3IrK1xyXG4gICAgdGhpcy5tZXRyaWMudG90YWwrK1xyXG4gIH1cclxuXHJcbiAgbG9nIChuZXdSZWNvcmQsIGlzU3VjY2VzcyAvKiB0cnVlID0+IHN1Y2Nlc3Mgb3IgZmFsc2UgPT4gZXJyb3IgKi8pIHtcclxuICAgIGxldCByZWMgPSB7XHJcbiAgICAgIHN1Y2Nlc3M6IGlzU3VjY2VzcyxcclxuICAgICAgcGhhc2VJZDogdGhpcy5tZXRyaWMucGhhc2VJZCxcclxuICAgICAgbWVzc2FnZTogbmV3UmVjb3JkLFxyXG4gICAgICB0aW1lU3RhbXA6IG5ldyBEYXRlKClcclxuICAgIH1cclxuICAgIExvZ3MuaW5zZXJ0KHJlYylcclxuICB9XHJcblxyXG4gIGVycm9yT2N1cnJlZCAoKSB7XHJcbiAgICByZXR1cm4gdGhpcy5tZXRyaWMuZXJyb3JcclxuICB9XHJcbn1cclxuIiwiZXhwb3J0IGRlZmF1bHQgY2xhc3MgVGV4dFV0aWwge1xyXG4gIHN0YXRpYyBzdWJzdHI4ICh0ZXh0LCBsZW4sIHRydW5jYXRpb24pIHtcclxuICAgIGlmICh0cnVuY2F0aW9uID09PSB1bmRlZmluZWQpIHsgdHJ1bmNhdGlvbiA9ICcnIH1cclxuICAgIHZhciB0ZXh0QXJyYXkgPSB0ZXh0LnNwbGl0KCcnKVxyXG4gICAgdmFyIGNvdW50ID0gMFxyXG4gICAgdmFyIHN0ciA9ICcnXHJcbiAgICBmb3IgKGxldCBpID0gMDsgaSA8IHRleHRBcnJheS5sZW5ndGg7IGkrKykge1xyXG4gICAgICB2YXIgbiA9IGVzY2FwZSh0ZXh0QXJyYXlbaV0pXHJcbiAgICAgIGlmIChuLmxlbmd0aCA8IDQpIGNvdW50KytcclxuICAgICAgZWxzZSBjb3VudCArPSAyXHJcbiAgICAgIGlmIChjb3VudCA+IGxlbikge1xyXG4gICAgICAgIHJldHVybiBzdHIgKyB0cnVuY2F0aW9uXHJcbiAgICAgIH1cclxuICAgICAgc3RyICs9IHRleHQuY2hhckF0KGkpXHJcbiAgICB9XHJcbiAgICByZXR1cm4gdGV4dFxyXG4gIH1cclxufVxyXG4iLCJpbXBvcnQgeyBNZXRlb3IgfSBmcm9tICdtZXRlb3IvbWV0ZW9yJ1xyXG5pbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbydcclxuXHJcbmV4cG9ydCBjb25zdCBMb2dzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2xvZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuZXhwb3J0IGNvbnN0IFVwbG9hZHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigndXBsb2FkcycsIHtpZEdlbmVyYXRpb246ICdNT05HTyd9KVxyXG5leHBvcnQgY29uc3QgUm9ib3RpblNob3AgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbigncm9ib3RpblNob3AnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuXHJcbmV4cG9ydCBjb25zdCBDb25maWdzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ2NvbmZpZ3MnLCB7aWRHZW5lcmF0aW9uOiAnTU9OR08nfSlcclxuXHJcbmlmIChNZXRlb3IuaXNTZXJ2ZXIpIHtcclxuICBNZXRlb3IucHVibGlzaCgnY29uZmlncycsICgpID0+IHtcclxuICAgIHJldHVybiBDb25maWdzLmZpbmQoKVxyXG4gIH0pXHJcbn1cclxuXHJcbmlmIChNZXRlb3IuaXNDbGllbnQpIHtcclxuICBNZXRlb3Iuc3Vic2NyaWJlKCdjb25maWdzJylcclxufVxyXG4iXX0=
