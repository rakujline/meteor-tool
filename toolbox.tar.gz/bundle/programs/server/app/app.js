var require = meteorInstall({"server":{"route":{"upload":{"image.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/route/upload/image.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let fs;
module.watch(require("fs"), {
  default(v) {
    fs = v;
  }

}, 0);
let uniqid;
module.watch(require("uniqid"), {
  default(v) {
    uniqid = v;
  }

}, 1);
let multiparty;
module.watch(require("connect-multiparty"), {
  default(v) {
    multiparty = v;
  }

}, 2);
let Uploads;
module.watch(require("../../../imports/collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 3);
let multipartyMiddleware = multiparty();
const route = '/upload/image'; // WebApp.connectHandlers.use('/upload', fuc.uploadFile );

WebApp.connectHandlers.use(route, multipartyMiddleware);
WebApp.connectHandlers.use(route, (req, resp) => {
  // don't forget to delete all req.files when done
  const reader = Meteor.wrapAsync(fs.readFile);
  const writer = Meteor.wrapAsync(fs.writeFile);
  const uploadId = uniqid();

  for (let file of req.files.file) {
    const data = reader(file.path); // ファイル名の重複を避けるため、一意のファイル名を作成する
    // 楽天のファイル名文字数制限20に合わせる

    let filename = `${uniqid()}.jpg`; // set the correct path for the file not the temporary one from the API:

    let savePath = req.body.imagedir + '/' + filename; // copy the data from the req.files.file.path and paste it to file.path
    // アップロード結果を記録する

    let doc = {
      uploadId: uploadId,
      clientFileName: file.name,
      uploadedFileName: filename
    };

    try {
      writer(savePath, data);
    } catch (err) {
      doc.error = err;
    }

    Uploads.insert(doc);
    delete file;
  }

  ;
  resp.writeHead(200);
  resp.end(JSON.stringify({
    uploadId: uploadId,
    saveDir: req.body.imagedir
  }));
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}},"cube":{"_cubeup.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cube/_cubeup.js                                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../../imports/core/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../../imports/controller/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let tag = 'cubeup';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.item`](config) {
    return Promise.asyncApply(() => {
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('JLINE ENGINE からの取り込み', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'SAMPLE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              cubeItem = ItemController.itemCube3(item);
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(config.creator_id, cubeItem));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  },

  //
  // 画像更新
  [`${tag}.image`](config) {
    return Promise.asyncApply(() => {
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('JLINE ENGINE からの取り込み', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'SAMPLE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let res = Promise.await(api.productImageUpdate(config.creator_id, ItemController.itemCube3(item)));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"_cubex.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cube/_cubex.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../../imports/core/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 4);
let ItemController;
module.watch(require("../../imports/controller/items"), {
  default(v) {
    ItemController = v;
  }

}, 5);
let tag = 'cubex';
Meteor.methods({
  [`${tag}.exhibit`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // let mongoJline;
      // let Items;
      // await report.phase(
      //   'JLINE ENGINE への接続',
      //   async ()=>{
      //     let plug = config.sourceDB;
      //     mongoJline = await MongoClient.connect(plug.uri);
      //     Items = mongoJline.db(plug.database).collection(plug.collection);
      //   }
      // );

      let filter = new MongoDBFilter(config.sourceDB, config.profile);
      let targetDB = new MySQL(config.targetDB.cred);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('JLINE ENGINE からの取り込み', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'KOMINE_NOTEXISTS': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let insertRet = Promise.await(api.productCreate(config.creator_id, ItemController.itemCube3(item)));
              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRet.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"cubemig.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cube/cubemig.js                                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let crypto;
module.watch(require("crypto"), {
  default(v) {
    crypto = v;
  }

}, 0);
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Report;
module.watch(require("../../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 2);
let Group, GroupFactory;
module.watch(require("../../imports/collection/groups"), {
  Group(v) {
    Group = v;
  },

  GroupFactory(v) {
    GroupFactory = v;
  }

}, 3);
let Filter;
module.watch(require("../../imports/collection/filters"), {
  Filter(v) {
    Filter = v;
  }

}, 4);
let tag = 'cubemig';
Meteor.methods({
  [`${tag}.migrate`](config) {
    return Promise.asyncApply(() => {
      let report = new Report(); // setup group
      //

      let filter = new Filter(config.srcFilterId); // let plug = group.getPlug();
      // checking connection
      //

      let testQuery = 'SHOW DATABASES';
      let dstDb = new MySQL(config.dst.cred);
      Promise.await(report.phase('Connect to Destination', () => Promise.asyncApply(() => {
        Promise.await(dstDb.query(testQuery));
      }))); // process for each members
      //

      Promise.await(report.phase('Select loop in source', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          mobileNull: record => Promise.asyncApply(() => {
            // // 値を整理
            // for (let key of Object.keys(record)) {
            //   if (record[key] === null);
            //   else if (record[key].constructor.name === 'Date') {
            //     // 日付を変換
            //     record[key] = MySQL.formatDate(record[key]);
            //     record[key] = `"${record[key]}"`;
            //   }
            // }
            // dtb_customer に保存
            let sql = `

                INSERT dtb_customer
                ( \`customer_id\`, \`status\`, \`sex\`, \`job\`, \`country_id\`, \`pref\`, \`name01\`, \`name02\`, \`kana01\`, \`kana02\`, \`company_name\`, \`zip01\`, \`zip02\`, \`zipcode\`, \`addr01\`, \`addr02\`, \`email\`, \`tel01\`, \`tel02\`, \`tel03\`, \`fax01\`, \`fax02\`, \`fax03\`, \`birth\`, \`password\`, \`salt\`, \`secret_key\`, \`first_buy_date\`, \`last_buy_date\`, \`buy_times\`, \`buy_total\`, \`note\`, \`create_date\`, \`update_date\`, \`del_flg\` )

                VALUES( ${record.customer_id} , ${record.status} , ${record.sex} , ${record.job} , ${record.country_id} , ${record.pref} , ${record.name01} , ${record.name02} , ${record.kana01} , ${record.kana02} , ${record.company_name} , ${record.zip01} , ${record.zip02} , ${record.zipcode} , ${record.addr01} , ${record.addr02} , ${record.email} , ${record.tel01} , ${record.tel02} , ${record.tel03} , ${record.fax01} , ${record.fax02} , ${record.fax03} , ${record.birth} , ${record.password} , ${record.salt} , ${record.secret_key} , ${record.first_buy_date} , ${record.last_buy_date} , ${record.buy_times} , ${record.buy_total} , ${record.note} , ${record.create_date} , ${record.update_date} , ${record.del_flg} )
                
                `;

            try {
              Promise.await(dstDb.queryInsert('dtb_customer', {
                customer_id: record.customer_id,
                status: record.status,
                sex: record.sex,
                job: record.job,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                email: record.email,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                birth: record.birth,
                password: record.password,
                salt: record.salt,
                secret_key: record.secret_key,
                first_buy_date: record.first_buy_date,
                last_buy_date: record.last_buy_date,
                buy_times: record.buy_times,
                buy_total: record.buy_total,
                note: record.note,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // dtb_customer_address


            try {
              Promise.await(dstDb.queryInsert('dtb_customer_address', {
                customer_address_id: null,
                customer_id: record.customer_id,
                country_id: record.country_id,
                pref: record.pref,
                name01: record.name01,
                name02: record.name02,
                kana01: record.kana01,
                kana02: record.kana02,
                company_name: record.company_name,
                zip01: record.zip01,
                zip02: record.zip02,
                zipcode: record.zipcode,
                addr01: record.addr01,
                addr02: record.addr02,
                tel01: record.tel01,
                tel02: record.tel02,
                tel03: record.tel03,
                fax01: record.fax01,
                fax02: record.fax02,
                fax03: record.fax03,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // メルマガプラグイン plg_mailmaga_customer


            try {
              Promise.await(dstDb.queryInsert('plg_mailmaga_customer', {
                id: null,
                customer_id: record.customer_id,
                mailmaga_flg: record.mailmaga_flg,
                create_date: record.create_date,
                update_date: record.update_date,
                del_flg: record.del_flg
              }));
            } catch (e) {
              report.iError(e);
            } // クーポン発行（ECCUBE2のポイント還元）


            let coupon_cd = crypto.randomBytes(8).toString('base64').substring(0, 11);
            let coupon_name = `${record.name01} ${record.name02} 様 ご優待クーポン 会員番号:${record.customer_id}`;
            let discount_price = record.point + 500;

            try {
              let res = Promise.await(dstDb.queryInsert('plg_coupon', {
                coupon_id: null,
                coupon_cd: coupon_cd,
                coupon_type: 3,
                // 全商品
                coupon_name: coupon_name,
                discount_type: 1,
                coupon_use_time: 1,
                coupon_release: 1,
                discount_price: discount_price,
                discount_rate: null,
                enable_flag: 1,
                coupon_member: 1,
                coupon_lower_limit: null,
                available_from_date: '2018-04-02 00:00:00',
                available_to_date: '2019-05-02 00:00:00',
                del_flg: 0
              }, {
                create_date: 'NOW()',
                update_date: 'NOW()'
              }));
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          report.iError(e);
        })));
      })));
      return report.publish();
    });
  },

  'cubemig.serverCheck'(profile) {
    return Promise.asyncApply(() => {
      let db = new MySQL(profile);
      let res = Promise.await(db.query('SHOW DATABASES'));
      return res;
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"jline":{"collection.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/jline/collection.js                                                                                      //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let MongoCollection;
module.watch(require("../../imports/util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let tag = 'jline.collection';
Meteor.methods({
  [`${tag}.find`](plug, query = {}, projection = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug));
      return Promise.await(coll.find(query, {
        projection: projection
      }).toArray());
    });
  },

  [`${tag}.aggregate`](plug, query = {}) {
    return Promise.asyncApply(() => {
      let coll = Promise.await(MongoCollection.get(plug));
      return Promise.await(coll.aggregate(query).toArray());
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/jline/items.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let ItemController;
module.watch(require("../../imports/controller/items"), {
  default(v) {
    ItemController = v;
  }

}, 0);
let tag = 'jline.items';
Meteor.methods({
  /**
   * 指定された条件に一致するitemsコレクション内のドキュメントに、
   * アップロード済み画像を関連付けます。
   * @param  
   */
  [`${tag}.setImage`](plug, uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      let uploaded = Promise.await(itemcon.setImage(uploadId, model, class1, class2));
      return uploaded;
    });
  },

  /**
   * アイテム情報データベースの画像登録を削除する（画像自体は削除しない）
   */
  [`${tag}.cleanImage`](plug, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      let itemcon = new ItemController();
      Promise.await(itemcon.init(plug));
      Promise.await(itemcon.cleanImage(model, class1, class2));
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"cube.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/cube.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let Cube3Api;
module.watch(require("../imports/core/cube3api"), {
  Cube3Api(v) {
    Cube3Api = v;
  }

}, 2);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 3);
let ItemController;
module.watch(require("../imports/controller/items"), {
  default(v) {
    ItemController = v;
  }

}, 4);
let tag = 'cube';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.exhibItem`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      let targetDB = new MySQL(config.cube3DB);
      let api = new Cube3Api(targetDB);
      Promise.await(report.phase('ECCUBE3への商品登録', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'INSERT': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = ItemController.itemCube3(config.creator_id, item);
              let insertRes = Promise.await(api.productCreate(cubeItem)); // item データベースへの登録

              Promise.await(col.update({
                _id: item._id
              }, {
                $set: {
                  'mall.sharakuShop': insertRes.res
                }
              }));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      Promise.await(report.phase('ECCUBE3商品情報の更新', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({
          'UPDATE': (item, context) => Promise.asyncApply(() => {
            let col = context.collection;

            try {
              let cubeItem = ItemController.itemCube3(config.creator_id, item);
              Promise.await(api.productImageUpdate(cubeItem));
              Promise.await(api.productUpdate(cubeItem));
              Promise.await(api.productTagUpdate(cubeItem));
              report.iSuccess();
            } catch (e) {
              report.iError(e);
            }
          })
        }, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"tooltest.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/tooltest.js                                                                                              //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
let Report;
module.watch(require("../imports/util/report"), {
  default(v) {
    Report = v;
  }

}, 0);
let MongoDBFilter;
module.watch(require("../imports/core/dbfilter"), {
  MongoDBFilter(v) {
    MongoDBFilter = v;
  }

}, 1);
let MySQL;
module.watch(require("../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 2);
let tag = 'tool';
Meteor.methods({
  //
  // 商品情報更新
  [`${tag}.test`](config) {
    return Promise.asyncApply(() => {
      // クライアントが参照するための処理結果作成オブジェクト
      let report = new Report();
      let filter = new MongoDBFilter(config.itemsDB, config.profile);
      Promise.await(report.phase('フィルターテスト', () => Promise.asyncApply(() => {
        return Promise.await(filter.foreach({}, e => Promise.asyncApply(() => {
          throw e;
        })));
      })));
      return report.publish();
    });
  }

});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"main.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// server/main.js                                                                                                  //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.watch(require("../imports/collection/configs"));
module.watch(require("./route/upload/image"));
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"imports":{"collection":{"configs.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/collection/configs.js                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Configs: () => Configs
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Configs = new Mongo.Collection('configs', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"filters.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/collection/filters.js                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Filter: () => Filter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 3);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 4);
let GroupBase;
module.watch(require("./groups"), {
  GroupBase(v) {
    GroupBase = v;
  }

}, 5);
const Filters = new Mongo.Collection('filters', {
  idGeneration: 'MONGO'
});

class Filter extends GroupBase {
  constructor(filterId) {
    let profile = Filters.findOne({
      _id: filterId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table}`;
          return Promise.await(this.mysql.streamingQuery(sql, onResult, onError));
        });

        break;

      default:
        throw new Error('invalid platform type');
    }
  }
  /**
   * traces members of the group
   * @param {{ filterType: async (record ) => {} }} callback custom function for each members
   */


  foreach(callbacks = {}, onError = e => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        type: 'misc',
        query: {}
      });
      let count = {};

      for (let filter of profile.filters) {
        count[filter.type] = {
          query: filter.query,
          count: 0
        };
      }

      Promise.await(this.import(record => Promise.asyncApply(() => {
        for (let filter of profile.filters) {
          let query = mobject.unescape(filter.query);
          let exam = sift(query);

          if (exam(record)) {
            count[filter.type].count++;

            if (typeof callbacks[filter.type] !== 'undefined') {
              Promise.await(callbacks[filter.type](record));
            }

            break;
          }
        }
      }), onError)); // return result of filtering

      return count;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"groups.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/collection/groups.js                                                                                    //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  GroupBase: () => GroupBase,
  Group: () => Group
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 1);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 2);
const Groups = new Mongo.Collection('groups', {
  idGeneration: 'MONGO'
});

class GroupBase {
  constructor(profile) {
    this.profile = profile;
  }
  /**
   * gets 'Plug' witch is a set of properties needed
   * when connect to some platforms
   * to get datas(Members of the Group)
   */


  getPlug() {
    return this.profile.platformPlug;
  }

  getProfile() {
    return this.profile;
  }

  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {}

}

class Group extends GroupBase {
  constructor(groupId) {
    let profile = Groups.findOne({
      _id: groupId
    });
    super(profile);
    let plug = this.getPlug();

    switch (plug.type) {
      case 'mysql':
        this.mysql = new MySQL(plug.cred);

        this.import = doc => Promise.asyncApply(() => {
          let sql = `SELECT * FROM ${plug.table} WHERE \`${doc.key}\` = "${doc.id}"`;
          return Promise.await(this.mysql.query(sql));
        });

        break;

      default:
        throw new Error('invalid group type');
    }
  }
  /**
   * traces members of the group
   * @param {async (record)=>void} callback custom function for each members
   */


  foreach(callback = record => Promise.asyncApply(() => {}), onError = e => Promise.asyncApply(() => {})) {
    let cur = Groups.find({
      groupId: this.profile._id
    }, {
      fields: {
        _id: 0,
        id: 1,
        key: 1
      }
    });
    return new Promise((resolve, reject) => {
      cur.forEach((doc, index) => Promise.asyncApply(() => {
        try {
          let record = Promise.await(this.import(doc));
          Promise.await(callback(record));
        } catch (e) {
          onError(e);
        }

        if (index + 1 === cur.count()) {
          resolve();
        }
      }));
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"uploads.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/collection/uploads.js                                                                                   //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Uploads: () => Uploads
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
const Uploads = new Mongo.Collection('uploads', {
  idGeneration: 'MONGO'
});
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"controller":{"items.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/controller/items.js                                                                                     //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  default: () => ItemController
});
let MongoCollection;
module.watch(require("../util/mongo"), {
  MongoCollection(v) {
    MongoCollection = v;
  }

}, 0);
let Uploads;
module.watch(require("../collection/uploads"), {
  Uploads(v) {
    Uploads = v;
  }

}, 1);

class ItemController {
  init(plug) {
    return Promise.asyncApply(() => {
      plug.collection = 'items';
      this.Items = Promise.await(MongoCollection.get(plug));
    });
  }
  /**
   * 
   * 指定された条件に一致するitems内のドキュメントに、
   * アップロード済み画像を関連付ける。
   * 
   * メーカーモデルに共通の画像を一括で関連付けたい場合、
   * class1、class2引数を指定せずに実行する。
   * 
   * 特定の属性（カラーなど）に共通の画像を一括で関連付けたい場合、
   * class1に値を指定し、class2引数を指定せずに実行する。
   * もしclass2のみ指定したい場合はclass1にnullを指定する。
   * 
   * 例：JK-100のBLACKの商品画像を
   * すべてのサイズ（S,M,L,XL,2XL,3XL,4XL…）に関連付ける場合
   * setImage( uploadId, 'JK-100', 'BLACK' );
   * 
   * @param {String} uploadId 一回のアップロード画像を束ねているID。meteorデータベース、Uploadsコレクション内ドキュメントのuploadIdプロパティ
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  setImage(uploadId, model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // アップロード済み画像の情報取得
      let images = Uploads.find({
        uploadId: uploadId
      }).fetch().map(v => v.uploadedFileName); // 検索条件の組み立て

      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $push: {
          images: {
            $each: images
          }
        }
      })); // 登録した画像ファイル名一覧

      return images;
    });
  }
  /**
   * 
   * 指定された条件に一致するitems内のドキュメントに登録されている画像情報を削除する。
   * 
   * @param {String} model メーカーモデル
   * @param {String} class1 カラー、サイズなどの属性
   * @param {String} class2 カラー、サイズなどの属性
   */


  cleanImage(model, class1 = null, class2 = null) {
    return Promise.asyncApply(() => {
      // 検索条件の組み立て
      let filter = {};
      filter.model = model;
      if (class1) filter.class1_value = class1;
      if (class2) filter.class2_value = class2;
      let res = Promise.await(this.Items.updateMany(filter, {
        $set: {
          images: []
        }
      }));
    });
  }

  static itemCube3(creator_id, item) {
    return new itemCube3(creator_id, item);
  }

}

class itemCube3 {
  constructor(creator_id, item) {
    // product_id
    let product_id = 'NULL';

    if (item.sharakuShop) {
      product_id = item.sharakuShop.product_id;
    } // 下記の形式を作る
    // メーカーコード/属性1（カラーなど）/属性2（サイズなど）


    let modelClass = [];
    if (item.model) modelClass.push(item.model);
    if (item.class1_value) modelClass.push(item.class1_value);
    if (item.class2_value) modelClass.push(item.class2_value); // 商品種別を割り当てる

    let product_type_id;

    switch (item.delivery) {
      case '宅配便':
        product_type_id = 1;
        break;

      case 'ゆうパケット':
        product_type_id = 2;
        break;

      default:
        product_type_id = 1;
        break;
    } // 商品タグを設定する


    let tags = [];

    switch (item.delivery) {
      case '宅配便':
        tags.push({
          tag: 4,
          set: 'on'
        }, {
          tag: 5,
          set: 'off'
        });
        break;

      case 'ゆうパケット':
        tags.push({
          tag: 5,
          set: 'on'
        }, {
          tag: 4,
          set: 'off'
        });
        break;
    } // 商品データを作る


    let data = {
      product_id: product_id,
      name: `${modelClass.join('/')} ${item.name} ${item.jan_code}`,
      description_detail: item.description,
      product_code: item.model,
      price01: item.retail_price,
      price02: item.sales_price,
      images: item.images,
      product_type_id: product_type_id,
      tags: tags
    };
    Object.assign(this, {
      creator_id: creator_id
    });
    Object.assign(this, data);
    Object.assign(this, item.mall.sharakuShop);
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"core":{"cube3api.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/core/cube3api.js                                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  Cube3Api: () => Cube3Api
});
let MySQL;
module.watch(require("../../imports/util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 0);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 1);

class Cube3Api {
  constructor(mysql = new MySQL()) {
    this.mysql_ = mysql;
  }

  productTagUpdate(data) {
    return Promise.asyncApply(() => {
      let creator_id = data.creator_id;
      let res = [];

      let tagon = tag => Promise.asyncApply(() => {
        res.push(Promise.await(this.mysql_.queryInsert('dtb_product_tag', {}, {
          product_id: data.product_id,
          tag: tag,
          creator_id: creator_id
        })));
      });

      let tagoff = tag => Promise.asyncApply(() => {
        let sql = `
      DELETE FROM dtb_product_tag 
      WHERE product_id = ${data.product_id} AND tag = ${tag}
      `;
        res.push(Promise.await(this.mysql_.query(sql)));
      });

      for (let tagSet of data.tags) {
        switch (tagSet.set) {
          case 'on':
            Promise.await(tagon(tagSet.tag));
            break;

          case 'off':
            Promise.await(tagoff(tagSet.tag));
            break;
        }
      }

      return {
        res: res
      };
    });
  }

  productImageUpdate(data) {
    return Promise.asyncApply(() => {
      let product_id = data.product_id;
      let images = data.images;
      let creator_id = data.creator_id;
      let res = []; // 商品に関連するすべての画像情報を削除する

      let sql = `DELETE FROM dtb_product_image WHERE product_id = ${product_id}`;
      res.push(Promise.await(this.mysql_.query(sql))); // 改めて画像を登録しなおす

      for (let i = 0; i < images.length; i++) {
        this.mysql_.queryInsert('dtb_product_image', {
          product_id: product_id,
          creator_id: creator_id,
          file_name: images[i],
          rank: i + 1
        }, {
          create_date: 'NOW()'
        });
      }

      return {
        res: res
      };
    });
  }

  productUpdate(data) {
    return Promise.asyncApply(() => {
      let update_data = {};
      let keys = []; // dtb_product

      keys = ['status', 'name', 'note', 'description_list', 'description_detail', 'search_word', 'free_area'];

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      this.mysql_.queryUpdate('dtb_product', `product_id = ${data.product_id}`, update_data, {
        update_date: 'NOW()'
      }); // dtb_product_class

      update_data = {};
      keys = ['delivery_date_id', 'product_code', 'sale_limit', 'price01', 'price02', 'delivery_fee'];

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      let res = this.mysql_.queryUpdate('dtb_product_class', `product_id = ${data.product_id}`, update_data, {
        update_date: 'NOW()'
      });
      return {
        res: res
      };
    });
  }

  productCreate(data) {
    return Promise.asyncApply(() => {
      let creator_id = data.creator_id;
      let res = {};
      let update_data = {};
      let keys = [];
      keys = ['name', 'description_detail']; // {
      //   name: item.name,
      //   description_detail: item.description,
      // },

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_id = Promise.await(this.mysql_.queryInsert('dtb_product', update_data, {
        creator_id: creator_id,
        status: 1,
        note: 'NULL',
        description_list: 'NULL',
        search_word: 'NULL',
        free_area: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));
      update_data = {};
      keys = ['product_code', 'product_type_id', 'price01', 'price02']; // {
      //   product_code: item.model,
      //   price01: item.retail_price,
      //   price02: item.sales_price,
      // },

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_class_id = Promise.await(this.mysql_.queryInsert('dtb_product_class', update_data, {
        creator_id: creator_id,
        product_id: res.product_id,
        stock: 0,
        stock_unlimited: 0,
        class_category_id1: 'NULL',
        class_category_id2: 'NULL',
        delivery_date_id: 'NULL',
        sale_limit: 'NULL',
        delivery_fee: 'NULL',
        create_date: 'NOW()',
        update_date: 'NOW()'
      }));

      for (let k of keys) {
        if (data[k]) update_data[k] = data[k];
      }

      res.product_stock_id = Promise.await(this.mysql_.queryInsert('dtb_product_stock', {}, {
        product_class_id: res.product_class_id,
        creator_id: creator_id,
        stock: 0,
        create_date: 'NOW()',
        update_date: 'NOW()'
      })); // for test

      return {
        res: res
      };
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"dbfilter.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/core/dbfilter.js                                                                                        //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  DBFilterFactory: () => DBFilterFactory,
  DBFilter: () => DBFilter,
  MysqlDBFilter: () => MysqlDBFilter,
  MongoDBFilter: () => MongoDBFilter
});
let Mongo;
module.watch(require("meteor/mongo"), {
  Mongo(v) {
    Mongo = v;
  }

}, 0);
let Meteor;
module.watch(require("meteor/meteor"), {
  Meteor(v) {
    Meteor = v;
  }

}, 1);
let sift;
module.watch(require("sift"), {
  default(v) {
    sift = v;
  }

}, 2);
let mobject;
module.watch(require("mongoobject"), {
  default(v) {
    mobject = v;
  }

}, 3);
let MySQL;
module.watch(require("../util/mysql"), {
  default(v) {
    MySQL = v;
  }

}, 4);
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 5);

class DBFilterFactory {
  constructor(plug, profile) {
    let instance;

    switch (plug.type) {
      case "mysql":
        instance = new MysqlDBFilter(plug, profile);
    }

    return instance;
  }

}

class DBFilter {
  // DB からデータを取得するプロセス
  constructor(plug, profile) {
    this.plug = plug;
    this.profile = profile;
  }

  static factory(plug, profile) {
    let instance;

    switch (plug.type) {
      case "mysql":
        return new MysqlDBFilter(plug, profile);

      default:
        throw new Error("invalid plug type");
    }
  }

  getPlug_() {
    return this.plug;
  }

  getCred_() {
    return this.plug.cred;
  }

  getProfile_() {
    return this.profile;
  }

  setImportFunction_(fn = (onResult = record => {}, onError = e => {}) => Promise.asyncApply(() => {})) {
    this.import = fn;
  }
  /**
   * traces members of the group
   * useage:
   * 
   * 
   * @param { Object } iterators { filterName: async (doc,context)=>{}, ... } iterator for each filters 
   * @param { async function } onError error handler while iterating
   * @returns { Object } { filterName: { query: any, count: number }, ... }
   */


  foreach(iterators = {}) {
    return Promise.asyncApply(() => {
      let profile = this.getProfile_(); // misc フィルターを末尾に自動追加

      profile.filters.push({
        name: 'misc',
        query: {}
      });
      let counter = {};

      for (let f of profile.filters) {}

      let filters = [];

      for (let f of profile.filters) {
        counter[f.name] = {
          query: f.query,
          limit: typeof f.limit !== 'undefined' ? f.limit : 0,
          count: 0
        };
        filters.push({
          name: f.name,
          exam: sift(mobject.unescape(f.query))
        });
      }

      Promise.await(this.import((record, context) => Promise.asyncApply(() => {
        for (let f of filters) {
          // counter limiter
          let c = counter[f.name];

          if (c.limit) {
            if (c.count >= c.limit) {
              continue;
            }
          }

          if (f.exam(record)) {
            // counter limiter
            c.count++; // iterator

            if (typeof iterators[f.name] !== "undefined") {
              Promise.await(iterators[f.name](record, context));
            }

            break;
          }
        }
      }))); // return result of filtering

      return counter;
    });
  }

}

class MysqlDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile);
    let cred = this.getCred_();
    this.mysql = new MySQL(cred);
    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let sql = `SELECT * FROM ${plug.table}`;
      return Promise.await(this.mysql.streamingQuery(sql, onResult, e => {
        throw e;
      }));
    }));
  }

}

class MongoDBFilter extends DBFilter {
  constructor(plug, profile) {
    super(plug, profile); // mongo へ接続

    this.setImportFunction_((onResult, onError) => Promise.asyncApply(() => {
      let client;
      client = Promise.await(MongoClient.connect(plug.uri)); // コレクションを取得

      let db = client.db(plug.database);
      let collection = db.collection(plug.collection);
      let context = {
        client: client,
        collection: collection,
        database: db
      };
      let cur = collection.find();

      while (Promise.await(cur.hasNext())) {
        let doc = Promise.await(cur.next());
        Promise.await(onResult(doc, context));
      }

      ;
    }));
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}},"util":{"mongo.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/util/mongo.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  MongoCollection: () => MongoCollection
});
let MongoClient;
module.watch(require("mongodb"), {
  MongoClient(v) {
    MongoClient = v;
  }

}, 0);

class MongoCollection {
  static get(plug) {
    return Promise.asyncApply(() => {
      let client = Promise.await(MongoClient.connect(plug.uri));
      let db = client.db(plug.database);
      return db.collection(plug.collection);
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"mysql.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/util/mysql.js                                                                                           //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  default: () => MySQL
});
let mysql;
module.watch(require("mysql"), {
  default(v) {
    mysql = v;
  }

}, 0);
let moment;
module.watch(require("moment"), {
  default(v) {
    moment = v;
  }

}, 1);

class MySQL {
  constructor(profile) {
    // コネクションプール初期化
    this.pool = mysql.createPool(profile); // 複数行ステートメント対応

    let profileMulti = {
      multipleStatements: true
    };
    Object.assign(profileMulti, profile);
    this.poolMulti = mysql.createPool(profileMulti);
  }

  static formatDate(date) {
    return moment(date).format().substring(0, 19).replace('T', ' ');
  }
  /**
   * 
   * @param {String} sql 
   */


  query(sql) {
    // コネクション確立
    // let con = await this.getCon();
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql, (e, res) => {
          // コネクション開放
          con.release();

          if (e) {
            reject(e);
          } else resolve(res);
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  queryInsert_(sql) {
    return Promise.asyncApply(() => {
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   * 
   * @param {String} table 
   * @param {Object} data 文字列のパラメーター、null、javascript->mysql日付変換にも対応
   * @param {Object} data_sql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryInsert(table, data = {}, data_sql = {}) {
    return Promise.asyncApply(() => {
      // let res = await this.query(sql);
      // return res.insertId;
      let sql = `INSERT INTO ${table} `;
      let map = new Map();

      for (let k of Object.keys(data)) {
        if (data[k] === null) {
          map.set(k, 'NULL');
        } else if (data[k].constructor.name === 'Date') {
          // 日付を変換
          map.set(k, `"${MySQL.formatDate(data[k])}"`);
        } else {
          map.set(k, `"${data[k]}"`);
        }
      }

      for (let k of Object.keys(data_sql)) {
        map.set(k, data_sql[k] === null ? 'NULL' : data_sql[k]);
      }

      sql += `( ${[...map.keys()].join(',')} ) `;
      sql += `VALUES( ${[...map.values()].join(',')} ) `;
      let res = Promise.await(this.query(sql));
      return res.insertId;
    });
  }
  /**
   * 
   * @param {String} table 
   * @param {String} filter SQL UPDATEステートメントのWHERE句
   * @param {Object} data 文字列のパラメーター
   * @param {Object} data_sql SQLステートメントや数字など文字列以外のパラメータ
   */


  queryUpdate(table, filter, data, data_sql) {
    return Promise.asyncApply(() => {
      let sql = `UPDATE ${table} SET `;
      let updates = [];

      for (let k of Object.keys(data)) {
        updates.push(`${k}="${data[k]}"`);
      }

      for (let k of Object.keys(data_sql)) {
        updates.push(`${k}=${data_sql[k]}`);
      }

      sql += updates.join(',');
      sql += ` WHERE ${filter} `;
      let res = Promise.await(this.query(sql));
      return res;
    });
  } // enable to use multiple statements


  queryMulti(sql) {
    return Promise.asyncApply(() => {
      let poolSwap = this.pool;
      this.pool = this.poolMulti;

      try {
        let res = Promise.await(this.query(sql));
        return res;
      } finally {
        this.pool = poolSwap;
      }
    });
  }

  startTransaction() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`START TRANSACTION;`));
    });
  }

  commit() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`COMMIT;`));
    });
  }

  rollback() {
    return Promise.asyncApply(() => {
      Promise.await(this.query(`ROLLBACK;`));
    });
  }

  streamingQuery(sql, onResult = record => {}, onError = e => {}) {
    return this.getCon().then(con => {
      return new Promise((resolve, reject) => Promise.asyncApply(() => {
        // クエリ送信
        con.query(sql).on('result', record => {
          con.pause();
          onResult(record);
          con.resume();
        }).on('error', e => {
          onError(e);
        }).on('end', () => {
          con.release();
          resolve();
        });
      }));
    }).catch(e => {
      throw e;
    });
  }

  getCon() {
    return new Promise((resolve, reject) => {
      // プールからのコネクション獲得
      this.pool.getConnection((e, con) => {
        if (e) {
          reject(e);
        } else {
          resolve(con);
        }
      });
    }).catch(e => {
      throw e;
    });
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

},"report.js":function(require,exports,module){

/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                                                                                 //
// imports/util/report.js                                                                                          //
//                                                                                                                 //
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
                                                                                                                   //
module.export({
  default: () => Report
});

class Report {
  constructor() {
    this.record = [];
    this.iterator = new Iterator();
  }

  phase(name = '', fn = () => Promise.asyncApply(() => {})) {
    return Promise.asyncApply(() => {
      this.iterator = new Iterator();
      let rec = {};

      try {
        let res = Promise.await(fn());
        Object.assign(rec, {
          type: 'success',
          phase: name,
          result: res
        });
      } catch (e) {
        Object.assign(rec, {
          type: 'error',
          phase: name,
          result: e
        });
      } finally {
        if (this.iterator.total) {
          Object.assign(rec, {
            iterator: this.iterator
          });
        }

        this.record.push(rec);
      }
    });
  }

  iSuccess(newRecord) {
    this.iterator.success(newRecord);
  }

  iError(newRecord) {
    this.iterator.error(newRecord);
  }

  errorOcurred() {
    let iteError = this.iterator.trace.error.total;
    let phaError = false;

    for (let rec of this.record) {
      if (rec.type === 'error') {
        phaError = true;
        break;
      }
    }

    return iteError || phaError;
  }

  publish() {
    if (this.errorOcurred()) {
      throw new Meteor.Error(this.record);
    }

    return this.record;
  }

}

class Iterator {
  constructor() {
    this.total = 0;
    this.trace = {
      success: {
        total: 0,
        records: []
      },
      error: {
        total: 0,
        records: []
      }
    };
  }

  success(newRecord) {
    if (newRecord) {
      this.trace.success.records.push(newRecord);
    }

    this.trace.success.total++;
    this.total++;
  }

  error(newRecord) {
    if (newRecord && newRecord !== {} && newRecord !== '') {
      this.trace.error.records.push(JSON.parse(newRecord));
    }

    this.trace.error.total++;
    this.total++;
  }

}
/////////////////////////////////////////////////////////////////////////////////////////////////////////////////////

}}}},{
  "extensions": [
    ".js",
    ".json"
  ]
});
require("/server/route/upload/image.js");
require("/server/cube/_cubeup.js");
require("/server/cube/_cubex.js");
require("/server/cube/cubemig.js");
require("/server/jline/collection.js");
require("/server/jline/items.js");
require("/server/cube.js");
require("/server/tooltest.js");
require("/server/main.js");
//# sourceURL=meteor://💻app/app/app.js
//# sourceMappingURL=data:application/json;charset=utf8;base64,eyJ2ZXJzaW9uIjozLCJzb3VyY2VzIjpbIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3JvdXRlL3VwbG9hZC9pbWFnZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvX2N1YmV1cC5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2N1YmUvX2N1YmV4LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY3ViZS9jdWJlbWlnLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvamxpbmUvY29sbGVjdGlvbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL2psaW5lL2l0ZW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvY3ViZS5qcyIsIm1ldGVvcjovL/CfkrthcHAvc2VydmVyL3Rvb2x0ZXN0LmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9zZXJ2ZXIvbWFpbi5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb2xsZWN0aW9uL2NvbmZpZ3MuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29sbGVjdGlvbi9maWx0ZXJzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvbGxlY3Rpb24vdXBsb2Fkcy5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy9jb250cm9sbGVyL2l0ZW1zLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL2NvcmUvY3ViZTNhcGkuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvY29yZS9kYmZpbHRlci5qcyIsIm1ldGVvcjovL/CfkrthcHAvaW1wb3J0cy91dGlsL21vbmdvLmpzIiwibWV0ZW9yOi8v8J+Su2FwcC9pbXBvcnRzL3V0aWwvbXlzcWwuanMiLCJtZXRlb3I6Ly/wn5K7YXBwL2ltcG9ydHMvdXRpbC9yZXBvcnQuanMiXSwibmFtZXMiOlsiZnMiLCJtb2R1bGUiLCJ3YXRjaCIsInJlcXVpcmUiLCJkZWZhdWx0IiwidiIsInVuaXFpZCIsIm11bHRpcGFydHkiLCJVcGxvYWRzIiwibXVsdGlwYXJ0eU1pZGRsZXdhcmUiLCJyb3V0ZSIsIldlYkFwcCIsImNvbm5lY3RIYW5kbGVycyIsInVzZSIsInJlcSIsInJlc3AiLCJyZWFkZXIiLCJNZXRlb3IiLCJ3cmFwQXN5bmMiLCJyZWFkRmlsZSIsIndyaXRlciIsIndyaXRlRmlsZSIsInVwbG9hZElkIiwiZmlsZSIsImZpbGVzIiwiZGF0YSIsInBhdGgiLCJmaWxlbmFtZSIsInNhdmVQYXRoIiwiYm9keSIsImltYWdlZGlyIiwiZG9jIiwiY2xpZW50RmlsZU5hbWUiLCJuYW1lIiwidXBsb2FkZWRGaWxlTmFtZSIsImVyciIsImVycm9yIiwiaW5zZXJ0Iiwid3JpdGVIZWFkIiwiZW5kIiwiSlNPTiIsInN0cmluZ2lmeSIsInNhdmVEaXIiLCJSZXBvcnQiLCJNb25nb0RCRmlsdGVyIiwiQ3ViZTNBcGkiLCJNeVNRTCIsIkl0ZW1Db250cm9sbGVyIiwidGFnIiwibWV0aG9kcyIsImNvbmZpZyIsInJlcG9ydCIsImZpbHRlciIsIml0ZW1zREIiLCJwcm9maWxlIiwidGFyZ2V0REIiLCJjdWJlM0RCIiwiYXBpIiwicGhhc2UiLCJmb3JlYWNoIiwiaXRlbSIsImNvbnRleHQiLCJjb2wiLCJjb2xsZWN0aW9uIiwiY3ViZUl0ZW0iLCJpdGVtQ3ViZTMiLCJwcm9kdWN0VXBkYXRlIiwicHJvZHVjdFRhZ1VwZGF0ZSIsImNyZWF0b3JfaWQiLCJpU3VjY2VzcyIsImUiLCJpRXJyb3IiLCJwdWJsaXNoIiwicmVzIiwicHJvZHVjdEltYWdlVXBkYXRlIiwiTW9uZ29DbGllbnQiLCJzb3VyY2VEQiIsImNyZWQiLCJpbnNlcnRSZXQiLCJwcm9kdWN0Q3JlYXRlIiwidXBkYXRlIiwiX2lkIiwiJHNldCIsImNyeXB0byIsIkdyb3VwIiwiR3JvdXBGYWN0b3J5IiwiRmlsdGVyIiwic3JjRmlsdGVySWQiLCJ0ZXN0UXVlcnkiLCJkc3REYiIsImRzdCIsInF1ZXJ5IiwibW9iaWxlTnVsbCIsInJlY29yZCIsInNxbCIsImN1c3RvbWVyX2lkIiwic3RhdHVzIiwic2V4Iiwiam9iIiwiY291bnRyeV9pZCIsInByZWYiLCJuYW1lMDEiLCJuYW1lMDIiLCJrYW5hMDEiLCJrYW5hMDIiLCJjb21wYW55X25hbWUiLCJ6aXAwMSIsInppcDAyIiwiemlwY29kZSIsImFkZHIwMSIsImFkZHIwMiIsImVtYWlsIiwidGVsMDEiLCJ0ZWwwMiIsInRlbDAzIiwiZmF4MDEiLCJmYXgwMiIsImZheDAzIiwiYmlydGgiLCJwYXNzd29yZCIsInNhbHQiLCJzZWNyZXRfa2V5IiwiZmlyc3RfYnV5X2RhdGUiLCJsYXN0X2J1eV9kYXRlIiwiYnV5X3RpbWVzIiwiYnV5X3RvdGFsIiwibm90ZSIsImNyZWF0ZV9kYXRlIiwidXBkYXRlX2RhdGUiLCJkZWxfZmxnIiwicXVlcnlJbnNlcnQiLCJjdXN0b21lcl9hZGRyZXNzX2lkIiwiaWQiLCJtYWlsbWFnYV9mbGciLCJjb3Vwb25fY2QiLCJyYW5kb21CeXRlcyIsInRvU3RyaW5nIiwic3Vic3RyaW5nIiwiY291cG9uX25hbWUiLCJkaXNjb3VudF9wcmljZSIsInBvaW50IiwiY291cG9uX2lkIiwiY291cG9uX3R5cGUiLCJkaXNjb3VudF90eXBlIiwiY291cG9uX3VzZV90aW1lIiwiY291cG9uX3JlbGVhc2UiLCJkaXNjb3VudF9yYXRlIiwiZW5hYmxlX2ZsYWciLCJjb3Vwb25fbWVtYmVyIiwiY291cG9uX2xvd2VyX2xpbWl0IiwiYXZhaWxhYmxlX2Zyb21fZGF0ZSIsImF2YWlsYWJsZV90b19kYXRlIiwiZGIiLCJNb25nb0NvbGxlY3Rpb24iLCJwbHVnIiwicHJvamVjdGlvbiIsImNvbGwiLCJnZXQiLCJmaW5kIiwidG9BcnJheSIsImFnZ3JlZ2F0ZSIsIm1vZGVsIiwiY2xhc3MxIiwiY2xhc3MyIiwiaXRlbWNvbiIsImluaXQiLCJ1cGxvYWRlZCIsInNldEltYWdlIiwiY2xlYW5JbWFnZSIsImluc2VydFJlcyIsImV4cG9ydCIsIkNvbmZpZ3MiLCJNb25nbyIsIkNvbGxlY3Rpb24iLCJpZEdlbmVyYXRpb24iLCJzaWZ0IiwibW9iamVjdCIsIkdyb3VwQmFzZSIsIkZpbHRlcnMiLCJjb25zdHJ1Y3RvciIsImZpbHRlcklkIiwiZmluZE9uZSIsImdldFBsdWciLCJ0eXBlIiwibXlzcWwiLCJpbXBvcnQiLCJvblJlc3VsdCIsIm9uRXJyb3IiLCJ0YWJsZSIsInN0cmVhbWluZ1F1ZXJ5IiwiRXJyb3IiLCJjYWxsYmFja3MiLCJnZXRQcm9maWxlIiwiZmlsdGVycyIsInB1c2giLCJjb3VudCIsInVuZXNjYXBlIiwiZXhhbSIsIkdyb3VwcyIsInBsYXRmb3JtUGx1ZyIsImNhbGxiYWNrIiwiZ3JvdXBJZCIsImtleSIsImN1ciIsImZpZWxkcyIsIlByb21pc2UiLCJyZXNvbHZlIiwicmVqZWN0IiwiZm9yRWFjaCIsImluZGV4IiwiY2F0Y2giLCJJdGVtcyIsImltYWdlcyIsImZldGNoIiwibWFwIiwiY2xhc3MxX3ZhbHVlIiwiY2xhc3MyX3ZhbHVlIiwidXBkYXRlTWFueSIsIiRwdXNoIiwiJGVhY2giLCJwcm9kdWN0X2lkIiwic2hhcmFrdVNob3AiLCJtb2RlbENsYXNzIiwicHJvZHVjdF90eXBlX2lkIiwiZGVsaXZlcnkiLCJ0YWdzIiwic2V0Iiwiam9pbiIsImphbl9jb2RlIiwiZGVzY3JpcHRpb25fZGV0YWlsIiwiZGVzY3JpcHRpb24iLCJwcm9kdWN0X2NvZGUiLCJwcmljZTAxIiwicmV0YWlsX3ByaWNlIiwicHJpY2UwMiIsInNhbGVzX3ByaWNlIiwiT2JqZWN0IiwiYXNzaWduIiwibWFsbCIsIm15c3FsXyIsInRhZ29uIiwidGFnb2ZmIiwidGFnU2V0IiwiaSIsImxlbmd0aCIsImZpbGVfbmFtZSIsInJhbmsiLCJ1cGRhdGVfZGF0YSIsImtleXMiLCJrIiwicXVlcnlVcGRhdGUiLCJkZXNjcmlwdGlvbl9saXN0Iiwic2VhcmNoX3dvcmQiLCJmcmVlX2FyZWEiLCJwcm9kdWN0X2NsYXNzX2lkIiwic3RvY2siLCJzdG9ja191bmxpbWl0ZWQiLCJjbGFzc19jYXRlZ29yeV9pZDEiLCJjbGFzc19jYXRlZ29yeV9pZDIiLCJkZWxpdmVyeV9kYXRlX2lkIiwic2FsZV9saW1pdCIsImRlbGl2ZXJ5X2ZlZSIsInByb2R1Y3Rfc3RvY2tfaWQiLCJEQkZpbHRlckZhY3RvcnkiLCJEQkZpbHRlciIsIk15c3FsREJGaWx0ZXIiLCJpbnN0YW5jZSIsImZhY3RvcnkiLCJnZXRQbHVnXyIsImdldENyZWRfIiwiZ2V0UHJvZmlsZV8iLCJzZXRJbXBvcnRGdW5jdGlvbl8iLCJmbiIsIml0ZXJhdG9ycyIsImNvdW50ZXIiLCJmIiwibGltaXQiLCJjIiwiY2xpZW50IiwiY29ubmVjdCIsInVyaSIsImRhdGFiYXNlIiwiaGFzTmV4dCIsIm5leHQiLCJtb21lbnQiLCJwb29sIiwiY3JlYXRlUG9vbCIsInByb2ZpbGVNdWx0aSIsIm11bHRpcGxlU3RhdGVtZW50cyIsInBvb2xNdWx0aSIsImZvcm1hdERhdGUiLCJkYXRlIiwiZm9ybWF0IiwicmVwbGFjZSIsImdldENvbiIsInRoZW4iLCJjb24iLCJyZWxlYXNlIiwicXVlcnlJbnNlcnRfIiwiaW5zZXJ0SWQiLCJkYXRhX3NxbCIsIk1hcCIsInZhbHVlcyIsInVwZGF0ZXMiLCJxdWVyeU11bHRpIiwicG9vbFN3YXAiLCJzdGFydFRyYW5zYWN0aW9uIiwiY29tbWl0Iiwicm9sbGJhY2siLCJvbiIsInBhdXNlIiwicmVzdW1lIiwiZ2V0Q29ubmVjdGlvbiIsIml0ZXJhdG9yIiwiSXRlcmF0b3IiLCJyZWMiLCJyZXN1bHQiLCJ0b3RhbCIsIm5ld1JlY29yZCIsInN1Y2Nlc3MiLCJlcnJvck9jdXJyZWQiLCJpdGVFcnJvciIsInRyYWNlIiwicGhhRXJyb3IiLCJyZWNvcmRzIiwicGFyc2UiXSwibWFwcGluZ3MiOiI7Ozs7Ozs7O0FBQUEsSUFBSUEsRUFBSjtBQUFPQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsSUFBUixDQUFiLEVBQTJCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDTCxTQUFHSyxDQUFIO0FBQUs7O0FBQWpCLENBQTNCLEVBQThDLENBQTlDO0FBQWlELElBQUlDLE1BQUo7QUFBV0wsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFFBQVIsQ0FBYixFQUErQjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ0MsYUFBT0QsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJRSxVQUFKO0FBQWVOLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxvQkFBUixDQUFiLEVBQTJDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDRSxpQkFBV0YsQ0FBWDtBQUFhOztBQUF6QixDQUEzQyxFQUFzRSxDQUF0RTtBQUF5RSxJQUFJRyxPQUFKO0FBQVlQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxxQ0FBUixDQUFiLEVBQTREO0FBQUNLLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTVELEVBQW9GLENBQXBGO0FBYWhPLElBQUlJLHVCQUF1QkYsWUFBM0I7QUFFQSxNQUFNRyxRQUFRLGVBQWQsQyxDQUVBOztBQUNBQyxPQUFPQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQkgsS0FBM0IsRUFBa0NELG9CQUFsQztBQUNBRSxPQUFPQyxlQUFQLENBQXVCQyxHQUF2QixDQUEyQkgsS0FBM0IsRUFBa0MsQ0FBQ0ksR0FBRCxFQUFNQyxJQUFOLEtBQWU7QUFDL0M7QUFFQSxRQUFNQyxTQUFTQyxPQUFPQyxTQUFQLENBQWlCbEIsR0FBR21CLFFBQXBCLENBQWY7QUFDQSxRQUFNQyxTQUFTSCxPQUFPQyxTQUFQLENBQWlCbEIsR0FBR3FCLFNBQXBCLENBQWY7QUFDQSxRQUFNQyxXQUFXaEIsUUFBakI7O0FBRUEsT0FBSyxJQUFJaUIsSUFBVCxJQUFpQlQsSUFBSVUsS0FBSixDQUFVRCxJQUEzQixFQUFpQztBQUMvQixVQUFNRSxPQUFPVCxPQUFPTyxLQUFLRyxJQUFaLENBQWIsQ0FEK0IsQ0FFL0I7QUFDQTs7QUFDQSxRQUFJQyxXQUFZLEdBQUVyQixRQUFTLE1BQTNCLENBSitCLENBTS9COztBQUNBLFFBQUlzQixXQUFXZCxJQUFJZSxJQUFKLENBQVNDLFFBQVQsR0FBb0IsR0FBcEIsR0FBMEJILFFBQXpDLENBUCtCLENBUy9CO0FBRUE7O0FBQ0EsUUFBSUksTUFBTTtBQUNSVCxnQkFBVUEsUUFERjtBQUVSVSxzQkFBZ0JULEtBQUtVLElBRmI7QUFHUkMsd0JBQWtCUDtBQUhWLEtBQVY7O0FBTUEsUUFBRztBQUNEUCxhQUFPUSxRQUFQLEVBQWlCSCxJQUFqQjtBQUNELEtBRkQsQ0FHQSxPQUFNVSxHQUFOLEVBQVU7QUFDUkosVUFBSUssS0FBSixHQUFZRCxHQUFaO0FBQ0Q7O0FBQ0QzQixZQUFRNkIsTUFBUixDQUFlTixHQUFmO0FBRUEsV0FBT1IsSUFBUDtBQUVEOztBQUFBO0FBQ0RSLE9BQUt1QixTQUFMLENBQWUsR0FBZjtBQUNBdkIsT0FBS3dCLEdBQUwsQ0FBU0MsS0FBS0MsU0FBTCxDQUFlO0FBQ3RCbkIsY0FBVUEsUUFEWTtBQUV0Qm9CLGFBQVM1QixJQUFJZSxJQUFKLENBQVNDO0FBRkksR0FBZixDQUFUO0FBS0QsQ0ExQ0QsRTs7Ozs7Ozs7Ozs7QUNuQkEsSUFBSWEsTUFBSjtBQUFXMUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzQyxhQUFPdEMsQ0FBUDtBQUFTOztBQUFyQixDQUFsRCxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJdUMsYUFBSjtBQUFrQjNDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUN5QyxnQkFBY3ZDLENBQWQsRUFBZ0I7QUFBQ3VDLG9CQUFjdkMsQ0FBZDtBQUFnQjs7QUFBbEMsQ0FBcEQsRUFBd0YsQ0FBeEY7QUFBMkYsSUFBSXdDLFFBQUo7QUFBYTVDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSw2QkFBUixDQUFiLEVBQW9EO0FBQUMwQyxXQUFTeEMsQ0FBVCxFQUFXO0FBQUN3QyxlQUFTeEMsQ0FBVDtBQUFXOztBQUF4QixDQUFwRCxFQUE4RSxDQUE5RTtBQUFpRixJQUFJeUMsS0FBSjtBQUFVN0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN5QyxZQUFNekMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJMEMsY0FBSjtBQUFtQjlDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxnQ0FBUixDQUFiLEVBQXVEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDMEMscUJBQWUxQyxDQUFmO0FBQWlCOztBQUE3QixDQUF2RCxFQUFzRixDQUF0RjtBQVV6WSxJQUFJMkMsTUFBTSxRQUFWO0FBRUEvQixPQUFPZ0MsT0FBUCxDQUFlO0FBRWI7QUFDQTtBQUVBLEdBQVEsR0FBRUQsR0FBSSxPQUFkLEVBQXNCRSxNQUF0QjtBQUFBLG9DQUE4QjtBQUU1QixVQUFJQyxTQUFTLElBQUlSLE1BQUosRUFBYjtBQUVBLFVBQUlTLFNBQVMsSUFBSVIsYUFBSixDQUFrQk0sT0FBT0csT0FBekIsRUFBa0NILE9BQU9JLE9BQXpDLENBQWI7QUFDQSxVQUFJQyxXQUFXLElBQUlULEtBQUosQ0FBVUksT0FBT00sT0FBakIsQ0FBZjtBQUNBLFVBQUlDLE1BQU0sSUFBSVosUUFBSixDQUFhVSxRQUFiLENBQVY7QUFFQSxvQkFBTUosT0FBT08sS0FBUCxDQUNKLHNCQURJLEVBRUosK0JBQVk7QUFDViw2QkFBYU4sT0FBT08sT0FBUCxDQUFlO0FBQ3hCLG9CQUFVLENBQU9DLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFFakMsZ0JBQUlDLE1BQU1ELFFBQVFFLFVBQWxCOztBQUVBLGdCQUFJO0FBRUZDLHlCQUFXakIsZUFBZWtCLFNBQWYsQ0FBeUJMLElBQXpCLENBQVg7QUFFQSw0QkFBTUgsSUFBSVMsYUFBSixDQUFrQkYsUUFBbEIsQ0FBTjtBQUNBLDRCQUFNUCxJQUFJVSxnQkFBSixDQUFxQmpCLE9BQU9rQixVQUE1QixFQUF1Q0osUUFBdkMsQ0FBTjtBQUVBYixxQkFBT2tCLFFBQVA7QUFFRCxhQVRELENBU0UsT0FBT0MsQ0FBUCxFQUFVO0FBRVZuQixxQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUVEO0FBQ0YsV0FsQlM7QUFEYyxTQUFmLEVBcUJKQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBckJXLENBQWI7QUF5QkQsT0ExQkQsQ0FGSSxDQUFOO0FBZ0NBLGFBQU9uQixPQUFPcUIsT0FBUCxFQUFQO0FBRUQsS0ExQ0Q7QUFBQSxHQUxhOztBQWtEYjtBQUNBO0FBRUEsR0FBUSxHQUFFeEIsR0FBSSxRQUFkLEVBQXVCRSxNQUF2QjtBQUFBLG9DQUErQjtBQUU3QixVQUFJQyxTQUFTLElBQUlSLE1BQUosRUFBYjtBQUVBLFVBQUlTLFNBQVMsSUFBSVIsYUFBSixDQUFrQk0sT0FBT0csT0FBekIsRUFBa0NILE9BQU9JLE9BQXpDLENBQWI7QUFDQSxVQUFJQyxXQUFXLElBQUlULEtBQUosQ0FBVUksT0FBT00sT0FBakIsQ0FBZjtBQUNBLFVBQUlDLE1BQU0sSUFBSVosUUFBSixDQUFhVSxRQUFiLENBQVY7QUFFQSxvQkFBTUosT0FBT08sS0FBUCxDQUNKLHNCQURJLEVBRUosK0JBQVk7QUFDViw2QkFBYU4sT0FBT08sT0FBUCxDQUFlO0FBQ3hCLG9CQUFVLENBQU9DLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFFakMsZ0JBQUlDLE1BQU1ELFFBQVFFLFVBQWxCOztBQUVBLGdCQUFJO0FBRUYsa0JBQUlVLG9CQUFZaEIsSUFBSWlCLGtCQUFKLENBQ2R4QixPQUFPa0IsVUFETyxFQUVkckIsZUFBZWtCLFNBQWYsQ0FBeUJMLElBQXpCLENBRmMsQ0FBWixDQUFKO0FBS0FULHFCQUFPa0IsUUFBUDtBQUVELGFBVEQsQ0FTRSxPQUFPQyxDQUFQLEVBQVU7QUFFVm5CLHFCQUFPb0IsTUFBUCxDQUFjRCxDQUFkO0FBRUQ7QUFDRixXQWxCUztBQURjLFNBQWYsRUFxQkpBLENBQVAsNkJBQWE7QUFDWCxnQkFBTUEsQ0FBTjtBQUNELFNBRkQsQ0FyQlcsQ0FBYjtBQXlCRCxPQTFCRCxDQUZJLENBQU47QUFnQ0EsYUFBT25CLE9BQU9xQixPQUFQLEVBQVA7QUFFRCxLQTFDRDtBQUFBOztBQXJEYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDWkEsSUFBSTdCLE1BQUo7QUFBVzFDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwyQkFBUixDQUFiLEVBQWtEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDc0MsYUFBT3RDLENBQVA7QUFBUzs7QUFBckIsQ0FBbEQsRUFBeUUsQ0FBekU7QUFBNEUsSUFBSXVDLGFBQUo7QUFBa0IzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDeUMsZ0JBQWN2QyxDQUFkLEVBQWdCO0FBQUN1QyxvQkFBY3ZDLENBQWQ7QUFBZ0I7O0FBQWxDLENBQXBELEVBQXdGLENBQXhGO0FBQTJGLElBQUl3QyxRQUFKO0FBQWE1QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsNkJBQVIsQ0FBYixFQUFvRDtBQUFDMEMsV0FBU3hDLENBQVQsRUFBVztBQUFDd0MsZUFBU3hDLENBQVQ7QUFBVzs7QUFBeEIsQ0FBcEQsRUFBOEUsQ0FBOUU7QUFBaUYsSUFBSXlDLEtBQUo7QUFBVTdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDeUMsWUFBTXpDLENBQU47QUFBUTs7QUFBcEIsQ0FBakQsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSXNFLFdBQUo7QUFBZ0IxRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUN3RSxjQUFZdEUsQ0FBWixFQUFjO0FBQUNzRSxrQkFBWXRFLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7QUFBbUUsSUFBSTBDLGNBQUo7QUFBbUI5QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsZ0NBQVIsQ0FBYixFQUF1RDtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQzBDLHFCQUFlMUMsQ0FBZjtBQUFpQjs7QUFBN0IsQ0FBdkQsRUFBc0YsQ0FBdEY7QUFhNWQsSUFBSTJDLE1BQU0sT0FBVjtBQUVBL0IsT0FBT2dDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxVQUFkLEVBQXlCRSxNQUF6QjtBQUFBLG9DQUFpQztBQUUvQixVQUFJQyxTQUFTLElBQUlSLE1BQUosRUFBYixDQUYrQixDQUkvQjtBQUNBO0FBRUE7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTs7QUFFQSxVQUFJUyxTQUFTLElBQUlSLGFBQUosQ0FBa0JNLE9BQU8wQixRQUF6QixFQUFtQzFCLE9BQU9JLE9BQTFDLENBQWI7QUFDQSxVQUFJQyxXQUFXLElBQUlULEtBQUosQ0FBVUksT0FBT0ssUUFBUCxDQUFnQnNCLElBQTFCLENBQWY7QUFDQSxVQUFJcEIsTUFBTSxJQUFJWixRQUFKLENBQWFVLFFBQWIsQ0FBVjtBQUVBLG9CQUFNSixPQUFPTyxLQUFQLENBQ0osc0JBREksRUFFSiwrQkFBWTtBQUNWLDZCQUFhTixPQUFPTyxPQUFQLENBQWU7QUFDeEIsOEJBQW9CLENBQU9DLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFFM0MsZ0JBQUlDLE1BQU1ELFFBQVFFLFVBQWxCOztBQUVBLGdCQUFJO0FBRUYsa0JBQUllLDBCQUFrQnJCLElBQUlzQixhQUFKLENBQ3BCN0IsT0FBT2tCLFVBRGEsRUFFcEJyQixlQUFla0IsU0FBZixDQUF5QkwsSUFBekIsQ0FGb0IsQ0FBbEIsQ0FBSjtBQUtBLDRCQUFNRSxJQUFJa0IsTUFBSixDQUFXO0FBQ2ZDLHFCQUFLckIsS0FBS3FCO0FBREssZUFBWCxFQUVIO0FBQ0RDLHNCQUFNO0FBQ0osc0NBQW9CSixVQUFVTDtBQUQxQjtBQURMLGVBRkcsQ0FBTjtBQVFBdEIscUJBQU9rQixRQUFQO0FBRUQsYUFqQkQsQ0FpQkUsT0FBT0MsQ0FBUCxFQUFVO0FBRVZuQixxQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUVEO0FBQ0YsV0ExQm1CO0FBREksU0FBZixFQTZCSkEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQTdCVyxDQUFiO0FBaUNELE9BbENELENBRkksQ0FBTjtBQXdDQSxhQUFPbkIsT0FBT3FCLE9BQVAsRUFBUDtBQUVELEtBOUREO0FBQUE7O0FBRmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ2ZBLElBQUlXLE1BQUo7QUFBV2xGLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxRQUFSLENBQWIsRUFBK0I7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUM4RSxhQUFPOUUsQ0FBUDtBQUFTOztBQUFyQixDQUEvQixFQUFzRCxDQUF0RDtBQUF5RCxJQUFJeUMsS0FBSjtBQUFVN0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN5QyxZQUFNekMsQ0FBTjtBQUFROztBQUFwQixDQUFqRCxFQUF1RSxDQUF2RTtBQUEwRSxJQUFJc0MsTUFBSjtBQUFXMUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDJCQUFSLENBQWIsRUFBa0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUNzQyxhQUFPdEMsQ0FBUDtBQUFTOztBQUFyQixDQUFsRCxFQUF5RSxDQUF6RTtBQUE0RSxJQUFJK0UsS0FBSixFQUFVQyxZQUFWO0FBQXVCcEYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGlDQUFSLENBQWIsRUFBd0Q7QUFBQ2lGLFFBQU0vRSxDQUFOLEVBQVE7QUFBQytFLFlBQU0vRSxDQUFOO0FBQVEsR0FBbEI7O0FBQW1CZ0YsZUFBYWhGLENBQWIsRUFBZTtBQUFDZ0YsbUJBQWFoRixDQUFiO0FBQWU7O0FBQWxELENBQXhELEVBQTRHLENBQTVHO0FBQStHLElBQUlpRixNQUFKO0FBQVdyRixPQUFPQyxLQUFQLENBQWFDLFFBQVEsa0NBQVIsQ0FBYixFQUF5RDtBQUFDbUYsU0FBT2pGLENBQVAsRUFBUztBQUFDaUYsYUFBT2pGLENBQVA7QUFBUzs7QUFBcEIsQ0FBekQsRUFBK0UsQ0FBL0U7QUFZaFksSUFBSTJDLE1BQU0sU0FBVjtBQUVBL0IsT0FBT2dDLE9BQVAsQ0FBZTtBQUViLEdBQVEsR0FBRUQsR0FBSSxVQUFkLEVBQXlCRSxNQUF6QjtBQUFBLG9DQUFpQztBQUUvQixVQUFJQyxTQUFTLElBQUlSLE1BQUosRUFBYixDQUYrQixDQUkvQjtBQUNBOztBQUVBLFVBQUlTLFNBQVMsSUFBSWtDLE1BQUosQ0FBV3BDLE9BQU9xQyxXQUFsQixDQUFiLENBUCtCLENBUS9CO0FBRUE7QUFDQTs7QUFFQSxVQUFJQyxZQUFZLGdCQUFoQjtBQUVBLFVBQUlDLFFBQVEsSUFBSTNDLEtBQUosQ0FBVUksT0FBT3dDLEdBQVAsQ0FBV2IsSUFBckIsQ0FBWjtBQUVBLG9CQUFNMUIsT0FBT08sS0FBUCxDQUFhLHdCQUFiLEVBQ0osK0JBQVk7QUFDVixzQkFBTStCLE1BQU1FLEtBQU4sQ0FBWUgsU0FBWixDQUFOO0FBQ0QsT0FGRCxDQURJLENBQU4sRUFqQitCLENBdUIvQjtBQUNBOztBQUVBLG9CQUFNckMsT0FBT08sS0FBUCxDQUFhLHVCQUFiLEVBQ0osK0JBQVk7QUFDViw2QkFBYU4sT0FBT08sT0FBUCxDQUFlO0FBQ3hCaUMsc0JBQW1CQyxNQUFQLDZCQUFrQjtBQUU1QjtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7QUFFQTtBQUVBLGdCQUFJQyxNQUFPOzs7OzswQkFLRUQsT0FBT0UsV0FBYSxNQUFNRixPQUFPRyxNQUFRLE1BQU1ILE9BQU9JLEdBQUssTUFBTUosT0FBT0ssR0FBSyxNQUFNTCxPQUFPTSxVQUFZLE1BQU1OLE9BQU9PLElBQU0sTUFBTVAsT0FBT1EsTUFBUSxNQUFNUixPQUFPUyxNQUFRLE1BQU1ULE9BQU9VLE1BQVEsTUFBTVYsT0FBT1csTUFBUSxNQUFNWCxPQUFPWSxZQUFjLE1BQU1aLE9BQU9hLEtBQU8sTUFBTWIsT0FBT2MsS0FBTyxNQUFNZCxPQUFPZSxPQUFTLE1BQU1mLE9BQU9nQixNQUFRLE1BQU1oQixPQUFPaUIsTUFBUSxNQUFNakIsT0FBT2tCLEtBQU8sTUFBTWxCLE9BQU9tQixLQUFPLE1BQU1uQixPQUFPb0IsS0FBTyxNQUFNcEIsT0FBT3FCLEtBQU8sTUFBTXJCLE9BQU9zQixLQUFPLE1BQU10QixPQUFPdUIsS0FBTyxNQUFNdkIsT0FBT3dCLEtBQU8sTUFBTXhCLE9BQU95QixLQUFPLE1BQU16QixPQUFPMEIsUUFBVSxNQUFNMUIsT0FBTzJCLElBQU0sTUFBTTNCLE9BQU80QixVQUFZLE1BQU01QixPQUFPNkIsY0FBZ0IsTUFBTTdCLE9BQU84QixhQUFlLE1BQU05QixPQUFPK0IsU0FBVyxNQUFNL0IsT0FBT2dDLFNBQVcsTUFBTWhDLE9BQU9pQyxJQUFNLE1BQU1qQyxPQUFPa0MsV0FBYSxNQUFNbEMsT0FBT21DLFdBQWEsTUFBTW5DLE9BQU9vQyxPQUFTOztpQkFMdHdCOztBQVNBLGdCQUFJO0FBQ0YsNEJBQU14QyxNQUFNeUMsV0FBTixDQUNKLGNBREksRUFFSjtBQUNFbkMsNkJBQWFGLE9BQU9FLFdBRHRCO0FBRUVDLHdCQUFRSCxPQUFPRyxNQUZqQjtBQUdFQyxxQkFBS0osT0FBT0ksR0FIZDtBQUlFQyxxQkFBS0wsT0FBT0ssR0FKZDtBQUtFQyw0QkFBWU4sT0FBT00sVUFMckI7QUFNRUMsc0JBQU1QLE9BQU9PLElBTmY7QUFPRUMsd0JBQVFSLE9BQU9RLE1BUGpCO0FBUUVDLHdCQUFRVCxPQUFPUyxNQVJqQjtBQVNFQyx3QkFBUVYsT0FBT1UsTUFUakI7QUFVRUMsd0JBQVFYLE9BQU9XLE1BVmpCO0FBV0VDLDhCQUFjWixPQUFPWSxZQVh2QjtBQVlFQyx1QkFBT2IsT0FBT2EsS0FaaEI7QUFhRUMsdUJBQU9kLE9BQU9jLEtBYmhCO0FBY0VDLHlCQUFTZixPQUFPZSxPQWRsQjtBQWVFQyx3QkFBUWhCLE9BQU9nQixNQWZqQjtBQWdCRUMsd0JBQVFqQixPQUFPaUIsTUFoQmpCO0FBaUJFQyx1QkFBT2xCLE9BQU9rQixLQWpCaEI7QUFrQkVDLHVCQUFPbkIsT0FBT21CLEtBbEJoQjtBQW1CRUMsdUJBQU9wQixPQUFPb0IsS0FuQmhCO0FBb0JFQyx1QkFBT3JCLE9BQU9xQixLQXBCaEI7QUFxQkVDLHVCQUFPdEIsT0FBT3NCLEtBckJoQjtBQXNCRUMsdUJBQU92QixPQUFPdUIsS0F0QmhCO0FBdUJFQyx1QkFBT3hCLE9BQU93QixLQXZCaEI7QUF3QkVDLHVCQUFPekIsT0FBT3lCLEtBeEJoQjtBQXlCRUMsMEJBQVUxQixPQUFPMEIsUUF6Qm5CO0FBMEJFQyxzQkFBTTNCLE9BQU8yQixJQTFCZjtBQTJCRUMsNEJBQVk1QixPQUFPNEIsVUEzQnJCO0FBNEJFQyxnQ0FBZ0I3QixPQUFPNkIsY0E1QnpCO0FBNkJFQywrQkFBZTlCLE9BQU84QixhQTdCeEI7QUE4QkVDLDJCQUFXL0IsT0FBTytCLFNBOUJwQjtBQStCRUMsMkJBQVdoQyxPQUFPZ0MsU0EvQnBCO0FBZ0NFQyxzQkFBTWpDLE9BQU9pQyxJQWhDZjtBQWlDRUMsNkJBQWFsQyxPQUFPa0MsV0FqQ3RCO0FBa0NFQyw2QkFBYW5DLE9BQU9tQyxXQWxDdEI7QUFtQ0VDLHlCQUFTcEMsT0FBT29DO0FBbkNsQixlQUZJLENBQU47QUF3Q0QsYUF6Q0QsQ0F5Q0UsT0FBTzNELENBQVAsRUFBVTtBQUNWbkIscUJBQU9vQixNQUFQLENBQWNELENBQWQ7QUFDRCxhQWxFMkIsQ0FvRTVCOzs7QUFDQSxnQkFBSTtBQUNGLDRCQUFNbUIsTUFBTXlDLFdBQU4sQ0FDSixzQkFESSxFQUNvQjtBQUN0QkMscUNBQXFCLElBREM7QUFFdEJwQyw2QkFBYUYsT0FBT0UsV0FGRTtBQUd0QkksNEJBQVlOLE9BQU9NLFVBSEc7QUFJdEJDLHNCQUFNUCxPQUFPTyxJQUpTO0FBS3RCQyx3QkFBUVIsT0FBT1EsTUFMTztBQU10QkMsd0JBQVFULE9BQU9TLE1BTk87QUFPdEJDLHdCQUFRVixPQUFPVSxNQVBPO0FBUXRCQyx3QkFBUVgsT0FBT1csTUFSTztBQVN0QkMsOEJBQWNaLE9BQU9ZLFlBVEM7QUFVdEJDLHVCQUFPYixPQUFPYSxLQVZRO0FBV3RCQyx1QkFBT2QsT0FBT2MsS0FYUTtBQVl0QkMseUJBQVNmLE9BQU9lLE9BWk07QUFhdEJDLHdCQUFRaEIsT0FBT2dCLE1BYk87QUFjdEJDLHdCQUFRakIsT0FBT2lCLE1BZE87QUFldEJFLHVCQUFPbkIsT0FBT21CLEtBZlE7QUFnQnRCQyx1QkFBT3BCLE9BQU9vQixLQWhCUTtBQWlCdEJDLHVCQUFPckIsT0FBT3FCLEtBakJRO0FBa0J0QkMsdUJBQU90QixPQUFPc0IsS0FsQlE7QUFtQnRCQyx1QkFBT3ZCLE9BQU91QixLQW5CUTtBQW9CdEJDLHVCQUFPeEIsT0FBT3dCLEtBcEJRO0FBcUJ0QlUsNkJBQWFsQyxPQUFPa0MsV0FyQkU7QUFzQnRCQyw2QkFBYW5DLE9BQU9tQyxXQXRCRTtBQXVCdEJDLHlCQUFTcEMsT0FBT29DO0FBdkJNLGVBRHBCLENBQU47QUEyQkQsYUE1QkQsQ0E0QkUsT0FBTzNELENBQVAsRUFBVTtBQUNWbkIscUJBQU9vQixNQUFQLENBQWNELENBQWQ7QUFDRCxhQW5HMkIsQ0FxRzVCOzs7QUFDQSxnQkFBSTtBQUNGLDRCQUFNbUIsTUFBTXlDLFdBQU4sQ0FDSix1QkFESSxFQUNxQjtBQUN2QkUsb0JBQUksSUFEbUI7QUFFdkJyQyw2QkFBYUYsT0FBT0UsV0FGRztBQUd2QnNDLDhCQUFjeEMsT0FBT3dDLFlBSEU7QUFJdkJOLDZCQUFhbEMsT0FBT2tDLFdBSkc7QUFLdkJDLDZCQUFhbkMsT0FBT21DLFdBTEc7QUFNdkJDLHlCQUFTcEMsT0FBT29DO0FBTk8sZUFEckIsQ0FBTjtBQVVELGFBWEQsQ0FXRSxPQUFPM0QsQ0FBUCxFQUFVO0FBQ1ZuQixxQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUNELGFBbkgyQixDQXFINUI7OztBQUVBLGdCQUFJZ0UsWUFBWW5ELE9BQU9vRCxXQUFQLENBQW1CLENBQW5CLEVBQXNCQyxRQUF0QixDQUErQixRQUEvQixFQUF5Q0MsU0FBekMsQ0FBbUQsQ0FBbkQsRUFBcUQsRUFBckQsQ0FBaEI7QUFFQSxnQkFBSUMsY0FBZSxHQUFFN0MsT0FBT1EsTUFBTyxJQUFHUixPQUFPUyxNQUFPLG1CQUFrQlQsT0FBT0UsV0FBWSxFQUF6RjtBQUVBLGdCQUFJNEMsaUJBQWlCOUMsT0FBTytDLEtBQVAsR0FBZSxHQUFwQzs7QUFFQSxnQkFBSTtBQUNGLGtCQUFJbkUsb0JBQVlnQixNQUFNeUMsV0FBTixDQUNkLFlBRGMsRUFDQTtBQUNaVywyQkFBVyxJQURDO0FBRVpQLDJCQUFXQSxTQUZDO0FBR1pRLDZCQUFhLENBSEQ7QUFHSTtBQUNoQkosNkJBQWFBLFdBSkQ7QUFLWkssK0JBQWUsQ0FMSDtBQU1aQyxpQ0FBaUIsQ0FOTDtBQU9aQyxnQ0FBZ0IsQ0FQSjtBQVFaTixnQ0FBZ0JBLGNBUko7QUFTWk8sK0JBQWUsSUFUSDtBQVVaQyw2QkFBYSxDQVZEO0FBV1pDLCtCQUFlLENBWEg7QUFZWkMsb0NBQW9CLElBWlI7QUFhWkMscUNBQXFCLHFCQWJUO0FBY1pDLG1DQUFtQixxQkFkUDtBQWVadEIseUJBQVM7QUFmRyxlQURBLEVBaUJaO0FBQ0FGLDZCQUFhLE9BRGI7QUFFQUMsNkJBQWE7QUFGYixlQWpCWSxDQUFaLENBQUo7QUFzQkQsYUF2QkQsQ0F1QkUsT0FBTzFELENBQVAsRUFBVTtBQUNWbkIscUJBQU9vQixNQUFQLENBQWNELENBQWQ7QUFDRDtBQUNGLFdBdkpXO0FBRFksU0FBZixFQTBKSkEsQ0FBUCw2QkFBYTtBQUNYbkIsaUJBQU9vQixNQUFQLENBQWNELENBQWQ7QUFDRCxTQUZELENBMUpXLENBQWI7QUE4SkQsT0EvSkQsQ0FESSxDQUFOO0FBa0tBLGFBQU9uQixPQUFPcUIsT0FBUCxFQUFQO0FBQ0QsS0E3TEQ7QUFBQSxHQUZhOztBQWlNUCx1QkFBTixDQUE2QmxCLE9BQTdCO0FBQUEsb0NBQXNDO0FBRXBDLFVBQUlrRyxLQUFLLElBQUkxRyxLQUFKLENBQVVRLE9BQVYsQ0FBVDtBQUNBLFVBQUltQixvQkFBWStFLEdBQUc3RCxLQUFILENBQVMsZ0JBQVQsQ0FBWixDQUFKO0FBQ0EsYUFBT2xCLEdBQVA7QUFDRCxLQUxEO0FBQUE7O0FBak1hLENBQWYsRTs7Ozs7Ozs7Ozs7QUNkQSxJQUFJZ0YsZUFBSjtBQUFvQnhKLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNzSixrQkFBZ0JwSixDQUFoQixFQUFrQjtBQUFDb0osc0JBQWdCcEosQ0FBaEI7QUFBa0I7O0FBQXRDLENBQWpELEVBQXlGLENBQXpGO0FBRXBCLElBQUkyQyxNQUFNLGtCQUFWO0FBRUEvQixPQUFPZ0MsT0FBUCxDQUFlO0FBRWIsR0FBUSxHQUFFRCxHQUFJLE9BQWQsRUFBdUIwRyxJQUF2QixFQUE2Qi9ELFFBQU0sRUFBbkMsRUFBdUNnRSxhQUFXLEVBQWxEO0FBQUEsb0NBQXVEO0FBRXJELFVBQUlDLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixDQUFiLENBQUo7QUFDQSwyQkFBYUUsS0FBS0UsSUFBTCxDQUFVbkUsS0FBVixFQUFnQjtBQUFDZ0Usb0JBQVdBO0FBQVosT0FBaEIsRUFBeUNJLE9BQXpDLEVBQWI7QUFFRCxLQUxEO0FBQUEsR0FGYTs7QUFTYixHQUFRLEdBQUUvRyxHQUFJLFlBQWQsRUFBNEIwRyxJQUE1QixFQUFrQy9ELFFBQU0sRUFBeEM7QUFBQSxvQ0FBNkM7QUFFM0MsVUFBSWlFLHFCQUFhSCxnQkFBZ0JJLEdBQWhCLENBQW9CSCxJQUFwQixDQUFiLENBQUo7QUFDQSwyQkFBYUUsS0FBS0ksU0FBTCxDQUFlckUsS0FBZixFQUFzQm9FLE9BQXRCLEVBQWI7QUFFRCxLQUxEO0FBQUE7O0FBVGEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBLElBQUloSCxjQUFKO0FBQW1COUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGdDQUFSLENBQWIsRUFBdUQ7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMwQyxxQkFBZTFDLENBQWY7QUFBaUI7O0FBQTdCLENBQXZELEVBQXNGLENBQXRGO0FBRW5CLElBQUkyQyxNQUFNLGFBQVY7QUFFQS9CLE9BQU9nQyxPQUFQLENBQWU7QUFFYjs7Ozs7QUFLQSxHQUFRLEdBQUVELEdBQUksV0FBZCxFQUEyQjBHLElBQTNCLEVBQWlDcEksUUFBakMsRUFBMkMySSxLQUEzQyxFQUFrREMsU0FBUyxJQUEzRCxFQUFpRUMsU0FBUyxJQUExRTtBQUFBLG9DQUFpRjtBQUMvRSxVQUFJQyxVQUFVLElBQUlySCxjQUFKLEVBQWQ7QUFDQSxvQkFBTXFILFFBQVFDLElBQVIsQ0FBYVgsSUFBYixDQUFOO0FBQ0EsVUFBSVkseUJBQWlCRixRQUFRRyxRQUFSLENBQWtCakosUUFBbEIsRUFBNEIySSxLQUE1QixFQUFtQ0MsTUFBbkMsRUFBMkNDLE1BQTNDLENBQWpCLENBQUo7QUFDQSxhQUFPRyxRQUFQO0FBQ0QsS0FMRDtBQUFBLEdBUGE7O0FBY2I7OztBQUdBLEdBQVEsR0FBRXRILEdBQUksYUFBZCxFQUE2QjBHLElBQTdCLEVBQW1DTyxLQUFuQyxFQUEwQ0MsU0FBUyxJQUFuRCxFQUF5REMsU0FBUyxJQUFsRTtBQUFBLG9DQUF5RTtBQUN2RSxVQUFJQyxVQUFVLElBQUlySCxjQUFKLEVBQWQ7QUFDQSxvQkFBTXFILFFBQVFDLElBQVIsQ0FBYVgsSUFBYixDQUFOO0FBQ0Esb0JBQU1VLFFBQVFJLFVBQVIsQ0FBb0JQLEtBQXBCLEVBQTJCQyxNQUEzQixFQUFtQ0MsTUFBbkMsQ0FBTjtBQUNELEtBSkQ7QUFBQTs7QUFqQmEsQ0FBZixFOzs7Ozs7Ozs7OztBQ0pBLElBQUl4SCxNQUFKO0FBQVcxQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsd0JBQVIsQ0FBYixFQUErQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3NDLGFBQU90QyxDQUFQO0FBQVM7O0FBQXJCLENBQS9DLEVBQXNFLENBQXRFO0FBQXlFLElBQUl1QyxhQUFKO0FBQWtCM0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQ3lDLGdCQUFjdkMsQ0FBZCxFQUFnQjtBQUFDdUMsb0JBQWN2QyxDQUFkO0FBQWdCOztBQUFsQyxDQUFqRCxFQUFxRixDQUFyRjtBQUF3RixJQUFJd0MsUUFBSjtBQUFhNUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDBCQUFSLENBQWIsRUFBaUQ7QUFBQzBDLFdBQVN4QyxDQUFULEVBQVc7QUFBQ3dDLGVBQVN4QyxDQUFUO0FBQVc7O0FBQXhCLENBQWpELEVBQTJFLENBQTNFO0FBQThFLElBQUl5QyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVE7O0FBQXBCLENBQTlDLEVBQW9FLENBQXBFO0FBQXVFLElBQUkwQyxjQUFKO0FBQW1COUMsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLDZCQUFSLENBQWIsRUFBb0Q7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMwQyxxQkFBZTFDLENBQWY7QUFBaUI7O0FBQTdCLENBQXBELEVBQW1GLENBQW5GO0FBVTdYLElBQUkyQyxNQUFNLE1BQVY7QUFFQS9CLE9BQU9nQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLFlBQWQsRUFBMkJFLE1BQTNCO0FBQUEsb0NBQW1DO0FBRWpDO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUixNQUFKLEVBQWI7QUFFQSxVQUFJUyxTQUFTLElBQUlSLGFBQUosQ0FBa0JNLE9BQU9HLE9BQXpCLEVBQWtDSCxPQUFPSSxPQUF6QyxDQUFiO0FBQ0EsVUFBSUMsV0FBVyxJQUFJVCxLQUFKLENBQVVJLE9BQU9NLE9BQWpCLENBQWY7QUFDQSxVQUFJQyxNQUFNLElBQUlaLFFBQUosQ0FBYVUsUUFBYixDQUFWO0FBRUEsb0JBQU1KLE9BQU9PLEtBQVAsQ0FDSixlQURJLEVBRUosK0JBQVk7QUFDViw2QkFBYU4sT0FBT08sT0FBUCxDQUFlO0FBQ3hCLG9CQUFVLENBQU9DLElBQVAsRUFBYUMsT0FBYiw4QkFBeUI7QUFFakMsZ0JBQUlDLE1BQU1ELFFBQVFFLFVBQWxCOztBQUVBLGdCQUFJO0FBRUYsa0JBQUlDLFdBQVdqQixlQUFla0IsU0FBZixDQUF5QmYsT0FBT2tCLFVBQWhDLEVBQTRDUixJQUE1QyxDQUFmO0FBRUEsa0JBQUk2RywwQkFBa0JoSCxJQUFJc0IsYUFBSixDQUFrQmYsUUFBbEIsQ0FBbEIsQ0FBSixDQUpFLENBTUY7O0FBQ0EsNEJBQU1GLElBQUlrQixNQUFKLENBQVc7QUFDZkMscUJBQUtyQixLQUFLcUI7QUFESyxlQUFYLEVBRUg7QUFDREMsc0JBQU07QUFDSixzQ0FBb0J1RixVQUFVaEc7QUFEMUI7QUFETCxlQUZHLENBQU47QUFRQXRCLHFCQUFPa0IsUUFBUDtBQUVELGFBakJELENBaUJFLE9BQU9DLENBQVAsRUFBVTtBQUVWbkIscUJBQU9vQixNQUFQLENBQWNELENBQWQ7QUFFRDtBQUNGLFdBMUJTO0FBRGMsU0FBZixFQTZCSkEsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQTdCVyxDQUFiO0FBZ0NELE9BakNELENBRkksQ0FBTjtBQXFDQSxvQkFBTW5CLE9BQU9PLEtBQVAsQ0FDSixnQkFESSxFQUVKLCtCQUFZO0FBQ1YsNkJBQWFOLE9BQU9PLE9BQVAsQ0FBZTtBQUN4QixvQkFBVSxDQUFPQyxJQUFQLEVBQWFDLE9BQWIsOEJBQXlCO0FBRWpDLGdCQUFJQyxNQUFNRCxRQUFRRSxVQUFsQjs7QUFFQSxnQkFBSTtBQUVGLGtCQUFJQyxXQUFXakIsZUFBZWtCLFNBQWYsQ0FBeUJmLE9BQU9rQixVQUFoQyxFQUE0Q1IsSUFBNUMsQ0FBZjtBQUVBLDRCQUFNSCxJQUFJaUIsa0JBQUosQ0FBdUJWLFFBQXZCLENBQU47QUFDQSw0QkFBTVAsSUFBSVMsYUFBSixDQUFrQkYsUUFBbEIsQ0FBTjtBQUNBLDRCQUFNUCxJQUFJVSxnQkFBSixDQUFxQkgsUUFBckIsQ0FBTjtBQUVBYixxQkFBT2tCLFFBQVA7QUFFRCxhQVZELENBVUUsT0FBT0MsQ0FBUCxFQUFVO0FBRVZuQixxQkFBT29CLE1BQVAsQ0FBY0QsQ0FBZDtBQUVEO0FBQ0YsV0FuQlM7QUFEYyxTQUFmLEVBc0JKQSxDQUFQLDZCQUFhO0FBQ1gsZ0JBQU1BLENBQU47QUFDRCxTQUZELENBdEJXLENBQWI7QUF5QkQsT0ExQkQsQ0FGSSxDQUFOO0FBOEJBLGFBQU9uQixPQUFPcUIsT0FBUCxFQUFQO0FBRUQsS0E5RUQ7QUFBQTs7QUFMYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDWkEsSUFBSTdCLE1BQUo7QUFBVzFDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx3QkFBUixDQUFiLEVBQStDO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDc0MsYUFBT3RDLENBQVA7QUFBUzs7QUFBckIsQ0FBL0MsRUFBc0UsQ0FBdEU7QUFBeUUsSUFBSXVDLGFBQUo7QUFBa0IzQyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsMEJBQVIsQ0FBYixFQUFpRDtBQUFDeUMsZ0JBQWN2QyxDQUFkLEVBQWdCO0FBQUN1QyxvQkFBY3ZDLENBQWQ7QUFBZ0I7O0FBQWxDLENBQWpELEVBQXFGLENBQXJGO0FBQXdGLElBQUl5QyxLQUFKO0FBQVU3QyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsdUJBQVIsQ0FBYixFQUE4QztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVE7O0FBQXBCLENBQTlDLEVBQW9FLENBQXBFO0FBTXhNLElBQUkyQyxNQUFNLE1BQVY7QUFFQS9CLE9BQU9nQyxPQUFQLENBQWU7QUFFYjtBQUNBO0FBRUEsR0FBUSxHQUFFRCxHQUFJLE9BQWQsRUFBc0JFLE1BQXRCO0FBQUEsb0NBQThCO0FBRTVCO0FBQ0EsVUFBSUMsU0FBUyxJQUFJUixNQUFKLEVBQWI7QUFFQSxVQUFJUyxTQUFTLElBQUlSLGFBQUosQ0FBa0JNLE9BQU9HLE9BQXpCLEVBQWtDSCxPQUFPSSxPQUF6QyxDQUFiO0FBRUEsb0JBQU1ILE9BQU9PLEtBQVAsQ0FDSixVQURJLEVBRUosK0JBQVk7QUFDViw2QkFBYU4sT0FBT08sT0FBUCxDQUNYLEVBRFcsRUFFSlcsQ0FBUCw2QkFBYTtBQUNYLGdCQUFNQSxDQUFOO0FBQ0QsU0FGRCxDQUZXLENBQWI7QUFLRCxPQU5ELENBRkksQ0FBTjtBQVVBLGFBQU9uQixPQUFPcUIsT0FBUCxFQUFQO0FBRUQsS0FuQkQ7QUFBQTs7QUFMYSxDQUFmLEU7Ozs7Ozs7Ozs7O0FDUkF2RSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsK0JBQVIsQ0FBYjtBQUF1REYsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLHNCQUFSLENBQWIsRTs7Ozs7Ozs7Ozs7QUNBdkRGLE9BQU95SyxNQUFQLENBQWM7QUFBQ0MsV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSUMsS0FBSjtBQUFVM0ssT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDeUssUUFBTXZLLENBQU4sRUFBUTtBQUFDdUssWUFBTXZLLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFFeEMsTUFBTXNLLFVBQVUsSUFBSUMsTUFBTUMsVUFBVixDQUFxQixTQUFyQixFQUErQjtBQUFDQyxnQkFBYTtBQUFkLENBQS9CLENBQWhCLEM7Ozs7Ozs7Ozs7O0FDRlA3SyxPQUFPeUssTUFBUCxDQUFjO0FBQUNwRixVQUFPLE1BQUlBO0FBQVosQ0FBZDtBQUFtQyxJQUFJc0YsS0FBSjtBQUFVM0ssT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDeUssUUFBTXZLLENBQU4sRUFBUTtBQUFDdUssWUFBTXZLLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXlDLEtBQUo7QUFBVTdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN5QyxZQUFNekMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUkwSyxJQUFKO0FBQVM5SyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDMEssV0FBSzFLLENBQUw7QUFBTzs7QUFBbkIsQ0FBN0IsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTJLLE9BQUo7QUFBWS9LLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMySyxjQUFRM0ssQ0FBUjtBQUFVOztBQUF0QixDQUFwQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJNEssU0FBSjtBQUFjaEwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFVBQVIsQ0FBYixFQUFpQztBQUFDOEssWUFBVTVLLENBQVYsRUFBWTtBQUFDNEssZ0JBQVU1SyxDQUFWO0FBQVk7O0FBQTFCLENBQWpDLEVBQTZELENBQTdEO0FBYW5aLE1BQU02SyxVQUFVLElBQUlOLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBZ0M7QUFDOUNDLGdCQUFjO0FBRGdDLENBQWhDLENBQWhCOztBQUlPLE1BQU14RixNQUFOLFNBQXFCMkYsU0FBckIsQ0FBK0I7QUFFcENFLGNBQVlDLFFBQVosRUFBc0I7QUFFcEIsUUFBSTlILFVBQVU0SCxRQUFRRyxPQUFSLENBQWdCO0FBQzVCcEcsV0FBS21HO0FBRHVCLEtBQWhCLENBQWQ7QUFJQSxVQUFNOUgsT0FBTjtBQUVBLFFBQUlvRyxPQUFPLEtBQUs0QixPQUFMLEVBQVg7O0FBRUEsWUFBUTVCLEtBQUs2QixJQUFiO0FBRUUsV0FBSyxPQUFMO0FBQ0UsYUFBS0MsS0FBTCxHQUFhLElBQUkxSSxLQUFKLENBQVU0RyxLQUFLN0UsSUFBZixDQUFiOztBQUNBLGFBQUs0RyxNQUFMLEdBQWMsQ0FBUUMsV0FBWTdGLE1BQUQsSUFBVSxDQUFFLENBQS9CLEVBQWlDOEYsVUFBV3JILENBQUQsSUFBSyxDQUFFLENBQWxELDhCQUF3RDtBQUNwRSxjQUFJd0IsTUFBTyxpQkFBZ0I0RCxLQUFLa0MsS0FBTSxFQUF0QztBQUNBLCtCQUFhLEtBQUtKLEtBQUwsQ0FBV0ssY0FBWCxDQUEwQi9GLEdBQTFCLEVBQStCNEYsUUFBL0IsRUFBeUNDLE9BQXpDLENBQWI7QUFDRCxTQUhhLENBQWQ7O0FBSUE7O0FBRUY7QUFDRSxjQUFNLElBQUlHLEtBQUosQ0FBVSx1QkFBVixDQUFOO0FBWEo7QUFjRDtBQUVEOzs7Ozs7QUFJTW5JLFNBQU4sQ0FBY29JLFlBQVksRUFBMUIsRUFBOEJKLFVBQWlCckgsQ0FBUCw2QkFBYSxDQUFFLENBQWYsQ0FBeEM7QUFBQSxvQ0FBeUQ7QUFFdkQsVUFBSWhCLFVBQVUsS0FBSzBJLFVBQUwsRUFBZCxDQUZ1RCxDQUl2RDs7QUFDQTFJLGNBQVEySSxPQUFSLENBQWdCQyxJQUFoQixDQUFxQjtBQUNuQlgsY0FBTSxNQURhO0FBRW5CNUYsZUFBTztBQUZZLE9BQXJCO0FBS0EsVUFBSXdHLFFBQVEsRUFBWjs7QUFDQSxXQUFLLElBQUkvSSxNQUFULElBQW1CRSxRQUFRMkksT0FBM0IsRUFBb0M7QUFDbENFLGNBQU0vSSxPQUFPbUksSUFBYixJQUFxQjtBQUNuQjVGLGlCQUFPdkMsT0FBT3VDLEtBREs7QUFFbkJ3RyxpQkFBTztBQUZZLFNBQXJCO0FBSUQ7O0FBRUQsb0JBQU0sS0FBS1YsTUFBTCxDQUNHNUYsTUFBUCw2QkFBZ0I7QUFDZCxhQUFLLElBQUl6QyxNQUFULElBQW1CRSxRQUFRMkksT0FBM0IsRUFBb0M7QUFDbEMsY0FBSXRHLFFBQVFxRixRQUFRb0IsUUFBUixDQUFpQmhKLE9BQU91QyxLQUF4QixDQUFaO0FBQ0EsY0FBSTBHLE9BQU90QixLQUFNcEYsS0FBTixDQUFYOztBQUNBLGNBQUkwRyxLQUFLeEcsTUFBTCxDQUFKLEVBQWtCO0FBQ2hCc0csa0JBQU0vSSxPQUFPbUksSUFBYixFQUFtQlksS0FBbkI7O0FBQ0EsZ0JBQUksT0FBT0osVUFBVTNJLE9BQU9tSSxJQUFqQixDQUFQLEtBQWtDLFdBQXRDLEVBQWtEO0FBQ2hELDRCQUFNUSxVQUFVM0ksT0FBT21JLElBQWpCLEVBQXVCMUYsTUFBdkIsQ0FBTjtBQUNEOztBQUNEO0FBQ0Q7QUFDRjtBQUNGLE9BWkQsQ0FESSxFQWNKOEYsT0FkSSxDQUFOLEVBbEJ1RCxDQW1DdkQ7O0FBQ0EsYUFBT1EsS0FBUDtBQUVELEtBdENEO0FBQUE7O0FBaENvQyxDOzs7Ozs7Ozs7OztBQ2pCdENsTSxPQUFPeUssTUFBUCxDQUFjO0FBQUNPLGFBQVUsTUFBSUEsU0FBZjtBQUF5QjdGLFNBQU0sTUFBSUE7QUFBbkMsQ0FBZDtBQUF5RCxJQUFJd0YsS0FBSjtBQUFVM0ssT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGNBQVIsQ0FBYixFQUFxQztBQUFDeUssUUFBTXZLLENBQU4sRUFBUTtBQUFDdUssWUFBTXZLLENBQU47QUFBUTs7QUFBbEIsQ0FBckMsRUFBeUQsQ0FBekQ7QUFBNEQsSUFBSXlDLEtBQUo7QUFBVTdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxlQUFSLENBQWIsRUFBc0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUN5QyxZQUFNekMsQ0FBTjtBQUFROztBQUFwQixDQUF0QyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBUW5OLE1BQU1pTSxTQUFTLElBQUkxQixNQUFNQyxVQUFWLENBQXFCLFFBQXJCLEVBQStCO0FBQzVDQyxnQkFBYztBQUQ4QixDQUEvQixDQUFmOztBQUlPLE1BQU1HLFNBQU4sQ0FBZ0I7QUFJckJFLGNBQVk3SCxPQUFaLEVBQXFCO0FBQ25CLFNBQUtBLE9BQUwsR0FBZUEsT0FBZjtBQUNEO0FBRUQ7Ozs7Ozs7QUFLQWdJLFlBQVU7QUFDUixXQUFPLEtBQUtoSSxPQUFMLENBQWFpSixZQUFwQjtBQUNEOztBQUVEUCxlQUFhO0FBQ1gsV0FBTyxLQUFLMUksT0FBWjtBQUNEOztBQUVESyxVQUFRNkksV0FBa0IzRyxNQUFQLDZCQUFrQixDQUFFLENBQXBCLENBQW5CLEVBQXlDOEYsVUFBaUJySCxDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUFuRCxFQUFvRSxDQUFFOztBQXJCakQ7O0FBeUJoQixNQUFNYyxLQUFOLFNBQW9CNkYsU0FBcEIsQ0FBOEI7QUFFbkNFLGNBQVlzQixPQUFaLEVBQXFCO0FBRW5CLFFBQUluSixVQUFVZ0osT0FBT2pCLE9BQVAsQ0FBZTtBQUMzQnBHLFdBQUt3SDtBQURzQixLQUFmLENBQWQ7QUFJQSxVQUFNbkosT0FBTjtBQUVBLFFBQUlvRyxPQUFPLEtBQUs0QixPQUFMLEVBQVg7O0FBRUEsWUFBUTVCLEtBQUs2QixJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UsYUFBS0MsS0FBTCxHQUFhLElBQUkxSSxLQUFKLENBQVU0RyxLQUFLN0UsSUFBZixDQUFiOztBQUNBLGFBQUs0RyxNQUFMLEdBQXFCMUosR0FBUCw2QkFBZTtBQUMzQixjQUFJK0QsTUFBTyxpQkFBZ0I0RCxLQUFLa0MsS0FBTSxZQUFXN0osSUFBSTJLLEdBQUksU0FBUTNLLElBQUlxRyxFQUFHLEdBQXhFO0FBQ0EsK0JBQWEsS0FBS29ELEtBQUwsQ0FBVzdGLEtBQVgsQ0FBaUJHLEdBQWpCLENBQWI7QUFDRCxTQUhhLENBQWQ7O0FBSUE7O0FBQ0Y7QUFDRSxjQUFNLElBQUlnRyxLQUFKLENBQVUsb0JBQVYsQ0FBTjtBQVRKO0FBWUQ7QUFHRDs7Ozs7O0FBSUFuSSxVQUFRNkksV0FBa0IzRyxNQUFQLDZCQUFrQixDQUFFLENBQXBCLENBQW5CLEVBQXlDOEYsVUFBaUJySCxDQUFQLDZCQUFhLENBQUUsQ0FBZixDQUFuRCxFQUFvRTtBQUVsRSxRQUFJcUksTUFBTUwsT0FBT3hDLElBQVAsQ0FBWTtBQUNwQjJDLGVBQVMsS0FBS25KLE9BQUwsQ0FBYTJCO0FBREYsS0FBWixFQUVQO0FBQ0QySCxjQUFRO0FBQ04zSCxhQUFLLENBREM7QUFFTm1ELFlBQUksQ0FGRTtBQUdOc0UsYUFBSztBQUhDO0FBRFAsS0FGTyxDQUFWO0FBVUEsV0FBTyxJQUFJRyxPQUFKLENBQ0wsQ0FBQ0MsT0FBRCxFQUFVQyxNQUFWLEtBQXFCO0FBRW5CSixVQUFJSyxPQUFKLENBQ0UsQ0FBT2pMLEdBQVAsRUFBWWtMLEtBQVosOEJBQXNCO0FBQ3BCLFlBQUk7QUFDRixjQUFJcEgsdUJBQWUsS0FBSzRGLE1BQUwsQ0FBWTFKLEdBQVosQ0FBZixDQUFKO0FBQ0Esd0JBQU15SyxTQUFTM0csTUFBVCxDQUFOO0FBQ0QsU0FIRCxDQUdFLE9BQU92QixDQUFQLEVBQVU7QUFDVnFILGtCQUFRckgsQ0FBUjtBQUNEOztBQUNELFlBQUkySSxRQUFRLENBQVIsS0FBY04sSUFBSVIsS0FBSixFQUFsQixFQUErQjtBQUM3Qlc7QUFDRDtBQUNGLE9BVkQsQ0FERjtBQWFELEtBaEJJLEVBaUJMSSxLQWpCSyxDQWtCSjVJLENBQUQsSUFBTztBQUNMLFlBQU1BLENBQU47QUFDRCxLQXBCSSxDQUFQO0FBdUJEOztBQWxFa0MsQzs7Ozs7Ozs7Ozs7QUNyQ3JDckUsT0FBT3lLLE1BQVAsQ0FBYztBQUFDbEssV0FBUSxNQUFJQTtBQUFiLENBQWQ7QUFBcUMsSUFBSW9LLEtBQUo7QUFBVTNLLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxjQUFSLENBQWIsRUFBcUM7QUFBQ3lLLFFBQU12SyxDQUFOLEVBQVE7QUFBQ3VLLFlBQU12SyxDQUFOO0FBQVE7O0FBQWxCLENBQXJDLEVBQXlELENBQXpEO0FBRXhDLE1BQU1HLFVBQVUsSUFBSW9LLE1BQU1DLFVBQVYsQ0FBcUIsU0FBckIsRUFBK0I7QUFBQ0MsZ0JBQWE7QUFBZCxDQUEvQixDQUFoQixDOzs7Ozs7Ozs7OztBQ0ZQN0ssT0FBT3lLLE1BQVAsQ0FBYztBQUFDdEssV0FBUSxNQUFJMkM7QUFBYixDQUFkO0FBQTRDLElBQUkwRyxlQUFKO0FBQW9CeEosT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDc0osa0JBQWdCcEosQ0FBaEIsRUFBa0I7QUFBQ29KLHNCQUFnQnBKLENBQWhCO0FBQWtCOztBQUF0QyxDQUF0QyxFQUE4RSxDQUE5RTtBQUFpRixJQUFJRyxPQUFKO0FBQVlQLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSx1QkFBUixDQUFiLEVBQThDO0FBQUNLLFVBQVFILENBQVIsRUFBVTtBQUFDRyxjQUFRSCxDQUFSO0FBQVU7O0FBQXRCLENBQTlDLEVBQXNFLENBQXRFOztBQUc5SSxNQUFNMEMsY0FBTixDQUFvQjtBQUUzQnNILE1BQU4sQ0FBV1gsSUFBWDtBQUFBLG9DQUFnQjtBQUVkQSxXQUFLM0YsVUFBTCxHQUFrQixPQUFsQjtBQUNBLFdBQUtvSixLQUFMLGlCQUFtQjFELGdCQUFnQkksR0FBaEIsQ0FBb0JILElBQXBCLENBQW5CO0FBRUQsS0FMRDtBQUFBO0FBT0E7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7Ozs7O0FBcUJNYSxVQUFOLENBQWdCakosUUFBaEIsRUFBMEIySSxLQUExQixFQUFpQ0MsU0FBUyxJQUExQyxFQUFnREMsU0FBUyxJQUF6RDtBQUFBLG9DQUErRDtBQUU3RDtBQUNBLFVBQUlpRCxTQUFTNU0sUUFBUXNKLElBQVIsQ0FBYTtBQUFDeEksa0JBQVNBO0FBQVYsT0FBYixFQUFrQytMLEtBQWxDLEdBQTBDQyxHQUExQyxDQUErQ2pOLEtBQUtBLEVBQUU2QixnQkFBdEQsQ0FBYixDQUg2RCxDQUs3RDs7QUFDQSxVQUFJa0IsU0FBUyxFQUFiO0FBQ0FBLGFBQU82RyxLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQWE5RyxPQUFPbUssWUFBUCxHQUFzQnJELE1BQXRCO0FBQ2IsVUFBSUMsTUFBSixFQUFhL0csT0FBT29LLFlBQVAsR0FBc0JyRCxNQUF0QjtBQUViLFVBQUkxRixvQkFBWSxLQUFLMEksS0FBTCxDQUFXTSxVQUFYLENBQ2RySyxNQURjLEVBRWQ7QUFDRXNLLGVBQU07QUFDSk4sa0JBQVE7QUFDTk8sbUJBQU9QO0FBREQ7QUFESjtBQURSLE9BRmMsQ0FBWixDQUFKLENBWDZELENBc0I3RDs7QUFDQSxhQUFPQSxNQUFQO0FBQ0QsS0F4QkQ7QUFBQTtBQTBCQTs7Ozs7Ozs7OztBQVFNNUMsWUFBTixDQUFrQlAsS0FBbEIsRUFBeUJDLFNBQVMsSUFBbEMsRUFBd0NDLFNBQVMsSUFBakQ7QUFBQSxvQ0FBdUQ7QUFFckQ7QUFDQSxVQUFJL0csU0FBUyxFQUFiO0FBQ0FBLGFBQU82RyxLQUFQLEdBQWVBLEtBQWY7QUFDQSxVQUFJQyxNQUFKLEVBQWE5RyxPQUFPbUssWUFBUCxHQUFzQnJELE1BQXRCO0FBQ2IsVUFBSUMsTUFBSixFQUFhL0csT0FBT29LLFlBQVAsR0FBc0JyRCxNQUF0QjtBQUViLFVBQUkxRixvQkFBWSxLQUFLMEksS0FBTCxDQUFXTSxVQUFYLENBQ2RySyxNQURjLEVBRWQ7QUFDRThCLGNBQUs7QUFDSGtJLGtCQUFRO0FBREw7QUFEUCxPQUZjLENBQVosQ0FBSjtBQVNELEtBakJEO0FBQUE7O0FBbUJBLFNBQU9uSixTQUFQLENBQWlCRyxVQUFqQixFQUE2QlIsSUFBN0IsRUFBa0M7QUFDaEMsV0FBTyxJQUFJSyxTQUFKLENBQWNHLFVBQWQsRUFBMEJSLElBQTFCLENBQVA7QUFDRDs7QUFyRmdDOztBQXlGbkMsTUFBTUssU0FBTixDQUFnQjtBQUVka0gsY0FBYS9HLFVBQWIsRUFBeUJSLElBQXpCLEVBQThCO0FBRTVCO0FBQ0EsUUFBSWdLLGFBQWEsTUFBakI7O0FBQ0EsUUFBSWhLLEtBQUtpSyxXQUFULEVBQXNCO0FBQ3BCRCxtQkFBYWhLLEtBQUtpSyxXQUFMLENBQWlCRCxVQUE5QjtBQUNELEtBTjJCLENBUTVCO0FBQ0E7OztBQUNBLFFBQUlFLGFBQWEsRUFBakI7QUFDQSxRQUFHbEssS0FBS3FHLEtBQVIsRUFBZTZELFdBQVc1QixJQUFYLENBQWdCdEksS0FBS3FHLEtBQXJCO0FBQ2YsUUFBR3JHLEtBQUsySixZQUFSLEVBQXNCTyxXQUFXNUIsSUFBWCxDQUFnQnRJLEtBQUsySixZQUFyQjtBQUN0QixRQUFHM0osS0FBSzRKLFlBQVIsRUFBc0JNLFdBQVc1QixJQUFYLENBQWdCdEksS0FBSzRKLFlBQXJCLEVBYk0sQ0FlNUI7O0FBQ0EsUUFBSU8sZUFBSjs7QUFDQSxZQUFPbkssS0FBS29LLFFBQVo7QUFDRSxXQUFLLEtBQUw7QUFBWUQsMEJBQWtCLENBQWxCO0FBQXFCOztBQUNqQyxXQUFLLFFBQUw7QUFBZUEsMEJBQWlCLENBQWpCO0FBQW9COztBQUNuQztBQUFVQSwwQkFBa0IsQ0FBbEI7QUFBcUI7QUFIakMsS0FqQjRCLENBdUI1Qjs7O0FBQ0EsUUFBSUUsT0FBTyxFQUFYOztBQUNBLFlBQU9ySyxLQUFLb0ssUUFBWjtBQUNFLFdBQUssS0FBTDtBQUFZQyxhQUFLL0IsSUFBTCxDQUFVO0FBQUNsSixlQUFJLENBQUw7QUFBT2tMLGVBQUk7QUFBWCxTQUFWLEVBQTJCO0FBQUNsTCxlQUFJLENBQUw7QUFBT2tMLGVBQUk7QUFBWCxTQUEzQjtBQUErQzs7QUFDM0QsV0FBSyxRQUFMO0FBQWVELGFBQUsvQixJQUFMLENBQVU7QUFBQ2xKLGVBQUksQ0FBTDtBQUFPa0wsZUFBSTtBQUFYLFNBQVYsRUFBMkI7QUFBQ2xMLGVBQUksQ0FBTDtBQUFPa0wsZUFBSTtBQUFYLFNBQTNCO0FBQStDO0FBRmhFLEtBekI0QixDQThCNUI7OztBQUNBLFFBQUl6TSxPQUFPO0FBQ1RtTSxrQkFBWUEsVUFESDtBQUVUM0wsWUFBTyxHQUFFNkwsV0FBV0ssSUFBWCxDQUFnQixHQUFoQixDQUFxQixJQUFHdkssS0FBSzNCLElBQUssSUFBRzJCLEtBQUt3SyxRQUFTLEVBRm5EO0FBR1RDLDBCQUFvQnpLLEtBQUswSyxXQUhoQjtBQUlUQyxvQkFBYzNLLEtBQUtxRyxLQUpWO0FBS1R1RSxlQUFTNUssS0FBSzZLLFlBTEw7QUFNVEMsZUFBUzlLLEtBQUsrSyxXQU5MO0FBT1R2QixjQUFReEosS0FBS3dKLE1BUEo7QUFRVFcsdUJBQWlCQSxlQVJSO0FBU1RFLFlBQU1BO0FBVEcsS0FBWDtBQVlBVyxXQUFPQyxNQUFQLENBQWUsSUFBZixFQUFxQjtBQUFDekssa0JBQVlBO0FBQWIsS0FBckI7QUFDQXdLLFdBQU9DLE1BQVAsQ0FBZSxJQUFmLEVBQXFCcE4sSUFBckI7QUFDQW1OLFdBQU9DLE1BQVAsQ0FBZSxJQUFmLEVBQXFCakwsS0FBS2tMLElBQUwsQ0FBVWpCLFdBQS9CO0FBRUQ7O0FBakRhLEM7Ozs7Ozs7Ozs7O0FDNUZoQjVOLE9BQU95SyxNQUFQLENBQWM7QUFBQzdILFlBQVMsTUFBSUE7QUFBZCxDQUFkO0FBQXVDLElBQUlDLEtBQUo7QUFBVTdDLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSwwQkFBUixDQUFiLEVBQWlEO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDeUMsWUFBTXpDLENBQU47QUFBUTs7QUFBcEIsQ0FBakQsRUFBdUUsQ0FBdkU7QUFBMEUsSUFBSXNFLFdBQUo7QUFBZ0IxRSxPQUFPQyxLQUFQLENBQWFDLFFBQVEsU0FBUixDQUFiLEVBQWdDO0FBQUN3RSxjQUFZdEUsQ0FBWixFQUFjO0FBQUNzRSxrQkFBWXRFLENBQVo7QUFBYzs7QUFBOUIsQ0FBaEMsRUFBZ0UsQ0FBaEU7O0FBS3BJLE1BQU13QyxRQUFOLENBQWU7QUFFcEJzSSxjQUFZSyxRQUFRLElBQUkxSSxLQUFKLEVBQXBCLEVBQWlDO0FBQy9CLFNBQUtpTSxNQUFMLEdBQWN2RCxLQUFkO0FBQ0Q7O0FBR0tySCxrQkFBTixDQUF1QjFDLElBQXZCO0FBQUEsb0NBQTZCO0FBRTNCLFVBQUkyQyxhQUFhM0MsS0FBSzJDLFVBQXRCO0FBRUEsVUFBSUssTUFBTSxFQUFWOztBQUVBLFVBQUl1SyxRQUFlaE0sR0FBUCw2QkFBZTtBQUN6QnlCLFlBQUl5SCxJQUFKLGVBQ1EsS0FBSzZDLE1BQUwsQ0FBWTdHLFdBQVosQ0FDSixpQkFESSxFQUVKLEVBRkksRUFHSjtBQUNFMEYsc0JBQVluTSxLQUFLbU0sVUFEbkI7QUFFRTVLLGVBQUtBLEdBRlA7QUFHRW9CLHNCQUFZQTtBQUhkLFNBSEksQ0FEUjtBQVNNLE9BVkksQ0FBWjs7QUFZQSxVQUFJNkssU0FBZ0JqTSxHQUFQLDZCQUFlO0FBQzFCLFlBQUk4QyxNQUFPOzsyQkFFVXJFLEtBQUttTSxVQUFXLGNBQWE1SyxHQUFJO09BRnREO0FBSUF5QixZQUFJeUgsSUFBSixlQUFnQixLQUFLNkMsTUFBTCxDQUFZcEosS0FBWixDQUFrQkcsR0FBbEIsQ0FBaEI7QUFDRCxPQU5ZLENBQWI7O0FBUUEsV0FBSyxJQUFJb0osTUFBVCxJQUFtQnpOLEtBQUt3TSxJQUF4QixFQUE4QjtBQUM1QixnQkFBUWlCLE9BQU9oQixHQUFmO0FBQ0UsZUFBSyxJQUFMO0FBQ0UsMEJBQU1jLE1BQU1FLE9BQU9sTSxHQUFiLENBQU47QUFDQTs7QUFDRixlQUFLLEtBQUw7QUFDRSwwQkFBTWlNLE9BQU9DLE9BQU9sTSxHQUFkLENBQU47QUFDQTtBQU5KO0FBUUQ7O0FBRUQsYUFBTztBQUNMeUIsYUFBS0E7QUFEQSxPQUFQO0FBSUQsS0F6Q0Q7QUFBQTs7QUEyQ01DLG9CQUFOLENBQXlCakQsSUFBekI7QUFBQSxvQ0FBK0I7QUFFN0IsVUFBSW1NLGFBQWFuTSxLQUFLbU0sVUFBdEI7QUFDQSxVQUFJUixTQUFTM0wsS0FBSzJMLE1BQWxCO0FBQ0EsVUFBSWhKLGFBQWEzQyxLQUFLMkMsVUFBdEI7QUFFQSxVQUFJSyxNQUFNLEVBQVYsQ0FONkIsQ0FRN0I7O0FBQ0EsVUFBSXFCLE1BQU8sb0RBQW1EOEgsVUFBVyxFQUF6RTtBQUNBbkosVUFBSXlILElBQUosZUFBZSxLQUFLNkMsTUFBTCxDQUFZcEosS0FBWixDQUFrQkcsR0FBbEIsQ0FBZixHQVY2QixDQVk3Qjs7QUFDQSxXQUFLLElBQUlxSixJQUFJLENBQWIsRUFBZ0JBLElBQUkvQixPQUFPZ0MsTUFBM0IsRUFBbUNELEdBQW5DLEVBQXdDO0FBRXRDLGFBQUtKLE1BQUwsQ0FBWTdHLFdBQVosQ0FDRSxtQkFERixFQUN1QjtBQUNuQjBGLHNCQUFZQSxVQURPO0FBRW5CeEosc0JBQVlBLFVBRk87QUFHbkJpTCxxQkFBV2pDLE9BQU8rQixDQUFQLENBSFE7QUFJbkJHLGdCQUFNSCxJQUFJO0FBSlMsU0FEdkIsRUFNSztBQUNEcEgsdUJBQWE7QUFEWixTQU5MO0FBVUQ7O0FBRUQsYUFBTztBQUNMdEQsYUFBS0E7QUFEQSxPQUFQO0FBSUQsS0EvQkQ7QUFBQTs7QUFpQ01QLGVBQU4sQ0FBb0J6QyxJQUFwQjtBQUFBLG9DQUEwQjtBQUV4QixVQUFJOE4sY0FBYyxFQUFsQjtBQUNBLFVBQUlDLE9BQU8sRUFBWCxDQUh3QixDQUt4Qjs7QUFFQUEsYUFBTyxDQUNMLFFBREssRUFFTCxNQUZLLEVBR0wsTUFISyxFQUlMLGtCQUpLLEVBS0wsb0JBTEssRUFNTCxhQU5LLEVBT0wsV0FQSyxDQUFQOztBQVNBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUkvTixLQUFLZ08sQ0FBTCxDQUFKLEVBQWFGLFlBQVlFLENBQVosSUFBaUJoTyxLQUFLZ08sQ0FBTCxDQUFqQjtBQUNkOztBQUVELFdBQUtWLE1BQUwsQ0FBWVcsV0FBWixDQUNFLGFBREYsRUFFRyxnQkFBZWpPLEtBQUttTSxVQUFXLEVBRmxDLEVBR0UyQixXQUhGLEVBR2U7QUFDWHZILHFCQUFhO0FBREYsT0FIZixFQXBCd0IsQ0E0QnhCOztBQUVBdUgsb0JBQWMsRUFBZDtBQUNBQyxhQUFPLENBQ0wsa0JBREssRUFFTCxjQUZLLEVBR0wsWUFISyxFQUlMLFNBSkssRUFLTCxTQUxLLEVBTUwsY0FOSyxDQUFQOztBQVFBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUkvTixLQUFLZ08sQ0FBTCxDQUFKLEVBQWFGLFlBQVlFLENBQVosSUFBaUJoTyxLQUFLZ08sQ0FBTCxDQUFqQjtBQUNkOztBQUVELFVBQUloTCxNQUFNLEtBQUtzSyxNQUFMLENBQVlXLFdBQVosQ0FDUixtQkFEUSxFQUVQLGdCQUFlak8sS0FBS21NLFVBQVcsRUFGeEIsRUFHUjJCLFdBSFEsRUFHSztBQUNYdkgscUJBQWE7QUFERixPQUhMLENBQVY7QUFRQSxhQUFPO0FBQ0x2RCxhQUFLQTtBQURBLE9BQVA7QUFJRCxLQXZERDtBQUFBOztBQXlETU0sZUFBTixDQUFvQnRELElBQXBCO0FBQUEsb0NBQTBCO0FBRXhCLFVBQUkyQyxhQUFhM0MsS0FBSzJDLFVBQXRCO0FBRUEsVUFBSUssTUFBTSxFQUFWO0FBRUEsVUFBSThLLGNBQWMsRUFBbEI7QUFDQSxVQUFJQyxPQUFPLEVBQVg7QUFFQUEsYUFBTyxDQUNMLE1BREssRUFFTCxvQkFGSyxDQUFQLENBVHdCLENBYXhCO0FBQ0E7QUFDQTtBQUNBOztBQUVBLFdBQUssSUFBSUMsQ0FBVCxJQUFjRCxJQUFkLEVBQW9CO0FBQ2xCLFlBQUkvTixLQUFLZ08sQ0FBTCxDQUFKLEVBQWFGLFlBQVlFLENBQVosSUFBaUJoTyxLQUFLZ08sQ0FBTCxDQUFqQjtBQUNkOztBQUVEaEwsVUFBSW1KLFVBQUosaUJBQXVCLEtBQUttQixNQUFMLENBQVk3RyxXQUFaLENBQ3JCLGFBRHFCLEVBRXJCcUgsV0FGcUIsRUFFUjtBQUNYbkwsb0JBQVlBLFVBREQ7QUFFWDRCLGdCQUFRLENBRkc7QUFHWDhCLGNBQU0sTUFISztBQUlYNkgsMEJBQWtCLE1BSlA7QUFLWEMscUJBQWEsTUFMRjtBQU1YQyxtQkFBVyxNQU5BO0FBT1g5SCxxQkFBYSxPQVBGO0FBUVhDLHFCQUFhO0FBUkYsT0FGUSxDQUF2QjtBQWVBdUgsb0JBQWMsRUFBZDtBQUNBQyxhQUFPLENBQ0wsY0FESyxFQUVMLGlCQUZLLEVBR0wsU0FISyxFQUlMLFNBSkssQ0FBUCxDQXRDd0IsQ0E0Q3hCO0FBQ0E7QUFDQTtBQUNBO0FBQ0E7O0FBRUEsV0FBSyxJQUFJQyxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSS9OLEtBQUtnTyxDQUFMLENBQUosRUFBYUYsWUFBWUUsQ0FBWixJQUFpQmhPLEtBQUtnTyxDQUFMLENBQWpCO0FBQ2Q7O0FBRURoTCxVQUFJcUwsZ0JBQUosaUJBQTZCLEtBQUtmLE1BQUwsQ0FBWTdHLFdBQVosQ0FDM0IsbUJBRDJCLEVBRTNCcUgsV0FGMkIsRUFFZDtBQUNYbkwsb0JBQVlBLFVBREQ7QUFFWHdKLG9CQUFZbkosSUFBSW1KLFVBRkw7QUFHWG1DLGVBQU8sQ0FISTtBQUlYQyx5QkFBaUIsQ0FKTjtBQUtYQyw0QkFBb0IsTUFMVDtBQU1YQyw0QkFBb0IsTUFOVDtBQU9YQywwQkFBa0IsTUFQUDtBQVFYQyxvQkFBWSxNQVJEO0FBU1hDLHNCQUFjLE1BVEg7QUFVWHRJLHFCQUFhLE9BVkY7QUFXWEMscUJBQWE7QUFYRixPQUZjLENBQTdCOztBQWlCQSxXQUFLLElBQUl5SCxDQUFULElBQWNELElBQWQsRUFBb0I7QUFDbEIsWUFBSS9OLEtBQUtnTyxDQUFMLENBQUosRUFBYUYsWUFBWUUsQ0FBWixJQUFpQmhPLEtBQUtnTyxDQUFMLENBQWpCO0FBQ2Q7O0FBRURoTCxVQUFJNkwsZ0JBQUosaUJBQTZCLEtBQUt2QixNQUFMLENBQVk3RyxXQUFaLENBQzNCLG1CQUQyQixFQUNOLEVBRE0sRUFDRjtBQUN2QjRILDBCQUFrQnJMLElBQUlxTCxnQkFEQztBQUV2QjFMLG9CQUFZQSxVQUZXO0FBR3ZCMkwsZUFBTyxDQUhnQjtBQUl2QmhJLHFCQUFhLE9BSlU7QUFLdkJDLHFCQUFhO0FBTFUsT0FERSxDQUE3QixFQTNFd0IsQ0FxRnhCOztBQUNBLGFBQU87QUFDTHZELGFBQUtBO0FBREEsT0FBUDtBQUlELEtBMUZEO0FBQUE7O0FBNUlvQixDOzs7Ozs7Ozs7OztBQ0x0QnhFLE9BQU95SyxNQUFQLENBQWM7QUFBQzZGLG1CQUFnQixNQUFJQSxlQUFyQjtBQUFxQ0MsWUFBUyxNQUFJQSxRQUFsRDtBQUEyREMsaUJBQWMsTUFBSUEsYUFBN0U7QUFBMkY3TixpQkFBYyxNQUFJQTtBQUE3RyxDQUFkO0FBQTJJLElBQUlnSSxLQUFKO0FBQVUzSyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsY0FBUixDQUFiLEVBQXFDO0FBQUN5SyxRQUFNdkssQ0FBTixFQUFRO0FBQUN1SyxZQUFNdkssQ0FBTjtBQUFROztBQUFsQixDQUFyQyxFQUF5RCxDQUF6RDtBQUE0RCxJQUFJWSxNQUFKO0FBQVdoQixPQUFPQyxLQUFQLENBQWFDLFFBQVEsZUFBUixDQUFiLEVBQXNDO0FBQUNjLFNBQU9aLENBQVAsRUFBUztBQUFDWSxhQUFPWixDQUFQO0FBQVM7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUkwSyxJQUFKO0FBQVM5SyxPQUFPQyxLQUFQLENBQWFDLFFBQVEsTUFBUixDQUFiLEVBQTZCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDMEssV0FBSzFLLENBQUw7QUFBTzs7QUFBbkIsQ0FBN0IsRUFBa0QsQ0FBbEQ7QUFBcUQsSUFBSTJLLE9BQUo7QUFBWS9LLE9BQU9DLEtBQVAsQ0FBYUMsUUFBUSxhQUFSLENBQWIsRUFBb0M7QUFBQ0MsVUFBUUMsQ0FBUixFQUFVO0FBQUMySyxjQUFRM0ssQ0FBUjtBQUFVOztBQUF0QixDQUFwQyxFQUE0RCxDQUE1RDtBQUErRCxJQUFJeUMsS0FBSjtBQUFVN0MsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLGVBQVIsQ0FBYixFQUFzQztBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ3lDLFlBQU16QyxDQUFOO0FBQVE7O0FBQXBCLENBQXRDLEVBQTRELENBQTVEO0FBQStELElBQUlzRSxXQUFKO0FBQWdCMUUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDd0UsY0FBWXRFLENBQVosRUFBYztBQUFDc0Usa0JBQVl0RSxDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFOztBQU90ZixNQUFNa1EsZUFBTixDQUFzQjtBQUMzQnBGLGNBQVl6QixJQUFaLEVBQWtCcEcsT0FBbEIsRUFBMkI7QUFDekIsUUFBSW9OLFFBQUo7O0FBQ0EsWUFBUWhILEtBQUs2QixJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0VtRixtQkFBVyxJQUFJRCxhQUFKLENBQWtCL0csSUFBbEIsRUFBd0JwRyxPQUF4QixDQUFYO0FBRko7O0FBS0EsV0FBT29OLFFBQVA7QUFDRDs7QUFUMEI7O0FBWXRCLE1BQU1GLFFBQU4sQ0FBZTtBQUNwQjtBQUdBckYsY0FBWXpCLElBQVosRUFBa0JwRyxPQUFsQixFQUEyQjtBQUN6QixTQUFLb0csSUFBTCxHQUFZQSxJQUFaO0FBQ0EsU0FBS3BHLE9BQUwsR0FBZUEsT0FBZjtBQUNEOztBQUVELFNBQU9xTixPQUFQLENBQWVqSCxJQUFmLEVBQXFCcEcsT0FBckIsRUFBOEI7QUFDNUIsUUFBSW9OLFFBQUo7O0FBQ0EsWUFBUWhILEtBQUs2QixJQUFiO0FBQ0UsV0FBSyxPQUFMO0FBQ0UsZUFBTyxJQUFJa0YsYUFBSixDQUFrQi9HLElBQWxCLEVBQXdCcEcsT0FBeEIsQ0FBUDs7QUFDRjtBQUNFLGNBQU0sSUFBSXdJLEtBQUosQ0FBVSxtQkFBVixDQUFOO0FBSko7QUFNRDs7QUFFRDhFLGFBQVc7QUFDVCxXQUFPLEtBQUtsSCxJQUFaO0FBQ0Q7O0FBRURtSCxhQUFXO0FBQ1QsV0FBTyxLQUFLbkgsSUFBTCxDQUFVN0UsSUFBakI7QUFDRDs7QUFFRGlNLGdCQUFjO0FBQ1osV0FBTyxLQUFLeE4sT0FBWjtBQUNEOztBQUVEeU4scUJBQ0VDLEtBQUssQ0FBT3RGLFdBQVc3RixVQUFVLENBQUUsQ0FBOUIsRUFBZ0M4RixVQUFVckgsS0FBSyxDQUFFLENBQWpELDhCQUFzRCxDQUFFLENBQXhELENBRFAsRUFFRTtBQUNBLFNBQUttSCxNQUFMLEdBQWN1RixFQUFkO0FBQ0Q7QUFFRDs7Ozs7Ozs7Ozs7QUFTTXJOLFNBQU4sQ0FBY3NOLFlBQVksRUFBMUI7QUFBQSxvQ0FBOEI7QUFDNUIsVUFBSTNOLFVBQVUsS0FBS3dOLFdBQUwsRUFBZCxDQUQ0QixDQUc1Qjs7QUFDQXhOLGNBQVEySSxPQUFSLENBQWdCQyxJQUFoQixDQUFxQjtBQUNuQmpLLGNBQU0sTUFEYTtBQUVuQjBELGVBQU87QUFGWSxPQUFyQjtBQUtBLFVBQUl1TCxVQUFVLEVBQWQ7O0FBQ0EsV0FBSyxJQUFJQyxDQUFULElBQWM3TixRQUFRMkksT0FBdEIsRUFBK0IsQ0FDOUI7O0FBRUQsVUFBSUEsVUFBVSxFQUFkOztBQUVBLFdBQUssSUFBSWtGLENBQVQsSUFBYzdOLFFBQVEySSxPQUF0QixFQUErQjtBQUM3QmlGLGdCQUFRQyxFQUFFbFAsSUFBVixJQUFrQjtBQUNoQjBELGlCQUFPd0wsRUFBRXhMLEtBRE87QUFFaEJ5TCxpQkFBTyxPQUFPRCxFQUFFQyxLQUFULEtBQW1CLFdBQW5CLEdBQWlDRCxFQUFFQyxLQUFuQyxHQUEyQyxDQUZsQztBQUdoQmpGLGlCQUFPO0FBSFMsU0FBbEI7QUFLQUYsZ0JBQVFDLElBQVIsQ0FDRTtBQUNFakssZ0JBQU1rUCxFQUFFbFAsSUFEVjtBQUVFb0ssZ0JBQU10QixLQUFNQyxRQUFRb0IsUUFBUixDQUFpQitFLEVBQUV4TCxLQUFuQixDQUFOO0FBRlIsU0FERjtBQU1EOztBQUVELG9CQUFNLEtBQUs4RixNQUFMLENBQ0osQ0FBTzVGLE1BQVAsRUFBZWhDLE9BQWYsOEJBQTJCO0FBRXpCLGFBQUssSUFBSXNOLENBQVQsSUFBY2xGLE9BQWQsRUFBdUI7QUFFckI7QUFDQSxjQUFJb0YsSUFBSUgsUUFBUUMsRUFBRWxQLElBQVYsQ0FBUjs7QUFDQSxjQUFJb1AsRUFBRUQsS0FBTixFQUFhO0FBQ1gsZ0JBQUlDLEVBQUVsRixLQUFGLElBQVdrRixFQUFFRCxLQUFqQixFQUF3QjtBQUN0QjtBQUNEO0FBQ0Y7O0FBRUQsY0FBSUQsRUFBRTlFLElBQUYsQ0FBT3hHLE1BQVAsQ0FBSixFQUFvQjtBQUVsQjtBQUNBd0wsY0FBRWxGLEtBQUYsR0FIa0IsQ0FLbEI7O0FBQ0EsZ0JBQUksT0FBTzhFLFVBQVVFLEVBQUVsUCxJQUFaLENBQVAsS0FBNkIsV0FBakMsRUFBOEM7QUFDNUMsNEJBQU1nUCxVQUFVRSxFQUFFbFAsSUFBWixFQUFrQjRELE1BQWxCLEVBQTBCaEMsT0FBMUIsQ0FBTjtBQUNEOztBQUNEO0FBRUQ7QUFDRjtBQUNGLE9BekJELENBREksQ0FBTixFQTdCNEIsQ0F5RDVCOztBQUNBLGFBQU9xTixPQUFQO0FBQ0QsS0EzREQ7QUFBQTs7QUE5Q29COztBQThHZixNQUFNVCxhQUFOLFNBQTRCRCxRQUE1QixDQUFxQztBQUMxQ3JGLGNBQVl6QixJQUFaLEVBQWtCcEcsT0FBbEIsRUFBMkI7QUFDekIsVUFBTW9HLElBQU4sRUFBWXBHLE9BQVo7QUFFQSxRQUFJdUIsT0FBTyxLQUFLZ00sUUFBTCxFQUFYO0FBRUEsU0FBS3JGLEtBQUwsR0FBYSxJQUFJMUksS0FBSixDQUFVK0IsSUFBVixDQUFiO0FBQ0EsU0FBS2tNLGtCQUFMLENBQXdCLENBQU9yRixRQUFQLEVBQWlCQyxPQUFqQiw4QkFBNkI7QUFDbkQsVUFBSTdGLE1BQU8saUJBQWdCNEQsS0FBS2tDLEtBQU0sRUFBdEM7QUFDQSwyQkFBYSxLQUFLSixLQUFMLENBQVdLLGNBQVgsQ0FBMEIvRixHQUExQixFQUErQjRGLFFBQS9CLEVBQTBDcEgsQ0FBRCxJQUFLO0FBQUMsY0FBTUEsQ0FBTjtBQUFRLE9BQXZELENBQWI7QUFDRCxLQUh1QixDQUF4QjtBQUlEOztBQVh5Qzs7QUFtQnJDLE1BQU0xQixhQUFOLFNBQTRCNE4sUUFBNUIsQ0FBcUM7QUFDMUNyRixjQUFZekIsSUFBWixFQUFrQnBHLE9BQWxCLEVBQTJCO0FBQ3pCLFVBQU1vRyxJQUFOLEVBQVlwRyxPQUFaLEVBRHlCLENBR3pCOztBQUNBLFNBQUt5TixrQkFBTCxDQUF3QixDQUFPckYsUUFBUCxFQUFpQkMsT0FBakIsOEJBQTZCO0FBRW5ELFVBQUkyRixNQUFKO0FBQ0FBLDZCQUFlM00sWUFBWTRNLE9BQVosQ0FBb0I3SCxLQUFLOEgsR0FBekIsQ0FBZixFQUhtRCxDQUtuRDs7QUFDQSxVQUFJaEksS0FBSzhILE9BQU85SCxFQUFQLENBQVVFLEtBQUsrSCxRQUFmLENBQVQ7QUFDQSxVQUFJMU4sYUFBYXlGLEdBQUd6RixVQUFILENBQWMyRixLQUFLM0YsVUFBbkIsQ0FBakI7QUFFQSxVQUFJRixVQUFVO0FBQ1p5TixnQkFBUUEsTUFESTtBQUVadk4sb0JBQVlBLFVBRkE7QUFHWjBOLGtCQUFVakk7QUFIRSxPQUFkO0FBTUEsVUFBSW1ELE1BQU01SSxXQUFXK0YsSUFBWCxFQUFWOztBQUVBLDJCQUFhNkMsSUFBSStFLE9BQUosRUFBYixHQUE0QjtBQUMxQixZQUFJM1Asb0JBQVk0SyxJQUFJZ0YsSUFBSixFQUFaLENBQUo7QUFDQSxzQkFBTWpHLFNBQVMzSixHQUFULEVBQWM4QixPQUFkLENBQU47QUFDRDs7QUFBQTtBQUVGLEtBdEJ1QixDQUF4QjtBQXdCRDs7QUE3QnlDLEM7Ozs7Ozs7Ozs7O0FDcEo1QzVELE9BQU95SyxNQUFQLENBQWM7QUFBQ2pCLG1CQUFnQixNQUFJQTtBQUFyQixDQUFkO0FBQXFELElBQUk5RSxXQUFKO0FBQWdCMUUsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLFNBQVIsQ0FBYixFQUFnQztBQUFDd0UsY0FBWXRFLENBQVosRUFBYztBQUFDc0Usa0JBQVl0RSxDQUFaO0FBQWM7O0FBQTlCLENBQWhDLEVBQWdFLENBQWhFOztBQUU5RCxNQUFNb0osZUFBTixDQUFxQjtBQUMxQixTQUFhSSxHQUFiLENBQWlCSCxJQUFqQjtBQUFBLG9DQUFzQjtBQUNwQixVQUFJNEgsdUJBQWUzTSxZQUFZNE0sT0FBWixDQUFvQjdILEtBQUs4SCxHQUF6QixDQUFmLENBQUo7QUFDQSxVQUFJaEksS0FBSzhILE9BQU85SCxFQUFQLENBQVVFLEtBQUsrSCxRQUFmLENBQVQ7QUFDQSxhQUFPakksR0FBR3pGLFVBQUgsQ0FBYzJGLEtBQUszRixVQUFuQixDQUFQO0FBQ0QsS0FKRDtBQUFBOztBQUQwQixDOzs7Ozs7Ozs7OztBQ0Y1QjlELE9BQU95SyxNQUFQLENBQWM7QUFBQ3RLLFdBQVEsTUFBSTBDO0FBQWIsQ0FBZDtBQUFtQyxJQUFJMEksS0FBSjtBQUFVdkwsT0FBT0MsS0FBUCxDQUFhQyxRQUFRLE9BQVIsQ0FBYixFQUE4QjtBQUFDQyxVQUFRQyxDQUFSLEVBQVU7QUFBQ21MLFlBQU1uTCxDQUFOO0FBQVE7O0FBQXBCLENBQTlCLEVBQW9ELENBQXBEO0FBQXVELElBQUl1UixNQUFKO0FBQVczUixPQUFPQyxLQUFQLENBQWFDLFFBQVEsUUFBUixDQUFiLEVBQStCO0FBQUNDLFVBQVFDLENBQVIsRUFBVTtBQUFDdVIsYUFBT3ZSLENBQVA7QUFBUzs7QUFBckIsQ0FBL0IsRUFBc0QsQ0FBdEQ7O0FBSWhHLE1BQU15QyxLQUFOLENBQVk7QUFFekJxSSxjQUFZN0gsT0FBWixFQUFxQjtBQUNuQjtBQUNBLFNBQUt1TyxJQUFMLEdBQVlyRyxNQUFNc0csVUFBTixDQUFpQnhPLE9BQWpCLENBQVosQ0FGbUIsQ0FJbkI7O0FBQ0EsUUFBSXlPLGVBQWU7QUFBQ0MsMEJBQW1CO0FBQXBCLEtBQW5CO0FBQ0FwRCxXQUFPQyxNQUFQLENBQWVrRCxZQUFmLEVBQTZCek8sT0FBN0I7QUFDQSxTQUFLMk8sU0FBTCxHQUFpQnpHLE1BQU1zRyxVQUFOLENBQWlCQyxZQUFqQixDQUFqQjtBQUNEOztBQUVELFNBQU9HLFVBQVAsQ0FBbUJDLElBQW5CLEVBQXlCO0FBQ3ZCLFdBQU9QLE9BQU9PLElBQVAsRUFBYUMsTUFBYixHQUFzQjNKLFNBQXRCLENBQWdDLENBQWhDLEVBQWtDLEVBQWxDLEVBQXNDNEosT0FBdEMsQ0FBOEMsR0FBOUMsRUFBbUQsR0FBbkQsQ0FBUDtBQUNEO0FBRUQ7Ozs7OztBQUlBMU0sUUFBTUcsR0FBTixFQUFXO0FBRVQ7QUFDQTtBQUNBLFdBQU8sS0FBS3dNLE1BQUwsR0FDSkMsSUFESSxDQUVGQyxHQUFELElBQVM7QUFDUCxhQUFPLElBQUkzRixPQUFKLENBQ0wsQ0FBT0MsT0FBUCxFQUFnQkMsTUFBaEIsOEJBQTJCO0FBQ3pCO0FBQ0F5RixZQUFJN00sS0FBSixDQUFVRyxHQUFWLEVBQWUsQ0FBQ3hCLENBQUQsRUFBSUcsR0FBSixLQUFZO0FBQ3pCO0FBQ0ErTixjQUFJQyxPQUFKOztBQUNBLGNBQUluTyxDQUFKLEVBQU87QUFDTHlJLG1CQUFPekksQ0FBUDtBQUNELFdBRkQsTUFFT3dJLFFBQVFySSxHQUFSO0FBQ1IsU0FORDtBQU9ELE9BVEQsQ0FESyxDQUFQO0FBYUQsS0FoQkUsRUFrQkp5SSxLQWxCSSxDQWtCRzVJLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQXBCSSxDQUFQO0FBcUJEOztBQUVLb08sY0FBTixDQUFtQjVNLEdBQW5CO0FBQUEsb0NBQXVCO0FBQ3JCLFVBQUlyQixvQkFBWSxLQUFLa0IsS0FBTCxDQUFXRyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9yQixJQUFJa08sUUFBWDtBQUNELEtBSEQ7QUFBQTtBQUtBOzs7Ozs7OztBQU1PekssYUFBTixDQUFrQjBELEtBQWxCLEVBQXlCbkssT0FBTyxFQUFoQyxFQUFvQ21SLFdBQVcsRUFBL0M7QUFBQSxvQ0FBa0Q7QUFFakQ7QUFDQTtBQUVBLFVBQUk5TSxNQUFPLGVBQWM4RixLQUFNLEdBQS9CO0FBRUEsVUFBSTBCLE1BQU0sSUFBSXVGLEdBQUosRUFBVjs7QUFDQSxXQUFLLElBQUlwRCxDQUFULElBQWNiLE9BQU9ZLElBQVAsQ0FBWS9OLElBQVosQ0FBZCxFQUFpQztBQUUvQixZQUFJQSxLQUFLZ08sQ0FBTCxNQUFZLElBQWhCLEVBQXFCO0FBQ25CbkMsY0FBSVksR0FBSixDQUFRdUIsQ0FBUixFQUFXLE1BQVg7QUFDRCxTQUZELE1BR0ssSUFBSWhPLEtBQUtnTyxDQUFMLEVBQVF0RSxXQUFSLENBQW9CbEosSUFBcEIsS0FBNkIsTUFBakMsRUFBeUM7QUFDNUM7QUFDQXFMLGNBQUlZLEdBQUosQ0FBUXVCLENBQVIsRUFBWSxJQUFHM00sTUFBTW9QLFVBQU4sQ0FBaUJ6USxLQUFLZ08sQ0FBTCxDQUFqQixDQUEwQixHQUF6QztBQUNELFNBSEksTUFJRDtBQUNGbkMsY0FBSVksR0FBSixDQUFRdUIsQ0FBUixFQUFZLElBQUdoTyxLQUFLZ08sQ0FBTCxDQUFRLEdBQXZCO0FBQ0Q7QUFFRjs7QUFDRCxXQUFLLElBQUlBLENBQVQsSUFBY2IsT0FBT1ksSUFBUCxDQUFZb0QsUUFBWixDQUFkLEVBQXFDO0FBQ25DdEYsWUFBSVksR0FBSixDQUFRdUIsQ0FBUixFQUFXbUQsU0FBU25ELENBQVQsTUFBZ0IsSUFBaEIsR0FBdUIsTUFBdkIsR0FBZ0NtRCxTQUFTbkQsQ0FBVCxDQUEzQztBQUNEOztBQUVEM0osYUFBUSxLQUFJLENBQUMsR0FBR3dILElBQUlrQyxJQUFKLEVBQUosRUFBZ0JyQixJQUFoQixDQUFxQixHQUFyQixDQUEwQixLQUF0QztBQUVBckksYUFBUSxXQUFVLENBQUMsR0FBR3dILElBQUl3RixNQUFKLEVBQUosRUFBa0IzRSxJQUFsQixDQUF1QixHQUF2QixDQUE0QixLQUE5QztBQUVBLFVBQUkxSixvQkFBWSxLQUFLa0IsS0FBTCxDQUFXRyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9yQixJQUFJa08sUUFBWDtBQUVELEtBakNBO0FBQUE7QUFtQ0Q7Ozs7Ozs7OztBQU9NakQsYUFBTixDQUFrQjlELEtBQWxCLEVBQXlCeEksTUFBekIsRUFBaUMzQixJQUFqQyxFQUF1Q21SLFFBQXZDO0FBQUEsb0NBQWdEO0FBQzlDLFVBQUk5TSxNQUFPLFVBQVM4RixLQUFNLE9BQTFCO0FBRUEsVUFBSW1ILFVBQVUsRUFBZDs7QUFDQSxXQUFLLElBQUl0RCxDQUFULElBQWNiLE9BQU9ZLElBQVAsQ0FBWS9OLElBQVosQ0FBZCxFQUFpQztBQUMvQnNSLGdCQUFRN0csSUFBUixDQUFjLEdBQUV1RCxDQUFFLEtBQUloTyxLQUFLZ08sQ0FBTCxDQUFRLEdBQTlCO0FBQ0Q7O0FBQ0QsV0FBSyxJQUFJQSxDQUFULElBQWNiLE9BQU9ZLElBQVAsQ0FBWW9ELFFBQVosQ0FBZCxFQUFxQztBQUNuQ0csZ0JBQVE3RyxJQUFSLENBQWMsR0FBRXVELENBQUUsSUFBR21ELFNBQVNuRCxDQUFULENBQVksRUFBakM7QUFDRDs7QUFDRDNKLGFBQU9pTixRQUFRNUUsSUFBUixDQUFhLEdBQWIsQ0FBUDtBQUVBckksYUFBUSxVQUFTMUMsTUFBTyxHQUF4QjtBQUVBLFVBQUlxQixvQkFBWSxLQUFLa0IsS0FBTCxDQUFXRyxHQUFYLENBQVosQ0FBSjtBQUNBLGFBQU9yQixHQUFQO0FBQ0QsS0FoQkQ7QUFBQSxHQXBHeUIsQ0FzSHpCOzs7QUFDTXVPLFlBQU4sQ0FBaUJsTixHQUFqQjtBQUFBLG9DQUFzQjtBQUNwQixVQUFJbU4sV0FBVyxLQUFLcEIsSUFBcEI7QUFDQSxXQUFLQSxJQUFMLEdBQVksS0FBS0ksU0FBakI7O0FBQ0EsVUFBRztBQUNELFlBQUl4TixvQkFBWSxLQUFLa0IsS0FBTCxDQUFXRyxHQUFYLENBQVosQ0FBSjtBQUNBLGVBQU9yQixHQUFQO0FBQ0QsT0FIRCxTQUlPO0FBQ0wsYUFBS29OLElBQUwsR0FBWW9CLFFBQVo7QUFDRDtBQUNGLEtBVkQ7QUFBQTs7QUFZTUMsa0JBQU47QUFBQSxvQ0FBd0I7QUFDdEIsb0JBQU0sS0FBS3ZOLEtBQUwsQ0FBWSxvQkFBWixDQUFOO0FBQ0QsS0FGRDtBQUFBOztBQUlNd04sUUFBTjtBQUFBLG9DQUFjO0FBQ1osb0JBQU0sS0FBS3hOLEtBQUwsQ0FBWSxTQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSU15TixVQUFOO0FBQUEsb0NBQWdCO0FBQ2Qsb0JBQU0sS0FBS3pOLEtBQUwsQ0FBWSxXQUFaLENBQU47QUFDRCxLQUZEO0FBQUE7O0FBSUFrRyxpQkFBZS9GLEdBQWYsRUFBb0I0RixXQUFZN0YsTUFBRCxJQUFZLENBQUUsQ0FBN0MsRUFBK0M4RixVQUFXckgsQ0FBRCxJQUFPLENBQUUsQ0FBbEUsRUFBb0U7QUFDbEUsV0FBTyxLQUFLZ08sTUFBTCxHQUNKQyxJQURJLENBRUZDLEdBQUQsSUFBUztBQUNQLGFBQU8sSUFBSTNGLE9BQUosQ0FDTCxDQUFPQyxPQUFQLEVBQWdCQyxNQUFoQiw4QkFBMkI7QUFDekI7QUFDQXlGLFlBQUk3TSxLQUFKLENBQVVHLEdBQVYsRUFDR3VOLEVBREgsQ0FDTSxRQUROLEVBRUt4TixNQUFELElBQVk7QUFDVjJNLGNBQUljLEtBQUo7QUFDQTVILG1CQUFTN0YsTUFBVDtBQUNBMk0sY0FBSWUsTUFBSjtBQUNELFNBTkwsRUFPR0YsRUFQSCxDQU9NLE9BUE4sRUFPZ0IvTyxDQUFELElBQU87QUFDbEJxSCxrQkFBUXJILENBQVI7QUFDRCxTQVRILEVBVUcrTyxFQVZILENBVU0sS0FWTixFQVVhLE1BQU07QUFDZmIsY0FBSUMsT0FBSjtBQUNBM0Y7QUFDRCxTQWJIO0FBY0QsT0FoQkQsQ0FESyxDQUFQO0FBb0JELEtBdkJFLEVBeUJKSSxLQXpCSSxDQXlCRzVJLENBQUQsSUFBTztBQUNaLFlBQU1BLENBQU47QUFDRCxLQTNCSSxDQUFQO0FBNkJEOztBQUdEZ08sV0FBUztBQUNQLFdBQU8sSUFBSXpGLE9BQUosQ0FDSCxDQUFDQyxPQUFELEVBQVVDLE1BQVYsS0FBcUI7QUFDbkI7QUFDQSxXQUFLOEUsSUFBTCxDQUFVMkIsYUFBVixDQUF3QixDQUFDbFAsQ0FBRCxFQUFJa08sR0FBSixLQUFZO0FBQ2xDLFlBQUlsTyxDQUFKLEVBQU87QUFDTHlJLGlCQUFPekksQ0FBUDtBQUNELFNBRkQsTUFFTztBQUNMd0ksa0JBQVEwRixHQUFSO0FBQ0Q7QUFDRixPQU5EO0FBT0QsS0FWRSxFQVlKdEYsS0FaSSxDQWFGNUksQ0FBRCxJQUFPO0FBQ0wsWUFBTUEsQ0FBTjtBQUNELEtBZkUsQ0FBUDtBQWlCRDs7QUFsTXdCLEM7Ozs7Ozs7Ozs7O0FDSjNCckUsT0FBT3lLLE1BQVAsQ0FBYztBQUFDdEssV0FBUSxNQUFJdUM7QUFBYixDQUFkOztBQUFlLE1BQU1BLE1BQU4sQ0FBYTtBQUUxQndJLGdCQUFjO0FBQ1osU0FBS3RGLE1BQUwsR0FBYyxFQUFkO0FBQ0EsU0FBSzROLFFBQUwsR0FBZ0IsSUFBSUMsUUFBSixFQUFoQjtBQUNEOztBQUVLaFEsT0FBTixDQUFZekIsT0FBTyxFQUFuQixFQUF1QitPLEtBQUssK0JBQVksQ0FBRSxDQUFkLENBQTVCO0FBQUEsb0NBQTRDO0FBRTFDLFdBQUt5QyxRQUFMLEdBQWdCLElBQUlDLFFBQUosRUFBaEI7QUFDQSxVQUFJQyxNQUFNLEVBQVY7O0FBRUEsVUFBSTtBQUVGLFlBQUlsUCxvQkFBWXVNLElBQVosQ0FBSjtBQUVBcEMsZUFBT0MsTUFBUCxDQUFjOEUsR0FBZCxFQUFtQjtBQUNqQnBJLGdCQUFNLFNBRFc7QUFFakI3SCxpQkFBT3pCLElBRlU7QUFHakIyUixrQkFBUW5QO0FBSFMsU0FBbkI7QUFNRCxPQVZELENBVUUsT0FBT0gsQ0FBUCxFQUFVO0FBRVZzSyxlQUFPQyxNQUFQLENBQWM4RSxHQUFkLEVBQW1CO0FBQ2pCcEksZ0JBQU0sT0FEVztBQUVqQjdILGlCQUFPekIsSUFGVTtBQUdqQjJSLGtCQUFRdFA7QUFIUyxTQUFuQjtBQU1ELE9BbEJELFNBa0JVO0FBRVIsWUFBSSxLQUFLbVAsUUFBTCxDQUFjSSxLQUFsQixFQUF5QjtBQUN2QmpGLGlCQUFPQyxNQUFQLENBQWM4RSxHQUFkLEVBQW1CO0FBQ2pCRixzQkFBVSxLQUFLQTtBQURFLFdBQW5CO0FBR0Q7O0FBQ0QsYUFBSzVOLE1BQUwsQ0FBWXFHLElBQVosQ0FBaUJ5SCxHQUFqQjtBQUVEO0FBRUYsS0FsQ0Q7QUFBQTs7QUFvQ0F0UCxXQUFTeVAsU0FBVCxFQUFvQjtBQUNsQixTQUFLTCxRQUFMLENBQWNNLE9BQWQsQ0FBc0JELFNBQXRCO0FBQ0Q7O0FBRUR2UCxTQUFPdVAsU0FBUCxFQUFrQjtBQUNoQixTQUFLTCxRQUFMLENBQWNyUixLQUFkLENBQW9CMFIsU0FBcEI7QUFDRDs7QUFFREUsaUJBQWM7QUFDWixRQUFJQyxXQUFXLEtBQUtSLFFBQUwsQ0FBY1MsS0FBZCxDQUFvQjlSLEtBQXBCLENBQTBCeVIsS0FBekM7QUFDQSxRQUFJTSxXQUFXLEtBQWY7O0FBQ0EsU0FBSyxJQUFJUixHQUFULElBQWdCLEtBQUs5TixNQUFyQixFQUE2QjtBQUMzQixVQUFJOE4sSUFBSXBJLElBQUosS0FBYSxPQUFqQixFQUF5QjtBQUN2QjRJLG1CQUFXLElBQVg7QUFDQTtBQUNEO0FBQ0Y7O0FBQ0QsV0FBT0YsWUFBWUUsUUFBbkI7QUFDRDs7QUFFRDNQLFlBQVU7QUFDUixRQUFHLEtBQUt3UCxZQUFMLEVBQUgsRUFBdUI7QUFDckIsWUFBTSxJQUFJL1MsT0FBTzZLLEtBQVgsQ0FBaUIsS0FBS2pHLE1BQXRCLENBQU47QUFDRDs7QUFDRCxXQUFPLEtBQUtBLE1BQVo7QUFDRDs7QUFwRXlCOztBQXlFNUIsTUFBTTZOLFFBQU4sQ0FBZTtBQUVidkksZ0JBQWM7QUFDWixTQUFLMEksS0FBTCxHQUFZLENBQVo7QUFDQSxTQUFLSyxLQUFMLEdBQWE7QUFDWEgsZUFBUztBQUNQRixlQUFPLENBREE7QUFFUE8saUJBQVM7QUFGRixPQURFO0FBS1hoUyxhQUFPO0FBQ0x5UixlQUFPLENBREY7QUFFTE8saUJBQVM7QUFGSjtBQUxJLEtBQWI7QUFVRDs7QUFFREwsVUFBUUQsU0FBUixFQUFtQjtBQUNqQixRQUFHQSxTQUFILEVBQWE7QUFDWCxXQUFLSSxLQUFMLENBQVdILE9BQVgsQ0FBbUJLLE9BQW5CLENBQTJCbEksSUFBM0IsQ0FBZ0M0SCxTQUFoQztBQUNEOztBQUNELFNBQUtJLEtBQUwsQ0FBV0gsT0FBWCxDQUFtQkYsS0FBbkI7QUFDQSxTQUFLQSxLQUFMO0FBQ0Q7O0FBQ0R6UixRQUFNMFIsU0FBTixFQUFpQjtBQUNmLFFBQUdBLGFBQWFBLGNBQWMsRUFBM0IsSUFBaUNBLGNBQWEsRUFBakQsRUFBcUQ7QUFDbkQsV0FBS0ksS0FBTCxDQUFXOVIsS0FBWCxDQUFpQmdTLE9BQWpCLENBQXlCbEksSUFBekIsQ0FBOEIxSixLQUFLNlIsS0FBTCxDQUFXUCxTQUFYLENBQTlCO0FBQ0Q7O0FBQ0QsU0FBS0ksS0FBTCxDQUFXOVIsS0FBWCxDQUFpQnlSLEtBQWpCO0FBQ0EsU0FBS0EsS0FBTDtBQUNEOztBQTdCWSxDIiwiZmlsZSI6Ii9hcHAuanMiLCJzb3VyY2VzQ29udGVudCI6WyIvLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIChyZXEsIHJlcywgbmV4dCkgPT4ge1xyXG4vLyAgIHJlcy53cml0ZUhlYWQoMjAwKTtcclxuLy8gICByZXMuZW5kKGBIZWxsbyB3b3JsZCBmcm9tOiAke01ldGVvci5yZWxlYXNlfWApO1xyXG4vLyB9KTtcclxuXHJcbmltcG9ydCBmcyBmcm9tICdmcyc7XHJcbmltcG9ydCB1bmlxaWQgZnJvbSAndW5pcWlkJztcclxuXHJcbi8vIFJlcXVpcmVzIG11bHRpcGFydHkgXHJcbmltcG9ydCBtdWx0aXBhcnR5IGZyb20gJ2Nvbm5lY3QtbXVsdGlwYXJ0eSc7XHJcbmltcG9ydCB7XHJcbiAgVXBsb2Fkc1xyXG59IGZyb20gJy4uLy4uLy4uL2ltcG9ydHMvY29sbGVjdGlvbi91cGxvYWRzJztcclxubGV0IG11bHRpcGFydHlNaWRkbGV3YXJlID0gbXVsdGlwYXJ0eSgpO1xyXG5cclxuY29uc3Qgcm91dGUgPSAnL3VwbG9hZC9pbWFnZSc7XHJcblxyXG4vLyBXZWJBcHAuY29ubmVjdEhhbmRsZXJzLnVzZSgnL3VwbG9hZCcsIGZ1Yy51cGxvYWRGaWxlICk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCBtdWx0aXBhcnR5TWlkZGxld2FyZSk7XHJcbldlYkFwcC5jb25uZWN0SGFuZGxlcnMudXNlKHJvdXRlLCAocmVxLCByZXNwKSA9PiB7XHJcbiAgLy8gZG9uJ3QgZm9yZ2V0IHRvIGRlbGV0ZSBhbGwgcmVxLmZpbGVzIHdoZW4gZG9uZVxyXG5cclxuICBjb25zdCByZWFkZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLnJlYWRGaWxlKTtcclxuICBjb25zdCB3cml0ZXIgPSBNZXRlb3Iud3JhcEFzeW5jKGZzLndyaXRlRmlsZSk7XHJcbiAgY29uc3QgdXBsb2FkSWQgPSB1bmlxaWQoKTtcclxuXHJcbiAgZm9yIChsZXQgZmlsZSBvZiByZXEuZmlsZXMuZmlsZSkge1xyXG4gICAgY29uc3QgZGF0YSA9IHJlYWRlcihmaWxlLnBhdGgpO1xyXG4gICAgLy8g44OV44Kh44Kk44Or5ZCN44Gu6YeN6KSH44KS6YG/44GR44KL44Gf44KB44CB5LiA5oSP44Gu44OV44Kh44Kk44Or5ZCN44KS5L2c5oiQ44GZ44KLXHJcbiAgICAvLyDmpb3lpKnjga7jg5XjgqHjgqTjg6vlkI3mloflrZfmlbDliLbpmZAyMOOBq+WQiOOCj+OBm+OCi1xyXG4gICAgbGV0IGZpbGVuYW1lID0gYCR7dW5pcWlkKCl9LmpwZ2BcclxuXHJcbiAgICAvLyBzZXQgdGhlIGNvcnJlY3QgcGF0aCBmb3IgdGhlIGZpbGUgbm90IHRoZSB0ZW1wb3Jhcnkgb25lIGZyb20gdGhlIEFQSTpcclxuICAgIGxldCBzYXZlUGF0aCA9IHJlcS5ib2R5LmltYWdlZGlyICsgJy8nICsgZmlsZW5hbWU7XHJcblxyXG4gICAgLy8gY29weSB0aGUgZGF0YSBmcm9tIHRoZSByZXEuZmlsZXMuZmlsZS5wYXRoIGFuZCBwYXN0ZSBpdCB0byBmaWxlLnBhdGhcclxuXHJcbiAgICAvLyDjgqLjg4Pjg5fjg63jg7zjg4nntZDmnpzjgpLoqJjpjLLjgZnjgotcclxuICAgIGxldCBkb2MgPSB7XHJcbiAgICAgIHVwbG9hZElkOiB1cGxvYWRJZCxcclxuICAgICAgY2xpZW50RmlsZU5hbWU6IGZpbGUubmFtZSxcclxuICAgICAgdXBsb2FkZWRGaWxlTmFtZTogZmlsZW5hbWVcclxuICAgIH07XHJcbiAgICBcclxuICAgIHRyeXtcclxuICAgICAgd3JpdGVyKHNhdmVQYXRoLCBkYXRhKTtcclxuICAgIH1cclxuICAgIGNhdGNoKGVycil7XHJcbiAgICAgIGRvYy5lcnJvciA9IGVycjtcclxuICAgIH1cclxuICAgIFVwbG9hZHMuaW5zZXJ0KGRvYyk7XHJcblxyXG4gICAgZGVsZXRlIGZpbGU7XHJcblxyXG4gIH07XHJcbiAgcmVzcC53cml0ZUhlYWQoMjAwKTtcclxuICByZXNwLmVuZChKU09OLnN0cmluZ2lmeSh7XHJcbiAgICB1cGxvYWRJZDogdXBsb2FkSWQsXHJcbiAgICBzYXZlRGlyOiByZXEuYm9keS5pbWFnZWRpclxyXG4gIH0pKTtcclxuXHJcbn0pOyIsImltcG9ydCBSZXBvcnQgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL3JlcG9ydCc7XHJcbmltcG9ydCB7XHJcbiAgTW9uZ29EQkZpbHRlclxyXG59IGZyb20gJy4uLy4uL2ltcG9ydHMvY29yZS9kYmZpbHRlcic7XHJcbmltcG9ydCB7XHJcbiAgQ3ViZTNBcGlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvcmUvY3ViZTNhcGknO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJztcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uLy4uL2ltcG9ydHMvY29udHJvbGxlci9pdGVtcyc7XHJcblxyXG5sZXQgdGFnID0gJ2N1YmV1cCc7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8vXHJcbiAgLy8g5ZWG5ZOB5oOF5aCx5pu05pawXHJcblxyXG4gIGFzeW5jIFtgJHt0YWd9Lml0ZW1gXShjb25maWcpIHtcclxuXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpO1xyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKTtcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpO1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0pMSU5FIEVOR0lORSDjgYvjgonjga7lj5bjgorovrzjgb8nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICAgJ1NBTVBMRSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb247XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcblxyXG4gICAgICAgICAgICAgICAgY3ViZUl0ZW0gPSBJdGVtQ29udHJvbGxlci5pdGVtQ3ViZTMoaXRlbSk7XHJcblxyXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RVcGRhdGUoY3ViZUl0ZW0pO1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgYXBpLnByb2R1Y3RUYWdVcGRhdGUoY29uZmlnLmNyZWF0b3JfaWQsY3ViZUl0ZW0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xyXG5cclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpO1xyXG5cclxuICB9LFxyXG5cclxuXHJcbiAgLy9cclxuICAvLyDnlLvlg4/mm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uaW1hZ2VgXShjb25maWcpIHtcclxuXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpO1xyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKTtcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpO1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0pMSU5FIEVOR0lORSDjgYvjgonjga7lj5bjgorovrzjgb8nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICAgJ1NBTVBMRSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb247XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGFwaS5wcm9kdWN0SW1hZ2VVcGRhdGUoXHJcbiAgICAgICAgICAgICAgICAgIGNvbmZpZy5jcmVhdG9yX2lkLFxyXG4gICAgICAgICAgICAgICAgICBJdGVtQ29udHJvbGxlci5pdGVtQ3ViZTMoaXRlbSlcclxuICAgICAgICAgICAgICAgICk7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlTdWNjZXNzKCk7XHJcblxyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuXHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG5cclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICB0aHJvdyBlXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgKTtcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XHJcblxyXG4gIH1cclxuXHJcblxyXG59KTsiLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnO1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvcmUvZGJmaWx0ZXInO1xyXG5pbXBvcnQge1xyXG4gIEN1YmUzQXBpXHJcbn0gZnJvbSAnLi4vLi4vaW1wb3J0cy9jb3JlL2N1YmUzYXBpJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uLy4uL2ltcG9ydHMvdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTW9uZ29DbGllbnRcclxufSBmcm9tICdtb25nb2RiJztcclxuaW1wb3J0IEl0ZW1Db250cm9sbGVyIGZyb20gJy4uLy4uL2ltcG9ydHMvY29udHJvbGxlci9pdGVtcyc7XHJcblxyXG5sZXQgdGFnID0gJ2N1YmV4JztcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJpdGBdKGNvbmZpZykge1xyXG5cclxuICAgIGxldCByZXBvcnQgPSBuZXcgUmVwb3J0KCk7XHJcblxyXG4gICAgLy8gbGV0IG1vbmdvSmxpbmU7XHJcbiAgICAvLyBsZXQgSXRlbXM7XHJcblxyXG4gICAgLy8gYXdhaXQgcmVwb3J0LnBoYXNlKFxyXG4gICAgLy8gICAnSkxJTkUgRU5HSU5FIOOBuOOBruaOpee2micsXHJcbiAgICAvLyAgIGFzeW5jICgpPT57XHJcbiAgICAvLyAgICAgbGV0IHBsdWcgPSBjb25maWcuc291cmNlREI7XHJcbiAgICAvLyAgICAgbW9uZ29KbGluZSA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpO1xyXG4gICAgLy8gICAgIEl0ZW1zID0gbW9uZ29KbGluZS5kYihwbHVnLmRhdGFiYXNlKS5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XHJcbiAgICAvLyAgIH1cclxuICAgIC8vICk7XHJcblxyXG4gICAgbGV0IGZpbHRlciA9IG5ldyBNb25nb0RCRmlsdGVyKGNvbmZpZy5zb3VyY2VEQiwgY29uZmlnLnByb2ZpbGUpO1xyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy50YXJnZXREQi5jcmVkKTtcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpO1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0pMSU5FIEVOR0lORSDjgYvjgonjga7lj5bjgorovrzjgb8nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICAgJ0tPTUlORV9OT1RFWElTVFMnOiBhc3luYyAoaXRlbSwgY29udGV4dCkgPT4ge1xyXG5cclxuICAgICAgICAgICAgICBsZXQgY29sID0gY29udGV4dC5jb2xsZWN0aW9uO1xyXG5cclxuICAgICAgICAgICAgICB0cnkge1xyXG5cclxuICAgICAgICAgICAgICAgIGxldCBpbnNlcnRSZXQgPSBhd2FpdCBhcGkucHJvZHVjdENyZWF0ZShcclxuICAgICAgICAgICAgICAgICAgY29uZmlnLmNyZWF0b3JfaWQsXHJcbiAgICAgICAgICAgICAgICAgIEl0ZW1Db250cm9sbGVyLml0ZW1DdWJlMyhpdGVtKVxyXG4gICAgICAgICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgICAgICAgICBhd2FpdCBjb2wudXBkYXRlKHtcclxuICAgICAgICAgICAgICAgICAgX2lkOiBpdGVtLl9pZFxyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AnOiBpbnNlcnRSZXQucmVzXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xyXG5cclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgICAgfVxyXG4gICAgICAgICk7XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG5cclxuICAgIHJldHVybiByZXBvcnQucHVibGlzaCgpO1xyXG5cclxuICB9XHJcblxyXG59KTsiLCJpbXBvcnQgY3J5cHRvIGZyb20gJ2NyeXB0byc7XHJcblxyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vLi4vaW1wb3J0cy91dGlsL215c3FsJztcclxuaW1wb3J0IFJlcG9ydCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvcmVwb3J0JztcclxuaW1wb3J0IHtcclxuICBHcm91cCxcclxuICBHcm91cEZhY3RvcnlcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZ3JvdXBzJztcclxuaW1wb3J0IHtcclxuICBGaWx0ZXJcclxufSBmcm9tICcuLi8uLi9pbXBvcnRzL2NvbGxlY3Rpb24vZmlsdGVycyc7XHJcblxyXG5sZXQgdGFnID0gJ2N1YmVtaWcnO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5taWdyYXRlYF0oY29uZmlnKSB7XHJcblxyXG4gICAgbGV0IHJlcG9ydCA9IG5ldyBSZXBvcnQoKTtcclxuXHJcbiAgICAvLyBzZXR1cCBncm91cFxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgZmlsdGVyID0gbmV3IEZpbHRlcihjb25maWcuc3JjRmlsdGVySWQpO1xyXG4gICAgLy8gbGV0IHBsdWcgPSBncm91cC5nZXRQbHVnKCk7XHJcblxyXG4gICAgLy8gY2hlY2tpbmcgY29ubmVjdGlvblxyXG4gICAgLy9cclxuXHJcbiAgICBsZXQgdGVzdFF1ZXJ5ID0gJ1NIT1cgREFUQUJBU0VTJztcclxuXHJcbiAgICBsZXQgZHN0RGIgPSBuZXcgTXlTUUwoY29uZmlnLmRzdC5jcmVkKTtcclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ0Nvbm5lY3QgdG8gRGVzdGluYXRpb24nLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgYXdhaXQgZHN0RGIucXVlcnkodGVzdFF1ZXJ5KTtcclxuICAgICAgfSk7XHJcblxyXG5cclxuICAgIC8vIHByb2Nlc3MgZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAgLy9cclxuXHJcbiAgICBhd2FpdCByZXBvcnQucGhhc2UoJ1NlbGVjdCBsb29wIGluIHNvdXJjZScsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goe1xyXG4gICAgICAgICAgICBtb2JpbGVOdWxsOiBhc3luYyAocmVjb3JkKSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgIC8vIC8vIOWApOOCkuaVtOeQhlxyXG4gICAgICAgICAgICAgIC8vIGZvciAobGV0IGtleSBvZiBPYmplY3Qua2V5cyhyZWNvcmQpKSB7XHJcbiAgICAgICAgICAgICAgLy8gICBpZiAocmVjb3JkW2tleV0gPT09IG51bGwpO1xyXG4gICAgICAgICAgICAgIC8vICAgZWxzZSBpZiAocmVjb3JkW2tleV0uY29uc3RydWN0b3IubmFtZSA9PT0gJ0RhdGUnKSB7XHJcbiAgICAgICAgICAgICAgLy8gICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IE15U1FMLmZvcm1hdERhdGUocmVjb3JkW2tleV0pO1xyXG4gICAgICAgICAgICAgIC8vICAgICByZWNvcmRba2V5XSA9IGBcIiR7cmVjb3JkW2tleV19XCJgO1xyXG4gICAgICAgICAgICAgIC8vICAgfVxyXG4gICAgICAgICAgICAgIC8vIH1cclxuXHJcbiAgICAgICAgICAgICAgLy8gZHRiX2N1c3RvbWVyIOOBq+S/neWtmFxyXG5cclxuICAgICAgICAgICAgICBsZXQgc3FsID0gYFxyXG5cclxuICAgICAgICAgICAgICAgIElOU0VSVCBkdGJfY3VzdG9tZXJcclxuICAgICAgICAgICAgICAgICggXFxgY3VzdG9tZXJfaWRcXGAsIFxcYHN0YXR1c1xcYCwgXFxgc2V4XFxgLCBcXGBqb2JcXGAsIFxcYGNvdW50cnlfaWRcXGAsIFxcYHByZWZcXGAsIFxcYG5hbWUwMVxcYCwgXFxgbmFtZTAyXFxgLCBcXGBrYW5hMDFcXGAsIFxcYGthbmEwMlxcYCwgXFxgY29tcGFueV9uYW1lXFxgLCBcXGB6aXAwMVxcYCwgXFxgemlwMDJcXGAsIFxcYHppcGNvZGVcXGAsIFxcYGFkZHIwMVxcYCwgXFxgYWRkcjAyXFxgLCBcXGBlbWFpbFxcYCwgXFxgdGVsMDFcXGAsIFxcYHRlbDAyXFxgLCBcXGB0ZWwwM1xcYCwgXFxgZmF4MDFcXGAsIFxcYGZheDAyXFxgLCBcXGBmYXgwM1xcYCwgXFxgYmlydGhcXGAsIFxcYHBhc3N3b3JkXFxgLCBcXGBzYWx0XFxgLCBcXGBzZWNyZXRfa2V5XFxgLCBcXGBmaXJzdF9idXlfZGF0ZVxcYCwgXFxgbGFzdF9idXlfZGF0ZVxcYCwgXFxgYnV5X3RpbWVzXFxgLCBcXGBidXlfdG90YWxcXGAsIFxcYG5vdGVcXGAsIFxcYGNyZWF0ZV9kYXRlXFxgLCBcXGB1cGRhdGVfZGF0ZVxcYCwgXFxgZGVsX2ZsZ1xcYCApXHJcblxyXG4gICAgICAgICAgICAgICAgVkFMVUVTKCAkeyByZWNvcmQuY3VzdG9tZXJfaWQgfSAsICR7IHJlY29yZC5zdGF0dXMgfSAsICR7IHJlY29yZC5zZXggfSAsICR7IHJlY29yZC5qb2IgfSAsICR7IHJlY29yZC5jb3VudHJ5X2lkIH0gLCAkeyByZWNvcmQucHJlZiB9ICwgJHsgcmVjb3JkLm5hbWUwMSB9ICwgJHsgcmVjb3JkLm5hbWUwMiB9ICwgJHsgcmVjb3JkLmthbmEwMSB9ICwgJHsgcmVjb3JkLmthbmEwMiB9ICwgJHsgcmVjb3JkLmNvbXBhbnlfbmFtZSB9ICwgJHsgcmVjb3JkLnppcDAxIH0gLCAkeyByZWNvcmQuemlwMDIgfSAsICR7IHJlY29yZC56aXBjb2RlIH0gLCAkeyByZWNvcmQuYWRkcjAxIH0gLCAkeyByZWNvcmQuYWRkcjAyIH0gLCAkeyByZWNvcmQuZW1haWwgfSAsICR7IHJlY29yZC50ZWwwMSB9ICwgJHsgcmVjb3JkLnRlbDAyIH0gLCAkeyByZWNvcmQudGVsMDMgfSAsICR7IHJlY29yZC5mYXgwMSB9ICwgJHsgcmVjb3JkLmZheDAyIH0gLCAkeyByZWNvcmQuZmF4MDMgfSAsICR7IHJlY29yZC5iaXJ0aCB9ICwgJHsgcmVjb3JkLnBhc3N3b3JkIH0gLCAkeyByZWNvcmQuc2FsdCB9ICwgJHsgcmVjb3JkLnNlY3JldF9rZXkgfSAsICR7IHJlY29yZC5maXJzdF9idXlfZGF0ZSB9ICwgJHsgcmVjb3JkLmxhc3RfYnV5X2RhdGUgfSAsICR7IHJlY29yZC5idXlfdGltZXMgfSAsICR7IHJlY29yZC5idXlfdG90YWwgfSAsICR7IHJlY29yZC5ub3RlIH0gLCAkeyByZWNvcmQuY3JlYXRlX2RhdGUgfSAsICR7IHJlY29yZC51cGRhdGVfZGF0ZSB9ICwgJHsgcmVjb3JkLmRlbF9mbGcgfSApXHJcbiAgICAgICAgICAgICAgICBcclxuICAgICAgICAgICAgICAgIGA7XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcicsXHJcbiAgICAgICAgICAgICAgICAgIHtcclxuICAgICAgICAgICAgICAgICAgICBjdXN0b21lcl9pZDogcmVjb3JkLmN1c3RvbWVyX2lkLFxyXG4gICAgICAgICAgICAgICAgICAgIHN0YXR1czogcmVjb3JkLnN0YXR1cyxcclxuICAgICAgICAgICAgICAgICAgICBzZXg6IHJlY29yZC5zZXgsXHJcbiAgICAgICAgICAgICAgICAgICAgam9iOiByZWNvcmQuam9iLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdW50cnlfaWQ6IHJlY29yZC5jb3VudHJ5X2lkLFxyXG4gICAgICAgICAgICAgICAgICAgIHByZWY6IHJlY29yZC5wcmVmLFxyXG4gICAgICAgICAgICAgICAgICAgIG5hbWUwMTogcmVjb3JkLm5hbWUwMSxcclxuICAgICAgICAgICAgICAgICAgICBuYW1lMDI6IHJlY29yZC5uYW1lMDIsXHJcbiAgICAgICAgICAgICAgICAgICAga2FuYTAxOiByZWNvcmQua2FuYTAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGthbmEwMjogcmVjb3JkLmthbmEwMixcclxuICAgICAgICAgICAgICAgICAgICBjb21wYW55X25hbWU6IHJlY29yZC5jb21wYW55X25hbWUsXHJcbiAgICAgICAgICAgICAgICAgICAgemlwMDE6IHJlY29yZC56aXAwMSxcclxuICAgICAgICAgICAgICAgICAgICB6aXAwMjogcmVjb3JkLnppcDAyLFxyXG4gICAgICAgICAgICAgICAgICAgIHppcGNvZGU6IHJlY29yZC56aXBjb2RlLFxyXG4gICAgICAgICAgICAgICAgICAgIGFkZHIwMTogcmVjb3JkLmFkZHIwMSxcclxuICAgICAgICAgICAgICAgICAgICBhZGRyMDI6IHJlY29yZC5hZGRyMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgZW1haWw6IHJlY29yZC5lbWFpbCxcclxuICAgICAgICAgICAgICAgICAgICB0ZWwwMTogcmVjb3JkLnRlbDAxLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbDAyOiByZWNvcmQudGVsMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVsMDM6IHJlY29yZC50ZWwwMyxcclxuICAgICAgICAgICAgICAgICAgICBmYXgwMTogcmVjb3JkLmZheDAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGZheDAyOiByZWNvcmQuZmF4MDIsXHJcbiAgICAgICAgICAgICAgICAgICAgZmF4MDM6IHJlY29yZC5mYXgwMyxcclxuICAgICAgICAgICAgICAgICAgICBiaXJ0aDogcmVjb3JkLmJpcnRoLFxyXG4gICAgICAgICAgICAgICAgICAgIHBhc3N3b3JkOiByZWNvcmQucGFzc3dvcmQsXHJcbiAgICAgICAgICAgICAgICAgICAgc2FsdDogcmVjb3JkLnNhbHQsXHJcbiAgICAgICAgICAgICAgICAgICAgc2VjcmV0X2tleTogcmVjb3JkLnNlY3JldF9rZXksXHJcbiAgICAgICAgICAgICAgICAgICAgZmlyc3RfYnV5X2RhdGU6IHJlY29yZC5maXJzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBsYXN0X2J1eV9kYXRlOiByZWNvcmQubGFzdF9idXlfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBidXlfdGltZXM6IHJlY29yZC5idXlfdGltZXMsXHJcbiAgICAgICAgICAgICAgICAgICAgYnV5X3RvdGFsOiByZWNvcmQuYnV5X3RvdGFsLFxyXG4gICAgICAgICAgICAgICAgICAgIG5vdGU6IHJlY29yZC5ub3RlLFxyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApO1xyXG4gICAgICAgICAgICAgIH0gY2F0Y2ggKGUpIHtcclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XHJcbiAgICAgICAgICAgICAgfVxyXG5cclxuICAgICAgICAgICAgICAvLyBkdGJfY3VzdG9tZXJfYWRkcmVzc1xyXG4gICAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgICBhd2FpdCBkc3REYi5xdWVyeUluc2VydChcclxuICAgICAgICAgICAgICAgICAgJ2R0Yl9jdXN0b21lcl9hZGRyZXNzJywge1xyXG4gICAgICAgICAgICAgICAgICAgIGN1c3RvbWVyX2FkZHJlc3NfaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgICBjb3VudHJ5X2lkOiByZWNvcmQuY291bnRyeV9pZCxcclxuICAgICAgICAgICAgICAgICAgICBwcmVmOiByZWNvcmQucHJlZixcclxuICAgICAgICAgICAgICAgICAgICBuYW1lMDE6IHJlY29yZC5uYW1lMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgbmFtZTAyOiByZWNvcmQubmFtZTAyLFxyXG4gICAgICAgICAgICAgICAgICAgIGthbmEwMTogcmVjb3JkLmthbmEwMSxcclxuICAgICAgICAgICAgICAgICAgICBrYW5hMDI6IHJlY29yZC5rYW5hMDIsXHJcbiAgICAgICAgICAgICAgICAgICAgY29tcGFueV9uYW1lOiByZWNvcmQuY29tcGFueV9uYW1lLFxyXG4gICAgICAgICAgICAgICAgICAgIHppcDAxOiByZWNvcmQuemlwMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgemlwMDI6IHJlY29yZC56aXAwMixcclxuICAgICAgICAgICAgICAgICAgICB6aXBjb2RlOiByZWNvcmQuemlwY29kZSxcclxuICAgICAgICAgICAgICAgICAgICBhZGRyMDE6IHJlY29yZC5hZGRyMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgYWRkcjAyOiByZWNvcmQuYWRkcjAyLFxyXG4gICAgICAgICAgICAgICAgICAgIHRlbDAxOiByZWNvcmQudGVsMDEsXHJcbiAgICAgICAgICAgICAgICAgICAgdGVsMDI6IHJlY29yZC50ZWwwMixcclxuICAgICAgICAgICAgICAgICAgICB0ZWwwMzogcmVjb3JkLnRlbDAzLFxyXG4gICAgICAgICAgICAgICAgICAgIGZheDAxOiByZWNvcmQuZmF4MDEsXHJcbiAgICAgICAgICAgICAgICAgICAgZmF4MDI6IHJlY29yZC5mYXgwMixcclxuICAgICAgICAgICAgICAgICAgICBmYXgwMzogcmVjb3JkLmZheDAzLFxyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiByZWNvcmQuY3JlYXRlX2RhdGUsXHJcbiAgICAgICAgICAgICAgICAgICAgdXBkYXRlX2RhdGU6IHJlY29yZC51cGRhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICBkZWxfZmxnOiByZWNvcmQuZGVsX2ZsZ1xyXG4gICAgICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgICAgICApXHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuICAgICAgICAgICAgICB9XHJcblxyXG4gICAgICAgICAgICAgIC8vIOODoeODq+ODnuOCrOODl+ODqeOCsOOCpOODsyBwbGdfbWFpbG1hZ2FfY3VzdG9tZXJcclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgYXdhaXQgZHN0RGIucXVlcnlJbnNlcnQoXHJcbiAgICAgICAgICAgICAgICAgICdwbGdfbWFpbG1hZ2FfY3VzdG9tZXInLCB7XHJcbiAgICAgICAgICAgICAgICAgICAgaWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgY3VzdG9tZXJfaWQ6IHJlY29yZC5jdXN0b21lcl9pZCxcclxuICAgICAgICAgICAgICAgICAgICBtYWlsbWFnYV9mbGc6IHJlY29yZC5tYWlsbWFnYV9mbGcsXHJcbiAgICAgICAgICAgICAgICAgICAgY3JlYXRlX2RhdGU6IHJlY29yZC5jcmVhdGVfZGF0ZSxcclxuICAgICAgICAgICAgICAgICAgICB1cGRhdGVfZGF0ZTogcmVjb3JkLnVwZGF0ZV9kYXRlLFxyXG4gICAgICAgICAgICAgICAgICAgIGRlbF9mbGc6IHJlY29yZC5kZWxfZmxnXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIClcclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG4gICAgICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICAgICAgLy8g44Kv44O844Od44Oz55m66KGM77yIRUNDVUJFMuOBruODneOCpOODs+ODiOmChOWFg++8iVxyXG5cclxuICAgICAgICAgICAgICBsZXQgY291cG9uX2NkID0gY3J5cHRvLnJhbmRvbUJ5dGVzKDgpLnRvU3RyaW5nKCdiYXNlNjQnKS5zdWJzdHJpbmcoMCwxMSk7XHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb3Vwb25fbmFtZSA9IGAke3JlY29yZC5uYW1lMDF9ICR7cmVjb3JkLm5hbWUwMn0g5qeYIOOBlOWEquW+heOCr+ODvOODneODsyDkvJrlk6Hnlarlj7c6JHtyZWNvcmQuY3VzdG9tZXJfaWR9YDtcclxuXHJcbiAgICAgICAgICAgICAgbGV0IGRpc2NvdW50X3ByaWNlID0gcmVjb3JkLnBvaW50ICsgNTAwO1xyXG5cclxuICAgICAgICAgICAgICB0cnkge1xyXG4gICAgICAgICAgICAgICAgbGV0IHJlcyA9IGF3YWl0IGRzdERiLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAgICAgICAgICAgICAncGxnX2NvdXBvbicsIHtcclxuICAgICAgICAgICAgICAgICAgICBjb3Vwb25faWQ6IG51bGwsXHJcbiAgICAgICAgICAgICAgICAgICAgY291cG9uX2NkOiBjb3Vwb25fY2QsXHJcbiAgICAgICAgICAgICAgICAgICAgY291cG9uX3R5cGU6IDMsIC8vIOWFqOWVhuWTgVxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl9uYW1lOiBjb3Vwb25fbmFtZSxcclxuICAgICAgICAgICAgICAgICAgICBkaXNjb3VudF90eXBlOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl91c2VfdGltZTogMSxcclxuICAgICAgICAgICAgICAgICAgICBjb3Vwb25fcmVsZWFzZTogMSxcclxuICAgICAgICAgICAgICAgICAgICBkaXNjb3VudF9wcmljZTogZGlzY291bnRfcHJpY2UsXHJcbiAgICAgICAgICAgICAgICAgICAgZGlzY291bnRfcmF0ZTogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBlbmFibGVfZmxhZzogMSxcclxuICAgICAgICAgICAgICAgICAgICBjb3Vwb25fbWVtYmVyOiAxLFxyXG4gICAgICAgICAgICAgICAgICAgIGNvdXBvbl9sb3dlcl9saW1pdDogbnVsbCxcclxuICAgICAgICAgICAgICAgICAgICBhdmFpbGFibGVfZnJvbV9kYXRlOiAnMjAxOC0wNC0wMiAwMDowMDowMCcsXHJcbiAgICAgICAgICAgICAgICAgICAgYXZhaWxhYmxlX3RvX2RhdGU6ICcyMDE5LTA1LTAyIDAwOjAwOjAwJyxcclxuICAgICAgICAgICAgICAgICAgICBkZWxfZmxnOiAwXHJcbiAgICAgICAgICAgICAgICAgIH0se1xyXG4gICAgICAgICAgICAgICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgICAgICAgICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgICk7XHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuICAgICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0sXHJcbiAgICAgICAgICBhc3luYyAoZSkgPT4ge1xyXG4gICAgICAgICAgICByZXBvcnQuaUVycm9yKGUpO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIClcclxuICAgICAgfSk7XHJcblxyXG4gICAgcmV0dXJuIHJlcG9ydC5wdWJsaXNoKCk7XHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgJ2N1YmVtaWcuc2VydmVyQ2hlY2snIChwcm9maWxlKSB7XHJcblxyXG4gICAgbGV0IGRiID0gbmV3IE15U1FMKHByb2ZpbGUpO1xyXG4gICAgbGV0IHJlcyA9IGF3YWl0IGRiLnF1ZXJ5KCdTSE9XIERBVEFCQVNFUycpO1xyXG4gICAgcmV0dXJuIHJlcztcclxuICB9XHJcblxyXG59KTsiLCJpbXBvcnQgeyBNb25nb0NvbGxlY3Rpb24gfSBmcm9tIFwiLi4vLi4vaW1wb3J0cy91dGlsL21vbmdvXCI7XHJcblxyXG5sZXQgdGFnID0gJ2psaW5lLmNvbGxlY3Rpb24nO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICBhc3luYyBbYCR7dGFnfS5maW5kYF0oIHBsdWcsIHF1ZXJ5PXt9LCBwcm9qZWN0aW9uPXt9ICkge1xyXG5cclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnKTtcclxuICAgIHJldHVybiBhd2FpdCBjb2xsLmZpbmQocXVlcnkse3Byb2plY3Rpb246cHJvamVjdGlvbn0pLnRvQXJyYXkoKTtcclxuXHJcbiAgfSxcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uYWdncmVnYXRlYF0oIHBsdWcsIHF1ZXJ5PXt9ICkge1xyXG5cclxuICAgIGxldCBjb2xsID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnKTtcclxuICAgIHJldHVybiBhd2FpdCBjb2xsLmFnZ3JlZ2F0ZShxdWVyeSkudG9BcnJheSgpO1xyXG5cclxuICB9XHJcblxyXG59KTsiLCJpbXBvcnQgSXRlbUNvbnRyb2xsZXIgZnJvbSBcIi4uLy4uL2ltcG9ydHMvY29udHJvbGxlci9pdGVtc1wiO1xyXG5cclxubGV0IHRhZyA9ICdqbGluZS5pdGVtcyc7XHJcblxyXG5NZXRlb3IubWV0aG9kcyh7XHJcblxyXG4gIC8qKlxyXG4gICAqIOaMh+WumuOBleOCjOOBn+adoeS7tuOBq+S4gOiHtOOBmeOCi2l0ZW1z44Kz44Os44Kv44K344On44Oz5YaF44Gu44OJ44Kt44Ol44Oh44Oz44OI44Gr44CBXHJcbiAgICog44Ki44OD44OX44Ot44O844OJ5riI44G/55S75YOP44KS6Zai6YCj5LuY44GR44G+44GZ44CCXHJcbiAgICogQHBhcmFtICBcclxuICAgKi9cclxuICBhc3luYyBbYCR7dGFnfS5zZXRJbWFnZWBdKCBwbHVnLCB1cGxvYWRJZCwgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwgKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpO1xyXG4gICAgbGV0IHVwbG9hZGVkID0gYXdhaXQgaXRlbWNvbi5zZXRJbWFnZSggdXBsb2FkSWQsIG1vZGVsLCBjbGFzczEsIGNsYXNzMiApO1xyXG4gICAgcmV0dXJuIHVwbG9hZGVkO1xyXG4gIH0sXHJcblxyXG4gIC8qKlxyXG4gICAqIOOCouOCpOODhuODoOaDheWgseODh+ODvOOCv+ODmeODvOOCueOBrueUu+WDj+eZu+mMsuOCkuWJiumZpOOBmeOCi++8iOeUu+WDj+iHquS9k+OBr+WJiumZpOOBl+OBquOBhO+8iVxyXG4gICAqL1xyXG4gIGFzeW5jIFtgJHt0YWd9LmNsZWFuSW1hZ2VgXSggcGx1ZywgbW9kZWwsIGNsYXNzMSA9IG51bGwsIGNsYXNzMiA9IG51bGwgKSB7XHJcbiAgICBsZXQgaXRlbWNvbiA9IG5ldyBJdGVtQ29udHJvbGxlcigpO1xyXG4gICAgYXdhaXQgaXRlbWNvbi5pbml0KHBsdWcpO1xyXG4gICAgYXdhaXQgaXRlbWNvbi5jbGVhbkltYWdlKCBtb2RlbCwgY2xhc3MxLCBjbGFzczIgKTtcclxuICB9XHJcblxyXG59KTsiLCJpbXBvcnQgUmVwb3J0IGZyb20gJy4uL2ltcG9ydHMvdXRpbC9yZXBvcnQnO1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvREJGaWx0ZXJcclxufSBmcm9tICcuLi9pbXBvcnRzL2NvcmUvZGJmaWx0ZXInO1xyXG5pbXBvcnQge1xyXG4gIEN1YmUzQXBpXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9jb3JlL2N1YmUzYXBpJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCc7XHJcbmltcG9ydCBJdGVtQ29udHJvbGxlciBmcm9tICcuLi9pbXBvcnRzL2NvbnRyb2xsZXIvaXRlbXMnO1xyXG5cclxubGV0IHRhZyA9ICdjdWJlJztcclxuXHJcbk1ldGVvci5tZXRob2RzKHtcclxuXHJcbiAgLy9cclxuICAvLyDllYblk4Hmg4XloLHmm7TmlrBcclxuXHJcbiAgYXN5bmMgW2Ake3RhZ30uZXhoaWJJdGVtYF0oY29uZmlnKSB7XHJcblxyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpO1xyXG4gICAgbGV0IHRhcmdldERCID0gbmV3IE15U1FMKGNvbmZpZy5jdWJlM0RCKTtcclxuICAgIGxldCBhcGkgPSBuZXcgQ3ViZTNBcGkodGFyZ2V0REIpO1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0VDQ1VCRTPjgbjjga7llYblk4HnmbvpjLInLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICAgJ0lOU0VSVCc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb247XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gSXRlbUNvbnRyb2xsZXIuaXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKTtcclxuXHJcbiAgICAgICAgICAgICAgICBsZXQgaW5zZXJ0UmVzID0gYXdhaXQgYXBpLnByb2R1Y3RDcmVhdGUoY3ViZUl0ZW0pO1xyXG5cclxuICAgICAgICAgICAgICAgIC8vIGl0ZW0g44OH44O844K/44OZ44O844K544G444Gu55m76YyyXHJcbiAgICAgICAgICAgICAgICBhd2FpdCBjb2wudXBkYXRlKHtcclxuICAgICAgICAgICAgICAgICAgX2lkOiBpdGVtLl9pZFxyXG4gICAgICAgICAgICAgICAgfSwge1xyXG4gICAgICAgICAgICAgICAgICAkc2V0OiB7XHJcbiAgICAgICAgICAgICAgICAgICAgJ21hbGwuc2hhcmFrdVNob3AnOiBpbnNlcnRSZXMucmVzXHJcbiAgICAgICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pU3VjY2VzcygpO1xyXG5cclxuICAgICAgICAgICAgICB9IGNhdGNoIChlKSB7XHJcblxyXG4gICAgICAgICAgICAgICAgcmVwb3J0LmlFcnJvcihlKTtcclxuXHJcbiAgICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICB9LFxyXG4gICAgICAgICAgYXN5bmMgKGUpID0+IHtcclxuICAgICAgICAgICAgdGhyb3cgZVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgIH0pO1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ0VDQ1VCRTPllYblk4Hmg4XloLHjga7mm7TmlrAnLFxyXG4gICAgICBhc3luYyAoKSA9PiB7XHJcbiAgICAgICAgcmV0dXJuIGF3YWl0IGZpbHRlci5mb3JlYWNoKHtcclxuICAgICAgICAgICAgJ1VQREFURSc6IGFzeW5jIChpdGVtLCBjb250ZXh0KSA9PiB7XHJcblxyXG4gICAgICAgICAgICAgIGxldCBjb2wgPSBjb250ZXh0LmNvbGxlY3Rpb247XHJcblxyXG4gICAgICAgICAgICAgIHRyeSB7XHJcblxyXG4gICAgICAgICAgICAgICAgbGV0IGN1YmVJdGVtID0gSXRlbUNvbnRyb2xsZXIuaXRlbUN1YmUzKGNvbmZpZy5jcmVhdG9yX2lkLCBpdGVtKTtcclxuXHJcbiAgICAgICAgICAgICAgICBhd2FpdCBhcGkucHJvZHVjdEltYWdlVXBkYXRlKGN1YmVJdGVtKTtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VXBkYXRlKGN1YmVJdGVtKTtcclxuICAgICAgICAgICAgICAgIGF3YWl0IGFwaS5wcm9kdWN0VGFnVXBkYXRlKGN1YmVJdGVtKTtcclxuXHJcbiAgICAgICAgICAgICAgICByZXBvcnQuaVN1Y2Nlc3MoKTtcclxuXHJcbiAgICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG5cclxuICAgICAgICAgICAgICAgIHJlcG9ydC5pRXJyb3IoZSk7XHJcblxyXG4gICAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSxcclxuICAgICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICAgIHRocm93IGVcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKTtcclxuXHJcbiAgfVxyXG5cclxufSk7IiwiaW1wb3J0IFJlcG9ydCBmcm9tICcuLi9pbXBvcnRzL3V0aWwvcmVwb3J0JztcclxuaW1wb3J0IHtcclxuICBNb25nb0RCRmlsdGVyXHJcbn0gZnJvbSAnLi4vaW1wb3J0cy9jb3JlL2RiZmlsdGVyJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL2ltcG9ydHMvdXRpbC9teXNxbCc7XHJcblxyXG5sZXQgdGFnID0gJ3Rvb2wnO1xyXG5cclxuTWV0ZW9yLm1ldGhvZHMoe1xyXG5cclxuICAvL1xyXG4gIC8vIOWVhuWTgeaDheWgseabtOaWsFxyXG5cclxuICBhc3luYyBbYCR7dGFnfS50ZXN0YF0oY29uZmlnKSB7XHJcblxyXG4gICAgLy8g44Kv44Op44Kk44Ki44Oz44OI44GM5Y+C54Wn44GZ44KL44Gf44KB44Gu5Yem55CG57WQ5p6c5L2c5oiQ44Kq44OW44K444Kn44Kv44OIXHJcbiAgICBsZXQgcmVwb3J0ID0gbmV3IFJlcG9ydCgpO1xyXG5cclxuICAgIGxldCBmaWx0ZXIgPSBuZXcgTW9uZ29EQkZpbHRlcihjb25maWcuaXRlbXNEQiwgY29uZmlnLnByb2ZpbGUpO1xyXG5cclxuICAgIGF3YWl0IHJlcG9ydC5waGFzZShcclxuICAgICAgJ+ODleOCo+ODq+OCv+ODvOODhuOCueODiCcsXHJcbiAgICAgIGFzeW5jICgpID0+IHtcclxuICAgICAgICByZXR1cm4gYXdhaXQgZmlsdGVyLmZvcmVhY2goXHJcbiAgICAgICAgICB7fSxcclxuICAgICAgICAgIGFzeW5jIChlKSA9PiB7XHJcbiAgICAgICAgICAgIHRocm93IGVcclxuICAgICAgICAgIH0pO1xyXG4gICAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gcmVwb3J0LnB1Ymxpc2goKTtcclxuXHJcbiAgfVxyXG5cclxufSk7IiwiaW1wb3J0ICcuLi9pbXBvcnRzL2NvbGxlY3Rpb24vY29uZmlncyc7XHJcblxyXG5pbXBvcnQgJy4vcm91dGUvdXBsb2FkL2ltYWdlJzsiLCJpbXBvcnQgeyBNb25nbyB9IGZyb20gJ21ldGVvci9tb25nbyc7XHJcbiBcclxuZXhwb3J0IGNvbnN0IENvbmZpZ3MgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignY29uZmlncycse2lkR2VuZXJhdGlvbjonTU9OR08nfSk7XHJcblxyXG4vLyBNZXRlb3IubWV0aG9kcyh7IFxyXG4vLyAgIGFzeW5jICdteXNxbFNlcnZlcnMuaW5zZXJ0JyAoIG5ld1NlcnZlciApe1xyXG4vLyAgICAgcmV0dXJuIGF3YWl0IE15c3FsU2VydmVycy5pbnNlcnQobmV3U2VydmVyKTtcclxuLy8gICB9XHJcbi8vIH0pO1xyXG4iLCJpbXBvcnQge1xyXG4gIE1vbmdvXHJcbn0gZnJvbSAnbWV0ZW9yL21vbmdvJztcclxuaW1wb3J0IE15U1FMIGZyb20gJy4uL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1ldGVvclxyXG59IGZyb20gJ21ldGVvci9tZXRlb3InO1xyXG5cclxuLy8gdmFsaWRhdGUgb2JqZWN0cyAmIGZpbHRlciBhcnJheXMgd2l0aCBtb25nb2RiIHF1ZXJpZXNcclxuaW1wb3J0IHNpZnQgZnJvbSAnc2lmdCc7XHJcbmltcG9ydCBtb2JqZWN0IGZyb20gJ21vbmdvb2JqZWN0JztcclxuaW1wb3J0IHsgR3JvdXBCYXNlIH0gZnJvbSAnLi9ncm91cHMnO1xyXG5cclxuY29uc3QgRmlsdGVycyA9IG5ldyBNb25nby5Db2xsZWN0aW9uKCdmaWx0ZXJzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBGaWx0ZXIgZXh0ZW5kcyBHcm91cEJhc2Uge1xyXG5cclxuICBjb25zdHJ1Y3RvcihmaWx0ZXJJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gRmlsdGVycy5maW5kT25lKHtcclxuICAgICAgX2lkOiBmaWx0ZXJJZFxyXG4gICAgfSk7XHJcblxyXG4gICAgc3VwZXIocHJvZmlsZSk7XHJcblxyXG4gICAgbGV0IHBsdWcgPSB0aGlzLmdldFBsdWcoKTtcclxuXHJcbiAgICBzd2l0Y2ggKHBsdWcudHlwZSkge1xyXG5cclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jICggb25SZXN1bHQgPSAocmVjb3JkKT0+e30sIG9uRXJyb3IgPSAoZSk9Pnt9ICkgPT4ge1xyXG4gICAgICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gO1xyXG4gICAgICAgICAgcmV0dXJuIGF3YWl0IHRoaXMubXlzcWwuc3RyZWFtaW5nUXVlcnkoc3FsLCBvblJlc3VsdCwgb25FcnJvcik7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuXHJcbiAgICAgIGRlZmF1bHQ6XHJcbiAgICAgICAgdGhyb3cgbmV3IEVycm9yKCdpbnZhbGlkIHBsYXRmb3JtIHR5cGUnKTtcclxuXHJcbiAgICB9XHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge3sgZmlsdGVyVHlwZTogYXN5bmMgKHJlY29yZCApID0+IHt9IH19IGNhbGxiYWNrIGN1c3RvbSBmdW5jdGlvbiBmb3IgZWFjaCBtZW1iZXJzXHJcbiAgICovXHJcbiAgYXN5bmMgZm9yZWFjaChjYWxsYmFja3MgPSB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gdGhpcy5nZXRQcm9maWxlKCk7XHJcblxyXG4gICAgLy8gbWlzYyDjg5XjgqPjg6vjgr/jg7zjgpLmnKvlsL7jgavoh6rli5Xov73liqBcclxuICAgIHByb2ZpbGUuZmlsdGVycy5wdXNoKHtcclxuICAgICAgdHlwZTogJ21pc2MnLFxyXG4gICAgICBxdWVyeToge31cclxuICAgIH0pXHJcblxyXG4gICAgbGV0IGNvdW50ID0ge307XHJcbiAgICBmb3IoIGxldCBmaWx0ZXIgb2YgcHJvZmlsZS5maWx0ZXJzICl7XHJcbiAgICAgIGNvdW50W2ZpbHRlci50eXBlXSA9IHtcclxuICAgICAgICBxdWVyeTogZmlsdGVyLnF1ZXJ5LFxyXG4gICAgICAgIGNvdW50OiAwXHJcbiAgICAgIH07XHJcbiAgICB9XHJcblxyXG4gICAgYXdhaXQgdGhpcy5pbXBvcnQoXHJcbiAgICAgIGFzeW5jIChyZWNvcmQpPT57XHJcbiAgICAgICAgZm9yKCBsZXQgZmlsdGVyIG9mIHByb2ZpbGUuZmlsdGVycyApe1xyXG4gICAgICAgICAgbGV0IHF1ZXJ5ID0gbW9iamVjdC51bmVzY2FwZShmaWx0ZXIucXVlcnkpO1xyXG4gICAgICAgICAgbGV0IGV4YW0gPSBzaWZ0KCBxdWVyeSApO1xyXG4gICAgICAgICAgaWYoIGV4YW0ocmVjb3JkKSApe1xyXG4gICAgICAgICAgICBjb3VudFtmaWx0ZXIudHlwZV0uY291bnQrKztcclxuICAgICAgICAgICAgaWYoIHR5cGVvZiBjYWxsYmFja3NbZmlsdGVyLnR5cGVdICE9PSAndW5kZWZpbmVkJyl7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2tzW2ZpbHRlci50eXBlXShyZWNvcmQpO1xyXG4gICAgICAgICAgICB9XHJcbiAgICAgICAgICAgIGJyZWFrO1xyXG4gICAgICAgICAgfVxyXG4gICAgICAgIH1cclxuICAgICAgfSxcclxuICAgICAgb25FcnJvclxyXG4gICAgKTtcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50O1xyXG5cclxuICB9XHJcblxyXG59XHJcbiIsImltcG9ydCB7XHJcbiAgTW9uZ29cclxufSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG5pbXBvcnQgTXlTUUwgZnJvbSAnLi4vdXRpbC9teXNxbCc7XHJcbmltcG9ydCB7XHJcbiAgTWV0ZW9yXHJcbn0gZnJvbSAnbWV0ZW9yL21ldGVvcic7XHJcblxyXG5jb25zdCBHcm91cHMgPSBuZXcgTW9uZ28uQ29sbGVjdGlvbignZ3JvdXBzJywge1xyXG4gIGlkR2VuZXJhdGlvbjogJ01PTkdPJ1xyXG59KTtcclxuXHJcbmV4cG9ydCBjbGFzcyBHcm91cEJhc2Uge1xyXG5cclxuICBwcm9maWxlO1xyXG5cclxuICBjb25zdHJ1Y3Rvcihwcm9maWxlKSB7XHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogZ2V0cyAnUGx1Zycgd2l0Y2ggaXMgYSBzZXQgb2YgcHJvcGVydGllcyBuZWVkZWRcclxuICAgKiB3aGVuIGNvbm5lY3QgdG8gc29tZSBwbGF0Zm9ybXNcclxuICAgKiB0byBnZXQgZGF0YXMoTWVtYmVycyBvZiB0aGUgR3JvdXApXHJcbiAgICovXHJcbiAgZ2V0UGx1ZygpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGUucGxhdGZvcm1QbHVnO1xyXG4gIH1cclxuXHJcbiAgZ2V0UHJvZmlsZSgpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICBmb3JlYWNoKGNhbGxiYWNrID0gYXN5bmMgKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSBhc3luYyAoZSkgPT4ge30pIHt9O1xyXG5cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIEdyb3VwIGV4dGVuZHMgR3JvdXBCYXNlIHtcclxuXHJcbiAgY29uc3RydWN0b3IoZ3JvdXBJZCkge1xyXG5cclxuICAgIGxldCBwcm9maWxlID0gR3JvdXBzLmZpbmRPbmUoe1xyXG4gICAgICBfaWQ6IGdyb3VwSWRcclxuICAgIH0pO1xyXG5cclxuICAgIHN1cGVyKHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBwbHVnID0gdGhpcy5nZXRQbHVnKCk7XHJcblxyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSAnbXlzcWwnOlxyXG4gICAgICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwocGx1Zy5jcmVkKTtcclxuICAgICAgICB0aGlzLmltcG9ydCA9IGFzeW5jIChkb2MpID0+IHtcclxuICAgICAgICAgIGxldCBzcWwgPSBgU0VMRUNUICogRlJPTSAke3BsdWcudGFibGV9IFdIRVJFIFxcYCR7ZG9jLmtleX1cXGAgPSBcIiR7ZG9jLmlkfVwiYDtcclxuICAgICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnF1ZXJ5KHNxbCk7XHJcbiAgICAgICAgfTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgZGVmYXVsdDpcclxuICAgICAgICB0aHJvdyBuZXcgRXJyb3IoJ2ludmFsaWQgZ3JvdXAgdHlwZScpO1xyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG5cclxuICAvKipcclxuICAgKiB0cmFjZXMgbWVtYmVycyBvZiB0aGUgZ3JvdXBcclxuICAgKiBAcGFyYW0ge2FzeW5jIChyZWNvcmQpPT52b2lkfSBjYWxsYmFjayBjdXN0b20gZnVuY3Rpb24gZm9yIGVhY2ggbWVtYmVyc1xyXG4gICAqL1xyXG4gIGZvcmVhY2goY2FsbGJhY2sgPSBhc3luYyAocmVjb3JkKSA9PiB7fSwgb25FcnJvciA9IGFzeW5jIChlKSA9PiB7fSkge1xyXG5cclxuICAgIGxldCBjdXIgPSBHcm91cHMuZmluZCh7XHJcbiAgICAgIGdyb3VwSWQ6IHRoaXMucHJvZmlsZS5faWRcclxuICAgIH0sIHtcclxuICAgICAgZmllbGRzOiB7XHJcbiAgICAgICAgX2lkOiAwLFxyXG4gICAgICAgIGlkOiAxLFxyXG4gICAgICAgIGtleTogMVxyXG4gICAgICB9XHJcbiAgICB9KTtcclxuXHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgIChyZXNvbHZlLCByZWplY3QpID0+IHtcclxuICAgICAgICBcclxuICAgICAgICBjdXIuZm9yRWFjaChcclxuICAgICAgICAgIGFzeW5jIChkb2MsIGluZGV4KSA9PiB7XHJcbiAgICAgICAgICAgIHRyeSB7XHJcbiAgICAgICAgICAgICAgbGV0IHJlY29yZCA9IGF3YWl0IHRoaXMuaW1wb3J0KGRvYyk7XHJcbiAgICAgICAgICAgICAgYXdhaXQgY2FsbGJhY2socmVjb3JkKTtcclxuICAgICAgICAgICAgfSBjYXRjaCAoZSkge1xyXG4gICAgICAgICAgICAgIG9uRXJyb3IoZSk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgICAgaWYgKGluZGV4ICsgMSA9PT0gY3VyLmNvdW50KCkpIHtcclxuICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH0pO1xyXG5cclxuICAgICAgfVxyXG4gICAgKS5jYXRjaChcclxuICAgICAgKGUpID0+IHtcclxuICAgICAgICB0aHJvdyBlO1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICB9XHJcblxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tICdtZXRlb3IvbW9uZ28nO1xyXG4gXHJcbmV4cG9ydCBjb25zdCBVcGxvYWRzID0gbmV3IE1vbmdvLkNvbGxlY3Rpb24oJ3VwbG9hZHMnLHtpZEdlbmVyYXRpb246J01PTkdPJ30pO1xyXG5cclxuIiwiaW1wb3J0IHsgTW9uZ29Db2xsZWN0aW9uIH0gZnJvbSBcIi4uL3V0aWwvbW9uZ29cIjtcclxuaW1wb3J0IHsgVXBsb2FkcyB9IGZyb20gXCIuLi9jb2xsZWN0aW9uL3VwbG9hZHNcIjtcclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIEl0ZW1Db250cm9sbGVye1xyXG5cclxuICBhc3luYyBpbml0KHBsdWcpe1xyXG5cclxuICAgIHBsdWcuY29sbGVjdGlvbiA9ICdpdGVtcyc7XHJcbiAgICB0aGlzLkl0ZW1zID0gYXdhaXQgTW9uZ29Db2xsZWN0aW9uLmdldChwbHVnKTtcclxuXHJcbiAgfVxyXG5cclxuICAvKipcclxuICAgKiBcclxuICAgKiDmjIflrprjgZXjgozjgZ/mnaHku7bjgavkuIDoh7TjgZnjgotpdGVtc+WGheOBruODieOCreODpeODoeODs+ODiOOBq+OAgVxyXG4gICAqIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OCkumWoumAo+S7mOOBkeOCi+OAglxyXG4gICAqIFxyXG4gICAqIOODoeODvOOCq+ODvOODouODh+ODq+OBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqIFxyXG4gICAqIOeJueWumuOBruWxnuaAp++8iOOCq+ODqeODvOOBquOBqe+8ieOBq+WFsemAmuOBrueUu+WDj+OCkuS4gOaLrOOBp+mWoumAo+S7mOOBkeOBn+OBhOWgtOWQiOOAgVxyXG4gICAqIGNsYXNzMeOBq+WApOOCkuaMh+WumuOBl+OAgWNsYXNzMuW8leaVsOOCkuaMh+WumuOBm+OBmuOBq+Wun+ihjOOBmeOCi+OAglxyXG4gICAqIOOCguOBl2NsYXNzMuOBruOBv+aMh+WumuOBl+OBn+OBhOWgtOWQiOOBr2NsYXNzMeOBq251bGzjgpLmjIflrprjgZnjgovjgIJcclxuICAgKiBcclxuICAgKiDkvovvvJpKSy0xMDDjga5CTEFDS+OBruWVhuWTgeeUu+WDj+OCklxyXG4gICAqIOOBmeOBueOBpuOBruOCteOCpOOCuu+8iFMsTSxMLFhMLDJYTCwzWEwsNFhM4oCm77yJ44Gr6Zai6YCj5LuY44GR44KL5aC05ZCIXHJcbiAgICogc2V0SW1hZ2UoIHVwbG9hZElkLCAnSkstMTAwJywgJ0JMQUNLJyApO1xyXG4gICAqIFxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB1cGxvYWRJZCDkuIDlm57jga7jgqLjg4Pjg5fjg63jg7zjg4nnlLvlg4/jgpLmnZ/jga3jgabjgYTjgotJROOAgm1ldGVvcuODh+ODvOOCv+ODmeODvOOCueOAgVVwbG9hZHPjgrPjg6zjgq/jgrfjg6fjg7PlhoXjg4njgq3jg6Xjg6Hjg7Pjg4jjga51cGxvYWRJZOODl+ODreODkeODhuOCo1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBtb2RlbCDjg6Hjg7zjgqvjg7zjg6Ljg4fjg6tcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MxIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBjbGFzczIg44Kr44Op44O844CB44K144Kk44K644Gq44Gp44Gu5bGe5oCnXHJcbiAgICovXHJcbiAgYXN5bmMgc2V0SW1hZ2UoIHVwbG9hZElkLCBtb2RlbCwgY2xhc3MxID0gbnVsbCwgY2xhc3MyID0gbnVsbCApe1xyXG5cclxuICAgIC8vIOOCouODg+ODl+ODreODvOODiea4iOOBv+eUu+WDj+OBruaDheWgseWPluW+l1xyXG4gICAgbGV0IGltYWdlcyA9IFVwbG9hZHMuZmluZCh7dXBsb2FkSWQ6dXBsb2FkSWR9KS5mZXRjaCgpLm1hcCggdiA9PiB2LnVwbG9hZGVkRmlsZU5hbWUgKTtcclxuXHJcbiAgICAvLyDmpJzntKLmnaHku7bjga7ntYTjgb/nq4vjgaZcclxuICAgIGxldCBmaWx0ZXIgPSB7fTtcclxuICAgIGZpbHRlci5tb2RlbCA9IG1vZGVsO1xyXG4gICAgaWYoIGNsYXNzMSApIGZpbHRlci5jbGFzczFfdmFsdWUgPSBjbGFzczE7XHJcbiAgICBpZiggY2xhc3MyICkgZmlsdGVyLmNsYXNzMl92YWx1ZSA9IGNsYXNzMjtcclxuICAgIFxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMuSXRlbXMudXBkYXRlTWFueShcclxuICAgICAgZmlsdGVyLFxyXG4gICAgICB7XHJcbiAgICAgICAgJHB1c2g6e1xyXG4gICAgICAgICAgaW1hZ2VzOiB7XHJcbiAgICAgICAgICAgICRlYWNoOiBpbWFnZXNcclxuICAgICAgICAgIH1cclxuICAgICAgICB9XHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgLy8g55m76Yyy44GX44Gf55S75YOP44OV44Kh44Kk44Or5ZCN5LiA6KanXHJcbiAgICByZXR1cm4gaW1hZ2VzO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICog5oyH5a6a44GV44KM44Gf5p2h5Lu244Gr5LiA6Ie044GZ44KLaXRlbXPlhoXjga7jg4njgq3jg6Xjg6Hjg7Pjg4jjgavnmbvpjLLjgZXjgozjgabjgYTjgovnlLvlg4/mg4XloLHjgpLliYrpmaTjgZnjgovjgIJcclxuICAgKiBcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gbW9kZWwg44Oh44O844Kr44O844Oi44OH44OrXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IGNsYXNzMSDjgqvjg6njg7zjgIHjgrXjgqTjgrrjgarjganjga7lsZ7mgKdcclxuICAgKiBAcGFyYW0ge1N0cmluZ30gY2xhc3MyIOOCq+ODqeODvOOAgeOCteOCpOOCuuOBquOBqeOBruWxnuaAp1xyXG4gICAqL1xyXG4gIGFzeW5jIGNsZWFuSW1hZ2UoIG1vZGVsLCBjbGFzczEgPSBudWxsLCBjbGFzczIgPSBudWxsICl7XHJcblxyXG4gICAgLy8g5qSc57Si5p2h5Lu244Gu57WE44G/56uL44GmXHJcbiAgICBsZXQgZmlsdGVyID0ge307XHJcbiAgICBmaWx0ZXIubW9kZWwgPSBtb2RlbDtcclxuICAgIGlmKCBjbGFzczEgKSBmaWx0ZXIuY2xhc3MxX3ZhbHVlID0gY2xhc3MxO1xyXG4gICAgaWYoIGNsYXNzMiApIGZpbHRlci5jbGFzczJfdmFsdWUgPSBjbGFzczI7XHJcbiAgICBcclxuICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLkl0ZW1zLnVwZGF0ZU1hbnkoXHJcbiAgICAgIGZpbHRlcixcclxuICAgICAge1xyXG4gICAgICAgICRzZXQ6e1xyXG4gICAgICAgICAgaW1hZ2VzOiBbXVxyXG4gICAgICAgIH1cclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgfVxyXG5cclxuICBzdGF0aWMgaXRlbUN1YmUzKGNyZWF0b3JfaWQsIGl0ZW0pe1xyXG4gICAgcmV0dXJuIG5ldyBpdGVtQ3ViZTMoY3JlYXRvcl9pZCwgaXRlbSk7XHJcbiAgfVxyXG5cclxufVxyXG5cclxuY2xhc3MgaXRlbUN1YmUzIHtcclxuXHJcbiAgY29uc3RydWN0b3IoIGNyZWF0b3JfaWQsIGl0ZW0pe1xyXG5cclxuICAgIC8vIHByb2R1Y3RfaWRcclxuICAgIGxldCBwcm9kdWN0X2lkID0gJ05VTEwnO1xyXG4gICAgaWYoIGl0ZW0uc2hhcmFrdVNob3AgKXtcclxuICAgICAgcHJvZHVjdF9pZCA9IGl0ZW0uc2hhcmFrdVNob3AucHJvZHVjdF9pZDtcclxuICAgIH1cclxuXHJcbiAgICAvLyDkuIvoqJjjga7lvaLlvI/jgpLkvZzjgotcclxuICAgIC8vIOODoeODvOOCq+ODvOOCs+ODvOODiS/lsZ7mgKcx77yI44Kr44Op44O844Gq44Gp77yJL+WxnuaApzLvvIjjgrXjgqTjgrrjgarjganvvIlcclxuICAgIGxldCBtb2RlbENsYXNzID0gW107XHJcbiAgICBpZihpdGVtLm1vZGVsKSBtb2RlbENsYXNzLnB1c2goaXRlbS5tb2RlbCk7XHJcbiAgICBpZihpdGVtLmNsYXNzMV92YWx1ZSkgbW9kZWxDbGFzcy5wdXNoKGl0ZW0uY2xhc3MxX3ZhbHVlKTtcclxuICAgIGlmKGl0ZW0uY2xhc3MyX3ZhbHVlKSBtb2RlbENsYXNzLnB1c2goaXRlbS5jbGFzczJfdmFsdWUpO1xyXG5cclxuICAgIC8vIOWVhuWTgeeoruWIpeOCkuWJsuOCiuW9k+OBpuOCi1xyXG4gICAgbGV0IHByb2R1Y3RfdHlwZV9pZDtcclxuICAgIHN3aXRjaChpdGVtLmRlbGl2ZXJ5KXtcclxuICAgICAgY2FzZSAn5a6F6YWN5L6/JzogcHJvZHVjdF90eXBlX2lkID0gMTsgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6IHByb2R1Y3RfdHlwZV9pZCA9MjsgYnJlYWs7XHJcbiAgICAgIGRlZmF1bHQgOiBwcm9kdWN0X3R5cGVfaWQgPSAxOyBicmVhaztcclxuICAgIH1cclxuXHJcbiAgICAvLyDllYblk4Hjgr/jgrDjgpLoqK3lrprjgZnjgotcclxuICAgIGxldCB0YWdzID0gW107XHJcbiAgICBzd2l0Y2goaXRlbS5kZWxpdmVyeSl7XHJcbiAgICAgIGNhc2UgJ+WuhemFjeS+vyc6IHRhZ3MucHVzaCh7dGFnOjQsc2V0Oidvbid9LHt0YWc6NSxzZXQ6J29mZid9KTsgYnJlYWs7XHJcbiAgICAgIGNhc2UgJ+OChuOBhuODkeOCseODg+ODiCc6IHRhZ3MucHVzaCh7dGFnOjUsc2V0Oidvbid9LHt0YWc6NCxzZXQ6J29mZid9KTsgYnJlYWs7XHJcbiAgICB9XHJcblxyXG4gICAgLy8g5ZWG5ZOB44OH44O844K/44KS5L2c44KLXHJcbiAgICBsZXQgZGF0YSA9IHtcclxuICAgICAgcHJvZHVjdF9pZDogcHJvZHVjdF9pZCxcclxuICAgICAgbmFtZTogYCR7bW9kZWxDbGFzcy5qb2luKCcvJyl9ICR7aXRlbS5uYW1lfSAke2l0ZW0uamFuX2NvZGV9YCxcclxuICAgICAgZGVzY3JpcHRpb25fZGV0YWlsOiBpdGVtLmRlc2NyaXB0aW9uLFxyXG4gICAgICBwcm9kdWN0X2NvZGU6IGl0ZW0ubW9kZWwsXHJcbiAgICAgIHByaWNlMDE6IGl0ZW0ucmV0YWlsX3ByaWNlLFxyXG4gICAgICBwcmljZTAyOiBpdGVtLnNhbGVzX3ByaWNlLFxyXG4gICAgICBpbWFnZXM6IGl0ZW0uaW1hZ2VzLFxyXG4gICAgICBwcm9kdWN0X3R5cGVfaWQ6IHByb2R1Y3RfdHlwZV9pZCxcclxuICAgICAgdGFnczogdGFnc1xyXG4gICAgfTtcclxuXHJcbiAgICBPYmplY3QuYXNzaWduKCB0aGlzLCB7Y3JlYXRvcl9pZDogY3JlYXRvcl9pZH0gKTtcclxuICAgIE9iamVjdC5hc3NpZ24oIHRoaXMsIGRhdGEgKTtcclxuICAgIE9iamVjdC5hc3NpZ24oIHRoaXMsIGl0ZW0ubWFsbC5zaGFyYWt1U2hvcCk7XHJcblxyXG4gIH1cclxufSIsImltcG9ydCBNeVNRTCBmcm9tICcuLi8uLi9pbXBvcnRzL3V0aWwvbXlzcWwnO1xyXG5pbXBvcnQge1xyXG4gIE1vbmdvQ2xpZW50XHJcbn0gZnJvbSAnbW9uZ29kYic7XHJcblxyXG5leHBvcnQgY2xhc3MgQ3ViZTNBcGkge1xyXG5cclxuICBjb25zdHJ1Y3RvcihteXNxbCA9IG5ldyBNeVNRTCgpKSB7XHJcbiAgICB0aGlzLm15c3FsXyA9IG15c3FsO1xyXG4gIH1cclxuXHJcblxyXG4gIGFzeW5jIHByb2R1Y3RUYWdVcGRhdGUoZGF0YSkge1xyXG5cclxuICAgIGxldCBjcmVhdG9yX2lkID0gZGF0YS5jcmVhdG9yX2lkO1xyXG4gICAgXHJcbiAgICBsZXQgcmVzID0gW107XHJcblxyXG4gICAgbGV0IHRhZ29uID0gYXN5bmMgKHRhZykgPT4ge1xyXG4gICAgICByZXMucHVzaChcclxuICAgICAgICBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAgICdkdGJfcHJvZHVjdF90YWcnLFxyXG4gICAgICAgICAge30sXHJcbiAgICAgICAgICB7XHJcbiAgICAgICAgICAgIHByb2R1Y3RfaWQ6IGRhdGEucHJvZHVjdF9pZCxcclxuICAgICAgICAgICAgdGFnOiB0YWcsXHJcbiAgICAgICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JfaWRcclxuICAgICAgICAgIH1cclxuICAgICAgICApKTt9O1xyXG5cclxuICAgIGxldCB0YWdvZmYgPSBhc3luYyAodGFnKSA9PiB7XHJcbiAgICAgIGxldCBzcWwgPSBgXHJcbiAgICAgIERFTEVURSBGUk9NIGR0Yl9wcm9kdWN0X3RhZyBcclxuICAgICAgV0hFUkUgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfSBBTkQgdGFnID0gJHt0YWd9XHJcbiAgICAgIGA7XHJcbiAgICAgIHJlcy5wdXNoKCBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpICk7XHJcbiAgICB9O1xyXG5cclxuICAgIGZvciAobGV0IHRhZ1NldCBvZiBkYXRhLnRhZ3MpIHtcclxuICAgICAgc3dpdGNoICh0YWdTZXQuc2V0KSB7XHJcbiAgICAgICAgY2FzZSAnb24nOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb24odGFnU2V0LnRhZyk7XHJcbiAgICAgICAgICBicmVhaztcclxuICAgICAgICBjYXNlICdvZmYnOlxyXG4gICAgICAgICAgYXdhaXQgdGFnb2ZmKHRhZ1NldC50YWcpO1xyXG4gICAgICAgICAgYnJlYWs7XHJcbiAgICAgIH1cclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfTtcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0SW1hZ2VVcGRhdGUoZGF0YSkge1xyXG5cclxuICAgIGxldCBwcm9kdWN0X2lkID0gZGF0YS5wcm9kdWN0X2lkO1xyXG4gICAgbGV0IGltYWdlcyA9IGRhdGEuaW1hZ2VzO1xyXG4gICAgbGV0IGNyZWF0b3JfaWQgPSBkYXRhLmNyZWF0b3JfaWQ7XHJcblxyXG4gICAgbGV0IHJlcyA9IFtdO1xyXG5cclxuICAgIC8vIOWVhuWTgeOBq+mWoumAo+OBmeOCi+OBmeOBueOBpuOBrueUu+WDj+aDheWgseOCkuWJiumZpOOBmeOCi1xyXG4gICAgbGV0IHNxbCA9IGBERUxFVEUgRlJPTSBkdGJfcHJvZHVjdF9pbWFnZSBXSEVSRSBwcm9kdWN0X2lkID0gJHtwcm9kdWN0X2lkfWA7XHJcbiAgICByZXMucHVzaChhd2FpdCB0aGlzLm15c3FsXy5xdWVyeShzcWwpKTtcclxuXHJcbiAgICAvLyDmlLnjgoHjgabnlLvlg4/jgpLnmbvpjLLjgZfjgarjgYrjgZlcclxuICAgIGZvciAobGV0IGkgPSAwOyBpIDwgaW1hZ2VzLmxlbmd0aDsgaSsrKSB7XHJcblxyXG4gICAgICB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgICAnZHRiX3Byb2R1Y3RfaW1hZ2UnLCB7XHJcbiAgICAgICAgICBwcm9kdWN0X2lkOiBwcm9kdWN0X2lkLFxyXG4gICAgICAgICAgY3JlYXRvcl9pZDogY3JlYXRvcl9pZCxcclxuICAgICAgICAgIGZpbGVfbmFtZTogaW1hZ2VzW2ldLFxyXG4gICAgICAgICAgcmFuazogaSArIDFcclxuICAgICAgICB9LCB7XHJcbiAgICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICAgIH1cclxuICAgICAgKTtcclxuICAgIH1cclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfTtcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0VXBkYXRlKGRhdGEpIHtcclxuXHJcbiAgICBsZXQgdXBkYXRlX2RhdGEgPSB7fTtcclxuICAgIGxldCBrZXlzID0gW107XHJcblxyXG4gICAgLy8gZHRiX3Byb2R1Y3RcclxuXHJcbiAgICBrZXlzID0gW1xyXG4gICAgICAnc3RhdHVzJyxcclxuICAgICAgJ25hbWUnLFxyXG4gICAgICAnbm90ZScsXHJcbiAgICAgICdkZXNjcmlwdGlvbl9saXN0JyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCcsXHJcbiAgICAgICdzZWFyY2hfd29yZCcsXHJcbiAgICAgICdmcmVlX2FyZWEnXHJcbiAgICBdO1xyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVfZGF0YVtrXSA9IGRhdGFba107XHJcbiAgICB9XHJcblxyXG4gICAgdGhpcy5teXNxbF8ucXVlcnlVcGRhdGUoXHJcbiAgICAgICdkdGJfcHJvZHVjdCcsXHJcbiAgICAgIGBwcm9kdWN0X2lkID0gJHtkYXRhLnByb2R1Y3RfaWR9YCxcclxuICAgICAgdXBkYXRlX2RhdGEsIHtcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuICAgIC8vIGR0Yl9wcm9kdWN0X2NsYXNzXHJcblxyXG4gICAgdXBkYXRlX2RhdGEgPSB7fTtcclxuICAgIGtleXMgPSBbXHJcbiAgICAgICdkZWxpdmVyeV9kYXRlX2lkJyxcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdzYWxlX2xpbWl0JyxcclxuICAgICAgJ3ByaWNlMDEnLFxyXG4gICAgICAncHJpY2UwMicsXHJcbiAgICAgICdkZWxpdmVyeV9mZWUnXHJcbiAgICBdO1xyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVfZGF0YVtrXSA9IGRhdGFba107XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IHJlcyA9IHRoaXMubXlzcWxfLnF1ZXJ5VXBkYXRlKFxyXG4gICAgICAnZHRiX3Byb2R1Y3RfY2xhc3MnLFxyXG4gICAgICBgcHJvZHVjdF9pZCA9ICR7ZGF0YS5wcm9kdWN0X2lkfWAsXHJcbiAgICAgIHVwZGF0ZV9kYXRhLCB7XHJcbiAgICAgICAgdXBkYXRlX2RhdGU6ICdOT1coKSdcclxuICAgICAgfVxyXG4gICAgKTtcclxuXHJcbiAgICByZXR1cm4ge1xyXG4gICAgICByZXM6IHJlc1xyXG4gICAgfTtcclxuXHJcbiAgfVxyXG5cclxuICBhc3luYyBwcm9kdWN0Q3JlYXRlKGRhdGEpIHtcclxuXHJcbiAgICBsZXQgY3JlYXRvcl9pZCA9IGRhdGEuY3JlYXRvcl9pZDtcclxuXHJcbiAgICBsZXQgcmVzID0ge307XHJcblxyXG4gICAgbGV0IHVwZGF0ZV9kYXRhID0ge307XHJcbiAgICBsZXQga2V5cyA9IFtdO1xyXG5cclxuICAgIGtleXMgPSBbXHJcbiAgICAgICduYW1lJyxcclxuICAgICAgJ2Rlc2NyaXB0aW9uX2RldGFpbCdcclxuICAgIF07XHJcbiAgICAvLyB7XHJcbiAgICAvLyAgIG5hbWU6IGl0ZW0ubmFtZSxcclxuICAgIC8vICAgZGVzY3JpcHRpb25fZGV0YWlsOiBpdGVtLmRlc2NyaXB0aW9uLFxyXG4gICAgLy8gfSxcclxuXHJcbiAgICBmb3IgKGxldCBrIG9mIGtleXMpIHtcclxuICAgICAgaWYgKGRhdGFba10pIHVwZGF0ZV9kYXRhW2tdID0gZGF0YVtrXTtcclxuICAgIH1cclxuXHJcbiAgICByZXMucHJvZHVjdF9pZCA9IGF3YWl0IHRoaXMubXlzcWxfLnF1ZXJ5SW5zZXJ0KFxyXG4gICAgICAnZHRiX3Byb2R1Y3QnLFxyXG4gICAgICB1cGRhdGVfZGF0YSwge1xyXG4gICAgICAgIGNyZWF0b3JfaWQ6IGNyZWF0b3JfaWQsXHJcbiAgICAgICAgc3RhdHVzOiAxLFxyXG4gICAgICAgIG5vdGU6ICdOVUxMJyxcclxuICAgICAgICBkZXNjcmlwdGlvbl9saXN0OiAnTlVMTCcsXHJcbiAgICAgICAgc2VhcmNoX3dvcmQ6ICdOVUxMJyxcclxuICAgICAgICBmcmVlX2FyZWE6ICdOVUxMJyxcclxuICAgICAgICBjcmVhdGVfZGF0ZTogJ05PVygpJyxcclxuICAgICAgICB1cGRhdGVfZGF0ZTogJ05PVygpJ1xyXG4gICAgICB9XHJcbiAgICApO1xyXG5cclxuXHJcbiAgICB1cGRhdGVfZGF0YSA9IHt9O1xyXG4gICAga2V5cyA9IFtcclxuICAgICAgJ3Byb2R1Y3RfY29kZScsXHJcbiAgICAgICdwcm9kdWN0X3R5cGVfaWQnLFxyXG4gICAgICAncHJpY2UwMScsXHJcbiAgICAgICdwcmljZTAyJ1xyXG4gICAgXTtcclxuICAgIC8vIHtcclxuICAgIC8vICAgcHJvZHVjdF9jb2RlOiBpdGVtLm1vZGVsLFxyXG4gICAgLy8gICBwcmljZTAxOiBpdGVtLnJldGFpbF9wcmljZSxcclxuICAgIC8vICAgcHJpY2UwMjogaXRlbS5zYWxlc19wcmljZSxcclxuICAgIC8vIH0sXHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVfZGF0YVtrXSA9IGRhdGFba107XHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3RfY2xhc3NfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X2NsYXNzJyxcclxuICAgICAgdXBkYXRlX2RhdGEsIHtcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9yX2lkLFxyXG4gICAgICAgIHByb2R1Y3RfaWQ6IHJlcy5wcm9kdWN0X2lkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIHN0b2NrX3VubGltaXRlZDogMCxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDE6ICdOVUxMJyxcclxuICAgICAgICBjbGFzc19jYXRlZ29yeV9pZDI6ICdOVUxMJyxcclxuICAgICAgICBkZWxpdmVyeV9kYXRlX2lkOiAnTlVMTCcsXHJcbiAgICAgICAgc2FsZV9saW1pdDogJ05VTEwnLFxyXG4gICAgICAgIGRlbGl2ZXJ5X2ZlZTogJ05VTEwnLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgZm9yIChsZXQgayBvZiBrZXlzKSB7XHJcbiAgICAgIGlmIChkYXRhW2tdKSB1cGRhdGVfZGF0YVtrXSA9IGRhdGFba107XHJcbiAgICB9XHJcblxyXG4gICAgcmVzLnByb2R1Y3Rfc3RvY2tfaWQgPSBhd2FpdCB0aGlzLm15c3FsXy5xdWVyeUluc2VydChcclxuICAgICAgJ2R0Yl9wcm9kdWN0X3N0b2NrJywge30sIHtcclxuICAgICAgICBwcm9kdWN0X2NsYXNzX2lkOiByZXMucHJvZHVjdF9jbGFzc19pZCxcclxuICAgICAgICBjcmVhdG9yX2lkOiBjcmVhdG9yX2lkLFxyXG4gICAgICAgIHN0b2NrOiAwLFxyXG4gICAgICAgIGNyZWF0ZV9kYXRlOiAnTk9XKCknLFxyXG4gICAgICAgIHVwZGF0ZV9kYXRlOiAnTk9XKCknXHJcbiAgICAgIH1cclxuICAgICk7XHJcblxyXG4gICAgLy8gZm9yIHRlc3RcclxuICAgIHJldHVybiB7XHJcbiAgICAgIHJlczogcmVzXHJcbiAgICB9O1xyXG5cclxuICB9XHJcblxyXG59IiwiaW1wb3J0IHsgTW9uZ28gfSBmcm9tIFwibWV0ZW9yL21vbmdvXCI7XHJcbmltcG9ydCB7IE1ldGVvciB9IGZyb20gXCJtZXRlb3IvbWV0ZW9yXCI7XHJcblxyXG4vLyB2YWxpZGF0ZSBvYmplY3RzICYgZmlsdGVyIGFycmF5cyB3aXRoIG1vbmdvZGIgcXVlcmllc1xyXG5pbXBvcnQgc2lmdCBmcm9tIFwic2lmdFwiO1xyXG5pbXBvcnQgbW9iamVjdCBmcm9tIFwibW9uZ29vYmplY3RcIjtcclxuXHJcbmV4cG9ydCBjbGFzcyBEQkZpbHRlckZhY3Rvcnkge1xyXG4gIGNvbnN0cnVjdG9yKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIGxldCBpbnN0YW5jZTtcclxuICAgIHN3aXRjaCAocGx1Zy50eXBlKSB7XHJcbiAgICAgIGNhc2UgXCJteXNxbFwiOlxyXG4gICAgICAgIGluc3RhbmNlID0gbmV3IE15c3FsREJGaWx0ZXIocGx1ZywgcHJvZmlsZSk7XHJcbiAgICB9XHJcblxyXG4gICAgcmV0dXJuIGluc3RhbmNlO1xyXG4gIH1cclxufVxyXG5cclxuZXhwb3J0IGNsYXNzIERCRmlsdGVyIHtcclxuICAvLyBEQiDjgYvjgonjg4fjg7zjgr/jgpLlj5blvpfjgZnjgovjg5fjg63jgrvjgrlcclxuICBpbXBvcnQ7XHJcblxyXG4gIGNvbnN0cnVjdG9yKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHRoaXMucGx1ZyA9IHBsdWc7XHJcbiAgICB0aGlzLnByb2ZpbGUgPSBwcm9maWxlO1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZhY3RvcnkocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgbGV0IGluc3RhbmNlO1xyXG4gICAgc3dpdGNoIChwbHVnLnR5cGUpIHtcclxuICAgICAgY2FzZSBcIm15c3FsXCI6XHJcbiAgICAgICAgcmV0dXJuIG5ldyBNeXNxbERCRmlsdGVyKHBsdWcsIHByb2ZpbGUpO1xyXG4gICAgICBkZWZhdWx0OlxyXG4gICAgICAgIHRocm93IG5ldyBFcnJvcihcImludmFsaWQgcGx1ZyB0eXBlXCIpO1xyXG4gICAgfVxyXG4gIH1cclxuXHJcbiAgZ2V0UGx1Z18oKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wbHVnO1xyXG4gIH1cclxuXHJcbiAgZ2V0Q3JlZF8oKSB7XHJcbiAgICByZXR1cm4gdGhpcy5wbHVnLmNyZWQ7XHJcbiAgfVxyXG5cclxuICBnZXRQcm9maWxlXygpIHtcclxuICAgIHJldHVybiB0aGlzLnByb2ZpbGU7XHJcbiAgfVxyXG5cclxuICBzZXRJbXBvcnRGdW5jdGlvbl8oXHJcbiAgICBmbiA9IGFzeW5jIChvblJlc3VsdCA9IHJlY29yZCA9PiB7fSwgb25FcnJvciA9IGUgPT4ge30pID0+IHt9XHJcbiAgKSB7XHJcbiAgICB0aGlzLmltcG9ydCA9IGZuO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogdHJhY2VzIG1lbWJlcnMgb2YgdGhlIGdyb3VwXHJcbiAgICogdXNlYWdlOlxyXG4gICAqIFxyXG4gICAqIFxyXG4gICAqIEBwYXJhbSB7IE9iamVjdCB9IGl0ZXJhdG9ycyB7IGZpbHRlck5hbWU6IGFzeW5jIChkb2MsY29udGV4dCk9Pnt9LCAuLi4gfSBpdGVyYXRvciBmb3IgZWFjaCBmaWx0ZXJzIFxyXG4gICAqIEBwYXJhbSB7IGFzeW5jIGZ1bmN0aW9uIH0gb25FcnJvciBlcnJvciBoYW5kbGVyIHdoaWxlIGl0ZXJhdGluZ1xyXG4gICAqIEByZXR1cm5zIHsgT2JqZWN0IH0geyBmaWx0ZXJOYW1lOiB7IHF1ZXJ5OiBhbnksIGNvdW50OiBudW1iZXIgfSwgLi4uIH1cclxuICAgKi9cclxuICBhc3luYyBmb3JlYWNoKGl0ZXJhdG9ycyA9IHt9KSB7XHJcbiAgICBsZXQgcHJvZmlsZSA9IHRoaXMuZ2V0UHJvZmlsZV8oKTtcclxuXHJcbiAgICAvLyBtaXNjIOODleOCo+ODq+OCv+ODvOOCkuacq+WwvuOBq+iHquWLlei/veWKoFxyXG4gICAgcHJvZmlsZS5maWx0ZXJzLnB1c2goe1xyXG4gICAgICBuYW1lOiAnbWlzYycsXHJcbiAgICAgIHF1ZXJ5OiB7fVxyXG4gICAgfSk7XHJcblxyXG4gICAgbGV0IGNvdW50ZXIgPSB7fTtcclxuICAgIGZvciAobGV0IGYgb2YgcHJvZmlsZS5maWx0ZXJzKSB7XHJcbiAgICB9XHJcblxyXG4gICAgbGV0IGZpbHRlcnMgPSBbXTtcclxuXHJcbiAgICBmb3IgKGxldCBmIG9mIHByb2ZpbGUuZmlsdGVycykge1xyXG4gICAgICBjb3VudGVyW2YubmFtZV0gPSB7XHJcbiAgICAgICAgcXVlcnk6IGYucXVlcnksXHJcbiAgICAgICAgbGltaXQ6IHR5cGVvZiBmLmxpbWl0ICE9PSAndW5kZWZpbmVkJyA/IGYubGltaXQgOiAwICxcclxuICAgICAgICBjb3VudDogMFxyXG4gICAgICB9O1xyXG4gICAgICBmaWx0ZXJzLnB1c2goXHJcbiAgICAgICAge1xyXG4gICAgICAgICAgbmFtZTogZi5uYW1lLFxyXG4gICAgICAgICAgZXhhbTogc2lmdCggbW9iamVjdC51bmVzY2FwZShmLnF1ZXJ5KSApXHJcbiAgICAgICAgfVxyXG4gICAgICApO1xyXG4gICAgfVxyXG5cclxuICAgIGF3YWl0IHRoaXMuaW1wb3J0KFxyXG4gICAgICBhc3luYyAocmVjb3JkLCBjb250ZXh0KSA9PiB7XHJcblxyXG4gICAgICAgIGZvciAobGV0IGYgb2YgZmlsdGVycykge1xyXG5cclxuICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgbGV0IGMgPSBjb3VudGVyW2YubmFtZV07XHJcbiAgICAgICAgICBpZiggYy5saW1pdCApe1xyXG4gICAgICAgICAgICBpZiggYy5jb3VudCA+PSBjLmxpbWl0ICl7XHJcbiAgICAgICAgICAgICAgY29udGludWU7XHJcbiAgICAgICAgICAgIH1cclxuICAgICAgICAgIH1cclxuXHJcbiAgICAgICAgICBpZiAoZi5leGFtKHJlY29yZCkpIHtcclxuXHJcbiAgICAgICAgICAgIC8vIGNvdW50ZXIgbGltaXRlclxyXG4gICAgICAgICAgICBjLmNvdW50Kys7XHJcblxyXG4gICAgICAgICAgICAvLyBpdGVyYXRvclxyXG4gICAgICAgICAgICBpZiAodHlwZW9mIGl0ZXJhdG9yc1tmLm5hbWVdICE9PSBcInVuZGVmaW5lZFwiKSB7XHJcbiAgICAgICAgICAgICAgYXdhaXQgaXRlcmF0b3JzW2YubmFtZV0ocmVjb3JkLCBjb250ZXh0KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgICBicmVhaztcclxuXHJcbiAgICAgICAgICB9XHJcbiAgICAgICAgfVxyXG4gICAgICB9KTtcclxuXHJcbiAgICAvLyByZXR1cm4gcmVzdWx0IG9mIGZpbHRlcmluZ1xyXG4gICAgcmV0dXJuIGNvdW50ZXI7XHJcbiAgfVxyXG59XHJcblxyXG5pbXBvcnQgTXlTUUwgZnJvbSBcIi4uL3V0aWwvbXlzcWxcIjtcclxuXHJcbmV4cG9ydCBjbGFzcyBNeXNxbERCRmlsdGVyIGV4dGVuZHMgREJGaWx0ZXIge1xyXG4gIGNvbnN0cnVjdG9yKHBsdWcsIHByb2ZpbGUpIHtcclxuICAgIHN1cGVyKHBsdWcsIHByb2ZpbGUpO1xyXG5cclxuICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpO1xyXG5cclxuICAgIHRoaXMubXlzcWwgPSBuZXcgTXlTUUwoY3JlZCk7XHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuICAgICAgbGV0IHNxbCA9IGBTRUxFQ1QgKiBGUk9NICR7cGx1Zy50YWJsZX1gO1xyXG4gICAgICByZXR1cm4gYXdhaXQgdGhpcy5teXNxbC5zdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0LCAoZSk9Pnt0aHJvdyBlfSk7XHJcbiAgICB9KTtcclxuICB9XHJcbn1cclxuXHJcbi8vIGltcG9ydCBNb25nb05hdGl2ZSBmcm9tICdtb25nb2RiJztcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSBNb25nb05hdGl2ZS5Nb25nb0NsaWVudDtcclxuLy8gY29uc3QgTW9uZ29DbGllbnQgPSByZXF1aXJlKCdtb25nb2RiJykuTW9uZ29DbGllbnQ7XHJcbmltcG9ydCB7TW9uZ29DbGllbnR9IGZyb20gJ21vbmdvZGInO1xyXG5cclxuZXhwb3J0IGNsYXNzIE1vbmdvREJGaWx0ZXIgZXh0ZW5kcyBEQkZpbHRlciB7XHJcbiAgY29uc3RydWN0b3IocGx1ZywgcHJvZmlsZSkge1xyXG4gICAgc3VwZXIocGx1ZywgcHJvZmlsZSk7XHJcblxyXG4gICAgLy8gbW9uZ28g44G45o6l57aaXHJcbiAgICB0aGlzLnNldEltcG9ydEZ1bmN0aW9uXyhhc3luYyAob25SZXN1bHQsIG9uRXJyb3IpID0+IHtcclxuXHJcbiAgICAgIGxldCBjbGllbnQ7XHJcbiAgICAgIGNsaWVudCA9IGF3YWl0IE1vbmdvQ2xpZW50LmNvbm5lY3QocGx1Zy51cmkpO1xyXG5cclxuICAgICAgLy8g44Kz44Os44Kv44K344On44Oz44KS5Y+W5b6XXHJcbiAgICAgIGxldCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKTtcclxuICAgICAgbGV0IGNvbGxlY3Rpb24gPSBkYi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XHJcbiAgXHJcbiAgICAgIGxldCBjb250ZXh0ID0ge1xyXG4gICAgICAgIGNsaWVudDogY2xpZW50LFxyXG4gICAgICAgIGNvbGxlY3Rpb246IGNvbGxlY3Rpb24sXHJcbiAgICAgICAgZGF0YWJhc2U6IGRiXHJcbiAgICAgIH07XHJcblxyXG4gICAgICBsZXQgY3VyID0gY29sbGVjdGlvbi5maW5kKCk7XHJcbiAgICAgIFxyXG4gICAgICB3aGlsZSggYXdhaXQgY3VyLmhhc05leHQoKSApe1xyXG4gICAgICAgIGxldCBkb2MgPSBhd2FpdCBjdXIubmV4dCgpO1xyXG4gICAgICAgIGF3YWl0IG9uUmVzdWx0KGRvYywgY29udGV4dCk7XHJcbiAgICAgIH07XHJcblxyXG4gICAgfSk7XHJcblxyXG4gIH1cclxufVxyXG5cclxuXHJcbi8vIGltcG9ydCBtb25nb29zZSBmcm9tICdtb25nb29zZSc7XHJcblxyXG4vLyBleHBvcnQgY2xhc3MgTW9uZ29EQkZpbHRlciBleHRlbmRzIERCRmlsdGVyIHtcclxuLy8gICBjb25zdHJ1Y3RvcihwbHVnLCBwcm9maWxlKSB7XHJcbi8vICAgICBzdXBlcihwbHVnLCBwcm9maWxlKTtcclxuXHJcbi8vICAgICAvLyBtb25nbyDjgbjmjqXntppcclxuLy8gICAgIGxldCBjcmVkID0gdGhpcy5nZXRDcmVkXygpO1xyXG4vLyAgICAgbGV0IGNvbnVyaSA9IGBtb25nb2RiOi8vJHtjcmVkLmhvc3R9OiR7Y3JlZC5wb3J0fS8ke2NyZWQuZGF0YWJhc2V9YDtcclxuLy8gICAgIGF3YWl0IG1vbmdvb3NlLmNvbm5lY3QoY29udXJpKTtcclxuXHJcbi8vICAgICAvLyDjgrPjg6zjgq/jgrfjg6fjg7PjgpLkvZzjgotcclxuLy8gICAgIGxldCBjb2xsZWN0aW9uID0gbW9uZ29vc2UuY29ubmVjdGlvbi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XHJcblxyXG4vLyAgICAgdGhpcy5zZXRJbXBvcnRGdW5jdGlvbl8oYXN5bmMgKG9uUmVzdWx0LCBvbkVycm9yKSA9PiB7XHJcbi8vICAgICAgIGxldCBjdXIgPSBjb2xsZWN0aW9uLmZpbmQoKTtcclxuICAgICAgXHJcbi8vICAgICAgIHJldHVybiBhd2FpdCB0aGlzLm15c3FsLnN0cmVhbWluZ1F1ZXJ5KHNxbCwgb25SZXN1bHQsIG9uRXJyb3IpO1xyXG4vLyAgICAgfSk7XHJcbi8vICAgfVxyXG4vLyB9XHJcblxyXG5cclxuIiwiaW1wb3J0IHsgTW9uZ29DbGllbnQgfSBmcm9tICdtb25nb2RiJztcclxuXHJcbmV4cG9ydCBjbGFzcyBNb25nb0NvbGxlY3Rpb257XHJcbiAgc3RhdGljIGFzeW5jIGdldChwbHVnKXtcclxuICAgIGxldCBjbGllbnQgPSBhd2FpdCBNb25nb0NsaWVudC5jb25uZWN0KHBsdWcudXJpKTtcclxuICAgIGxldCBkYiA9IGNsaWVudC5kYihwbHVnLmRhdGFiYXNlKTtcclxuICAgIHJldHVybiBkYi5jb2xsZWN0aW9uKHBsdWcuY29sbGVjdGlvbik7XHJcbiAgfVxyXG59IiwiaW1wb3J0IG15c3FsIGZyb20gJ215c3FsJztcclxuaW1wb3J0IG1vbWVudCBmcm9tICdtb21lbnQnO1xyXG5cclxuXHJcbmV4cG9ydCBkZWZhdWx0IGNsYXNzIE15U1FMIHtcclxuXHJcbiAgY29uc3RydWN0b3IocHJvZmlsZSkge1xyXG4gICAgLy8g44Kz44ON44Kv44K344On44Oz44OX44O844Or5Yid5pyf5YyWXHJcbiAgICB0aGlzLnBvb2wgPSBteXNxbC5jcmVhdGVQb29sKHByb2ZpbGUpO1xyXG5cclxuICAgIC8vIOikh+aVsOihjOOCueODhuODvOODiOODoeODs+ODiOWvvuW/nFxyXG4gICAgbGV0IHByb2ZpbGVNdWx0aSA9IHttdWx0aXBsZVN0YXRlbWVudHM6dHJ1ZX07XHJcbiAgICBPYmplY3QuYXNzaWduKCBwcm9maWxlTXVsdGksIHByb2ZpbGUgKTtcclxuICAgIHRoaXMucG9vbE11bHRpID0gbXlzcWwuY3JlYXRlUG9vbChwcm9maWxlTXVsdGkpO1xyXG4gIH1cclxuXHJcbiAgc3RhdGljIGZvcm1hdERhdGUoIGRhdGUgKXtcclxuICAgIHJldHVybiBtb21lbnQoZGF0ZSkuZm9ybWF0KCkuc3Vic3RyaW5nKDAsMTkpLnJlcGxhY2UoJ1QnLCAnICcpO1xyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHNxbCBcclxuICAgKi9cclxuICBxdWVyeShzcWwpIHtcclxuXHJcbiAgICAvLyDjgrPjg43jgq/jgrfjg6fjg7Pnorrnq4tcclxuICAgIC8vIGxldCBjb24gPSBhd2FpdCB0aGlzLmdldENvbigpO1xyXG4gICAgcmV0dXJuIHRoaXMuZ2V0Q29uKClcclxuICAgICAgLnRoZW4oXHJcbiAgICAgICAgKGNvbikgPT4ge1xyXG4gICAgICAgICAgcmV0dXJuIG5ldyBQcm9taXNlKFxyXG4gICAgICAgICAgICBhc3luYyAocmVzb2x2ZSwgcmVqZWN0KSA9PiB7XHJcbiAgICAgICAgICAgICAgLy8g44Kv44Ko44Oq6YCB5L+hXHJcbiAgICAgICAgICAgICAgY29uLnF1ZXJ5KHNxbCwgKGUsIHJlcykgPT4ge1xyXG4gICAgICAgICAgICAgICAgLy8g44Kz44ON44Kv44K344On44Oz6ZaL5pS+XHJcbiAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpO1xyXG4gICAgICAgICAgICAgICAgaWYgKGUpIHtcclxuICAgICAgICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgICAgICAgICAgfSBlbHNlIHJlc29sdmUocmVzKTtcclxuICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH0pO1xyXG4gIH07XHJcblxyXG4gIGFzeW5jIHF1ZXJ5SW5zZXJ0XyhzcWwpe1xyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcbiAgfVxyXG4gIFxyXG4gIC8qKlxyXG4gICAqIFxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSB0YWJsZSBcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YSDmloflrZfliJfjga7jg5Hjg6njg6Hjg7zjgr/jg7zjgIFudWxs44CBamF2YXNjcmlwdC0+bXlzcWzml6Xku5jlpInmj5vjgavjgoLlr77lv5xcclxuICAgKiBAcGFyYW0ge09iamVjdH0gZGF0YV9zcWwgU1FM44K544OG44O844OI44Oh44Oz44OI44KE5pWw5a2X44Gq44Gp5paH5a2X5YiX5Lul5aSW44Gu44OR44Op44Oh44O844K/XHJcbiAgICovXHJcbiAgIGFzeW5jIHF1ZXJ5SW5zZXJ0KHRhYmxlLCBkYXRhID0ge30sIGRhdGFfc3FsID0ge30pe1xyXG5cclxuICAgIC8vIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XHJcbiAgICAvLyByZXR1cm4gcmVzLmluc2VydElkO1xyXG5cclxuICAgIGxldCBzcWwgPSBgSU5TRVJUIElOVE8gJHt0YWJsZX0gYDtcclxuXHJcbiAgICBsZXQgbWFwID0gbmV3IE1hcCgpO1xyXG4gICAgZm9yKCBsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhKSApe1xyXG5cclxuICAgICAgaWYgKGRhdGFba10gPT09IG51bGwpe1xyXG4gICAgICAgIG1hcC5zZXQoaywgJ05VTEwnKTtcclxuICAgICAgfVxyXG4gICAgICBlbHNlIGlmIChkYXRhW2tdLmNvbnN0cnVjdG9yLm5hbWUgPT09ICdEYXRlJykge1xyXG4gICAgICAgIC8vIOaXpeS7mOOCkuWkieaPm1xyXG4gICAgICAgIG1hcC5zZXQoaywgYFwiJHtNeVNRTC5mb3JtYXREYXRlKGRhdGFba10pfVwiYCk7XHJcbiAgICAgIH1cclxuICAgICAgZWxzZXtcclxuICAgICAgICBtYXAuc2V0KGssIGBcIiR7ZGF0YVtrXX1cImApO1xyXG4gICAgICB9XHJcblxyXG4gICAgfVxyXG4gICAgZm9yKCBsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhX3NxbCkgKXtcclxuICAgICAgbWFwLnNldChrLCBkYXRhX3NxbFtrXSA9PT0gbnVsbCA/ICdOVUxMJyA6IGRhdGFfc3FsW2tdKTtcclxuICAgIH1cclxuXHJcbiAgICBzcWwgKz0gYCggJHtbLi4ubWFwLmtleXMoKV0uam9pbignLCcpfSApIGA7XHJcblxyXG4gICAgc3FsICs9IGBWQUxVRVMoICR7Wy4uLm1hcC52YWx1ZXMoKV0uam9pbignLCcpfSApIGA7XHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIHJldHVybiByZXMuaW5zZXJ0SWQ7XHJcblxyXG4gIH1cclxuXHJcbiAgLyoqXHJcbiAgICogXHJcbiAgICogQHBhcmFtIHtTdHJpbmd9IHRhYmxlIFxyXG4gICAqIEBwYXJhbSB7U3RyaW5nfSBmaWx0ZXIgU1FMIFVQREFUReOCueODhuODvOODiOODoeODs+ODiOOBrldIRVJF5Y+lXHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGEg5paH5a2X5YiX44Gu44OR44Op44Oh44O844K/44O8XHJcbiAgICogQHBhcmFtIHtPYmplY3R9IGRhdGFfc3FsIFNRTOOCueODhuODvOODiOODoeODs+ODiOOChOaVsOWtl+OBquOBqeaWh+Wtl+WIl+S7peWkluOBruODkeODqeODoeODvOOCv1xyXG4gICAqL1xyXG4gIGFzeW5jIHF1ZXJ5VXBkYXRlKHRhYmxlLCBmaWx0ZXIsIGRhdGEsIGRhdGFfc3FsKXtcclxuICAgIGxldCBzcWwgPSBgVVBEQVRFICR7dGFibGV9IFNFVCBgO1xyXG5cclxuICAgIGxldCB1cGRhdGVzID0gW107XHJcbiAgICBmb3IoIGxldCBrIG9mIE9iamVjdC5rZXlzKGRhdGEpICl7XHJcbiAgICAgIHVwZGF0ZXMucHVzaChgJHtrfT1cIiR7ZGF0YVtrXX1cImApO1xyXG4gICAgfVxyXG4gICAgZm9yKCBsZXQgayBvZiBPYmplY3Qua2V5cyhkYXRhX3NxbCkgKXtcclxuICAgICAgdXBkYXRlcy5wdXNoKGAke2t9PSR7ZGF0YV9zcWxba119YCk7XHJcbiAgICB9XHJcbiAgICBzcWwgKz0gdXBkYXRlcy5qb2luKCcsJyk7XHJcblxyXG4gICAgc3FsICs9IGAgV0hFUkUgJHtmaWx0ZXJ9IGA7XHJcblxyXG4gICAgbGV0IHJlcyA9IGF3YWl0IHRoaXMucXVlcnkoc3FsKTtcclxuICAgIHJldHVybiByZXM7XHJcbiAgfVxyXG5cclxuICAvLyBlbmFibGUgdG8gdXNlIG11bHRpcGxlIHN0YXRlbWVudHNcclxuICBhc3luYyBxdWVyeU11bHRpKHNxbCkge1xyXG4gICAgbGV0IHBvb2xTd2FwID0gdGhpcy5wb29sO1xyXG4gICAgdGhpcy5wb29sID0gdGhpcy5wb29sTXVsdGk7XHJcbiAgICB0cnl7XHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCB0aGlzLnF1ZXJ5KHNxbCk7XHJcbiAgICAgIHJldHVybiByZXM7XHJcbiAgICB9XHJcbiAgICBmaW5hbGx5e1xyXG4gICAgICB0aGlzLnBvb2wgPSBwb29sU3dhcDtcclxuICAgIH1cclxuICB9XHJcblxyXG4gIGFzeW5jIHN0YXJ0VHJhbnNhY3Rpb24oKXtcclxuICAgIGF3YWl0IHRoaXMucXVlcnkoYFNUQVJUIFRSQU5TQUNUSU9OO2ApO1xyXG4gIH1cclxuXHJcbiAgYXN5bmMgY29tbWl0KCl7XHJcbiAgICBhd2FpdCB0aGlzLnF1ZXJ5KGBDT01NSVQ7YCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyByb2xsYmFjaygpe1xyXG4gICAgYXdhaXQgdGhpcy5xdWVyeShgUk9MTEJBQ0s7YCk7XHJcbiAgfVxyXG5cclxuICBzdHJlYW1pbmdRdWVyeShzcWwsIG9uUmVzdWx0ID0gKHJlY29yZCkgPT4ge30sIG9uRXJyb3IgPSAoZSkgPT4ge30pIHtcclxuICAgIHJldHVybiB0aGlzLmdldENvbigpXHJcbiAgICAgIC50aGVuKFxyXG4gICAgICAgIChjb24pID0+IHtcclxuICAgICAgICAgIHJldHVybiBuZXcgUHJvbWlzZShcclxuICAgICAgICAgICAgYXN5bmMgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgICAgIC8vIOOCr+OCqOODqumAgeS/oVxyXG4gICAgICAgICAgICAgIGNvbi5xdWVyeShzcWwpXHJcbiAgICAgICAgICAgICAgICAub24oJ3Jlc3VsdCcsXHJcbiAgICAgICAgICAgICAgICAgIChyZWNvcmQpID0+IHtcclxuICAgICAgICAgICAgICAgICAgICBjb24ucGF1c2UoKTtcclxuICAgICAgICAgICAgICAgICAgICBvblJlc3VsdChyZWNvcmQpO1xyXG4gICAgICAgICAgICAgICAgICAgIGNvbi5yZXN1bWUoKTtcclxuICAgICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZXJyb3InLCAoZSkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBvbkVycm9yKGUpO1xyXG4gICAgICAgICAgICAgICAgfSlcclxuICAgICAgICAgICAgICAgIC5vbignZW5kJywgKCkgPT4ge1xyXG4gICAgICAgICAgICAgICAgICBjb24ucmVsZWFzZSgpO1xyXG4gICAgICAgICAgICAgICAgICByZXNvbHZlKCk7XHJcbiAgICAgICAgICAgICAgICB9KTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgKTtcclxuXHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaCgoZSkgPT4ge1xyXG4gICAgICAgIHRocm93IGU7XHJcbiAgICAgIH0pO1xyXG5cclxuICB9XHJcblxyXG5cclxuICBnZXRDb24oKSB7XHJcbiAgICByZXR1cm4gbmV3IFByb21pc2UoXHJcbiAgICAgICAgKHJlc29sdmUsIHJlamVjdCkgPT4ge1xyXG4gICAgICAgICAgLy8g44OX44O844Or44GL44KJ44Gu44Kz44ON44Kv44K344On44Oz542y5b6XXHJcbiAgICAgICAgICB0aGlzLnBvb2wuZ2V0Q29ubmVjdGlvbigoZSwgY29uKSA9PiB7XHJcbiAgICAgICAgICAgIGlmIChlKSB7XHJcbiAgICAgICAgICAgICAgcmVqZWN0KGUpO1xyXG4gICAgICAgICAgICB9IGVsc2Uge1xyXG4gICAgICAgICAgICAgIHJlc29sdmUoY29uKTtcclxuICAgICAgICAgICAgfVxyXG4gICAgICAgICAgfSk7XHJcbiAgICAgICAgfVxyXG4gICAgICApXHJcbiAgICAgIC5jYXRjaChcclxuICAgICAgICAoZSkgPT4ge1xyXG4gICAgICAgICAgdGhyb3cgZTtcclxuICAgICAgICB9XHJcbiAgICAgICk7XHJcbiAgfTtcclxuXHJcbn0iLCJleHBvcnQgZGVmYXVsdCBjbGFzcyBSZXBvcnQge1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIHRoaXMucmVjb3JkID0gW107XHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbmV3IEl0ZXJhdG9yKCk7XHJcbiAgfVxyXG5cclxuICBhc3luYyBwaGFzZShuYW1lID0gJycsIGZuID0gYXN5bmMgKCkgPT4ge30pIHtcclxuXHJcbiAgICB0aGlzLml0ZXJhdG9yID0gbmV3IEl0ZXJhdG9yKCk7XHJcbiAgICBsZXQgcmVjID0ge307XHJcblxyXG4gICAgdHJ5IHtcclxuXHJcbiAgICAgIGxldCByZXMgPSBhd2FpdCBmbigpO1xyXG5cclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnc3VjY2VzcycsXHJcbiAgICAgICAgcGhhc2U6IG5hbWUsXHJcbiAgICAgICAgcmVzdWx0OiByZXNcclxuICAgICAgfSk7XHJcblxyXG4gICAgfSBjYXRjaCAoZSkge1xyXG5cclxuICAgICAgT2JqZWN0LmFzc2lnbihyZWMsIHtcclxuICAgICAgICB0eXBlOiAnZXJyb3InLFxyXG4gICAgICAgIHBoYXNlOiBuYW1lLFxyXG4gICAgICAgIHJlc3VsdDogZVxyXG4gICAgICB9KTtcclxuXHJcbiAgICB9IGZpbmFsbHkge1xyXG5cclxuICAgICAgaWYgKHRoaXMuaXRlcmF0b3IudG90YWwpIHtcclxuICAgICAgICBPYmplY3QuYXNzaWduKHJlYywge1xyXG4gICAgICAgICAgaXRlcmF0b3I6IHRoaXMuaXRlcmF0b3JcclxuICAgICAgICB9KTtcclxuICAgICAgfVxyXG4gICAgICB0aGlzLnJlY29yZC5wdXNoKHJlYyk7XHJcblxyXG4gICAgfVxyXG5cclxuICB9XHJcblxyXG4gIGlTdWNjZXNzKG5ld1JlY29yZCkge1xyXG4gICAgdGhpcy5pdGVyYXRvci5zdWNjZXNzKG5ld1JlY29yZCk7XHJcbiAgfVxyXG5cclxuICBpRXJyb3IobmV3UmVjb3JkKSB7XHJcbiAgICB0aGlzLml0ZXJhdG9yLmVycm9yKG5ld1JlY29yZCk7XHJcbiAgfVxyXG5cclxuICBlcnJvck9jdXJyZWQoKXtcclxuICAgIGxldCBpdGVFcnJvciA9IHRoaXMuaXRlcmF0b3IudHJhY2UuZXJyb3IudG90YWw7XHJcbiAgICBsZXQgcGhhRXJyb3IgPSBmYWxzZTtcclxuICAgIGZvciggbGV0IHJlYyBvZiB0aGlzLnJlY29yZCApe1xyXG4gICAgICBpZiggcmVjLnR5cGUgPT09ICdlcnJvcicpe1xyXG4gICAgICAgIHBoYUVycm9yID0gdHJ1ZTtcclxuICAgICAgICBicmVhaztcclxuICAgICAgfVxyXG4gICAgfVxyXG4gICAgcmV0dXJuIGl0ZUVycm9yIHx8IHBoYUVycm9yO1xyXG4gIH1cclxuXHJcbiAgcHVibGlzaCgpIHtcclxuICAgIGlmKHRoaXMuZXJyb3JPY3VycmVkKCkpe1xyXG4gICAgICB0aHJvdyBuZXcgTWV0ZW9yLkVycm9yKHRoaXMucmVjb3JkKTtcclxuICAgIH1cclxuICAgIHJldHVybiB0aGlzLnJlY29yZDtcclxuICB9XHJcblxyXG59XHJcblxyXG5cclxuY2xhc3MgSXRlcmF0b3Ige1xyXG5cclxuICBjb25zdHJ1Y3RvcigpIHtcclxuICAgIHRoaXMudG90YWwgPTA7XHJcbiAgICB0aGlzLnRyYWNlID0ge1xyXG4gICAgICBzdWNjZXNzOiB7XHJcbiAgICAgICAgdG90YWw6IDAsXHJcbiAgICAgICAgcmVjb3JkczogW11cclxuICAgICAgfSxcclxuICAgICAgZXJyb3I6IHtcclxuICAgICAgICB0b3RhbDogMCxcclxuICAgICAgICByZWNvcmRzOiBbXVxyXG4gICAgICB9LFxyXG4gICAgfTtcclxuICB9XHJcblxyXG4gIHN1Y2Nlc3MobmV3UmVjb3JkKSB7XHJcbiAgICBpZihuZXdSZWNvcmQpe1xyXG4gICAgICB0aGlzLnRyYWNlLnN1Y2Nlc3MucmVjb3Jkcy5wdXNoKG5ld1JlY29yZCk7XHJcbiAgICB9XHJcbiAgICB0aGlzLnRyYWNlLnN1Y2Nlc3MudG90YWwrKztcclxuICAgIHRoaXMudG90YWwrKztcclxuICB9XHJcbiAgZXJyb3IobmV3UmVjb3JkKSB7XHJcbiAgICBpZihuZXdSZWNvcmQgJiYgbmV3UmVjb3JkICE9PSB7fSAmJiBuZXdSZWNvcmQgIT09JycgKXtcclxuICAgICAgdGhpcy50cmFjZS5lcnJvci5yZWNvcmRzLnB1c2goSlNPTi5wYXJzZShuZXdSZWNvcmQpKTtcclxuICAgIH1cclxuICAgIHRoaXMudHJhY2UuZXJyb3IudG90YWwrKztcclxuICAgIHRoaXMudG90YWwrKztcclxuICB9XHJcblxyXG59XHJcbiJdfQ==
